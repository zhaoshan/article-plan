package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G3 更换 Owner 集成测试（2026-10-29 自同事实现换回 74e76be 我方语义，docs/08 §6）：
 * EXISTING_MEMBER 即时 swap（旧 Owner is_owner→is_admin 降级）；
 * INVITE_BY_EMAIL 角色切换延期到 accept（转移时只建邀请，同意后 swap 原子完成）；
 * 单 Owner 校验（setRoles 通道 400）、parlant 退化（owner 即 admin → 旧 Owner 卸角色让位）、双轨鉴权。
 */
class OwnerTransferIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("access_token").toString();
    }

    private String adminToken() throws Exception {
        return login("admin", "admin123");
    }

    private String createUser(String token, String username) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + username + "@unify.local\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("user_id").toString();
    }

    private String createTenant(String token, String code, String appCode, String ownerUserId) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"" + code + "\",\"tenant_name\":\"" + code + "\","
                                + "\"app_codes\":[\"" + appCode + "\"],\"owner_user_id\":\"" + ownerUserId + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
    }

    private String addMember(String token, String tenantId, String userId) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"" + tenantId + "\",\"user_id\":\"" + userId + "\",\"role_ids\":[]}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("membership_id").toString();
    }

    private java.util.List<String> roleCodesOf(String tenantId, String userId) {
        return jdbcTemplate.queryForList(
                "SELECT r.role_code FROM gateway_membership_role mr "
                        + "JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_role r ON mr.role_id=r.role_id "
                        + "WHERE m.tenant_id=? AND m.user_id=? AND mr.delete_flag=0 AND m.delete_flag=0 AND r.delete_flag=0",
                String.class, tenantId, userId);
    }

    @Test
    void transferToExistingMemberDemotesOldOwnerToAdmin() throws Exception {
        String token = adminToken();
        String uidA = createUser(token, "own_a");
        String uidB = createUser(token, "own_b");
        String tenantId = createTenant(token, "g3-t1", "imorph", uidA);
        String msB = addMember(token, tenantId, uidB);
        assertThat(roleCodesOf(tenantId, uidA)).containsExactly("iMorph-Owner");

        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"mode\":\"EXISTING_MEMBER\",\"membership_id\":\"" + msB + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("OWNER_CHANGED"))
                .andExpect(jsonPath("$.data.owner_user_id").value(uidB));

        // 新 Owner 持 Owner；旧 Owner 降级 Admin（不再持 Owner）
        assertThat(roleCodesOf(tenantId, uidB)).contains("iMorph-Owner");
        assertThat(roleCodesOf(tenantId, uidA)).containsExactly("iMorph-Admin");
        String ownerUserId = jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId);
        assertThat(ownerUserId.trim()).isEqualTo(uidB);

        // 单 Owner：setRoles 通道再给旧 Owner 授 Owner 角色 → 400
        String ownerRole = jdbcTemplate.queryForObject(
                "SELECT role_id FROM gateway_role WHERE scope_id=? AND role_code='iMorph-Owner'",
                String.class, tenantId).trim();
        String msA = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id=? AND user_id=?",
                String.class, tenantId, uidA);
        mockMvc.perform(put("/api/v1/admin/members/" + msA.trim() + "/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"" + ownerRole + "\"]}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("Owner uniqueness")));

        // 转移越权/参数校验
        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"mode\":\"EXISTING_MEMBER\",\"membership_id\":\"ms-9999\"}"))
                .andExpect(status().isNotFound()); // Membership not found

        // 双轨鉴权：新 Owner（持 iMorph-Owner、无 iam:* 权限）可再转交回 A；普通成员 C → 403
        String uidC = createUser(token, "own_c");
        addMember(token, tenantId, uidC);
        jdbcTemplate.update("UPDATE gateway_membership SET is_default=1 WHERE tenant_id=? AND user_id=?", tenantId, uidB);
        String tokenB = login("own_b", "Passw0rd!");
        jdbcTemplate.update("UPDATE gateway_user SET must_change_password=0 WHERE username='own_b'");
        String msA2 = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id=? AND user_id=?",
                String.class, tenantId, uidA);
        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + tokenB) // B 是租户 Owner
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"mode\":\"EXISTING_MEMBER\",\"membership_id\":\"" + msA2.trim() + "\"}"))
                .andExpect(status().isOk());
        jdbcTemplate.update("UPDATE gateway_membership SET is_default=1 WHERE tenant_id=? AND user_id=?", tenantId, uidC);
        String tokenC = login("own_c", "Passw0rd!");
        jdbcTemplate.update("UPDATE gateway_user SET must_change_password=0 WHERE username='own_c'");
        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + tokenC) // C 是普通成员
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"mode\":\"EXISTING_MEMBER\",\"membership_id\":\"" + msA2.trim() + "\"}"))
                .andExpect(status().isForbidden());
    }

    @Test
    void transferByInviteEmailDefersRoleSwapUntilAccept() throws Exception {
        String token = adminToken();
        String uidA = createUser(token, "own2_a");
        String tenantId = createTenant(token, "g3-t2", "imorph", uidA);

        // ① 转移：只发邀请（defaultRoleId=iMorph-Owner），角色与指针不动
        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"mode\":\"INVITE_BY_EMAIL\",\"email\":\"own2_new@unify.local\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("OWNER_INVITATION_SENT"));

        String uidNew = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE primary_email='own2_new@unify.local'", String.class).trim();
        // JIT 初始密码账号 + 受邀租户 = 默认成员关系（首登不 401）
        assertThat(jdbcTemplate.queryForObject(
                "SELECT must_change_password FROM gateway_user WHERE user_id=?", Integer.class, uidNew)).isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT is_default FROM gateway_membership WHERE tenant_id=? AND user_id=?",
                Integer.class, tenantId, uidNew)).isEqualTo(1);
        // 角色延期：转移后新账号零角色、旧 Owner 仍持 Owner、指针未动
        assertThat(roleCodesOf(tenantId, uidNew)).isEmpty();
        assertThat(roleCodesOf(tenantId, uidA)).containsExactly("iMorph-Owner");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId).trim())
                .isEqualTo(uidA);
        String ownerRoleId = jdbcTemplate.queryForObject(
                "SELECT role_id FROM gateway_role WHERE scope_id=? AND role_code='iMorph-Owner'",
                String.class, tenantId).trim();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE tenant_id=? AND email='own2_new@unify.local'",
                String.class, tenantId).trim()).isEqualTo(ownerRoleId);

        // ② 同意（accept）：swap 原子完成——新 Owner 授 Owner、旧 Owner 降 Admin、指针切换
        String rawToken = "owner-transfer-own2-token";
        jdbcTemplate.update("UPDATE gateway_invitation SET invite_token_hash=? WHERE tenant_id=? AND email='own2_new@unify.local'",
                com.unify.iam.common.util.SecureToken.hash(rawToken), tenantId);
        // JIT 初始密码未知：换成已知口令哈希（admin 的）后登录
        jdbcTemplate.update("UPDATE gateway_user SET password_hash=(SELECT password_hash FROM (SELECT password_hash FROM gateway_user WHERE username='admin') t) WHERE user_id=?", uidNew);
        String newToken = login("own2_new@unify.local", "admin123");
        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken + "/accept")
                        .header("Authorization", "Bearer " + newToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"));

        assertThat(roleCodesOf(tenantId, uidNew)).containsExactly("iMorph-Owner");
        assertThat(roleCodesOf(tenantId, uidA)).containsExactly("iMorph-Admin");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId).trim())
                .isEqualTo(uidNew);
    }

    @Test
    void parlantDegenerateTransferOldOwnerStepsDown() throws Exception {
        String token = adminToken();
        String uidA = createUser(token, "own3_a");
        String uidB = createUser(token, "own3_b");
        // parlant TenantAdmin 模板 is_owner=1 且 is_admin=1（退化：owner 即 admin，同角色）
        String tenantId = createTenant(token, "g3-t3", "parlant-agent-server", uidA);
        String msB = addMember(token, tenantId, uidB);
        assertThat(roleCodesOf(tenantId, uidA)).contains("TenantAdmin");

        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"mode\":\"EXISTING_MEMBER\",\"membership_id\":\"" + msB + "\"}"))
                .andExpect(status().isOk());

        // 退化情形：降级目标=Owner 角色自身 → 旧 Owner 卸 TenantAdmin 让位（不重复授予）
        assertThat(roleCodesOf(tenantId, uidB)).contains("TenantAdmin");
        assertThat(roleCodesOf(tenantId, uidA)).doesNotContain("TenantAdmin");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId).trim())
                .isEqualTo(uidB);
    }
}

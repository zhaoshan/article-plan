-- G1 Usage 配额模型（docs/requirements/M10W4-W5 §G1，模板驱动）：
--   gateway_quota_dimension = 维度注册表/模板（app_code 归属：iam=租户全局；具体应用=应用专属；source=IAM 计数强制 / BUSINESS 业务上报只存上限）
--   gateway_tenant_quota    = 租户级调额覆盖（无行 = 用模板默认 default_limit）
CREATE TABLE IF NOT EXISTS `gateway_quota_dimension` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `dimension_id` CHAR(32) NOT NULL COMMENT '配额维度业务唯一标识',
  `app_code` VARCHAR(64) NOT NULL COMMENT '归属应用：iam=租户全局维度；具体应用=应用专属维度',
  `dimension_key` VARCHAR(64) NOT NULL COMMENT '维度键：members/apps/agents/storage_mb…',
  `dimension_name` VARCHAR(128) NOT NULL COMMENT '展示名（Members/Apps/…）',
  `unit` VARCHAR(16) DEFAULT NULL COMMENT '单位（可空）',
  `default_limit` INT DEFAULT NULL COMMENT '模板默认上限；NULL=不限',
  `source` VARCHAR(16) NOT NULL DEFAULT 'IAM' COMMENT '计数来源：IAM=IAM 实时计数并强制；BUSINESS=业务应用上报，IAM 只存上限',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '展示顺序，小者先',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_quota_dimension_id` (`dimension_id`),
  UNIQUE KEY `uk_quota_dimension_app_key` (`app_code`, `dimension_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='配额维度注册表（模板）：新增应用维度=插行，不迁移';

CREATE TABLE IF NOT EXISTS `gateway_tenant_quota` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `tenant_quota_id` CHAR(32) NOT NULL COMMENT '租户配额覆盖业务唯一标识',
  `tenant_id` CHAR(32) NOT NULL COMMENT '租户ID；逻辑关联 gateway_tenant.tenant_id',
  `dimension_id` CHAR(32) NOT NULL COMMENT '配额维度ID；逻辑关联 gateway_quota_dimension.dimension_id',
  `limit_value` INT DEFAULT NULL COMMENT '租户级覆盖上限；NULL=用模板默认（等同无覆盖，正常不存 NULL）',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_quota_id` (`tenant_quota_id`),
  UNIQUE KEY `uk_tenant_quota_dimension` (`tenant_id`, `dimension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户配额调额覆盖表（无行=用模板默认）';

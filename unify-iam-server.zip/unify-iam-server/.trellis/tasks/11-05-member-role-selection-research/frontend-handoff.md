# Backend contract for frontend integration

## Query
`GET /api/v1/admin/tenant/roles?tenant_id=<actual target tenant ID>`

The user-facing route `/v1/admin/tenant/roles` carries the project's `/api` prefix externally. Do not use the earlier proposed `/admin/members/role-options` path. Authorization: Bearer with iam:member:read and permitted target tenant. Platform scope in a member-list view is not a target tenant ID; use each selected member row's real tenant_id. Invite uses its selected target tenant.

Success example (nullable values omitted):

```json
{"success":true,"data":{"tenant_id":"tenant-org-a","roles":[{"role_id":"custom-global","role_code":"Support","role_name":"Support","scope_type":"PLATFORM","scope_id":"PLATFORM","role_status":"ACTIVE","is_builtin":false,"is_owner":false},{"role_id":"local-reader","role_code":"Reader","role_name":"Reader","scope_type":"TENANT","scope_id":"tenant-org-a","role_status":"ACTIVE","is_builtin":true,"is_owner":false}],"count":2}}
```

role_description is optional. count equals returned rows, not selectable count. All non-deleted matching roles, including disabled tenant/global custom roles, are returned. No can_assign, no new server-enforced 禁选 policy. Query does not establish write authorization. Continue respecting existing application treatment of role_status without claiming a newly approved status policy.

Errors: 401 auth, 403 member-read/target isolation, 400 missing/blank tenant_id, 404 authorized absent/deleted tenant; existing failure envelope and centralized error codes. Empty success is roles=[]/count=0.

## Loading and Source
- Both dialogs use this same catalog. Edit current selection remains GET `/api/v1/admin/members/{membershipId}/roles`; do not conflate selected roles with candidates or drop missing Owner bindings.
- Edit: show role-row skeletons while candidates/current selections are pending; do not save a default empty/intersected array before initialization.
- Invite: loading must not disable the trigger; open panel displays skeleton during pending and actual options immediately on success. Distinguish error/retry from empty success. Explicitly selected role_id is still needed for submit; omission can invoke legacy Owner fallback.
- Ignore stale tenant/identity responses and scope caches by tenant and auth context.
- Source column after Role reads existing `members[].join_source`, e.g. OWNER, INVITE, ADMIN, SSO, SELF_REGISTER. Use the actual field, not role scope, user type or grant_source.

## Unresolved global grant integration — do not claim full end-to-end support
POST `/api/v1/admin/invitations` still accepts a singular role_id and currently rejects every PLATFORM candidate with HTTP400/IAM-ROLE-011. PUT member roles accepts a list but lacks a complete grant-eligibility validator. Any custom PLATFORM binding currently makes a holder pass platform scope guards when endpoint permission exists. No grant/identity change has been approved or implemented here; the UI must not silently treat global grants as safe or replace the pending decision with a newly invented disabled-option policy. Product decision and server-side write validation remain a release blocker for fully using these global options in both mutation flows.

-- ============================================================
-- Web Scraper Service — 爬取任务表 DDL
-- 数据库: MySQL 8.0+
-- 执行前请先创建数据库:
--   CREATE DATABASE web_scraper DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- ============================================================

CREATE TABLE IF NOT EXISTS crawl_tasks (
    -- 自增主键
    id              INT             NOT NULL AUTO_INCREMENT PRIMARY KEY
                                    COMMENT '主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】',

    -- 业务主键
    task_id         VARCHAR(36)     NOT NULL
                                    COMMENT '任务 UUID【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 任务分类
    task_type       VARCHAR(32)     NOT NULL
                                    COMMENT '任务类型: tree / dynamic / full_site / scheduled_full_site / content【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    site            VARCHAR(256)    NOT NULL DEFAULT ''
                                    COMMENT '站点域名（如 tokyostarbank.co.jp）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 任务状态
    status          VARCHAR(16)     NOT NULL DEFAULT 'pending'
                                    COMMENT '任务状态: pending / running / completed / failed【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 请求参数
    target_url      VARCHAR(2048)   NOT NULL DEFAULT ''
                                    COMMENT '爬取入口 URL【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    max_depth       INT             NULL
                                    COMMENT '最大爬取深度（NULL=使用配置默认值）【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    headless        TINYINT          NOT NULL DEFAULT 1
                                    COMMENT '是否无头模式运行浏览器【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    output_type     VARCHAR(8)      NOT NULL DEFAULT 'local'
                                    COMMENT '输出方式: local（本地文件）/ s3（S3 存储）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 输出文件路径
    links_path      VARCHAR(1024)   NULL
                                    COMMENT 'all_unique_links_{ts}.json 文件路径（local=相对路径, s3=S3 URL）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    tree_path       VARCHAR(1024)   NULL
                                    COMMENT 'tree_structure_{ts}.json 文件路径（local=相对路径, s3=S3 URL）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 执行进度
    pages_crawled   INT             NOT NULL DEFAULT 0
                                    COMMENT '已爬取页面数【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    links_found     INT             NOT NULL DEFAULT 0
                                    COMMENT '已发现链接数【updt:n】【Sec:D】【STD:Num】【Fmat:n】',

    -- 错误信息
    error_message   TEXT            NULL
                                    COMMENT '错误信息（失败时记录）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 时间戳
    create_time     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    COMMENT '添加时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    update_time     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                                    COMMENT '更新时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    finished_at     DATETIME        NULL
                                    COMMENT '完成/失败时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    schedule_id     VARCHAR(36)     NULL
                                    COMMENT '关联 crawl_schedules.schedule_id，周期性调度任务时填写【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 索引
    UNIQUE INDEX idx_task_id (task_id),
    INDEX idx_status (status),
    INDEX idx_site (site),
    INDEX idx_task_type (task_type),
    INDEX idx_create_time (create_time),
    INDEX idx_task_schedule_id (schedule_id)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='爬取任务表';


-- ============================================================
-- 全量链接树表 — 按站点组织，体现树层级
-- 数据来源: config/all_links_tag_result.xlsx（业务字段）
--          + output/tree_structure_{ts}.json（树层级字段）
-- ============================================================

CREATE TABLE IF NOT EXISTS crawl_link_tree (
    -- 自增主键
    id                  INT             NOT NULL AUTO_INCREMENT PRIMARY KEY
                                        COMMENT '主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】',

    -- 站点与链接
    site                VARCHAR(256)    NOT NULL DEFAULT ''
                                        COMMENT '站点域名（如 tokyostarbank.co.jp，与 config 配置文件一致）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    url                 VARCHAR(768)    NOT NULL
                                        COMMENT '链接 URL（业务唯一键，已标准化，实测最大 224 字符）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 树结构层级信息（来自 tree_structure JSON）
    level               INT             NOT NULL DEFAULT 0
                                        COMMENT '树层级（根节点=0，每下钻一层+1）【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    parent_url          VARCHAR(768)   NULL
                                        COMMENT '父节点 URL（根节点为 NULL）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    is_leaf             TINYINT         NOT NULL DEFAULT 0
                                        COMMENT '是否叶子节点（1=是, 0=否）【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    node_type           VARCHAR(16)     NULL
                                        COMMENT '节点类型: cross_domain（外域）/ file（同域文件）/ dynamic（动态）（仅叶子节点）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    not_found           TINYINT         NOT NULL DEFAULT 0
                                        COMMENT '是否未找到页面（1=页面内容命中 not_found_texts, 0=否）【updt:n】【Sec:D】【STD:Num】【Fmat:n】',

    -- Excel 业务字段（来自 all_links_tag_result.xlsx）
    domain              VARCHAR(256)    NOT NULL DEFAULT ''
                                        COMMENT '域名（Excel B 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    sub_path            VARCHAR(1024)   NULL
                                        COMMENT '子路径（Excel C 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    file_name           VARCHAR(512)    NULL
                                        COMMENT '文件名（链接结尾带 html/pdf，Excel D 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    link_type           VARCHAR(16)     NOT NULL DEFAULT ''
                                        COMMENT '链接类型: HTML/PDF/DOC 等（Excel E 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    site_owner          VARCHAR(8)      NOT NULL DEFAULT ''
                                        COMMENT '网站归属: 自社/他社（Excel F 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    service_category    VARCHAR(64)     NULL
                                        COMMENT '服务大类别（Excel G 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    service_subcategory VARCHAR(64)     NULL
                                        COMMENT '服务小类别（Excel H 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    download_flag       VARCHAR(4)      NULL
                                        COMMENT '是否下载（建议处理方式）: Y/N（Excel I 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    remark              VARCHAR(256)    NULL
                                        COMMENT '说明（Excel J 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    custom_tag          VARCHAR(64)     NULL
                                        COMMENT '自定义标记（对应原文档更新时间，Excel K 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    update_history      VARCHAR(64)     NULL
                                        COMMENT '更新履历（如 删除/补数据，Excel L 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    update_time_tag     DATETIME        NULL
                                        COMMENT '更新时间（Excel M 列维护）【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    last_crawl_time     DATETIME        NULL
                                        COMMENT '最后爬取时间（Excel N 列）【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    content_hash        VARCHAR(80)     NULL
                                        COMMENT '页面标识 content_hash（Excel O 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 内容爬取产物字段
    page_title          VARCHAR(512)    NULL
                                        COMMENT '页面标题（网页取 <title>，附件/图片取文件名）【updt:y】【Sec:D】【STD:varchar】【Fmat:anc】',
    crawl_file_list     JSON            NULL
                                        COMMENT '爬取产物文件清单 JSON 数组：[{file_type,file_size,s3_path}]【updt:y】【Sec:D】【STD:varchar】【Fmat:anc】',

    -- 时间戳
    create_time         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                        COMMENT '添加时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    update_time         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                                        COMMENT '更新时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',

    -- 索引
    UNIQUE INDEX idx_clt_url (url),
    INDEX idx_clt_site (site),
    INDEX idx_clt_level (level),
    INDEX idx_clt_parent (parent_url),
    INDEX idx_clt_domain (domain)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='全量链接树节点表';


-- ============================================================
-- 增量升级语句（已有库执行，全新库可忽略，create_all 会自动建列）
-- ============================================================
-- ALTER TABLE crawl_tasks
--     MODIFY COLUMN task_type VARCHAR(32) NOT NULL
--         COMMENT '任务类型: tree / dynamic / full_site / scheduled_full_site / content【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】';
-- ALTER TABLE crawl_tasks
--     ADD COLUMN schedule_id VARCHAR(36) NULL
--         COMMENT '关联 crawl_schedules.schedule_id，周期性调度任务时填写【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】'
--         AFTER finished_at;
-- ALTER TABLE crawl_tasks
--     ADD INDEX idx_task_schedule_id (schedule_id);

-- ALTER TABLE crawl_link_tree
--     ADD COLUMN page_title      VARCHAR(512) NULL
--         COMMENT '页面标题（网页取 <title>，附件/图片取文件名）【updt:y】【Sec:D】【STD:varchar】【Fmat:anc】'
--         AFTER content_hash,
--     ADD COLUMN crawl_file_list JSON NULL
--         COMMENT '爬取产物文件清单 JSON 数组：[{file_type,file_size,s3_path}]【updt:y】【Sec:D】【STD:varchar】【Fmat:anc】'
--         AFTER page_title;


-- ============================================================
-- 定时调度配置表
-- ============================================================

CREATE TABLE IF NOT EXISTS crawl_schedules (
    id              INT             NOT NULL AUTO_INCREMENT PRIMARY KEY
                                    COMMENT '主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    schedule_id     VARCHAR(36)     NOT NULL
                                    COMMENT '调度 UUID，兼做 APScheduler job id【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    site            VARCHAR(256)    NOT NULL
                                    COMMENT '站点域名（如 tokyostarbank.co.jp）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    target_url      VARCHAR(2048)   NOT NULL
                                    COMMENT '爬取入口 URL【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    cron_expression VARCHAR(64)     NOT NULL
                                    COMMENT '标准 5 字段 cron 表达式，如 0 2 * * *【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    timezone        VARCHAR(64)     NOT NULL DEFAULT 'Asia/Tokyo'
                                    COMMENT 'cron 时区，如 Asia/Tokyo【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    enabled         TINYINT         NOT NULL DEFAULT 1
                                    COMMENT '是否启用：1=启用，0=禁用【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    max_depth       INT             NULL
                                    COMMENT '最大爬取深度（NULL=使用遍历配置默认值）【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    headless        TINYINT         NOT NULL DEFAULT 1
                                    COMMENT '是否无头模式：1=是，0=否【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    output_type     VARCHAR(8)      NOT NULL DEFAULT 's3'
                                    COMMENT '输出方式：local / s3【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    description     VARCHAR(512)    NULL
                                    COMMENT '调度描述【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    create_time     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    COMMENT '创建时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    update_time     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                                    COMMENT '更新时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',

    UNIQUE INDEX idx_schedule_id (schedule_id),
    INDEX idx_schedule_site (site),
    INDEX idx_schedule_enabled (enabled)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='定时调度配置表';


-- ============================================================
-- 定时调度执行日志表
-- ============================================================

CREATE TABLE IF NOT EXISTS crawl_schedule_logs (
    id              INT             NOT NULL AUTO_INCREMENT PRIMARY KEY
                                    COMMENT '主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    log_id          VARCHAR(36)     NOT NULL
                                    COMMENT '日志 UUID【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    schedule_id     VARCHAR(36)     NOT NULL
                                    COMMENT '关联 crawl_schedules.schedule_id【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    task_id         VARCHAR(36)     NULL
                                    COMMENT '关联 crawl_tasks.task_id【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    site            VARCHAR(256)    NOT NULL
                                    COMMENT '本次执行站点域名【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    target_url      VARCHAR(2048)   NOT NULL
                                    COMMENT '本次执行入口 URL【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    status          VARCHAR(16)     NOT NULL DEFAULT 'pending'
                                    COMMENT '执行状态：pending / running / completed / failed / skipped【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    trigger_type    VARCHAR(16)     NOT NULL DEFAULT 'cron'
                                    COMMENT '触发方式：cron / manual【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    links_path      VARCHAR(1024)   NULL
                                    COMMENT 'all_unique_links_{ts}.json 文件路径【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    tree_path       VARCHAR(1024)   NULL
                                    COMMENT 'tree_structure_{ts}.json 文件路径【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    pages_crawled   INT             NOT NULL DEFAULT 0
                                    COMMENT '已爬取页面数【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    links_found     INT             NOT NULL DEFAULT 0
                                    COMMENT '已发现链接数【updt:n】【Sec:D】【STD:Num】【Fmat:n】',
    error_message   TEXT            NULL
                                    COMMENT '失败原因【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】',
    started_at      DATETIME        NULL
                                    COMMENT '开始执行时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    finished_at     DATETIME        NULL
                                    COMMENT '完成/失败时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',
    create_time     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                    COMMENT '记录创建时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】',

    UNIQUE INDEX idx_log_id (log_id),
    INDEX idx_log_schedule_id (schedule_id),
    INDEX idx_log_status (status),
    INDEX idx_log_create_time (create_time)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='定时调度执行日志表';

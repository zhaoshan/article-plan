package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

/** 当前用户 membership 租户投影：真实数据库关联、用户隔离和最小权限。 */
@Transactional
class SelfMembershipTenantCodeIntegrationTest extends IamIntegrationTestBase {

    @org.junit.jupiter.api.BeforeEach
    void isolateViewerMemberships() {
        jdbcTemplate.update("DELETE FROM gateway_membership WHERE user_id='u-1002' AND membership_id <> 'ms-3001'");
    }

    private LoginResponse viewerLogin() throws Exception {
        String json = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"viewer\",\"password\":\"" + b64("view123") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return JsonUtils.fromJson(dataJson(json), LoginResponse.class);
    }

    private void tenant(String id, String code, String name, String state, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_tenant
                  (tenant_id, tenant_code, tenant_name, tenant_type, tenant_status, delete_flag)
                VALUES (?, ?, ?, 'ORGANIZATION', ?, ?)
                """, id, code, name, state, deleted);
    }

    private void membership(String id, String tenantId, String userId, String state, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_membership
                  (membership_id, tenant_id, user_id, membership_status, is_default, delete_flag)
                VALUES (?, ?, ?, ?, 0, ?)
                """, id, tenantId, userId, state, deleted);
    }

    @Test
    void memberOnlyUserReceivesRealCodesForOwnTenantsWithoutTenantReadPermission() throws Exception {
        jdbcTemplate.update("""
                UPDATE gateway_tenant SET tenant_name='当前租户', tenant_code='self-current-live'
                WHERE tenant_id='tenant-org-a'
                """);
        tenant("self-second", "self-second-code", "我的第二租户", "ACTIVE", 0);
        membership("self-second-ms", "self-second", "u-1002", "ACTIVE", 0);
        tenant("self-foreign", "foreign-secret-code", "其他用户租户", "ACTIVE", 0);
        membership("self-foreign-ms", "self-foreign", "u-1001", "ACTIVE", 0);

        LoginResponse login = viewerLogin();
        assertThat(login.user().permissions()).doesNotContain(PermissionCodes.IAM_TENANT_READ);
        String bearer = "Bearer " + login.accessToken();

        // 即使伪造查询目标，查询仍只使用已验签 token 的 userId。
        String json = mockMvc.perform(get("/api/v1/auth/memberships")
                        .header("Authorization", bearer)
                        .param("user_id", "u-1001").param("tenant_id", "self-foreign"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.count").value(2))
                .andReturn().getResponse().getContentAsString();
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> memberships = (List<Map<String, Object>>) unwrapField(json, "memberships");
        assertThat(memberships).hasSize(2);
        assertThat(memberships.get(0)).containsAllEntriesOf(Map.of(
                "membership_id", "ms-3001", "tenant_id", "tenant-org-a",
                "tenant_name", "当前租户", "tenant_code", "self-current-live",
                "membership_status", "ACTIVE", "is_default", 1, "is_current", true));
        assertThat(memberships.get(1)).containsAllEntriesOf(Map.of(
                "membership_id", "self-second-ms", "tenant_id", "self-second",
                "tenant_name", "我的第二租户", "tenant_code", "self-second-code",
                "membership_status", "ACTIVE", "is_default", 0, "is_current", false));

        // 不因此获得全局租户列表、本人租户详情或其他租户详情的管理权限。
        for (String path : List.of("/api/v1/admin/tenants", "/api/v1/admin/tenants/tenant-org-a",
                "/api/v1/admin/tenants/self-foreign")) {
            mockMvc.perform(get(path).header("Authorization", bearer))
                    .andExpect(status().isForbidden())
                    .andExpect(jsonPath("$.success").value(false));
        }
    }

    @Test
    void unavailableTenantsAndDeletedMembershipsRemainExcluded() throws Exception {
        tenant("self-suspended", "suspended-code", "停用租户", "SUSPENDED", 0);
        tenant("self-deleted", "deleted-code", "已删除租户", "ACTIVE", 1);
        tenant("self-removed", "removed-code", "已退出租户", "ACTIVE", 0);
        tenant("self-pending", "pending-code", "待加入租户", "ACTIVE", 0);
        membership("self-suspended-ms", "self-suspended", "u-1002", "ACTIVE", 0);
        membership("self-deleted-ms", "self-deleted", "u-1002", "ACTIVE", 0);
        membership("self-removed-ms", "self-removed", "u-1002", "ACTIVE", 1);
        membership("self-missing-ms", "self-missing", "u-1002", "ACTIVE", 0);
        membership("self-pending-ms", "self-pending", "u-1002", "PENDING", 0);

        mockMvc.perform(get("/api/v1/auth/memberships")
                        .header("Authorization", "Bearer " + viewerLogin().accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(2))
                .andExpect(jsonPath("$.data.memberships[0].tenant_id").value("tenant-org-a"))
                .andExpect(jsonPath("$.data.memberships[0].tenant_code").value("org-a"))
                .andExpect(jsonPath("$.data.memberships[1].tenant_id").value("self-pending"))
                .andExpect(jsonPath("$.data.memberships[1].tenant_name").value("待加入租户"))
                .andExpect(jsonPath("$.data.memberships[1].tenant_code").value("pending-code"))
                .andExpect(jsonPath("$.data.memberships[1].membership_status").value("PENDING"));
    }

    @Test
    void missingAndInvalidBearerReturn401WithoutMembershipData() throws Exception {
        mockMvc.perform(get("/api/v1/auth/memberships"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.data.memberships").doesNotExist());
        mockMvc.perform(get("/api/v1/auth/memberships").header("Authorization", "Bearer invalid"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.data.memberships").doesNotExist());
    }
}

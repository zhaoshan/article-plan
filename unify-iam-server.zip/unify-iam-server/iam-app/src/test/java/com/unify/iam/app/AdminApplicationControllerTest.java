package com.unify.iam.app;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.AdminApplicationController;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.TemplatePermissionAdminService;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.config.WebMvcConfig;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import com.unify.iam.authorization.app.model.TemplatePermissionAddResult;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.ErrorCode;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

/** {@link AdminApplicationController}：应用角色模板新增权限点（iam:tenant:write）。 */
@WebMvcTest(AdminApplicationController.class)
@Import({GlobalExceptionHandler.class, WebMvcConfig.class, ManagementAuthorizationInterceptor.class})
class AdminApplicationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private JwtSigner jwtSigner;
    @MockitoBean
    private TemplatePermissionAdminService templatePermissionAdminService;
    @MockitoBean
    private com.unify.iam.authorization.app.service.ApplicationTemplateService applicationTemplateService;
    @MockitoBean
    private AuditService auditService;
    @MockitoBean
    private AuditLogRepository auditLogRepository;

    @Test
    void tenantWriterCanAddPermissionAndItIsAudited() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_WRITE));
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));
        // 控制器原样透传（trim 是 service 层职责），故桩/断言都用原始值
        when(templatePermissionAdminService.add(any())).thenReturn(new TemplatePermissionAdminService
                .TemplatePermissionChange(
                new TemplatePermissionAddResult("imorph", "iMorph-Admin", "agent:deploy", true, 42, false), 0, 0));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":" imorph ","role_code":"iMorph-Admin",
                                 "permission_code":"agent:deploy","operator":"ops-zhao"}"""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.app_code").value("imorph"))
                .andExpect(jsonPath("$.data.added").value(true))
                .andExpect(jsonPath("$.data.permission_count").value(42))
                .andExpect(jsonPath("$.data.created_permission").value(false))
                .andExpect(jsonPath("$.data.sync_tenants").value(false))
                .andExpect(jsonPath("$.data.synced_role_count").value(0))
                .andExpect(jsonPath("$.data.bumped_membership_count").value(0));
        verify(templatePermissionAdminService).add(any());
    }

    @Test
    void createPermissionReportsCreatedFlag() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_WRITE));
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));
        when(templatePermissionAdminService.add(any())).thenReturn(new TemplatePermissionAdminService
                .TemplatePermissionChange(
                new TemplatePermissionAddResult("parlant-agent-server", "Viewer", "parlant-agent:deploy:read",
                        true, 10, true), 0, 0));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":"parlant-agent-server","role_code":"Viewer",
                                 "permission_code":"parlant-agent:deploy:read","operator":"zhaoshan",
                                 "create_permission":true,"permission_name":"查看部署",
                                 "resource_type":"Deploy","action":"read"}"""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.added").value(true))
                .andExpect(jsonPath("$.data.created_permission").value(true));
    }

    @Test
    void syncTenantsReportsSyncCounts() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_WRITE));
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));
        when(templatePermissionAdminService.add(any())).thenReturn(new TemplatePermissionAdminService
                .TemplatePermissionChange(
                new TemplatePermissionAddResult("imorph", "iMorph-Admin", "agent:deploy", true, 42, false), 3, 17));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":"imorph","role_code":"iMorph-Admin",
                                 "permission_code":"agent:deploy","operator":"ops-zhao","sync_tenants":true}"""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.added").value(true))
                .andExpect(jsonPath("$.data.sync_tenants").value(true))
                .andExpect(jsonPath("$.data.synced_role_count").value(3))
                .andExpect(jsonPath("$.data.bumped_membership_count").value(17));
    }

    @Test
    void idempotentReplayReportsAddedFalse() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_WRITE));
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));
        when(templatePermissionAdminService.add(any())).thenReturn(new TemplatePermissionAdminService
                .TemplatePermissionChange(
                new TemplatePermissionAddResult("imorph", "iMorph-Admin", "agent:deploy", false, 42, false), 0, 0));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":"imorph","role_code":"iMorph-Admin",
                                 "permission_code":"agent:deploy","operator":"ops-zhao"}"""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.added").value(false));
    }

    @Test
    void tenantReaderIsRejected() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_READ));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":"imorph","role_code":"iMorph-Admin",
                                 "permission_code":"agent:deploy","operator":"ops-zhao"}"""))
                .andExpect(status().isForbidden());
        verifyNoInteractions(templatePermissionAdminService);
    }

    @Test
    void missingOperatorFailsValidation() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_WRITE));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":"imorph","role_code":"iMorph-Admin","permission_code":"agent:deploy"}"""))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(templatePermissionAdminService);
    }

    @Test
    void unknownTemplateIsNotFound() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_WRITE));
        when(templatePermissionAdminService.add(any()))
                .thenThrow(AuthException.notFound(ErrorCode.TEMPLATE_NOT_FOUND, "imorph:Nope"));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":"imorph","role_code":"Nope",
                                 "permission_code":"agent:deploy","operator":"ops-zhao"}"""))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("IAM-APP-010"));
    }

    @Test
    void unknownPermissionIsBadRequest() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_TENANT_WRITE));
        when(templatePermissionAdminService.add(any()))
                .thenThrow(AuthException.badRequest(ErrorCode.PERMISSION_NOT_FOUND, "agent:deploy"));

        mockMvc.perform(post("/api/v1/admin/applications/role-templates/permissions")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"app_code":"imorph","role_code":"iMorph-Admin",
                                 "permission_code":"agent:deploy","operator":"ops-zhao"}"""))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-PERM-002"));
    }

    private JwtClaims claims(String... permissions) {
        long now = Instant.now().getEpochSecond();
        return new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1",
                "tenant-org-a", "ms-1", List.of("PlatformAdmin"), List.of(permissions), Map.of(),
                now + 3600, now, "jti", 0L);
    }
}

# Independent Trellis check

## Scope
Reviewed current task PRD/design/implementation plan and check.jsonl references, new TenantRoleController/TenantRoleQueryService and TenantRoleOption/TenantRoleOptions, the additive RoleRepository.listForTenantMemberPicker method, new controller/service/MySQL tests, Source regression assertions, and the new backend spec/index. Pre-existing role-management changes were preserved. No production or test edits were needed by this reviewer.

## Findings fixed
None. The implementing agent owns the test fixture cache correction described below.

## Findings not fixed / external scope
- Global-role mutation support remains intentionally incomplete: InvitationService still rejects PLATFORM candidates with IAM-ROLE-011; existing member writes have no complete grant allowlist; any PLATFORM binding satisfies platform scope identity. Query approval does not authorize that security model change, and no can_assign/禁选 rule was invented. The current task artifacts explicitly record this release blocker.
- Initial escalated integration failure after a direct JDBC grant fixture followed a cached false platform guard lookup in the same MyBatis transaction. Implementer corrected test fixture cache invalidation without changing production guard semantics; focused rerun passed 27 tests. This is not evidence that custom PLATFORM roles are safe from scope elevation.

## Review conclusions
- Correct external route /api/v1/admin/tenant/roles with required explicit nonblank tenant_id, member read permission and target guard before existence/data lookups.
- Grouped union preserves logical deletion on both branches, own-tenant isolation, global non-builtin scope, id ASC and exact response count. Owner filtering uses enabled application templates and applies only to TENANT rows; non-owner tenant builtins and DISABLED rows remain visible.
- New read DTO has stable snake_case fields and does not expose persistence entities or claim grantability. Existing management/runtime queries and grant/security paths remain unchanged.
- Source was already real persisted join_source through SELECT m.*, shared member projection and list response. New tests preserve distinct per-membership sources in tenant/global views.
- Existing /api/v1/admin/** interceptor covers the new route. Standard API envelope and error handlers cover success, required parameter and service errors.

## Verification
- Whitespace/static diff check: git diff --check passed.
- Context manifests: task.py validate passed (4 entries each).
- Lint: no dedicated lint plugin configured in project Maven POMs.
- Type/compile and tests: JDK 21 Maven focused suite passed 27 tests; expanded eight-class management regression suite passed 54 tests with zero failures/errors/skips. Reviewer independently checked all eight Surefire XML reports and counts. See implementation-regression.log. No concurrent Maven or Docker processes were launched by the reviewer.

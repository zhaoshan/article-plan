package com.unify.iam.identity.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_idp_group_mapping IdP 组 → 内部角色白名单映射表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_idp_group_mapping")
public class IdpGroupMappingPO extends BaseEntity {

    /** 映射业务唯一标识 */
    private String idpGroupMappingId;
    /** 租户 IdP 配置 ID */
    private String tenantIdpConfigId;
    /** 匹配模式：EXACT/REGEX */
    private String matchMode;
    /** 外部 group 值或正则表达式 */
    private String matchValue;
    /** 目标角色 ID */
    private String targetRoleId;
    /** 匹配优先级：数值越小优先级越高 */
    private Integer priority;
    /** 映射状态：ACTIVE/DISABLED */
    private String mappingStatus;
}
---
description: 查看 unify_iam 数据库状态（Flyway / 表 / 关键数据）
---

用 `docker exec spring-ai-alibaba-mysql sh -c 'mysql -uroot -proot123456 -e "..."'` 查询 `unify_iam`：

- Flyway 版本：`SELECT version,description,success,checksum FROM unify_iam.flyway_schema_history ORDER BY installed_rank;`
- 表清单：`SHOW TABLES IN unify_iam;`
- 关键数据（可选参数指定）：默认输出 `gateway_tenant`、`gateway_tenant_idp_config`、`gateway_idp_group_mapping` 行数或摘要。

注意：迁移已应用不可改（checksum）；若改过迁移文件需走 `flyway repair` 或按 CLAUDE.md「开发注意」处理。

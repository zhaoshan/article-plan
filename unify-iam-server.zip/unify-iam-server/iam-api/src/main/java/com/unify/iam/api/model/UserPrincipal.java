package com.unify.iam.api.model;

/**
 * 认证通过的"用户主体"：凭据校验成功后跨域传递的最小载体。
 *
 * @param userId 用户业务 ID（sub）
 * @param username 登录名
 * @param userIdentityId 命中的本地身份 ID（gateway_user_identity.user_identity_id）
 */
public record UserPrincipal(String userId, String username, String userIdentityId) {
}

"""链接树管理请求模型"""

from pydantic import BaseModel, Field, field_validator


class LinkTreeSyncRequest(BaseModel):
    """链接树增量同步请求参数"""

    model_config = {"extra": "forbid", "str_strip_whitespace": True}

    tree_file: str = Field(
        ...,
        min_length=1,
        max_length=1024,
        description="tree_structure_{ts}.json 文件路径（全量爬取生成的链接树）",
    )
    site: str = Field(
        ...,
        min_length=1,
        max_length=256,
        description="所属站点域名（如 tokyostarbank.co.jp），与 config 配置文件一致",
    )
    headless: bool = Field(
        default=True,
        description="页面验证时是否使用无头浏览器",
    )

    @field_validator("site")
    @classmethod
    def validate_site_no_scheme(cls, v: str) -> str:
        """站点应为裸域名，不含协议和路径"""
        if "://" in v or "/" in v:
            raise ValueError("site 应为裸域名（如 tokyostarbank.co.jp），不含协议或路径")
        return v

"""数据库连接管理

提供异步 SQLAlchemy 引擎和 Session 工厂。
引擎通过 SystemConfig 注入，不再自行读取配置文件或环境变量。
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from src.config.system_config import DatabaseConfig

logger = logging.getLogger(__name__)

# ── 模块级全局变量（init 前为 None） ─────────────────────

_engine = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


# ── 初始化（由应用入口调用） ─────────────────────────────


def init_engine(db_config: DatabaseConfig) -> None:
    """根据 DatabaseConfig 初始化引擎和 Session 工厂。

    Args:
        db_config: 数据库配置（从 SystemConfig 获取）

    Raises:
        ValueError: 数据库配置不完整
    """
    global _engine, _session_factory

    if _engine is not None:
        logger.warning("数据库引擎已初始化，跳过重复初始化")
        return

    db_url = db_config.full_url
    if not db_url:
        raise ValueError("数据库连接 URL 为空，无法初始化引擎")

    engine_kwargs: dict = {
        "echo": db_config.echo,
    }
    # SQLite 不支持连接池大小参数，仅对 MySQL 等长连接方言启用
    if db_config.driver.startswith("mysql"):
        engine_kwargs.update(
            {
                "pool_size": db_config.pool_size,
                "max_overflow": db_config.max_overflow,
                # 连接池回收时间（秒），30 分钟回收避免长时间爬取期间连接被 MySQL/网络设备断开
                "pool_recycle": 1800,
                # 每次从池中取出连接前先 SELECT 1 探活，失效则透明重连
                "pool_pre_ping": True,
            }
        )

    _engine = create_async_engine(
        db_url,
        **engine_kwargs,
    )

    _session_factory = async_sessionmaker(
        _engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    logger.info(
        f"数据库引擎初始化完成: {db_config.full_url}"
    )


def is_initialized() -> bool:
    """引擎是否已初始化"""
    return _engine is not None


def ensure_initialized() -> None:
    """确保引擎已初始化，未初始化时抛出 RuntimeError"""
    if _engine is None or _session_factory is None:
        raise RuntimeError(
            "数据库引擎未初始化，请先调用 init_engine(db_config)"
        )


# ── Session 获取 ────────────────────────────────────────


@asynccontextmanager
async def get_session() -> AsyncSession:
    """获取一个新的异步 Session（调用方负责关闭）

    支持 async with 上下文管理器：
        async with get_session() as session:
            ...

    Raises:
        RuntimeError: 引擎未初始化
    """
    ensure_initialized()
    session = _session_factory()
    try:
        yield session
    finally:
        await session.close()


# ── ORM 基类 ────────────────────────────────────────────


class Base(DeclarativeBase):
    """SQLAlchemy ORM 基类，所有模型继承此类"""
    pass


# ── 生命周期管理 ─────────────────────────────────────────


async def init_db() -> None:
    """初始化数据库表（幂等操作）

    Raises:
        RuntimeError: 引擎未初始化
    """
    ensure_initialized()
    async with _engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("数据库表初始化完成")


async def close_db() -> None:
    """关闭数据库连接池"""
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
        logger.info("数据库连接池已关闭")
    _engine = None
    _session_factory = None
package com.unify.iam.app;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

/**
 * P1-02 登录暴力破解防护集成测试：账号/IP 双维度失败计数 + 冷却锁定（429 IAM-AUTH-020）。
 * 覆盖：账号阈值锁定、不存在账号同样计数、成功清零、IP 维度滑动窗口（XFF 信任开启 + 唯一测试 IP，
 * 避免污染共享单例上下文里其它用例的 127.0.0.1 维度）。
 *
 * <p>配置说明：短窗口用 {@link BeforeEach} 运行时翻转 IamProperties（子类 @DynamicPropertySource
 * 不生效——父类已声明时子类被忽略，既有结论；LoginRateLimiter 调用时读值非启动快照），
 * {@link AfterEach} 还原——IamProperties 为全 JVM 共享单例，必须还原。
 */
class LoginRateLimitIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private com.unify.iam.app.config.IamProperties iamProperties;

    private com.unify.iam.app.config.IamProperties.LoginRateLimit saved;

    @BeforeEach
    void shortenWindows() {
        com.unify.iam.app.config.IamProperties.LoginRateLimit c = iamProperties.getLoginRateLimit();
        saved = new com.unify.iam.app.config.IamProperties.LoginRateLimit();
        saved.setEnabled(c.isEnabled());
        saved.setMaxFailures(c.getMaxFailures());
        saved.setLockSeconds(c.getLockSeconds());
        saved.setIpMaxFailures(c.getIpMaxFailures());
        saved.setIpWindowSeconds(c.getIpWindowSeconds());
        saved.setIpLockSeconds(c.getIpLockSeconds());
        saved.setTrustXff(c.isTrustXff());
        // 短窗口：3 次失败锁 1s；IP 窗 60s 内 3 次锁 1s；信任 XFF（仅本类用例发 XFF 头）
        c.setMaxFailures(3);
        c.setLockSeconds(1);
        c.setIpMaxFailures(3);
        c.setIpWindowSeconds(60);
        c.setIpLockSeconds(1);
        c.setTrustXff(true);
    }

    @AfterEach
    void restoreWindows() {
        com.unify.iam.app.config.IamProperties.LoginRateLimit c = iamProperties.getLoginRateLimit();
        c.setEnabled(saved.isEnabled());
        c.setMaxFailures(saved.getMaxFailures());
        c.setLockSeconds(saved.getLockSeconds());
        c.setIpMaxFailures(saved.getIpMaxFailures());
        c.setIpWindowSeconds(saved.getIpWindowSeconds());
        c.setIpLockSeconds(saved.getIpLockSeconds());
        c.setTrustXff(saved.isTrustXff());
    }

    private String sfx() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    /** 本用例专属 XFF IP：默认 remoteAddr 恒为 127.0.0.1，类内多个用例的失败会累计锁掉该共享 IP 维度。 */
    private String xffIp;

    @BeforeEach
    void freshIp() {
        xffIp = "10.98." + (Math.abs(sfx().hashCode()) % 250) + "." + (Math.abs(sfx().hashCode()) % 250);
    }

    private org.springframework.test.web.servlet.ResultActions login(String username, String password) throws Exception {
        return mockMvc.perform(post("/api/v1/auth/token")
                .header("X-Forwarded-For", xffIp)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"));
    }

    /** 建 LOCAL 用户并加入 tenant-org-a（登录解析需要可用成员关系）。 */
    private void createUserWithMembership(String adminToken, String username) throws Exception {
        String uid = unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + username + "@unify.local\",\"password\":\""
                                + b64("RightPass1!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("user_id").toString();
        mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"user_id\":\"" + uid + "\",\"role_ids\":[]}"))
                .andExpect(status().isOk());
    }

    private String adminToken() throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/auth/token")
                        .header("X-Forwarded-For", xffIp)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("access_token").toString();
    }

    @Test
    void accountLockedAfterConsecutiveFailuresAndUnlocksAfterCooldown() throws Exception {
        String user = "rl_acc_" + sfx();
        for (int i = 0; i < 3; i++) {
            login(user, "WrongPass1!").andExpect(status().isUnauthorized());
        }
        // 第 4 次（即使密码正确）也 429——锁内不再做认证
        login(user, "Whatever1!").andExpect(status().isTooManyRequests())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-020"));
        // 冷却 1s 后恢复：造真实 LOCAL 用户验证解锁（admin 用户名维度与本用例无关）
        Thread.sleep(1100);
        createUserWithMembership(adminToken(), user);
        login(user, "RightPass1!").andExpect(status().isOk());
    }

    @Test
    void nonexistentAccountCountsTowardLock() throws Exception {
        String user = "rl_none_" + sfx();
        for (int i = 0; i < 3; i++) {
            login(user, "WrongPass1!").andExpect(status().isUnauthorized()); // 统一 401，不泄露不存在
        }
        login(user, "WrongPass1!").andExpect(status().isTooManyRequests())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-020"));
        Thread.sleep(1100); // 锁 1s，避免本类后续用例撞上（账号维度 key 唯一，仅为整洁）
    }

    @Test
    void successResetsFailureCounter() throws Exception {
        String user = "rl_reset_" + sfx();
        createUserWithMembership(adminToken(), user);
        login(user, "WrongPass1!").andExpect(status().isUnauthorized());
        login(user, "WrongPass1!").andExpect(status().isUnauthorized());
        login(user, "RightPass1!").andExpect(status().isOk());       // 成功清零
        login(user, "WrongPass1!").andExpect(status().isUnauthorized());
        login(user, "WrongPass1!").andExpect(status().isUnauthorized());
        login(user, "WrongPass1!").andExpect(status().isUnauthorized());
        login(user, "RightPass1!").andExpect(status().isTooManyRequests()); // 重新累计到 3 次 → 锁
    }

    @Test
    void ipDimensionLocksAcrossDifferentAccounts() throws Exception {
        String ip = "10.99." + (Math.abs(sfx().hashCode()) % 250) + "." + (Math.abs(sfx().hashCode()) % 250);
        for (int i = 0; i < 3; i++) {
            mockMvc.perform(post("/api/v1/auth/token")
                            .header("X-Forwarded-For", ip)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content("{\"username\":\"rl_ip_" + sfx() + "_" + i + "\",\"password\":\""
                                    + b64("WrongPass1!") + "\"}"))
                    .andExpect(status().isUnauthorized());
        }
        // 该 IP 已锁：换一个全新账号也是 429
        mockMvc.perform(post("/api/v1/auth/token")
                        .header("X-Forwarded-For", ip)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"rl_ip_new_" + sfx() + "\",\"password\":\"" + b64("WrongPass1!") + "\"}"))
                .andExpect(status().isTooManyRequests())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-020"));
        // 换一个干净 IP（本用例第二 IP）不受影响——证明维度隔离
        xffIp = "10.97." + (Math.abs(sfx().hashCode()) % 250) + "." + (Math.abs(sfx().hashCode()) % 250);
        login("admin", "admin123").andExpect(status().isOk());
        Thread.sleep(1100); // 等 IP 锁过期（唯一 IP，仅为整洁）
    }
}

package com.unify.iam.app.oidc;

/**
 * 一次 OIDC 登录的临时会话态（发起 authorize 时创建，回调时一次性消费）。
 *
 * @param state         防 CSRF 随机值
 * @param nonce         防重放（放入 ID Token 校验）
 * @param codeChallenge PKCE S256 code_challenge
 * @param codeVerifier  PKCE code_verifier（换 token 时用）
 * @param configId      IdP 配置 ID（回调后复载配置）
 * @param tenantId      发起 SSO 的租户
 * @param createdAtMs   创建时间（epoch ms，TTL 清理用）
 */
public record OidcAuthSession(
        String state,
        String nonce,
        String codeChallenge,
        String codeVerifier,
        String configId,
        String tenantId,
        long createdAtMs) {
}
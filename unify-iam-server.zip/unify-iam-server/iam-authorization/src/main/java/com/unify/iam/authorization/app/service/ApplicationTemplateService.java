package com.unify.iam.authorization.app.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.unify.iam.authorization.app.model.AppCatalog;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.po.ApplicationRoleTemplatePO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.JsonUtils;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

/**
 * 应用角色模板加载与校验（docs/06 §2.3）：按租户启用的应用查预置模板。
 *
 * <p>新增应用 = 往 {@code iam_application}/{@code iam_application_role_template} 插数据，零改代码。
 * 加载时做三处校验，避免模板数据问题被静默吞掉：
 * <ol>
 *   <li>app_code 全部存在且 ACTIVE（未知应用 400）；</li>
 *   <li>启用应用集合内同 {@code role_code} 的模板权限集必须一致（gateway_role 租户内 role_code 唯一，
 *       跨应用冲突会导致后建角色被静默跳过，docs/06 附录 C）；</li>
 *   <li>模板引用的权限点必须存在于 gateway_permission（未知/停用 400，防静默丢权限）。</li>
 * </ol>
 */
@Service
public class ApplicationTemplateService {

    private final ApplicationRepository applicationRepository;
    private final ApplicationRoleTemplateRepository templateRepository;
    private final PermissionRepository permissionRepository;

    public ApplicationTemplateService(ApplicationRepository applicationRepository,
                                      ApplicationRoleTemplateRepository templateRepository,
                                      PermissionRepository permissionRepository) {
        this.applicationRepository = applicationRepository;
        this.templateRepository = templateRepository;
        this.permissionRepository = permissionRepository;
    }

    /**
     * 校验 app_codes 全部存在且 ACTIVE，返回这些应用的预置模板（按 priority 排序）。
     *
     * @throws AuthException 400 存在未知应用 / role_code 跨应用权限冲突 / 模板引用未知权限点
     */
    public List<AppRoleTemplate> loadForApps(List<String> appCodes) {
        List<String> codes = appCodes.stream().map(String::trim).filter(c -> !c.isEmpty()).distinct().toList();
        if (codes.isEmpty()) {
            throw AuthException.badRequest("app_codes 不能为空：至少选择一个应用");
        }
        Set<String> active = applicationRepository.findActiveByCodes(codes).stream()
                .map(a -> a.getAppCode().trim()).collect(Collectors.toSet());
        List<String> missing = codes.stream().filter(c -> !active.contains(c)).toList();
        if (!missing.isEmpty()) {
            throw AuthException.badRequest("未知或未启用应用：" + missing);
        }
        List<AppRoleTemplate> templates = templateRepository.listByAppCodes(codes).stream()
                .map(this::toModel).toList();
        validateRoleCodeConflict(templates);
        validatePermissionCodes(templates);
        return templates;
    }

    /**
     * 应用目录：全部 ACTIVE 应用 + 各自预置角色（docs/05 §7.3 建租户表单的应用多选 + 角色提示）。
     */
    public List<AppCatalog> listCatalog() {
        List<ApplicationPO> apps = applicationRepository.listActive();
        if (apps.isEmpty()) {
            return List.of();
        }
        List<AppRoleTemplate> templates = templateRepository.listByAppCodes(
                        apps.stream().map(ApplicationPO::getAppCode).toList()).stream()
                .map(this::toModel).toList();
        return apps.stream().map(a -> new AppCatalog(
                a.getAppCode().trim(), a.getAppName(), a.getDescription(),
                templates.stream().filter(t -> t.appCode().equals(a.getAppCode().trim())).toList()))
                .toList();
    }

    /** ① 同 role_code 跨应用冲突：权限集不一致 → 400（gateway_role 租户内 role_code 唯一，静默跳过后权限丢失）。 */
    private void validateRoleCodeConflict(List<AppRoleTemplate> templates) {
        Map<String, List<List<String>>> permsByRole = templates.stream().collect(Collectors.groupingBy(
                AppRoleTemplate::roleCode,
                Collectors.mapping(t -> t.permissionCodes().stream().sorted().toList(), Collectors.toList())));
        for (Map.Entry<String, List<List<String>>> e : permsByRole.entrySet()) {
            if (new HashSet<>(e.getValue()).size() > 1) {
                throw AuthException.badRequest("角色编码冲突：" + e.getKey() + " 在不同应用下权限集不一致");
            }
        }
    }

    /** ④ 模板引用的权限点必须存在且 ACTIVE（防配置错误静默丢权限）。 */
    private void validatePermissionCodes(List<AppRoleTemplate> templates) {
        List<String> allCodes = templates.stream()
                .flatMap(t -> t.permissionCodes().stream()).distinct().toList();
        if (allCodes.isEmpty()) {
            return;
        }
        Set<String> existing = permissionRepository.findIdByCodes(allCodes).keySet();
        List<String> unknown = allCodes.stream().filter(c -> !existing.contains(c)).toList();
        if (!unknown.isEmpty()) {
            throw AuthException.badRequest("应用角色模板包含未知或停用权限点：" + unknown);
        }
    }

    private AppRoleTemplate toModel(ApplicationRoleTemplatePO po) {
        return new AppRoleTemplate(
                po.getAppCode().trim(),
                po.getRoleCode().trim(),
                po.getRoleName(),
                po.getRoleDescription(),
                parseCodes(po.getPermissionCodesJson()),
                po.getIsOwner() != null && po.getIsOwner() == 1,
                po.getScopeType() == null || po.getScopeType().isBlank() ? "TENANT" : po.getScopeType().trim());
    }

    private List<String> parseCodes(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return JsonUtils.fromJson(json, new TypeReference<List<String>>() {
            });
        } catch (Exception e) {
            throw new IllegalStateException("应用角色模板 permission_codes_json 非法", e);
        }
    }
}

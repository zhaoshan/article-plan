> Closed on 2026-11-04 before implementation. The user explicitly narrowed the request to frontend-only work: no backend logic or seed changes. All backend proposals below are withdrawn historical planning, not an approved or implemented API contract. No implementation approval is requested.

# Isolate the three IAM console identities

## Goal
Make console page visibility and server authorization agree for exactly three identities. Protect direct API requests as well as frontend navigation.

## Confirmed requirements
- Platform administrator: current authenticated role codes contain exact `PlatformAdmin`; this identity takes precedence.
- B-side administrator: otherwise the current authenticated role codes contain exact `iMorph-Owner` or `iMorph-Admin`.
- Member: every other authenticated user. Do not include historical `TenantAdmin`, generic PLATFORM roles, template flags, tenant ownership alone, permission possession, or role-name substrings.
- Platform menu: My identity, Tenants, Roles, Audit. B-side menu: My identity, Members, Apps. Member menu: My identity only.
- My identity is available to every authenticated identity. Other page families deny unrelated identities with HTTP 403.
- Only B-side administrators see the console tenant selector. Recompute identity after switching. This is a console display rule; do not remove business application tenant selection or shared auth switching APIs.
- Platform identity does not imply Members/Apps administration, including when all permission codes are present.

## Constraints and scope
Work only in this repository's current main workspace on `feature/lee-1102`. Keep task/planning/research/session artifacts under this project's `.trellis/`. Do not commit, merge, push, switch/reset branches, or create/delete worktrees. Frontend implementation belongs to another project; provide a precise contract without accessing it.

Cover existing management APIs, helper data needed by those pages, role assignment safety, shared identity classification, and regression tests. Keep platform Tenants detail member/owner summaries and application selection as platform-only Tenants capabilities. A shared reference read is not a grant of Members/Apps page administration.

No new application CRUD product, cross-project work, schema redesign, fourth identity, generic template-based administrator definition, or removal of business application permissions.

## Acceptance criteria
1. Exact case-sensitive classification and PlatformAdmin priority are verified, including mixed roles, no roles, TenantAdmin, custom PLATFORM roles and iMorph-Member.
2. All authenticated identities can read `/api/v1/auth/me`; existing fields and JWT contract remain compatible.
3. Platform can read/write existing Tenants and Roles APIs and read Audit; B-side/member callers receive 403 even with those permission codes.
4. Only B-side identities can read/write existing Members, invitations and join-review operations and read Apps. Platform/member callers receive 403 even with all management permissions.
5. B-side operations remain restricted to the token tenant. Foreign tenant/membership IDs and PLATFORM member search are rejected before data/mutation access.
6. Member assignment cannot bind a PLATFORM role, a foreign-tenant role, deleted/disabled or unknown roles. Existing Owner uniqueness and last-administrator protection remain enforced.
7. Required role options and application references remain available through identity-specific helper APIs; B-side users cannot enter the Roles page by using these helpers.
8. All existing API behavior inconsistent with the new matrix is updated explicitly in tests and specs; unrelated authentication/SSO/business access behavior stays intact.
9. Report passed, failed and blocked verification accurately; leave all changes uncommitted.

## Approval status
Identity codes were confirmed by the user's follow-up. This is the final proposed server boundary, pending explicit approval of this planning summary before `task.py start` and product-code edits.

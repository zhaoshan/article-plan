package com.unify.iam.app.adapter.controller;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateRoleRequest;
import com.unify.iam.api.dto.admin.SetPermissionsRequest;
import com.unify.iam.api.dto.admin.UpdateRoleRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminRoleService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：角色 CRUD（iam:role:*）。 */
@RestController
@RequestMapping("/api/v1/admin/roles")
public class AdminRoleController {

    private final AdminRoleService adminRoleService;
    private final AuditService auditService;
    private final TenantRepository tenantRepository;
    private final com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository applicationRoleTemplateRepository;
    private final com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository tenantApplicationRepository;
    public AdminRoleController(AdminRoleService adminRoleService, AuditService auditService,
                                  com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository applicationRoleTemplateRepository,
                                  com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository tenantApplicationRepository,
                                  TenantRepository tenantRepository) {
        this.tenantRepository = tenantRepository;
        this.adminRoleService = adminRoleService;
        this.auditService = auditService;
        this.applicationRoleTemplateRepository = applicationRoleTemplateRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_ROLE_READ)
    public Map<String, Object> list(@RequestParam(name = "scope_type", required = false) String scopeType,
                                    @RequestParam(name = "scope_id", required = false) String scopeId,
                                    @RequestParam(name = "filter_scope_type", required = false) String filterScopeType,
                                    @RequestParam(name = "filter_scope_id", required = false) String filterScopeId,
                                    @RequestParam(name = "keyword", required = false) String keyword) {
        List<RolePO> scopedRoles = adminRoleService.listByScope(CurrentAuth.claims(), scopeType, scopeId,
                filterScopeType, filterScopeId, keyword);
        Map<String, String> tenantNames = tenantNamesForRoles(scopedRoles);
        Map<String, java.util.Set<String>> ownerCodes = ownerCodesByTenant(scopedRoles);
        Map<String, Long> permissionCounts = adminRoleService.permissionCountsForRoles(scopedRoles);
        List<Map<String, Object>> roles = scopedRoles.stream()
                .map(r -> toBrief(r, "TENANT".equals(r.getScopeType()) && r.getScopeId() != null
                        ? ownerCodes.getOrDefault(r.getScopeId(), java.util.Set.of()) : java.util.Set.of(),
                        permissionCounts.getOrDefault(r.getRoleId(), 0L),
                        "TENANT".equals(r.getScopeType()) ? tenantNames.get(r.getScopeId()) : null)).toList();
        return Map.of("roles", roles, "count", roles.size());
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_ROLE_WRITE)
    public Map<String, String> create(@Valid @RequestBody CreateRoleRequest request) {
        String roleId = adminRoleService.create(CurrentAuth.claims(), request);
        return Map.of("role_id", roleId);
    }

    /** Updates only the display metadata; role code and scope remain stable identifiers. */
    @PutMapping("/{roleId}")
    @RequirePermission(PermissionCodes.IAM_ROLE_WRITE)
    public Map<String, String> update(@PathVariable String roleId,
                                      @Valid @RequestBody UpdateRoleRequest request) {
        if (request.roleCode() != null) {
            throw AuthException.badRequest(ErrorCode.ROLE_CODE_IMMUTABLE);
        }
        adminRoleService.update(CurrentAuth.claims(), roleId, request);
        return Map.of("role_id", roleId);
    }

    @PutMapping("/{roleId}/permissions")
    @RequirePermission(PermissionCodes.IAM_ROLE_WRITE)
    public Map<String, String> setPermissions(@PathVariable String roleId,
                                              @Valid @RequestBody SetPermissionsRequest request) {
        adminRoleService.setPermissions(CurrentAuth.claims(), roleId, request);
        auditService.audit().event("ADMIN_SET_ROLE_PERMISSIONS").actor(CurrentAuth.claims().userId())
                .target("ROLE", roleId).result("SUCCESS").write(null);
        return Map.of("role_id", roleId);
    }

    @GetMapping("/{roleId}/permissions")
    @RequirePermission(PermissionCodes.IAM_ROLE_READ)
    public Map<String, Object> getPermissions(@PathVariable String roleId) {
        return Map.of("permission_ids", adminRoleService.getPermissionIds(roleId));
    }

    @DeleteMapping("/{roleId}")
    @RequirePermission(PermissionCodes.IAM_ROLE_WRITE)
    public Map<String, String> delete(@PathVariable String roleId) {
        adminRoleService.delete(CurrentAuth.claims(), roleId);
        return Map.of("role_id", roleId);
    }

    private Map<String, String> tenantNamesForRoles(List<RolePO> roles) {
        List<String> tenantIds = roles.stream().filter(r -> "TENANT".equals(r.getScopeType()))
                .map(RolePO::getScopeId).filter(id -> id != null && !id.isBlank()).distinct().toList();
        Map<String, String> names = new java.util.HashMap<>();
        if (!tenantIds.isEmpty()) {
            tenantRepository.findByIds(tenantIds).forEach(t -> names.put(t.getTenantId(), t.getTenantName()));
        }
        return names;
    }

    /** Resolve Owner flags using each returned role's tenant, including the cross-tenant platform view. */
    private Map<String, java.util.Set<String>> ownerCodesByTenant(List<RolePO> roles) {
        List<String> tenantIds = roles.stream().filter(r -> "TENANT".equals(r.getScopeType()))
                .map(RolePO::getScopeId).filter(id -> id != null && !id.isBlank()).distinct().toList();
        if (tenantIds.isEmpty()) {
            return Map.of();
        }
        var tenantApps = tenantApplicationRepository.listByTenants(tenantIds);
        var templates = applicationRoleTemplateRepository.listByAppCodes(tenantApps.stream()
                .map(a -> a.getAppCode()).distinct().toList());
        Map<String, java.util.Set<String>> ownersByApp = new java.util.HashMap<>();
        for (var template : templates) {
            if (Integer.valueOf(1).equals(template.getIsOwner())) {
                ownersByApp.computeIfAbsent(template.getAppCode().trim(), k -> new java.util.HashSet<>())
                        .add(template.getRoleCode().trim());
            }
        }
        Map<String, java.util.Set<String>> result = new java.util.HashMap<>();
        for (var app : tenantApps) {
            result.computeIfAbsent(app.getTenantId(), k -> new java.util.HashSet<>())
                    .addAll(ownersByApp.getOrDefault(app.getAppCode(), java.util.Set.of()));
        }
        return result;
    }

    private Map<String, Object> toBrief(RolePO r, java.util.Set<String> ownerCodes, long permissionCounts, String tenantName) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("role_id", r.getRoleId());
        m.put("permissionCounts", permissionCounts);
        m.put("role_code", r.getRoleCode());
        m.put("role_name", r.getRoleName());
        m.put("role_description", r.getRoleDescription());
        m.put("scope_type", r.getScopeType());
        m.put("scope_id", r.getScopeId());
        m.put("tenant_name", tenantName);
        m.put("role_status", r.getRoleStatus());
        m.put("is_builtin", r.getIsBuiltin() != null && r.getIsBuiltin() == 1);
        m.put("is_owner", r.getRoleCode() != null && ownerCodes.contains(r.getRoleCode().trim()));
        return m;
    }
}

package com.unify.iam.authorization;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.unify.iam.authorization.app.service.RoleSyncService;
import com.unify.iam.authorization.infra.persistence.mapper.MembershipRoleMapper;
import com.unify.iam.authorization.infra.persistence.po.MembershipRolePO;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class RoleSyncServiceTest {

    @Mock
    private MembershipRoleMapper membershipRoleMapper;

    private MembershipRolePO mr(String id, String roleId, String grantSource) {
        MembershipRolePO po = new MembershipRolePO();
        po.setId(101L);
        po.setMembershipRoleId(id);
        po.setMembershipId("ms-1");
        po.setRoleId(roleId);
        po.setGrantSource(grantSource);
        return po;
    }

    @SuppressWarnings("unchecked")
    @Test
    void insertsDesiredAndPreservesDirect() {
        // 已有：roleA(IDP_SYNC)、roleB(DIRECT)；期望命中 roleA+roleC
        when(membershipRoleMapper.selectList(any(Wrapper.class)))
                .thenReturn(List.of(mr("mr-a", "rA", "IDP_SYNC"), mr("mr-b", "rB", "DIRECT")));
        when(membershipRoleMapper.insert(any(MembershipRolePO.class))).thenReturn(1);

        RoleSyncService service = new RoleSyncService(membershipRoleMapper);
        service.syncIdpRoles("ms-1", List.of("rA", "rC"));

        // rC 无墓碑 → revive 返回 0 → 补授（grant_source=IDP_SYNC）
        verify(membershipRoleMapper).revive("ms-1", "rC", "IDP_SYNC");
        ArgumentCaptor<MembershipRolePO> inserted = ArgumentCaptor.forClass(MembershipRolePO.class);
        verify(membershipRoleMapper).insert(inserted.capture());
        assertThat(inserted.getValue().getRoleId()).isEqualTo("rC");
        assertThat(inserted.getValue().getGrantSource()).isEqualTo("IDP_SYNC");
        // 现有 roleA 命中、roleB DIRECT 均不回收
        verify(membershipRoleMapper, never()).deleteById(any());
        verify(membershipRoleMapper, never()).updateById(any(MembershipRolePO.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void removesStaleIdpSyncRoles() {
        // 已有 roleOld(IDP_SYNC)；本次命中 roleNew
        when(membershipRoleMapper.selectList(any(Wrapper.class)))
                .thenReturn(List.of(mr("mr-old", "rOld", "IDP_SYNC")));
        when(membershipRoleMapper.insert(any(MembershipRolePO.class))).thenReturn(1);

        RoleSyncService service = new RoleSyncService(membershipRoleMapper);
        service.syncIdpRoles("ms-1", List.of("rNew"));

        // 回收 rOld → deleteById（@TableLogic 转 UPDATE delete_flag=1）；updateById 不写 delete_flag，必须弃用
        verify(membershipRoleMapper).deleteById(101L);
        verify(membershipRoleMapper, never()).updateById(any(MembershipRolePO.class));
        // 补授 rNew（无墓碑 → revive 返回 0 → insert）
        verify(membershipRoleMapper).revive("ms-1", "rNew", "IDP_SYNC");
        verify(membershipRoleMapper, times(1)).insert(any(MembershipRolePO.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void noDesiredRolesStillRemovesStale() {
        when(membershipRoleMapper.selectList(any(Wrapper.class)))
                .thenReturn(List.of(mr("mr-old", "rOld", "IDP_SYNC")));

        RoleSyncService service = new RoleSyncService(membershipRoleMapper);
        service.syncIdpRoles("ms-1", List.of());

        verify(membershipRoleMapper, never()).insert(any(MembershipRolePO.class));
        verify(membershipRoleMapper, never()).revive(any(), any(), any());
        verify(membershipRoleMapper, times(1)).deleteById(101L);
        verify(membershipRoleMapper, never()).updateById(any(MembershipRolePO.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    void directRoleNeverRemoved() {
        when(membershipRoleMapper.selectList(any(Wrapper.class)))
                .thenReturn(List.of(mr("mr-b", "rB", "DIRECT")));

        RoleSyncService service = new RoleSyncService(membershipRoleMapper);
        service.syncIdpRoles("ms-1", List.of());

        verify(membershipRoleMapper, never()).insert(any(MembershipRolePO.class));
        verify(membershipRoleMapper, never()).revive(any(), any(), any());
        verify(membershipRoleMapper, never()).deleteById(any());
        verify(membershipRoleMapper, never()).updateById(any(MembershipRolePO.class));
    }
}
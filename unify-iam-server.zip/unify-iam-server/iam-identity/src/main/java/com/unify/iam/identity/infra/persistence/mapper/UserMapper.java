package com.unify.iam.identity.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_user Mapper。 */
@Mapper
public interface UserMapper extends BaseMapper<UserPO> {
}

package com.unify.iam.authorization.app.model;

import java.util.List;

/**
 * RBAC 解析结果：某成员在租户下拥有的角色与权限点（有序，去重）。
 *
 * @param roles 角色编码（字典序）
 * @param permissions 权限点编码（字典序，跨角色去重）
 */
public record RbacResult(List<String> roles, List<String> permissions) {

    public static RbacResult of(List<String> roles, List<String> permissions) {
        return new RbacResult(List.copyOf(roles), List.copyOf(permissions));
    }
}

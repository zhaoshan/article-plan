package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.admin.CreateInvitationRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.app.service.JitLocalAccountService.ProvisionResult;
import com.unify.iam.app.app.service.QuotaService;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.infra.persistence.po.InvitationPO;
import com.unify.iam.app.infra.persistence.repository.InvitationRepository;
import com.unify.iam.app.mail.InvitationMailService;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.SecureToken;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 邀请（docs/04 §3.5 + G2 docs/08 §2.5）：管理员发邀请 → 受邀用户接受后建成员 + 默认角色。
 * 管理端发邀请限本租户（docs/06 §3.3）。
 *
 * <p>G2/G2 增强：按邮箱分支 JIT 建号 + 初始密码（首登强制改密）；发邀请邮件（§3 通道）；
 * 邀请盖隐含应用参数 {@code app_code}（默认 {@code iam.mail.invitation-default-app}）；
 * {@code role_id} 可选——**不传默认取当前租户 is_owner 模板角色**（产品口径）；
 * accept 返回 {@code redirect_url}（解析序：invitation.app_code → iam_application.homepage_url →
 * yml {@code iam.app-homepages.<code>} → 邀请链接基址兜底）。
 */
@Service
public class InvitationService {
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(InvitationService.class);

    /** 邀请有效期（天）——产品口径待最终确认，现状 7 天（差距文档 §5 建议天级）。 */
    private static final int TTL_DAYS = 7;
    private static final String OWNER_TRANSFER_PURPOSE = "OWNER_TRANSFER";
    private static final String TENANT_OWNER_SETUP_PURPOSE = "TENANT_OWNER_SETUP";

    private final InvitationRepository invitationRepository;
    private final TenantRepository tenantRepository;
    private final UserRepository userRepository;
    private final MembershipRepository membershipRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final RoleRepository roleRepository;
    private final TenantScopeGuard tenantScopeGuard;
    private final TenantQuotaService tenantQuotaService;
    private final com.unify.iam.app.app.service.admin.TenantOwnershipService tenantOwnershipService;
    private final com.unify.iam.app.mail.InvitationDeliveryGuard invitationDeliveryGuard;
    private final JitLocalAccountService jitLocalAccountService;
    private final PersonalTenantService personalTenantService;
    private final TenantAppProvisionService tenantAppProvisionService;
    private final InvitationMailService invitationMailService;
    private final IamProperties props;
    private final QuotaService quotaService;
    private final ApplicationRepository applicationRepository;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final ApplicationRoleTemplateRepository applicationRoleTemplateRepository;

    public InvitationService(InvitationRepository invitationRepository,
                             TenantRepository tenantRepository,
                             UserRepository userRepository,
                             MembershipRepository membershipRepository,
                             MembershipRoleRepository membershipRoleRepository,
                             RoleRepository roleRepository,
                             TenantScopeGuard tenantScopeGuard,
                             JitLocalAccountService jitLocalAccountService,
                             PersonalTenantService personalTenantService,
                             TenantAppProvisionService tenantAppProvisionService,
                             InvitationMailService invitationMailService,
                             IamProperties props,
                             QuotaService quotaService,
                             ApplicationRepository applicationRepository,
                             TenantApplicationRepository tenantApplicationRepository,
                             ApplicationRoleTemplateRepository applicationRoleTemplateRepository,
                             TenantQuotaService tenantQuotaService,
                             com.unify.iam.app.app.service.admin.TenantOwnershipService tenantOwnershipService,
                             com.unify.iam.app.mail.InvitationDeliveryGuard invitationDeliveryGuard) {
        this.tenantQuotaService = tenantQuotaService;
        this.tenantOwnershipService = tenantOwnershipService;
        this.invitationDeliveryGuard = invitationDeliveryGuard;
        this.invitationRepository = invitationRepository;
        this.tenantRepository = tenantRepository;
        this.userRepository = userRepository;
        this.membershipRepository = membershipRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.roleRepository = roleRepository;
        this.tenantScopeGuard = tenantScopeGuard;
        this.jitLocalAccountService = jitLocalAccountService;
        this.personalTenantService = personalTenantService;
        this.tenantAppProvisionService = tenantAppProvisionService;
        this.invitationMailService = invitationMailService;
        this.props = props;
        this.quotaService = quotaService;
        this.applicationRepository = applicationRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.applicationRoleTemplateRepository = applicationRoleTemplateRepository;
    }

    /** 邀请签发结果（Owner 邮箱开通流程复用）；roleId = 首生效角色（含默认值）；roleIds = 全量角色集。 */
    public record Issued(String token, LocalDateTime expiresAt, String roleId, java.util.List<String> roleIds,
                         String appCode) {
    }

    /**
     * 管理员发邀请（管理面）：租户级作用域校验 + 开通分支 + 发信。dev 返回令牌；生产走邮件。
     *
     * <p>语义：**成员即建**（2026-11-03 起新老账号一致——老账号成员关系不存在也预建，默认租户语义
     * 见 createInvitedMembership）；角色延期到 accept 绑定（accept 幂等：标记 ACCEPTED + redirect_url）。
     */
    @Transactional
    public Map<String, String> create(JwtClaims claims, CreateInvitationRequest request) {
        // 严格投递模式（delivery-enabled=true）：四道闸前置，不过 → 503 且零落库（docs/08 §7）
        invitationDeliveryGuard.requireDeliverable();
        tenantScopeGuard.assertTenantScope(claims, request.tenantId());
        String tid = request.tenantId().trim();
        // 2026-11-04 并发控制（P0 行锁）：租户行锁把同租户邀请串行化——并发/双击请求排队后
        // 由下方防重检查返回 400（与唯一索引同一错误码），顺带堵配额席位检查的竞态。
        tenantRepository.findByIdForUpdate(tid).orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        String email = request.email().trim().toLowerCase();
        // 过期翻转先行：保证 V20 pending_key 唯一索引「PENDING ⇒ 未过期」前提（生成列无 NOW()）
        invitationRepository.markExpiredInvitations(tid, email);
        // 2026-11-03/04 防重（先行于配额检查：重复邀请语义优先于席位不足，且纯查询更便宜）：
        // 同邮箱对同租户未接受邀请唯一；已是 ACTIVE 成员的邮箱直接 400。
        if (invitationRepository.findPendingByTenantEmailAndPurpose(tid, email, "MEMBER").isPresent()) {
            throw AuthException.badRequest(ErrorCode.INVITE_PENDING_DUPLICATE);
        }
        var existingUser = userRepository.findByPrimaryEmail(email);
        if (existingUser.isPresent()
                && membershipRepository.findByTenantAndUser(tid, existingUser.get().getUserId().trim()).isPresent()) {
            var msId = membershipRepository.findByTenantAndUser(tid, existingUser.get().getUserId().trim())
                    .get().getMembershipId().trim();
            boolean hasRoles = !membershipRoleRepository.listByMembership(msId).isEmpty();
            // 已接受邀请（无论是否有角色——parlant 类退化租户 accept 后可零角色）= 真成员，拦截；
            // 零角色且无任何 ACCEPTED 记录 = 过期邀请的占位成员，放行重邀（accept 会对既有成员只绑角色）
            if (hasRoles || invitationRepository.existsAcceptedByTenantAndEmail(tid, email)) {
                throw AuthException.badRequest(ErrorCode.EMAIL_ALREADY_MEMBER);
            }
        }
        quotaService.assertMemberSeat(tid);
        Issued issued = issueForTenant(tid, email,
                request.roleId() == null ? null : request.roleId().trim(), request.roleIds());
        ProvisionResult provisioned = jitLocalAccountService.provisionIfAbsent(email);
        // 2026-11-03：成员即建不再区分新老账号——老账号成员关系不存在也预建（角色仍 accept 才绑定）；
        // 默认租户语义：新 JIT 账号受邀租户置默认（否则首登无默认成员 401），老账号保留原默认
        // （被邀请 ≠ 强制迁移，accept 后用户可自行切换）。
        boolean makeDefault = provisioned.created()
                || membershipRepository.findDefaultActive(provisioned.userId()).isEmpty();
        createInvitedMembership(request.tenantId().trim(), provisioned.userId(), makeDefault);
        // 2026-11-05 点状日志：邀请已签发（email 脱敏；角色/席位语义由 DB 审计承载）
        log.info("invitation issued | email={} | tenant={} | newAccount={} | role={}",
                com.unify.iam.common.util.LogMasks.maskEmail(email), tid, provisioned.created(), issued.roleId());
        String tenantName = tenantRepository.findById(request.tenantId().trim())
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND)).getTenantName();
        // 模板按生效角色分派：is_owner 角色（含不传走默认）→ Owner 模板；其余 → Member/Admin 模板
        try {
            // 邮件分派：任一生效角色为 is_owner 模板角色 → Owner 模板；角色名渲染全量（逗号连接）
            boolean ownerTemplate = issued.roleIds().stream()
                    .anyMatch(rid -> isOwnerRole(request.tenantId().trim(), rid));
            String roleNames = issued.roleIds().stream()
                    .map(rid -> roleName(rid)).filter(n -> n != null && !n.isBlank())
                    .reduce((a, b) -> a + ", " + b).orElse(null);
            if (ownerTemplate) {
                invitationMailService.sendOwnerInvitation(email, tenantName,
                        provisioned.initialPassword(), issued.expiresAt(), issued.token(), issued.appCode());
            } else {
                invitationMailService.sendMemberInvitation(email, tenantName, roleNames,
                        provisioned.initialPassword(), issued.expiresAt(), issued.token(), issued.appCode());
            }
        } catch (RuntimeException ex) {
            // 严格模式语义：投递失败 = 本次邀请不可履约 → 503 + 整事务回滚（不留死邀请）
            throw AuthException.serviceUnavailable(ErrorCode.MEMBER_INVITE_DELIVERY_FAILED);
        }
        return Map.of("token", issued.token());
    }

    /** 生效角色是否 is_owner 模板角色（角色 code 命中租户启用应用的 is_owner 模板，G3 方式 B 同口径）。 */
    private boolean isOwnerRole(String tenantId, String roleId) {
        return roleRepository.findById(roleId.trim())
                .map(r -> r.getRoleCode() == null ? false
                        : applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                                tenantApplicationRepository.findAppCodesByTenant(tenantId))
                        .contains(r.getRoleCode().trim()))
                .orElse(false);
    }

    /**
     * 受邀租户成员（join_source=INVITE）——**角色不在此绑定**：须点击邀请邮件（accept）后才获得角色；
     * 角色以邀请上记录的 defaultRoleId 在 accept 时绑定。新老账号统一预建（2026-11-03）；
     * makeDefault=true 时受邀租户置默认租户并清旧默认（仅新 JIT 账号需要，否则首登无默认成员 401）。
     */
    private void createInvitedMembership(String tenantId, String userId, boolean makeDefault) {
        if (membershipRepository.findByTenantAndUser(tenantId, userId).isPresent()) {
            return;
        }
        if (makeDefault) {
            membershipRepository.clearDefault(userId); // 防御：保证恰一个默认
        }
        MembershipPO m = new MembershipPO();
        m.setMembershipId(IdGenerator.newBizId());
        m.setTenantId(tenantId);
        m.setUserId(userId);
        m.setMembershipStatus("ACTIVE");
        m.setJoinSource("INVITE");
        m.setIsDefault(makeDefault ? 1 : 0);
        if (!membershipRepository.create(m)) {
            // (tenant_id,user_id) 唯一键含逻辑删行 → insert 撞键：复活并归一化（重邀被删成员场景）
            membershipRepository.restore(tenantId, userId, makeDefault);
        }
    }

    /**
     * 签发邀请（G2 供 Owner 邮箱开通复用；调用方已做权限/作用域校验）。
     * 校验租户与角色归属，生成一次性令牌（哈希落库，7 天）。
     * {@code roleId} 为空 → 默认取当前租户 is_owner 模板角色；{@code appCode} 缺省默认应用。
     */
    @Transactional
    public Issued issueForTenant(String tenantId, String email, String roleId) {
        return issueForTenant(tenantId, email, roleId, null);
    }

    /**
     * 签发邀请（多角色版，2026-11-05 适配 iam-test 前端 {@code role_ids}）：{@code roleIds} 非空时
     * 优先于 {@code roleId}——全量角色逐一校验归属/单 Owner，{@code role_ids_json} 落库全量，
     * {@code default_role_id} 记首角色（存量单角色语义与邮件分派锚点）；accept 绑全量。
     */
    @Transactional
    public Issued issueForTenant(String tenantId, String email, String roleId, java.util.List<String> roleIds) {
        String tid = tenantId.trim();
        tenantRepository.findById(tid).orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        // 生效角色集：role_ids 优先（去重保序），否则单 role_id，否则默认解析
        java.util.List<String> effectiveRoleIds = normalizeRoleIds(roleIds);
        if (effectiveRoleIds.isEmpty() && roleId != null && !roleId.isBlank()) {
            effectiveRoleIds = java.util.List.of(roleId.trim());
        }
        String effectiveRoleId = effectiveRoleIds.isEmpty()
                ? defaultRoleIdForInvite(tid, email.trim().toLowerCase())
                : effectiveRoleIds.get(0);
        // 默认解析（补位 Owner/回落 Admin）的结果并入全量集——邮件分派/role_ids_json 与单角色语义一致
        if (effectiveRoleIds.isEmpty() && effectiveRoleId != null) {
            effectiveRoleIds = java.util.List.of(effectiveRoleId.trim());
        }
        if (!effectiveRoleIds.isEmpty()) {
            String excludeMs = userRepository.findByPrimaryEmail(email.trim().toLowerCase())
                    .flatMap(u -> membershipRepository.findByTenantAndUser(tid, u.getUserId().trim()))
                    .map(m -> m.getMembershipId().trim())
                    .orElse(null);
            for (String rid : effectiveRoleIds) {
                assertRoleInTenant(tid, rid);
                // G3 单 Owner：已有其他 ACTIVE 持有者则 400——排除受邀人自己的成员关系
                // （JIT 语义下受邀人可能已被授予该角色，如 owner_email 建租户流程）
                assertOwnerUnique(tid, rid, excludeMs, email);
            }
        }
        String plain = SecureToken.random();
        InvitationPO po = new InvitationPO();
        po.setInvitationId(IdGenerator.newBizId());
        po.setTenantId(tid);
        po.setEmail(email.trim().toLowerCase());
        po.setInviteType("EMAIL");
        po.setInvitationPurpose("MEMBER");
        po.setInvitationStatus("PENDING");
        po.setInviteTokenHash(SecureToken.hash(plain));
        po.setDefaultRoleId(effectiveRoleId);
        po.setAppCode(resolveInvitationAppCode(tid));
        po.setExpiresAt(LocalDateTime.now().plusDays(TTL_DAYS));
        if (!effectiveRoleIds.isEmpty()) {
            po.setRoleIdsJson(writeRoleIdsJson(effectiveRoleIds));
        }
        try {
            invitationRepository.insert(po);
        } catch (org.springframework.dao.DuplicateKeyException ex) {
            // V20 uk_invitation_pending 撞键（并发漏网）→ 与防重检查同一错误码
            throw AuthException.badRequest(ErrorCode.INVITE_PENDING_DUPLICATE);
        }
        return new Issued(plain, po.getExpiresAt(), effectiveRoleId, effectiveRoleIds, po.getAppCode());
    }

    /**
     * 邀请 app 解析（2026-11-11 修复「链接恒 imorph」）：租户启用应用的<b>首位（主应用）</b>——
     * iam_tenant_application 按登记序（id 升序）取第一个，即建租户时 app_codes 第一位；
     * 无记录（仅存量无应用登记租户/手工数据）回落 iam.mail.invitation-default-app。
     *
     * <p>产品语义：app_codes 第一位 = 主应用——邀请落点、登录目标分流按主应用解析，
     * 管理端建租户 UI 应把第一位标为「主应用」。多应用租户若需按次邀请指定不同应用，
     * 属后续产品迭代（邀请级 app_code 入参 / 租户 primary_app_code 列），届时在此扩展。
     */
    private String resolveInvitationAppCode(String tenantId) {
        return tenantApplicationRepository.findAppCodesByTenant(tenantId).stream()
                .filter(code -> code != null && !code.isBlank())
                .findFirst()
                .map(String::trim)
                .orElse(props.getMail().getInvitationDefaultApp());
    }

    /** role_ids 归一：去空/去重保序；null → 空列表。 */
    private java.util.List<String> normalizeRoleIds(java.util.List<String> roleIds) {
        if (roleIds == null) {
            return java.util.List.of();
        }
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        for (String rid : roleIds) {
            if (rid != null && !rid.isBlank()) {
                out.add(rid.trim());
            }
        }
        return java.util.List.copyOf(out);
    }

    private String writeRoleIdsJson(java.util.List<String> roleIds) {
        try {
            return com.unify.iam.common.util.JsonUtils.toJson(roleIds);
        } catch (RuntimeException e) {
            throw new IllegalStateException("serialize role_ids_json failed", e);
        }
    }

    private java.util.List<String> readRoleIdsJson(String json) {
        if (json == null || json.isBlank()) {
            return java.util.List.of();
        }
        try {
            return com.unify.iam.common.util.JsonUtils.fromJson(json, java.util.List.class);
        } catch (RuntimeException e) {
            return java.util.List.of(); // 脏数据防御：回落单角色
        }
    }

    /**
     * G3 默认角色（role_id 不传）：无 ACTIVE Owner → 补位 is_owner；已有 Owner → 回落同应用 is_admin
     * （imorph 即 iMorph-Admin）；admin 与 owner 同角色/缺失 → 试 'Member'；再无 → null（无默认角色）。
     */
    private String defaultRoleIdForInvite(String tenantId, String email) {
        String ownerRoleId = findRoleByTemplateFlag(tenantId, true);
        if (ownerRoleId == null) {
            return null; // 无 owner 模板 → 无默认
        }
        // 补位 Owner：无 ACTIVE 持有者且无待接受邀请（pending 即占用；排除本邮箱自己的邀请）
        if (!membershipRoleRepository.roleHasActiveHolder(ownerRoleId)
                && invitationRepository.countPendingByRole(ownerRoleId, email) == 0) {
            return ownerRoleId;
        }
        String adminRoleId = findRoleByTemplateFlag(tenantId, false);
        if (adminRoleId != null && !adminRoleId.equals(ownerRoleId)) {
            return adminRoleId;
        }
        return roleRepository.listByScope("TENANT", tenantId).stream()
                .filter(r -> "Member".equalsIgnoreCase(r.getRoleCode() == null ? "" : r.getRoleCode().trim()))
                .map(r -> r.getRoleId().trim()).findFirst().orElse(null);
    }

    /** is_owner / is_admin 模板角色 id（tenant 作用域已灌入的）。 */
    private String findRoleByTemplateFlag(String tenantId, boolean owner) {
        Set<String> codes = new HashSet<>(owner
                ? applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                        tenantApplicationRepository.findAppCodesByTenant(tenantId))
                : applicationRoleTemplateRepository.listIsAdminRoleCodes(
                        tenantApplicationRepository.findAppCodesByTenant(tenantId)));
        if (codes.isEmpty()) {
            return null;
        }
        return roleRepository.listByScope("TENANT", tenantId).stream()
                .filter(r -> r.getRoleCode() != null && codes.contains(r.getRoleCode().trim()))
                .map(r -> r.getRoleId().trim())
                .findFirst()
                .orElse(null);
    }

    /**
     * G3 单 Owner 校验：is_owner 角色已有其他 ACTIVE 持有者或待接受（PENDING）邀请（角色延期到 accept
     * 绑定后，pending 即视为已占用）→ 400。excludeEmail 排除受邀人自己的邀请。
     */
    private void assertOwnerUnique(String tenantId, String roleId, String excludeMembershipId, String excludeEmail) {
        Set<String> ownerCodes = new HashSet<>(applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                tenantApplicationRepository.findAppCodesByTenant(tenantId)));
        boolean isOwnerRole = roleRepository.findById(roleId.trim())
                .map(r -> r.getRoleCode() != null && ownerCodes.contains(r.getRoleCode().trim()))
                .orElse(false);
        if (!isOwnerRole) {
            return;
        }
        boolean held = excludeMembershipId == null
                ? membershipRoleRepository.roleHasActiveHolder(roleId)
                : membershipRoleRepository.roleHasAnotherActiveHolder(roleId, excludeMembershipId);
        boolean pending = invitationRepository.countPendingByRole(roleId, excludeEmail) > 0;
        if (held || pending) {
            throw AuthException.badRequest(ErrorCode.OWNER_ROLE_PENDING);
        }
    }

    /** 默认角色必须属于目标租户（TENANT 作用域 + 该租户），防存无效/他租户角色 id。 */
    private void assertRoleInTenant(String tenantId, String roleId) {
        RolePO role = roleRepository.findById(roleId)
                .orElseThrow(() -> AuthException.badRequest(ErrorCode.DEFAULT_ROLE_NOT_FOUND));
        if (!"TENANT".equals(role.getScopeType()) || !tenantId.equals(role.getScopeId())) {
            throw AuthException.badRequest(ErrorCode.DEFAULT_ROLE_TENANT_MISMATCH);
        }
    }

    /** 邀请预设角色名（邮件 {{role}} 展示；空 → Member）。 */
    private String roleName(String roleId) {
        if (roleId == null || roleId.isBlank()) {
            return "Member";
        }
        return roleRepository.findById(roleId.trim())
                .map(r -> r.getRoleName() == null || r.getRoleName().isBlank() ? r.getRoleCode() : r.getRoleName())
                .orElse("Member");
    }

    /**
     * 受邀用户（已登录、邮箱匹配）接受邀请 → 无成员则建成员 + 默认角色（幂等：已有成员不动）。
     *
     * @return accept 后跳转地址（G2 增强 redirect_url；解析序见类注释）
     */
    @Transactional
    public String accept(String token, String userId) {
        InvitationPO invitation = invitationRepository.findByHash(SecureToken.hash(token))
                .orElseThrow(() -> AuthException.unauthorized(ErrorCode.INVITE_INVALID));
        // 幂等重放：同一人对 ACCEPTED 邀请重复 accept（StrictMode 双发/双击/刷新）→ 原样返回 redirect_url
        if ("ACCEPTED".equals(invitation.getInvitationStatus())
                && userId.trim().equals(invitation.getAcceptedByUserId() == null ? ""
                        : invitation.getAcceptedByUserId().trim())) {
            // 存量邀请 app_code 可能为 NULL（旧 persistOwnerInvitation 不写该列）→ 按租户启用应用兜底
            return resolveHomepage(effectiveInvitationAppCode(invitation));
        }
        if (!"PENDING".equals(invitation.getInvitationStatus())) {
            throw AuthException.unauthorized(ErrorCode.INVITE_INVALID);
        }
        UserPO user = userRepository.findByUserId(userId)
                .orElseThrow(() -> AuthException.unauthorized(ErrorCode.USER_NOT_FOUND));
        if (invitation.getEmail() == null
                || !invitation.getEmail().equalsIgnoreCase(user.getPrimaryEmail() == null ? "" : user.getPrimaryEmail())) {
            throw AuthException.forbidden(ErrorCode.INVITE_EMAIL_MISMATCH);
        }
        String tenantId = invitation.getTenantId();
        String membershipId = membershipRepository.findByTenantAndUser(tenantId, userId)
                .map(m -> m.getMembershipId().trim())
                .orElse(null);
        if (membershipId == null) {
            MembershipPO m = new MembershipPO();
            m.setMembershipId(IdGenerator.newBizId());
            m.setTenantId(tenantId);
            m.setUserId(userId);
            m.setMembershipStatus("ACTIVE");
            m.setJoinSource("INVITE");
            m.setIsDefault(0);
            membershipRepository.create(m);
            membershipId = m.getMembershipId();
        }
        // 角色绑定统一在 accept 时（收紧语义：新 JIT 账号须点邮件才获得角色）；已有绑定则跳过。
        // 例外：OWNER_TRANSFER 邀请的绑定并入 acceptOwnerTransfer——旧 Owner 同事务降级，泛化单 Owner 校验会误拒。
        boolean ownerTransfer = OWNER_TRANSFER_PURPOSE.equals(invitation.getInvitationPurpose());
        // 2026-11-05 多角色邀请：role_ids_json 全量绑定（空则回落 default_role_id 存量单角色）
        java.util.List<String> acceptRoleIds = ownerTransfer ? java.util.List.of()
                : readRoleIdsJson(invitation.getRoleIdsJson());
        if (acceptRoleIds.isEmpty() && invitation.getDefaultRoleId() != null && !ownerTransfer) {
            acceptRoleIds = java.util.List.of(invitation.getDefaultRoleId().trim());
        }
        if (!acceptRoleIds.isEmpty() && !ownerTransfer) {
            List<String> current = new java.util.ArrayList<>(membershipRoleRepository
                    .listByMembership(membershipId).stream().map(mr -> mr.getRoleId().trim()).toList());
            boolean changed = false;
            for (String roleId : acceptRoleIds) {
                assertOwnerUnique(tenantId, roleId, membershipId, invitation.getEmail());
                if (!current.contains(roleId)) {
                    current.add(roleId);
                    changed = true;
                }
            }
            if (changed) {
                membershipRoleRepository.replaceDirectRoles(membershipId, current);
            }
        }
        // 2026-11-05 点状日志：邀请已接受（延期绑定语义的角色在此刻生效）
        log.info("invitation accepted | email={} | tenant={} | role={}",
                com.unify.iam.common.util.LogMasks.maskEmail(invitation.getEmail()),
                tenantId, invitation.getDefaultRoleId());
        invitation.setInvitationStatus("ACCEPTED");
        invitation.setAcceptedByUserId(userId);
        invitation.setAcceptedAt(LocalDateTime.now());
        invitationRepository.update(invitation);
        if (OWNER_TRANSFER_PURPOSE.equals(invitation.getInvitationPurpose())) {
            tenantOwnershipService.acceptOwnerTransfer(invitation, userId);
        } else if (TENANT_OWNER_SETUP_PURPOSE.equals(invitation.getInvitationPurpose())) {
            tenantOwnershipService.acceptInitialOwnerSetup(invitation, userId);
        }
        return resolveHomepage(effectiveInvitationAppCode(invitation));
    }

    /** 存量兜底（2026-11-11）：旧流程产生的邀请 app_code 为 NULL——按租户启用应用解析（同新邀请口径）。 */
    private String effectiveInvitationAppCode(InvitationPO invitation) {
        String code = invitation.getAppCode();
        return (code == null || code.isBlank()) ? resolveInvitationAppCode(invitation.getTenantId()) : code.trim();
    }

    /** redirect_url 解析：invitation.app_code → iam_application.homepage_url → yml iam.app-homepages → 链接基址兜底。 */
    private String resolveHomepage(String appCode) {
        if (appCode != null && !appCode.isBlank()) {
            String code = appCode.trim();
            String db = applicationRepository.findActiveByCodes(List.of(code)).stream()
                    .findFirst()
                    .map(ApplicationPO::getHomepageUrl)
                    .filter(h -> h != null && !h.isBlank())
                    .map(String::trim)
                    .orElse(null);
            // 各层统一归一去尾斜杠（DB/yml 配置都可能带，前端拼接 ?token 时会出 //）
            if (db != null) {
                String url = db.replaceAll("/+$", "");
                log.info("invitation redirect resolved | appCode={} | tier=db_homepage_url | url={}", code, url);
                return url;
            }
            String yml = props.getAppHomepages().get(code);
            if (yml != null && !yml.isBlank()) {
                String url = yml.trim().replaceAll("/+$", "");
                log.info("invitation redirect resolved | appCode={} | tier=yml_app_homepages | url={}", code, url);
                return url;
            }
        }
        // 归一去尾斜杠：与 DB homepage_url / yml 层格式一致（DB 习惯不带尾斜杠，基址兜底可能带）
        String fallback = props.getMail().getInvitationLinkBaseUrl() == null
                ? null : props.getMail().getInvitationLinkBaseUrl().replaceAll("/+$", "");
        log.info("invitation redirect resolved | appCode={} | tier=invitation_link_base | url={}", appCode, fallback);
        return fallback;
    }

    /**
     * 创建待投递的 Owner 转移邀请。调用方必须先验证真实邮件投递配置，并在同一事务中发送，
     * 以免持久化一个用户永远拿不到 token 的伪邀请。
     */
    @Transactional
    public OwnerInvitation createOwnerTransfer(JwtClaims claims, String tenantId, String email) {
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        String normalizedTenantId = tenantId.trim();
        String normalizedEmail = email == null ? "" : email.trim().toLowerCase();
        if (normalizedEmail.isBlank()) {
            throw AuthException.badRequest(ErrorCode.EMAIL_REQUIRED);
        }
        var tenant = tenantRepository.findById(normalizedTenantId)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        if (tenant.getOwnerUserId() != null && userRepository.findByUserId(tenant.getOwnerUserId())
                .map(user -> normalizedEmail.equalsIgnoreCase(user.getPrimaryEmail())).orElse(false)) {
            throw AuthException.badRequest(ErrorCode.EMAIL_ALREADY_OWNER);
        }
        // G3（74e76be 语义）：邮箱转移即时 JIT 建号 + 受邀租户成员即建（新账号 is_default=1，首登不 401）；
        // 角色仍延期到 accept 绑定（defaultRoleId=is_owner，swap 在 acceptOwnerTransfer 内完成）
        ProvisionResult provisioned = jitLocalAccountService.provisionIfAbsent(normalizedEmail);
        invitationRepository.markExpiredInvitations(normalizedTenantId, normalizedEmail); // V20 唯一索引前提
        if (invitationRepository.findPendingByTenantEmailAndPurpose(normalizedTenantId, normalizedEmail,
                OWNER_TRANSFER_PURPOSE).isPresent()) {
            throw AuthException.badRequest(ErrorCode.OWNER_INVITE_PENDING);
        }
        tenantQuotaService.assertCanReserveMember(normalizedTenantId);
        boolean makeDefault = provisioned.created()
                || membershipRepository.findDefaultActive(provisioned.userId()).isEmpty();
        createInvitedMembership(normalizedTenantId, provisioned.userId(), makeDefault); // 角色延期 accept，此出不绑
        OwnerInvitation invited = persistOwnerInvitation(claims, normalizedTenantId, normalizedEmail,
                OWNER_TRANSFER_PURPOSE);
        return new OwnerInvitation(invited.invitationId(), invited.email(), invited.plainToken(),
                invited.expiresAt(), provisioned.initialPassword(), invited.appCode());
    }

    /**
     * Creates the first Owner invitation for a PENDING enterprise tenant. The caller owns the outer
     * transaction and sends the email before it commits, so an SMTP failure cannot leave an unowned tenant.
     */
    @Transactional
    public OwnerInvitation createInitialOwnerSetup(JwtClaims claims, String tenantId, String email) {
        String normalizedTenantId = tenantId.trim();
        String normalizedEmail = email == null ? "" : email.trim().toLowerCase();
        if (normalizedEmail.isBlank()) {
            throw AuthException.badRequest(ErrorCode.OWNER_EMAIL_REQUIRED);
        }
        var tenant = tenantRepository.findByIdForUpdate(normalizedTenantId)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        if (!"PENDING".equals(tenant.getTenantStatus()) || tenant.getOwnerUserId() != null
                || !com.unify.iam.app.app.service.admin.EnterpriseTenantOwnerInvitationService.PENDING_OWNER_REGISTRATION_SOURCE
                .equals(tenant.getRegistrationSource())) {
            throw AuthException.badRequest(ErrorCode.TENANT_NOT_PENDING_OWNER);
        }
        invitationRepository.markExpiredInvitations(normalizedTenantId, normalizedEmail); // V20 唯一索引前提
        if (invitationRepository.findPendingByTenantEmailAndPurpose(normalizedTenantId, normalizedEmail,
                TENANT_OWNER_SETUP_PURPOSE).isPresent()) {
            throw AuthException.badRequest(ErrorCode.OWNER_INVITE_PENDING);
        }
        // 产品口径统一（2026-11-02）：owner 邮箱邀请即时 JIT 建号 + 初始密码（与成员邀请/Owner 转交一致）。
        // PENDING 企业租户激活前不可作登录上下文（TokenService 要求默认 ACTIVE 成员、
        // LoginTargetService 目录跳过非 ACTIVE 租户）——新 JIT 账号补个人租户（自助注册同口径，
        // ensurePersonalTenantAndOwner 幂等），保证"初始密码可登录、首登强制改密后 accept"；
        // 企业租户成员仍由 accept 建立（acceptInitialOwnerSetup 校验成员已存在）。
        ProvisionResult provisioned = jitLocalAccountService.provisionIfAbsent(normalizedEmail);
        if (provisioned.created()) {
            userRepository.findByUserId(provisioned.userId()).ifPresent(user -> {
                MembershipPO membership = personalTenantService.ensurePersonalTenantAndOwner(user);
                // 与自助注册同口径：个人租户灌入默认业务应用（模板角色 + 应用记录 + owner 授
                // is_owner 角色）——否则个人租户无应用记录，登录目录（/available-apps）为空
                // → DENIED，受邀人拿着初始密码也进不了 hub 完成 accept。
                provisionPersonalTenantApps(membership);
            });
        }
        tenantQuotaService.assertCanReserveMember(normalizedTenantId);
        OwnerInvitation invited = persistOwnerInvitation(claims, normalizedTenantId, normalizedEmail,
                TENANT_OWNER_SETUP_PURPOSE);
        return new OwnerInvitation(invited.invitationId(), invited.email(), invited.plainToken(),
                invited.expiresAt(), provisioned.initialPassword(), invited.appCode());
    }

    /** JIT 个人租户应用灌入（与 RegisterService.provisionApps 同口径，默认应用取平台注册策略）。 */
    private void provisionPersonalTenantApps(MembershipPO membership) {
        List<String> appCodes = props.getEnterpriseTenantProvisioning().getDefaultAppCodes();
        if (appCodes == null || appCodes.isEmpty()) {
            return;
        }
        List<AppRoleTemplate> templates;
        try {
            templates = tenantAppProvisionService.loadForApps(appCodes);
        } catch (AuthException e) {
            return; // 未知/未启用应用忽略（与注册一致，不阻断邀请）
        }
        String tenantId = membership.getTenantId().trim();
        tenantAppProvisionService.seedTemplates(tenantId, templates);
        tenantAppProvisionService.recordTenantApps(tenantId, appCodes);
        tenantAppProvisionService.grantOwnerRoles(membership.getMembershipId().trim(), tenantId, templates);
    }

    private OwnerInvitation persistOwnerInvitation(JwtClaims claims, String tenantId, String email, String purpose) {
        String plain = SecureToken.random();
        LocalDateTime expiresAt = LocalDateTime.now().plusDays(TTL_DAYS);
        InvitationPO po = new InvitationPO();
        po.setInvitationId(IdGenerator.newBizId());
        po.setTenantId(tenantId);
        po.setEmail(email);
        po.setInviteType("EMAIL");
        po.setInvitationPurpose(purpose);
        po.setInvitationStatus("PENDING");
        // The caller sends during the enclosing transaction; failed delivery rolls this row back.
        po.setDeliveryStatus("DELIVERED");
        po.setInviteTokenHash(SecureToken.hash(plain));
        po.setInvitedByUserId(claims.userId());
        po.setExpiresAt(expiresAt);
        po.setAppCode(resolveInvitationAppCode(tenantId));
        // G3：Owner 邀请的默认角色 = is_owner 模板角色——accept 时才绑定（角色切换延期到同意，docs/08 §6）
        po.setDefaultRoleId(resolveOwnerRoleId(tenantId));
        try {
            invitationRepository.insert(po);
        } catch (org.springframework.dao.DuplicateKeyException ex) {
            // V20 uk_invitation_pending 撞键（并发漏网）→ 与防重检查同一错误码（Owner 语义）
            throw AuthException.badRequest(ErrorCode.OWNER_INVITE_PENDING);
        }
        return new OwnerInvitation(po.getInvitationId(), email, plain, expiresAt, null, po.getAppCode());
    }

    /** 租户已启用应用的 is_owner 模板角色（已灌入者；未灌入/多应用取首个）。 */
    private String resolveOwnerRoleId(String tenantId) {
        Set<String> ownerCodes = new HashSet<>(applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                tenantApplicationRepository.findAppCodesByTenant(tenantId)));
        return roleRepository.listByScope("TENANT", tenantId.trim()).stream()
                .filter(r -> r.getRoleCode() != null && ownerCodes.contains(r.getRoleCode().trim()))
                .map(r -> r.getRoleId().trim())
                .findFirst()
                .orElse(null);
    }


    /** initialPassword：JIT 新建账号的初始密码（邮件密码块用；已有账号/首人开通为 null）。 */
    public record OwnerInvitation(String invitationId, String email, String plainToken, LocalDateTime expiresAt,
                                  String initialPassword, String appCode) {}
}

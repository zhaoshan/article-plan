# Align admin member list with scope contract

## Goal

Change `GET /api/v1/admin/members` to use the same explicit scope tuple as the admin role list:
`scope_type=PLATFORM&scope_id=PLATFORM` returns the platform-wide member aggregation, while
`scope_type=TENANT&scope_id=<tenant_id>` returns only that tenant's members. Preserve the existing
keyword, owner-candidate, limit, ordering, projection, and count/total semantics.

## Confirmed current behavior and old omission cause

- `AdminMemberController#list` currently requires `tenant_id` and passes it to `TenantMemberQueryService#search`.
- `TenantMemberQueryService` trims the tenant ID, validates the limit, calls `TenantScopeGuard.assertTenantScope`, requires the tenant to exist, and executes `TenantMemberQueryMapper` with `WHERE m.tenant_id = #{tenantId}`.
- The endpoint was introduced as a tenant-specific member-management list in the E2E-3 contract and docs; later member-search work extended filtering but retained the same required `tenant_id` contract. The role list was subsequently standardized on `scope_type/scope_id`, but the member list was not migrated, so a platform request using only a tenant ID had no way to express the platform scope tuple.

## Requirements

1. Bind paired snake_case `scope_type` and `scope_id` query parameters on the member list; reject the legacy `tenant_id` parameter.
2. Validate the tuple with the established role/tenant-list rules: a scope tuple must be complete, values are exact uppercase `PLATFORM` or `TENANT`, `PLATFORM` requires ID `PLATFORM`, and `TENANT` requires a non-blank tenant ID. Invalid or partial tuples return standard 400.
3. `PLATFORM/PLATFORM` is a global management query: include members from every visible, non-deleted tenant, subject to the existing filters and limit. It requires platform-admin scope authorization.
4. `TENANT/<tenant_id>` filters to that tenant before keyword/owner-candidate filtering and `LIMIT`; it requires the existing tenant-scope guard. Unknown or deleted authorized tenants preserve the existing member-list not-found behavior rather than returning another tenant's data.
5. Preserve `keyword`, `owner_candidates`, `limit` (1..1000), stable membership database id ordering, projection fields, role aggregation, `count`, `total`, and `truncated`. Every member row must expose its real `tenant_id` and `tenant_name`; it may also expose its tenant type for row-level attribution. A PLATFORM aggregate must not claim one top-level `tenant_type`; omit that singleton field or use an explicitly documented aggregate-safe representation.
6. Do not change POST/PUT/DELETE member contracts or frontend code. Do not weaken the `iam:member:read` permission gate or scope authorization.
7. Define `owner_candidates=true` globally as per-tenant eligibility: membership/user must be active and the user must differ from that row's tenant owner. Support one canonical status filter `membership_status` with comma-separated values from `ACTIVE,PENDING,SUSPENDED`; filter before count/limit. Do not add a `status` alias. Add focused unit/controller and integration regression coverage for global and tenant results, filtering-before-limit, aggregation semantics, invalid tuples, tenant isolation, platform authorization, status filtering, and legacy rejection.

## Acceptance criteria

- Platform admin can query `scope_type=PLATFORM&scope_id=PLATFORM` and receives members across tenants with no cross-tenant leakage.
- Tenant admin can query its own `TENANT/<id>` scope and is rejected for foreign tenants and PLATFORM scope.
- Search keyword and owner-candidate filters remain correct in both scopes and are applied before limit.
- Missing/legacy handling is explicit and tested; no silent fallback from malformed scope parameters to a broad query.
- Existing permission failures remain 401/403 and malformed tuples use the standard 400 envelope.
- Reject old `tenant_id` alone or mixed with new fields. No-scope requests are 400; no compatibility mapping exists.

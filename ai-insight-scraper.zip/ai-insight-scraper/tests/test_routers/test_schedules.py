"""schedules 路由单元测试"""

import os
import uuid
from datetime import datetime
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from src.database.models import CrawlScheduleModel, CrawlScheduleLogModel
from src.database.repository import ScheduleRepository, ScheduleLogRepository


@pytest.fixture
def internal_token():
    """测试用内部 token"""
    return "test-internal-token"


@pytest.fixture(autouse=True)
def set_auth_env(internal_token, monkeypatch):
    """设置内部鉴权 token 环境变量"""
    monkeypatch.setenv("AUTH_INTERNAL_TOKEN", internal_token)


@pytest.fixture(autouse=True)
def mock_scheduler_service(monkeypatch):
    """mock scheduler_service 单例，避免测试中依赖真实 APScheduler"""
    from unittest.mock import MagicMock

    from src.routers import schedules

    mock = MagicMock()
    mock.get_job_info.return_value = None
    monkeypatch.setattr(schedules, "scheduler_service", mock)
    return mock


@pytest.fixture
def client(mock_scheduler_service):
    """创建 FastAPI TestClient"""
    from main import app

    return TestClient(app)


@pytest.fixture
def auth_headers(internal_token):
    """带内部 token 的请求头"""
    return {"Authorization": f"Bearer {internal_token}"}


@pytest.fixture
def sample_schedule_payload():
    """创建调度请求 payload"""
    return {
        "site": "example.com",
        "target_url": "https://example.com/",
        "cron_expression": "0 2 * * *",
        "timezone": "Asia/Tokyo",
        "enabled": True,
        "max_depth": 0,
        "headless": True,
        "output_type": "local",
        "description": "test schedule",
    }


class TestScheduleRouter:
    """调度管理路由测试"""

    @pytest.mark.asyncio
    async def test_create_schedule(
        self, client, auth_headers, sample_schedule_payload, db_session
    ):
        """创建调度配置"""
        response = client.post("/api/schedules", json=sample_schedule_payload, headers=auth_headers)
        assert response.status_code == 200
        data = response.json()["data"]
        assert data["site"] == "example.com"
        assert data["enabled"] is True
        assert "schedule_id" in data

    @pytest.mark.asyncio
    async def test_create_schedule_without_auth(self, client, sample_schedule_payload, db_session):
        """未携带 token 应被拒绝"""
        response = client.post("/api/schedules", json=sample_schedule_payload)
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_list_schedules(self, client, auth_headers, sample_schedule_payload, db_session):
        """列表查询调度配置"""
        client.post("/api/schedules", json=sample_schedule_payload, headers=auth_headers)
        response = client.get("/api/schedules", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()["data"]
        assert isinstance(data, list)
        assert len(data) >= 1

    @pytest.mark.asyncio
    async def test_get_schedule(self, client, auth_headers, sample_schedule_payload, db_session):
        """查询单个调度配置"""
        created = client.post(
            "/api/schedules", json=sample_schedule_payload, headers=auth_headers
        ).json()["data"]
        schedule_id = created["schedule_id"]

        response = client.get(f"/api/schedules/{schedule_id}", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()["data"]
        assert data["schedule_id"] == schedule_id

    @pytest.mark.asyncio
    async def test_get_schedule_not_exists(self, client, auth_headers, db_session):
        """查询不存在的调度返回 404"""
        response = client.get("/api/schedules/not-exist", headers=auth_headers)
        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_update_schedule(self, client, auth_headers, sample_schedule_payload, db_session):
        """更新调度配置"""
        created = client.post(
            "/api/schedules", json=sample_schedule_payload, headers=auth_headers
        ).json()["data"]
        schedule_id = created["schedule_id"]

        update_payload = {"enabled": False, "cron_expression": "*/10 * * * *"}
        response = client.put(
            f"/api/schedules/{schedule_id}", json=update_payload, headers=auth_headers
        )
        assert response.status_code == 200
        data = response.json()["data"]
        assert data["enabled"] is False
        assert data["cron_expression"] == "*/10 * * * *"

    @pytest.mark.asyncio
    async def test_delete_schedule(self, client, auth_headers, sample_schedule_payload, db_session):
        """删除调度配置"""
        created = client.post(
            "/api/schedules", json=sample_schedule_payload, headers=auth_headers
        ).json()["data"]
        schedule_id = created["schedule_id"]

        response = client.delete(f"/api/schedules/{schedule_id}", headers=auth_headers)
        assert response.status_code == 200
        assert response.json()["data"]["deleted"] is True

        get_response = client.get(f"/api/schedules/{schedule_id}", headers=auth_headers)
        assert get_response.status_code == 404

    @pytest.mark.asyncio
    async def test_trigger_schedule(
        self, client, auth_headers, sample_schedule_payload, db_session
    ):
        """手动触发调度"""
        created = client.post(
            "/api/schedules", json=sample_schedule_payload, headers=auth_headers
        ).json()["data"]
        schedule_id = created["schedule_id"]

        with patch("src.routers.schedules.scheduler_service") as mock_service:
            response = client.post(
                f"/api/schedules/{schedule_id}/trigger", headers=auth_headers
            )
            assert response.status_code == 200
            assert response.json()["data"]["triggered"] is True
            mock_service.trigger_job_now.assert_called_once_with(schedule_id, trigger_type="manual")

    @pytest.mark.asyncio
    async def test_list_schedule_logs(self, client, auth_headers, sample_schedule_payload, db_session):
        """查询调度执行日志"""
        created = client.post(
            "/api/schedules", json=sample_schedule_payload, headers=auth_headers
        ).json()["data"]
        schedule_id = created["schedule_id"]

        repo = ScheduleLogRepository()
        await repo.create(
            CrawlScheduleLogModel(
                log_id=str(uuid.uuid4()),
                schedule_id=schedule_id,
                site="example.com",
                target_url="https://example.com/",
                status="completed",
                trigger_type="cron",
                create_time=datetime.now(),
            )
        )

        response = client.get(f"/api/schedules/{schedule_id}/logs", headers=auth_headers)
        assert response.status_code == 200
        data = response.json()["data"]
        assert len(data) == 1
        assert data[0]["schedule_id"] == schedule_id


class TestScheduleValidation:
    """调度接口参数校验测试"""

    @pytest.mark.asyncio
    async def test_invalid_cron_expression(self, client, auth_headers, db_session):
        """非法 cron 表达式应返回 422"""
        payload = {
            "site": "example.com",
            "target_url": "https://example.com/",
            "cron_expression": "not-a-cron",
        }
        response = client.post("/api/schedules", json=payload, headers=auth_headers)
        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_invalid_url_scheme(self, client, auth_headers, db_session):
        """非法 URL 协议应返回 422"""
        payload = {
            "site": "example.com",
            "target_url": "ftp://example.com/",
            "cron_expression": "0 2 * * *",
        }
        response = client.post("/api/schedules", json=payload, headers=auth_headers)
        assert response.status_code == 422

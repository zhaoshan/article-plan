package com.unify.iam.tenant.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_membership 用户与租户成员关系表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_membership")
public class MembershipPO extends BaseEntity {

    /** 成员关系业务唯一标识 */
    private String membershipId;
    /** 所属租户 ID */
    private String tenantId;
    /** 所属用户 ID */
    private String userId;
    /** 成员状态：PENDING/ACTIVE/SUSPENDED/REMOVED */
    private String membershipStatus;
    /** 加入来源 */
    private String joinSource;
    /** 是否默认进入该租户 */
    private Integer isDefault;
    /** 令牌版本（方案 c 即时吊销，docs/07 §8.3）：角色/权限变更时 +1，JWT ver 落后即失效 */
    private Integer tokenVersion;
    /** G9：成员级最近打开时间（初始登录设置 / switch-tenant 更新；Last opened 排序） */
    private java.time.LocalDateTime lastOpenedAt;
    private String invitedByUserId;
    private String approvedByUserId;
    private LocalDateTime joinedAt;
    private LocalDateTime suspendedAt;
    private LocalDateTime leftAt;
}

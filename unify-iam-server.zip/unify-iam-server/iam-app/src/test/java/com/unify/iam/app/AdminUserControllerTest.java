package com.unify.iam.app;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.AdminUserController;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminUserService;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.config.WebMvcConfig;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(AdminUserController.class)
@Import({GlobalExceptionHandler.class, WebMvcConfig.class, ManagementAuthorizationInterceptor.class})
class AdminUserControllerTest {

    private static String b64(String raw) {
        return com.unify.iam.common.util.PasswordCodecs.encodeBase64(raw);
    }

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private JwtSigner jwtSigner;
    @MockitoBean
    private UserRepository userRepository;
    @MockitoBean
    private AdminUserService adminUserService;
    @MockitoBean
    private AuditService auditService;
    @MockitoBean
    private AuditLogRepository auditLogRepository;

    private JwtClaims claims(String... permissions) {
        long now = Instant.now().getEpochSecond();
        return new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1",
                "tenant-org-a", "ms-1", List.of("PlatformAdmin"), List.of(permissions), Map.of(),
                now + 3600, now, "jti", 0L);
    }

    @Test
    void adminUsersWithoutTokenReturns401() throws Exception {
        mockMvc.perform(get("/api/v1/admin/users"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("Missing token")));
    }

    @Test
    void adminUsersWithoutIamPermissionReturns403() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims("agent:read")); // 无 iam:user:read

        mockMvc.perform(get("/api/v1/admin/users").header("Authorization", "Bearer t"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("Missing permission point")));
    }

    @Test
    void adminUsersWithIamPermissionReturns200() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_READ));
        UserPO u = new UserPO();
        u.setUserId("u-1000");
        u.setUsername("admin");
        u.setPrimaryEmail("admin@unify.local");
        u.setUserStatus("ACTIVE");
        when(userRepository.search(anyInt())).thenReturn(List.of(u));
        when(auditService.audit())
                .thenReturn(new AuditService.AuditEntry(auditLogRepository)); // 真实 entry，repo mock 落库无副作用

        mockMvc.perform(get("/api/v1/admin/users").header("Authorization", "Bearer t"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(1))
                .andExpect(jsonPath("$.data.users[0].username").value("admin"))
                .andExpect(jsonPath("$.data.users[0].user_id").value("u-1000"));
    }

    @Test
    void userWriterCanUpdateEmail() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_WRITE));
        when(auditService.audit())
                .thenReturn(new AuditService.AuditEntry(auditLogRepository));

        mockMvc.perform(put("/api/v1/admin/users/u-1000")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"new@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.user_id").value("u-1000"));

        verify(adminUserService).update(eq("u-1000"), argThat(request ->
                "new@example.com".equals(request.email())
                        && request.fullName() == null
                        && request.displayName() == null
                        && request.userStatus() == null));
    }

    @Test
    void invalidUpdateEmailReturns400BeforeService() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_WRITE));

        mockMvc.perform(put("/api/v1/admin/users/u-1000")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"not-an-email\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Request validation failed: email format is invalid"));

        verifyNoInteractions(adminUserService);
    }

    @Test
    void blankUpdateEmailReturns400BeforeService() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_WRITE));

        mockMvc.perform(put("/api/v1/admin/users/u-1000")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false));

        verifyNoInteractions(adminUserService);
    }

    @Test
    void oversizedUpdateEmailReturns400BeforeService() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_WRITE));
        String email = "a".repeat(252) + "@x.io";

        mockMvc.perform(put("/api/v1/admin/users/u-1000")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false));

        verifyNoInteractions(adminUserService);
    }

    @Test
    void userWriterCanResetLocalPassword() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_WRITE));
        when(auditService.audit())
                .thenReturn(new AuditService.AuditEntry(auditLogRepository));

        mockMvc.perform(post("/api/v1/admin/users/u-1000/reset-password")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"password\":\"" + b64("NewPassword123!") + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.user_id").value("u-1000"))
                .andExpect(jsonPath("$.data.status").value("PASSWORD_RESET"));

        verify(adminUserService).resetPassword("u-1000", "NewPassword123!");
    }

    @Test
    void passwordResetRejectsBlankPasswordBeforeService() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_WRITE));

        mockMvc.perform(post("/api/v1/admin/users/u-1000/reset-password")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"password\":\"" + b64("   ") + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("password is required"));

        verifyNoInteractions(adminUserService);
    }

    @Test
    void passwordResetRejectsDeprecatedNewPasswordFieldBeforeService() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_WRITE));

        mockMvc.perform(post("/api/v1/admin/users/u-1000/reset-password")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"new_password\":\"" + b64("NewPassword123!") + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Request validation failed: password is required"));

        verifyNoInteractions(adminUserService);
    }

    @Test
    void passwordResetRequiresUserWritePermission() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_READ));

        mockMvc.perform(post("/api/v1/admin/users/u-1000/reset-password")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"password\":\"" + b64("NewPassword123!") + "\"}"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.success").value(false));

        verifyNoInteractions(adminUserService);
    }
}

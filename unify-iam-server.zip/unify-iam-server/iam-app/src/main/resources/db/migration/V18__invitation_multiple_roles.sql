-- Keep historical invitations readable through default_role_id when this column is NULL.
-- New invitations persist the complete role set, including an explicit empty array.
ALTER TABLE gateway_invitation
    ADD COLUMN role_ids_json JSON DEFAULT NULL COMMENT 'Full invitation role IDs; NULL uses legacy default_role_id'
    AFTER default_role_id;

"""定时调度服务

封装 APScheduler 生命周期管理与 job 注册/移除/触发。
所有调度配置持久化在 crawl_schedules 表，应用启动时加载启用项并注册 cron job。
"""

import logging
from datetime import datetime
from typing import Any

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from src.database import ScheduleRepository, CrawlScheduleModel
from src.schedulers.scheduled_executor import execute_scheduled_crawl

logger = logging.getLogger(__name__)


class SchedulerService:
    """APScheduler 包装服务"""

    def __init__(self):
        self._scheduler: AsyncIOScheduler | None = None
        self._schedule_repo = ScheduleRepository()

    def start(self) -> None:
        """启动调度器"""
        if self._scheduler is not None and self._scheduler.running:
            logger.warning("调度器已在运行")
            return

        self._scheduler = AsyncIOScheduler()
        self._scheduler.start()
        logger.info("APScheduler 已启动")

    async def shutdown(self) -> None:
        """关闭调度器"""
        if self._scheduler is None or not self._scheduler.running:
            return
        self._scheduler.shutdown(wait=False)
        self._scheduler = None
        logger.info("APScheduler 已关闭")

    async def load_schedules_from_db(self) -> None:
        """从数据库加载所有启用调度并注册为 APScheduler job"""
        if self._scheduler is None:
            raise RuntimeError("调度器尚未启动")

        schedules = await self._schedule_repo.list_enabled()
        for schedule in schedules:
            self.add_schedule_job(schedule)
        logger.info(f"已从数据库加载 {len(schedules)} 条启用调度")

    def add_schedule_job(self, schedule: CrawlScheduleModel) -> None:
        """将单个调度配置注册为 APScheduler cron job"""
        if self._scheduler is None:
            raise RuntimeError("调度器尚未启动")

        job_id = schedule.schedule_id
        # 如果已存在则先移除再重新添加（用于更新场景）
        if self._scheduler.get_job(job_id):
            self._scheduler.remove_job(job_id)

        trigger = CronTrigger.from_crontab(
            schedule.cron_expression,
            timezone=schedule.timezone,
        )
        self._scheduler.add_job(
            execute_scheduled_crawl,
            trigger=trigger,
            id=job_id,
            name=f"{schedule.site} - {schedule.target_url}",
            args=[schedule.schedule_id],
            max_instances=1,
            replace_existing=True,
        )
        logger.info(
            f"已注册调度 job: schedule_id={job_id}, site={schedule.site}, "
            f"cron={schedule.cron_expression}, timezone={schedule.timezone}"
        )

    def remove_schedule_job(self, schedule_id: str) -> bool:
        """移除已注册的 job"""
        if self._scheduler is None:
            return False
        try:
            self._scheduler.remove_job(schedule_id)
            logger.info(f"已移除调度 job: schedule_id={schedule_id}")
            return True
        except Exception:
            return False

    def reschedule_job(self, schedule: CrawlScheduleModel) -> None:
        """重新注册调度（更新 cron/时区后调用）"""
        self.add_schedule_job(schedule)

    def trigger_job_now(self, schedule_id: str, trigger_type: str = "manual") -> None:
        """立即手动触发一次调度执行"""
        if self._scheduler is None:
            raise RuntimeError("调度器尚未启动")

        self._scheduler.add_job(
            execute_scheduled_crawl,
            trigger="date",
            run_date=datetime.now(),
            args=[schedule_id, trigger_type],
            max_instances=1,
        )
        logger.info(f"已手动触发调度: schedule_id={schedule_id}")

    def get_job_info(self, schedule_id: str) -> dict[str, Any] | None:
        """获取已注册 job 的下次执行时间等信息"""
        if self._scheduler is None:
            return None
        job = self._scheduler.get_job(schedule_id)
        if job is None:
            return None
        return {
            "next_run_time": job.next_run_time.isoformat() if job.next_run_time else None,
        }


# 全局单例
scheduler_service = SchedulerService()

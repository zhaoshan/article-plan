"""定时调度配置与执行日志 Pydantic 模型"""

import uuid
from datetime import datetime

from pydantic import BaseModel, Field, field_validator, ConfigDict


class CrawlScheduleBase(BaseModel):
    """定时调度配置基础字段"""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    site: str = Field(
        ...,
        min_length=1,
        max_length=256,
        description="站点域名（如 tokyostarbank.co.jp）",
    )
    target_url: str = Field(
        ...,
        min_length=1,
        max_length=2048,
        description="爬取入口 URL",
    )
    cron_expression: str = Field(
        ...,
        min_length=1,
        max_length=64,
        description="标准 5 字段 cron 表达式，如 0 2 * * *",
    )
    timezone: str = Field(
        default="Asia/Tokyo",
        min_length=1,
        max_length=64,
        description="cron 时区，如 Asia/Tokyo",
    )
    enabled: bool = Field(
        default=True,
        description="是否启用",
    )
    max_depth: int | None = Field(
        default=None,
        ge=0,
        description="最大爬取深度（None=使用遍历配置默认值）",
    )
    headless: bool = Field(
        default=True,
        description="是否无头模式运行浏览器",
    )
    output_type: str = Field(
        default="s3",
        pattern=r"^(local|s3)$",
        description="输出方式：local / s3",
    )
    description: str | None = Field(
        default=None,
        max_length=512,
        description="调度描述",
    )

    @field_validator("target_url")
    @classmethod
    def validate_url_scheme(cls, v: str) -> str:
        """校验 URL 必须以 http:// 或 https:// 开头"""
        if not v.startswith(("http://", "https://")):
            raise ValueError("target_url 必须以 http:// 或 https:// 开头")
        return v

    @field_validator("cron_expression")
    @classmethod
    def validate_cron_expression(cls, v: str) -> str:
        """校验 cron 表达式可被 APScheduler 解析"""
        try:
            # 延迟导入，避免模型层强依赖 APScheduler
            from apscheduler.triggers.cron import CronTrigger

            CronTrigger.from_crontab(v.strip())
        except Exception as e:
            raise ValueError(f"无效的 cron 表达式: {e}") from e
        return v.strip()


class CrawlScheduleCreate(CrawlScheduleBase):
    """创建定时调度配置请求"""

    pass


class CrawlScheduleUpdate(BaseModel):
    """更新定时调度配置请求（全部可选）"""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)

    site: str | None = Field(
        default=None,
        min_length=1,
        max_length=256,
        description="站点域名",
    )
    target_url: str | None = Field(
        default=None,
        min_length=1,
        max_length=2048,
        description="爬取入口 URL",
    )
    cron_expression: str | None = Field(
        default=None,
        min_length=1,
        max_length=64,
        description="标准 5 字段 cron 表达式",
    )
    timezone: str | None = Field(
        default=None,
        min_length=1,
        max_length=64,
        description="cron 时区",
    )
    enabled: bool | None = Field(
        default=None,
        description="是否启用",
    )
    max_depth: int | None = Field(
        default=None,
        ge=0,
        description="最大爬取深度",
    )
    headless: bool | None = Field(
        default=None,
        description="是否无头模式运行浏览器",
    )
    output_type: str | None = Field(
        default=None,
        pattern=r"^(local|s3)$",
        description="输出方式：local / s3",
    )
    description: str | None = Field(
        default=None,
        max_length=512,
        description="调度描述",
    )

    @field_validator("target_url")
    @classmethod
    def validate_url_scheme(cls, v: str | None) -> str | None:
        """校验 URL 必须以 http:// 或 https:// 开头"""
        if v is not None and not v.startswith(("http://", "https://")):
            raise ValueError("target_url 必须以 http:// 或 https:// 开头")
        return v

    @field_validator("cron_expression")
    @classmethod
    def validate_cron_expression(cls, v: str | None) -> str | None:
        """校验 cron 表达式可被 APScheduler 解析"""
        if v is None:
            return v
        try:
            from apscheduler.triggers.cron import CronTrigger

            CronTrigger.from_crontab(v.strip())
        except Exception as e:
            raise ValueError(f"无效的 cron 表达式: {e}") from e
        return v.strip()


class CrawlScheduleResponse(CrawlScheduleBase):
    """定时调度配置响应"""

    model_config = ConfigDict(from_attributes=True)

    schedule_id: str = Field(
        ...,
        description="调度 UUID",
    )
    create_time: datetime = Field(
        ...,
        description="创建时间",
    )
    update_time: datetime | None = Field(
        default=None,
        description="更新时间",
    )


class CrawlScheduleLogResponse(BaseModel):
    """定时调度执行日志响应"""

    model_config = ConfigDict(from_attributes=True)

    log_id: str = Field(..., description="日志 UUID")
    schedule_id: str = Field(..., description="关联调度 UUID")
    task_id: str | None = Field(default=None, description="关联任务 UUID")
    site: str = Field(..., description="本次执行站点")
    target_url: str = Field(..., description="本次执行入口 URL")
    status: str = Field(..., description="执行状态")
    trigger_type: str = Field(..., description="触发方式")
    links_path: str | None = Field(default=None, description="links 文件路径")
    tree_path: str | None = Field(default=None, description="tree 文件路径")
    pages_crawled: int = Field(default=0, description="已爬取页面数")
    links_found: int = Field(default=0, description="已发现链接数")
    error_message: str | None = Field(default=None, description="失败原因")
    started_at: datetime | None = Field(default=None, description="开始执行时间")
    finished_at: datetime | None = Field(default=None, description="完成/失败时间")
    create_time: datetime = Field(..., description="记录创建时间")

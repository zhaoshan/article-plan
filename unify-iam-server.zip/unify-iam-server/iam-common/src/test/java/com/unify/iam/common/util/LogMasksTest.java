package com.unify.iam.common.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

/** 日志脱敏（2026-11-05 日志分层③）：字段名黑名单无条件打码 + email 掩码。 */
class LogMasksTest {

    @Test
    void passwordAndTokenFieldsAreMaskedRegardlessOfValue() {
        String out = LogMasks.maskJson(
                "{\"username\":\"alice\",\"password\":\"QmFzZTY0PWNsYXNz\",\"refresh_token\":\"rt-123\",\"client_secret\":\"cs\"}");
        assertThat(out).contains("\"username\":\"alice\"");
        assertThat(out).contains("\"password\":\"***\"");
        assertThat(out).contains("\"refresh_token\":\"***\"");
        assertThat(out).contains("\"client_secret\":\"***\"");
        // base64 密码绝不可出现在日志输出里
        assertThat(out).doesNotContain("QmFzZTY0PWNsYXNz");
    }

    @Test
    void nestedStructuresAreRecursivelyMasked() {
        String out = LogMasks.maskJson(
                "{\"outer\":{\"token\":\"abc\"},\"list\":[{\"secret\":\"s1\"},1,\"a@b.com\"]}");
        assertThat(out).contains("\"token\":\"***\"");
        assertThat(out).contains("\"secret\":\"***\"");
        assertThat(out).contains("a***@b.com");
    }

    @Test
    void emailsInStringValuesAreMasked() {
        assertThat(LogMasks.maskEmail("alice@example.com")).isEqualTo("al***@example.com");
        assertThat(LogMasks.maskEmail("a@example.com")).isEqualTo("a***@example.com");
        assertThat(LogMasks.maskText("invited alice@example.com and bob@x.io"))
                .isEqualTo("invited al***@example.com and bo***@x.io");
        assertThat(LogMasks.maskText("no email here")).isEqualTo("no email here");
    }

    @Test
    void mapPayloadIsMasked() {
        Map<String, Object> out = LogMasks.maskMap(Map.of(
                "email", "alice@example.com",
                "password", "x",
                "nested", Map.of("token", "t", "v", 1),
                "list", List.of(Map.of("secret", "s"))));
        assertThat(out.get("email")).isEqualTo("al***@example.com");
        assertThat(out.get("password")).isEqualTo("***");
        @SuppressWarnings("unchecked")
        Map<String, Object> nested = (Map<String, Object>) out.get("nested");
        assertThat(nested.get("token")).isEqualTo("***");
        assertThat(nested.get("v")).isEqualTo(1);
        assertThat(out.toString()).contains("secret=***");
    }

    @Test
    void malformedJsonFallsBackToTruncatedRaw() {
        String raw = "not-json" + "x".repeat(600);
        String out = LogMasks.maskJson(raw);
        assertThat(out).endsWith("...(truncated)");
        assertThat(out.length()).isLessThan(600);
    }
}

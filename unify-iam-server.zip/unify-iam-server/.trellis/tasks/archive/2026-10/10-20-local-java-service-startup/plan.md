# 后端重编译与重启计划

**日期：** 2026-10-26  
**范围：** 当前 `platform-iam-service` 主工作区、该工作区既有的本地 MySQL 容器，以及既有的 IAM 用户级服务代理。

## 目标

重新编译当前后端，并让已注册的本地 IAM 服务加载新构建产物后恢复到可用状态。

## 边界与已确认事项

- 用户已明确请求本次重编译与启动；不修改产品源码、数据库配置、Flyway 迁移、分支或 worktree。
- 当前工作区递归查找未发现 `AGENTS.md` 或 `.trellis/workflow.md`；因此不存在可读取或执行的未落盘 Trellis 确认门禁。已改为遵守实际存在的 `CLAUDE.md`、`.claude/rules/` 与本任务既有 PRD。
- 工作区在开始前已有未提交的业务代码、文档和 `.trellis/` 改动；本次不改动或回退它们。
- 编译命令须使用 JDK 26 所需的 `-Dmaven.compiler.proc=full`。仅做重新构建时跳过测试；运行时仍以现有 `platform-iam-service-mysql` 容器和现有 `com.platform-iam.service` 用户级服务为准。
- 不执行提交、合并、推送、切换或重置分支，也不创建或删除 worktree。

## 执行项

- [x] 核对 JDK/Maven、既有 MySQL、服务代理、端口和现有进程状态。
- [x] 执行全模块干净构建并安装可执行 `iam-app` JAR。
- [x] 重启既有用户级 IAM 服务，使其载入新构建的 JAR。
- [x] 验证 8090 监听、健康检查和 JWKS 端点；记录结果与 Git 状态。

## 执行结果

- 预检时发现 IAM 服务因 Docker 守护进程未运行、MySQL 连接被拒绝而无法完成启动。仅恢复了已有的 Docker Desktop 和 `platform-iam-service-mysql` 容器；容器恢复后为 `running / healthy`，继续绑定 `127.0.0.1:3306`。
- `mvn clean install -DskipTests -Dmaven.compiler.proc=full` 在 JDK 26.0.2.1 / Maven 3.9.16 下完成，根项目及六个子模块均为 `SUCCESS`，并重新生成 `iam-app/target/iam-app-0.0.1-SNAPSHOT.jar`。
- 用既有 `launchctl` 任务 `com.platform-iam.service` 重启服务后，Java 进程监听 `*:8090`；它完成 Flyway 校验并加载当前工作区的已有私钥。
- 受控本机验证通过：`GET /actuator/health` 返回 `UP`，`GET /.well-known/jwks.json` 返回一把 `kid=iam-key-1`、`kty=RSA`、`alg=RS256` 的签名公钥。
- 本次构建按请求跳过测试；未执行提交、合并、推送、分支切换、重置或 worktree 操作。

# Backend tenant usage contract for member management

Date: 2026-11-02 (Asia/Shanghai). Repository: `/Users/ramiro.li/root/apps/work/platform-iam-service`.
Branch: `feature/lee-1102`; inspected HEAD: `5506ab0`. Scope: backend source and existing tests only; no frontend inspection or business-code changes.

## 1. Decision and endpoint inventory

Use **GET `/api/v1/admin/tenants/{tenantId}/usage`** for the member page quota display.
**There is no GET `/usage/{dimensionId}` in this checkout.** That path is a PUT
mutation for setting/resetting a quota. Do not send PUT just to obtain usage.

| Method and path suffix | Purpose | Permission | Successful `data` |
| --- | --- | --- | --- |
| GET `/{tenantId}/usage` | Read all registered dimensions belonging to enabled tenant applications | `iam:tenant:read` | `{tenant_id, usage: UsageRow[]}` |
| PUT `/{tenantId}/usage/{dimensionId}` | Set/reset a single dimension's tenant override | `iam:tenant:write` | One `UsageRow`, without a surrounding `usage` array or `tenant_id` |
| GET `/{tenantId}/details` | Tenant drawer: tenant, owner, applications, members, and a different usage DTO | `iam:tenant:read` AND `iam:member:read` | `TenantDetailResponse` |
| GET `/{tenantId}` | Basic tenant detail | `iam:tenant:read` | Tenant basic fields; no usage |

Evidence: `iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminTenantController.java:94`, `:101`, `:140`, `:148`.
The comments above GET and `QuotaService.usage()` still mention global IAM dimensions; the executable implementation and test assertions override those stale comments.

## 2. Wire format and field contract

The global response advice wraps successful API payloads. `CommonResponse.success`
sets `code` and `message` to null; application Jackson inclusion is `non_null`,
so null fields (including null map entries) are omitted. Clients should accept
both absent and explicit null optional fields; do not require `code: "0"`.

```ts
type UsageRow = {
  dimension_id: string;
  app_code: string;
  dimension_key: string;
  dimension_name: string;
  unit?: string | null;
  source: string; // current modeled sources: IAM, BUSINESS
  default_limit?: number | null; // nullable Integer, template value
  limit?: number | null;         // nullable Integer, effective tenant value
  override: boolean;
  used?: number | null;          // Java long for IAM; unavailable for BUSINESS
  pending?: number | null;       // Java long for IAM members only
  remaining?: number | null;
};
type UsageResponse = {
  success: true;
  code?: string | null;
  message?: string | null;
  data: { tenant_id: string; usage: UsageRow[] };
};
```

Representative example derived from `QuotaService.row` and the imorph seed
(illustrative counts, not a captured live response):

```json
{
  "success": true,
  "data": {
    "tenant_id": "tenant-example",
    "usage": [
      {
        "dimension_id": "gd-3001",
        "app_code": "imorph",
        "dimension_key": "members",
        "dimension_name": "Members",
        "source": "IAM",
        "default_limit": 10,
        "limit": 10,
        "override": false,
        "used": 2,
        "pending": 1,
        "remaining": 7
      },
      {
        "dimension_id": "gd-3002",
        "app_code": "imorph",
        "dimension_key": "apps",
        "dimension_name": "Apps",
        "source": "IAM",
        "default_limit": 20,
        "limit": 20,
        "override": false,
        "used": 1,
        "remaining": 19
      }
    ]
  }
}
```

There are no `used_count`, `active_count`, `pending_count`, `limit_value`,
`limited`, `over_limit`, or `usage_available` response fields in this API.
Those belong to `TenantUsageDimension` used by `/details` and `/quotas/{dimensionKey}`.

Evidence: `iam-app/src/main/java/com/unify/iam/app/app/service/QuotaService.java:172`;
`iam-app/src/main/java/com/unify/iam/app/config/ApiEnvelopeAdvice.java`;
`iam-common/src/main/java/com/unify/iam/common/result/CommonResponse.java`;
`iam-app/src/main/resources/application.yml:4`;
`iam-api/src/main/java/com/unify/iam/api/dto/admin/TenantUsageDimension.java`.

## 3. Dimensions and aggregation

`dimensionId` is the database business identifier, not `members`, not
`iam:members`, and not the numeric primary key. Resolve it from the returned row.

| Current seed ID | app_code | dimension_key | default_limit | source |
| --- | --- | --- | --- | --- |
| `gd-2001` | `iam` | `members` | 10 | IAM |
| `gd-2002` | `iam` | `apps` | 20 | IAM |
| `gd-3001` | `imorph` | `members` | 10 | IAM |
| `gd-3002` | `imorph` | `apps` | 20 | IAM |

The list is extensible through registered database rows; these IDs are seed facts,
not a closed enum for frontend code. Seeds currently define no parlant dimension.

GET obtains app codes from undeleted `gateway_tenant_application` relations, then
lists undeleted dimensions for those codes, ordered by `sort_order`, then
`dimension_id`. It does not check application status or `dimension_status`.
IAM dimensions appear only if the tenant explicitly enables `iam`.
An imorph-only tenant returns its two imorph rows, not IAM rows as well.
No enabled apps/no matching dimensions yields `usage: []` (200).

This is an aggregation of dimension rows, **not a sum of usage**. Every IAM
`members` row counts the same tenant-wide member population; `app_code` identifies
the policy owner, not an app-specific member subset. Every IAM `apps` row counts
the number of enabled tenant/application relations. Several `members` policies
can apply concurrently; never add their `used`, `pending`, `limit`, or `remaining`.

Evidence: `QuotaService.java:70`, `:145`, `:172`;
`iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/repository/QuotaDimensionRepository.java:23`;
`iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/repository/TenantApplicationRepository.java:102`;
`iam-app/src/main/resources/db/seed/R__platform_bootstrap.sql:124`;
`iam-app/src/main/resources/db/seed/R__app_imorph.sql:386`;
`iam-app/src/test/java/com/unify/iam/app/QuotaIntegrationTest.java:31`.

## 4. Member usage, quota, unlimited state, and enforcement

For an IAM `members` row:

- `used`: DISTINCT undeleted ACTIVE memberships with at least one undeleted role
  binding, excluding memberships holding a resolved Owner role. The SQL does not
  require the ordinary bound role to be active or undeleted; it checks the binding.
- Owner roles are resolved from enabled applications' `is_owner` templates and
  active, undeleted TENANT-scoped roles matching those role codes. This is based
  on roles, not directly on `tenant.owner_user_id`.
- `pending`: PENDING invitation rows for the tenant, excluding an invitation when
  its email already belongs to an ACTIVE membership in that tenant. It counts
  invitations, not distinct emails. This query has **no expires_at filter**, no
  purpose filter, and its nested user/membership existence query does not filter
  soft deletion. Do not describe it as strictly unexpired invitations.
- `remaining = max(0, limit - used - pending)` for a finite limit.
- PENDING membership rows are **not** added by this endpoint; SUSPENDED and
  DELETED memberships do not contribute to `used`. Owner-only tenants can show 0.

`limit` uses a non-null tenant override if present, otherwise `default_limit`.
`override` says whether a non-null override exists. Missing/null `limit` means
unlimited in the display; `remaining` is then missing/null. **0 is a finite,
exhausted quota**, not unlimited. `limit_value: null` on PUT resets to the default;
it does not request unlimited unless the default itself is null. -1 is invalid.

For BUSINESS rows, `used` and `pending` are unavailable/omitted. The current code
still calculates `remaining` using local zero counts when a limit exists; this
is not measured business usage. Unknown IAM dimension keys currently show used=0
rather than an availability flag. Restrict the member quota widget to
`source === "IAM" && dimension_key === "members"`.

**Display is not an admission guarantee.** `assertMemberSeat()` counts every
ACTIVE non-Owner membership, including zero-role/JIT memberships excluded from
display. It checks every applicable members dimension, with the strictest policy
blocking a new seat. Its applicability filter requires a non-null template
default, so a finite override on a null-default dimension is displayed but is
not enforced by that G1 loop. Separately, `TenantQuotaService.assertCanReserveMember`
also checks the active IAM-owned members dimension, includes PENDING memberships,
and honors an explicit IAM override even when IAM is not enabled. Thus a hidden
IAM policy can reject an add/invite despite an apparently available `/usage` row.

Evidence: `QuotaService.java:117`, `:145`, `:161`, `:172`;
`iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/mapper/MembershipRoleMapper.java:78`;
`iam-app/src/main/java/com/unify/iam/app/infra/persistence/repository/InvitationRepository.java:29`;
`iam-app/src/main/java/com/unify/iam/app/app/service/TenantQuotaService.java:122`;
`iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminMemberService.java:95`;
`iam-app/src/main/java/com/unify/iam/app/app/service/InvitationService.java:123`, `:408`, `:438`.

## 5. PUT mutation contract and errors

Request: `Content-Type: application/json`, body `{"limit_value": 12}`; field is a
Java `Integer` (32-bit), nonnegative. `{}`, `{"limit_value":null}`, or no request
body resets/deletes the override. Return `data` is the same row shape as GET.
This mutation has audit event `ADMIN_SET_TENANT_QUOTA`.

Unlike `/quotas/{dimensionKey}`, this PUT does not reject a limit below current
usage, does not verify that the dimension belongs to an enabled app, and does not
explicitly check the tenant exists. Its dimension lookup is by undeleted business
ID only. Do not import the stricter `/quotas` validation contract into this API.

Both usage endpoints require a valid Bearer JWT. In addition to their separate
permission requirements, `TenantScopeGuard` permits the token tenant only unless
the JWT membership has a real nondeleted PLATFORM role binding in the database.
JWT role names alone do not establish platform scope. The platform-role SQL
does not itself filter role status or join membership status; normal token
validation is a separate concern.

| Condition | Current behavior |
| --- | --- |
| Missing/invalid Bearer for a mapped usage method | HTTP 401 |
| Missing respective tenant read/write permission | HTTP 403, missing permission message |
| Non-platform caller targets a different tenant | HTTP 403, `无权操作其他租户` |
| Authorized GET for nonexistent tenant | No tenant existence check; ordinarily HTTP 200 with empty usage |
| PUT nonexistent/deleted dimension ID (including literal `members`) | HTTP 404, `配额维度不存在` |
| PUT negative limit | HTTP 400, `limit_value 不能为负数` |
| Malformed/unreadable body or Integer overflow | HTTP 400, `请求体格式错误` |
| PUT finite value below current used+pending | Accepted; returned remaining clamps to 0 |
| PUT dimension for a non-enabled app | Accepted if dimension exists; not necessarily returned by subsequent GET |
| GET `/usage/{dimensionId}` | No GET mapping; unsupported method, not a read contract |
| Unexpected persistence/other exception | HTTP 500, system error |

AuthException failures use `{"success":false,"code":"IAM-AUTH-000","message":"..."}`;
JSON parse failures use `IAM-PARAM-000`; fallback failures use `IAM-SYST-000`.
`data` is omitted under non_null. Consume HTTP status and `message`; do not expect
legacy `detail`. Unsupported-method status was not runtime-tested: there is a
catch-all Exception handler and no explicit method-not-supported handler, so
do not promise 405 (it may be converted to 500 by current advice).

Evidence: `AdminTenantController.java:101`;
`iam-api/src/main/java/com/unify/iam/api/dto/admin/SetQuotaRequest.java`;
`QuotaService.java:84`;
`iam-app/src/main/java/com/unify/iam/app/security/ManagementAuthorizationInterceptor.java:34`;
`iam-app/src/main/java/com/unify/iam/app/security/TenantScopeGuard.java:24`;
`iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/mapper/RoleMapper.java:17`;
`iam-app/src/main/java/com/unify/iam/app/config/GlobalExceptionHandler.java:36`;
`iam-common/src/main/java/com/unify/iam/common/result/ResultCode.java`.

## 6. Concrete frontend integration recommendation

1. When tenant scope changes or the page loads, request GET `/usage` with the
   selected tenant ID and Bearer token. Keep usage state keyed by tenant ID and
   discard stale responses from a previous tenant. Do not use `/details` for this
   widget. Continue obtaining the member table and its count from the member API.
2. Unwrap the project's HTTP client exactly once. The wire payload uses
   `response.data.usage` within the envelope; if the client already returns the
   envelope's `data`, consume `payload.usage`.
3. Filter IAM `members` rows. For a page already scoped to an application,
   display its matching row and label the app. For a tenant-wide member page,
   retain all member rows (app-labeled) so multiple policies are visible. If the
   existing UI has exactly one bar, show the finite row with the minimum
   `remaining` (deterministic tie by dimension_id); prefer a finite policy over
   an unlimited row. This selection is a UI recommendation, not a backend aggregate.
4. Bind the bar to `used`, `limit`, `pending`, `remaining`. Suggested copy:
   `2 / 10 seats, 1 pending, 7 remaining`; if the visual reserves pending seats,
   its fill is `used + pending`, while the label keeps the breakdown. Clamp the
   percentage, handle `limit===0` explicitly, and use nullish checks, never
   `limit || fallback`. Do not relabel this number as total members.
5. No rows: show no configured member quota / no applicable policy. Missing/null
   limit: show unlimited for that row. Neither state proves all server-side
   admission checks will pass. A read failure is an unavailable/error state,
   never zero usage or unlimited. Do not silently recover via tenant detail.
6. Read only requires tenant read permission; member read alone is insufficient.
   If the member page can be entered without tenant read, show the quota section
   as unavailable for that permission set and continue normal member operations
   as allowed. Confirm actual page permission wiring in the later web task.
7. Only if the page has a quota editing feature and `iam:tenant:write`, PUT the
   returned row's `dimension_id`, then refresh GET `/usage`. Do not invent a
   single-dimension GET. Reset means template default, not unlimited. The server
   remains authoritative for mutations; show its rejection message and refresh
   the member/usage state after add, invite, remove, suspend/restore, role changes,
   Owner changes, or other operations that affect seats.

`/details` migration is not a field rename: its usage is
`usage.dimensions`, IAM-owned active dimensions only, counts pending memberships
as well as invitations, has `used_count = active_count + pending_count`, and can
expose an explicit IAM override without enabling IAM. By contrast `/usage` has
enabled-app dimensions, `used` excludes pending, and no availability/over-limit
flags. Do not carry over the old selection, summation, or pending arithmetic.

Evidence: `iam-app/src/main/java/com/unify/iam/app/app/service/admin/TenantDetailService.java:55`;
`TenantQuotaService.java:163`, `:177`, `:196`;
`iam-tenant/src/main/java/com/unify/iam/tenant/infra/persistence/repository/QuotaDimensionRepository.java:24`;
`iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminMemberController.java:41`.

## 7. Validation and remaining boundaries

- Read existing integration assertions in `QuotaIntegrationTest` (GET shape,
  imorph-only dimensions, PUT override/reset, seat blocking, foreign-tenant 403)
  and `TenantDetailOwnerQuotaIntegrationTest` (Owner-free usage and dual quota APIs).
- These existing tests were inspected, not rerun. They require Spring Boot and
  MySQL Testcontainers; no live DB/API was used and no test fixture was mutated.
- Source review found stale comments in tests/docs (global IAM inclusion,
  Owner consuming a seat, unexpired invitations). Treat executable code and
  assertions as evidence and the differences above as current behavior.
- Standalone read-only contract checks and `git diff --check` are recorded in
  `validation.md`. Business source/test files remain untouched.
- The web task must inspect actual page features and HTTP-client unwrapping to
  finalize UI mapping. Adding a single-dimension GET or aligning display and
  enforcement would require separate backend work; neither is necessary to read
  the existing enabled-app member usage rows.

package com.unify.iam.app;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.mockito.ArgumentMatchers.isNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.AdminRoleController;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminRoleService;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.config.WebMvcConfig;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.common.exception.AuthException;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(AdminRoleController.class)
@Import({GlobalExceptionHandler.class, WebMvcConfig.class, ManagementAuthorizationInterceptor.class})
class AdminRoleControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private JwtSigner jwtSigner;
    @MockitoBean
    private AdminRoleService adminRoleService;
    @MockitoBean
    private AuditService auditService;
    @MockitoBean
    private AuditLogRepository auditLogRepository;
    @MockitoBean
    private com.unify.iam.tenant.infra.persistence.repository.TenantRepository tenantRepository;
    @MockitoBean
    private com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository applicationRoleTemplateRepository;
    @MockitoBean
    private com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository tenantApplicationRepository;

    @Test
    void roleCreationAcceptsOmittedCodeAndRetainsRoleIdResponse() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_WRITE));
        when(adminRoleService.create(any(), any())).thenReturn("generated-id");
        mockMvc.perform(post("/api/v1/admin/roles").header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"tenant-org-a\",\"role_name\":\"Support\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.role_id").value("generated-id"));
        verify(adminRoleService).create(any(), argThat(r -> r.roleCode() == null));
        verifyNoInteractions(auditService);
    }

    @Test
    void listBindsIndependentFiltersAndBatchesTenantNames() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_READ));
        RolePO a = role("a", "TENANT", "tenant-org-a");
        RolePO b = role("b", "TENANT", "tenant-org-a");
        RolePO platform = role("p", "PLATFORM", "tenant-org-a");
        RolePO missing = role("m", "TENANT", "missing");
        RolePO blank = role("blank", "TENANT", " ");
        RolePO absent = role("null", "TENANT", null);
        when(adminRoleService.listByScope(any(), eq("PLATFORM"), eq("PLATFORM"),
                eq("TENANT,PLATFORM"), eq("tenant-org-a"), eq("Support")))
                .thenReturn(List.of(a, b, platform, missing, blank, absent));
        var tenant = new com.unify.iam.tenant.infra.persistence.po.TenantPO();
        tenant.setTenantId("tenant-org-a");
        tenant.setTenantName("Organization A");
        when(tenantRepository.findByIds(List.of("tenant-org-a", "missing"))).thenReturn(List.of(tenant));
        mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer t")
                        .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                        .param("filter_scope_type", "TENANT,PLATFORM")
                        .param("filter_scope_id", "tenant-org-a").param("keyword", "Support"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.count").value(6))
                .andExpect(jsonPath("$.data.roles[0].tenant_name").value("Organization A"))
                .andExpect(jsonPath("$.data.roles[1].tenant_name").value("Organization A"))
                .andExpect(jsonPath("$.data.roles[2].tenant_name").doesNotExist())
                .andExpect(jsonPath("$.data.roles[3].tenant_name").doesNotExist())
                .andExpect(jsonPath("$.data.roles[4].tenant_name").doesNotExist())
                .andExpect(jsonPath("$.data.roles[5].tenant_name").doesNotExist());
        verify(tenantRepository).findByIds(List.of("tenant-org-a", "missing"));
        verify(tenantRepository, org.mockito.Mockito.never()).findById(any());
    }

    @Test
    void tenantRowsWithOnlyMissingScopesDoNotTriggerLookupsOrCrash() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_READ));
        when(adminRoleService.listByScope(any(), eq("PLATFORM"), isNull(), isNull(), isNull(), isNull()))
                .thenReturn(List.of(role("null", "TENANT", null), role("blank", "TENANT", " ")));
        mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer t")
                        .param("scope_type", "PLATFORM"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.count").value(2))
                .andExpect(jsonPath("$.data.roles[0].tenant_name").doesNotExist())
                .andExpect(jsonPath("$.data.roles[1].tenant_name").doesNotExist());
        verifyNoInteractions(tenantRepository, tenantApplicationRepository, applicationRoleTemplateRepository);
    }

    private RolePO role(String id, String type, String scopeId) {
        RolePO role = new RolePO();
        role.setRoleId(id);
        role.setScopeType(type);
        role.setScopeId(scopeId);
        return role;
    }

    private JwtClaims claims(String... permissions) {
        long now = Instant.now().getEpochSecond();
        return new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1",
                "tenant-org-a", "ms-1", List.of("PlatformAdmin"), List.of(permissions), Map.of(),
                now + 3600, now, "jti", 0L);
    }

    @Test
    void roleWriterCanUpdateBasicInformation() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_WRITE));

        mockMvc.perform(put("/api/v1/admin/roles/r-1")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_name\":\" Support operator \",\"role_description\":\"Handles tickets\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.role_id").value("r-1"));

        verify(adminRoleService).update(any(), eq("r-1"), argThat(request ->
                " Support operator ".equals(request.roleName())
                        && "Handles tickets".equals(request.roleDescription())
                        && request.roleCode() == null));
    }

    @Test
    void roleUpdateWithoutTokenReturns401() throws Exception {
        mockMvc.perform(put("/api/v1/admin/roles/r-1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_name\":\"Support operator\"}"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false));

        verifyNoInteractions(adminRoleService);
    }

    @Test
    void roleUpdateRejectsRoleCodeBeforeService() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_WRITE));

        mockMvc.perform(put("/api/v1/admin/roles/r-1")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_code\":\"Renamed\",\"role_name\":\"Support operator\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("role_code cannot be updated"));

        verifyNoInteractions(adminRoleService);
    }

    @Test
    void roleUpdateRejectsBlankNameBeforeService() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_WRITE));

        mockMvc.perform(put("/api/v1/admin/roles/r-1")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_name\":\"   \",\"role_description\":\"x\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Request validation failed: role_name is required"));

        verifyNoInteractions(adminRoleService);
    }

    @Test
    void roleUpdateRequiresRoleWritePermission() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_READ));

        mockMvc.perform(put("/api/v1/admin/roles/r-1")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_name\":\"Support operator\"}"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.success").value(false));

        verifyNoInteractions(adminRoleService);
    }

    @Test
    void roleUpdateReturns404ForMissingRole() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_WRITE));
        doThrow(AuthException.notFound("Role not found")).when(adminRoleService)
                .update(any(), eq("missing"), any());

        mockMvc.perform(put("/api/v1/admin/roles/missing")
                        .header("Authorization", "Bearer t")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_name\":\"Support operator\"}"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Role not found"));
    }

    @Test
    void roleListExposesNumericPermissionCountsIncludingZero() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_READ));
        RolePO assigned = new RolePO();
        assigned.setRoleId("r-assigned");
        RolePO empty = new RolePO();
        empty.setRoleId("r-empty");
        List<RolePO> roles = List.of(assigned, empty);
        when(adminRoleService.listByScope(any(), eq("PLATFORM"), eq("PLATFORM"), isNull(), isNull(), isNull())).thenReturn(roles);
        when(adminRoleService.permissionCountsForRoles(roles)).thenReturn(Map.of("r-assigned", 2L));

        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                        .header("Authorization", "Bearer t"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(2))
                .andExpect(jsonPath("$.data.roles[0].permissionCounts").isNumber())
                .andExpect(jsonPath("$.data.roles[0].permissionCounts").value(2))
                .andExpect(jsonPath("$.data.roles[1].permissionCounts").isNumber())
                .andExpect(jsonPath("$.data.roles[1].permissionCounts").value(0));
        verify(adminRoleService).permissionCountsForRoles(roles);
    }

    @Test
    void roleListExposesDescriptionWhenPresent() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_ROLE_READ));
        RolePO role = new RolePO();
        role.setRoleId("r-1");
        role.setRoleCode("SupportOperator");
        role.setRoleName("Support operator");
        role.setRoleDescription("Handles tickets");
        role.setScopeType("TENANT");
        role.setScopeId("tenant-org-a");
        role.setRoleStatus("ACTIVE");
        when(adminRoleService.listByScope(any(), eq("TENANT"), eq("tenant-org-a"), isNull(), isNull(), isNull())).thenReturn(List.of(role));

        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT")
                        .param("scope_id", "tenant-org-a")
                        .header("Authorization", "Bearer t"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.roles[0].role_description").value("Handles tickets"));
    }
}

# Implementation plan

1. Load backend specs and approved review proposal. Remove only dedicated obsolete API code and its old tests; preserve generic role semantics.
2. Add endpoint removal regression and permission flag contract regression. Reuse existing tenant-list isolation and grant validation integration tests.
3. Repair the explicitly authorized iMorph-Admin role-write seed gap, test new provisioning and existing-role idempotency plus actual token own-tenant success/cross-tenant and PLATFORM denial/Member denial.
4. Run JDK 21 reactor tests for AdminRoleControllerTest, AdminRoleServiceTest, AdminRoleListIntegrationTest, removal/permission tests, and relevant P3 grant tests. MySQL tests require Docker.
5. Review all changed files through trellis-check; fix local issues and rerun affected checks.
6. Update backend spec and validation/session record. Run git diff --check and verify branch/status. Keep work uncommitted; do not invoke automatic commit/archive paths.

Approval: reviewed proposal approved by user before task creation. No additional routine confirmation is required.

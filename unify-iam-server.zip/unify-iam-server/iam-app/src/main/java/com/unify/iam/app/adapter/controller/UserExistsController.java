package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.UserExistsRequest;
import com.unify.iam.app.app.service.UserExistsService;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import jakarta.validation.Valid;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 邮箱存在性判定端点（G8，登录/注册两段式；docs/requirements/M10W4-W5 §G8）。
 *
 * <p>服务间端点（非用户 JWT）：登录页后端调 {@code POST /api/v1/auth/user-exists}，
 * {@code {email}} → {@code {exists, auth_mode}}（LOCAL→password / 仅 OIDC→sso）。
 * 鉴权同版本 feed：{@code X-IAM-Service-Token} 与 {@code iam.versions.service-token} 常量时间比较；
 * 未配置 → 403。响应已套统一信封（{@code data} 为业务体）。
 */
@RestController
@RequestMapping("/api/v1/auth")
public class UserExistsController {

    private final UserExistsService userExistsService;
    private final IamProperties props;

    public UserExistsController(UserExistsService userExistsService, IamProperties props) {
        this.userExistsService = userExistsService;
        this.props = props;
    }

    @PostMapping("/user-exists")
    public Map<String, Object> userExists(
            @RequestHeader(value = "X-IAM-Service-Token", required = false) String serviceToken,
            @Valid @RequestBody UserExistsRequest request) {
        String expected = props.getVersions().getServiceToken();
        if (expected == null || expected.isBlank()) {
            throw AuthException.forbidden("邮箱判定未启用：请配置 iam.versions.service-token");
        }
        if (serviceToken == null
                || !MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
                serviceToken.getBytes(StandardCharsets.UTF_8))) {
            throw AuthException.unauthorized("服务间令牌校验失败");
        }
        return userExistsService.check(request.email());
    }
}

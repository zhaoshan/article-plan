package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.RolePermissionMapper;
import com.unify.iam.authorization.infra.persistence.po.RolePermissionPO;
import com.unify.iam.common.util.IdGenerator;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Repository;

/**
 * 角色-权限点绑定仓储（管理面授权）。采用"补缺 + 回收"覆盖式替换，
 * 避免物理删除后同 pair 再插入撞唯一键（role_id, permission_id）。
 */
@Repository
public class RolePermissionRepository {

    private final RolePermissionMapper rolePermissionMapper;

    public RolePermissionRepository(RolePermissionMapper rolePermissionMapper) {
        this.rolePermissionMapper = rolePermissionMapper;
    }

    /** 覆盖式设置角色的权限点集合：期望命中则保留/补插，未命中且现有则逻辑删除。 */
    public void replaceForRole(String roleId, Collection<String> permissionIds) {
        String roleIdT = roleId.trim();
        List<RolePermissionPO> existing = rolePermissionMapper.selectList(
                new LambdaQueryWrapper<RolePermissionPO>().eq(RolePermissionPO::getRoleId, roleIdT));
        Set<String> existingPermIds = existing.stream()
                .map(RolePermissionPO::getPermissionId).collect(Collectors.toSet());
        Set<String> desired = permissionIds.stream().map(String::trim).collect(Collectors.toSet());
        for (String permissionId : desired) {
            if (existingPermIds.contains(permissionId)) {
                continue;
            }
            // 重授：软删后唯一键 (role_id, permission_id) 仍占位，先复活墓碑，无墓碑才新插
            if (rolePermissionMapper.revive(roleIdT, permissionId) == 0) {
                RolePermissionPO po = new RolePermissionPO();
                po.setRolePermissionId(IdGenerator.newBizId());
                po.setRoleId(roleIdT);
                po.setPermissionId(permissionId);
                try {
                    rolePermissionMapper.insert(po);
                } catch (DuplicateKeyException ignored) {
                    // 并发兜底
                }
            }
        }
        // 回收：逻辑删除必须走 deleteById/delete（@TableLogic 字段被 updateById 的 SET 剔除，
        // setDeleteFlag+updateById 是静默空操作——曾致撤权不生效，权限永远只增不减）
        for (RolePermissionPO po : existing) {
            if (!desired.contains(po.getPermissionId())) {
                rolePermissionMapper.deleteById(po.getId());
            }
        }
    }

    /** 某角色的当前权限点 id 集（管理台授权回显，docs/05 §7.3 ④）。 */
    public List<String> listPermissionIdsForRole(String roleId) {
        return rolePermissionMapper.selectList(
                        new LambdaQueryWrapper<RolePermissionPO>().eq(RolePermissionPO::getRoleId, roleId.trim()))
                .stream().map(RolePermissionPO::getPermissionId).toList();
    }
}

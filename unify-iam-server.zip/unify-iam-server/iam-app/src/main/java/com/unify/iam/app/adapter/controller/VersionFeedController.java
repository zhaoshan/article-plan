package com.unify.iam.app.adapter.controller;

import com.unify.iam.app.app.service.TokenVersionFeedService;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 版本 feed 端点（方案 c 即时吊销，docs/07 §8.3；parlant doc11 附录 B）。
 *
 * <p>服务间端点（非用户 JWT）：parlant 后台定时拉取成员令牌版本，配合 token 的 {@code ver} claim
 * 判断旧 token 是否已失效。鉴权：请求头 {@code X-IAM-Service-Token} 与配置
 * {@code iam.versions.service-token} 常量时间比较；未配置 → 403（端点禁用）。
 */
@RestController
@RequestMapping("/api/v1/auth/versions")
public class VersionFeedController {

    private final TokenVersionFeedService feedService;
    private final IamProperties props;

    public VersionFeedController(TokenVersionFeedService feedService, IamProperties props) {
        this.feedService = feedService;
        this.props = props;
    }

    @GetMapping
    public Map<String, Object> versions(
            @RequestHeader(value = "X-IAM-Service-Token", required = false) String serviceToken,
            @RequestParam(value = "app_code", required = false) String appCode,
            @RequestParam(value = "since", required = false) Long since,
            @RequestParam(value = "membership_id", required = false) String membershipId) {
        String expected = props.getVersions().getServiceToken();
        if (expected == null || expected.isBlank()) {
            throw AuthException.forbidden("版本 feed 未启用：请配置 iam.versions.service-token");
        }
        if (serviceToken == null
                || !MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
                serviceToken.getBytes(StandardCharsets.UTF_8))) {
            throw AuthException.unauthorized("版本 feed 鉴权失败");
        }
        // app_code 缺省回落到 JWT audience（parlant-agent-server）
        String app = (appCode == null || appCode.isBlank()) ? props.getJwt().getAudiences().stream().findFirst().orElse("") : appCode.trim();
        return feedService.feed(app, since, membershipId);
    }
}

# iMorph 多租户公共能力需求 → IAM 能力盘点与差距分析

> 来源需求：`docs/requirements/CommonCapabilities_M10W3.md`（iMorph M10W3 多租户公共能力 PRD，V0.1）。
> 定位：从业务系统视角的需求，盘点「依赖当前 IAM 实现的能力」哪些已具备、哪些缺失/需完善，作为 IAM 侧工作项清单。
> 结论一句话：**身份/租户/成员/角色/权限/审计的基础设施与「角色调整即时撤权」已具备；主要缺口集中在「租户/成员停用的即时失效与管理动作」「最后管理员保护」「被拒操作审计留痕」「业务系统查询租户状态接口」「租户配额/有效期」**。
> 日期：2026-10-19。

---

## 1. 需求 → IAM 能力映射

### 1.1 §4.1 账号、租户与资源归属

| 需求 | IAM 现状 | 判定 |
|---|---|---|
| 账号多租户（一个账号多个成员） | `gateway_user` + 多条 `gateway_membership`，多租户切换 `switch-tenant` | ✅ 已具备 |
| 个人/企业两类租户 | `gateway_tenant.tenant_type`（PERSONAL/ORGANIZATION），注册/邀请建个人租户、JIT 个人租户 | ✅ 已具备 |
| 稳定标识、名称可重复、标识独立 | `tenant_id`（唯一）+ `tenant_code`（唯一键）；名称不参与身份 | ✅ 已具备 |
| 租户启停状态 | `tenant_status`（ACTIVE/SUSPENDED/DELETED）；登录/切换已过滤停用租户 | ✅ 字段与过滤已具备，**停用后的即时撤权见 §2 G1** |
| 成员状态（已加入且未停用、未移除才可访问） | `gateway_membership.membership_status`（ACTIVE/PENDING/SUSPENDED/REMOVED）+ 登录/切换过滤；**SUSPENDED 无管理动作** | ⚠️ 字段在，**停用动作缺失（G2）** |
| 角色按租户生效、Admin/Member 固定角色 | IAM 角色=应用模板驱动（业务侧定义 Admin/Member 模板即可）；`TenantScopeGuard` 租户内生效 | ✅ 基础设施已具备 |
| 业务资源归属 | 资源是业务系统数据；IAM 提供 token 的 `tenantId/membershipId` 作归属依据 | ✅ IAM 提供上下文，归属校验属业务侧 |
| 最后管理员保护 | **无**（移除/停用/降权不检查剩余 Admin） | ❌ **缺失（G3）** |

### 1.2 §4.2 当前租户与数据隔离

| 需求 | IAM 现状 | 判定 |
|---|---|---|
| 登录有效→租户可用→成员有效→授权→归属 | token 含 tenantId/membershipId/roles/permissions；登录/切换校验租户与成员有效 | ✅ IAM 已提供校验链 |
| 列表/详情/批量/文件/缓存/后台任务隔离 | **业务系统职责**，用 IAM token 上下文实现 | ➖ 业务侧，IAM 提供依据 |
| 租户停用后阻断访问（含已登录会话） | 登录/切换已拒；**已登录 token 在 TTL 内仍有效（无状态、未 bump）** | ❌ **缺口（G1）** |
| 业务系统查询租户状态信息 | **无对业务系统的租户状态接口**（`/me` 只返回 token 上下文，不返回租户状态） | ❌ **缺口（G4，需求 4.4 明确点出）** |

### 1.3 §4.3 Admin/Member 与平台管理员

| 需求 | IAM 现状 | 判定 |
|---|---|---|
| 平台管理员 ≠ 租户 Admin，平台不默认读业务数据 | `iam:*` 平台专属（V8）、`TenantScopeGuard`、平台角色与租户角色分离 | ✅ 已具备 |
| 编辑不能改管理字段 | 角色/成员/租户状态都有独立管理 API，业务资源字段由业务侧管 | ✅ IAM 侧已具备 |
| 页面与接口同一规则、默认拒绝 | `@RequirePermission` + 管理面默认拒绝；前端按权限显隐 | ✅ 已具备 |
| **最后管理员保护** | **无** | ❌ **缺失（G3）** |

### 1.4 §4.4 权限变更即时生效

| 需求 | IAM 现状 | 判定 |
|---|---|---|
| 角色调整即时生效（降权/撤权） | 方案 c：`setRoles/setPermissions` bump `token_version` + 版本 feed + 业务侧 ver 校验 + 静默刷新 | ✅ 已具备 |
| 成员移除即时失效 | `remove` → tombstone（feed 下发） | ✅ 已具备 |
| **成员停用即时失效** | **SUSPENDED 无管理动作、无 bump** | ❌ **缺失（G2）** |
| **租户停用即时失效** | **停用不 bump 该租户成员版本** | ❌ **缺失（G1）** |
| 成员/租户恢复 | 按当前状态重新签发/校验；不恢复已删关系 | ✅ 已具备 |
| 排队任务执行前再校验 | 业务侧用 token `ver` + 版本 feed 实现（parlant doc11 附录 B 即为该机制） | ✅ IAM 已提供机制 |
| 校验暂时不可用时不放行 | 业务侧策略（feed/点查超时处理） | ➖ 业务侧 |

### 1.5 §4.5 关键操作审计

| 需求 | IAM 现状 | 判定 |
|---|---|---|
| 时间/操作者/租户/操作/对象/变更前后值/结果/失败原因/请求编号 | `gateway_audit_log` **schema 齐全**（actor/event/target/result_status(含 FAILED/DENIED)/request_id/ip/ua/before_json/after_json/metadata） | ✅ 表结构已具备 |
| 成功变更与被拒绝操作均可核验 | **当前主要写成功路径；被拒（DENIED）/失败（FAILED）留痕不完整** | ⚠️ **待补强（G5）** |
| 自动执行可追溯触发账号 | actor 字段记录 | ✅ |
| 不记录秘密 | 约定 + 实现均不落 token/密钥 | ✅ |

### 1.6 §4.6 存量迁移 / §6 后续版本

| 需求 | IAM 现状 | 判定 |
|---|---|---|
| 存量迁移（补建个人空间 + Admin + 资源承接） | 一次性运维：可用现有建租户/成员/角色 API 或 `scripts/` 幂等脚本；幂等（INSERT IGNORE）有约定 | ✅ 可支撑，需脚本化 |
| V0.2 新注册自动开通个人空间 | `RegisterService` 注册即建个人租户 + owner | ✅ 已具备 |
| V0.3 邀请/成员列表/角色调整/移除 | 邀请/审批/成员/角色管理 | ✅ 已具备 |
| V0.4 对接密钥/开放 API/调用限额 | **业务侧 API 网关职责**（IAM 提供 JWT 验签 + aud 白名单；service-token 机制已有雏形） | ➖ 业务侧为主 |
| V0.5 成员停用页面/租户资料/额度/有效期/日志查询 | 成员停用（G2）；**租户额度/有效期字段缺失（G6）**；审计数据在，可建日志查询页 | ❌/✅ 混合 |

---

## 2. IAM 能力缺口清单（按优先级）

### G1 【P0·安全】租户停用时已登录 token 未即时失效
- **现状**：`AdminTenantService.update`（tenant_status→SUSPENDED/DISABLED）与 `delete` 均不 bump 该租户成员的 `token_version`，不记 tombstone——已登录 token 在 TTL（1800s）内仍可访问业务。
- **需求**：§4.4「租户停用→所有成员业务访问被阻断」即时生效。
- **✅ 已实施（2026-10-19）**：`TokenVersionService.bumpForTenant(tenantId, changeType)`；`AdminTenantService.update`（转非 ACTIVE）与 `delete` 均调用。
- **涉及**：`AdminTenantService` + `TokenVersionService` + 版本 feed。

### G2 【P0】成员「停用（SUSPENDED）」管理动作缺失
- **现状**：`gateway_membership.membership_status` 有 SUSPENDED，但**无任何停用动作/接口**（`AdminMemberService` 只有 remove=逻辑删除）。需求要「停用≠移除：停用后恢复按原角色，移除不恢复」。
- **✅ 已实施（2026-10-19）**：`AdminMemberService.suspend/restore` + `POST /admin/members/{id}/suspend|restore`；停用 bump（MEMBER_SUSPENDED），恢复不 bump；switch-tenant/登录本就滤 SUSPENDED。
- **涉及**：`AdminMemberController/Service` + `TokenVersionService`。

### G3 【P0·安全】最后管理员保护缺失
- **现状**：移除成员/停用/降权不检查「该租户是否还剩有效 Admin」——可把最后一名 Admin 移除/降权，租户失去管理入口。
- **需求**：§4.3「每个租户至少保留一名有效 Admin，不能通过移除、停用、降权或并发操作破坏」。
- **✅ 已实施（2026-10-19，方式 B）**：判定升级为并集——① 每个业务系统的 **is_owner（租户Admin）角色**必须保留 ≥1 持有者（按 role_code 匹配 `iam_application_role_template.is_owner`，跨应用撞名已被 `loadForApps` 校验阻止；`ApplicationRoleTemplateRepository.listIsOwnerRoleCodes`）+ ② 兜底：IAM 租户管理能力（`iam:member/role:write`）不能归零。`AdminMemberService.assertKeepsAdmin` 在 `remove/suspend/setRoles` 拦截，触底 400「至少保留一名有效租户管理员」；`AdminProtectionIntegrationTest` 覆盖 G1/G2/G3（含 is_owner 唯一持有者用例）。
- **涉及**：`AdminMemberService` + 租户角色计数查询。

### G4 【P1】业务系统查询租户/成员状态接口
- **现状**：业务系统只能拿 token 上下文（`/me`），**无法权威查询租户是否停用、成员是否有效**；且租户停用后旧 token 仍过 `/me`。
- **需求**：§4.4「考虑提供接口，业务系统查询租户状态信息」。
- **✅ 已实施（2026-10-20）**：① 前端/登录态：`GET /api/v1/auth/session-status`（Bearer）+ `GET /api/v1/auth/tenant-status?tenant_id=`（Bearer，限调用者成员关系防枚举）；② **服务间（后台任务）**：`POST /api/v1/auth/status-check`（`X-IAM-Service-Token`，按任务提交时存的 tenant_id+membership_id 权威校验 valid）——iMorph 默认任务执行前据此判断租户/成员是否停用；`SessionStatusController`；`AdminProtectionIntegrationTest` 覆盖。
- **涉及**：新增 controller 端点（复用 `TenantRepository`）。

### G5 【P0/P1】关键操作审计：字段完整性 + 覆盖补全 + 被拒留痕 + 去重

> 对照 §4.5：每条记录需含 **时间 / 操作者 / 租户 / 操作 / 对象 / 必要字段变更前后值 / 结果及失败原因 / 请求编号**；成功与被拒的关键管理操作均可核验；重复提交不得误记为多次成功；自动执行可追溯触发账号。

- **G5-a 字段完整性** ✅ **已实施（2026-10-20）**：`AuditService` 增加 `tenant/before/after` 并自动填 `request_id`/`ip`/`user_agent`/`actor_membership_id`；新增 `RequestIdFilter`（生成/透传 `X-Request-Id`，MDC + request attribute + 响应头，入站值白名单清洗）+ `RequestMeta`。
- **G5-b 覆盖补全** ✅ **已实施（2026-10-20）**：新增审计——`ADMIN_UPDATE_TENANT`/`ADMIN_DELETE_TENANT`（含 before/after 状态）、`ADMIN_SET_MEMBER_ROLES`（前后角色集）、`ADMIN_SUSPEND_MEMBER`/`ADMIN_RESTORE_MEMBER`（前后状态）、`ADMIN_DELETE_ROLE`（含租户）、`ADMIN_UPDATE_USER`、`ADMIN_UPDATE/DELETE_GROUP_MAPPING`、`ADMIN_REJECT_JOIN`；`AuditCompletenessIntegrationTest` 覆盖字段与写点。
- **G5-c 被拒/失败留痕（P1）**：全仓库 **0 处** `DENIED/FAILED` 写点；401/403/400 被拒操作不留痕。
  → 管理面拦截器写 `DENIED`、service 层写 `FAILED`（含失败原因）。
- **G5-d 去重与系统执行追溯（P2）**：无幂等键/去重（重复提交可能多次记成功）；JIT/IdP 同步等自动执行无 `actor=system` 追溯。
- **已在范围外/已满足**：不记录密码/密钥/凭证（现写点只写 id）；审计仅 GET、无删改入口；V0.5 日志页面明确延后；存量迁移批次由脚本保证。

### G6 【P2·V0.5】租户配额/有效期字段缺失
- **现状**：`gateway_tenant` 无 quota/expiry 字段（仅有 `billing_plan_code`/`settings_json` 可承载）。
- **需求**：§6 V0.5「额度与有效期调整」。
- **建议**：后续加 `quota_json`/`expires_at` 字段 + 管理 API（V0.5 再做）；可用 `settings_json` 先行。

---

## 3. 业务系统侧职责（非 IAM 缺口，标注供对齐）

| 需求 | 承担方 |
|---|---|
| 资源归属、父子关联、数据隔离（列表/详情/批量/文件/缓存/后台任务） | 业务系统用 IAM token（tenantId/membershipId）实现 |
| 批量请求任一对象无权限整拒、无权限资源与不存在同提示 | 业务系统 |
| 排队任务执行前再校验、流式输出撤权后停止 | 业务系统（用 IAM 版本 feed `ver`，机制已备） |
| 存量数据迁移（批次/幂等/回滚） | 一次性脚本/工具，复用 IAM 现有 API |
| 对接密钥/开放 API/调用限额（V0.4） | 业务侧 API 网关为主（IAM 提供验签/aud 白名单/service-token 雏形） |

---

## 4. 相关代码/文档

- IAM 即时撤权：`TokenVersionService` / `MembershipVersionLogRepository` / `VersionFeedController`（方案 c，parlant doc11 附录 B）
- 成员/租户管理：`AdminMemberService` / `AdminTenantService`
- 审计：`gateway_audit_log`（V5）+ `AuditService`；字段已含 before/after/FAILED/DENIED/request_id
- 租户状态过滤：`MembershipResolver`（登录/切换已滤停用租户）
- 业务侧接入参考：`docs/user-manual/03`（§6 权限变更即时生效）、`docs/user-manual/04`（业务逻辑）

package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.admin.CreateDomainRequest;
import com.unify.iam.app.infra.persistence.po.TenantDomainChallengePO;
import com.unify.iam.app.infra.persistence.po.TenantDomainPO;
import com.unify.iam.app.infra.persistence.repository.TenantDomainChallengeRepository;
import com.unify.iam.app.infra.persistence.repository.TenantDomainRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.SecureToken;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.time.LocalDateTime;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 域名验证（docs/04 §3.5）：企业租户域名 + 验证挑战；dev 自动验证（生产校验 DNS TXT / HTTP 文件）。
 */
@Service
public class DomainVerificationService {

    private final TenantDomainRepository domainRepository;
    private final TenantDomainChallengeRepository challengeRepository;
    private final TenantRepository tenantRepository;

    public DomainVerificationService(TenantDomainRepository domainRepository,
                                     TenantDomainChallengeRepository challengeRepository,
                                     TenantRepository tenantRepository) {
        this.domainRepository = domainRepository;
        this.challengeRepository = challengeRepository;
        this.tenantRepository = tenantRepository;
    }

    /** 为租户登记域名并生成验证挑战，返回 challenge_token（DNS TXT 值 / HTTP 文件内容）。 */
    @Transactional
    public Map<String, String> createDomain(String tenantId, CreateDomainRequest request) {
        tenantRepository.findById(tenantId.trim())
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        String domainId = IdGenerator.newBizId();
        TenantDomainPO d = new TenantDomainPO();
        d.setTenantDomainId(domainId);
        d.setTenantId(tenantId.trim());
        d.setDomain(request.domain().trim().toLowerCase());
        d.setDomainType("COMPANY");
        d.setVerificationStatus("PENDING");
        d.setJoinPolicy("REQUEST");
        d.setIsPrimary(0);
        domainRepository.insert(d);

        String challengeType = request.challengeType() == null ? "DNS_TXT" : request.challengeType();
        String token = SecureToken.random();
        TenantDomainChallengePO c = new TenantDomainChallengePO();
        c.setTenantDomainChallengeId(IdGenerator.newBizId());
        c.setTenantDomainId(domainId);
        c.setChallengeType(challengeType);
        c.setChallengeStatus("PENDING");
        c.setChallengeToken(token);
        c.setExpiresAt(LocalDateTime.now().plusHours(24));
        challengeRepository.insert(c);
        return Map.of("tenant_domain_id", domainId, "challenge_type", challengeType, "challenge_token", token);
    }

    /** 校验通过：dev 自动验证（生产应校验 DNS/HTTP 挑战后调用）。 */
    @Transactional
    public Map<String, String> verify(String tenantDomainId) {
        TenantDomainPO d = domainRepository.findById(tenantDomainId)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.DOMAIN_NOT_FOUND));
        d.setVerificationStatus("VERIFIED");
        d.setVerifiedAt(LocalDateTime.now());
        d.setIsPrimary(1);
        domainRepository.update(d);
        challengeRepository.findPendingByDomain(tenantDomainId).ifPresent(c -> {
            c.setChallengeStatus("VERIFIED");
            c.setVerifiedAt(LocalDateTime.now());
            challengeRepository.update(c);
        });
        // 租户无主域名则回填
        tenantRepository.findById(d.getTenantId()).ifPresent(t -> {
            if (t.getPrimaryDomain() == null) {
                t.setPrimaryDomain(d.getDomain());
                tenantRepository.update(t);
            }
        });
        return Map.of("status", "VERIFIED", "domain", d.getDomain());
    }
}

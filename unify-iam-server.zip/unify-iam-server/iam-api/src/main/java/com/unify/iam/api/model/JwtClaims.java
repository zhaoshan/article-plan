package com.unify.iam.api.model;

import java.util.List;
import java.util.Map;

/**
 * JWT claims 契约模型（E2E-1 范围文档 §4.1）：签发与验签共用。
 *
 * <p>序列化为 JWT payload 时字段名保持 camelCase（{@code tenantId}/{@code membershipId}），
 * 与 parlant {@code claims_to_context} 读取一致。{@code sub} 即 userId。
 */
public record JwtClaims(
        String iss,
        List<String> aud,
        String sub,
        String tenantId,
        String membershipId,
        List<String> roles,
        List<String> permissions,
        Map<String, List<String>> attrs,
        long exp,
        long iat,
        String jti,
        long ver) {

    /** 便捷访问：sub 即 userId */
    public String userId() {
        return sub;
    }
}

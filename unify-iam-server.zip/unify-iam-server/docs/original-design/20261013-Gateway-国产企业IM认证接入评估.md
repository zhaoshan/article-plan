# 20261013-Gateway-国产企业IM（飞书 / 企业微信 / 钉钉）认证与权限接入评估

> 状态：**评估完成，待决策**（2026-10-13）。
> 定位：评估将 飞书（Feishu/Lark）、企业微信（WeCom）、钉钉（DingTalk）作为企业身份源接入当前 IAM 的**可行性、协议适配、Gap 与落地路径**，供后续实施决策。
> 评估方法：Brave Search 检索官方文档与行业实践（观测云飞书OIDC、钉钉开放平台 OAuth2、企微开发者中心、IDaaS Book 等，见 §8 来源）+ 既有架构（docs/01-07、CLAUDE.md 认证可插拔约定）。
> 关联：CLAUDE.md「新增登录方式只换认证器」；docs/03（SSO/JIT/组映射）；docs/07（P3.5 SSO 配置）；docs/04（平台级 IdP）。

---

## 0. 结论速览

- **可行性：中等偏高**。飞书可**基本按标准 OIDC 直连**（Discovery/标准 claims）；钉钉为**标准 OAuth2 + `openid` scope**（小适配）；企业微信为**自有 OAuth2 变体**（需自定义 adapter，工作量最大）。
- **最大的坑不是认证协议，而是两个决策点**：① 稳定身份主键（三家无统一 email → 用 `union_id/UnionId/unionId` 作 subject？）；② 部门→组→角色的组织映射策略（登录时组映射 vs 组织架构定期同步）。
- **落地方式二选一**：自建 connector（贴合当前「认证器可插拔」，轻量）或前置 **Keycloak Identity Broker**（行业标准做法，统一暴露 OIDC，但多一个组件）。
- **权限模型边界**：平台 scope/权限 =「谁有权调平台 API / 读通讯录」，与 IAM 业务 RBAC 权限点**语义不同、不冲突**——平台负责"验证你是谁 + 你在哪个部门"，IAM 负责"你能做什么"。

---

## 1. 三平台认证协议速览（对照当前 IAM 的 OIDC Provider 模型）

| 维度 | **飞书** | **企业微信** | **钉钉** | **当前 IAM（OIDC）** |
|---|---|---|---|---|
| 协议 | **接近标准 OIDC**（有 Discovery Endpoint、标准 claims；观测云以 client_secret_post 接入） | **自有 OAuth2 网页授权**（`open.weixin.qq.com/connect/oauth2/authorize` → code → `qyapi.../getuserinfo` 取 UserId），无标准 OIDC | **标准 OAuth2 授权码**（`login.dingtalk.com/oauth2/auth?scope=openid`，RFC 6749），近 OIDC | 标准 OIDC（issuer/.well-known/jwks/id_token 验签） |
| 身份主键 | `user_id`（租户内）/ `open_id`（应用维度）/ `union_id`（企业统一，跨应用稳定） | `UserId`（企业内）/ `OpenId` / `UnionId` | `userId`（企业内）/ `unionId`（跨应用）/ `openId` | `sub` + email 匹配（JIT 按邮箱） |
| 邮箱 | 需通讯录权限，非必有；有 `batch_get_id`（邮箱/手机→用户ID） | 无邮箱字段（需额外绑定） | 无邮箱字段 | JIT 依赖 email |
| 部门/组 | 通讯录层级树（`contact:*` 权限） | `department`（partyid），通讯录权限 | 通讯录层级树 | `groups` claim → `gateway_idp_group_mapping` |
| token/信任 | `user_access_token`/`tenant_access_token`；拉取 userinfo | `access_token`（**需可信 IP 白名单**）；拉取 userinfo | `appKey`/`appSecret` 换 token；拉取 userinfo | RS256 JWT + **本地 JWKS 验签** |
| 权限模型 | 应用/通讯录权限 | 应用可见范围 + 基础接口权限 | 权限点（Contact.User.* 等） | IAM 业务权限点（RBAC） |

**共同点**：部门是**层级树**而非标准 `groups` claim；身份标识各不相同、**不保证 email**；平台"权限"是 API/通讯录权限而非业务权限点；信任模型是"换 token 拉 userinfo"（非本地验签）。

---

## 2. 分平台协议适配评估

| 平台 | 适配难度 | 主要工作 | 备注 |
|---|---|---|---|
| **飞书** | 低（近 OIDC） | claim 映射（sub 用 `union_id` 或 `user_id`）+ 部门经通讯录 API 拉取 | 若 Discovery 可用，可复用现有 OIDC 管线大半 |
| **钉钉** | 中（标准 OAuth2+openid） | token/userinfo 适配 + `userId/unionId` 映射 + 部门拉取 | 新版 OAuth2 有 `openid` scope，社区实现已验证 |
| **企业微信** | 高（自有协议） | 自定义 adapter：authorize（corpid）→ code → `gettoken`(corpid+corpsecret) → `getuserinfo` 取 UserId → 部门 | 运维前置最多：可信域名 + access_token 可信 IP 白名单 |

---

## 3. 与当前 IAM 体系的映射（复用点，不重构）

| 当前能力 | 复用方式 |
|---|---|
| **认证管线不动**（`TokenService.issueFor` / RBAC / JWT 签发） | CLAUDE.md 明言「新增登录方式只换认证器」——connector 只负责产出 VerifiedClaims(email/sub/groups) |
| **组映射** `gateway_idp_group_mapping`（IDP_SYNC） | 把平台部门拉取后转成**虚拟 group** 喂给现有映射，机制原样工作 |
| **JIT** find-or-create 身份/成员 | 身份主键策略定好后原样复用（见 §5 G2） |
| **租户绑定** `gateway_tenant_idp_config.tenant_id` | 天然成立——"登录这个 IdP 就进这个租户" |
| **SSO 配置页 / 审计 / 作用域校验** | 配置模型按协议分支；其余不动 |

---

## 4. Gap 清单（分级）

| # | Gap | 说明 | 级别 |
|---|---|---|---|
| **G1 协议** | 非全部标准 OIDC | 飞书≈OIDC、钉钉≈标准 OAuth2、企微需自定义 adapter；信任模型从"JWKS 验签"变"拉取 userinfo"需文档化 | 中-大（架构扩展点） |
| **G2 身份主键** | 三家无统一 email | JIT 现按 email 匹配；建议用 **unionId 作 subject** + 平台标识；飞书 `batch_get_id` 可反查邮箱缓解；缺 email 时 JIT 需降级策略 | **大（先定）** |
| **G3 部门→组** | 部门是层级树非 group claim | 登录时：connector 拉部门转虚拟 group；**组织架构定期同步（部门→组→角色）**是行业做法，可归 P4 | 中 |
| **G4 配置模型/前端** | 平台字段不同 | 钉钉 appKey/appSecret（+agentId）、企微 corpid/corpsecret/agentid、飞书 app_id/app_secret + 可信域名/IP | 中 |
| **G5 运维前置** | 企微可信域名 + **access_token 可信 IP 白名单** | 反向代理出口需固定 IP；钉钉回调/免登域名 | 中（部署约束） |
| **G6 测试** | 现有 `MockOidcProvider` 只适用标准 OIDC | 飞书/钉钉可扩；企微需 Mock adapter | 中 |
| **G7 权限错位** | 平台 scope=API 权限 vs IAM 业务权限点 | 边界写清：平台只验证身份/部门，IAM 授业务权限 | 低（清晰即可） |
| **G8 token 时效** | 平台 token 与 IAM JWT 两套时效 | 涉及「角色变更重新校验」待办（docs/07 §8.3） | 低-中 |

---

## 5. 决策点（实施前必定）

1. **身份主键策略**：`union_id/UnionId/unionId`（跨应用稳定）作 `gateway_user_identity.subject`；是否要求邮箱绑定（平台管理员在企业目录补邮箱）？跨平台同人如何归并（unionId 不同平台是不同值 → 靠绑定/手动归并）？
2. **部门→虚拟 group 命名/层级策略**：部门名 or 部门路径？父部门是否包含子部门成员（展平策略）？
3. **缺 email 时的 JIT 降级**：无 email → 无法按邮箱匹配已有用户 → 是"每平台各建一个 IAM 用户（按 unionId）"还是"要求绑定邮箱后合并"？
4. **组织映射粒度**：登录时拉部门（轻量） vs 组织架构定期同步（部门→组→角色，行业做法，归 P4）——先做哪种？

---

## 6. 建议落地路径

1. **架构先抽象**：`OidcProviderConfig` → `IdentityProvider` 接口（OIDC / Feishu / DingTalk / WeCom 实现）；`gateway_tenant_idp_config.protocol` 扩展；SSO 配置页按协议渲染字段。
2. **分平台逐个落地 connector**：建议顺序 **飞书（近 OIDC，最快）→ 钉钉（标准 OAuth2）→ 企业微信（自定义 adapter + 可信域名/IP）**。
3. **备选：前置 Keycloak Identity Broker**——把三家统一成 OIDC 暴露给 IAM（行业标准做法），代价是生产多一个组件；**自建 connector 更贴合当前轻量 IAM**，二选一。
4. **组织同步（可选，P4）**：部门树定期同步 → 虚拟组 → 角色（对齐竹云/PingCode/TOPIAM 等行业 IDaaS 做法）。
5. **测试**：各平台 Mock connector 集成测试（对齐现有 `MockOidcProvider` 模式）。
6. **安全**：信任模型变化（拉取 vs 验签）写入安全约束；token 新鲜度沿用 docs/07 §8.3 待办。

---

## 7. 参考来源

- IDaaS Book — [Keycloak 集成企业微信 / 飞书 / 钉钉（Identity Broker / OIDC）](https://idaas.xlabs.club/docs/solution-blogs/keycloak-wecom-feishu-dingtalk/)
- 观测云 — [飞书 SSO（OIDC）集成最佳实践（client_secret_post）](https://www.guance.com/learn/articles/guance-feishu-oidc)
- 钉钉开放平台 — [OAuth2.0 鉴权](https://open.dingtalk.com/document/connection/oauth2-0-authentication)；[浏览器内获取用户委托访问凭证（RFC 6749 授权码）](https://open-dingtalk.github.io/developerpedia/docs/develop/permission/token/browser/get_user_app_token_browser/)；[通过免登码获取用户 userId](https://open.dingtalk.com/document/orgapp-server/obtain-the-userid-of-a-user-by-using-the-log-free)
- 企业微信开发者中心 — [构造网页授权链接](https://developer.work.weixin.qq.com/document/path/91022)（corpid→code→UserId）
- 飞书开放平台 — [用户身份体系（User/Open/Union ID）](https://open.feishu.cn/document/platform-overveiw/basic-concepts/user-identity-introduction/open-id)；[通过手机号或邮箱获取用户 ID（batch_get_id）](https://open.feishu.cn/document/server-docs/contact-v3/user/batch_get_id)
- 组织架构同步参考：竹云 IDaaS（[钉钉/企微/飞书身份数据同步](https://www.bccastle.com/scene/dingding-workweixin-feishu-user-provisioning)）、PingCode 目录服务、TOPIAM（[身份源：企业微信/钉钉/飞书](https://topiam.cn/docs/overview/terminology/)）

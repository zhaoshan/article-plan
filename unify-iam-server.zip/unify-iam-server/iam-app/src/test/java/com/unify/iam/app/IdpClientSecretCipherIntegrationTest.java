package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.app.security.IdpSecretCipher;
import com.unify.iam.common.util.JsonUtils;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

/**
 * P1-06 IdP client_secret 加密存储集成测试：
 * ① 管理端 create/update 写入密文（DB 非明文、可解密还原）；
 * ② 查询响应只回 has_secret、不回显任何形态的秘密；
 * ③ 存量明文行 decrypt 宽容回落（保存即迁移）。
 */
class IdpClientSecretCipherIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private IdpSecretCipher cipher;

    private String sfx() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    private String adminToken() throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("access_token").toString();
    }

    private Map<String, Object> idpBody(String secret) {
        String sfx = sfx();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("tenant_id", "tenant-org-a");
        m.put("provider_key", "keycloak");
        m.put("display_name", "Cipher Test " + sfx);
        m.put("issuer", "http://localhost:8099/realms/cipher-" + sfx);
        m.put("authorization_endpoint", "http://localhost:8099/realms/cipher-" + sfx + "/auth");
        m.put("token_endpoint", "http://localhost:8099/realms/cipher-" + sfx + "/token");
        m.put("jwk_set_uri", "http://localhost:8099/realms/cipher-" + sfx + "/certs");
        m.put("client_id", "iam");
        m.put("client_secret", secret);
        m.put("scopes", java.util.List.of("openid", "email"));
        m.put("jit_provisioning_enabled", true);
        return m;
    }

    private String dbCipher(String configId) {
        return jdbcTemplate.queryForObject(
                "SELECT client_secret_cipher FROM gateway_tenant_idp_config WHERE tenant_idp_config_id=?",
                String.class, configId.trim());
    }

    @Test
    void clientSecretStoredEncryptedAndResponseMasked() throws Exception {
        String admin = adminToken();
        String secret = "Cipher-Secret-123!";
        // create 响应只回 idp_config_id；has_secret 经列表断言
        String body = mockMvc.perform(post("/api/v1/admin/idp-configs")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(idpBody(secret))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(body).doesNotContain(secret).doesNotContain("client_secret");
        String configId = unwrapData(body).get("idp_config_id").toString();

        // 查询响应只回 has_secret、不回显任何形态的秘密
        String listBody = mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .get("/api/v1/admin/idp-configs").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.idp_configs[?(@.idp_config_id == '" + configId + "')].has_secret")
                        .value(org.hamcrest.Matchers.hasItem(true)))
                .andReturn().getResponse().getContentAsString();
        assertThat(listBody).doesNotContain(secret);

        // 落库为密文：非明文且可解密还原
        String stored = dbCipher(configId);
        assertThat(stored).isNotEqualTo(secret);
        assertThat(cipher.decrypt(stored)).isEqualTo(secret);

        // update 换密 → 新密文
        String secret2 = "Cipher-Secret-456!";
        mockMvc.perform(put("/api/v1/admin/idp-configs/" + configId)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(idpBody(secret2))))
                .andExpect(status().isOk());
        String stored2 = dbCipher(configId);
        assertThat(stored2).isNotEqualTo(secret2).isNotEqualTo(stored);
        assertThat(cipher.decrypt(stored2)).isEqualTo(secret2);
    }

    @Test
    void legacyPlaintextRowDecryptsWithGracefulFallback() throws Exception {
        String admin = adminToken();
        String secret = "Legacy-Plain-789!";
        String configId = unwrapData(mockMvc.perform(post("/api/v1/admin/idp-configs")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(idpBody(secret))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("idp_config_id").toString();

        // 模拟存量明文行（2026-11-11 前的历史数据）
        jdbcTemplate.update("UPDATE gateway_tenant_idp_config SET client_secret_cipher=? "
                + "WHERE tenant_idp_config_id=?", secret, configId.trim());
        assertThat(dbCipher(configId)).isEqualTo(secret);
        // 读取宽容：按明文回落（下次 update 经 encrypt 自动迁移）
        assertThat(cipher.decrypt(dbCipher(configId))).isEqualTo(secret);
    }
}

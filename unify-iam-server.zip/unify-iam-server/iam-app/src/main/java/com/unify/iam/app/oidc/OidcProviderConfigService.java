package com.unify.iam.app.oidc;

import com.fasterxml.jackson.core.type.TypeReference;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.identity.infra.persistence.po.IdpConfigPO;
import com.unify.iam.identity.infra.persistence.repository.IdpConfigRepository;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/**
 * 加载并解析租户 IdP 配置（gateway_tenant_idp_config）为 {@link OidcProviderConfig}。
 */
@Service
public class OidcProviderConfigService {

    private static final List<String> DEFAULT_SCOPES = List.of("openid", "email", "profile");
    private static final Map<String, String> DEFAULT_CLAIM_MAPPING = Map.of(
            "email", "email", "name", "name", "sub", "sub", "groups", "groups");

    private final IdpConfigRepository idpConfigRepository;

    public OidcProviderConfigService(IdpConfigRepository idpConfigRepository) {
        this.idpConfigRepository = idpConfigRepository;
    }

    /** 按租户查 ACTIVE OIDC 配置（企业 SSO；平台级 consumer 用 tenantId=PLATFORM）。 */
    public OidcProviderConfig loadByTenant(String tenantId) {
        IdpConfigPO po = idpConfigRepository.findActiveOidcByTenant(tenantId)
                .orElseThrow(() -> AuthException.notFound("未找到租户 [" + tenantId + "] 的 OIDC IdP 配置"));
        return toConfig(po);
    }

    /** 按配置 ID 查（回调阶段）。 */
    public OidcProviderConfig loadById(String configId) {
        IdpConfigPO po = idpConfigRepository.findActiveById(configId)
                .orElseThrow(() -> AuthException.notFound("未找到 IdP 配置"));
        return toConfig(po);
    }

    private OidcProviderConfig toConfig(IdpConfigPO po) {
        List<String> scopes = parseJsonList(po.getScopesJson(), DEFAULT_SCOPES);
        Map<String, String> claimMapping = parseJsonMap(po.getClaimMappingJson());
        if (claimMapping.isEmpty()) {
            claimMapping = new LinkedHashMap<>(DEFAULT_CLAIM_MAPPING);
        }
        List<String> allowedDomains = parseJsonList(po.getAllowedDomainsJson(), List.of());
        return new OidcProviderConfig(
                po.getTenantIdpConfigId(),
                po.getTenantId(),
                po.getProviderKey(),
                po.getIssuer(),
                po.getAuthorizationEndpoint(),
                po.getTokenEndpoint(),
                po.getJwkSetUri(),
                po.getClientId(),
                po.getClientSecretCipher(),
                scopes,
                claimMapping,
                allowedDomains,
                po.getPkceRequired() == null || po.getPkceRequired() == 1,
                po.getEmailVerifiedRequired() != null && po.getEmailVerifiedRequired() == 1,
                po.getJitProvisioningEnabled() == null || po.getJitProvisioningEnabled() == 1,
                po.getDefaultJoinPolicy() != null ? po.getDefaultJoinPolicy() : "INVITE_ONLY");
    }

    private List<String> parseJsonList(String json, List<String> fallback) {
        if (json == null || json.isBlank()) {
            return fallback;
        }
        try {
            return JsonUtils.fromJson(json, new TypeReference<List<String>>() {
            });
        } catch (Exception e) {
            return fallback;
        }
    }

    private Map<String, String> parseJsonMap(String json) {
        if (json == null || json.isBlank()) {
            return new LinkedHashMap<>();
        }
        try {
            return JsonUtils.fromJson(json, new TypeReference<Map<String, String>>() {
            });
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }
}
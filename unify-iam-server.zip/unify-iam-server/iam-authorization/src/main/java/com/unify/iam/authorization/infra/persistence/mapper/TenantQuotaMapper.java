package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.TenantQuotaPO;

/** G1 租户配额覆盖 Mapper。 */
public interface TenantQuotaMapper extends BaseMapper<TenantQuotaPO> {
}

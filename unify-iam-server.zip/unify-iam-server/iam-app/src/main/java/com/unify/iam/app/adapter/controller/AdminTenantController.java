package com.unify.iam.app.adapter.controller;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.ChangeTenantOwnerRequest;
import com.unify.iam.api.dto.admin.CreateTenantRequest;
import com.unify.iam.api.dto.admin.SetQuotaRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.QuotaService;
import com.unify.iam.api.dto.admin.TenantDetailResponse;
import com.unify.iam.api.dto.admin.TenantOwnerActionResponse;
import com.unify.iam.api.dto.admin.TenantApplicationSummary;
import com.unify.iam.api.dto.admin.TenantUsageDimension;
import com.unify.iam.api.dto.admin.UpdateTenantQuotaRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.TenantQuotaService;
import com.unify.iam.app.app.service.admin.AdminTenantService;
import com.unify.iam.app.app.service.admin.EnterpriseTenantOwnerInvitationService;
import com.unify.iam.app.app.service.admin.OwnerTransferInvitationService;
import com.unify.iam.app.app.service.admin.TenantDetailService;
import com.unify.iam.app.app.service.admin.TenantOwnershipService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.po.TenantApplicationPO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：租户 CRUD（iam:tenant:*）+ 租户已开通应用（iam:role:read，角色配置用）。 */
@RestController
@RequestMapping("/api/v1/admin/tenants")
public class AdminTenantController {

    private final TenantRepository tenantRepository;
    private final AdminTenantService adminTenantService;
    private final AuditService auditService;
    private final TenantScopeGuard tenantScopeGuard;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final ApplicationRepository applicationRepository;
    private final QuotaService quotaService;
    private final TenantDetailService tenantDetailService;
    private final TenantQuotaService tenantQuotaService;
    private final TenantOwnershipService tenantOwnershipService;
    private final OwnerTransferInvitationService ownerTransferInvitationService;
    private final EnterpriseTenantOwnerInvitationService enterpriseTenantOwnerInvitationService;

    public AdminTenantController(TenantRepository tenantRepository,
                                 AdminTenantService adminTenantService,
                                 AuditService auditService,
                                 TenantScopeGuard tenantScopeGuard,
                                 TenantApplicationRepository tenantApplicationRepository,
                                 ApplicationRepository applicationRepository,
                                 QuotaService quotaService,
                                 TenantDetailService tenantDetailService,
                                 TenantQuotaService tenantQuotaService,
                                 TenantOwnershipService tenantOwnershipService,
                                 OwnerTransferInvitationService ownerTransferInvitationService,
                                 EnterpriseTenantOwnerInvitationService enterpriseTenantOwnerInvitationService) {
        this.tenantRepository = tenantRepository;
        this.adminTenantService = adminTenantService;
        this.auditService = auditService;
        this.tenantScopeGuard = tenantScopeGuard;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.applicationRepository = applicationRepository;
        this.quotaService = quotaService;
        this.tenantDetailService = tenantDetailService;
        this.tenantQuotaService = tenantQuotaService;
        this.tenantOwnershipService = tenantOwnershipService;
        this.ownerTransferInvitationService = ownerTransferInvitationService;
        this.enterpriseTenantOwnerInvitationService = enterpriseTenantOwnerInvitationService;

    }

    /** G1 Usage 视图（A-03 抽屉/成员管理配额条）：全局 iam 维度 + 租户已启用应用维度。 */
    @GetMapping("/{tenantId}/usage")
    @RequirePermission(PermissionCodes.IAM_APPS_READ)
    public Map<String, Object> usage(@PathVariable String tenantId) {
        return quotaService.usage(CurrentAuth.claims(), tenantId);
    }

    /** G1 租户调额（limit_value 缺省/null → 清除覆盖回落模板默认）。写操作仅平台管理员（iam:tenant:write），不开放租户 Owner。 */
    @PutMapping("/{tenantId}/usage/{dimensionId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, Object> setUsageLimit(@PathVariable String tenantId,
                                             @PathVariable String dimensionId,
                                             @RequestBody(required = false) SetQuotaRequest request) {
        return quotaService.setLimit(CurrentAuth.claims(), tenantId, dimensionId,
                request == null ? null : request.limitValue());
    }

    /**
     * 某租户已开通的应用（角色配置按应用隔离的数据源，docs/05 §7.3 ④）。
     * 权限：iam:role:read（租户管理员可访问本租户；平台管理员任意租户）。
     */
    @GetMapping("/{tenantId}/applications")
    @RequirePermission(PermissionCodes.IAM_ROLE_READ)
    public Map<String, Object> applications(@PathVariable String tenantId) {
        tenantScopeGuard.assertTenantScope(CurrentAuth.claims(), tenantId.trim());
        List<String> appCodes = tenantApplicationRepository.findAppCodesByTenant(tenantId.trim());
        Map<String, ApplicationPO> appByCode = applicationsByCode(appCodes);
        List<TenantApplicationSummary> apps = appCodes.stream()
                .map(code -> applicationSummary(code, appByCode.get(code)))
                .toList();
        return Map.of("applications", apps, "count", apps.size());
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public Map<String, Object> list(@RequestParam(name = "limit", defaultValue = "20") int limit,
                                    @RequestParam(name = "scope_type", required = false) String scopeType,
                                    @RequestParam(name = "scope_id", required = false) String scopeId) {
        List<TenantPO> tenantRows = adminTenantService.list(limit, scopeType, scopeId);
        Map<String, List<TenantApplicationSummary>> applicationsByTenant = applicationsByTenant(tenantRows);
        List<Map<String, Object>> tenants = tenantRows.stream()
                .map(tenant -> toListBrief(tenant,
                        applicationsByTenant.getOrDefault(tenant.getTenantId(), List.of())))
                .toList();
        return Map.of("tenants", tenants, "count", tenants.size());
    }

    @GetMapping("/{tenantId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public Map<String, String> detail(@PathVariable String tenantId) {
        return toBrief(tenantRepository.findById(tenantId)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND)));
    }

    /** 详情抽屉聚合：成员身份信息须同时具有 iam:member:read，避免 tenant 基础读权限泄露成员目录。 */
    @GetMapping("/{tenantId}/details")
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public TenantDetailResponse drawerDetail(@PathVariable String tenantId) {
        assertPermission(PermissionCodes.IAM_MEMBER_READ);
        return tenantDetailService.detail(CurrentAuth.claims(), tenantId);
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Object create(@Valid @RequestBody CreateTenantRequest request) {
        if (request.ownerEmail() != null && request.tenantCode() == null && request.appCodes() == null) {
            return enterpriseTenantOwnerInvitationService.createAndInvite(CurrentAuth.claims(), request);
        }
        String tenantId = adminTenantService.create(request);
        auditService.audit().event("ADMIN_CREATE_TENANT").actor(CurrentAuth.claims().userId())
                .target("TENANT", tenantId).result("SUCCESS").write(Map.of("tenant_code", request.tenantCode()));
        return Map.of("tenant_id", tenantId, "tenant_type", "ORGANIZATION");
    }

    /** 设置有权威 Usage 来源的 IAM 配额覆盖。 */
    @PutMapping("/{tenantId}/quotas/{dimensionKey}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public TenantUsageDimension updateQuota(@PathVariable String tenantId,
                                             @PathVariable String dimensionKey,
                                             @Valid @RequestBody UpdateTenantQuotaRequest request) {
        tenantScopeGuard.assertTenantScope(CurrentAuth.claims(), tenantId.trim());
        TenantUsageDimension before = usageDimension(tenantId, dimensionKey);
        TenantUsageDimension updated = tenantQuotaService.updateLimit(tenantId, dimensionKey, request.limitValue());
        auditService.audit().event("ADMIN_UPDATE_TENANT_QUOTA").actor(CurrentAuth.claims().userId())
                .tenant(tenantId.trim()).target("TENANT_QUOTA", tenantId.trim() + ":" + dimensionKey)
                .before(before).after(updated).write(Map.of());
        return updated;
    }

    /** 清除租户覆盖并回退到维度默认上限。 */
    @DeleteMapping("/{tenantId}/quotas/{dimensionKey}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public TenantUsageDimension resetQuota(@PathVariable String tenantId, @PathVariable String dimensionKey) {
        tenantScopeGuard.assertTenantScope(CurrentAuth.claims(), tenantId.trim());
        TenantUsageDimension before = usageDimension(tenantId, dimensionKey);
        TenantUsageDimension updated = tenantQuotaService.resetLimit(tenantId, dimensionKey);
        auditService.audit().event("ADMIN_UPDATE_TENANT_QUOTA").actor(CurrentAuth.claims().userId())
                .tenant(tenantId.trim()).target("TENANT_QUOTA", tenantId.trim() + ":" + dimensionKey)
                .before(before).after(updated).write(Map.of("reset", true));
        return updated;
    }

    /**
     * 更换 Owner（G3 我方语义，docs/08 §6）：EXISTING_MEMBER 即时 swap（旧 Owner 降 is_admin）；
     * INVITE_BY_EMAIL 角色切换延期到 accept。鉴权服务层双轨：iam:tenant:write 或该租户 is_owner 持有者。
     */
    @PostMapping("/{tenantId}/owner")
    public TenantOwnerActionResponse changeOwner(@PathVariable String tenantId,
                                                  @Valid @RequestBody ChangeTenantOwnerRequest request) {
        String mode = request.mode().trim().toUpperCase(Locale.ROOT);
        return switch (mode) {
            case "EXISTING_MEMBER" -> {
                if (request.membershipId() == null || request.membershipId().isBlank()) {
                    throw AuthException.badRequest(ErrorCode.MEMBERSHIP_ID_REQUIRED);
                }
                yield tenantOwnershipService.transferToExistingMember(CurrentAuth.claims(), tenantId,
                        request.membershipId());
            }
            case "INVITE_BY_EMAIL" -> {
                if (request.email() == null || request.email().isBlank()) {
                    throw AuthException.badRequest(ErrorCode.EMAIL_REQUIRED);
                }
                yield ownerTransferInvitationService.invite(CurrentAuth.claims(), tenantId, request.email());
            }
            default -> throw AuthException.badRequest(ErrorCode.MODE_INVALID);
        };
    }

    @PutMapping("/{tenantId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, String> update(@PathVariable String tenantId,
                                      @RequestBody Map<String, String> fields) {
        adminTenantService.update(CurrentAuth.claims(), tenantId, fields);
        return Map.of("tenant_id", tenantId);
    }

    @DeleteMapping("/{tenantId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, String> delete(@PathVariable String tenantId) {
        adminTenantService.delete(CurrentAuth.claims(), tenantId);
        return Map.of("tenant_id", tenantId);
    }

    private Map<String, String> toBrief(TenantPO t) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("tenant_id", t.getTenantId());
        m.put("tenant_code", t.getTenantCode());
        m.put("tenant_name", t.getTenantName());
        m.put("tenant_type", t.getTenantType());
        m.put("tenant_status", t.getTenantStatus());
        m.put("primary_domain", t.getPrimaryDomain());
        return m;
    }

    private TenantUsageDimension usageDimension(String tenantId, String dimensionKey) {
        return tenantQuotaService.usageFor(tenantId).dimensions().stream()
                .filter(dimension -> dimension.dimensionKey().equals(dimensionKey))
                .findFirst().orElseThrow(() -> AuthException.notFound(ErrorCode.QUOTA_DIMENSION_NOT_FOUND));
    }

    private void assertPermission(String permission) {
        if (CurrentAuth.claims().permissions() == null || !CurrentAuth.claims().permissions().contains(permission)) {
            throw AuthException.forbidden(ErrorCode.PERMISSION_DENIED_GENERIC, permission);
        }
    }

    private Map<String, List<TenantApplicationSummary>> applicationsByTenant(List<TenantPO> tenants) {
        List<TenantApplicationPO> tenantApplications = tenantApplicationRepository.listByTenants(
                tenants.stream().map(TenantPO::getTenantId).toList());
        Map<String, ApplicationPO> applicationByCode = applicationsByCode(
                tenantApplications.stream().map(TenantApplicationPO::getAppCode).toList());
        return tenantApplications.stream()
                .collect(Collectors.groupingBy(TenantApplicationPO::getTenantId, LinkedHashMap::new,
                        Collectors.mapping(tenantApplication -> applicationSummary(tenantApplication.getAppCode(),
                                        applicationByCode.get(tenantApplication.getAppCode())),
                                Collectors.toList())));
    }

    private Map<String, Object> toListBrief(TenantPO tenant, List<TenantApplicationSummary> applications) {
        Map<String, Object> brief = new LinkedHashMap<>(toBrief(tenant));
        brief.put("applications", applications);
        return brief;
    }

    private Map<String, ApplicationPO> applicationsByCode(List<String> appCodes) {
        return applicationRepository.findByCodes(appCodes).stream()
                .collect(Collectors.toMap(ApplicationPO::getAppCode, Function.identity(), (a, b) -> a));
    }

    private TenantApplicationSummary applicationSummary(String appCode, ApplicationPO application) {
        if (application == null) {
            // 历史关联缺少目录记录时，仍把关系和可识别的 code 返回给管理台，而不是静默丢弃。
            return new TenantApplicationSummary(appCode, appCode, null, null);
        }
        return new TenantApplicationSummary(appCode, application.getAppName(), application.getDescription(),
                application.getAppStatus());
    }
}

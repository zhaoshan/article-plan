package com.unify.iam.common.exception;

import com.unify.iam.common.result.ResultCode;
import lombok.Getter;

/**
 * 认证/授权异常：对外契约端点专用，强制真实 HTTP 状态（401/403/404/400）。
 *
 * <p>GlobalExceptionHandler 将其渲染为 {@code {"detail": message}}（FastAPI 兼容信封），
 * 供 parlant-agent 登录 BFF（读 detail/message/error）原样转发。不能换成 200 信封。
 */
@Getter
public class AuthException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final int httpStatus;

    public AuthException(int httpStatus, String message) {
        super(message);
        this.httpStatus = httpStatus;
    }

    public AuthException(int httpStatus, String message, Throwable cause) {
        super(message, cause);
        this.httpStatus = httpStatus;
    }

    /** 401 未认证/凭据无效 */
    public static AuthException unauthorized(String message) {
        return new AuthException(401, message);
    }

    /** 403 已认证但不可用 */
    public static AuthException forbidden(String message) {
        return new AuthException(403, message);
    }

    /** 404 目标不存在 */
    public static AuthException notFound(String message) {
        return new AuthException(404, message);
    }

    /** 400 参数错误 */
    public static AuthException badRequest(String message) {
        return new AuthException(400, message);
    }

    /** 503 依赖不可用（如 IdP 不可达 / JWKS 拉取失败） */
    public static AuthException serviceUnavailable(String message) {
        return new AuthException(503, message);
    }
}

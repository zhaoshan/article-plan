package com.unify.iam.common.exception;

import com.unify.iam.common.result.ResultCode;
import lombok.Getter;

/**
 * 认证/授权异常：对外契约端点专用，强制真实 HTTP 状态（401/403/404/400）。
 *
 * <p>GlobalExceptionHandler 将其渲染为 {@code {"detail": message}}（FastAPI 兼容信封），
 * 供 parlant-agent 登录 BFF（读 detail/message/error）原样转发。不能换成 200 信封。
 */
@Getter
public class AuthException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final int httpStatus;

    /** 细粒度错误码（IAM-域-序号）；null 时信封回落 ResultCode 类目码。2026-11-03 错误目录契约。 */
    private final String code;

    public AuthException(int httpStatus, String message) {
        this(httpStatus, null, message);
    }

    public AuthException(int httpStatus, String code, String message) {
        super(message);
        this.httpStatus = httpStatus;
        this.code = code;
    }

    public AuthException(int httpStatus, String message, Throwable cause) {
        this(httpStatus, null, message, cause);
    }

    public AuthException(int httpStatus, String code, String message, Throwable cause) {
        super(message, cause);
        this.httpStatus = httpStatus;
        this.code = code;
    }

    /** 401 未认证/凭据无效 */
    public static AuthException unauthorized(String message) {
        return new AuthException(401, message);
    }

    /** 401 未认证/凭据无效（错误目录版，{0} 占位经 format 填充） */
    public static AuthException unauthorized(ErrorCode error, Object... args) {
        return new AuthException(401, error.code(), args.length == 0 ? error.message() : error.format(args));
    }

    /** 403 已认证但不可用 */
    public static AuthException forbidden(String message) {
        return new AuthException(403, message);
    }

    /** 403（错误目录版） */
    public static AuthException forbidden(ErrorCode error, Object... args) {
        return new AuthException(403, error.code(), args.length == 0 ? error.message() : error.format(args));
    }

    /** 404 目标不存在 */
    public static AuthException notFound(String message) {
        return new AuthException(404, message);
    }

    /** 404（错误目录版） */
    public static AuthException notFound(ErrorCode error, Object... args) {
        return new AuthException(404, error.code(), args.length == 0 ? error.message() : error.format(args));
    }

    /** 429 请求过于频繁/冷却中（限流，P1-02 登录暴力破解防护） */
    public static AuthException tooManyRequests(ErrorCode error, Object... args) {
        return new AuthException(429, error.code(), args.length == 0 ? error.message() : error.format(args));
    }

    /** 400 参数错误 */
    public static AuthException badRequest(String message) {
        return new AuthException(400, message);
    }

    /** 400（错误目录版） */
    public static AuthException badRequest(ErrorCode error, Object... args) {
        return new AuthException(400, error.code(), args.length == 0 ? error.message() : error.format(args));
    }

    /** 503 依赖不可用（如 IdP 不可达 / JWKS 拉取失败） */
    public static AuthException serviceUnavailable(String message) {
        return new AuthException(503, message);
    }

    /** 503（错误目录版） */
    public static AuthException serviceUnavailable(ErrorCode error, Object... args) {
        return new AuthException(503, error.code(), args.length == 0 ? error.message() : error.format(args));
    }
}

-- ============================================================
-- dev/test 专用 seed（可重复、幂等；仅 db/seed-dev 位置，生产不含）
-- 内容：dev 三账号（admin/operator/viewer）+ tenant-org-a + parlant 应用/模板
--       + 9 业务权限点（app_code=parlant-agent-server）+ 平台管理员绑定（admin→r-2001，需先有 platform_bootstrap）
-- 密码：admin/admin123、operator/op123、viewer/view123（BCrypt cost10，$2y$ 前缀）
-- 约定：全部 INSERT IGNORE（幂等）；permission 带 V8 隔离列 app_code/tenant_grantable。
-- ============================================================

SET NAMES utf8mb4;

-- 1. 租户
INSERT IGNORE INTO `gateway_tenant`
  (`tenant_id`, `tenant_code`, `tenant_name`, `tenant_type`, `tenant_status`,
   `registration_source`, `owner_user_id`, `join_policy`, `sso_required`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('tenant-org-a', 'org-a', 'Org A', 'ORGANIZATION', 'ACTIVE',
   'ADMIN', 'u-1000', 'INVITE_ONLY', 0,
   0, 'system', 'system');

-- 2. 用户
INSERT IGNORE INTO `gateway_user`
  (`user_id`, `username`, `primary_email`, `password_hash`, `full_name`, `display_name`,
   `default_tenant_id`, `user_status`, `registration_source`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('u-1000', 'admin', 'admin@unify.local', '$2y$10$rKYNH6UsTYNgjfLz2khy5O/yoazBt.R/Ak03v8o9dQ0fc9cvpwDmi', 'Platform Admin', 'Admin',
   'tenant-org-a', 'ACTIVE', 'ADMIN', 0, 'system', 'system'),
  ('u-1001', 'operator', 'operator@unify.local', '$2y$10$rRWIDtZFfiUnRXg/rTABNeyJvb0AE5rnu8hUutqLVgoaIgQ/BDrW6', 'Agent Operator', 'Operator',
   'tenant-org-a', 'ACTIVE', 'ADMIN', 0, 'system', 'system'),
  ('u-1002', 'viewer', 'viewer@unify.local', '$2y$10$7fz/ZSudBKRu/2fbea44sOImpP.amOjFSvf26iCp5s8Oovl.HDvfa', 'Readonly Viewer', 'Viewer',
   'tenant-org-a', 'ACTIVE', 'ADMIN', 0, 'system', 'system');

-- 3. 本地身份
INSERT IGNORE INTO `gateway_user_identity`
  (`user_identity_id`, `user_id`, `provider_type`, `provider_key`, `issuer`, `subject`,
   `login_name`, `identity_status`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('id-1001', 'u-1000', 'LOCAL', 'password', NULL, 'admin', 'admin', 'ACTIVE', 0, 'system', 'system'),
  ('id-2001', 'u-1001', 'LOCAL', 'password', NULL, 'operator', 'operator', 'ACTIVE', 0, 'system', 'system'),
  ('id-3001', 'u-1002', 'LOCAL', 'password', NULL, 'viewer', 'viewer', 'ACTIVE', 0, 'system', 'system');

-- 4. 成员关系
INSERT IGNORE INTO `gateway_membership`
  (`membership_id`, `tenant_id`, `user_id`, `membership_status`, `join_source`, `is_default`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('ms-1001', 'tenant-org-a', 'u-1000', 'ACTIVE', 'ADMIN', 1, 0, 'system', 'system'),
  ('ms-2001', 'tenant-org-a', 'u-1001', 'ACTIVE', 'ADMIN', 1, 0, 'system', 'system'),
  ('ms-3001', 'tenant-org-a', 'u-1002', 'ACTIVE', 'ADMIN', 1, 0, 'system', 'system');

-- 5. 角色（TENANT 作用域 / tenant-org-a）
INSERT IGNORE INTO `gateway_role`
  (`role_id`, `scope_type`, `scope_id`, `role_code`, `role_name`, `role_description`,
   `is_builtin`, `role_status`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('r-1001', 'TENANT', 'tenant-org-a', 'AgentOperator', 'Agent Operator', 'Agent 运维角色', 1, 'ACTIVE', 0, 'system', 'system'),
  ('r-1002', 'TENANT', 'tenant-org-a', 'TenantAdmin', 'Tenant Admin', '租户管理员', 1, 'ACTIVE', 0, 'system', 'system'),
  ('r-1003', 'TENANT', 'tenant-org-a', 'Viewer', 'Viewer', '只读用户', 1, 'ACTIVE', 0, 'system', 'system');

-- 6. 业务权限点（9 码，V8 隔离列：app_code=parlant-agent-server，租户可授）
INSERT IGNORE INTO `gateway_permission`
  (`permission_id`, `permission_code`, `resource_type`, `app_code`, `tenant_grantable`, `action`, `permission_name`,
   `permission_description`, `is_builtin`, `permission_status`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('p-1001', 'agent:read',     'AGENT',    'parlant-agent-server', 1, 'READ',    '查看 Agent 定义',  '查看 Agent 定义/版本/旅程布局',        1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1002', 'agent:build',    'AGENT',    'parlant-agent-server', 1, 'BUILD',   '构建 Agent',       '新建/存草稿、旅程布局编辑',            1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1003', 'agent:publish',  'AGENT',    'parlant-agent-server', 1, 'PUBLISH', '发布 Agent',       '发布 Agent',                           1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1004', 'agent:delete',   'AGENT',    'parlant-agent-server', 1, 'DELETE',  '删除 Agent',       '删除/卸载/回滚/删版本',                1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1005', 'session:read',   'SESSION',  'parlant-agent-server', 1, 'READ',    '查看会话',         '会话/消息历史查看（含 SSE 事件流）',    1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1006', 'session:send',   'SESSION',  'parlant-agent-server', 1, 'SEND',    '发送会话消息',     '建会话/发事件/关/删会话',              1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1007', 'customer:manage','CUSTOMER', 'parlant-agent-server', 1, 'MANAGE',  '客户管理',         '客户管理',                             1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1008', 'trace:read',     'TRACE',    'parlant-agent-server', 1, 'READ',    '查看观测链路',     '观测链路历史',                         1, 'ACTIVE', 0, 'system', 'system'),
  ('p-1009', 'settings:read',  'SETTINGS', 'parlant-agent-server', 1, 'READ',    '查看平台设置',     '平台设置查看',                         1, 'ACTIVE', 0, 'system', 'system');

-- 7. 角色权限绑定（TenantAdmin 全量 / AgentOperator 全量 / Viewer 3 只读）
INSERT IGNORE INTO `gateway_role_permission`
  (`role_permission_id`, `role_id`, `permission_id`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('rp-2001', 'r-1002', 'p-1001', 0, 'system', 'system'),
  ('rp-2002', 'r-1002', 'p-1002', 0, 'system', 'system'),
  ('rp-2003', 'r-1002', 'p-1003', 0, 'system', 'system'),
  ('rp-2004', 'r-1002', 'p-1004', 0, 'system', 'system'),
  ('rp-2005', 'r-1002', 'p-1005', 0, 'system', 'system'),
  ('rp-2006', 'r-1002', 'p-1006', 0, 'system', 'system'),
  ('rp-2007', 'r-1002', 'p-1007', 0, 'system', 'system'),
  ('rp-2008', 'r-1002', 'p-1008', 0, 'system', 'system'),
  ('rp-2009', 'r-1002', 'p-1009', 0, 'system', 'system'),
  ('rp-1001', 'r-1001', 'p-1001', 0, 'system', 'system'),
  ('rp-1002', 'r-1001', 'p-1002', 0, 'system', 'system'),
  ('rp-1003', 'r-1001', 'p-1003', 0, 'system', 'system'),
  ('rp-1004', 'r-1001', 'p-1004', 0, 'system', 'system'),
  ('rp-1005', 'r-1001', 'p-1005', 0, 'system', 'system'),
  ('rp-1006', 'r-1001', 'p-1006', 0, 'system', 'system'),
  ('rp-1007', 'r-1001', 'p-1007', 0, 'system', 'system'),
  ('rp-1008', 'r-1001', 'p-1008', 0, 'system', 'system'),
  ('rp-1009', 'r-1001', 'p-1009', 0, 'system', 'system'),
  ('rp-3001', 'r-1003', 'p-1001', 0, 'system', 'system'),
  ('rp-3002', 'r-1003', 'p-1005', 0, 'system', 'system'),
  ('rp-3003', 'r-1003', 'p-1009', 0, 'system', 'system');

-- 8. 成员角色（dev 三角色；admin 另授 PlatformAdmin → 需先有 platform_bootstrap 的 r-2001）
INSERT IGNORE INTO `gateway_membership_role`
  (`membership_role_id`, `membership_id`, `role_id`, `grant_source`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('mr-1001', 'ms-1001', 'r-1002', 'DIRECT', 0, 'system', 'system'),
  ('mr-2001', 'ms-2001', 'r-1001', 'DIRECT', 0, 'system', 'system'),
  ('mr-3001', 'ms-3001', 'r-1003', 'DIRECT', 0, 'system', 'system'),
  ('mrp-2001', 'ms-1001', 'r-2001', 'DIRECT', 0, 'system', 'system'); -- admin → PlatformAdmin

-- 9. parlant 应用 + 三角色模板 + tenant-org-a 启用登记
INSERT IGNORE INTO `iam_application`
  (`app_id`, `app_code`, `app_name`, `app_status`, `description`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('app-2001', 'parlant-agent-server', 'Parlant Agent Server', 'ACTIVE', 'parlant 企业级客服 Agent 平台', 0, 'system', 'system');

INSERT IGNORE INTO `iam_application_role_template`
  (`template_id`, `app_code`, `role_code`, `role_name`, `role_description`, `permission_codes_json`,
   `is_owner`, `priority`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('tpl-2001', 'parlant-agent-server', 'AgentOperator', 'Agent Operator', 'Agent 运维角色',
   JSON_ARRAY('agent:read','agent:build','agent:publish','agent:delete',
              'session:read','session:send','customer:manage','trace:read','settings:read'),
   0, 20, 0, 'system', 'system'),
  ('tpl-2002', 'parlant-agent-server', 'TenantAdmin', 'Tenant Admin', '租户管理员（本租户管理面）',
   JSON_ARRAY('agent:read','agent:build','agent:publish','agent:delete',
              'session:read','session:send','customer:manage','trace:read','settings:read',
              'iam:member:read','iam:member:write','iam:role:read','iam:role:write'),
   1, 10, 0, 'system', 'system'),
  ('tpl-2003', 'parlant-agent-server', 'Viewer', 'Viewer', '只读用户',
   JSON_ARRAY('agent:read','session:read','settings:read'),
   0, 30, 0, 'system', 'system');

INSERT IGNORE INTO `iam_tenant_application`
  (`tenant_app_id`, `tenant_id`, `app_code`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('tpa-2001', 'tenant-org-a', 'parlant-agent-server', 0, 'system', 'system');

-- 兜底：历史/存量 permission 行补隔离列（旧结构迁移来的库 p-1001..1009 可能缺 app_code；幂等）
UPDATE `gateway_permission` SET `app_code` = 'parlant-agent-server', `tenant_grantable` = 1
 WHERE `permission_id` IN ('p-1001','p-1002','p-1003','p-1004','p-1005','p-1006','p-1007','p-1008','p-1009');

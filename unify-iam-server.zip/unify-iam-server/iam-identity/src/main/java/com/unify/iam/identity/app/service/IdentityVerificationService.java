package com.unify.iam.identity.app.service;

import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.identity.common.constant.UserStatus;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import org.springframework.stereotype.Service;

/**
 * 本地密码凭据校验：username/password → UserPrincipal。
 *
 * <p>任何失败统一抛 {@code AuthException(401, "用户名或密码错误")}（防账号枚举）：
 * 未知用户、本地身份缺失/停用、账号非 ACTIVE、密码不匹配 同文案。
 */
@Service
public class IdentityVerificationService {

    private static final String LOGIN_FAILED = "用户名或密码错误";

    private final UserRepository userRepository;
    private final UserIdentityRepository userIdentityRepository;

    public IdentityVerificationService(UserRepository userRepository,
                                       UserIdentityRepository userIdentityRepository) {
        this.userRepository = userRepository;
        this.userIdentityRepository = userIdentityRepository;
    }

    /**
     * 校验登录名 + 密码，返回认证通过的用户主体。
     *
     * @throws AuthException 401（凭据无效/账号不可用，统一文案）
     */
    public UserPrincipal verify(String username, String password) {
        UserPO user = userRepository.findByUsername(username).orElseThrow(
                () -> AuthException.unauthorized(LOGIN_FAILED));
        UserIdentityPO identity = userIdentityRepository.findLocalActive(user.getUserId()).orElseThrow(
                () -> AuthException.unauthorized(LOGIN_FAILED));
        if (!UserStatus.isActive(user.getUserStatus())) {
            throw AuthException.unauthorized(LOGIN_FAILED);
        }
        if (!BCryptUtils.matches(password, user.getPasswordHash())) {
            throw AuthException.unauthorized(LOGIN_FAILED);
        }
        return new UserPrincipal(user.getUserId(), username, identity.getUserIdentityId());
    }
}

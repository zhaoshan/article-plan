"""DynamicCrawler 文件合并逻辑测试"""

import json
import pytest
from pathlib import Path
from src.core.dynamic_crawler import DynamicCrawler
from src.utils.url_utils import normalize_url


class TestMergeIntoLinksFile:
    """_merge_into_links_file 去重合并测试"""

    def test_new_file_creates_with_links(self, tmp_path: Path):
        """文件不存在时创建并写入"""
        crawler = DynamicCrawler()
        links_path = tmp_path / "test_links.json"
        count = crawler._merge_into_links_file(
            links_path, ["https://example.com/page1", "https://example.com/page2"]
        )
        assert count == 2
        data = json.loads(links_path.read_text(encoding="utf-8"))
        assert len(data) == 2

    def test_append_new_links(self, tmp_path: Path):
        """已有文件追加新链接"""
        links_path = tmp_path / "test_links.json"
        links_path.write_text(
            json.dumps(["https://example.com/a"]), encoding="utf-8"
        )

        crawler = DynamicCrawler()
        count = crawler._merge_into_links_file(
            links_path, ["https://example.com/b", "https://example.com/c"]
        )
        assert count == 2
        data = json.loads(links_path.read_text(encoding="utf-8"))
        assert len(data) == 3

    def test_dedup_existing_links(self, tmp_path: Path):
        """去重：已有链接不重复添加"""
        links_path = tmp_path / "test_links.json"
        links_path.write_text(
            json.dumps(["https://example.com/a", "https://example.com/b"]),
            encoding="utf-8",
        )

        crawler = DynamicCrawler()
        count = crawler._merge_into_links_file(
            links_path, ["https://example.com/b", "https://example.com/c"]
        )
        assert count == 1  # 只新增 c
        data = json.loads(links_path.read_text(encoding="utf-8"))
        assert len(data) == 3

    def test_all_duplicates_returns_zero(self, tmp_path: Path):
        """全重复返回 0"""
        links_path = tmp_path / "test_links.json"
        links_path.write_text(
            json.dumps(["https://example.com/a"]), encoding="utf-8"
        )

        crawler = DynamicCrawler()
        count = crawler._merge_into_links_file(
            links_path, ["https://example.com/a"]
        )
        assert count == 0

    def test_normalize_dedup(self, tmp_path: Path):
        """标准化后去重：不同形式但同一 URL 不重复"""
        links_path = tmp_path / "test_links.json"
        links_path.write_text(
            json.dumps(["https://example.com/a/"]), encoding="utf-8"
        )

        crawler = DynamicCrawler()
        # 同一 URL 去掉尾部斜杠 → 标准化后相同
        count = crawler._merge_into_links_file(
            links_path, ["https://example.com/a"]
        )
        assert count == 0

    def test_invalid_json_resets(self, tmp_path: Path):
        """损坏的 JSON 文件视为空"""
        links_path = tmp_path / "test_links.json"
        links_path.write_text("not valid json", encoding="utf-8")

        crawler = DynamicCrawler()
        count = crawler._merge_into_links_file(
            links_path, ["https://example.com/a"]
        )
        assert count == 1


class TestMergeIntoTreeFile:
    """_merge_into_tree_file 树合并测试"""

    def _make_tree(self, url: str, children: list[dict] | None = None, leaf: bool = False, node_type: str | None = None) -> dict:
        """构建树节点"""
        node: dict = {"url": url}
        if children:
            node["children"] = children
        if leaf:
            node["leaf"] = True
            if node_type:
                node["type"] = node_type
        return node

    def test_add_children_to_root(self, tmp_path: Path):
        """在根节点下添加子节点"""
        tree = self._make_tree("https://example.com/", children=[
            self._make_tree("https://example.com/page1", leaf=True, node_type="file"),
        ])
        tree_path = tmp_path / "tree.json"
        tree_path.write_text(json.dumps(tree), encoding="utf-8")

        crawler = DynamicCrawler()
        result = crawler._merge_into_tree_file(
            tree_path,
            parent_link="https://example.com/",
            new_links=["https://example.com/dynamic1", "https://example.com/dynamic2"],
        )
        assert result is True

        data = json.loads(tree_path.read_text(encoding="utf-8"))
        children = data["children"]
        assert len(children) == 3  # 原有 1 个 + 新增 2 个
        child_urls = {c["url"] for c in children}
        assert "https://example.com/page1" in child_urls
        assert normalize_url("https://example.com/dynamic1") in child_urls
        assert normalize_url("https://example.com/dynamic2") in child_urls

        # 动态链接标记正确
        dynamic_nodes = [c for c in children if c.get("type") == "dynamic"]
        assert len(dynamic_nodes) == 2
        for node in dynamic_nodes:
            assert node["leaf"] is True

    def test_parent_was_leaf_now_expanded(self, tmp_path: Path):
        """父节点原是叶子节点，添加子节点后移除 leaf 标记"""
        tree = self._make_tree("https://example.com/", children=[
            self._make_tree("https://other.com/faq", leaf=True, node_type="cross_domain"),
        ])
        tree_path = tmp_path / "tree.json"
        tree_path.write_text(json.dumps(tree), encoding="utf-8")

        crawler = DynamicCrawler()
        result = crawler._merge_into_tree_file(
            tree_path,
            parent_link="https://other.com/faq",
            new_links=["https://support.other.com/q1"],
        )
        assert result is True

        data = json.loads(tree_path.read_text(encoding="utf-8"))
        faq_node = data["children"][0]
        assert "leaf" not in faq_node  # leaf 标记已移除
        assert "type" not in faq_node
        assert len(faq_node["children"]) == 1
        assert faq_node["children"][0]["type"] == "dynamic"

    def test_parent_not_found_returns_false(self, tmp_path: Path):
        """父节点不存在返回 False"""
        tree = self._make_tree("https://example.com/")
        tree_path = tmp_path / "tree.json"
        tree_path.write_text(json.dumps(tree), encoding="utf-8")

        crawler = DynamicCrawler()
        result = crawler._merge_into_tree_file(
            tree_path,
            parent_link="https://nonexistent.com/page",
            new_links=["https://example.com/dynamic1"],
        )
        assert result is False

    def test_all_links_already_in_tree(self, tmp_path: Path):
        """所有链接已存在树中"""
        tree = self._make_tree("https://example.com/", children=[
            self._make_tree("https://example.com/existing"),
        ])
        tree_path = tmp_path / "tree.json"
        tree_path.write_text(json.dumps(tree), encoding="utf-8")

        crawler = DynamicCrawler()
        result = crawler._merge_into_tree_file(
            tree_path,
            parent_link="https://example.com/",
            new_links=["https://example.com/existing"],
        )
        assert result is False  # 无新增

    def test_nested_parent_found(self, tmp_path: Path):
        """深层嵌套的父节点也能找到"""
        tree = self._make_tree("https://example.com/", children=[
            self._make_tree("https://example.com/a", children=[
                self._make_tree("https://example.com/b", leaf=True),
            ]),
        ])
        tree_path = tmp_path / "tree.json"
        tree_path.write_text(json.dumps(tree), encoding="utf-8")

        crawler = DynamicCrawler()
        result = crawler._merge_into_tree_file(
            tree_path,
            parent_link="https://example.com/b",
            new_links=["https://example.com/dynamic1"],
        )
        assert result is True

        data = json.loads(tree_path.read_text(encoding="utf-8"))
        b_node = data["children"][0]["children"][0]
        assert len(b_node["children"]) == 1
        assert b_node["children"][0]["type"] == "dynamic"


class TestCollectAllUrls:
    """_collect_all_urls 测试"""

    def test_collect_from_tree(self):
        """递归收集所有 URL"""
        tree = {
            "url": "https://example.com/",
            "children": [
                {"url": "https://example.com/a", "children": [
                    {"url": "https://example.com/b", "leaf": True},
                ]},
                {"url": "https://other.com/c", "leaf": True, "type": "cross_domain"},
            ],
        }
        crawler = DynamicCrawler()
        urls = crawler._collect_all_urls(tree)
        assert normalize_url("https://example.com/") in urls
        assert normalize_url("https://example.com/a") in urls
        assert normalize_url("https://example.com/b") in urls
        assert normalize_url("https://other.com/c") in urls
        assert len(urls) == 4


class TestIsInWhitelist:
    """_is_in_whitelist 测试"""

    def test_exact_match(self):
        """精确匹配"""
        crawler = DynamicCrawler()
        assert crawler._is_in_whitelist("https://partner.com/page", ["partner.com"]) is True

    def test_subdomain_match(self):
        """子域名匹配"""
        crawler = DynamicCrawler()
        assert crawler._is_in_whitelist("https://sub.partner.com/page", ["partner.com"]) is True

    def test_no_match(self):
        """不匹配"""
        crawler = DynamicCrawler()
        assert crawler._is_in_whitelist("https://other.com/page", ["partner.com"]) is False

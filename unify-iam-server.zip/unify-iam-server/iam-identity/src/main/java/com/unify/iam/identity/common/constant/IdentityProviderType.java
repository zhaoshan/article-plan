package com.unify.iam.identity.common.constant;

/** 身份协议类型（对应 gateway_user_identity.provider_type）。 */
public enum IdentityProviderType {
    LOCAL,
    OIDC,
    SAML
}

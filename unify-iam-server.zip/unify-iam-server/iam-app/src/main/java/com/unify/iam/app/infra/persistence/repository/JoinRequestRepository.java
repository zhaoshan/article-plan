package com.unify.iam.app.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.app.infra.persistence.mapper.JoinRequestMapper;
import com.unify.iam.app.infra.persistence.po.JoinRequestPO;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** 加入申请仓储。 */
@Repository
public class JoinRequestRepository {

    private final JoinRequestMapper joinRequestMapper;

    public JoinRequestRepository(JoinRequestMapper joinRequestMapper) {
        this.joinRequestMapper = joinRequestMapper;
    }

    public void insert(JoinRequestPO po) {
        joinRequestMapper.insert(po);
    }

    public Optional<JoinRequestPO> findById(String joinRequestId) {
        return Optional.ofNullable(joinRequestMapper.selectOne(new LambdaQueryWrapper<JoinRequestPO>()
                        .eq(JoinRequestPO::getJoinRequestId, joinRequestId)))
                .map(this::trimBizKeys);
    }

    /** 管理端申请列表（按租户 + 可选状态）。 */
    public List<JoinRequestPO> listByTenant(String tenantId, String status) {
        return joinRequestMapper.selectList(new LambdaQueryWrapper<JoinRequestPO>()
                        .eq(JoinRequestPO::getTenantId, tenantId)
                        .eq(status != null && !status.isBlank(), JoinRequestPO::getRequestStatus, status)
                        .orderByDesc(JoinRequestPO::getId))
                .stream().map(this::trimBizKeys).toList();
    }

    public void update(JoinRequestPO po) {
        joinRequestMapper.updateById(po);
    }

    private JoinRequestPO trimBizKeys(JoinRequestPO po) {
        if (po.getJoinRequestId() != null) {
            po.setJoinRequestId(po.getJoinRequestId().trim());
        }
        if (po.getTenantId() != null) {
            po.setTenantId(po.getTenantId().trim());
        }
        if (po.getUserId() != null) {
            po.setUserId(po.getUserId().trim());
        }
        return po;
    }
}

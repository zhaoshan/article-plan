package com.unify.iam.identity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.app.service.IdentityVerificationService;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class IdentityVerificationServiceTest {

    private static final String HASH = "$2y$10$rRWIDtZFfiUnRXg/rTABNeyJvb0AE5rnu8hUutqLVgoaIgQ/BDrW6"; // op123

    @Mock
    private UserRepository userRepository;
    @Mock
    private UserIdentityRepository userIdentityRepository;

    private IdentityVerificationService service;

    @BeforeEach
    void setUp() {
        service = new IdentityVerificationService(userRepository, userIdentityRepository);
    }

    private UserPO user(String status) {
        UserPO po = new UserPO();
        po.setUserId("u-1001");
        po.setUsername("operator");
        po.setPasswordHash(HASH);
        po.setUserStatus(status);
        return po;
    }

    private UserIdentityPO activeIdentity() {
        UserIdentityPO po = new UserIdentityPO();
        po.setUserIdentityId("id-2001");
        po.setUserId("u-1001");
        po.setProviderType("LOCAL");
        po.setProviderKey("password");
        po.setIdentityStatus("ACTIVE");
        return po;
    }

    @Test
    void verifySuccessReturnsPrincipal() {
        when(userRepository.findByLoginIdentifier("operator")).thenReturn(Optional.of(user("ACTIVE")));
        when(userIdentityRepository.findLocalActive("u-1001")).thenReturn(Optional.of(activeIdentity()));

        UserPrincipal principal = service.verify("operator", "op123");

        assertThat(principal.userId()).isEqualTo("u-1001");
        assertThat(principal.username()).isEqualTo("operator");
        assertThat(principal.userIdentityId()).isEqualTo("id-2001");
    }

    @Test
    void emailLoginReturnsStoredUsername() {
        when(userRepository.findByLoginIdentifier("operator@unify.local")).thenReturn(Optional.of(user("ACTIVE")));
        when(userIdentityRepository.findLocalActive("u-1001")).thenReturn(Optional.of(activeIdentity()));

        UserPrincipal principal = service.verify("operator@unify.local", "op123");

        assertThat(principal.userId()).isEqualTo("u-1001");
        assertThat(principal.username()).isEqualTo("operator");
        assertThat(principal.userIdentityId()).isEqualTo("id-2001");
    }

    @Test
    void unknownUserThrows401() {
        when(userRepository.findByLoginIdentifier("nobody")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.verify("nobody", "x"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessage("Incorrect username or password");
    }

    @Test
    void missingLocalIdentityThrows401() {
        when(userRepository.findByLoginIdentifier("operator")).thenReturn(Optional.of(user("ACTIVE")));
        when(userIdentityRepository.findLocalActive("u-1001")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.verify("operator", "op123"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
    }

    @Test
    void suspendedUserThrows401() {
        when(userRepository.findByLoginIdentifier("operator")).thenReturn(Optional.of(user("SUSPENDED")));
        when(userIdentityRepository.findLocalActive("u-1001")).thenReturn(Optional.of(activeIdentity()));

        assertThatThrownBy(() -> service.verify("operator", "op123"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
    }

    @Test
    void wrongPasswordThrows401() {
        when(userRepository.findByLoginIdentifier("operator")).thenReturn(Optional.of(user("ACTIVE")));
        when(userIdentityRepository.findLocalActive("u-1001")).thenReturn(Optional.of(activeIdentity()));

        assertThatThrownBy(() -> service.verify("operator", "wrong"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessage("Incorrect username or password");
    }

    @Test
    void allFailuresShareSameMessageToAvoidEnumeration() {
        // 未知用户 与 密码错误 文案一致（防账号枚举）
        when(userRepository.findByLoginIdentifier("ghost")).thenReturn(Optional.empty());
        when(userRepository.findByLoginIdentifier("operator")).thenReturn(Optional.of(user("ACTIVE")));
        when(userIdentityRepository.findLocalActive("u-1001")).thenReturn(Optional.of(activeIdentity()));

        assertThatThrownBy(() -> service.verify("ghost", "x")).hasMessage("Incorrect username or password");
        assertThatThrownBy(() -> service.verify("operator", "x")).hasMessage("Incorrect username or password");
    }
}

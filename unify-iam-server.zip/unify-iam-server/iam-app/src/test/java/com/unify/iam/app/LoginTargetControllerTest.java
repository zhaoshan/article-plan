package com.unify.iam.app;

import com.unify.iam.api.dto.auth.LoginTarget;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.LoginTargetController;
import com.unify.iam.app.app.service.LoginTargetService;
import com.unify.iam.app.config.ApiEnvelopeAdvice;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.security.JwtSigner;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class LoginTargetControllerTest {
    private final JwtSigner signer = mock(JwtSigner.class);
    private final LoginTargetService service = mock(LoginTargetService.class);
    private MockMvc mvc;
    private JwtClaims claims;

    @BeforeEach void setup() {
        mvc = MockMvcBuilders.standaloneSetup(new LoginTargetController(signer, service))
                .setControllerAdvice(new GlobalExceptionHandler(), new ApiEnvelopeAdvice()).build();
        claims = new JwtClaims("issuer", List.of("business"), "verified-user", "t1", "m1", List.of(), List.of(), Map.of(), 9999999999L, 0, "jti", 0);
        when(signer.verify("valid-token")).thenReturn(claims);
    }

    @Test void endpointsRequireBearerWithoutQueryingCatalog() throws Exception {
        mvc.perform(get("/api/v1/auth/available-apps")).andExpect(status().isUnauthorized()).andExpect(jsonPath("$.success").value(false));
        mvc.perform(post("/api/v1/auth/resolve-target").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isUnauthorized());
        verifyNoInteractions(service);
    }

    @Test void catalogUsesVerifiedSubjectAndReturnsEnvelope() throws Exception {
        when(service.catalog("verified-user")).thenReturn(new LoginTarget.Catalog(List.of(), true));
        mvc.perform(get("/api/v1/auth/available-apps").header("Authorization", "Bearer valid-token").param("user_id", "foreign-user"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.applications").isArray()).andExpect(jsonPath("$.data.is_platform_admin").value(true));
        verify(service).catalog("verified-user");
    }

    @Test void resolveDeserializesSnakeCaseAndNeverReturnsTokens() throws Exception {
        var request = new LoginTarget.Request("business", "https://business.test/callback", "m1");
        when(service.resolve(claims, request)).thenReturn(new LoginTarget.Resolution(LoginTarget.Decision.REDIRECT, null, null,
                new LoginTarget.Membership("m1", "t1", "Tenant", "tenant"), "https://business.test/callback"));
        mvc.perform(post("/api/v1/auth/resolve-target").header("Authorization", "Bearer valid-token")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"app_code\":\"business\",\"return_to\":\"https://business.test/callback\",\"membership_id\":\"m1\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.decision").value("REDIRECT"))
                .andExpect(jsonPath("$.data.membership.membership_id").value("m1"))
                .andExpect(jsonPath("$.data.callback_url").value("https://business.test/callback"))
                .andExpect(jsonPath("$.data.access_token").doesNotExist()).andExpect(jsonPath("$.data.refresh_token").doesNotExist());
        verify(service).resolve(claims, request);
    }

    @Test void oversizedRoutingInputIsRejected() throws Exception {
        mvc.perform(post("/api/v1/auth/resolve-target").header("Authorization", "Bearer valid-token")
                .contentType(MediaType.APPLICATION_JSON).content("{\"app_code\":\"" + "a".repeat(129) + "\"}"))
                .andExpect(status().isBadRequest());
        verifyNoInteractions(service);
    }
}

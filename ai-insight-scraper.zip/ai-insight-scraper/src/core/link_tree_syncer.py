"""LinkTreeSyncer — 全量链接树 JSON → crawl_link_tree 增量同步

以一份新爬取的 tree_structure_{ts}.json 为基准，对数据库 crawl_link_tree 表
做增量同步。同步规则：

  1. JSON 有 / DB 有  → 跳过（不处理）
  2. JSON 有 / DB 无  → 新增一条，update_history="新增"，update_time_tag=当前时间
  3. DB 有 / JSON 无  → 标记 update_history="待删除"，update_time_tag=当前时间；
                        随后逐个用 Playwright 打开页面验证可达性：
                          - 页面正常 → 去掉"待删除"，custom_tag="验证页面正常"
                          - 其它情况 → update_history="已删除"

JSON 节点只含 url/children/leaf/type/not_found，缺失的 Excel 业务字段
（domain/sub_path/file_name/link_type/site_owner 等）按 merge_links_to_excel.py
的规则推导赋值。

S3 支持：
  - tree_file 为 s3:// 路径时，自动从 S3 下载后解析

NOT_FOUND_TEXTS：
  - 从 traversal_rule_config.json 动态加载，不再硬编码
"""

import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from playwright.async_api import BrowserContext, Page, async_playwright

from src.boundaries.s3_boundary import S3Boundary
from src.config.traversal_config import load_traversal_config
from src.core.base_crawler import BaseCrawler
from src.database import LinkTreeRepository
from src.database.models import CrawlLinkTreeModel
from src.utils.url_utils import normalize_url

logger = logging.getLogger(__name__)

# ── 业务字段推导（与 scripts/merge_links_to_excel.py 一致）──────────

# 附件扩展名 → 类型标签
ATTACHMENT_EXTENSIONS: dict[str, str] = {
    ".pdf": "PDF", ".doc": "DOC", ".docx": "DOC",
    ".xls": "EXCEL", ".xlsx": "EXCEL", ".csv": "EXCEL",
    ".ppt": "PPT", ".pptx": "PPT",
    ".zip": "ZIP", ".rar": "ZIP", ".7z": "ZIP", ".tar": "ZIP", ".gz": "ZIP",
    ".png": "IMAGE", ".jpg": "IMAGE", ".jpeg": "IMAGE", ".gif": "IMAGE",
    ".bmp": "IMAGE", ".svg": "IMAGE", ".webp": "IMAGE",
    ".txt": "TEXT",
    ".mp4": "VIDEO", ".avi": "VIDEO", ".mov": "VIDEO", ".wmv": "VIDEO",
}

# 页面状态结果
RESULT_OK = "页面正常"
RESULT_NOT_FOUND = "页面能打开，但提示不存在"
RESULT_TIMEOUT = "页面无法打开"

# 页面超时（毫秒）
PAGE_TIMEOUT = 60000
WAIT_DYNAMIC_MS = 3000


def detect_attachment_type(url: str) -> str:
    """从 URL 路径检测附件类型，否则返回 HTML（与 merge_links_to_excel 一致）"""
    path = urlparse(url).path.lower()
    if path and "." in path:
        ext = "." + path.rsplit(".", 1)[-1]
        if ext in ATTACHMENT_EXTENSIONS:
            return ATTACHMENT_EXTENSIONS[ext]
    return "HTML"


def parse_url(url: str) -> dict:
    """解析 URL 提取 domain/sub_path/file_name（与 merge_links_to_excel 一致）"""
    parsed = urlparse(url)
    domain = parsed.netloc.replace("www.", "")
    path = parsed.path
    sub_path: str | None = None
    file_name: str | None = None

    if path and path != "/":
        parts = path.strip("/").split("/")
        if len(parts) > 1:
            sub_path = "/" + "/".join(parts[:-1])
        else:
            sub_path = ""
        if "." in parts[-1]:
            file_name = parts[-1]
        else:
            file_name = ""
            sub_path = "/" + "/".join(parts) if parts else ""
    elif path == "/":
        sub_path = ""
        file_name = ""

    return {
        "domain": domain,
        "sub_path": sub_path if sub_path else None,
        "file_name": file_name if file_name else None,
    }


def is_same_site(url: str, site: str) -> bool:
    """判断 URL 域名是否与站点一致（精确匹配或子域名后缀匹配）"""
    domain = urlparse(url).netloc.replace("www.", "")
    if not domain:
        return False
    return domain == site or domain.endswith("." + site)


# ── 树 JSON 解析 ─────────────────────────────────────


def collect_tree_nodes(tree_root: dict) -> dict[str, dict]:
    """递归遍历 tree_structure，构建 normalized_url → 节点信息索引。

    同一 URL 首次出现时记录其层级信息（树已无全局重复）。

    Returns:
        {normalize_url(url): {url, level, parent_url, is_leaf, node_type, not_found}}
    """
    index: dict[str, dict] = {}

    def walk(node: dict, level: int, parent_url: str | None) -> None:
        url = node.get("url")
        if not url:
            return
        norm = normalize_url(url)
        if norm not in index:
            index[norm] = {
                "url": url,
                "level": level,
                "parent_url": parent_url,
                "is_leaf": 1 if node.get("leaf") else 0,
                "node_type": node.get("type"),
                "not_found": 1 if node.get("not_found") else 0,
            }
        for child in node.get("children", []):
            walk(child, level + 1, url)

    walk(tree_root, 0, None)
    return index


# ── 同步器 ───────────────────────────────────────────


class LinkTreeSyncer(BaseCrawler):
    """链接树增量同步器

    继承 BaseCrawler 复用 Playwright 浏览器生命周期管理（页面验证用）。
    支持 S3 路径的 tree_file 输入。
    NOT_FOUND_TEXTS 从 traversal_rule_config.json 动态加载。
    """

    def __init__(self, headless: bool = True, s3_boundary: S3Boundary | None = None):
        self.headless = headless
        self._browser = None
        self._s3_boundary = s3_boundary

    async def sync(
        self,
        tree_file: str | Path,
        site: str,
    ) -> dict:
        """执行增量同步。

        Args:
            tree_file: tree_structure_{ts}.json 文件路径（支持 s3:// 路径）
            site: 站点域名（如 tokyostarbank.co.jp）

        Returns:
            统计结果 dict：skipped/inserted/marked_pending_delete/
            verified_ok/marked_deleted/errors/total_before/total_after/duplicates
        """
        # ── 加载树 JSON（支持 S3 路径） ─────────────────
        tree_file_str = str(tree_file)
        if tree_file_str.startswith("s3://") and self._s3_boundary is not None:
            content = await self._s3_boundary.download_text(tree_file_str)
            tree_root = json.loads(content)
            logger.info(f"从 S3 加载树结构: {tree_file_str}")
        else:
            tree_path = Path(tree_file)
            if not tree_path.exists():
                raise FileNotFoundError(f"树结构文件不存在: {tree_path}")
            with open(tree_path, "r", encoding="utf-8") as f:
                tree_root = json.load(f)
            logger.info(f"加载本地树结构文件: {tree_path}")

        # ── 从配置文件动态加载 NOT_FOUND_TEXTS ─────────
        traversal_config = load_traversal_config(site)
        not_found_texts = traversal_config.not_found_texts
        logger.info(
            f"开始增量同步: site={site}, "
            f"not_found_texts={'有配置' if not_found_texts else '未配置'}"
        )

        tree_nodes = collect_tree_nodes(tree_root)
        tree_urls = set(tree_nodes.keys())
        logger.info(f"JSON 节点数: {len(tree_urls)}")

        repo = LinkTreeRepository()
        db_urls = set(await repo.list_urls_by_site(site))
        logger.info(f"DB 已有记录数: {len(db_urls)}")

        # 重复检测：DB 内部不应有重复（url UNIQUE 保证），这里仍校验一次
        all_rows = await repo.list_all_by_site(site)
        from collections import Counter
        url_counter = Counter(r.url for r in all_rows)
        duplicates = {u: c for u, c in url_counter.items() if c > 1}

        # 分类
        to_insert = tree_urls - db_urls        # JSON 有 / DB 无 → 新增
        to_check_delete = db_urls - tree_urls  # DB 有 / JSON 无 → 待删除，需验证
        skipped = tree_urls & db_urls          # 都有 → 跳过

        stats = {
            "site": site,
            "tree_file": tree_file_str,
            "tree_nodes": len(tree_urls),
            "db_before": len(db_urls),
            "skipped": len(skipped),
            "inserted": 0,
            "marked_pending_delete": 0,
            "verified_ok": 0,
            "marked_deleted": 0,
            "errors": 0,
            "duplicates_in_db": len(duplicates),
            "duplicate_samples": list(duplicates.keys())[:10],
        }

        # 1. 新增
        if to_insert:
            now = datetime.now()
            new_models: list[CrawlLinkTreeModel] = []
            for norm in to_insert:
                info = tree_nodes[norm]
                parsed = parse_url(info["url"])
                new_models.append(CrawlLinkTreeModel(
                    site=site,
                    url=info["url"],
                    level=info["level"],
                    parent_url=info["parent_url"],
                    is_leaf=info["is_leaf"],
                    node_type=info["node_type"],
                    not_found=info["not_found"],
                    domain=parsed["domain"],
                    sub_path=parsed["sub_path"],
                    file_name=parsed["file_name"],
                    link_type=detect_attachment_type(info["url"]),
                    site_owner="自社" if is_same_site(info["url"], site) else "他社",
                    update_history="新增",
                    update_time_tag=now,
                ))
            # 分批插入
            batch = 500
            for i in range(0, len(new_models), batch):
                await repo.bulk_create(new_models[i:i + batch])
            stats["inserted"] = len(new_models)
            logger.info(f"新增 {stats['inserted']} 条")

        # 2. 待删除 → 页面验证
        if to_check_delete:
            await self._handle_deletions(repo, to_check_delete, stats, not_found_texts)
        else:
            logger.info("无需处理的待删除链接")

        stats["db_after"] = await repo.count_by_site(site)
        logger.info(
            f"同步完成: 新增 {stats['inserted']}, 跳过 {stats['skipped']}, "
            f"待删除 {stats['marked_pending_delete']}, 验证正常 {stats['verified_ok']}, "
            f"已删除 {stats['marked_deleted']}, 错误 {stats['errors']}, "
            f"DB 重复 {stats['duplicates_in_db']}"
        )
        return stats

    async def _handle_deletions(
        self,
        repo: LinkTreeRepository,
        urls: set[str],
        stats: dict,
        not_found_texts: list[str],
    ) -> None:
        """处理待删除链接：先标记"待删除"，再逐个页面验证。

        Args:
            repo: 链接树仓储
            urls: 待验证的 URL 集合
            stats: 统计结果字典（会被修改）
            not_found_texts: 页面"未找到"判定文本列表，从配置动态加载
        """
        now = datetime.now()
        # 先批量标记"待删除"
        for url in urls:
            await repo.update_fields_by_url(
                url, update_history="待删除", update_time_tag=now,
            )
        stats["marked_pending_delete"] = len(urls)
        logger.info(f"已标记 {len(urls)} 条为 待删除，开始页面验证")

        # 逐个页面验证
        async with async_playwright() as p:
            context = await self._setup_browser_context(p)
            page = await context.new_page()
            try:
                for idx, url in enumerate(sorted(urls), start=1):
                    logger.info(f"[{idx}/{len(urls)}] 验证: {url}")
                    result = await self._check_page_status(page, url, not_found_texts)
                    if result == RESULT_OK:
                        # 页面正常：去掉待删除标记，custom_tag 记录验证结果
                        await repo.update_fields_by_url(
                            url,
                            update_history=None,
                            custom_tag="验证页面正常",
                            update_time_tag=datetime.now(),
                        )
                        stats["verified_ok"] += 1
                        logger.info(f"  → 页面正常，去掉待删除标记")
                    else:
                        # 无法访问或提示不存在 → 已删除
                        await repo.update_fields_by_url(
                            url,
                            update_history="已删除",
                            custom_tag=result,
                            update_time_tag=datetime.now(),
                        )
                        stats["marked_deleted"] += 1
                        logger.info(f"  → {result}，标记为 已删除")
                    await page.wait_for_timeout(1000)
            except Exception as e:
                logger.error(f"页面验证过程出错: {e}", exc_info=True)
                stats["errors"] += 1
            finally:
                await self._teardown_browser(context)

    async def _check_page_status(self, page: Page, url: str, not_found_texts: list[str]) -> str:
        """打开页面判断状态（参考 check_tokyostarbank_links.py）。

        Args:
            page: Playwright 页面实例
            url: 要验证的 URL
            not_found_texts: 页面"未找到"判定文本列表，从配置动态加载

        Returns:
            RESULT_OK / RESULT_NOT_FOUND / RESULT_TIMEOUT
        """
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
            await page.wait_for_load_state("domcontentloaded", timeout=30000)
            await page.wait_for_timeout(WAIT_DYNAMIC_MS)
            content = await page.content()
            for text in not_found_texts:
                if text in content:
                    return RESULT_NOT_FOUND
            return RESULT_OK
        except Exception as e:
            logger.warning(f"  页面无法打开: {type(e).__name__}: {e}")
            return RESULT_TIMEOUT
package com.unify.iam.app.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_tenant_domain_challenge 域名验证挑战表 PO（P3）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_tenant_domain_challenge")
public class TenantDomainChallengePO extends BaseEntity {

    private String tenantDomainChallengeId;
    private String tenantDomainId;
    private String challengeType;
    private String challengeStatus;
    private String challengeToken;
    private String challengePayload;
    private LocalDateTime expiresAt;
    private LocalDateTime verifiedAt;
}

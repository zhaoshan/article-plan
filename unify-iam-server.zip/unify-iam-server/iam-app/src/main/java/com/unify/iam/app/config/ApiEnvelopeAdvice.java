package com.unify.iam.app.config;

import com.unify.iam.common.result.CommonResponse;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * 统一信封（docs/user-manual/05）：全部 JSON API 的成功响应包装为
 * {@code {success:true, code, message, data}}；仅 OIDC 重定向流程排除（见 {@link EnvelopePaths}）。
 * 已是 {@link CommonResponse}（异常处理器产出）则跳过，避免二次包装。
 */
@RestControllerAdvice
public class ApiEnvelopeAdvice implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
                                  Class<? extends HttpMessageConverter<?>> selectedConverterType,
                                  ServerHttpRequest request, ServerHttpResponse response) {
        if (!EnvelopePaths.inScope(request.getURI().getPath())) {
            return body;
        }
        if (body instanceof CommonResponse<?>) {
            return body; // 已是信封（错误响应），避免二次包装
        }
        return CommonResponse.success(body);
    }
}

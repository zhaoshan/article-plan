# 分支合并冲突处理说明（2026-10-28）

当前分支 dev/261026_v0.2（2237d14）合入 feature/v0.10.3-m10w3（a220631）。直接处理 Git 合并，不执行 Trellis 流程。

## 解决方案

- 登录：保留当前分支 must_change_password、成员 last_opened_at，叠加来源分支头像和用户级最近登录信息。刷新/切租户不记录交互式登录。
- 租户菜单：保留当前分支完整增强字段、整数 is_default 和 is_current；保留来源分支 tenant_code 与用户/租户隔离行为。
- 创建租户：显式 tenant_code/app_codes 沿用当前分支 JIT Owner 邮箱开通。仅 tenant_name/owner_email 时支持来源分支 PENDING 租户、受控邮件投递、接受后激活。服务层继续校验旧调用的必填字段。
- 成员邀请：默认保留当前分支 JIT 建号、初始密码、默认 Owner、应用跳转和 token 响应。显式 member-invitation.delivery-enabled=true 时支持来源分支严格 SMTP 投递、不回传 token 的邀请流程。两种流程共享邮箱、作用域及应用席位校验。Owner 转移/初始 Owner 邀请按用途分派接受处理。
- 配额：保留 usage/{dimensionId} 与来源分支 quotas/{dimensionKey}、详情聚合接口。保留当前分支种子维度 ID 和默认值；模板限额随已启用应用生效，详情接口显式设置的租户覆盖生效。JIT 已建成员的邀请不重复占席位。
- 租户详情、成员查询投影、Owner 转移、审计过滤、账号资料与管理端密码/角色接口保留来源分支增量；当前分支角色删除双护栏继续保留。
- 两个模块出现同名配额 Repository/Mapper：Repository 显式命名，Mapper 使用完整类名注册，保留两套实现对同一数据表的访问。
- 普通邀请审计记录使用邀请 ID 或 token 哈希，避免把明文 token 写入审计目标。

## 数据库兼容

当前分支 V11–V14 保持不变。合入分支重复的 V11 审计索引顺延到 V17，重复 V12 的邀请用途/投递状态与配额表扩展改为增量 V16，不重建现有表。恢复本地已应用但合并前源码缺失的 V15__invitation_multiple_roles.sql，其 CRC32 与本地 Flyway 记录完全一致（-1352523046）；该恢复仅保证迁移历史可验证，不引入额外多角色业务逻辑。

没有执行 Flyway repair 或关闭校验。启动前本地数据库备份保存到忽略目录 logs/merge-20261028/unify_iam-before-merge.sql，权限 0600。

## 验证

使用本机 JDK 21 执行 mvn test，应用模块 231 项测试全部通过（0 失败、0 错误），其他模块构建和测试成功。覆盖两种邀请流程、Owner 转移/首次开通、配额、登录头像、切租户/刷新、审计、OIDC 与角色删除保护。修复新增测试对共享库数据及旧响应精确字段集合的假设，同时保留当前分支增强字段。

构建、启动日志与运行验证结果见 logs/merge-20261028/。服务通过既有 com.platform-iam.service launchd 作业重启，继续使用既有 RSA 私钥。

## 兼容边界

邀请接口的两种响应形状由服务端显式配置决定；默认以当前分支为准。配额的两个接口共享表与租户覆盖，默认限额及 ID 以当前分支为准。V16/V17 供从当前分支数据库升级；已经应用来源分支原 V11/V12 的其他环境，需要单独核对迁移历史后制定增量升级方案。

## 本地启动结果

2026-10-28 16:17（Asia/Shanghai），launchd 已加载新 JAR，PID 92725，监听 8090。health 与 readiness 均为 HTTP 200 / UP；JWKS 为 HTTP 200，包含 1 把公钥；OpenAPI 为 HTTP 200，包含 58 条路径，原有 usage 与新增 details/quotas/owner 路由同时存在。

-- --------------------------------------------
-- unify-iam-server E2E-1 schema（V1）
-- 数据库：MySQL 8.x；schema：unify_iam（由 datasource 指定，本脚本不写 USE）
-- 来源：20260825-Gateway-Tenant-IAM-schema-mysql.sql（去掉 USE、去掉存量库兼容注释）
-- 范围：只建 E2E-1 的 8 张核心表；tenant_domain / idp_config / invitation / audit_log 等后置
-- 约定：自增 id + {表名}_id CHAR(32) 业务唯一键 + 公共字段；不强依赖物理外键；delete_flag 逻辑删除
-- --------------------------------------------

SET NAMES utf8mb4;

-- ============================================================
-- 1. 用户主表：自然人账号本体 + 默认租户入口
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_user` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键（内部关联与分页使用）',
  `user_id` CHAR(32) NOT NULL COMMENT '用户业务唯一标识（UUID，无横线 32 位）',
  `username` VARCHAR(255) NOT NULL COMMENT '平台登录名；可等于邮箱，也可为企业侧指定账号名/UPN',
  `primary_email` VARCHAR(255) DEFAULT NULL COMMENT '主邮箱；推荐统一小写后写入，作为用户主联系邮箱',
  `password_hash` VARCHAR(255) DEFAULT NULL COMMENT '本地密码摘要（如 BCrypt）；纯 SSO 账号可为空',
  `full_name` VARCHAR(128) DEFAULT NULL COMMENT '用户全名/实名',
  `display_name` VARCHAR(128) DEFAULT NULL COMMENT '前端展示名称；可用于昵称或企业展示名',
  `avatar_url` VARCHAR(512) DEFAULT NULL COMMENT '头像地址；可来自用户资料或外部 IdP',
  `phone_number` VARCHAR(64) DEFAULT NULL COMMENT '手机号；可选',
  `locale` VARCHAR(32) DEFAULT NULL COMMENT '语言偏好；如 zh-CN/en-US',
  `time_zone` VARCHAR(64) DEFAULT NULL COMMENT '时区；如 Asia/Shanghai/UTC',
  `tenant_id` CHAR(32) DEFAULT NULL COMMENT '兼容字段：历史 workspaceId；迁移期可镜像 default_tenant_id',
  `default_tenant_id` CHAR(32) DEFAULT NULL COMMENT '默认进入的 tenant_id；真正的多租户入口语义',
  `email_verified` TINYINT NOT NULL DEFAULT 0 COMMENT '主邮箱是否已验证：0否 1是',
  `user_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '账号状态：PENDING/ACTIVE/SUSPENDED/DELETED',
  `auth_provider` VARCHAR(32) DEFAULT NULL COMMENT '兼容字段：历史主登录来源；如 password/google/microsoft',
  `last_login_provider` VARCHAR(64) DEFAULT NULL COMMENT '最近一次登录提供方：password/google/microsoft/okta/keycloak 等',
  `registration_source` VARCHAR(16) NOT NULL DEFAULT 'SELF_SERVICE' COMMENT '注册来源：SELF_SERVICE/INVITE/SSO/JIT/ADMIN/IMPORT',
  `last_login_time` DATETIME DEFAULT NULL COMMENT '最近一次登录时间',
  `activated_at` DATETIME DEFAULT NULL COMMENT '账号激活时间',
  `suspended_at` DATETIME DEFAULT NULL COMMENT '账号停用时间',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_user_id` (`user_id`),
  UNIQUE KEY `uk_gateway_user_username` (`username`),
  UNIQUE KEY `uk_gateway_user_primary_email` (`primary_email`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_default_tenant_id` (`default_tenant_id`),
  KEY `idx_user_status` (`user_status`),
  KEY `idx_auth_provider` (`auth_provider`),
  KEY `idx_last_login_provider` (`last_login_provider`),
  KEY `idx_delete_flag` (`delete_flag`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户主表；仅承载自然人账号本体与默认租户入口，不再承载成员关系与角色权限';

-- ============================================================
-- 2. 租户主表：个人空间 / 企业空间统一抽象
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_tenant` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `tenant_id` CHAR(32) NOT NULL COMMENT '租户业务唯一标识（UUID，无横线 32 位）',
  `tenant_code` VARCHAR(64) NOT NULL COMMENT '租户编码/slug；用于 URL、外部展示或后台检索',
  `tenant_name` VARCHAR(128) NOT NULL COMMENT '租户名称；个人租户可默认取用户昵称，企业租户取公司名',
  `tenant_type` VARCHAR(16) NOT NULL COMMENT '租户类型：PERSONAL/ORGANIZATION',
  `tenant_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '租户状态：PENDING/ACTIVE/SUSPENDED/DELETED',
  `registration_source` VARCHAR(16) NOT NULL DEFAULT 'SELF_SERVICE' COMMENT '注册来源：SELF_SERVICE/ADMIN/IMPORT/SALES',
  `owner_user_id` CHAR(32) DEFAULT NULL COMMENT '首个拥有者用户ID；逻辑关联 gateway_user.user_id',
  `primary_domain` VARCHAR(255) DEFAULT NULL COMMENT '主域名；企业租户可为空，待验证后回填',
  `join_policy` VARCHAR(16) NOT NULL DEFAULT 'INVITE_ONLY' COMMENT '加入策略：INVITE_ONLY/DOMAIN_REQUEST/DOMAIN_AUTO_JOIN/SSO_ONLY',
  `sso_required` TINYINT NOT NULL DEFAULT 0 COMMENT '是否强制走企业 SSO：0否 1是',
  `billing_plan_code` VARCHAR(64) DEFAULT NULL COMMENT '计费套餐编码；可为空，供后续商业化使用',
  `settings_json` JSON DEFAULT NULL COMMENT '租户级配置 JSON；如品牌、默认语言、功能开关等',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_tenant_id` (`tenant_id`),
  UNIQUE KEY `uk_gateway_tenant_code` (`tenant_code`),
  KEY `idx_tenant_type_status` (`tenant_type`, `tenant_status`),
  KEY `idx_owner_user_id` (`owner_user_id`),
  KEY `idx_primary_domain` (`primary_domain`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户主表（个人空间 / 企业空间统一抽象）';

-- ============================================================
-- 3. 用户与租户成员关系：一个用户可加入多个租户
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_membership` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `membership_id` CHAR(32) NOT NULL COMMENT '成员关系业务唯一标识',
  `tenant_id` CHAR(32) NOT NULL COMMENT '所属租户ID；逻辑关联 gateway_tenant.tenant_id',
  `user_id` CHAR(32) NOT NULL COMMENT '所属用户ID；逻辑关联 gateway_user.user_id',
  `membership_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '成员状态：PENDING/ACTIVE/SUSPENDED/REMOVED',
  `join_source` VARCHAR(16) NOT NULL DEFAULT 'SELF_REGISTER' COMMENT '加入来源：SELF_REGISTER/INVITE/SSO/JIT/ADMIN/IMPORT',
  `is_default` TINYINT NOT NULL DEFAULT 0 COMMENT '是否默认进入该租户：0否 1是',
  `invited_by_user_id` CHAR(32) DEFAULT NULL COMMENT '邀请人用户ID',
  `approved_by_user_id` CHAR(32) DEFAULT NULL COMMENT '审批人用户ID',
  `joined_at` DATETIME DEFAULT NULL COMMENT '正式加入时间',
  `suspended_at` DATETIME DEFAULT NULL COMMENT '暂停时间',
  `left_at` DATETIME DEFAULT NULL COMMENT '离开/移除时间',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_membership_id` (`membership_id`),
  UNIQUE KEY `uk_gateway_membership_tenant_user` (`tenant_id`, `user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_membership_status` (`membership_status`),
  KEY `idx_tenant_default` (`tenant_id`, `is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户与租户的成员关系表；支持一个用户加入多个租户';

-- ============================================================
-- 4. 用户外部身份 / 本地身份绑定
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_user_identity` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_identity_id` CHAR(32) NOT NULL COMMENT '用户身份绑定业务唯一标识',
  `user_id` CHAR(32) NOT NULL COMMENT '所属用户ID；逻辑关联 gateway_user.user_id',
  `provider_type` VARCHAR(16) NOT NULL COMMENT '身份协议类型：LOCAL/OIDC/SAML',
  `provider_key` VARCHAR(64) NOT NULL COMMENT '身份提供方标识：password/google/microsoft/okta/keycloak/auth0/custom',
  `issuer` VARCHAR(255) DEFAULT NULL COMMENT 'OIDC/SAML issuer / entityId；本地密码登录可为空',
  `subject` VARCHAR(255) DEFAULT NULL COMMENT '外部身份主键；推荐存 OIDC sub 或 SAML NameID',
  `external_tenant_key` VARCHAR(128) DEFAULT NULL COMMENT '外部 IdP 的组织/租户标识；如 Azure tid',
  `login_name` VARCHAR(255) DEFAULT NULL COMMENT '外部登录名；如 email / upn / preferred_username',
  `email_at_idp` VARCHAR(255) DEFAULT NULL COMMENT '身份提供方返回的邮箱',
  `email_verified` TINYINT NOT NULL DEFAULT 0 COMMENT '邮箱是否在 IdP 侧已验证：0否 1是',
  `full_name_at_idp` VARCHAR(255) DEFAULT NULL COMMENT 'IdP 侧展示名',
  `phone_at_idp` VARCHAR(64) DEFAULT NULL COMMENT 'IdP 侧手机号',
  `identity_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '身份绑定状态：ACTIVE/DISABLED/REVOKED',
  `claims_json` JSON DEFAULT NULL COMMENT '原始或裁剪后的 claims 快照；用于审计与排障',
  `last_login_at` DATETIME DEFAULT NULL COMMENT '最近一次使用该身份登录时间',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_user_identity_id` (`user_identity_id`),
  UNIQUE KEY `uk_gateway_identity_provider_subject` (`provider_type`, `provider_key`, `issuer`, `subject`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_email_at_idp` (`email_at_idp`),
  KEY `idx_identity_status` (`identity_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户外部身份 / 本地身份绑定表；支持 password、OIDC、SAML 并存';

-- ============================================================
-- 5. 角色表：平台级 / 租户级角色
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_role` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `role_id` CHAR(32) NOT NULL COMMENT '角色业务唯一标识',
  `scope_type` VARCHAR(16) NOT NULL COMMENT '作用域类型：PLATFORM/TENANT',
  `scope_id` CHAR(32) NOT NULL COMMENT '作用域标识；scope_type=TENANT 时取 tenant_id，PLATFORM 时可固定为 PLATFORM',
  `role_code` VARCHAR(64) NOT NULL COMMENT '角色编码；如 TENANT_ADMIN/BUILDER/VIEWER',
  `role_name` VARCHAR(128) NOT NULL COMMENT '角色名称',
  `role_description` VARCHAR(512) DEFAULT NULL COMMENT '角色描述',
  `is_builtin` TINYINT NOT NULL DEFAULT 0 COMMENT '是否内置角色：0否 1是',
  `role_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '角色状态：ACTIVE/DISABLED',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_role_id` (`role_id`),
  UNIQUE KEY `uk_gateway_role_scope_code` (`scope_type`, `scope_id`, `role_code`),
  KEY `idx_scope_type_scope_id` (`scope_type`, `scope_id`),
  KEY `idx_role_status` (`role_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色表；既可承载平台级角色，也可承载租户级角色';

-- ============================================================
-- 6. 权限字典表：功能权限点
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_permission` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `permission_id` CHAR(32) NOT NULL COMMENT '权限业务唯一标识',
  `permission_code` VARCHAR(128) NOT NULL COMMENT '权限编码；如 agent.build.edit / tenant.member.invite',
  `resource_type` VARCHAR(64) NOT NULL COMMENT '资源类型；如 TENANT/USER/AGENT/KNOWLEDGE/OPENAPI',
  `action` VARCHAR(64) NOT NULL COMMENT '动作；如 VIEW/EDIT/DELETE/INVITE/DEPLOY',
  `permission_name` VARCHAR(128) NOT NULL COMMENT '权限名称',
  `permission_description` VARCHAR(512) DEFAULT NULL COMMENT '权限描述',
  `is_builtin` TINYINT NOT NULL DEFAULT 1 COMMENT '是否内置权限：0否 1是',
  `permission_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '权限状态：ACTIVE/DISABLED',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_permission_id` (`permission_id`),
  UNIQUE KEY `uk_gateway_permission_code` (`permission_code`),
  KEY `idx_resource_type_action` (`resource_type`, `action`),
  KEY `idx_permission_status` (`permission_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限字典表';

-- ============================================================
-- 7. 角色与权限关联表
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_role_permission` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `role_permission_id` CHAR(32) NOT NULL COMMENT '角色权限关系业务唯一标识',
  `role_id` CHAR(32) NOT NULL COMMENT '角色ID；逻辑关联 gateway_role.role_id',
  `permission_id` CHAR(32) NOT NULL COMMENT '权限ID；逻辑关联 gateway_permission.permission_id',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_role_permission_id` (`role_permission_id`),
  UNIQUE KEY `uk_gateway_role_permission_pair` (`role_id`, `permission_id`),
  KEY `idx_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='角色与权限关联表';

-- ============================================================
-- 8. 成员与角色关联表
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_membership_role` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `membership_role_id` CHAR(32) NOT NULL COMMENT '成员角色关系业务唯一标识',
  `membership_id` CHAR(32) NOT NULL COMMENT '成员关系ID；逻辑关联 gateway_membership.membership_id',
  `role_id` CHAR(32) NOT NULL COMMENT '角色ID；逻辑关联 gateway_role.role_id',
  `grant_source` VARCHAR(16) NOT NULL DEFAULT 'DIRECT' COMMENT '授予来源：DIRECT/GROUP/IDP_SYNC',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_membership_role_id` (`membership_role_id`),
  UNIQUE KEY `uk_gateway_membership_role_pair` (`membership_id`, `role_id`),
  KEY `idx_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成员与角色关联表';

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import com.unify.iam.api.dto.auth.LoginRequest;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.app.service.RefreshTokenService;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.app.authenticator.LocalPasswordAuthenticator;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.authorization.app.model.RbacResult;
import com.unify.iam.authorization.app.service.RbacResolver;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TokenServiceTest {

    @Mock
    private LocalPasswordAuthenticator localPasswordAuthenticator;
    @Mock
    private MembershipResolver membershipResolver;
    @Mock
    private RbacResolver rbacResolver;
    @Mock
    private JwtSigner jwtSigner;
    @Mock
    private RefreshTokenService refreshTokenService;
    @Mock
    private TenantApplicationRepository tenantApplicationRepository;
    @Mock
    private com.unify.iam.identity.infra.persistence.repository.UserRepository userRepository;
    @Mock
    private com.unify.iam.tenant.infra.persistence.repository.MembershipRepository membershipRepository;

    private final IamProperties props = new IamProperties();
    private TokenService tokenService;

    @BeforeEach
    void setUp() {
        tokenService = new TokenService(localPasswordAuthenticator, membershipResolver,
                rbacResolver, jwtSigner, refreshTokenService, props, tenantApplicationRepository, userRepository,
                membershipRepository);
        com.unify.iam.identity.infra.persistence.po.UserPO user = new com.unify.iam.identity.infra.persistence.po.UserPO();
        user.setUserId("u-1001");
        user.setMustChangePassword(0);
        lenient().when(userRepository.findByUserId(anyString())).thenReturn(java.util.Optional.of(user));
    }

    private UserPrincipal operator() {
        return new UserPrincipal("u-1001", "operator", "id-2001");
    }

    private MembershipPO membership() {
        MembershipPO m = new MembershipPO();
        m.setMembershipId("ms-2001");
        m.setTenantId("tenant-org-a");
        m.setUserId("u-1001");
        m.setMembershipStatus("ACTIVE");
        return m;
    }

    private RbacResult agentOperatorRbac() {
        return RbacResult.of(List.of("AgentOperator"), List.of(
                "agent:read", "agent:build", "agent:publish", "agent:delete",
                "session:read", "session:send", "customer:manage", "trace:read", "settings:read"));
    }

    @Test
    void issueAssemblesFullClaimsAndResponse() {
        when(localPasswordAuthenticator.authenticate("operator", "op123")).thenReturn(operator());
        when(membershipResolver.findDefaultActiveMembership("u-1001")).thenReturn(Optional.of(membership()));
        when(rbacResolver.resolve("ms-2001")).thenReturn(agentOperatorRbac());
        when(tenantApplicationRepository.findAppCodesByTenant("tenant-org-a"))
                .thenReturn(List.of("parlant-agent-server"));
        when(jwtSigner.sign(any(JwtClaims.class))).thenReturn("signed-token");

        LoginResponse resp = tokenService.issue(new LoginRequest("operator", "op123"));

        assertThat(resp.accessToken()).isEqualTo("signed-token");
        assertThat(resp.tokenType()).isEqualTo("bearer");
        assertThat(resp.expiresIn()).isEqualTo(7200L);
        assertThat(resp.user().userId()).isEqualTo("u-1001");
        assertThat(resp.user().userName()).isEqualTo("operator");
        assertThat(resp.user().roles()).containsExactly("AgentOperator");
        assertThat(resp.user().permissions()).hasSize(9);

        ArgumentCaptor<JwtClaims> captor = ArgumentCaptor.forClass(JwtClaims.class);
        verify(jwtSigner).sign(captor.capture());
        JwtClaims claims = captor.getValue();
        assertThat(claims.iss()).isEqualTo("https://www.identityfabric.com");
        assertThat(claims.aud()).isEqualTo(List.of("parlant-agent-server"));
        assertThat(claims.sub()).isEqualTo("u-1001");
        assertThat(claims.tenantId()).isEqualTo("tenant-org-a");
        assertThat(claims.membershipId()).isEqualTo("ms-2001");
        assertThat(claims.roles()).containsExactly("AgentOperator");
        assertThat(claims.permissions()).hasSize(9);
        assertThat(claims.attrs()).isEmpty();
        assertThat(claims.exp() - claims.iat()).isEqualTo(7200L);
        assertThat(claims.jti()).isNotBlank();
    }

    @Test
    void wrongPasswordPropagates401() {
        when(localPasswordAuthenticator.authenticate(eq("operator"), eq("wrong")))
                .thenThrow(AuthException.unauthorized("用户名或密码错误"));

        assertThatThrownBy(() -> tokenService.issue(new LoginRequest("operator", "wrong")))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
    }

    @Test
    void noMembershipThrows401() {
        when(localPasswordAuthenticator.authenticate("operator", "op123")).thenReturn(operator());
        when(membershipResolver.findDefaultActiveMembership("u-1001")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> tokenService.issue(new LoginRequest("operator", "op123")))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
    }

    @Test
    void multiRolePermissionsAreDedupedAndSorted() {
        when(localPasswordAuthenticator.authenticate("operator", "op123")).thenReturn(operator());
        when(membershipResolver.findDefaultActiveMembership("u-1001")).thenReturn(Optional.of(membership()));
        // 两角色 union 后：SQL 层已 DISTINCT + ORDER BY，这里模拟返回有序去重结果
        when(rbacResolver.resolve("ms-2001"))
                .thenReturn(RbacResult.of(List.of("AgentOperator", "TenantAdmin"),
                        List.of("agent:read", "agent:publish", "session:read", "settings:read")));
        when(jwtSigner.sign(any(JwtClaims.class))).thenReturn("t");

        tokenService.issue(new LoginRequest("operator", "op123"));

        ArgumentCaptor<JwtClaims> captor = ArgumentCaptor.forClass(JwtClaims.class);
        verify(jwtSigner).sign(captor.capture());
        assertThat(captor.getValue().roles()).containsExactly("AgentOperator", "TenantAdmin");
        assertThat(captor.getValue().permissions()).containsExactly(
                "agent:read", "agent:publish", "session:read", "settings:read");
    }
}

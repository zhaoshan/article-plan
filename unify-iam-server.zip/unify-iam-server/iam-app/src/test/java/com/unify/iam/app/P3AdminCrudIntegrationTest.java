package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * P3 管理面全量 CRUD 集成测试：用户 / 租户 / 角色 / 成员 + 授权，及非管理员 403。
 */
class P3AdminCrudIntegrationTest extends IamIntegrationTestBase {

    private String adminToken() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"admin123\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminPost(String url, Object body, String token) throws Exception {
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        // 统一信封：admin 接口已套 {success,code,message,data}，返回 data 子体便于后续解析
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    @Test
    void fullCrudCycleForUsersTenantsRolesMembers() throws Exception {
        String token = adminToken();

        // ① 建用户
        String createdUser = adminPost("/api/v1/admin/users",
                Map.of("username", "crud_user1", "email", "crud@unify.local", "password", "Passw0rd!"), token);
        String userId = JsonUtils.fromJson(createdUser, Map.class).get("user_id").toString();
        mockMvc.perform(get("/api/v1/admin/users/" + userId).header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.username").value("crud_user1"));

        // ② 建租户
        String createdTenant = adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "crud-tenant", "tenant_name", "Crud Tenant", "tenant_type", "ORGANIZATION",
                        "app_codes", java.util.List.of("parlant-agent-server")), token);
        String tenantId = JsonUtils.fromJson(createdTenant, Map.class).get("tenant_id").toString();
        // 共享单例容器下租户会累积超默认 100 → 显式大 limit（平台管理面列表，非分页场景）
        mockMvc.perform(get("/api/v1/admin/tenants").param("limit", "500").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenants[?(@.tenant_id == '" + tenantId + "')]").exists());

        // ③ 建角色 + 授权
        String createdRole = adminPost("/api/v1/admin/roles",
                Map.of("scope_type", "TENANT", "scope_id", tenantId, "role_code", "CrudRole", "role_name", "CRUD 角色"), token);
        String roleId = JsonUtils.fromJson(createdRole, Map.class).get("role_id").toString();
        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"permission_ids\":[\"p-1001\",\"p-1003\"]}"))
                .andExpect(status().isOk());

        // ④ 加成员 + 授角色
        String createdMember = adminPost("/api/v1/admin/members",
                Map.of("tenant_id", tenantId, "user_id", userId, "role_ids", java.util.List.of(roleId)), token);
        String membershipId = JsonUtils.fromJson(createdMember, Map.class).get("membership_id").toString();
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.members[?(@.membership_id == '" + membershipId + "')]").exists());

        // ⑤ 移除成员
        mockMvc.perform(delete("/api/v1/admin/members/" + membershipId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());

        // 审计落库
        Integer audit = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_audit_log WHERE event_type IN ('ADMIN_CREATE_USER','ADMIN_CREATE_TENANT','ADMIN_CREATE_ROLE','ADMIN_ADD_MEMBER')",
                Integer.class);
        assertThat(audit).isGreaterThanOrEqualTo(4);
    }

    /**
     * 成员角色覆盖式替换（docs/06 §3.3）：撤旧 + 增新 + 重授都要生效。
     * 回归：@TableLogic 字段会被 updateById 的 SET 剔除，setDeleteFlag+updateById 是静默空操作，
     * 曾致「回收不生效」（旧角色撤不掉，成员角色只增不减）；软删墓碑占唯一键又致「重授静默失败」——
     * 现回收走 deleteById（@TableLogic 转 UPDATE delete_flag=1）、重授走 revive 复活墓碑。
     */
    @Test
    void memberRolesReplaceRevokesAndRegrants() throws Exception {
        String token = adminToken();

        // 自建用户 + 加入 seed 租户 tenant-org-a（不动 seed 成员 ms-1001/2001/3001 的角色）
        String userId = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                Map.of("username", "repl_user1", "email", "repl@unify.local", "password", "Passw0rd!"), token),
                Map.class).get("user_id").toString();
        String membershipId = JsonUtils.fromJson(adminPost("/api/v1/admin/members",
                Map.of("tenant_id", "tenant-org-a", "user_id", userId, "role_ids", java.util.List.of("r-1003")), token),
                Map.class).get("membership_id").toString();

        // 初始：Viewer(r-1003)
        assertMemberRoles(token, membershipId, "r-1003");

        // 覆盖式替换 → [r-1001]：r-1003 必须被回收（回归点：updateById 不写 delete_flag）
        mockMvc.perform(put("/api/v1/admin/members/" + membershipId + "/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"r-1001\"]}"))
                .andExpect(status().isOk());
        assertMemberRoles(token, membershipId, "r-1001");

        // 再替换回 [r-1003]：r-1001 回收 + r-1003 墓碑复活（回归点：唯一键占位，重授走 revive 而非重插）
        mockMvc.perform(put("/api/v1/admin/members/" + membershipId + "/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"r-1003\"]}"))
                .andExpect(status().isOk());
        assertMemberRoles(token, membershipId, "r-1003");

        // 无重复绑定：每个 (membership_id, role_id) 恰一行 delete_flag=0（墓碑+重授不产生双活行）
        Integer active = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role WHERE membership_id = ? AND delete_flag = 0",
                Integer.class, membershipId);
        assertThat(active).isEqualTo(1);
    }

    private void assertMemberRoles(String token, String membershipId, String... expectedRoleIds) throws Exception {
        MvcResult res = mockMvc.perform(get("/api/v1/admin/members/" + membershipId + "/roles")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn();
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> roles = (List<Map<String, Object>>) unwrapData(
                res.getResponse().getContentAsString()).get("roles");
        assertThat(roles).extracting(m -> m.get("role_id"))
                .containsExactlyInAnyOrder(expectedRoleIds);
    }

    @Test
    void nonAdminForbiddenOnAllCrud() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"viewer\",\"password\":\"view123\"}"))
                .andExpect(status().isOk())
                .andReturn();
        String viewerToken = JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();

        mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + viewerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"x\",\"password\":\"y\"}"))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + viewerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"t\",\"tenant_name\":\"t\"}"))
                .andExpect(status().isForbidden());
        mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + viewerToken))
                .andExpect(status().isForbidden());
    }

    @Test
    void catalogDirectoryAndMemberUsername() throws Exception {
        String admin = adminToken();

        // ① 应用目录（建租户表单用）：parlant + 3 个预置角色
        mockMvc.perform(get("/api/v1/admin/applications").header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.applications[?(@.app_code == 'parlant-agent-server')].roles.length()")
                        .value(org.hamcrest.Matchers.hasItem(3)))
                .andExpect(jsonPath("$.data.applications[?(@.app_code == 'parlant-agent-server')].roles[?(@.role_code == 'TenantAdmin')].is_owner")
                        .value(org.hamcrest.Matchers.hasItem("1")));

        // ② 用户目录检索（member:read）：按 username 模糊命中 operator
        mockMvc.perform(get("/api/v1/admin/user-directory").param("search", "op")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.users[?(@.username == 'operator')]").exists());

        // ③ 成员列表补 username
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.members[?(@.user_id == 'u-1000')].username")
                        .value(org.hamcrest.Matchers.hasItem("admin")))
                // ③b 成员列表带当前租户角色（admin 在 tenant-org-a 有 PlatformAdmin）
                .andExpect(jsonPath("$.data.members[?(@.user_id == 'u-1000')].roles[?(@.role_code == 'PlatformAdmin')].role_name")
                        .value(org.hamcrest.Matchers.hasItem("Platform Admin")));

        // ③b 权限点目录（角色授权清单）：业务码 + iam:* 都在
        mockMvc.perform(get("/api/v1/admin/permissions").header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.permissions[?(@.permission_code == 'agent:read')]").exists())
                .andExpect(jsonPath("$.data.permissions[?(@.permission_code == 'iam:member:write')]").exists());

        // ④ 租户管理员（新建租户首人）可访问用户目录 + 成员列表带 username（无 iam:user:read 也能找人）
        String ownerUserId = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                Map.of("username", "dir_owner", "email", "dir-owner@unify.local", "password", "Passw0rd!"), admin),
                Map.class).get("user_id").toString();
        String tenantId = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "dir-tenant", "tenant_name", "Dir Tenant",
                        "owner_user_id", ownerUserId, "app_codes", List.of("parlant-agent-server")), admin),
                Map.class).get("tenant_id").toString();
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"dir_owner\",\"password\":\"Passw0rd!\"}"))
                .andExpect(status().isOk())
                .andReturn();
        String ownerToken = JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
        mockMvc.perform(get("/api/v1/admin/user-directory").param("search", "admin")
                        .header("Authorization", "Bearer " + ownerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.users[?(@.username == 'admin')]").exists());
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", tenantId)
                        .header("Authorization", "Bearer " + ownerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.members[?(@.user_id == '" + ownerUserId + "')].username")
                        .value(org.hamcrest.Matchers.hasItem("dir_owner")));
    }

    @Test
    void inviteValidatesDefaultRoleInTenant() throws Exception {
        String admin = adminToken();
        // 建租户（角色为 UUID 风格 id）
        String tenantId = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "inv-tenant", "tenant_name", "Inv Tenant",
                        "app_codes", List.of("parlant-agent-server")), admin),
                Map.class).get("tenant_id").toString();
        // 取该租户 Viewer 角色 id
        String rolesBody = mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        String viewerRoleId = ((List<Map<String, Object>>) unwrapData(rolesBody).get("roles"))
                .stream().filter(r -> "Viewer".equals(r.get("role_code")))
                .map(r -> r.get("role_id").toString()).findFirst().orElseThrow();

        // ① 合法：默认角色属于该租户 → 200，且入库 = 所选角色
        adminPost("/api/v1/admin/invitations", Map.of(
                "email", "inv-role@unify.local", "tenant_id", tenantId, "role_id", viewerRoleId), admin);
        String stored = jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE email='inv-role@unify.local' ORDER BY id DESC LIMIT 1",
                String.class);
        assertThat(stored).isEqualTo(viewerRoleId);

        // ② 非法：默认角色不存在 → 400
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "email", "inv-bad@unify.local", "tenant_id", tenantId, "role_id", "no-such-role"))))
                .andExpect(status().isBadRequest());

        // ③ 非法：他租户角色 → 400
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "email", "inv-bad2@unify.local", "tenant_id", "tenant-org-a",
                                "role_id", viewerRoleId))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void tenantRoleCannotGrantPlatformOnlyPermissions() throws Exception {
        String admin = adminToken();
        // 建租户（启用 parlant）+ 租户内角色
        String tenantId = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "iso-tenant", "tenant_name", "Iso Tenant",
                        "app_codes", List.of("parlant-agent-server")), admin),
                Map.class).get("tenant_id").toString();
        String roleId = JsonUtils.fromJson(adminPost("/api/v1/admin/roles", Map.of(
                "scope_type", "TENANT", "scope_id", tenantId,
                "role_code", "IsoRole", "role_name", "隔离角色"), admin),
                Map.class).get("role_id").toString();

        // ① 平台专属 iam:user:write（p-2002）→ 400（防提权）
        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("permission_ids", List.of("p-2002")))))
                .andExpect(status().isBadRequest());
        // ①b iam:tenant:write（p-2004）→ 400
        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("permission_ids", List.of("p-2004")))))
                .andExpect(status().isBadRequest());

        // ② 本租户已开通应用的业务权限（p-1001/p-1003）→ 200
        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("permission_ids", List.of("p-1001", "p-1003")))))
                .andExpect(status().isOk());

        // ③ 租户内管理权限 iam:member:write（p-2006，tenant_grantable=1）→ 200
        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("permission_ids", List.of("p-2006")))))
                .andExpect(status().isOk());

        // ④ 租户已开通应用列表（角色配置按应用隔离的数据源）
        mockMvc.perform(get("/api/v1/admin/tenants/" + tenantId + "/applications")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.applications[?(@.app_code == 'parlant-agent-server')].app_name")
                        .value(org.hamcrest.Matchers.hasItem("Parlant Agent Server")));
    }
}
"""Pydantic 模型校验测试"""

import pytest
from pydantic import ValidationError
from src.models.crawl_request import CrawlRequest
from src.models.traversal_config import DomainTraversalConfig
from src.models.crawl_task import CrawlTask, TaskProgress
from src.models.crawl_result import TreeNode
from src.models.api_response import DefaultResult


class TestCrawlRequest:
    """CrawlRequest 校验测试"""

    def test_valid_request(self):
        """合法请求"""
        req = CrawlRequest(target_url="https://example.com")
        assert req.target_url == "https://example.com"
        assert req.output_type == "local"
        assert req.headless is True

    def test_defaults(self):
        """默认值"""
        req = CrawlRequest(target_url="https://example.com")
        assert req.output_type == "local"
        assert req.headless is True
        assert req.max_depth is None  # 不传时默认 None，表示使用配置文件值

    def test_max_depth_override(self):
        """传入 max_depth 覆盖配置"""
        req = CrawlRequest(target_url="https://example.com", max_depth=3)
        assert req.max_depth == 3

    def test_max_depth_zero_means_unlimited(self):
        """max_depth=0 表示不限深度"""
        req = CrawlRequest(target_url="https://example.com", max_depth=0)
        assert req.max_depth == 0

    def test_max_depth_negative_raises(self):
        """max_depth 不能为负数"""
        with pytest.raises(ValidationError):
            CrawlRequest(target_url="https://example.com", max_depth=-1)

    def test_invalid_url_scheme(self):
        """非法 URL 协议"""
        with pytest.raises(ValidationError):
            CrawlRequest(target_url="ftp://example.com")

    def test_empty_url(self):
        """空 URL"""
        with pytest.raises(ValidationError):
            CrawlRequest(target_url="")

    def test_invalid_output_type(self):
        """非法 output_type"""
        with pytest.raises(ValidationError):
            CrawlRequest(target_url="https://example.com", output_type="ftp")


class TestDomainTraversalConfig:
    """DomainTraversalConfig 测试"""

    def test_defaults(self):
        """默认值"""
        config = DomainTraversalConfig()
        assert config.need_outer_site is True
        assert config.outer_site_whitelist == []
        assert config.drill_down_levels == 0

    def test_negative_drill_down_raises(self):
        """drill_down_levels 不能为负数"""
        with pytest.raises(ValidationError):
            DomainTraversalConfig(drill_down_levels=-1)


class TestCrawlTask:
    """CrawlTask 测试"""

    def test_default_status(self):
        """默认状态"""
        task = CrawlTask(target_url="https://example.com")
        assert task.status == "pending"
        assert task.progress.pages_crawled == 0
        assert task.progress.links_found == 0

    def test_task_id_is_generated(self):
        """task_id 自动生成"""
        task1 = CrawlTask(target_url="https://a.com")
        task2 = CrawlTask(target_url="https://b.com")
        assert task1.task_id != task2.task_id


class TestTreeNode:
    """TreeNode 测试"""

    def test_basic_node(self):
        """基本节点"""
        node = TreeNode(url="https://example.com")
        assert node.url == "https://example.com"
        assert node.children == []
        assert node.leaf is False

    def test_leaf_node(self):
        """叶子节点"""
        node = TreeNode(url="https://other.com", leaf=True, type="cross_domain")
        assert node.leaf is True
        assert node.type == "cross_domain"


class TestDefaultResult:
    """DefaultResult 测试"""

    def test_defaults(self):
        """默认值"""
        result = DefaultResult()
        assert result.code == "0000"
        assert result.message == "SUCCESS"
        assert result.data is None

    def test_with_data(self):
        """带数据"""
        result = DefaultResult(data={"key": "value"})
        assert result.data == {"key": "value"}

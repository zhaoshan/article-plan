-- ============================================================
-- unify-iam-server 本地 Keycloak 联调 seed（【手动执行】，非 Flyway 迁移）
-- 位置：scripts/seed_sso_keycloak_dev.sql
--
-- 为什么不做成迁移：环境相关 + 带 DEV 占位符，且常被手工二次调整；作为 Flyway V4 时
-- "迁移一旦应用便不可改"导致 checksum 失配。改为幂等手动脚本，可安全重复执行。
--
-- 前提：
--   - 库已应用 V1-V3（gateway_tenant / idp_config / idp_group_mapping 等表存在）
--   - Keycloak 起在 8099；realm=org-a；client `iam`（Standard flow；
--     Valid redirect URIs 含 http://localhost:8090/api/v1/auth/oidc/callback）
--   - realm 内用户 alice@org-a.com（Email verified=ON）
--   - 组 agent-operators 已建；client 已配 Group Membership mapper
--     （Token Claim Name=groups、Add to ID token=ON）
--
-- 执行（幂等，重复执行无副作用）：
--   mysql -uroot -p*** < scripts/seed_sso_keycloak_dev.sql
--   或 docker exec spring-ai-alibaba-mysql sh -c 'mysql -uroot -p$$$PWD < /dev/stdin' < scripts/seed_sso_keycloak_dev.sql
--
-- 注意：client_secret_cipher 为 DEV 占位，P2 实现按其直作明文密钥；生产必须加密/密钥管理。
-- ============================================================

USE `unify_iam`;
SET NAMES utf8mb4;

-- ① 租户域名路由：让 tenant-org-a 可按域名 org-a.com 命中（E2E-1 seed 的 primary_domain 为空）
UPDATE `gateway_tenant`
   SET `primary_domain` = 'org-a.com'
 WHERE `tenant_id` = 'tenant-org-a';

-- ② 预置 Keycloak `org-a` realm 的 IdP 配置（挂在 tenant-org-a；存在则跳过，幂等）
INSERT IGNORE INTO `gateway_tenant_idp_config`
  (`tenant_idp_config_id`, `tenant_id`, `protocol`, `provider_key`, `display_name`, `config_status`,
   `issuer`, `discovery_uri`, `jwk_set_uri`, `authorization_endpoint`, `token_endpoint`,
   `client_id`, `client_secret_cipher`,
   `scopes_json`, `claim_mapping_json`, `allowed_domains_json`,
   `pkce_required`, `email_verified_required`, `jit_provisioning_enabled`, `default_join_policy`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('kc-org-a', 'tenant-org-a', 'OIDC', 'keycloak', 'Org A SSO', 'ACTIVE',
   'http://localhost:8099/realms/org-a',
   'http://localhost:8099/realms/org-a/.well-known/openid-configuration',
   'http://localhost:8099/realms/org-a/protocol/openid-connect/certs',
   'http://localhost:8099/realms/org-a/protocol/openid-connect/auth',
   'http://localhost:8099/realms/org-a/protocol/openid-connect/token',
   'iam', 'DEV_ONLY:replace-with-keycloak-client-secret',
   '["openid","email","profile","groups"]',
   '{"email":"email","sub":"sub","name":"name","groups":"groups"}',
   '["org-a.com"]',
   1, 0, 1, 'AUTO_JOIN',
   0, 'system', 'system');

-- ③ 预置组映射：IdP 组 agent-operators → 内部角色 AgentOperator（r-1001）
--    注意：match_value 用 Keycloak 的完整组路径形态（前导斜杠）"/agent-operators"，
--         与 ID token 的 groups claim 对齐；IAM 匹配已对前导斜杠容忍
INSERT IGNORE INTO `gateway_idp_group_mapping`
  (`idp_group_mapping_id`, `tenant_idp_config_id`, `match_mode`, `match_value`,
   `target_role_id`, `priority`, `mapping_status`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('gm-org-a', 'kc-org-a', 'EXACT', '/agent-operators', 'r-1001', 100, 'ACTIVE', 0, 'system', 'system');
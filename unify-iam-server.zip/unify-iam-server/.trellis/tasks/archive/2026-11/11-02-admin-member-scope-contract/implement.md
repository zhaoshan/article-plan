# Implementation plan

1. Inspect existing role/tenant scope validation and member projection constraints; enforce rejection of legacy `tenant_id` rather than mapping it.
2. Add a small scope value/validation path in `TenantMemberQueryService`, preserving standard `AuthException.badRequest` messages and authorization semantics.
3. Extend the member mapper/query orchestration to support global and tenant-scoped membership retrieval, applying keyword, owner-candidate, and limit predicates before truncation and preserving batch role/user projection.
4. Update the controller signature to expose only the supported snake_case scope parameters plus existing filters.
5. Add focused controller/service tests for valid tuples, missing/partial/incorrect case values, permission and scope rejection, and compatibility behavior.
6. Extend integration coverage with multiple tenants, owner candidates, keyword matches beyond the limit, aggregate response checks, unknown/deleted target behavior, and no cross-tenant leakage.
7. Run `git diff --check`, focused Maven tests, and project checks; record environment blockers if the known JDK/Lombok baseline prevents execution.

## Approved adjustments and validation

- User approved implementation and explicitly rejected any legacy tenant_id mapping.
- Added canonical comma-separated membership_status with ACTIVE/PENDING/SUSPENDED; status alias rejected.
- Row attribution includes tenant_id/tenant_name/tenant_type. PLATFORM omits top-level singleton metadata.
- Reviewed the three migrated integration test diffs endpoint by endpoint and restored unrelated
  join-request tenant_id parameters. Only member-list calls change scope contracts.
- Current machine: JDK 26.0.2.1, Maven 3.9.16; project target is Java 21. No installed JDK 21 found.
- Default Maven compilation fails because annotation processing is not enabled. With
  `-Dmaven.compiler.proc=full`, compilation succeeds without changing repository compiler configuration.
- Mockito on JDK 26 needs its existing 5.17.0 jar supplied as javaagent plus
  `-Dnet.bytebuddy.experimental=true`; these are command-only verification settings.
- The initial integration attempt could not initialize Testcontainers because the Docker socket was unavailable. The user subsequently explicitly waived full database integration testing; it is no longer a completion gate. Compile, six contract tests, generated SQL and diff checks satisfy the approved verification scope.

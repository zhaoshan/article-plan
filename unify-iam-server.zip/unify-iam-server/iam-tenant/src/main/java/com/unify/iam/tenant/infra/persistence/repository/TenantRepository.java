package com.unify.iam.tenant.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.tenant.infra.persistence.mapper.TenantMapper;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Repository;

/**
 * 租户仓储。E2E-2 JIT 需要按域名路由与新建租户。
 */
@Repository
public class TenantRepository {

    private final TenantMapper tenantMapper;

    public TenantRepository(TenantMapper tenantMapper) {
        this.tenantMapper = tenantMapper;
    }

    /**
     * 按主域名查 ACTIVE 租户（JIT 域名路由用；未逻辑删除）。
     *
     * <p>{@code primary_domain} 非唯一列，可能存在多行（JIT 误建/历史数据）→ 取 id 最小的一个
     * （即最早创建的 seed 租户）。这是对 `selectOne` 在二义性时抛错的健壮性修复。
     */
    public Optional<TenantPO> findActiveByPrimaryDomain(String primaryDomain) {
        List<TenantPO> list = tenantMapper.selectList(new LambdaQueryWrapper<TenantPO>()
                .eq(TenantPO::getPrimaryDomain, primaryDomain)
                .eq(TenantPO::getTenantStatus, "ACTIVE")
                .orderByAsc(TenantPO::getId)
                .last("LIMIT 1"));
        return list.isEmpty() ? Optional.empty() : Optional.of(trimBizKeys(list.get(0)));
    }

    /** 批量按租户 ID 查（审计富化等）。 */
    public List<TenantPO> findByIds(Collection<String> tenantIds) {
        if (tenantIds == null || tenantIds.isEmpty()) {
            return List.of();
        }
        return tenantMapper.selectList(new LambdaQueryWrapper<TenantPO>()
                        .in(TenantPO::getTenantId, tenantIds))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 按租户 ID 查。 */
    public Optional<TenantPO> findById(String tenantId) {
        return Optional.ofNullable(tenantMapper.selectOne(new LambdaQueryWrapper<TenantPO>()
                        .eq(TenantPO::getTenantId, tenantId)))
                .map(this::trimBizKeys);
    }

    /** 按拥有人 + 类型查（consumer 的个人租户复用）；同型可多行 → 取最早一个。 */
    public Optional<TenantPO> findActiveByOwnerAndType(String ownerUserId, String tenantType) {
        List<TenantPO> list = tenantMapper.selectList(new LambdaQueryWrapper<TenantPO>()
                .eq(TenantPO::getOwnerUserId, ownerUserId)
                .eq(TenantPO::getTenantType, tenantType)
                .eq(TenantPO::getTenantStatus, "ACTIVE")
                .orderByAsc(TenantPO::getId)
                .last("LIMIT 1"));
        return list.isEmpty() ? Optional.empty() : Optional.of(trimBizKeys(list.get(0)));
    }

    /** 新建租户（JIT）；返回是否新插入（唯一键冲突视为已存在）。 */
    public boolean create(TenantPO po) {
        try {
            return tenantMapper.insert(po) > 0;
        } catch (DuplicateKeyException e) {
            return false;
        }
    }

    private TenantPO trimBizKeys(TenantPO po) {
        if (po.getTenantId() != null) {
            po.setTenantId(po.getTenantId().trim());
        }
        if (po.getOwnerUserId() != null) {
            po.setOwnerUserId(po.getOwnerUserId().trim());
        }
        return po;
    }

    /** 管理端租户列表（非敏感字段，按 id 升序，限 100 条）。 */
    public List<TenantPO> listAll(int limit) {
        return tenantMapper.selectList(new LambdaQueryWrapper<TenantPO>()
                        .select(TenantPO::getTenantId, TenantPO::getTenantCode, TenantPO::getTenantName,
                                TenantPO::getTenantType, TenantPO::getTenantStatus, TenantPO::getPrimaryDomain,
                                TenantPO::getOwnerUserId, TenantPO::getCreateTime)
                        .orderByAsc(TenantPO::getId)
                        .last("LIMIT " + Math.min(Math.max(limit, 1), 1000)))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 更新租户（状态/域名/名称）。 */
    public void update(TenantPO po) {
        tenantMapper.updateById(po);
    }

    /** 逻辑删除（delete_flag=1，经 @TableLogic）。 */
    public void logicalDelete(String tenantId) {
        tenantMapper.delete(new LambdaQueryWrapper<TenantPO>().eq(TenantPO::getTenantId, tenantId));
    }
}
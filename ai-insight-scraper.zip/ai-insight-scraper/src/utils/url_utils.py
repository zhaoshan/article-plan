"""URL 工具函数（从 scripts/deep_crawl_nested_links.py 提取）"""

from urllib.parse import urlparse, urljoin

# 不需要下钻的文件扩展名
NON_CRAWLABLE_EXTENSIONS: set[str] = {
    '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
    '.zip', '.rar', '.tar', '.gz', '.7z',
    '.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp', '.bmp', '.ico',
    '.mp3', '.mp4', '.avi', '.mov', '.wmv', '.flv',
    '.txt', '.csv', '.xml', '.json',
}

# 保留 www. 前缀的域名列表（这些域名的 www 与裸域名指向不同内容）
KEEP_WWW_DOMAINS: set[str] = {'www.tokyostarbank.co.jp'}


def normalize_url(url_string: str) -> str:
    """
    标准化 URL 用于去重比较。
    忽略查询参数和哈希，只保留协议、域名和路径。

    Args:
        url_string: 原始 URL 字符串

    Returns:
        str: 标准化后的 URL（不包含查询参数和哈希）
    """
    try:
        url = urlparse(url_string)

        # 只处理 http/https 协议
        if url.scheme not in ['http', 'https']:
            return url_string.lower()

        # 统一协议和主机名（移除 www，但排除保留 www. 的域名）
        host = url.netloc
        if not any(
            host == domain or host.endswith('.' + domain.split('.', 1)[1])
            for domain in KEEP_WWW_DOMAINS if host.startswith('www.')
        ):
            host = host.replace('www.', '')

        # 统一路径（移除末尾斜杠）
        pathname = url.path.rstrip('/')

        # 返回标准化 URL（忽略查询参数和哈希）
        return f"{url.scheme}://{host}{pathname}".lower()
    except Exception:
        return url_string.lower()


def get_domain(url_string: str) -> str | None:
    """
    提取 URL 的域名。

    Args:
        url_string: URL 字符串

    Returns:
        str | None: 域名（不含 www），解析失败返回 None
    """
    try:
        parsed = urlparse(url_string)
        if parsed.scheme not in ['http', 'https']:
            return None
        host = parsed.netloc.replace('www.', '')
        return host.lower()
    except Exception:
        return None


def is_same_domain(url_string: str, target_domain: str | None) -> bool:
    """
    检查 URL 是否与目标域名相同。

    Args:
        url_string: URL 字符串
        target_domain: 目标域名，None 时认为所有 URL 都符合

    Returns:
        bool: 是否同域名
    """
    if not target_domain:
        return True

    url_domain = get_domain(url_string)
    if not url_domain:
        return False

    return url_domain == target_domain or url_domain.endswith('.' + target_domain)


def is_crawlable_url(url_string: str) -> bool:
    """
    检查 URL 是否可以继续下钻爬取（PDF 等文件返回 False）。

    Args:
        url_string: URL 字符串

    Returns:
        bool: 是否可继续下钻
    """
    try:
        parsed = urlparse(url_string)
        path = parsed.path.lower()

        for ext in NON_CRAWLABLE_EXTENSIONS:
            if path.endswith(ext):
                return False

        if parsed.scheme not in ['http', 'https']:
            return False

        return True
    except Exception:
        return False


def is_valid_url_for_collection(url_string: str) -> bool:
    """
    检查 URL 是否是有效的可收集链接（包括 PDF 等文件）。

    Args:
        url_string: URL 字符串

    Returns:
        bool: 是否是有效链接
    """
    try:
        parsed = urlparse(url_string)
        return parsed.scheme in ['http', 'https'] and bool(parsed.netloc)
    except Exception:
        return False


def is_valid_url(url_string: str) -> bool:
    """检查 URL 是否有效（只处理 http/https 链接）"""
    try:
        parsed = urlparse(url_string)
        return parsed.scheme in ['http', 'https'] and bool(parsed.netloc)
    except Exception:
        return False


def resolve_url(base_url: str, link: str) -> str:
    """将相对链接转换为绝对链接"""
    return urljoin(base_url, link)


def is_domain_in_whitelist(url_or_domain: str, whitelist: list[str]) -> bool:
    """
    检查 URL 或域名的域名是否在白名单中。

    支持精确匹配（url_domain == wl）和子域名匹配（url_domain.endswith("." + wl)）。

    Args:
        url_or_domain: URL 字符串或裸域名
        whitelist: 域名白名单列表

    Returns:
        bool: 是否在白名单中
    """
    # 尝试解析域名（如果传入的是完整 URL）
    domain = get_domain(url_or_domain)
    if not domain:
        # 传入的可能已是裸域名
        domain = url_or_domain.lower()
    return any(
        domain == wl or domain.endswith("." + wl)
        for wl in whitelist
    )

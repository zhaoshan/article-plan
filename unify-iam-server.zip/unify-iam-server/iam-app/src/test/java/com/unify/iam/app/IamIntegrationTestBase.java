package com.unify.iam.app;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.containers.MySQLContainer;

/**
 * 集成测试基类：Testcontainers MySQL 8 + Flyway 自动建库 seed + 独立 JWT 密钥。
 *
 * <p>采用「手动单例容器」：static 一次性启动、JVM 退出才停（共享给所有子类），
 * 避免 JUnit5 + 继承的 {@code @Container} 字段在多个子类间"先停后复用"导致的连接失败。
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public abstract class IamIntegrationTestBase {

    private static final MySQLContainer<?> MYSQL = startMysql();

    private static final Path KEY_DIR = createKeyDir();

    static {
        Runtime.getRuntime().addShutdownHook(new Thread(MYSQL::stop));
        Runtime.getRuntime().addShutdownHook(new Thread(() -> deleteRecursively(KEY_DIR)));
    }

    private static MySQLContainer<?> startMysql() {
        MySQLContainer<?> container = new MySQLContainer<>("mysql:8.0")
                .withDatabaseName("unify_iam")
                .withUsername("test")
                .withPassword("test");
        container.start();
        return container;
    }

    private static Path createKeyDir() {
        try {
            return Files.createTempDirectory("iam-it-keys");
        } catch (IOException e) {
            throw new IllegalStateException("创建测试密钥目录失败", e);
        }
    }

    private static void deleteRecursively(Path dir) {
        if (dir == null || !Files.exists(dir)) {
            return;
        }
        try (var paths = Files.walk(dir)) {
            paths.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // ignore
                }
            });
        } catch (IOException ignored) {
            // ignore
        }
    }

    /**
     * 注册验证码测试助手（2026-11-05）：为邮箱预置一条 PENDING 验证码（码 123456，10 分钟有效），
     * 免走发信链路；配合注册请求体带 "verification_code":"123456"。
     */
    protected void issueVerificationCode(String email) {
        jdbcTemplate.update("INSERT INTO gateway_email_verification "
                        + "(verification_id, email, purpose, code_hash, verification_status, attempts, expires_at, "
                        + "delete_flag, create_by, update_by) VALUES (?, ?, 'REGISTER', ?, 'PENDING', 0, ?, 0, 'test', 'test')",
                "ev-test-" + java.util.UUID.randomUUID().toString().substring(0, 20),
                email.trim().toLowerCase(),
                com.unify.iam.common.util.SecureToken.hash("123456"),
                java.time.LocalDateTime.now().plusMinutes(10));
    }

    /** 密码字段线上 base64 编码（PasswordCodecs，docs/user-manual/05）——测试提交密码一律经此方法。 */
    protected static String b64(String raw) {
        return com.unify.iam.common.util.PasswordCodecs.encodeBase64(raw);
    }

    /** 统一信封解包：取响应体 {@code data}（前端管理台/hub 专属接口已套 {success,code,message,data}）。 */
    @SuppressWarnings("unchecked")
    protected Map<String, Object> unwrapData(String json) {
        Map<String, Object> body = JsonUtils.fromJson(json, Map.class);
        return body.get("data") instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of();
    }

    /** 统一信封解包：直接取字段值。 */
    protected Object unwrapField(String json, String field) {
        return unwrapData(json).get(field);
    }

    /** 统一信封解包：返回 {@code data} 的 JSON 字符串（供 {@code JsonUtils.fromJson(.., Type)} 复用原解析）。 */
    protected String dataJson(String json) {
        return JsonUtils.toJson(unwrapData(json));
    }

    @DynamicPropertySource
    static void datasourceProps(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", MYSQL::getJdbcUrl);
        registry.add("spring.datasource.username", MYSQL::getUsername);
        registry.add("spring.datasource.password", MYSQL::getPassword);
        registry.add("spring.flyway.enabled", () -> "true");
        // 测试需要 seed（admin/tenant-org-a/parlant + 平台引导）——生产/本地为 schema-only，seed 仅测试注入
        registry.add("spring.flyway.locations",
                () -> "classpath:db/migration,classpath:db/seed,classpath:db/seed-dev");
        registry.add("iam.jwt.private-key-path", () -> KEY_DIR.resolve("it-rsa.pem").toString());
        registry.add("iam.versions.service-token", () -> "it-service-token"); // 版本 feed（方案 c）测试令牌
        // 邮件通道强制日志模式：测试不依赖本机 application.yml 的 SMTP 配置（真实发送会在 CI/本地炸 500）
        registry.add("spring.mail.host", () -> "");
        registry.add("spring.mail.username", () -> "");
        registry.add("iam.mail.invitation-link-base-url", () -> "http://localhost:5173");
        // 严格投递开关钉死关闭（hermetic：本地 application.yml 可能默认开启，测试统一 dev 语义；
        // 严格模式测试用 @BeforeEach 改 IamProperties 运行时翻转，规避动态属性父类覆盖不生效）
        registry.add("iam.mail.delivery-enabled", () -> "false");
        // dev-token 默认已关（P0-07）；测试显式开启（dev-token 相关用例依赖）
        registry.add("iam.dev-token-enabled", () -> "true");
        // SMTP 钉死未配置（日志模式，hermetic：本地 application.yml 可能配了真实 SMTP）——
        // EmailTool.isMailConfigured()=false，forgot 等「日志模式才返回 token」的用例结果确定（P0-08）
        registry.add("spring.mail.host", () -> "");
        registry.add("spring.mail.username", () -> "");
    }

    /** 测试生态口径（2026-11-05）：大量用例直插 gateway_user 造数不带 email_verified——每个用例前统一回填 1，
     *  登录闸门④的专属断言见 EmailVerificationIntegrationTest（其内部显式置 0 验证）。 */
    @org.junit.jupiter.api.BeforeEach
    void markAllUsersVerifiedForTests() {
        jdbcTemplate.update("UPDATE gateway_user SET email_verified = 1 WHERE email_verified = 0");
    }

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected JdbcTemplate jdbcTemplate;
}

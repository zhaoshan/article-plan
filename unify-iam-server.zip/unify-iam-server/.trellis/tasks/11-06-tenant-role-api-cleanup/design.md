# Design

Remove TenantRoleController, TenantRoleQueryService, TenantRoleOption(s), and RoleRepository.listForTenantMemberPicker. The existing AdminRoleController -> AdminRoleService -> TenantScopeGuard -> RoleRepository.listForAdmin path already provides the requested TENANT behavior; preserve it without a redundant refactor.

The general endpoint requires iam:role:read, while the removed endpoint required iam:member:read. The independent frontend has migrated both member dialogs and tenant Roles lists to the canonical query, binding tenant context to the authenticated tenant. The permission catalog exposes tenant_grantable as string "1"/"0", with app_code and category; frontend filters tenant role trees. The backend write path additionally enforces target-enabled apps. Do not change the shared platform permission directory.

Replace old endpoint integration coverage with route-removal proof using handler registration and an authenticated request. Keep/reuse existing MySQL tenant-list and privilege regression coverage. Add focused permission catalog contract coverage if missing.

Update tenant-role-candidates spec and index. API prefix is /api/v1 in this backend; external /v1 depends on frontend proxy. No access to another project is authorized. Breaking endpoint removal requires coordinated frontend/backend rollout; rollback restores task-owned edits only. No schema migration.

## Authorized requirement-3 addition
User explicitly directed verification and repair of B-end Admin creation. R__app_imorph.sql currently appends only iam:member:read/iam:role:read for tpl-3002, while AdminRoleController.create requires iam:role:write. Minimal fix: append that single grant to the iMorph-Admin template and idempotently repair existing non-deleted TENANT iMorph-Admin role bindings. Do not add PLATFORM role bindings or change Member. Existing role:write is the CRUD/permission-write capability, so this permission also allows those existing role operations within the scope guard. Actual token/provisioning integration must prove own-tenant creation and foreign/PLATFORM denial. Added permissions require refreshed/reissued tokens; deployed database seed execution is part of rollout, not an action taken against a live database in this session.

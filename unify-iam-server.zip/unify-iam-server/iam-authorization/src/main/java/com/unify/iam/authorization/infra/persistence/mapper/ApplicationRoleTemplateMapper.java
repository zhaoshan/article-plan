package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.ApplicationRoleTemplatePO;
import org.apache.ibatis.annotations.Mapper;

/** iam_application_role_template Mapper。 */
@Mapper
public interface ApplicationRoleTemplateMapper extends BaseMapper<ApplicationRoleTemplatePO> {
}

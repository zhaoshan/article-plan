package com.unify.iam.app.security;

import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.common.exception.AuthException;
import org.springframework.stereotype.Component;

/**
 * 管理面作用域守卫（docs/06 §3.3）：区分平台级 / 租户级管理操作。
 *
 * <p>判定依据是角色作用域（PLATFORM vs TENANT），而非成员所在租户：持平台级角色
 * （PlatformAdmin）的调用者对任意目标租户放行；仅持租户内管理权限者要求
 * 目标对象.tenant_id == token.tenantId，否则 403。
 */
@Component
public class TenantScopeGuard {

    private final RoleRepository roleRepository;

    public TenantScopeGuard(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    /** 调用者的活跃成员关系是否持有平台级角色（即平台管理员）。 */
    public boolean isPlatformAdmin(String membershipId) {
        return roleRepository.hasPlatformRoleByMembership(membershipId);
    }

    /** 管理面目标租户作用域校验：平台级放行；租户级要求目标租户 == token.tenantId，否则 403。 */
    public void assertTenantScope(JwtClaims claims, String targetTenantId) {
        if (isPlatformAdmin(claims.membershipId())) {
            return;
        }
        if (targetTenantId == null || !targetTenantId.equals(claims.tenantId())) {
            throw AuthException.forbidden("无权操作其他租户");
        }
    }

    /** 平台级操作校验（目标 scope_type=PLATFORM）：非平台管理员 403。 */
    public void assertPlatformAdmin(JwtClaims claims) {
        if (!isPlatformAdmin(claims.membershipId())) {
            throw AuthException.forbidden("需要平台管理员权限");
        }
    }
}

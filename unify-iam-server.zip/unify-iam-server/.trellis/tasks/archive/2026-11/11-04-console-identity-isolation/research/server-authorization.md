> Closed on 2026-11-04 before implementation. The user explicitly narrowed the request to frontend-only work: no backend logic or seed changes. All backend proposals below are withdrawn historical planning, not an approved or implemented API contract. No implementation approval is requested.

# Server authorization evidence

## Findings
- `iam-app/.../security/ManagementAuthorizationInterceptor.java:40` checks only permission possession. Old seed privileges therefore leak into console access.
- `iam-app/.../security/TenantScopeGuard.java:26` delegates to RoleRepository.hasPlatformRoleByMembership; assertTenantScope at line 31 bypasses all target-tenant checks for platform roles.
- `iam-authorization/.../mapper/RoleMapper.java:17` counts any PLATFORM role without role_status or exact PlatformAdmin condition. This differs from the user's identity definition and active RBAC token projection.
- `iam-authorization/.../mapper/AuthorizationQueryMapper.java:19` projects ACTIVE undeleted roles for a single membership; TokenService.issueFor uses it for JWT roles and permissions.
- `iam-app/.../adapter/controller/AuthController.java:140` returns /me roles/permissions from verified claims; AuthIdentityResponse keeps camelCase record fields.
- `iam-app/.../app/service/MembershipMenuService.java:77` includes assigned roles without ACTIVE-role filtering for menu badges. Treat this as display metadata, not the authenticated identity source.
- `iam-app/.../adapter/controller/AdminApplicationController.java:29` currently requires iam:tenant:read, so B-side app access is blocked even when iam:apps:read exists.
- `iam-app/.../adapter/controller/AdminTenantController.java:95,115,200` mixes Apps usage and application reference reads with platform tenant management and an Owner-transfer method lacking @RequirePermission. A blanket controller gate would break shared helpers; every method needs explicit classification.
- `iam-app/.../app/service/admin/AdminMemberService.java:98,129` accepts supplied role IDs and replaces bindings without scope validation. A member manager can submit PLATFORM/foreign role IDs; fix before enabling B-side writes.
- `iam-app/.../app/service/admin/TenantMemberQueryService.java:52` intentionally supports platform aggregated member search; this old contract now conflicts with exclusive B-side Members access.
- `iam-app/.../app/service/admin/AdminRoleService.java:69` permits tenant-role queries to tenant callers. Roles page/API must become platform-only under the new requirement.
- `iam-app/src/main/resources/db/seed/R__platform_bootstrap.sql:32,43` grants PlatformAdmin every iam capability including member/apps.
- `iam-app/src/main/resources/db/seed/R__app_imorph.sql:522` adds member/role/apps capabilities to Owner; line 553 adds member/role read to both Admin and Member. Admin does not yet receive the full intended member/apps operation grants. Retain business grants while adjusting console capabilities.

## Test/environment evidence
Initial branch `feature/lee-1102`; initial tracked/untracked status clean. Existing task `11-04-audit-query-utc` belongs to prior work and is not changed. Source HEAD: `14a71db`.

Project uses Maven, JDK 21 source target, JUnit/Spring MockMvc and MySQL Testcontainers. `mvn` is installed. Shell Java is OpenJDK 26.0.2.1; macOS java_home reports no registered runtime. Docker socket access is currently sandbox-denied; no integration verification has run. No external messages, live API writes, commits, branch changes or worktrees have been created.

## Process gate
`.agents/skills/trellis-brainstorm/SKILL.md`: "Only a subsequent user message that explicitly approves the latest planning summary authorizes task.py start and implementation."
`.trellis/workflow.md` Phase 1.4/1.5 requires reviewed complex-task PRD/design/implementation artifacts and user confirmation before start. Identity-code confirmation resolves a product decision but does not itself approve this final server plan.

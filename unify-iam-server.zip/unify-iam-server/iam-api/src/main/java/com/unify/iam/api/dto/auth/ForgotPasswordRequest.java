package com.unify.iam.api.dto.auth;

import jakarta.validation.constraints.NotBlank;

/** 忘记密码请求：{@code POST /api/v1/auth/forgot-password}。 */
public record ForgotPasswordRequest(
        @NotBlank(message = "email 不能为空") String email) {
}

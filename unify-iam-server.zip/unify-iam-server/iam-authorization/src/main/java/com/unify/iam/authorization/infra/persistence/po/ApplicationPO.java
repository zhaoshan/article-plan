package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** iam_application 应用注册表 PO（docs/06 §2.2）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("iam_application")
public class ApplicationPO extends BaseEntity {

    /** 应用业务唯一标识 */
    private String appId;
    /** 应用编码，如 parlant-agent-server */
    private String appCode;
    private String appName;
    /** 状态：ACTIVE/DISABLED */
    private String appStatus;
    private String description;
    /** G2 增强：应用主页地址（accept 后跳转目标） */
    private String homepageUrl;
}

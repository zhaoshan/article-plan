package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

class AdminUserEmailUpdateIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(response.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    @Test
    void changingEmailNormalizesItAndInvalidatesExistingResetTokens() throws Exception {
        String adminToken = login("admin", "admin123");
        String suffix = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String username = "mail-" + suffix;
        String oldEmail = "old-" + suffix + "@example.test";
        String newEmail = "new-" + suffix + "@example.test";
        String userId = createUser(adminToken, username, oldEmail);

        jdbcTemplate.update("UPDATE gateway_user SET email_verified = 1 WHERE user_id = ?", userId);
        MvcResult forgot = mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + oldEmail + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        String resetToken = String.valueOf(unwrapField(forgot.getResponse().getContentAsString(), "token"));

        mockMvc.perform(put("/api/v1/admin/users/{userId}", userId)
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + newEmail.toUpperCase() + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.user_id").value(userId));

        assertThat(jdbcTemplate.queryForObject(
                "SELECT primary_email FROM gateway_user WHERE user_id = ?", String.class, userId))
                .isEqualTo(newEmail);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT email_verified FROM gateway_user WHERE user_id = ?", Integer.class, userId))
                .isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_password_reset_token WHERE user_id = ? AND is_latest = 1",
                Integer.class, userId)).isZero();

        mockMvc.perform(post("/api/v1/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"token\":\"" + resetToken + "\",\"new_password\":\"" + b64("NextPassw0rd!") + "\"}"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void duplicatePrimaryEmailReturns400AndPreservesTheCurrentEmail() throws Exception {
        String adminToken = login("admin", "admin123");
        String suffix = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String occupiedEmail = "occupied-" + suffix + "@example.test";
        String currentEmail = "current-" + suffix + "@example.test";
        createUser(adminToken, "occupied-" + suffix, occupiedEmail);
        String targetUserId = createUser(adminToken, "target-" + suffix, currentEmail);

        mockMvc.perform(put("/api/v1/admin/users/{userId}", targetUserId)
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + occupiedEmail + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Email is already in use"));

        assertThat(jdbcTemplate.queryForObject(
                "SELECT primary_email FROM gateway_user WHERE user_id = ?", String.class, targetUserId))
                .isEqualTo(currentEmail);
    }

    private String createUser(String adminToken, String username, String email) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + email
                                + "\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return String.valueOf(unwrapField(response.getResponse().getContentAsString(), "user_id"));
    }
}

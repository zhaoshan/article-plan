package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * 方案 c 闭环集成测试（2026-11-09，docs/07 §8.3）：管理面拦截器校验 token ver。
 * 角色变更 bump 版本后，旧 token 的首次 /admin/** 请求 → 401 IAM-AUTH-015 TOKEN_STALE；
 * 前端「401 → 静默 refresh → 原地重试」链路追平后 200。
 */
class VerStaleCheckIntegrationTest extends IamIntegrationTestBase {

    private LoginResponse login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class);
    }

    @Test
    void roleChangeMakesTokenStaleUntilRefresh() throws Exception {
        LoginResponse admin = login("admin", "admin123");
        // 管理面请求正常（ver 未变）
        mockMvc.perform(get("/api/v1/admin/users?limit=1").header("Authorization", "Bearer " + admin.accessToken()))
                .andExpect(status().isOk());

        // 变更角色（setRoles 恒 bump token_version，即使角色集不变）
        mockMvc.perform(put("/api/v1/admin/members/ms-1001/roles")
                        .header("Authorization", "Bearer " + admin.accessToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"r-1002\",\"r-2001\"]}"))
                .andExpect(status().isOk());

        // 旧 token 首次管理面请求 → 401 TOKEN_STALE
        mockMvc.perform(get("/api/v1/admin/users?limit=1").header("Authorization", "Bearer " + admin.accessToken()))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-015"));

        // 静默刷新（refresh 重解析 RBAC，新 token ver 追平）→ 重试成功
        MvcResult refreshed = mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"" + admin.refreshToken() + "\"}"))
                .andExpect(status().isOk()).andReturn();
        LoginResponse after = JsonUtils.fromJson(
                dataJson(refreshed.getResponse().getContentAsString()), LoginResponse.class);
        assertThat(after.accessToken()).isNotBlank();
        assertThat(after.refreshToken()).isNotBlank(); // 轮换
        mockMvc.perform(get("/api/v1/admin/users?limit=1").header("Authorization", "Bearer " + after.accessToken()))
                .andExpect(status().isOk());
    }

    @Test
    void membershipRemovalMakesTokenStale() throws Exception {
        // viewer 仅 viewer 角色：建成员→移除（bump 生效在 remove 上）；旧 token 立即 stale
        String admin = login("admin", "admin123").accessToken();
        String uid = unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"stale_u1\",\"email\":\"stale-u1@unify.local\",\"password\":\""
                                + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("user_id").toString();
        unwrapData(mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"user_id\":\"" + uid.trim() + "\",\"role_ids\":[]}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        String token = login("stale_u1", "Passw0rd!").accessToken();
        String msId = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE user_id=? AND delete_flag=0",
                String.class, uid.trim()).trim();
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .delete("/api/v1/admin/members/" + msId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
        // 成员已删（孤儿清理同时软删用户）→ token 按 stale 拒绝
        mockMvc.perform(get("/api/v1/admin/users?limit=1").header("Authorization", "Bearer " + token))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-015"));
    }
}

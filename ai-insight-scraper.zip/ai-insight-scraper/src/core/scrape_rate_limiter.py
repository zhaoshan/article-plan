"""/v2/scrape 并发与内存限流依赖

提供 FastAPI dependency，在请求进入爬取逻辑前：
1. 检查系统可用内存，低于阈值直接拒绝。
2. 检查 /v2/scrape 当前并发数，达到上限直接拒绝。

两者均抛出 ScrapeRateLimitError，由 main.py 中专用异常处理函数
转换为 /v2 风格的 JSON 响应（HTTP 429）。
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator

import psutil

from src.config.system_config import SystemConfig, load_system_config

logger = logging.getLogger(__name__)

_MB = 1024 * 1024


class ScrapeRateLimitError(Exception):
    """限流异常，携带对外展示的 error 与 HTTP 状态码"""

    def __init__(self, error: str, status_code: int = 429) -> None:
        super().__init__(error)
        self.error = error
        self.status_code = status_code


class ScrapeRateLimiter:
    """/v2/scrape 专用并发 + 内存限制器"""

    def __init__(
        self,
        config: SystemConfig | None = None,
        psutil_module=psutil,
    ) -> None:
        crawl_cfg = (config or load_system_config()).crawl
        self._max_concurrent = max(1, crawl_cfg.max_concurrent_scrapes)
        self._min_memory_mb = max(0, crawl_cfg.scrape_min_available_memory_mb)
        self._sem = asyncio.Semaphore(self._max_concurrent)
        self._psutil = psutil_module

    def _check_memory(self) -> None:
        """检查可用内存，低于阈值时抛出 ScrapeRateLimitError"""
        available_bytes = self._psutil.virtual_memory().available
        available_mb = available_bytes // _MB
        if available_mb < self._min_memory_mb:
            raise ScrapeRateLimitError(
                f"系统可用内存不足（当前 {available_mb} MB），无法启动新的爬取任务"
            )

    async def __aenter__(self) -> None:
        """进入上下文：先查内存，再非阻塞获取并发槽"""
        self._check_memory()
        if self._sem.locked():
            raise ScrapeRateLimitError("当前爬取任务数已达上限，请稍后再试")
        await self._sem.acquire()

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """退出上下文：释放并发槽"""
        self._sem.release()


# 模块级单例，避免重复加载配置
_limiter: ScrapeRateLimiter | None = None


def _get_limiter() -> ScrapeRateLimiter:
    """获取模块级 ScrapeRateLimiter 单例"""
    global _limiter
    if _limiter is None:
        _limiter = ScrapeRateLimiter()
    return _limiter


async def scrape_rate_limiter() -> AsyncIterator[None]:
    """FastAPI dependency：在请求期间持有 /v2/scrape 并发槽"""
    async with _get_limiter():
        yield

package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.TenantQuotaMapper;
import com.unify.iam.authorization.infra.persistence.po.TenantQuotaPO;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** G1 租户配额覆盖仓储（无行 = 用模板默认）。 */
@Repository
public class TenantQuotaRepository {

    private final TenantQuotaMapper mapper;

    public TenantQuotaRepository(TenantQuotaMapper mapper) {
        this.mapper = mapper;
    }

    public Optional<TenantQuotaPO> findByTenantAndDimension(String tenantId, String dimensionId) {
        return Optional.ofNullable(mapper.selectOne(new LambdaQueryWrapper<TenantQuotaPO>()
                .eq(TenantQuotaPO::getTenantId, tenantId.trim())
                .eq(TenantQuotaPO::getDimensionId, dimensionId.trim())));
    }

    public void insert(TenantQuotaPO po) {
        mapper.insert(po);
    }

    public void update(TenantQuotaPO po) {
        mapper.updateById(po);
    }

    /** 清除覆盖（limit 传 NULL 时 → 删除行，回落模板默认）。 */
    public void deleteByTenantAndDimension(String tenantId, String dimensionId) {
        mapper.delete(new LambdaQueryWrapper<TenantQuotaPO>()
                .eq(TenantQuotaPO::getTenantId, tenantId.trim())
                .eq(TenantQuotaPO::getDimensionId, dimensionId.trim()));
    }
}

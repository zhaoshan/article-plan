package com.unify.iam.app.security;

import com.unify.iam.api.model.JwtClaims;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 请求元信息访问器（审计/日志用）：requestId / ip / userAgent / 当前操作者 membership。
 *
 * <p>requestId 由 {@link com.unify.iam.app.config.RequestIdFilter} 写入 request attribute；
 * actor membership 复用管理面拦截器写入的 claims attribute。无请求上下文时安全返回 null。
 */
public final class RequestMeta {

    public static final String REQUEST_ID_ATTR = "iam.request-id";

    private RequestMeta() {
    }

    private static HttpServletRequest request() {
        return (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes a)
                ? a.getRequest() : null;
    }

    /** 请求编号（由 Filter 生成或透传 X-Request-Id）；无上下文 → null。 */
    public static String requestId() {
        HttpServletRequest r = request();
        if (r == null) {
            return null;
        }
        Object v = r.getAttribute(REQUEST_ID_ATTR);
        return v == null ? null : String.valueOf(v);
    }

    /** 来源 IP（优先 X-Forwarded-For 首项，否则 remoteAddr）。 */
    public static String ip() {
        HttpServletRequest r = request();
        if (r == null) {
            return null;
        }
        String xff = r.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isBlank()) {
            return xff.split(",")[0].trim();
        }
        return r.getRemoteAddr();
    }

    public static String userAgent() {
        HttpServletRequest r = request();
        return r == null ? null : r.getHeader("User-Agent");
    }

    /** 当前请求已认证的成员关系 ID（管理面拦截器写入）；无 → null。 */
    public static String actorMembershipId() {
        HttpServletRequest r = request();
        if (r == null) {
            return null;
        }
        Object v = r.getAttribute(ManagementAuthorizationInterceptor.AUTH_CLAIMS_ATTR);
        return (v instanceof JwtClaims c) ? c.membershipId() : null;
    }
}

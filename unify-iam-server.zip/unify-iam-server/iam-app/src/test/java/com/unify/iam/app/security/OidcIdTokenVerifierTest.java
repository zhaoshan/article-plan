package com.unify.iam.app.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.app.oidc.OidcProviderClient;
import com.unify.iam.app.oidc.OidcProviderConfig;
import com.unify.iam.app.oidc.VerifiedClaims;
import com.unify.iam.app.support.MockOidcProvider;
import com.unify.iam.common.exception.AuthException;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.crypto.spec.SecretKeySpec;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

class OidcIdTokenVerifierTest {

    private MockOidcProvider mock;
    private OidcIdTokenVerifier verifier;

    @BeforeEach
    void setUp() {
        mock = MockOidcProvider.start();
        mock.configure(new MockOidcProvider.UserProfile("u-oidc-1", "alice@org-a.com", List.of("agent-operators")));
        verifier = new OidcIdTokenVerifier(new OidcProviderClient(RestClient.builder()));
    }

    @AfterEach
    void tearDown() {
        mock.close();
    }

    private OidcProviderConfig config() {
        return new OidcProviderConfig(
                "cfg-1", "tenant-org-a", "keycloak",
                mock.issuer(),
                mock.baseUrl() + "/authorize", mock.baseUrl() + "/token", mock.baseUrl() + "/jwks",
                "iam", "secret",
                List.of("openid", "email", "profile", "groups"),
                Map.of("email", "email", "name", "name", "sub", "sub", "groups", "groups"),
                List.of("org-a.com"),
                true, false, true, "AUTO_JOIN");
    }

    @Test
    void validTokenVerifiesAndMapsClaims() {
        String token = mock.issueIdToken("nonce-1", "iam");
        VerifiedClaims claims = verifier.verify(token, config(), "nonce-1");

        assertThat(claims.subject()).isEqualTo("u-oidc-1");
        assertThat(claims.email()).isEqualTo("alice@org-a.com");
        assertThat(claims.groups()).containsExactly("agent-operators");
    }

    @Test
    void tamperedTokenRejected() {
        String token = mock.issueIdToken("nonce-1", "iam");
        int mid = token.length() / 2;
        String tampered = token.substring(0, mid) + (token.charAt(mid) == 'A' ? 'B' : 'A') + token.substring(mid + 1);

        assertThatThrownBy(() -> verifier.verify(tampered, config(), "nonce-1"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessageContaining("签名");
    }

    @Test
    void wrongIssuerRejected() {
        OidcProviderConfig badConfig = new OidcProviderConfig(
                "cfg-1", "tenant-org-a", "keycloak", "https://evil.example.com/issuer",
                config().authorizationEndpoint(), config().tokenEndpoint(), config().jwkSetUri(),
                "iam", "secret", config().scopes(), config().claimMapping(), config().allowedDomains(),
                true, false, true, "AUTO_JOIN");
        String token = mock.issueIdToken("nonce-1", "iam");

        assertThatThrownBy(() -> verifier.verify(token, badConfig, "nonce-1"))
                .isInstanceOf(AuthException.class)
                .hasMessageContaining("issuer");
    }

    @Test
    void expiredTokenRejected() {
        mock.setTtlSeconds(3600);
        String token = mock.issueIdToken("nonce-1", "iam", Instant.now().getEpochSecond() - 60);

        assertThatThrownBy(() -> verifier.verify(token, config(), "nonce-1"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessageContaining("过期");
    }

    @Test
    void wrongNonceRejected() {
        String token = mock.issueIdToken("nonce-A", "iam");

        assertThatThrownBy(() -> verifier.verify(token, config(), "nonce-B"))
                .isInstanceOf(AuthException.class)
                .hasMessageContaining("nonce");
    }

    @Test
    void forbiddenAlgorithmRejected() throws Exception {
        JWTClaimsSet cs = new JWTClaimsSet.Builder()
                .issuer(mock.issuer()).audience("iam").subject("u-oidc-1")
                .claim("email", "alice@org-a.com")
                .expirationTime(Date.from(Instant.now().plusSeconds(3600)))
                .build();
        SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.HS256).keyID("h").build(), cs);
        jwt.sign(new MACSigner(new SecretKeySpec("0123456789abcdef0123456789abcdef".getBytes(), "HmacSHA256")));

        assertThatThrownBy(() -> verifier.verify(jwt.serialize(), config(), "nonce-1"))
                .isInstanceOf(AuthException.class)
                .hasMessageContaining("算法不允许");
    }

    @Test
    void unknownKidRejected() throws Exception {
        RSAKey other = new RSAKeyGenerator(2048).keyID("other-key").generate();
        JWTClaimsSet cs = new JWTClaimsSet.Builder()
                .issuer(mock.issuer()).audience("iam").subject("u-oidc-1")
                .claim("email", "alice@org-a.com")
                .expirationTime(Date.from(Instant.now().plusSeconds(3600)))
                .build();
        SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID("other-key").build(), cs);
        jwt.sign(new RSASSASigner(other));

        assertThatThrownBy(() -> verifier.verify(jwt.serialize(), config(), "nonce-1"))
                .isInstanceOf(AuthException.class)
                .hasMessageContaining("kid");
    }
}
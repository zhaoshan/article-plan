package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.app.app.service.admin.AdminAuditService;
import com.unify.iam.app.security.RequirePermission;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：审计查询（iam:audit:read，平台管理员专属，docs/05 Audit 页）。 */
@RestController
@RequestMapping("/api/v1/admin/audit")
public class AdminAuditController {

    private final AdminAuditService adminAuditService;

    public AdminAuditController(AdminAuditService adminAuditService) {
        this.adminAuditService = adminAuditService;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_AUDIT_READ)
    public Map<String, Object> list(@RequestParam(name = "tenant_id", required = false) String tenantId,
                                    @RequestParam(name = "event_type", required = false) String eventType,
                                    @RequestParam(name = "actor_user_id", required = false) String actorUserId,
                                    @RequestParam(name = "page", defaultValue = "1") int page,
                                    @RequestParam(name = "size", defaultValue = "20") int size) {
        List<Map<String, Object>> audits = adminAuditService.list(tenantId, eventType, actorUserId, page, size);
        long total = adminAuditService.count(tenantId, eventType, actorUserId);
        return Map.of("audits", audits, "total", total, "page", Math.max(page, 1), "size", Math.min(Math.max(size, 1), 200));
    }

    /** 事件类型目录（code + 名称），供管理台筛选下拉。 */
    @GetMapping("/events")
    @RequirePermission(PermissionCodes.IAM_AUDIT_READ)
    public Map<String, Object> events() {
        List<Map<String, String>> events = adminAuditService.events();
        return Map.of("events", events, "count", events.size());
    }

}

package com.unify.iam.app.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.app.infra.persistence.po.PasswordResetTokenPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_password_reset_token Mapper。 */
@Mapper
public interface PasswordResetTokenMapper extends BaseMapper<PasswordResetTokenPO> {
}

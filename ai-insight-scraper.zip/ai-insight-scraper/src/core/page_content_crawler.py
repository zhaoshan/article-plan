"""PageContentCrawler — 单页面内容爬取服务

从 scripts/crawl_page_content.py 提取核心逻辑（忽略 Excel 解析部分），
重构为基于 S3 的单页面内容爬取服务。

核心流程：
  1. 校验 URL 在 crawl_link_tree 表中存在（不存在则报错，不支持爬取）
  2. 按域名从 content_crawl_config.json 加载 exclude_tags
  3. 按 URL 类型分支爬取（HTML / PDF / 图片 / 二进制附件）
  4. 计算 content_hash，与 DB 已有 hash 比对：
     - 一致 → 不上传 S3、不更新 DB，复用已有 crawl_file_list
     - 不一致 → 上传 S3 + 更新 DB（page_title/content_hash/crawl_file_list/last_crawl_time）
  5. 返回爬取元数据（link_type/page_title/content_hash/crawl_file_list/changed）

设计要点：
  - 所有产物上传到 S3，不落本地（output/ 仅用于临时中转，可选）
  - page_title：网页取 <title>（缺失用 url 或 50 字内容摘要），附件/图片取文件名
  - crawl_file_list：JSON 数组字符串，网页 3 项（markdown/html/rawHtml），附件/图片 1 项
"""

from __future__ import annotations

import base64
import hashlib
import logging
import random
import time
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

from bs4 import BeautifulSoup
from playwright.async_api import BrowserContext, Page, async_playwright

from src.boundaries.s3_boundary import S3Boundary
from src.config.content_crawl_config import load_content_crawl_config
from src.core.base_crawler import BaseCrawler
from src.database import LinkTreeRepository
from src.database.models import CrawlLinkTreeModel
from src.utils.html_converter import HtmlConverter
from src.utils.url_utils import get_domain

logger = logging.getLogger(__name__)

# ── 常量 ────────────────────────────────────────────────

PAGE_TIMEOUT = 60000
WAIT_DYNAMIC_MS = 3000

# 图片扩展名 → file_type
IMAGE_EXTENSIONS: dict[str, str] = {
    ".png": "png",
    ".jpg": "jpg",
    ".jpeg": "jpeg",
    ".gif": "gif",
    ".svg": "svg",
    ".webp": "webp",
    ".bmp": "bmp",
    ".ico": "ico",
}

# 附件扩展名 → file_type
ATTACHMENT_EXTENSIONS: dict[str, str] = {
    ".pdf": "pdf",
    ".doc": "doc",
    ".docx": "docx",
    ".xls": "xls",
    ".xlsx": "xlsx",
    ".ppt": "ppt",
    ".pptx": "pptx",
    ".zip": "zip",
    ".rar": "rar",
    ".7z": "7z",
    ".tar": "tar",
    ".gz": "gz",
    ".txt": "txt",
    ".csv": "csv",
    ".mp4": "mp4",
    ".avi": "avi",
    ".mov": "mov",
}

# S3 存储子目录前缀
S3_PAGE_CONTENT_PREFIX = "page_content"


# ── 工具函数 ────────────────────────────────────────────


def compute_dedup_hash(text: str) -> str:
    """根据内容计算去重哈希（去除空白后 sha256）"""
    normalized = "".join(text.split())
    return "sha256:" + hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _url_path(url: str) -> str:
    """提取 URL 的路径部分（去掉查询参数和锚点）"""
    return url.split("?")[0].split("#")[0]


def is_pdf_url(url: str) -> bool:
    """判断 URL 是否指向 PDF"""
    if not url:
        return False
    return _url_path(url).lower().endswith(".pdf")


def is_image_url(url: str) -> bool:
    """判断 URL 是否指向图片"""
    if not url:
        return False
    path = _url_path(url).lower()
    for ext in IMAGE_EXTENSIONS:
        if path.endswith(ext):
            return True
    return False


def is_attachment_url(url: str) -> bool:
    """判断 URL 是否指向附件（PDF/DOC/XLS/ZIP 等非 HTML/图片资源）"""
    if not url:
        return False
    path = _url_path(url).lower()
    for ext in ATTACHMENT_EXTENSIONS:
        if path.endswith(ext):
            return True
    return False


def is_html_like_url(url: str) -> bool:
    """判断 URL 是否应作为 HTML 页面爬取（.html/.htm 结尾，或无文件后缀）"""
    if not url:
        return True
    path = _url_path(url)
    last_segment = path.rstrip("/").rsplit("/", 1)[-1] if path.rstrip("/") else ""
    if not last_segment:
        return True
    if "." not in last_segment:
        return True
    ext = last_segment.rsplit(".", 1)[-1].lower()
    return ext in ("html", "htm")


def extract_filename_from_url(url: str) -> str:
    """从 URL 路径中提取文件名"""
    path = _url_path(url)
    filename = path.rsplit("/", 1)[-1]
    if not filename:
        filename = f"page_{int(time.time())}"
    return filename


def build_dir_name(url: str) -> str:
    """根据 URL 构建存储目录名（去掉协议头和参数，/ 和 . 替换为 _）"""
    parsed = urlparse(url)
    host = parsed.netloc
    path = _url_path(parsed.path).lstrip("/")
    full = f"{host}/{path}" if path else host
    return full.replace("/", "_").replace(".", "_").rstrip("_")


def detect_file_type(url: str) -> str:
    """根据 URL 后缀检测 file_type，返回 markdown/html/rawHtml/pdf/png 等"""
    path = _url_path(url).lower()
    if not path or "." not in path.rsplit("/", 1)[-1]:
        return "html"
    ext = "." + path.rsplit(".", 1)[-1]
    if ext in IMAGE_EXTENSIONS:
        return IMAGE_EXTENSIONS[ext]
    if ext in ATTACHMENT_EXTENSIONS:
        return ATTACHMENT_EXTENSIONS[ext]
    return "html"


def remove_exclude_tags(soup: BeautifulSoup, exclude_rules: list[dict]) -> int:
    """从 BeautifulSoup 对象中删除匹配排除规则的 DOM 标签"""
    removed = 0
    for rule in exclude_rules:
        tag_name = rule.get("tag", "")
        if not tag_name:
            continue
        rule_id = rule.get("id", "")
        rule_class = rule.get("class", "")
        matched = []
        for element in soup.find_all(tag_name):
            match = True
            if rule_id:
                if element.get("id", "") != rule_id:
                    match = False
            if rule_class and match:
                elem_classes = element.get("class", [])
                if isinstance(elem_classes, str):
                    elem_classes = elem_classes.split()
                if rule_class not in elem_classes:
                    match = False
            if match:
                matched.append(element)
        for element in matched:
            element.decompose()
            removed += 1
    return removed


def _extract_title(soup: BeautifulSoup, url: str, content_text: str = "") -> str:
    """提取页面标题：优先 <title>，其次 50 字内容摘要，最后用 url"""
    title_tag = soup.find("title")
    if title_tag and title_tag.get_text(strip=True):
        return title_tag.get_text(strip=True)[:512]
    if content_text:
        snippet = content_text.strip().replace("\n", " ")[:50]
        if snippet:
            return snippet
    return url[:512]


# ── 抽象基类 ────────────────────────────────────────────


class PageContentCrawlerBase(ABC):
    """单页面内容爬取服务抽象基类"""

    @abstractmethod
    async def crawl(self, url: str) -> dict:
        """爬取单个页面，返回元数据 dict"""
        ...


# ── 实现 ────────────────────────────────────────────────


class PageContentCrawler(PageContentCrawlerBase, BaseCrawler):
    """单页面内容爬取服务实现

    基于 Playwright 爬取页面内容，产物上传 S3，元数据落 crawl_link_tree 表。
    """

    def __init__(self, headless: bool = True, s3_boundary: S3Boundary | None = None):
        self.headless = headless
        self._browser = None
        self._s3_boundary = s3_boundary
        self._repo = LinkTreeRepository()

    async def crawl(self, url: str) -> dict:
        """爬取单个页面。

        Args:
            url: 目标页面 URL（必须在 crawl_link_tree 表中存在）

        Returns:
            dict: {
                "link_type": "HTML"|"PDF"|"IMAGE"|...,
                "page_title": str,
                "content_hash": str,
                "crawl_file_list": list[dict],
                "changed": bool,
            }

        Raises:
            ValueError: 链接不在 crawl_link_tree 表中
        """
        domain = get_domain(url)
        if not domain:
            raise ValueError(f"无法解析 URL 域名: {url}")

        # 1. 校验链接在 crawl_link_tree 中存在
        node = await self._repo.find_by_url(url)
        if node is None:
            raise ValueError(f"链接不在 crawl_link_tree 中，不支持爬取: {url}")

        # 1.1 校验 download_flag 必须为 Y 才允许爬取
        if (node.download_flag or "").strip().upper() != "Y":
            raise ValueError(
                f"链接 download_flag 非 Y，不支持爬取: {url}（当前值: {node.download_flag!r}）"
            )

        # 2. 加载 exclude_tags
        content_config = load_content_crawl_config(domain)
        exclude_rules = [t.model_dump(by_alias=True) for t in content_config.exclude_tags]

        # 3. 启动浏览器爬取
        async with async_playwright() as p:
            context = await self._setup_browser_context(p)
            try:
                page = await context.new_page()
                crawl_result = await self._crawl_by_type(page, context, url, exclude_rules)
            finally:
                await self._teardown_browser(context)

        # 4. hash 比对 + S3 上传 + DB 更新
        return await self._persist(url, node, crawl_result)

    # ── 按类型爬取 ────────────────────────────────────

    async def _crawl_by_type(
        self,
        page: Page,
        context: BrowserContext,
        url: str,
        exclude_rules: list[dict],
    ) -> dict:
        """按 URL 类型分支爬取，返回中间结果 dict"""
        if is_pdf_url(url):
            return await self._crawl_pdf(page, url)
        if is_image_url(url):
            return await self._crawl_image(page, context, url)
        if is_attachment_url(url):
            return await self._crawl_attachment(page, context, url)
        return await self._crawl_html(page, url, exclude_rules)

    async def _crawl_html(
        self, page: Page, url: str, exclude_rules: list[dict]
    ) -> dict:
        """爬取 HTML 页面：rawHtml + 清洗后 html + markdown"""
        raw_html = await self._fetch_html_content(page, url)
        if not raw_html:
            raise RuntimeError(f"页面内容获取失败: {url}")

        soup = BeautifulSoup(raw_html, "html.parser")
        page_title = _extract_title(soup, url, soup.get_text())

        # 排除标签
        if exclude_rules:
            removed = remove_exclude_tags(soup, exclude_rules)
            if removed > 0:
                logger.info(f"已删除 {removed} 个排除标签: {url}")

        # 清洗后完整 html（含 head）
        cleaned_html = str(soup)
        # body 部分 html
        body_tag = soup.find("body")
        body_html = str(body_tag) if body_tag else cleaned_html

        # markdown
        markdown = HtmlConverter.html_to_markdown(
            body_tag if body_tag else soup, base_url=url
        )

        content_hash = compute_dedup_hash(cleaned_html)

        return {
            "link_type": "HTML",
            "page_title": page_title,
            "content_hash": content_hash,
            "files": {
                "markdown": markdown.encode("utf-8"),
                "html": body_html.encode("utf-8"),
                "rawHtml": cleaned_html.encode("utf-8"),
            },
        }

    async def _crawl_pdf(self, page: Page, url: str) -> dict:
        """下载 PDF（浏览器内 fetch，校验 %PDF 魔数）"""
        filename = extract_filename_from_url(url)
        if not filename.lower().endswith(".pdf"):
            filename += ".pdf"

        body = await self._download_pdf_bytes(page, url)
        if body is None:
            raise RuntimeError(f"PDF 下载失败: {url}")

        return {
            "link_type": "PDF",
            "page_title": filename,
            "content_hash": "",
            "files": {"pdf": body},
        }

    async def _crawl_image(
        self, page: Page, context: BrowserContext, url: str
    ) -> dict:
        """下载图片，markdown 引用在持久化阶段生成"""
        filename = extract_filename_from_url(url)
        body = await self._download_binary_bytes(context, url)
        if body is None:
            raise RuntimeError(f"图片下载失败: {url}")

        file_type = detect_file_type(url)
        return {
            "link_type": file_type.upper(),
            "page_title": filename,
            "content_hash": compute_dedup_hash(filename),
            "files": {file_type: body},
            "is_image": True,
            "source_url": url,
        }

    async def _crawl_attachment(
        self, page: Page, context: BrowserContext, url: str
    ) -> dict:
        """下载二进制附件"""
        filename = extract_filename_from_url(url)
        body = await self._download_binary_bytes(context, url)
        if body is None:
            raise RuntimeError(f"附件下载失败: {url}")

        file_type = detect_file_type(url)
        return {
            "link_type": file_type.upper(),
            "page_title": filename,
            "content_hash": "",
            "files": {file_type: body},
        }

    # ── Playwright 爬取原语 ───────────────────────────

    async def _fetch_html_content(self, page: Page, url: str) -> str | None:
        """用浏览器打开页面，获取完整 HTML"""
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
            await page.wait_for_load_state("domcontentloaded", timeout=30000)
            await page.wait_for_timeout(random.randint(2000, 6000))
            return await page.content()
        except Exception as e:
            logger.error(f"页面打开失败: {url}, 错误: {e}")
            return None

    async def _download_pdf_bytes(self, page: Page, url: str) -> bytes | None:
        """浏览器内 fetch 下载 PDF，校验 %PDF 魔数"""
        try:
            parent_url = url.rsplit("/", 1)[0] + "/"
            try:
                await page.goto(parent_url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
                await page.wait_for_timeout(random.randint(2000, 4000))
            except Exception as e:
                logger.warning(f"打开父页面失败: {e}，尝试直接 fetch")

            body_base64 = await page.evaluate("""
                async (url) => {
                    try {
                        const response = await fetch(url, { credentials: 'include' });
                        if (!response.ok) return { error: 'HTTP ' + response.status };
                        const buffer = await response.arrayBuffer();
                        const bytes = new Uint8Array(buffer);
                        let binary = '';
                        const chunkSize = 8192;
                        for (let i = 0; i < bytes.length; i += chunkSize) {
                            const chunk = bytes.subarray(i, i + chunkSize);
                            binary += String.fromCharCode.apply(null, chunk);
                        }
                        return { data: btoa(binary), size: bytes.length };
                    } catch (e) {
                        return { error: e.message };
                    }
                }
            """, url)

            if not body_base64 or (isinstance(body_base64, dict) and body_base64.get("error")):
                logger.error(f"PDF fetch 失败: {body_base64}")
                return None

            body = base64.b64decode(body_base64["data"])
            if len(body) <= 4 or body[:4] != b"%PDF":
                logger.error(f"下载内容不是有效 PDF: {url}")
                return None
            return body
        except Exception as e:
            logger.error(f"PDF 下载失败: {url}, 错误: {e}")
            return None

    async def _download_binary_bytes(
        self, context: BrowserContext, url: str
    ) -> bytes | None:
        """用 Playwright ctx.request.get 下载二进制资源"""
        try:
            response = await context.request.get(url, timeout=PAGE_TIMEOUT)
            if not response.ok:
                logger.error(f"二进制资源下载失败: {url}, HTTP {response.status}")
                return None
            body = await response.body()
            if not body:
                logger.warning(f"二进制资源下载内容为空: {url}")
                return None
            return body
        except Exception as e:
            logger.error(f"二进制资源下载失败: {url}, 错误: {e}")
            return None

    # ── 持久化：hash 比对 + S3 上传 + DB 更新 ─────────

    async def _persist(
        self,
        url: str,
        node: CrawlLinkTreeModel,
        crawl_result: dict,
    ) -> dict:
        """hash 比对，决定是否上传 S3 并更新 DB"""
        new_hash = crawl_result["content_hash"]
        files: dict[str, bytes] = crawl_result["files"]
        page_title = crawl_result["page_title"]
        link_type = crawl_result["link_type"]
        is_image = crawl_result.get("is_image", False)

        # 附件不计算内容 hash，每次都重新上传（按文件名+大小判等太弱）
        # 这里统一用 hash 比对：附件 hash 为空字符串，与 DB 不一致则上传
        existing_hash = node.content_hash or ""
        existing_file_list = node.crawl_file_list

        # hash 一致且有已存文件清单 → 跳过上传，复用 DB 数据
        if new_hash and existing_hash and new_hash == existing_hash and existing_file_list:
            logger.info(f"content_hash 一致，跳过上传与更新: {url}")
            return {
                "link_type": link_type,
                "page_title": node.page_title or page_title,
                "content_hash": new_hash,
                "crawl_file_list": _parse_file_list(existing_file_list),
                "changed": False,
            }

        # 上传 S3
        crawl_file_list = await self._upload_files(url, files, is_image, crawl_result.get("source_url"))

        # 更新 DB
        now = datetime.now()
        await self._repo.update_fields_by_url(
            url,
            page_title=page_title,
            content_hash=new_hash,
            crawl_file_list=_dump_file_list(crawl_file_list),
            last_crawl_time=now,
        )
        logger.info(f"已更新 crawl_link_tree: {url}, files={len(crawl_file_list)}")

        return {
            "link_type": link_type,
            "page_title": page_title,
            "content_hash": new_hash,
            "crawl_file_list": crawl_file_list,
            "changed": True,
        }

    async def _upload_files(
        self,
        url: str,
        files: dict[str, bytes],
        is_image: bool,
        source_url: str | None,
    ) -> list[dict]:
        """上传产物到 S3，返回 crawl_file_list 结构"""
        if self._s3_boundary is None:
            raise RuntimeError("S3Boundary 未配置，无法上传爬取产物")

        dir_name = build_dir_name(url)
        base_key = f"{S3_PAGE_CONTENT_PREFIX}/{dir_name}"
        crawl_file_list: list[dict] = []

        for file_type, body in files.items():
            # 文件名约定：网页 page.md/page.html/page_raw.html；附件/图片 用原始文件名
            if file_type == "markdown":
                object_key = f"{base_key}/page.md"
            elif file_type == "html":
                object_key = f"{base_key}/page.html"
            elif file_type == "rawHtml":
                object_key = f"{base_key}/page_raw.html"
            else:
                # 附件/图片：用原始文件名
                filename = extract_filename_from_url(url)
                object_key = f"{base_key}/{filename}"

            # 图片 markdown 引用需要替换 s3_path
            content = body
            if is_image and file_type != "markdown":
                pass  # 图片本体直接上传 bytes

            s3_path = await self._s3_boundary.upload_to_path(content, object_key)
            crawl_file_list.append({
                "file_type": file_type,
                "file_size": len(body),
                "s3_path": s3_path,
            })

        # 图片：补生成 markdown 引用并上传
        if is_image:
            image_s3 = next(
                (f["s3_path"] for f in crawl_file_list if f["file_type"] != "markdown"),
                None,
            )
            if image_s3:
                filename = extract_filename_from_url(url)
                markdown = f"![{filename}]({image_s3})"
                md_key = f"{base_key}/page.md"
                md_s3 = await self._s3_boundary.upload_to_path(markdown, md_key)
                crawl_file_list.append({
                    "file_type": "markdown",
                    "file_size": len(markdown.encode("utf-8")),
                    "s3_path": md_s3,
                })

        return crawl_file_list


# ── JSON 序列化辅助 ─────────────────────────────────────


import json


def _dump_file_list(file_list: list[dict]) -> str:
    """序列化 crawl_file_list 为 JSON 字符串"""
    return json.dumps(file_list, ensure_ascii=False)


def _parse_file_list(file_list_str: str | None) -> list[dict]:
    """反序列化 crawl_file_list JSON 字符串"""
    if not file_list_str:
        return []
    try:
        data = json.loads(file_list_str)
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, TypeError):
        return []

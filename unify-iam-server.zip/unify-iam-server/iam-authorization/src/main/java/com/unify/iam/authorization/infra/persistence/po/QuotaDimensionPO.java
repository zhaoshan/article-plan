package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** G1 配额维度注册表（模板）：gateway_quota_dimension。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_quota_dimension")
public class QuotaDimensionPO extends BaseEntity {

    /** 维度业务唯一标识 */
    private String dimensionId;
    /** 归属应用：iam=租户全局维度；具体应用=应用专属维度 */
    private String appCode;
    /** 维度键：members/apps/agents/storage_mb… */
    private String dimensionKey;
    /** 展示名 */
    private String dimensionName;
    /** 单位（可空） */
    private String unit;
    /** 模板默认上限；NULL=不限 */
    private Integer defaultLimit;
    /** 计数来源：IAM=IAM 实时计数并强制；BUSINESS=业务上报，IAM 只存上限 */
    private String source;
    /** 展示顺序，小者先 */
    private Integer sortOrder;
}

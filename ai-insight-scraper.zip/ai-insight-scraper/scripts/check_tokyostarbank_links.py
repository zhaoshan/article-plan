# -*- coding: utf-8 -*-
"""
检查 tokyostarbank 链接可达性脚本

功能：
1. 读取 crawl_output/all_links_tag_result.xlsx
2. 对 A 列中 https://tokyostarbank.co.jp/xxx 域名的 URL 统一加上 www.
3. 对 I 列值为 TBD 的行，使用 Chromium 打开 URL，判断页面状态：
   - 包含「お探しのページが見つかりませんでした」或「お探しのページは見つかりません」→ K列记录：页面能打开，但提示不存在
   - 超时无法打开 → K列记录：页面无法打开
   - 正常可访问 → K列记录：页面正常
4. 将结果写回 Excel

用法：
    # CDP 模式（连接已运行的 Chrome，推荐，速度快）
    python -m app.scripts.check_tokyostarbank_links

    # 本地 Chromium 模式
    python -m app.scripts.check_tokyostarbank_links --local-chromium

    # 显示浏览器窗口（调试用）
    python -m app.scripts.check_tokyostarbank_links --local-chromium --visible

    # 从指定行号继续（跳过已处理的行）
    python -m app.scripts.check_tokyostarbank_links --start-row 100

    # 仅修改 www. 前缀，不做页面检查
    python -m app.scripts.check_tokyostarbank_links --fix-url-only
"""

import asyncio
import logging
import re
import sys
import argparse
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from playwright.async_api import async_playwright, Browser, BrowserContext, Page

# 确保项目根目录在 sys.path 中
import os
_project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 解决 Windows 控制台 UTF-8 编码问题
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ==================== 常量配置 ====================

# Excel 文件路径
EXCEL_PATH = Path(__file__).parent.parent.parent / "crawler" / "service" / "crawl_output" / "all_links_tag_result.xlsx"

# 目标域名
TARGET_DOMAIN = "tokyostarbank.co.jp"

# 页面不存在的标识文本
NOT_FOUND_TEXTS = [
    "お探しのページが見つかりませんでした",
    "お探しのページは見つかりません",
]

# 结果文本
RESULT_NOT_FOUND = "页面能打开，但提示不存在"
RESULT_TIMEOUT = "页面无法打开"
RESULT_OK = "页面正常"

# 浏览器 User-Agent
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)

# CDP 默认调试端口
CDP_DEBUG_PORT = 9222

# 页面超时时间（毫秒）
PAGE_TIMEOUT = 60000

# 等待动态内容加载时间（毫秒）
WAIT_DYNAMIC_MS = 3000

# Chromium 启动参数
CHROMIUM_ARGS = [
    '--disable-blink-features=AutomationControlled',
    '--disable-features=VizDisplayCompositor',
    '--disable-dev-shm-usage',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-software-rasterizer',
    '--disable-gpu',
]

# ==================== 日志配置 ====================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def _find_chrome_path() -> str:
    """查找本地 Chrome 浏览器可执行文件路径"""
    import platform

    system = platform.system()
    if system == "Windows":
        paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
    elif system == "Darwin":
        paths = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        ]
    else:
        paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
        ]

    for path in paths:
        if os.path.exists(path):
            return path
    return ""


def is_tokyostarbank_url(url: str) -> bool:
    """
    判断 URL 是否属于 tokyostarbank.co.jp 域名（不含子域名）
    即：https://tokyostarbank.co.jp/xxx 或 http://tokyostarbank.co.jp/xxx
    不包括 app.tokyostarbank、direct.tokyostarbank 等子域名
    """
    if not url:
        return False
    try:
        parsed = urlparse(url)
        host = parsed.netloc
        # 精确匹配 tokyostarbank.co.jp（不含 www）
        return host == TARGET_DOMAIN
    except Exception:
        return False


def add_www_prefix(url: str) -> str:
    """
    将 https://tokyostarbank.co.jp/xxx 转为 https://www.tokyostarbank.co.jp/xxx
    将 http://tokyostarbank.co.jp/xxx 转为 http://www.tokyostarbank.co.jp/xxx
    """
    if not url:
        return url
    # 替换协议后的域名部分
    url = url.replace("://tokyostarbank.co.jp", "://www.tokyostarbank.co.jp", 1)
    return url


async def check_page_status(page: Page, url: str) -> str:
    """
    使用 Chromium 打开页面，判断页面状态

    Args:
        page: Playwright Page 对象
        url: 要检查的 URL

    Returns:
        状态文本：RESULT_OK / RESULT_NOT_FOUND / RESULT_TIMEOUT
    """
    try:
        response = await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
        await page.wait_for_load_state("domcontentloaded", timeout=30000)
        # 等待动态内容加载
        await page.wait_for_timeout(WAIT_DYNAMIC_MS)

        # 获取页面文本内容
        page_content = await page.content()

        # 检查是否包含"页面不存在"的标识文本
        for not_found_text in NOT_FOUND_TEXTS:
            if not_found_text in page_content:
                logger.info(f"  → {RESULT_NOT_FOUND}")
                return RESULT_NOT_FOUND

        logger.info(f"  → {RESULT_OK}")
        return RESULT_OK

    except Exception as e:
        logger.warning(f"  → {RESULT_TIMEOUT} ({type(e).__name__}: {e})")
        return RESULT_TIMEOUT


async def run_check(excel_path: str, use_cdp: bool = True, cdp_port: int = CDP_DEBUG_PORT,
                    headless: bool = True, start_row: int = 2, fix_url_only: bool = False):
    """
    主流程

    Args:
        excel_path: Excel 文件路径
        use_cdp: 是否使用 CDP 连接已运行的 Chrome
        cdp_port: CDP 调试端口
        headless: 是否无头模式
        start_row: 从第几行开始处理（跳过已处理的行）
        fix_url_only: 仅修改 URL 的 www. 前缀，不做页面检查
    """
    import openpyxl

    excel_file = Path(excel_path)
    if not excel_file.exists():
        logger.error(f"Excel 文件不存在: {excel_file}")
        return

    # 1. 读取 Excel
    logger.info(f"正在读取 Excel 文件: {excel_file}")
    wb = openpyxl.load_workbook(excel_file)
    ws = wb.active
    max_row = ws.max_row
    logger.info(f"共 {max_row} 行数据")

    # 2. 对 K 列匹配特定值的行，在 M 列设置最后更新时间
    UPDATE_TIME = "2026-06-16 23:35:07"
    K_TARGET_VALUES = {"页面正常", "页面无法打开", "页面能打开，但提示不存在"}
    m_update_count = 0
    for row in range(2, max_row + 1):
        k_val = str(ws.cell(row=row, column=11).value or '').strip()
        if k_val in K_TARGET_VALUES:
            ws.cell(row=row, column=13).value = UPDATE_TIME
            m_update_count += 1
    logger.info(f"共 {m_update_count} 行 K 列匹配目标值，已设置 M 列更新时间")

    # 3. 对 K 列匹配目标值的行，将 I 列改为 TBD
    i_update_count = 0
    for row in range(2, max_row + 1):
        k_val = str(ws.cell(row=row, column=11).value or '').strip()
        i_val = str(ws.cell(row=row, column=9).value or '').strip()
        if k_val in K_TARGET_VALUES and i_val != 'TBD':
            ws.cell(row=row, column=9).value = 'TBD'
            i_update_count += 1
    logger.info(f"共 {i_update_count} 行 I 列已改为 TBD")

    # 4. 修改 A 列中 tokyostarbank.co.jp 域名的 URL，加上 www.
    fix_count = 0
    for row in range(2, max_row + 1):
        a_val = ws.cell(row=row, column=1).value
        if a_val and is_tokyostarbank_url(str(a_val)):
            new_url = add_www_prefix(str(a_val))
            if new_url != str(a_val):
                ws.cell(row=row, column=1).value = new_url
                fix_count += 1
                logger.debug(f"Row {row}: {a_val} → {new_url}")

    logger.info(f"共修改 {fix_count} 个 URL，添加 www. 前缀")

    if fix_url_only:
        # 仅修改数据，保存并退出
        wb.save(excel_file)
        logger.info(f"已保存修改到 {excel_file}")
        wb.close()
        return

    # 5. 使用 Chromium 逐个检查页面状态
    # 筛选需要检查的 URL：A 列包含 www.tokyostarbank.co.jp 域名，且 I 列值为 TBD，且 K 列无已有结果
    check_rows = []
    for row in range(start_row, max_row + 1):
        a_val = str(ws.cell(row=row, column=1).value or '')
        i_val = str(ws.cell(row=row, column=9).value or '').strip()
        k_val = str(ws.cell(row=row, column=11).value or '').strip()
        # 只检查 www.tokyostarbank.co.jp 域名且 I 列为 TBD 且 K 列无结果的链接
        if 'www.tokyostarbank.co.jp' in a_val and i_val == 'TBD' and not k_val:
            check_rows.append(row)

    total_to_check = len(check_rows)
    logger.info(f"需要检查的 tokyostarbank 链接共 {total_to_check} 条（从第 {start_row} 行开始）")

    if total_to_check == 0:
        wb.save(excel_file)
        logger.info("无需检查的链接，已保存 URL 修改")
        wb.close()
        return

    async with async_playwright() as p:
        browser = None
        cdp_browser = None
        ctx = None

        try:
            if use_cdp:
                cdp_url = f"http://127.0.0.1:{cdp_port}"
                logger.info(f"正在通过 CDP 连接已运行的 Chrome: {cdp_url}")
                cdp_browser = await p.chromium.connect_over_cdp(
                    endpoint_url=cdp_url,
                    timeout=30000,
                )
                contexts = cdp_browser.contexts
                if contexts:
                    ctx = contexts[0]
                    logger.info(f"已连接 Chrome，复用现有 context（共 {len(contexts)} 个）")
                else:
                    ctx = await cdp_browser.new_context(
                        viewport={"width": 1920, "height": 1080},
                        user_agent=USER_AGENT,
                    )
                    logger.info("已连接 Chrome，创建新 context")
            else:
                chrome_path = _find_chrome_path()
                if chrome_path:
                    logger.info(f"使用本地 Chrome: {chrome_path}")
                    browser = await p.chromium.launch(
                        executable_path=chrome_path,
                        headless=headless,
                        args=CHROMIUM_ARGS,
                    )
                else:
                    logger.info("使用 Playwright 自带的 Chromium")
                    browser = await p.chromium.launch(
                        headless=headless,
                        args=CHROMIUM_ARGS,
                    )
                ctx = await browser.new_context(
                    viewport={"width": 1920, "height": 1080},
                    user_agent=USER_AGENT,
                )

            # 逐个检查页面
            page = await ctx.new_page()
            ok_count = 0
            not_found_count = 0
            timeout_count = 0
            skip_count = 0
            save_interval = 50  # 每 50 条保存一次

            for idx, row in enumerate(check_rows):
                url = str(ws.cell(row=row, column=1).value or '')
                k_val = ws.cell(row=row, column=11).value
                i_val = str(ws.cell(row=row, column=9).value or '').strip()

                # 仅对 I 列为 TBD 的行做判定（已在筛选时保证，此处为兜底）
                if i_val != 'TBD':
                    skip_count += 1
                    continue

                # 如果 K 列已有结果，跳过（支持断点续查）
                if k_val and str(k_val).strip():
                    skip_count += 1
                    continue

                logger.info(f"[{idx + 1}/{total_to_check}] Row {row}: {url}")

                result = await check_page_status(page, url)

                # 写入 K 列
                ws.cell(row=row, column=11).value = result

                if result == RESULT_OK:
                    ok_count += 1
                    # 页面正常可访问，将 I 列改为 Y
                    ws.cell(row=row, column=9).value = 'Y'
                    logger.info(f"  → I 列已改为 Y")
                elif result == RESULT_NOT_FOUND:
                    not_found_count += 1
                else:
                    timeout_count += 1

                # 定期保存
                if (idx + 1) % save_interval == 0:
                    wb.save(excel_file)
                    logger.info(f"已保存进度（已检查 {idx + 1}/{total_to_check}）")

                # 每个页面之间稍微等待，避免过快请求
                await page.wait_for_timeout(1000)

            # 最终保存
            wb.save(excel_file)
            logger.info(f"所有检查完成，已保存到 {excel_file}")
            logger.info(f"统计: 正常={ok_count}, 不存在={not_found_count}, 无法打开={timeout_count}, 跳过已有结果={skip_count}")

        except Exception as e:
            logger.error(f"检查过程出错: {e}")
            import traceback
            traceback.print_exc()
            # 尝试保存已处理的结果
            try:
                wb.save(excel_file)
                logger.info(f"已保存部分结果到 {excel_file}")
            except Exception as save_err:
                logger.error(f"保存失败: {save_err}")
        finally:
            if browser:
                try:
                    await browser.close()
                except Exception:
                    pass
            if cdp_browser:
                try:
                    await cdp_browser.close()
                except Exception:
                    pass
            wb.close()


def main():
    """脚本入口"""
    parser = argparse.ArgumentParser(description="检查 tokyostarbank 链接可达性")
    parser.add_argument(
        "--excel",
        type=str,
        default=str(EXCEL_PATH),
        help=f"Excel 文件路径（默认: {EXCEL_PATH}）",
    )
    parser.add_argument(
        "--local-chromium",
        action="store_true",
        help="使用本地 Playwright Chromium（默认通过 CDP 连接已运行的 Chrome）",
    )
    parser.add_argument(
        "--cdp-port",
        type=int,
        default=CDP_DEBUG_PORT,
        help=f"CDP 调试端口（默认 {CDP_DEBUG_PORT}）",
    )
    parser.add_argument(
        "--visible",
        action="store_true",
        help="显示浏览器窗口（仅 --local-chromium 模式生效，调试用）",
    )
    parser.add_argument(
        "--start-row",
        type=int,
        default=2,
        help="从第几行开始处理（默认 2，跳过表头；可用于断点续查）",
    )
    parser.add_argument(
        "--fix-url-only",
        action="store_true",
        help="仅修改 URL 的 www. 前缀，不做页面检查",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=60,
        help="页面超时秒数（默认 60）",
    )

    args = parser.parse_args()

    global PAGE_TIMEOUT
    PAGE_TIMEOUT = args.timeout * 1000

    use_cdp = not args.local_chromium
    headless = not args.visible

    asyncio.run(run_check(
        excel_path=args.excel,
        use_cdp=use_cdp,
        cdp_port=args.cdp_port,
        headless=headless,
        start_row=args.start_row,
        fix_url_only=args.fix_url_only,
    ))


if __name__ == "__main__":
    main()

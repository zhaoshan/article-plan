---
path: iam-app/src/main/resources/db/migration/**
description: Flyway 迁移规则（已应用不可改，变更只新增）
---

- **已应用的迁移文件不可修改**：Flyway 按 checksum 校验，改动已应用版本会导致启动报 `Migration checksum mismatch`。需要变更只能新增 `V{n+1}__...sql`。
- **seed 分层**：`db/migration/` 只放 schema（V 迁移）；**`spring.flyway.locations: classpath:db/migration,db/seed`**——schema + **平台引导（`R__platform_bootstrap.sql`）默认应用**；`db/seed-dev/R__seed_dev.sql`（dev 数据）**不进任何环境 locations**——仅测试基类 `IamIntegrationTestBase` 的 `@DynamicPropertySource` 注入 + 手动参考；业务数据手动初始化。需要变更 seed 就改对应 `R__` 文件（测试重放 / 手动重新执行）。
- **环境相关 / 带占位的数据（Keycloak 配置、客户端密钥）仍放 `scripts/` 幂等手动脚本**（参照 `scripts/seed_sso_keycloak_dev.sql`），不做成迁移。
- **删 V 迁移文件后清 `target/classes` 残留**：否则旧迁移仍被应用（如曾删的 V2/V7），导致新旧 seed 混跑、隔离列不一致。
- 迁移文件命名：`V{n}__描述.sql`；建表沿用源 DDL 约定（自增 id + `{表}_id` CHAR(32) + 公共字段 + 逻辑删除 delete_flag）。

# Security design: email-first login decision and reset-email delivery

Date: 2026-10-23

Status: the immediate direct-browser split is confirmed. No email-verification, magic-link, or added user flow is allowed. Endpoint naming and the remaining identity/security-release decisions still require confirmation before implementation.

## 1. Evidence-based current state

| Area | Current behavior | Consequence for the requested flow |
|---|---|---|
| Account check | POST /api/v1/auth/user-exists accepts X-IAM-Service-Token, compares it in constant time with iam.versions.service-token, then returns data:{exists, auth_mode}. | Correctly kept out of a browser, but a SPA cannot call it without leaking a shared credential. |
| Account lookup | UserExistsService normalizes the input and queries gateway_user.primary_email, then examines active LOCAL and OIDC identities. | The source of truth is email plus identity records, not registration_source. |
| Local password login | IdentityVerificationService only queries gateway_user.username. Its failure message is consistently 401 "用户名或密码错误". | An email-first UI can send an existing user to password entry and still fail if that user's username differs from their primary email. |
| Registration | POST /api/v1/auth/register requires username and password; email is optional. RegisterService creates gateway_user, a LOCAL/password identity, and a PERSONAL tenant. | New email-first UI needs an explicit compatibility decision rather than silently assuming email is the username. |
| SSO | An OIDC-only account produces auth_mode=sso. OIDC authorization still needs a tenant_id. | An email lookup alone cannot safely select an SSO tenant or disclose an IdP configuration. |
| Response envelope | ApiEnvelopeAdvice wraps normal /api/v1 JSON success and failure responses as success/code/message/data. | The new endpoint must use the same envelope and real HTTP status codes. |
| Forgot password | POST /api/v1/auth/forgot-password normalizes email and creates a hashed 15-minute token for any user found by primary_email; its development response returns plaintext token. Unknown email returns a generic detail message. | It is not a production reset-email API; returning the token leaks a bearer credential and status differs by account existence. |
| Reset token use | PasswordResetService reads an active token, changes the password, then marks the token used. | The current select-then-update pattern needs compare-and-set or locking so concurrent reset requests cannot both succeed. |
| Session invalidation | Reset revokes refresh tokens only. Existing access tokens stay valid until their normal TTL because reset does not alter a claim checked by access-token consumers. | "All sessions invalidated" is not currently true for access tokens and needs a product/security decision. |
| Abuse controls | No application rate limiter, Redis-like shared store, CAPTCHA/bot defense, mail dependency, or authentication-event auditing is present. | These controls need to exist before a browser-visible account decision or mail endpoint is enabled. |
| Audit metadata | RequestIdFilter records request ID and derives IP from X-Forwarded-For without a trusted-proxy policy. | A rate limiter/audit trail must not trust user-supplied forwarding headers directly. |

Sources include the current UserExistsController, UserExistsService, LoginUiController, PasswordResetService, RegisterService, IdentityVerificationService, IamProperties, EnvelopePaths, RequestIdFilter, API manual, and lifecycle design.

## 2. Confirmed browser boundary

Do not change the existing POST /api/v1/auth/user-exists endpoint into a browser endpoint. It is a documented service endpoint and shares the versions/status-check credential. Reusing that credential in browser JavaScript would expose a secret that also authorizes other service-to-service reads.

The browser-facing need is a login-flow decision, not a general-purpose user-directory API. The user confirmed this exact public interaction:

1. Browser input of an email directly calls an IAM API.
2. An existing account immediately routes to password entry.
3. An absent account immediately routes to account creation.
4. No email ownership proof, magic link, or new user-facing step may be added.

The direct IAM browser endpoint is therefore the planned boundary. It must remain distinct from the service-only user-exists endpoint and cannot be released until limiter, auditing, trusted-proxy, and ingress controls are present.

The direct browser shape is not made secure by CORS, Origin, Referer, or a hidden frontend header. Those are routing/browser controls, not authentication.

## 3. Candidate browser contract

The following is the recommended minimal contract for final approval:

    POST /api/v1/auth/login/identifier
    Content-Type: application/json

    {
      "email": "person@example.com"
    }

    200
    {
      "success": true,
      "code": null,
      "message": null,
      "data": {
        "exists": true
      }
    }

The browser maps exists=true to password entry and exists=false to account creation. The endpoint must not return user_id, tenant_id, organization name, role, account state, auth_mode, provider key, mail-delivery status, or a reset token.

The confirmed direct branch is an existence signal:

- exists=true implies a retained account.
- exists=false implies no conflicting account under the selected product semantics.

The user selected the immediate branch and prohibited the privacy-first alternate flow. The response should therefore be minimal, while non-interactive technical controls contain the accepted enumeration risk.

All invalid input and policy errors remain real HTTP errors in the established envelope. 429 must use a generic message and Retry-After where appropriate. No error result should reveal more account state.

## 4. Account resolution rules to decide and implement

### 4.1 Canonical identifier

For this flow, normalize a validated email by trim plus lowercase before lookup. The request should require a syntactically valid email and a bounded length; the current @NotBlank-only DTO is not enough for a public email endpoint.

The effective identity state should be calculated from:

- a non-deleted gateway_user selected by primary_email;
- user_status;
- an active LOCAL/password identity;
- an active OIDC identity.

The existing LOCAL-preferred behavior for a dual-identity account is a useful default: a user with both identities can take PASSWORD and still choose organization SSO through the existing SSO entry. An OIDC-only result creates an unresolved conflict: the confirmed two-way response maps every existing account to password entry, but that account has no local credential. The public endpoint must not reveal a tenant or provider. This requires an explicit product decision before implementation.

An account with no usable identity is data corruption or an unsupported lifecycle state. It must not be redirected to CREATE_ACCOUNT because registration will later hit the unique-email constraint. Return a generic unavailable result, create a privacy-safe security signal, and remediate operationally.

Suspended and pending lifecycle states need an explicit product rule. The secure default is not to allow new registration for a retained email and not to reveal the suspension reason.

### 4.2 Username and email compatibility

The requested email-first UX conflicts with current local login semantics because LoginRequest calls the field username and IdentityVerificationService only looks up username.

Before enabling email-first login:

1. Audit existing cross-identity collisions where one user's username can equal another user's primary_email.
2. Decide whether the token endpoint accepts an email identifier in addition to legacy username, or whether the new password screen uses an intentionally separate email-aware credential path.
3. Preserve the generic 401 response for unknown user, disabled local identity, suspended account, and password mismatch.
4. Update JIT account association to fall back from username to primary_email only after reviewing collision handling. Current JitProvisioner only falls back by username.
5. For new email-first registrations, decide whether email becomes required and canonical while existing username clients remain compatible.

Silently treating every email as username is not safe for historical username-not-equal-email accounts.

## 5. Browser abuse and enumeration controls

The immediate branch UX is confirmed. Implement these as a required release set without adding a visible verification or challenge flow:

1. Edge control: non-interactive WAF/gateway bot defense and coarse IP velocity protection before traffic reaches IAM.
2. Application control: a shared, distributed token-bucket limiter keyed independently by trusted client IP and a keyed-HMAC fingerprint of normalized email. In-memory limits do not protect a multi-instance deployment.
3. Reset-mail control: stricter per-email and per-IP limits, plus a global circuit breaker/queue depth guard to protect the mail provider.
4. Trust boundary: only consume a forwarding header inserted by approved proxies. Otherwise derive the source address from the direct trusted connection. The current unconditional X-Forwarded-For behavior is insufficient for enforcement.
5. Uniform external behavior: invalid email, unknown email, local account, OIDC-only account, disabled account, and mail scheduling failure must not expose more than the approved UI decision. Never use timing, response text, or body fields as an account oracle.
6. Feature gate: leave the browser-facing route disabled until limiter, gateway controls, alerting, and deployment configuration are verified in the target environment.

Limit values should be configuration owned by security/SRE rather than source literals. The approved configuration must define burst, window, response, monitoring threshold, and incident escalation for both identifier and reset-mail traffic.

## 6. Audit and observability

Existing gateway_audit_log can retain relevant security events, but a high-volume public route should not write raw PII or secrets to it.

Record security-relevant events with:

- request ID, trusted client IP, user agent, route, limiter decision, and outcome class;
- a keyed-HMAC email fingerprint only when cross-event correlation is needed;
- no plaintext email, password, reset token, service token, account existence, auth_mode, tenant, or IdP/provider data.

Recommended event categories:

- AUTH_IDENTIFIER_RATE_LIMITED;
- AUTH_IDENTIFIER_DENIED;
- AUTH_RESET_REQUEST_ACCEPTED;
- AUTH_RESET_RATE_LIMITED;
- AUTH_RESET_DELIVERY_FAILED;
- AUTH_RESET_COMPLETED;
- AUTH_RESET_REPLAY_DENIED.

Normal high-volume request telemetry may be sent to a security log/SIEM rather than adding a database audit row for every request. Persisted audit records are appropriate for denied, throttled, reset completion, and delivery-failure events. Event catalog documentation and tests must be updated together.

## 7. Production password-reset design

Keep the currently documented browser request shape, POST /api/v1/auth/forgot-password with email, unless a compatibility review approves a replacement. Change its semantic result to one generic accepted response for every valid request. It must never return token, user details, auth_mode, or mail delivery result.

The production reset path should:

1. Normalize and validate the email.
2. Apply the reset-mail abuse controls before any user-specific work.
3. Queue a generic delivery request. A user with active LOCAL/password identity receives a reset email; an unknown, disabled, or SSO-only account receives the same HTTP response. Do not add an email-verification or a new user-facing branch to this process.
4. Generate a high-entropy reset token only for a reset-eligible account. Store only its hash in gateway_password_reset_token and invalidate previous tokens for that email.
5. Deliver a link to the configured reset-password frontend route. Never log the link or token.
6. Use an asynchronous delivery workflow with retry and alerting. Do not persist an unencrypted raw reset token in an outbox record. A preferred design creates the token in the delivery worker after it claims a queued generic request; each retry creates a fresh token and invalidates any older token.
7. Keep the reset token TTL at the approved value and consume it atomically with an update predicate such as unused, latest, and unexpired. Exactly one concurrent reset succeeds.
8. Enforce the password policy on the server, not only in the browser.
9. Revoke refresh tokens after successful reset, then apply the separately approved access-token invalidation policy.

The existing docs describe a JavaMail abstraction as a future implementation direction. The chosen implementation must reconcile that abstraction with asynchronous delivery and secret handling; no SMTP password, encryption key, reset token, or transport credential may enter source control or logs.

## 8. Session invalidation decision

Current PasswordResetService calls refreshTokenRepository.revokeByUser, but already issued JWT access tokens remain usable until expiration. Current default access TTL is 1800 seconds.

Choose one of:

- bounded invalidation: revoke refresh tokens and document that existing access tokens survive for at most their configured TTL;
- immediate invalidation: introduce a user-level session version or deliberately bump every relevant membership version and ensure all IAM consumers enforce it through the existing version feed.

The second option is stronger but touches cross-service JWT freshness semantics and cannot be implied by this UI change.

## 9. Test strategy after confirmation

### Unit and MVC tests

- email normalization, invalid syntax, length bounds, and generic error envelope;
- state matrix: no account, active LOCAL, active OIDC-only, dual identities, suspended/pending, and no-valid-identity anomaly;
- missing/wrong service credential remains rejected on the existing internal endpoint;
- browser route never accepts or requires the shared versions service token;
- no user, tenant, provider, token, or auth_mode leaks in browser response or error body;
- limiter keys, trusted-proxy behavior, 429 envelope, and Retry-After;
- audit redaction proves raw email/password/tokens are absent.

### Integration and concurrency tests

- existing local email chooses password and can complete password login;
- historical username-not-equal-email behavior follows the approved compatibility rule;
- OIDC-only behavior follows the approved tenant-safe rule;
- registration collision and case-normalization behavior;
- forgot-password always has the same accepted public response and no token field;
- only active LOCAL identity gets a reset credential; SSO-only does not create an orphan password hash;
- expired, old, malformed, and replayed token behavior is uniform;
- two concurrent reset submissions with one token cause exactly one password change;
- reset revokes refresh tokens and verifies the chosen access-token policy;
- mail queue success, retry, delivery failure, and no-raw-token-at-rest invariant;
- distributed limiter behavior across two application instances or a real shared test store.

### Existing baseline

The current UserExistsIntegrationTest covers service-token rejection, blank email, unknown/local/OIDC/dual identity responses. P3LoginUiIntegrationTest covers a development reset-token happy path. Neither suite currently covers public browser protection, real mail delivery, limiter behavior, audit redaction, SSO-only reset behavior, username/email mismatch, concurrent reset consumption, or access-token invalidation.

## 10. Rollout conditions

- Deploy transport credentials and limiter secrets through environment/secret management, never in application.yml or source.
- Configure the approved mail sender, reset-link base URL, bot-defense verifier, shared limiter store, trusted proxy chain, and audit sink.
- Enable behind a feature flag or ingress rule only after staging verifies rates, response envelopes, mail scheduling, redaction, and rollback behavior.
- Keep the existing service-only user-exists endpoint backward compatible unless an explicit API deprecation is approved.
- Update docs/08 and docs/user-manual/05 only once an actual browser contract is approved and implemented.

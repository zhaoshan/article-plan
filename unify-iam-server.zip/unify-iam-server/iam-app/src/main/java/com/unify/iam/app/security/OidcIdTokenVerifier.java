package com.unify.iam.app.security;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.factories.DefaultJWSVerifierFactory;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.app.oidc.OidcProviderClient;
import com.unify.iam.app.oidc.OidcProviderConfig;
import com.unify.iam.app.oidc.VerifiedClaims;
import com.unify.iam.common.exception.AuthException;
import java.security.Key;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

/**
 * OIDC ID Token 验签与 claim 映射（E2E-2 核心）。
 *
 * <p>流程（docs/03 §11.1）：算法白名单 → 拉 IdP JWKS 按 kid 选钥 → RS256/ES256 验签 →
 * 校验 iss/aud/exp/nonce → claim 映射。JWKS 缓存 300s，未知 kid 强制回源（同 parlant PyJWKClient）。
 */
@Component
public class OidcIdTokenVerifier {

    private static final long JWKS_TTL_MS = 300_000L; // 300s
    private static final Set<JWSAlgorithm> ALLOWED = Set.of(JWSAlgorithm.RS256, JWSAlgorithm.ES256);

    private final OidcProviderClient client;
    private final Map<String, CachedJwks> jwksCache = new ConcurrentHashMap<>();

    public OidcIdTokenVerifier(OidcProviderClient client) {
        this.client = client;
    }

    public VerifiedClaims verify(String idToken, OidcProviderConfig config, String expectedNonce) {
        try {
            SignedJWT jwt = SignedJWT.parse(idToken);
            JWSAlgorithm alg = jwt.getHeader().getAlgorithm();
            if (alg == null || !ALLOWED.contains(alg)) {
                throw AuthException.unauthorized("ID Token 算法不允许：" + alg);
            }
            List<? extends Key> keys = selectKeys(jwt, config);
            if (keys.isEmpty()) {
                jwksCache.remove(config.jwkSetUri()); // 未知 kid → 强制回源
                keys = selectKeys(jwt, config);
            }
            if (keys.isEmpty()) {
                throw AuthException.unauthorized("未找到匹配 kid 的 IdP 公钥");
            }
            JWSVerifier verifier = new DefaultJWSVerifierFactory()
                    .createJWSVerifier(jwt.getHeader(), keys.get(0));
            if (!jwt.verify(verifier)) {
                throw AuthException.unauthorized("ID Token 签名无效");
            }
            JWTClaimsSet cs = jwt.getJWTClaimsSet();
            if (config.issuer() != null && !config.issuer().equals(cs.getIssuer())) {
                throw AuthException.unauthorized("issuer 不匹配");
            }
            if (cs.getAudience() == null || !cs.getAudience().contains(config.clientId())) {
                throw AuthException.unauthorized("aud 不匹配");
            }
            if (cs.getExpirationTime() == null || !cs.getExpirationTime().after(new Date())) {
                throw AuthException.unauthorized("ID Token 已过期");
            }
            Object nonce = cs.getClaim("nonce");
            if (expectedNonce != null && !expectedNonce.equals(String.valueOf(nonce))) {
                throw AuthException.unauthorized("nonce 不匹配");
            }
            return mapClaims(config, cs);
        } catch (AuthException e) {
            throw e;
        } catch (java.text.ParseException e) {
            throw AuthException.unauthorized("ID Token 格式错误");
        } catch (Exception e) {
            throw AuthException.serviceUnavailable("ID Token 验签失败：" + e.getMessage());
        }
    }

    private List<? extends Key> selectKeys(SignedJWT jwt, OidcProviderConfig config) throws Exception {
        JWKSet jwkSet = fetchJwkSet(config.jwkSetUri());
        JWSKeySelector<SecurityContext> selector = new JWSVerificationKeySelector<>(
                new HashSet<>(ALLOWED), new ImmutableJWKSet<>(jwkSet));
        return selector.selectJWSKeys(jwt.getHeader(), null);
    }

    private JWKSet fetchJwkSet(String jwkSetUri) {
        CachedJwks cached = jwksCache.get(jwkSetUri);
        if (cached != null && cached.fetchedAt().plusMillis(JWKS_TTL_MS).isAfter(Instant.now())) {
            return cached.jwkSet();
        }
        String json = client.getString(jwkSetUri);
        try {
            JWKSet set = JWKSet.parse(json);
            jwksCache.put(jwkSetUri, new CachedJwks(set, Instant.now()));
            return set;
        } catch (Exception e) {
            throw AuthException.serviceUnavailable("JWKS 解析失败：" + e.getMessage());
        }
    }

    private VerifiedClaims mapClaims(OidcProviderConfig config, JWTClaimsSet cs) {
        Map<String, Object> mapped = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : config.claimMapping().entrySet()) {
            mapped.put(e.getKey(), cs.getClaim(e.getValue()));
        }
        List<String> groups = toStrList(mapped.get("groups"));
        return new VerifiedClaims(
                cs.getSubject(),
                strOf(mapped.get("email")),
                strOf(mapped.get("name")),
                groups,
                mapped);
    }

    private String strOf(Object value) {
        return value == null ? "" : String.valueOf(value);
    }

    private List<String> toStrList(Object value) {
        List<String> result = new ArrayList<>();
        if (value instanceof List<?> list) {
            list.forEach(o -> result.add(String.valueOf(o)));
        } else if (value != null) {
            result.add(String.valueOf(value));
        }
        return result;
    }

    private record CachedJwks(JWKSet jwkSet, Instant fetchedAt) {
    }
}
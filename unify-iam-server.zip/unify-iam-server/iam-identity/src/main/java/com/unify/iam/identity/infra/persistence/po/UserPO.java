package com.unify.iam.identity.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_user 用户主表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_user")
public class UserPO extends BaseEntity {

    /** 用户业务唯一标识 */
    private String userId;
    /** 平台登录名 */
    private String username;
    /** 主邮箱 */
    private String primaryEmail;
    /** 本地密码摘要（BCrypt） */
    private String passwordHash;
    /** 用户全名 */
    private String fullName;
    /** 前端展示名称 */
    private String displayName;
    private String avatarUrl;
    private String phoneNumber;
    private String locale;
    private String timeZone;
    /** 兼容字段：历史 workspaceId */
    private String tenantId;
    /** 默认进入的租户 */
    private String defaultTenantId;
    /** 邮箱是否已验证 */
    private Integer emailVerified;
    /** 账号状态：PENDING/ACTIVE/SUSPENDED/DELETED */
    private String userStatus;
    /** 首登必须改密（G2 初始密码账号）：登录响应透出，改密后清零 */
    private Integer mustChangePassword;
    /** 兼容字段：历史主登录来源 */
    private String authProvider;
    private String lastLoginProvider;
    /** 注册来源 */
    private String registrationSource;
    private LocalDateTime lastLoginTime;
    private LocalDateTime activatedAt;
    private LocalDateTime suspendedAt;
}

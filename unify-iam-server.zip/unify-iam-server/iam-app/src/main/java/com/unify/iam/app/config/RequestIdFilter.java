package com.unify.iam.app.config;

import com.unify.iam.app.security.RequestMeta;
import com.unify.iam.common.util.IdGenerator;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * 请求编号 Filter（G5-a）：为每个请求分配/透传 {@code X-Request-Id}，写入 request attribute + MDC + 响应头，
 * 供审计记录 {@code request_id} 与日志追踪使用。入站值做白名单清洗（防日志注入）。
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RequestIdFilter extends OncePerRequestFilter {

    private static final String HEADER = "X-Request-Id";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String id = sanitize(request.getHeader(HEADER));
        if (id == null) {
            id = IdGenerator.newBizId();
        }
        request.setAttribute(RequestMeta.REQUEST_ID_ATTR, id);
        response.setHeader(HEADER, id);
        MDC.put("requestId", id);
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.remove("requestId");
        }
    }

    /** 只允许字母数字与 ._-，最长 64；不合法 → null（改由服务端生成）。 */
    private String sanitize(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String cleaned = raw.trim().replaceAll("[^A-Za-z0-9._-]", "");
        if (cleaned.isEmpty()) {
            return null;
        }
        return cleaned.length() > 64 ? cleaned.substring(0, 64) : cleaned;
    }
}

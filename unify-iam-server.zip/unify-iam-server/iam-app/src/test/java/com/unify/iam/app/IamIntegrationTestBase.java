package com.unify.iam.app;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.containers.MySQLContainer;

/**
 * 集成测试基类：Testcontainers MySQL 8 + Flyway 自动建库 seed + 独立 JWT 密钥。
 *
 * <p>采用「手动单例容器」：static 一次性启动、JVM 退出才停（共享给所有子类），
 * 避免 JUnit5 + 继承的 {@code @Container} 字段在多个子类间"先停后复用"导致的连接失败。
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
public abstract class IamIntegrationTestBase {

    private static final MySQLContainer<?> MYSQL = startMysql();

    private static final Path KEY_DIR = createKeyDir();

    static {
        Runtime.getRuntime().addShutdownHook(new Thread(MYSQL::stop));
        Runtime.getRuntime().addShutdownHook(new Thread(() -> deleteRecursively(KEY_DIR)));
    }

    private static MySQLContainer<?> startMysql() {
        MySQLContainer<?> container = new MySQLContainer<>("mysql:8.0")
                .withDatabaseName("unify_iam")
                .withUsername("test")
                .withPassword("test");
        container.start();
        return container;
    }

    private static Path createKeyDir() {
        try {
            return Files.createTempDirectory("iam-it-keys");
        } catch (IOException e) {
            throw new IllegalStateException("创建测试密钥目录失败", e);
        }
    }

    private static void deleteRecursively(Path dir) {
        if (dir == null || !Files.exists(dir)) {
            return;
        }
        try (var paths = Files.walk(dir)) {
            paths.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException ignored) {
                    // ignore
                }
            });
        } catch (IOException ignored) {
            // ignore
        }
    }

    /** 统一信封解包：取响应体 {@code data}（前端管理台/hub 专属接口已套 {success,code,message,data}）。 */
    @SuppressWarnings("unchecked")
    protected Map<String, Object> unwrapData(String json) {
        Map<String, Object> body = JsonUtils.fromJson(json, Map.class);
        return body.get("data") instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of();
    }

    /** 统一信封解包：直接取字段值。 */
    protected Object unwrapField(String json, String field) {
        return unwrapData(json).get(field);
    }

    /** 统一信封解包：返回 {@code data} 的 JSON 字符串（供 {@code JsonUtils.fromJson(.., Type)} 复用原解析）。 */
    protected String dataJson(String json) {
        return JsonUtils.toJson(unwrapData(json));
    }

    @DynamicPropertySource
    static void datasourceProps(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", MYSQL::getJdbcUrl);
        registry.add("spring.datasource.username", MYSQL::getUsername);
        registry.add("spring.datasource.password", MYSQL::getPassword);
        registry.add("spring.flyway.enabled", () -> "true");
        // 测试需要 seed（admin/tenant-org-a/parlant + 平台引导）——生产/本地为 schema-only，seed 仅测试注入
        registry.add("spring.flyway.locations",
                () -> "classpath:db/migration,classpath:db/seed,classpath:db/seed-dev");
        registry.add("iam.jwt.private-key-path", () -> KEY_DIR.resolve("it-rsa.pem").toString());
        registry.add("iam.versions.service-token", () -> "it-service-token"); // 版本 feed（方案 c）测试令牌
        // 邮件通道强制日志模式：测试不依赖本机 application.yml 的 SMTP 配置（真实发送会在 CI/本地炸 500）
        registry.add("spring.mail.host", () -> "");
        registry.add("spring.mail.username", () -> "");
        registry.add("iam.mail.invitation-link-base-url", () -> "http://localhost:5173");
    }

    @Autowired
    protected MockMvc mockMvc;

    @Autowired
    protected JdbcTemplate jdbcTemplate;
}
-- V10：方案 c 即时吊销——成员令牌版本（IAM docs/07 §8.3 待办 c；parlant doc11 附录 B）。
-- gateway_membership.token_version：角色/权限变更时 +1；JWT 带签发时的 ver（token_version），落后即失效。
-- gateway_membership_version_log：版本变更日志，支撑 parlant 增量 feed（自增 id 作游标，支持全量快照/增量/tombstone）。

ALTER TABLE `gateway_membership`
    ADD COLUMN `token_version` INT NOT NULL DEFAULT 0 COMMENT '令牌版本：角色/权限变更时+1，JWT ver 落后即失效（方案c即时吊销）' AFTER `is_default`;

CREATE TABLE IF NOT EXISTS `gateway_membership_version_log` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键（版本 feed 游标）',
    `log_id` CHAR(32) NOT NULL COMMENT '日志业务唯一标识',
    `membership_id` CHAR(32) NOT NULL COMMENT '成员关系ID',
    `tenant_id` CHAR(32) NOT NULL COMMENT '租户ID（feed app 作用域过滤用）',
    `token_version` INT NOT NULL DEFAULT 0 COMMENT '变更后的 token_version（tombstone 行恒 0）',
    `change_type` VARCHAR(20) NOT NULL COMMENT '变更类型：ROLE_CHANGE/PERM_CHANGE/MEMBERSHIP_REMOVE',
    `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
    `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
    `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_gateway_membership_version_log_id` (`log_id`),
    KEY `idx_membership_id` (`membership_id`),
    KEY `idx_tenant_id_id` (`tenant_id`, `id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成员令牌版本变更日志（方案c即时吊销 feed 数据源）';

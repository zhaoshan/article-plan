# Email-first login and reset-mail design plan

Date: 2026-10-23

Status: Phase 1 contract consolidation in progress. The immediate two-way browser flow is confirmed; no business implementation has started.

## Scope and constraints

- Work only in the current platform-iam-service main worktree.
- Keep every task, design, check, and session artifact below this repository's .trellis directory.
- Do not access, modify, create, or inspect another Platform IAM project.
- Do not create or delete a worktree; do not switch, reset, commit, merge, or push a branch.
- Do not change product source, API contracts, migrations, configuration, or tests before the required decision gates are confirmed.
- The repository contains no AGENTS.md and no .trellis/workflow.md, including under hidden and ignored paths searched from this worktree. The actual project instruction file, CLAUDE.md, was read and is being followed. The unavailable Trellis-specific gates cannot be inferred or executed.

## Requested outcome

The login UI must accept an email first, directly call an API, and immediately choose an appropriate next page:

1. an existing account proceeds to password entry;
2. an account that does not exist proceeds to account creation;
3. the reset-password screen submits a reset-email request.

The server design must not use the generic credential error from POST /api/v1/auth/token as an account-existence oracle.

Confirmed product constraints:

- Do not add email ownership verification, a magic link, or another user-facing preflight.
- The immediate branch is intentionally browser-visible. Its residual account-enumeration risk must be contained by non-interactive technical controls, not by changing the user journey.

## Completed evidence gathering

- [x] Read CLAUDE.md, relevant .claude security and migration rules, current lifecycle/login documentation, API manual, source, DTOs, repositories, and integration tests.
- [x] Confirm the repository has no AGENTS.md or .trellis/workflow.md; preserve pre-existing untracked .trellis material.
- [x] Confirm POST /api/v1/auth/user-exists already exists, but only accepts X-IAM-Service-Token and is documented as a service-to-service endpoint.
- [x] Confirm that user-exists returns exists plus auth_mode by looking up gateway_user.primary_email and active LOCAL/OIDC identities.
- [x] Confirm the public password login currently only resolves username, whereas the account check resolves primary_email.
- [x] Confirm that registration currently requires username, makes email optional, and creates a LOCAL identity plus a PERSONAL tenant.
- [x] Confirm that POST /api/v1/auth/forgot-password currently returns a plaintext reset token for an existing account, has no actual mail sender, and returns a generic message only for an unknown email.
- [x] Confirm there is no application-level rate limiter, no mail dependency, and no authentication-event audit usage; current AuditService is used by management operations.
- [x] Confirm all normal /api/v1 JSON responses use the existing success/code/message/data envelope, except the documented OIDC redirect family.
- [x] Run the relevant existing Testcontainers baseline successfully: UserExistsIntegrationTest (7 tests) and P3LoginUiIntegrationTest (4 tests).
- [x] Record the user's explicit confirmation of the immediate existing-versus-absent route and the prohibition on an added email-verification/user flow.

## Proposed implementation sequence after confirmation

1. Close the remaining identity and credential-compatibility decisions below; the browser direction is now direct IAM API access, not a BFF implementation.
2. Add a dedicated public login-identifier use case without weakening or exposing the current service-only user-exists endpoint.
3. Align email-first authentication with the existing username/password model and define behavior for LOCAL-only, OIDC-only, mixed, suspended, and anomalous accounts.
4. Add distributed abuse controls, trusted-proxy handling, privacy-safe security telemetry, and operational configuration before enabling browser traffic.
5. Replace the development reset-token response with production mail scheduling and an asynchronous delivery mechanism that never persists or returns a plaintext reset token.
6. Make reset-token consumption atomic; define a password policy and decide whether password reset invalidates currently issued access tokens immediately or at the existing access-token TTL.
7. Add focused unit, MVC, integration, concurrency, and operational tests; update the current repository documentation and API inventory.
8. Run the focused suites and the project-appropriate broader verification, then record results in this task. A commit remains forbidden unless the user explicitly asks for one after reviewing the file list.

## Confirmation gates

### Gate 1: account enumeration and UX - confirmed

The requested branch is observable to an unauthenticated browser. Returning password versus create-account necessarily reveals useful account-existence information.

The user explicitly selected bounded-enumeration UX:

- Browser email input immediately calls an API.
- Existing account routes to password entry; absent account routes to account creation.
- No email-verification, magic-link, or added user flow may be inserted.
- Technical controls remain mandatory: rate limits, monitoring, minimal response data, generic error messages, and non-interactive gateway abuse protection.

### Gate 2: browser integration boundary - direction confirmed

The current login hub is documented as a browser SPA and has no independent BFF in this repository. The confirmed product wording requires the browser to call an IAM API directly. A browser must never receive IAM_VERSIONS_SERVICE_TOKEN.

Therefore the planned direction is a new, public, browser-safe IAM identifier endpoint. It is distinct from the existing service-only user-exists endpoint. The direct route cannot be enabled until the Gate 4 release controls are available.

### Candidate direct-browser contract

This is the recommended contract to finalize after Gate 3:

    POST /api/v1/auth/login/identifier
    Content-Type: application/json

    { "email": "person@example.com" }

    200
    { "success": true, "code": null, "message": null, "data": { "exists": true } }

The browser maps exists=true to password entry and exists=false to account creation. POST keeps the email out of a URL. The public body contains no user ID, tenant, provider, auth_mode, mail status, reset token, or account lifecycle detail. The existing POST /api/v1/auth/user-exists remains unchanged for trusted service callers.

### Gate 3: identity semantics and credential compatibility

These decisions remain open and block implementation:

1. OIDC-only account: the confirmed two-way contract would route every existing account to password entry, but an OIDC-only account cannot complete local password authentication. Decide whether email-first applies only to the existing local-account entry while enterprise SSO remains its current separate entry, or whether a third response is permitted despite the two-way product rule.
2. Suspended/pending account: decide whether it is treated as existing and reaches password entry with the existing generic failure, or receives another generic behavior. It must never be treated as absent because registration would later violate the unique email constraint.
3. Username/email compatibility: decide whether the password submit endpoint accepts primary_email as a legacy-compatible alias for username, and how to resolve historical cross-column collisions.
4. Registration contract: decide whether the create-account page continues to collect the existing required username, or whether the server derives a compatible username from the required email while preserving existing API clients.

### Gate 4: production controls

Confirm the mail provider/secret-management path, Redis or equivalent distributed limiter, approved bot-defense mechanism, trusted reverse-proxy model for client IP, audit/SIEM retention, and password-reset access-token invalidation policy.

## Current validation

The first Maven invocation on the current JDK 26 failed before tests because JDK 26 disables automatic annotation-processor discovery and Lombok accessors were missing. The repository's earlier Trellis record documents the required compiler switch. With the switch and Docker access, the focused test command passed 11 tests:

    mvn -pl iam-app -am test -Dtest='UserExistsIntegrationTest,P3LoginUiIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full

No source or API contract was changed as part of this validation.

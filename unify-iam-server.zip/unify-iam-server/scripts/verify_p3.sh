#!/usr/bin/env bash
# ============================================================
# verify_p3.sh — unify-iam-server P3 端到端 curl 验证（无前端）
# 覆盖：自身鉴权 / 管理面 CRUD / 邀请 / 加入申请 / 切换租户 / refresh / 找回重置 / 域名验证 / 负向 / 审计
# 前置：IAM 已启动（最新 P3 代码，端口 8090）；本机 Docker MySQL（unify_iam）用于 DB 断言（best-effort）
# 用法：bash scripts/verify_p3.sh
# ============================================================
set -u
BASE="${IAM_BASE:-http://127.0.0.1:8090}"
BODY_FILE=/tmp/vp_body
DB_EXEC=(docker exec spring-ai-alibaba-mysql sh -c 'mysql -uroot -proot123456 -N -e "$1"' _)
PASS=0; FAIL=0
SUF="$(date +%H%M%S)"
U1="vuser${SUF}"; U2="vuser2${SUF}"
E1="${U1}@unify.local"; E2="${U2}@unify.local"

say() { printf '%-46s' "$1"; }
ok()  { echo "PASS"; PASS=$((PASS+1)); }
bad() { echo "FAIL: $1"; FAIL=$((FAIL+1)); }
check() { # check <desc> <actual> <expected-substr>
  local desc="$1" actual="$2" expect="$3"
  say "$desc"
  case "$actual" in *"$expect"*) ok;; *) bad "got '${actual:0:120}' expect contains '$expect'";; esac
}
check_nb() { # check_nb <desc> <value>：非空断言
  local desc="$1" val="$2"
  say "$desc"
  [ -n "$val" ] && ok || bad "值为空"
}
# http <args...> -> 状态码(stdout)，body 写 $BODY_FILE
http() { curl -s -o "$BODY_FILE" -w '%{http_code}' "$@"; }
# jget <python-expr>：从 $BODY_FILE 取字段
jget() { python3 -c "import json;print(json.load(open('$BODY_FILE'))$1)"; }
body() { cat "$BODY_FILE"; }
login() { # login <user> <pass> -> access_token
  local code
  code=$(http -X POST "$BASE/api/v1/auth/token" -H 'Content-Type: application/json' \
    -d "{\"username\":\"$1\",\"password\":\"$2\"}")
  [ "$code" = "200" ] && jget "['access_token']" || { echo ""; }
}
db() { "${DB_EXEC[@]}" "$1" 2>/dev/null | head -1; }

echo "== P3 端到端验证（unify-iam-server） =="

# 1. JWKS
code=$(http "$BASE/.well-known/jwks.json")
check "1. JWKS 200" "$code" "200"
check "1b. JWKS alg=RS256 kid" "$(body)" "RS256"

# 2. admin 登录带 iam:*（自身鉴权地基）
ADMIN=$(login admin admin123)
[ -n "$ADMIN" ] || { echo "FAIL: admin 登录失败"; exit 1; }
code=$(http "$BASE/api/v1/auth/me" -H "Authorization: Bearer $ADMIN")
ME=$(body)
check "2. admin /me 200" "$code" "200"
check "2b. admin /me 含 PlatformAdmin" "$ME" "PlatformAdmin"
check "2c. admin /me 含 iam:user:read" "$ME" "iam:user:read"

# 3. 注册 → 个人租户可登录
code=$(http -X POST "$BASE/api/v1/auth/register" -H 'Content-Type: application/json' \
  -d "{\"username\":\"$U1\",\"email\":\"$E1\",\"password\":\"Passw0rd!\"}")
check "3. 注册返回 user_id" "$(body)" "user_id"
UT=$(login "$U1" "Passw0rd!")
check_nb "3b. 新用户可登录" "$UT"
T_TYPE=$(db "SELECT tenant_type FROM unify_iam.gateway_tenant t JOIN unify_iam.gateway_membership m ON m.tenant_id=t.tenant_id WHERE m.user_id=(SELECT user_id FROM unify_iam.gateway_user WHERE username='$U1') AND t.tenant_type='PERSONAL' LIMIT 1")
check "3c. 注册自动建 PERSONAL 租户" "$T_TYPE" "PERSONAL"

# 4. 管理面 CRUD：建租户 + 建角色 + 授权
code=$(http -X POST "$BASE/api/v1/admin/tenants" -H "Authorization: Bearer $ADMIN" -H 'Content-Type: application/json' \
  -d "{\"tenant_code\":\"t1$SUF\",\"tenant_name\":\"T1 $SUF\",\"tenant_type\":\"ORGANIZATION\"}")
T1ID=$(jget "['tenant_id']")
check_nb "4. 建租户返回 tenant_id" "$T1ID"
code=$(http -X POST "$BASE/api/v1/admin/roles" -H "Authorization: Bearer $ADMIN" -H 'Content-Type: application/json' \
  -d "{\"scope_type\":\"TENANT\",\"scope_id\":\"$T1ID\",\"role_code\":\"Vr\",\"role_name\":\"V 角色\"}")
RID=$(jget "['role_id']")
check_nb "4b. 建角色返回 role_id" "$RID"
code=$(http -X PUT "$BASE/api/v1/admin/roles/$RID/permissions" -H "Authorization: Bearer $ADMIN" -H 'Content-Type: application/json' \
  -d '{"permission_ids":["p-1001","p-1003"]}')
check "4c. 角色授权 200" "$code" "200"

# 5. 邀请 → 接受
code=$(http -X POST "$BASE/api/v1/admin/invitations" -H "Authorization: Bearer $ADMIN" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$E1\",\"tenant_id\":\"tenant-org-a\",\"role_id\":\"r-1001\"}")
ITOK=$(jget "['token']")
check_nb "5. 邀请返回 token" "$ITOK"
code=$(http -X POST "$BASE/api/v1/auth/invitations/$ITOK/accept" -H "Authorization: Bearer $UT")
check "5b. 接受邀请 200" "$code" "200"
code=$(http "$BASE/api/v1/auth/memberships" -H "Authorization: Bearer $UT")
MS=$(body)
check "5c. memberships 含 tenant-org-a" "$MS" "tenant-org-a"

# 6. 切换租户（单租户重签）
ORG_MS=$(echo "$MS" | python3 -c "
import sys,json
for m in json.load(sys.stdin)['memberships']:
    if m['tenant_id']=='tenant-org-a': print(m['membership_id'])")
check_nb "6. 找到 tenant-org-a 成员" "$ORG_MS"
code=$(http -X POST "$BASE/api/v1/auth/switch-tenant" -H "Authorization: Bearer $UT" -H 'Content-Type: application/json' \
  -d "{\"membership_id\":\"$ORG_MS\"}")
SW=$(jget "['access_token']")
code=$(http "$BASE/api/v1/auth/me" -H "Authorization: Bearer $SW")
check "6b. 切换后 /me tenantId=tenant-org-a" "$(body)" "tenant-org-a"

# 7. refresh 轮换
code=$(http -X POST "$BASE/api/v1/auth/token" -H 'Content-Type: application/json' -d "{\"username\":\"$U1\",\"password\":\"Passw0rd!\"}")
RT=$(jget "['refresh_token']")
check_nb "7. 登录返回 refresh_token" "$RT"
code=$(http -X POST "$BASE/api/v1/auth/refresh" -H 'Content-Type: application/json' -d "{\"refresh_token\":\"$RT\"}")
NEW_AT=$(jget "['access_token']")
check_nb "7b. refresh 返回新 access" "$NEW_AT"
code=$(http -X POST "$BASE/api/v1/auth/refresh" -H 'Content-Type: application/json' -d "{\"refresh_token\":\"$RT\"}")
check "7c. 旧 refresh 复用 401" "$code" "401"

# 8. 找回 / 重置（独立用户）
code=$(http -X POST "$BASE/api/v1/auth/register" -H 'Content-Type: application/json' \
  -d "{\"username\":\"$U2\",\"email\":\"$E2\",\"password\":\"Old123456!\"}")
code=$(http -X POST "$BASE/api/v1/auth/forgot-password" -H 'Content-Type: application/json' -d "{\"email\":\"$E2\"}")
FTOK=$(jget "['token']")
check_nb "8. forgot 返回重置 token" "$FTOK"
code=$(http -X POST "$BASE/api/v1/auth/reset-password" -H 'Content-Type: application/json' \
  -d "{\"token\":\"$FTOK\",\"new_password\":\"New654321!\"}")
check "8b. reset 200" "$code" "200"
code=$(http -X POST "$BASE/api/v1/auth/token" -H 'Content-Type: application/json' -d "{\"username\":\"$U2\",\"password\":\"Old123456!\"}")
check "8c. 旧密码 401" "$code" "401"
NEW2=$(login "$U2" "New654321!")
check_nb "8d. 新密码可登录" "$NEW2"

# 9. 加入申请：INVITE_ONLY → 403
code=$(http -X POST "$BASE/api/v1/memberships/join-request" -H "Authorization: Bearer $UT" -H 'Content-Type: application/json' \
  -d "{\"tenant_id\":\"$T1ID\"}")
check "9. INVITE_ONLY 申请 403" "$code" "403"

# 10. 加入申请：REQUEST → PENDING → 审批 → 加入 → 切换
"${DB_EXEC[@]}" "UPDATE unify_iam.gateway_tenant SET join_policy='DOMAIN_REQUEST' WHERE tenant_id='$T1ID'" 2>/dev/null
code=$(http -X POST "$BASE/api/v1/memberships/join-request" -H "Authorization: Bearer $UT" -H 'Content-Type: application/json' \
  -d "{\"tenant_id\":\"$T1ID\"}")
check "10. REQUEST 申请返回 PENDING" "$(body)" "PENDING"
code=$(http "$BASE/api/v1/admin/join-requests?tenant_id=$T1ID" -H "Authorization: Bearer $ADMIN")
JRID=$(jget "['join_requests'][0]['join_request_id']")
check_nb "10b. 审批列表取到申请 ID" "$JRID"
code=$(http -X POST "$BASE/api/v1/admin/join-requests/$JRID/approve" -H "Authorization: Bearer $ADMIN")
check "10c. 审批通过 200" "$code" "200"
code=$(http "$BASE/api/v1/auth/memberships" -H "Authorization: Bearer $UT")
MS2=$(body)
T1_MS=$(echo "$MS2" | python3 -c "
import sys,json
for m in json.load(sys.stdin)['memberships']:
    if m['tenant_id']=='$T1ID': print(m['membership_id'])")
check_nb "10d. memberships 含 T1" "$T1_MS"
code=$(http -X POST "$BASE/api/v1/auth/switch-tenant" -H "Authorization: Bearer $UT" -H 'Content-Type: application/json' \
  -d "{\"membership_id\":\"$T1_MS\"}")
SW2=$(jget "['access_token']")
code=$(http "$BASE/api/v1/auth/me" -H "Authorization: Bearer $SW2")
check "10e. 切换后 /me tenantId=T1" "$(body)" "$T1ID"

# 11. 域名登记 + 验证
code=$(http -X POST "$BASE/api/v1/admin/tenants/tenant-org-a/domains" -H "Authorization: Bearer $ADMIN" -H 'Content-Type: application/json' \
  -d "{\"domain\":\"sub$SUF.org-a.com\"}")
DID=$(jget "['tenant_domain_id']")
check_nb "11. 登记域名返回 domain_id" "$DID"
code=$(http -X POST "$BASE/api/v1/admin/domains/$DID/verify" -H "Authorization: Bearer $ADMIN")
check "11b. 验证 VERIFIED" "$(body)" "VERIFIED"

# 12. 负向：无 token / viewer 403 / 越权切租户 403
code=$(http "$BASE/api/v1/admin/users")
check "12. 无 token 管理接口 401" "$code" "401"
VW=$(login viewer view123)
code=$(http "$BASE/api/v1/admin/users" -H "Authorization: Bearer $VW")
check "12b. viewer 管理接口 403" "$code" "403"
code=$(http -X POST "$BASE/api/v1/auth/switch-tenant" -H "Authorization: Bearer $VW" -H 'Content-Type: application/json' \
  -d "{\"membership_id\":\"ms-1001\"}")
check "12c. 越权切租户 403" "$code" "403"

# 13. 审计落库（best-effort）
AUDIT=$(db "SELECT COUNT(*) FROM unify_iam.gateway_audit_log WHERE event_type LIKE 'ADMIN_%'")
say "13. 审计落库 >0"
if [ "${AUDIT:-0}" -gt 0 ] 2>/dev/null; then ok; else bad "count=${AUDIT:-0}"; fi

echo
echo "== 结果：PASS=$PASS FAIL=$FAIL =="
[ "$FAIL" = "0" ]

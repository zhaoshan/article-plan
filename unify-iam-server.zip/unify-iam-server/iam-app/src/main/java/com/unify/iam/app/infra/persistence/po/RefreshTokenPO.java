package com.unify.iam.app.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_refresh_token 表 PO（P3：单租户 membership 语义，含 tenant/membership 上下文）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_refresh_token")
public class RefreshTokenPO extends BaseEntity {

    private String refreshTokenId;
    private String userId;
    private String tenantId;
    private String membershipId;
    private String refreshTokenHash;
    private LocalDateTime expiresAt;
    private LocalDateTime revokedAt;
}
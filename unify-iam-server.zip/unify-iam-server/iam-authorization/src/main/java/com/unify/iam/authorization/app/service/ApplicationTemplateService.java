package com.unify.iam.authorization.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.fasterxml.jackson.core.type.TypeReference;
import com.unify.iam.authorization.app.model.AppCatalog;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.authorization.app.model.TemplatePermissionAddResult;
import com.unify.iam.authorization.app.model.TemplatePermissionGrant;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.po.ApplicationRoleTemplatePO;
import com.unify.iam.authorization.infra.persistence.po.PermissionPO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.JsonUtils;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

/**
 * 应用角色模板加载与校验（docs/06 §2.3）：按租户启用的应用查预置模板。
 *
 * <p>新增应用 = 往 {@code iam_application}/{@code iam_application_role_template} 插数据，零改代码。
 * 加载时做三处校验，避免模板数据问题被静默吞掉：
 * <ol>
 *   <li>app_code 全部存在且 ACTIVE（未知应用 400）；</li>
 *   <li>启用应用集合内同 {@code role_code} 的模板权限集必须一致（gateway_role 租户内 role_code 唯一，
 *       跨应用冲突会导致后建角色被静默跳过，docs/06 附录 C）；</li>
 *   <li>模板引用的权限点必须存在于 gateway_permission（未知/停用 400，防静默丢权限）。</li>
 * </ol>
 */
@Service
public class ApplicationTemplateService {

    private final ApplicationRepository applicationRepository;
    private final ApplicationRoleTemplateRepository templateRepository;
    private final PermissionRepository permissionRepository;

    public ApplicationTemplateService(ApplicationRepository applicationRepository,
                                      ApplicationRoleTemplateRepository templateRepository,
                                      PermissionRepository permissionRepository) {
        this.applicationRepository = applicationRepository;
        this.templateRepository = templateRepository;
        this.permissionRepository = permissionRepository;
    }

    /**
     * 校验 app_codes 全部存在且 ACTIVE，返回这些应用的预置模板（按 priority 排序）。
     *
     * @throws AuthException 400 存在未知应用 / role_code 跨应用权限冲突 / 模板引用未知权限点
     */
    public List<AppRoleTemplate> loadForApps(List<String> appCodes) {
        List<String> codes = appCodes.stream().map(String::trim).filter(c -> !c.isEmpty()).distinct().toList();
        if (codes.isEmpty()) {
            throw AuthException.badRequest(ErrorCode.APP_CODES_REQUIRED);
        }
        Set<String> active = applicationRepository.findActiveByCodes(codes).stream()
                .map(a -> a.getAppCode().trim()).collect(Collectors.toSet());
        List<String> missing = codes.stream().filter(c -> !active.contains(c)).toList();
        if (!missing.isEmpty()) {
            throw AuthException.badRequest(ErrorCode.UNKNOWN_APP, missing);
        }
        List<AppRoleTemplate> templates = templateRepository.listByAppCodes(codes).stream()
                .map(this::toModel).toList();
        validateRoleCodeConflict(templates);
        validatePermissionCodes(templates);
        return templates;
    }

    /**
     * 应用目录：全部 ACTIVE 应用 + 各自预置角色（docs/05 §7.3 建租户表单的应用多选 + 角色提示）。
     */
    public List<AppCatalog> listCatalog() {
        List<ApplicationPO> apps = applicationRepository.listActive();
        if (apps.isEmpty()) {
            return List.of();
        }
        List<AppRoleTemplate> templates = templateRepository.listByAppCodes(
                        apps.stream().map(ApplicationPO::getAppCode).toList()).stream()
                .map(this::toModel).toList();
        return apps.stream().map(a -> new AppCatalog(
                a.getAppCode().trim(), a.getAppName(), a.getDescription(),
                templates.stream().filter(t -> t.appCode().equals(a.getAppCode().trim())).toList()))
                .toList();
    }

    /**
     * 应用角色模板新增权限点（管理面运维接口，scripts/grant_template_permission_to_tenants.sql 的 API 化）。
     *
     * <p>模板表是权限集唯一事实源；本方法只管模板与权限字典，存量租户 deep-copy 角色不回灌
     * （由 iam-app 编排层按 sync_tenants 开关处理）。校验链：
     * <ol>
     *   <li>模板必须存在（app_code + role_code）；</li>
     *   <li>权限点必须在 gateway_permission 字典且 ACTIVE——createPermission=true 时先自动登记
     *       （需 permission_name/resource_type/action；tenant_grantable=1 归属请求应用），
     *       否则 400 IAM-PERM-002。字典是 code 权威目录（建租户灌入时 code→id 在此映射，
     *       未知 code 会被静默丢弃），故不允许模板引用字典外权限点；</li>
     *   <li>追加后不得造成跨应用同名 role_code 权限集不一致（loadForApps 冲突校验的前置拦截）。</li>
     * </ol>
     * 已含该权限点时幂等返回 added=false（不再登记字典，permissionCreated=false）。
     *
     * @return added=模板是否新加；permissionCreated=字典是否新登记
     */
    public TemplatePermissionAddResult addPermission(TemplatePermissionGrant grant) {
        String app = trim(grant.appCode());
        String role = trim(grant.roleCode());
        String perm = trim(grant.permissionCode());
        String op = trim(grant.operator());
        ApplicationRoleTemplatePO template = templateRepository.findByAppCodeAndRoleCode(app, role)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TEMPLATE_NOT_FOUND, app + ":" + role));
        boolean created = ensurePermissionInDictionary(grant, template, perm, op);
        List<String> codes = new java.util.ArrayList<>(parseCodes(template.getPermissionCodesJson()));
        if (codes.contains(perm)) {
            return new TemplatePermissionAddResult(app, role, perm, false, codes.size(), false);
        }
        codes.add(perm);
        assertNoRoleCodeConflict(template, codes);
        template.setPermissionCodesJson(JsonUtils.toJson(codes));
        template.setUpdateBy(op);
        templateRepository.updatePermissionCodes(template);
        return new TemplatePermissionAddResult(app, role, perm, true, codes.size(), created);
    }

    /**
     * 权限点登记：已在字典（ACTIVE）→ false；createPermission=true → 校验元数据后插入；
     * 否则 400。软删/停用行占位唯一键时转 400 IAM-PERM-004（引导复活而非新建）。
     */
    private boolean ensurePermissionInDictionary(TemplatePermissionGrant grant,
                                                 ApplicationRoleTemplatePO template, String perm, String operator) {
        if (permissionRepository.findIdByCodes(List.of(perm)).containsKey(perm)) {
            return false;
        }
        if (!grant.createPermission()) {
            throw AuthException.badRequest(ErrorCode.PERMISSION_NOT_FOUND, perm);
        }
        String name = trim(grant.permissionName());
        String resourceType = trim(grant.resourceType());
        String action = trim(grant.action());
        if (name.isEmpty() || resourceType.isEmpty() || action.isEmpty()) {
            throw AuthException.badRequest(ErrorCode.PERMISSION_METADATA_REQUIRED);
        }
        PermissionPO po = new PermissionPO();
        po.setPermissionId(IdGenerator.newBizId());
        po.setPermissionCode(perm);
        po.setPermissionName(name);
        po.setResourceType(resourceType);
        po.setAction(action);
        po.setAppCode(trim(template.getAppCode()));
        po.setTenantGrantable(1);
        po.setCategory(trim(grant.category()).isEmpty() ? null : trim(grant.category()));
        po.setIsBuiltin(1);
        po.setPermissionStatus("ACTIVE");
        po.setCreateBy(operator);
        po.setUpdateBy(operator);
        try {
            permissionRepository.create(po);
        } catch (org.springframework.dao.DuplicateKeyException e) {
            throw AuthException.badRequest(ErrorCode.PERMISSION_DISABLED, perm);
        }
        return true;
    }

    private static String trim(String value) {
        return value == null ? "" : value.trim();
    }

    /** 追加后权限集与「跨应用同名 role_code 模板」既有集合不一致 → 400（保持租户灌入的冲突校验可过）。 */
    private void assertNoRoleCodeConflict(ApplicationRoleTemplatePO self, List<String> newCodes) {
        List<String> sortedNew = newCodes.stream().sorted().toList();
        for (ApplicationRoleTemplatePO other : templateRepository.listByRoleCode(self.getRoleCode())) {
            if (other.getId().equals(self.getId())) {
                continue;
            }
            List<String> otherCodes = parseCodes(other.getPermissionCodesJson()).stream().sorted().toList();
            if (!otherCodes.equals(sortedNew)) {
                throw AuthException.badRequest(ErrorCode.ROLE_CODE_CONFLICT, self.getRoleCode());
            }
        }
    }

    /** ① 同 role_code 跨应用冲突：权限集不一致 → 400（gateway_role 租户内 role_code 唯一，静默跳过后权限丢失）。 */
    private void validateRoleCodeConflict(List<AppRoleTemplate> templates) {
        Map<String, List<List<String>>> permsByRole = templates.stream().collect(Collectors.groupingBy(
                AppRoleTemplate::roleCode,
                Collectors.mapping(t -> t.permissionCodes().stream().sorted().toList(), Collectors.toList())));
        for (Map.Entry<String, List<List<String>>> e : permsByRole.entrySet()) {
            if (new HashSet<>(e.getValue()).size() > 1) {
                throw AuthException.badRequest(ErrorCode.ROLE_CODE_CONFLICT, e.getKey());
            }
        }
    }

    /** ④ 模板引用的权限点必须存在且 ACTIVE（防配置错误静默丢权限）。 */
    private void validatePermissionCodes(List<AppRoleTemplate> templates) {
        List<String> allCodes = templates.stream()
                .flatMap(t -> t.permissionCodes().stream()).distinct().toList();
        if (allCodes.isEmpty()) {
            return;
        }
        Set<String> existing = permissionRepository.findIdByCodes(allCodes).keySet();
        List<String> unknown = allCodes.stream().filter(c -> !existing.contains(c)).toList();
        if (!unknown.isEmpty()) {
            throw AuthException.badRequest(ErrorCode.TEMPLATE_UNKNOWN_PERMISSIONS, unknown);
        }
    }

    private AppRoleTemplate toModel(ApplicationRoleTemplatePO po) {
        return new AppRoleTemplate(
                po.getAppCode().trim(),
                po.getRoleCode().trim(),
                po.getRoleName(),
                po.getRoleDescription(),
                parseCodes(po.getPermissionCodesJson()),
                po.getIsOwner() != null && po.getIsOwner() == 1,
                po.getIsAdmin() != null && po.getIsAdmin() == 1,
                po.getScopeType() == null || po.getScopeType().isBlank() ? "TENANT" : po.getScopeType().trim());
    }

    private List<String> parseCodes(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return JsonUtils.fromJson(json, new TypeReference<List<String>>() {
            });
        } catch (Exception e) {
            throw new IllegalStateException("应用角色模板 permission_codes_json 非法", e);
        }
    }
}

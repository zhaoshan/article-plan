"""动态脚本注册表测试"""

import pytest
from src.core.dynamic_scripts import get_script, register_script
from src.core.dynamic_scripts.base import DynamicScript
from src.core.dynamic_scripts.faq_crawler import FaqCrawler


class TestScriptRegistry:
    """脚本注册表测试"""

    def test_get_known_script(self):
        """获取已知脚本类"""
        cls = get_script("faq_crawler")
        assert cls is FaqCrawler

    def test_get_unknown_script_raises(self):
        """未知脚本名抛出 KeyError"""
        with pytest.raises(KeyError) as exc:
            get_script("nonexistent")
        assert "nonexistent" in str(exc.value)
        assert "faq_crawler" in str(exc.value)  # 提示可用选项

    def test_register_new_script(self):
        """注册新脚本"""
        class MockScript(DynamicScript):
            async def execute(self, context, parent_link, entry_url):
                return {"discovered_links": [], "stats": {}}

        register_script("mock", MockScript)
        try:
            assert get_script("mock") is MockScript
        finally:
            # 清理：从注册表中移除测试脚本
            from src.core.dynamic_scripts import _SCRIPT_REGISTRY
            _SCRIPT_REGISTRY.pop("mock", None)

    def test_faq_crawler_is_dynamic_script(self):
        """FaqCrawler 是 DynamicScript 的子类"""
        assert issubclass(FaqCrawler, DynamicScript)

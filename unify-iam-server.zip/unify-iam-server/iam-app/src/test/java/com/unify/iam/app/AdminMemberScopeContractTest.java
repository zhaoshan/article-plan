package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.app.adapter.controller.AdminMemberController;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminMemberService;
import com.unify.iam.app.app.service.admin.TenantMemberProjectionService;
import com.unify.iam.app.app.service.admin.TenantMemberQueryService;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.infra.persistence.mapper.TenantMemberQueryMapper;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.ibatis.builder.annotation.MapperAnnotationBuilder;
import org.apache.ibatis.session.Configuration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

/** HTTP binding, real scope guard/service, and SQL generation without Docker. */
class AdminMemberScopeContractTest {
    private final RoleRepository roles = mock(RoleRepository.class);
    private final TenantRepository tenants = mock(TenantRepository.class);
    private final TenantMemberQueryMapper query = mock(TenantMemberQueryMapper.class);
    private final JwtSigner signer = mock(JwtSigner.class);
    private MockMvc mvc;

    @BeforeEach
    void setup() {
        var projection = new TenantMemberProjectionService(mock(UserRepository.class),
                mock(MembershipRoleRepository.class), roles);
        var service = new TenantMemberQueryService(new TenantScopeGuard(roles), tenants, query, projection);
        mvc = MockMvcBuilders.standaloneSetup(new AdminMemberController(mock(AdminMemberService.class),
                        mock(AuditService.class), service))
                .addInterceptors(new ManagementAuthorizationInterceptor(signer,
                        new org.springframework.beans.factory.support.StaticListableBeanFactory()
                                .getBeanProvider(com.unify.iam.tenant.infra.persistence.repository.MembershipRepository.class)))
                .setControllerAdvice(new GlobalExceptionHandler()).build();
        when(signer.verify("reader")).thenReturn(claims(List.of("iam:member:read")));
        when(signer.verify("no-permission")).thenReturn(claims(List.of()));
    }

    private JwtClaims claims(List<String> permissions) {
        return new JwtClaims("issuer", List.of("app"), "u", "own", "ms", List.of("PlatformAdmin"),
                permissions, Map.of(), Long.MAX_VALUE, 1L, "jti", 0L);
    }

    private MockHttpServletRequestBuilder request(String type, String id) {
        return get("/api/v1/admin/members").param("scope_type", type).param("scope_id", id)
                .header("Authorization", "Bearer reader");
    }

    @Test
    void rejectsMalformedScopeAndLegacyParametersBeforeQuerying() throws Exception {
        for (String[] tuple : List.of(new String[]{"platform", "PLATFORM"}, new String[]{"PLATFORM", "own"},
                new String[]{"TENANT", " "}, new String[]{"INVALID", "own"})) {
            mvc.perform(request(tuple[0], tuple[1])).andExpect(status().isBadRequest());
        }
        mvc.perform(get("/api/v1/admin/members").header("Authorization", "Bearer reader"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/api/v1/admin/members").param("scope_id", "own")
                .header("Authorization", "Bearer reader")).andExpect(status().isBadRequest());
        mvc.perform(get("/api/v1/admin/members").param("tenant_id", "own")
                .header("Authorization", "Bearer reader")).andExpect(status().isBadRequest());
        mvc.perform(request("PLATFORM", "PLATFORM").param("tenant_id", "own"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/api/v1/admin/members").param("scopeType", "PLATFORM").param("scopeId", "PLATFORM")
                .header("Authorization", "Bearer reader")).andExpect(status().isBadRequest());
        verifyNoInteractions(query, tenants);
    }

    @Test
    void permissionAndRealMembershipGuardRejectForgedPlatformRoleClaims() throws Exception {
        mvc.perform(get("/api/v1/admin/members")).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/v1/admin/members").param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                .header("Authorization", "Bearer no-permission"))
                .andExpect(status().isForbidden());
        mvc.perform(request("PLATFORM", "PLATFORM")).andExpect(status().isForbidden());
        mvc.perform(request("TENANT", "foreign")).andExpect(status().isForbidden());
        verifyNoInteractions(query, tenants);
    }

    @Test
    void platformAndTenantFiltersReachQueryAndCountIdentically() throws Exception {
        when(roles.hasPlatformRoleByMembership("ms")).thenReturn(true);
        mvc.perform(request("PLATFORM", "PLATFORM").param("membership_status", "ACTIVE,PENDING")
                .param("keyword", "%_").param("owner_candidates", "true").param("limit", "3"))
                .andExpect(status().isOk());
        verify(query).search(null, "%!%!_%", true, List.of("ACTIVE", "PENDING"), 3);
        verify(query).count(null, "%!%!_%", true, List.of("ACTIVE", "PENDING"));
        TenantPO tenant = new TenantPO();
        tenant.setTenantId("own"); tenant.setTenantType("ORGANIZATION");
        when(tenants.findById("own")).thenReturn(Optional.of(tenant));
        mvc.perform(request("TENANT", " own ").param("membership_status", "SUSPENDED"))
                .andExpect(status().isOk());
        verify(query).search("own", null, false, List.of("SUSPENDED"), 1000);
        verify(query).count("own", null, false, List.of("SUSPENDED"));
    }

    @Test
    void globalRowsKeepTheirOwnTenantAndOwnerWithoutCollapsingSameUser() throws Exception {
        when(roles.hasPlatformRoleByMembership("ms")).thenReturn(true);
        TenantPO a = new TenantPO(); a.setTenantId("a"); a.setTenantName("Tenant A");
        a.setTenantType("ORGANIZATION"); a.setOwnerUserId("same-user");
        TenantPO b = new TenantPO(); b.setTenantId("b"); b.setTenantName("Tenant B");
        b.setTenantType("PERSONAL");
        MembershipPO first = new MembershipPO(); first.setMembershipId("m-a");
        first.setTenantId("a"); first.setUserId("same-user"); first.setMembershipStatus("ACTIVE");
        first.setJoinSource("OWNER");
        MembershipPO second = new MembershipPO(); second.setMembershipId("m-b");
        second.setTenantId("b"); second.setUserId("same-user"); second.setMembershipStatus("ACTIVE");
        second.setJoinSource("INVITE");
        when(query.search(null, null, false, List.of(), 1000)).thenReturn(List.of(first, second));
        when(query.count(null, null, false, List.of())).thenReturn(2L);
        when(tenants.findByIds(List.of("a", "b"))).thenReturn(List.of(a, b));
        String body = mvc.perform(request("PLATFORM", "PLATFORM")).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        Map<?, ?> result = JsonUtils.fromJson(body, Map.class);
        assertThat(result.containsKey("tenant_type")).isFalse();
        List<?> rows = (List<?>) result.get("members");
        assertThat(rows).hasSize(2);
        Map<?, ?> rowA = (Map<?, ?>) rows.get(0);
        Map<?, ?> rowB = (Map<?, ?>) rows.get(1);
        assertThat(rowA.get("tenant_id")).isEqualTo("a");
        assertThat(rowA.get("tenant_name")).isEqualTo("Tenant A");
        assertThat(rowA.get("is_owner")).isEqualTo(true);
        assertThat(rowA.get("join_source")).isEqualTo("OWNER");
        assertThat(rowB.get("tenant_id")).isEqualTo("b");
        assertThat(rowB.get("tenant_name")).isEqualTo("Tenant B");
        assertThat(rowB.get("is_owner")).isEqualTo(false);
        assertThat(rowB.get("join_source")).isEqualTo("INVITE");
    }

    @Test
    void rejectsInvalidStatusesAndLimits() throws Exception {
        for (String value : List.of("", "active", "DISABLED", "ACTIVE,", ",PENDING", "ACTIVE,REMOVED")) {
            mvc.perform(request("PLATFORM", "PLATFORM").param("membership_status", value))
                    .andExpect(status().isBadRequest());
        }
        mvc.perform(request("PLATFORM", "PLATFORM").param("status", "ACTIVE"))
                .andExpect(status().isBadRequest());
        for (String value : List.of("0", "1001", "invalid")) {
            mvc.perform(request("PLATFORM", "PLATFORM").param("limit", value))
                    .andExpect(status().isBadRequest());
        }
        verifyNoInteractions(query, tenants);
    }

    @Test
    void mapperGeneratesScopedAndGlobalSqlWithFiltersBeforeLimit() {
        Configuration config = new Configuration();
        new MapperAnnotationBuilder(config, TenantMemberQueryMapper.class).parse();
        Map<String, Object> args = new HashMap<>();
        args.put("tenantId", "own"); args.put("pattern", "%needle%"); args.put("ownerCandidates", true);
        args.put("membershipStatuses", List.of("ACTIVE", "PENDING")); args.put("limit", 2);
        String namespace = TenantMemberQueryMapper.class.getName();
        String sql = config.getMappedStatement(namespace + ".search").getBoundSql(args).getSql()
                .replaceAll("\\s+", " ");
        assertThat(sql).contains("AND m.tenant_id=?", "m.membership_status IN", "t.owner_user_id",
                "t.delete_flag=0", "u.delete_flag=0", "ORDER BY m.id ASC LIMIT ?");
        assertThat(sql.indexOf("m.membership_status IN")).isLessThan(sql.indexOf("LIMIT"));
        args.put("tenantId", null);
        String global = config.getMappedStatement(namespace + ".search").getBoundSql(args).getSql();
        assertThat(global).doesNotContain("AND m.tenant_id=?");
        String count = config.getMappedStatement(namespace + ".count").getBoundSql(args).getSql();
        assertThat(count).contains("m.membership_status IN", "t.owner_user_id").doesNotContain("LIMIT");
    }
}

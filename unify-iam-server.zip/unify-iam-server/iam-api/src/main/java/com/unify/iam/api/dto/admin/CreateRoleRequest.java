package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 建角色（管理面）：作用域 + 编码 + 名称。 */
public record CreateRoleRequest(
        @JsonProperty("scope_type") String scopeType,
        @JsonProperty("scope_id") String scopeId,
        @NotBlank(message = "role_code 不能为空") @JsonProperty("role_code") String roleCode,
        @NotBlank(message = "role_name 不能为空") @JsonProperty("role_name") String roleName,
        @JsonProperty("role_description") String roleDescription) {
}

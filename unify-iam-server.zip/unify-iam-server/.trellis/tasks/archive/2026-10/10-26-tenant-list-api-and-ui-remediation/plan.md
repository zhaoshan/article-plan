# Tenant list API and UI remediation plan

Date: 2026-10-26

Status: In progress (service-side contract complete; frontend boundary remains separately tracked).

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep all task, planning, session, and validation records under this repository's `.trellis/` directory.
- Do not access, inspect, modify, or create another Platform IAM project, worktree, or task.
- Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- The requested `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree, including hidden-path searches. Follow the actual `CLAUDE.md` and `.claude/rules/security.md`; no undocumented Trellis confirmation gate can be inferred.

## Confirmed service-side findings

1. `GET /api/v1/admin/tenants` calls `AdminTenantService.list(limit)` and serializes only tenant fields through `AdminTenantController.toBrief`. It has no enabled-application field.
2. `GET /api/v1/admin/tenants/{tenantId}/applications` first reads `iam_tenant_application` for a tenant, then reads active `iam_application` rows by code. Calling it once per rendered row makes the UI workflow one list request plus two database reads per tenant, as well as one HTTP request per tenant.
3. The existing relationship is many-to-many: a tenant can have more than one enabled application. The list contract must therefore return a nested `applications` array, rather than a single scalar name.
4. `PUT /api/v1/admin/tenants/{tenantId}` already accepts `tenant_status`. A non-`ACTIVE` transition revokes active member token versions; returning to `ACTIVE` restores login eligibility. The requested frontend quick action and switch can use this existing protected route and do not require a second status endpoint.

## UI boundary and confirmation checkpoint

The current allowed worktree has no `.ts`, `.tsx`, `.js`, `.jsx`, `.vue`, `.css`, `.scss`, or HTML view source. It contains only the Java service and its resources. The service response has no column-width, color, validation-style, action-icon, form-order, or switch-component metadata.

The supplied screenshots prove the visible symptoms, but not their source-level CSS cause. The unequal column widths can only be caused by the tenant page's table/grid/flex declarations in the separately owned frontend. It would be inaccurate to claim a particular `grid-template-columns`, fixed width, or `flex` rule without inspecting that code, which the task expressly prohibits. This is the requested confirmation checkpoint for item 1.

## Intended service change

Keep the established envelope and all existing tenant fields. Add an additive field on every list row:

```json
{
  "applications": [
    {"app_code": "parlant-agent-server", "app_name": "Parlant Agent Server"}
  ]
}
```

Implementation will load all listed tenant/application relations in one query and the distinct active application directory entries in one query, then group them in memory. The endpoint therefore remains three database reads independent of the number of returned tenants, rather than the current frontend-driven `1 + 2N` pattern.

## Checklist

- [x] Read applicable project/security instructions and confirm the requested AGENTS/Trellis workflow files are absent.
- [x] Confirm the frontend-only versus service-owned boundaries from the current worktree and supplied screenshots.
- [x] Confirm the existing per-tenant application endpoint and status-update behavior.
- [x] Add bulk tenant-application lookup and the additive list response field.
- [x] Add integration coverage proving a newly created tenant receives its enabled application's code and name from the list response.
- [x] Run focused Maven validation and record results.

## Validation result

The repository uses Testcontainers for these integration tests. The first sandboxed run compiled all affected modules but could not connect to Docker; the rerun with Docker access passed.

```text
mvn -pl iam-app -am test -Dtest='P3AdminCrudIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 6 passed, 0 failures, 0 errors

mvn -pl iam-app -am test -Dtest='AdminProtectionIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 8 passed, 0 failures, 0 errors
```

The first suite creates a tenant, calls the list endpoint once, and verifies the returned row contains the enabled application's `app_code` and `app_name`. The second confirms the existing `tenant_status` update route remains valid for a UI enable/disable control: disabling invalidates active tenant membership token versions and blocks login; returning to `ACTIVE` restores eligibility.

## Follow-up: application-summary metadata preservation

The original bulk mapper used `findActiveByCodes`, which was correct for provisioning but not for displaying
an existing `iam_tenant_application` relationship. If the application directory is later marked `DISABLED`, that
filter silently removed the relation from both the list summary and the single-tenant application response.

The display contract now uses a dedicated `TenantApplicationSummary` DTO:

```json
{
  "app_code": "parlant-agent-server",
  "app_name": "Parlant Agent Server",
  "description": "...",
  "app_status": "ACTIVE"
}
```

It performs the same bounded list, relation, and application-directory lookups; the directory lookup includes
non-deleted applications regardless of `app_status`. Provisioning and authorization validation remain on the
existing ACTIVE-only repository method. A missing historical catalog record is represented by its code as the
display-name fallback instead of being dropped from the relationship list.

Focused validation after this follow-up. The CRUD test covers an existing relation whose directory app is
`DISABLED`, as well as a historical relation whose catalog entry is absent:

```text
mvn -pl iam-app -am test -Dtest='P3AdminCrudIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 7 passed, 0 failures, 0 errors

mvn -pl iam-app -am test -Dtest='AdminProtectionIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 8 passed, 0 failures, 0 errors
```


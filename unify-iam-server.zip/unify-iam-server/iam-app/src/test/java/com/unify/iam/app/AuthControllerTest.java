package com.unify.iam.app;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.api.dto.auth.TokenUser;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.AuthController;
import com.unify.iam.app.app.service.DevTokenService;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.exception.AuthException;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(AuthController.class)
@Import(GlobalExceptionHandler.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private TokenService tokenService;
    @MockitoBean
    private DevTokenService devTokenService;
    @MockitoBean
    private JwtSigner jwtSigner;
    @MockitoBean
    private com.unify.iam.identity.infra.persistence.repository.IdpConfigRepository idpConfigRepository;
    @MockitoBean
    private com.unify.iam.tenant.infra.persistence.repository.TenantRepository tenantRepository;
    @MockitoBean
    private com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository tenantApplicationRepository;
    @MockitoBean
    private IamProperties props;

    private static final String LOGIN_BODY = """
            {"username":"operator","password":"op123"}
            """;

    private LoginResponse response() {
        return LoginResponse.of("jwt-token", "bearer", 7200L,
                new TokenUser("u-1001", "operator", List.of("AgentOperator"), List.of("agent:read")));
    }

    @Test
    void tokenSuccessReturns200WithContractShape() throws Exception {
        when(tokenService.issue(any())).thenReturn(response());

        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(LOGIN_BODY))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.access_token").value("jwt-token"))
                .andExpect(jsonPath("$.data.token_type").value("bearer"))
                .andExpect(jsonPath("$.data.expires_in").value(7200))
                .andExpect(jsonPath("$.data.user.user_id").value("u-1001"))
                .andExpect(jsonPath("$.data.user.user_name").value("operator"))
                .andExpect(jsonPath("$.data.user.roles[0]").value("AgentOperator"));
    }

    @Test
    void tokenBadPasswordReturns401WithDetail() throws Exception {
        when(tokenService.issue(any())).thenThrow(AuthException.unauthorized("用户名或密码错误"));

        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(LOGIN_BODY))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("用户名或密码错误"));
    }

    @Test
    void tokenBlankParamsReturns400WithDetail() throws Exception {
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(containsString("不能为空")));
    }

    @Test
    void devTokenUnknownUserReturns404() throws Exception {
        when(devTokenService.issueDev(any())).thenThrow(AuthException.notFound("用户不存在"));

        mockMvc.perform(post("/api/v1/auth/dev-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"user_id\":\"u-9999\"}"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("用户不存在"));
    }

    @Test
    void devTokenDisabledReturns403() throws Exception {
        when(devTokenService.issueDev(any())).thenThrow(AuthException.forbidden("dev-token 已禁用"));

        mockMvc.perform(post("/api/v1/auth/dev-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"user_id\":\"u-1001\"}"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("dev-token 已禁用"));
    }

    @Test
    void devTokenMissingUserRefReturns400() throws Exception {
        when(devTokenService.issueDev(any())).thenThrow(AuthException.badRequest("userId 与 username 至少提供一个"));

        mockMvc.perform(post("/api/v1/auth/dev-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("userId 与 username 至少提供一个"));
    }

    @Test
    void meWithValidTokenReturnsContext() throws Exception {
        JwtClaims claims = new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1001",
                "tenant-org-a", "ms-2001", List.of("AgentOperator"),
                List.of("agent:read", "agent:publish"), Map.of(), 9999999999L, 1000000000L, "jti", 0L);
        when(jwtSigner.verify("jwt-token")).thenReturn(claims);

        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userId").value("u-1001"))
                .andExpect(jsonPath("$.data.tenantId").value("tenant-org-a"))
                .andExpect(jsonPath("$.data.membershipId").value("ms-2001"))
                .andExpect(jsonPath("$.data.roles[0]").value("AgentOperator"))
                .andExpect(jsonPath("$.data.permissions").isArray())
                .andExpect(jsonPath("$.data.attrs").isMap());
    }

    @Test
    void meWithoutTokenReturns401() throws Exception {
        mockMvc.perform(get("/api/v1/auth/me"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value(containsString("缺少令牌")));
    }


    @Test
    void returnOriginsReturnsWhitelist() throws Exception {
        IamProperties.Oidc oidc = new IamProperties.Oidc();
        oidc.setAllowedReturnOrigins(List.of("http://localhost:5173", "http://localhost:5175"));
        when(props.getOidc()).thenReturn(oidc);
        mockMvc.perform(get("/api/v1/auth/return-origins"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.origins[0]").value("http://localhost:5173"))
                .andExpect(jsonPath("$.data.origins[1]").value("http://localhost:5175"));
    }
}

"""数据库种子数据初始化

应用启动时，若 crawl_link_tree 表为空，则异步将 config/crawl_link_tree.sql
中的 INSERT 语句分批导入，不阻塞应用启动。
"""

from __future__ import annotations

import logging
from pathlib import Path

from sqlalchemy import text

from src.database import connection

logger = logging.getLogger(__name__)

# 默认种子 SQL 文件路径（项目根目录下的 config/）
_DEFAULT_SEED_SQL_PATH = Path(__file__).resolve().parent.parent.parent / "config" / "crawl_link_tree.sql"


async def seed_crawl_link_tree_if_empty(
    sql_path: Path | str | None = None,
    batch_size: int = 500,
) -> None:
    """若 crawl_link_tree 表为空，则异步导入 SQL 种子数据。

    Args:
        sql_path: 种子 SQL 文件路径，默认取 config/crawl_link_tree.sql
        batch_size: 每批执行的 INSERT 语句数量
    """
    connection.ensure_initialized()

    sql_file = Path(sql_path) if sql_path else _DEFAULT_SEED_SQL_PATH

    async with connection._engine.begin() as conn:
        result = await conn.execute(text("SELECT COUNT(1) FROM crawl_link_tree"))
        count = result.scalar() or 0

    if count > 0:
        logger.info(f"crawl_link_tree 表已有 {count} 条记录，跳过种子数据初始化")
        return

    if not sql_file.is_file():
        logger.warning(f"种子 SQL 文件不存在: {sql_file}，跳过初始化")
        return

    raw_sql = sql_file.read_text(encoding="utf-8")
    statements = [
        line.strip()
        for line in raw_sql.splitlines()
        if line.strip().upper().startswith("INSERT INTO")
    ]
    total = len(statements)
    if total == 0:
        logger.warning(f"种子 SQL 文件中未找到 INSERT 语句: {sql_file}")
        return

    logger.info(f"开始异步初始化 crawl_link_tree 种子数据，共 {total} 条，每批 {batch_size} 条")

    executed = 0
    for i in range(0, total, batch_size):
        batch = statements[i : i + batch_size]
        async with connection._engine.begin() as conn:
            for stmt in batch:
                await conn.execute(text(stmt))
        executed += len(batch)
        logger.info(f"种子数据导入进度: {executed}/{total}")

    logger.info(f"crawl_link_tree 种子数据初始化完成，共导入 {executed} 条")

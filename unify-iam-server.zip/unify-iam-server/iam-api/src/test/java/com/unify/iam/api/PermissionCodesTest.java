package com.unify.iam.api;

import static org.assertj.core.api.Assertions.assertThat;

import com.unify.iam.api.constant.PermissionCodes;
import java.util.List;
import org.junit.jupiter.api.Test;

class PermissionCodesTest {

    @Test
    void catalogHasExactlyNineCodes() {
        assertThat(PermissionCodes.ALL_PERMISSIONS).hasSize(9);
    }

    @Test
    void catalogMatchesE2E1Contract() {
        // E2E-1 范围文档 §4.2 权限点目录（与 parlant permissions.py 同套 code）
        assertThat(PermissionCodes.ALL_PERMISSIONS).containsExactlyInAnyOrder(
                "agent:read", "agent:build", "agent:publish", "agent:delete",
                "session:read", "session:send", "customer:manage", "trace:read", "settings:read");
    }

    @Test
    void catalogIsSortedDeterministically() {
        List<String> codes = PermissionCodes.ALL_PERMISSIONS;
        assertThat(codes).isSorted();
    }
}

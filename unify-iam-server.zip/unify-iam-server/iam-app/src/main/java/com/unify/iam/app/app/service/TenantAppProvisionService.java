package com.unify.iam.app.app.service;

import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.authorization.app.service.ApplicationTemplateService;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RolePermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.util.IdGenerator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import org.springframework.stereotype.Service;

/**
 * 应用角色模板灌入（docs/06 §2.3）：把应用的预置角色模板 deep-copy 进租户并授 owner。
 *
 * <p>供两条路径复用：① 管理面建租户（AdminTenantService.create）；② 注册时按 app 给个人租户
 * 授 is_owner 角色（RegisterService，个人租户 = 该应用的个人工作台，owner 即管理员）。
 * 两者都需登记 {@code iam_tenant_application}（角色配置页按应用隔离的数据源）。
 */
@Service
public class TenantAppProvisionService {

    private final ApplicationTemplateService applicationTemplateService;
    private final PermissionRepository permissionRepository;
    private final RoleRepository roleRepository;
    private final RolePermissionRepository rolePermissionRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final TenantApplicationRepository tenantApplicationRepository;

    public TenantAppProvisionService(ApplicationTemplateService applicationTemplateService,
                                     PermissionRepository permissionRepository,
                                     RoleRepository roleRepository,
                                     RolePermissionRepository rolePermissionRepository,
                                     MembershipRoleRepository membershipRoleRepository,
                                     TenantApplicationRepository tenantApplicationRepository) {
        this.applicationTemplateService = applicationTemplateService;
        this.permissionRepository = permissionRepository;
        this.roleRepository = roleRepository;
        this.rolePermissionRepository = rolePermissionRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
    }

    /** 按 app_codes 加载模板（应用须存在且 ACTIVE；未知应用抛 400，调用方决定是否忽略）。 */
    public List<AppRoleTemplate> loadForApps(List<String> appCodes) {
        return applicationTemplateService.loadForApps(appCodes);
    }

    /** 登记租户↔应用（幂等，角色配置页按应用隔离的数据源，docs/05 §7.3 ④）。 */
    public void recordTenantApps(String tenantId, List<String> appCodes) {
        if (appCodes == null || appCodes.isEmpty()) {
            return;
        }
        for (String appCode : appCodes) {
            tenantApplicationRepository.record(tenantId, appCode);
        }
    }

    /** deep-copy 模板角色到租户 + 权限绑定（幂等：scope_type+scope_id+role_code 判重）。 */
    public void seedTemplates(String tenantId, List<AppRoleTemplate> templates) {
        Map<String, String> permIdByCode = permissionRepository.findIdByCodes(
                templates.stream().flatMap(t -> t.permissionCodes().stream()).distinct().toList());
        for (AppRoleTemplate tpl : templates) {
            if ("PLATFORM".equalsIgnoreCase(tpl.scopeType())) {
                // 平台级模板：复用/建全局角色（不按租户复制），owner 授予在 grantOwnerRoles 统一处理
                ensurePlatformRole(tpl, permIdByCode);
                continue;
            }
            if (roleExists(tenantId, tpl.roleCode())) {
                continue;
            }
            RolePO role = new RolePO();
            role.setRoleId(IdGenerator.newBizId());
            role.setScopeType("TENANT");
            role.setScopeId(tenantId);
            role.setRoleCode(tpl.roleCode());
            role.setRoleName(tpl.roleName());
            role.setRoleDescription(tpl.roleDescription());
            role.setIsBuiltin(1);
            role.setRoleStatus("ACTIVE");
            roleRepository.create(role);
            List<String> permissionIds = tpl.permissionCodes().stream()
                    .map(permIdByCode::get).filter(Objects::nonNull).toList();
            rolePermissionRepository.replaceForRole(role.getRoleId(), permissionIds);
        }
    }

    /** 平台级模板：PLATFORM 作用域下按 role_code 判重——已存在则复用（不重绑权限，避免覆盖人工调整）；
     *  不存在则建全局角色 + 按模板绑权限（含 tenant_grantable=0 的平台专属权限，V8 仅平台角色可授）。
     *  授权对象（owner）由 grantOwnerRoles 统一授到成员，不经此方法。 */
    private void ensurePlatformRole(AppRoleTemplate tpl, Map<String, String> permIdByCode) {
        boolean exists = roleRepository.listByScope("PLATFORM", "PLATFORM").stream()
                .anyMatch(r -> tpl.roleCode().equals(r.getRoleCode()));
        if (exists) {
            return;
        }
        RolePO role = new RolePO();
        role.setRoleId(IdGenerator.newBizId());
        role.setScopeType("PLATFORM");
        role.setScopeId("PLATFORM");
        role.setRoleCode(tpl.roleCode());
        role.setRoleName(tpl.roleName());
        role.setRoleDescription(tpl.roleDescription());
        role.setIsBuiltin(1);
        role.setRoleStatus("ACTIVE");
        roleRepository.create(role);
        List<String> permissionIds = tpl.permissionCodes().stream()
                .map(permIdByCode::get).filter(Objects::nonNull).toList();
        rolePermissionRepository.replaceForRole(role.getRoleId(), permissionIds);
    }

    /** 授某成员所有启用应用中 {@code is_owner} 的模板角色（DIRECT）。 */
    /** G2 增强：解析租户内 is_owner 模板对应的已灌入角色 id（Owner 邀请的 defaultRoleId；无 is_owner 模板 → null）。 */
    public String findOwnerRoleId(String tenantId, List<AppRoleTemplate> templates) {
        return templates.stream()
                .filter(AppRoleTemplate::isOwner)
                .map(AppRoleTemplate::roleCode)
                .flatMap(code -> roleRepository.listByScope("TENANT", tenantId).stream()
                        .filter(r -> code.equals(r.getRoleCode())))
                .map(r -> r.getRoleId().trim())
                .findFirst()
                .orElse(null);
    }

    public void grantOwnerRoles(String membershipId, String tenantId, List<AppRoleTemplate> templates) {
        List<String> ownerRoleCodes = templates.stream()
                .filter(AppRoleTemplate::isOwner)
                .map(AppRoleTemplate::roleCode).toList();
        if (ownerRoleCodes.isEmpty()) {
            return;
        }
        List<String> ownerRoleIds = Stream.concat(
                        roleRepository.listByScope("TENANT", tenantId).stream(),
                        roleRepository.listByScope("PLATFORM", "PLATFORM").stream())
                .filter(r -> ownerRoleCodes.contains(r.getRoleCode()))
                .map(RolePO::getRoleId).toList();
        membershipRoleRepository.replaceDirectRoles(membershipId, ownerRoleIds);
    }

    private boolean roleExists(String tenantId, String roleCode) {
        return roleRepository.listByScope("TENANT", tenantId).stream()
                .anyMatch(r -> roleCode.equals(r.getRoleCode()));
    }
}

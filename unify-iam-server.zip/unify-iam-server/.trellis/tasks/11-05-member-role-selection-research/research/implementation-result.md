# Tenant role implementation result

## Delivered
- New GET `/api/v1/admin/tenant/roles?tenant_id=T`, member read permission, required normalized explicit tenant, scope guard before target existence/data access, typed response `{tenant_id,roles,count}` in existing envelope.
- New role DTO includes role_id/code/name/description, scope_type/id, role_status, is_builtin/is_owner. No grantability flag or unapproved disabling policy.
- Isolated grouped OR repository query: canonical PLATFORM custom plus target TENANT, logical deletion on both arms, id ASC. Service excludes only target template-defined TENANT Owner codes; retains global same-code roles, tenant builtin non-owner roles and DISABLED rows. Existing management/runtime queries remain unchanged.
- Tests prove both tenant/platform callers obtain exact union, authorization and isolation, missing/blank/deleted targets, metadata/count/order, Owner templates from enabled applications, and unchanged old queries.
- Existing ordinary invitation/member writes accept target non-owner builtin role. PLATFORM candidate remains rejected by invitation (IAM-ROLE-011). A test-only PLATFORM binding makes the real guard classify a tenant member as platform administrator, confirming why grant semantics remain a product blocker. No production write/guard change.

## Files owned by implementation
- iam-api/src/main/java/com/unify/iam/api/dto/admin/TenantRoleOption.java
- iam-api/src/main/java/com/unify/iam/api/dto/admin/TenantRoleOptions.java
- iam-app/src/main/java/com/unify/iam/app/adapter/controller/TenantRoleController.java
- iam-app/src/main/java/com/unify/iam/app/app/service/admin/TenantRoleQueryService.java
- iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/repository/RoleRepository.java (additive method only; existing dirty work preserved)
- iam-app/src/test/java/com/unify/iam/app/TenantRoleControllerTest.java
- iam-app/src/test/java/com/unify/iam/app/TenantRoleQueryServiceTest.java
- iam-app/src/test/java/com/unify/iam/app/TenantRoleOptionsIntegrationTest.java

## Validation
JDK21 at /opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home. Final escalated command:

```sh
JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin:$PATH mvn -q -pl iam-app -am -Dtest=TenantRoleQueryServiceTest,TenantRoleControllerTest,TenantRoleOptionsIntegrationTest,AdminMemberScopeContractTest,TenantMemberSearchIntegrationTest,AdminRoleListIntegrationTest,AdminRoleControllerTest,AdminRoleServiceTest -Dsurefire.failIfNoSpecifiedTests=false test
```

Passed, exit 0: 54 tests, zero failures/errors/skips. Includes parent-owned Source passthrough regressions. MySQL Testcontainers ran successfully. Full log: research/implementation-regression.log. `git diff --check` passed.

Earlier sandbox run compiled successfully but tests could not attach Mockito agent/access Docker; escalated rerun resolved environment blocks. One initial integration assertion observed stale MyBatis session cache after JDBC fixture insertion; test fixture now clears the session cache before checking newly inserted binding, consistent with existing integration tests. No production semantics were changed to make the test pass. The corrected focused 27-test suite and expanded final 54-test suite both pass.

No Git mutation, branch/worktree operation, other-project access or production write policy changes.

package com.unify.iam.api.model;

import java.util.List;
import java.util.Map;

/**
 * 授权上下文：业务应用只消费的"已授权上下文"（《架构设计》§8.2）。
 *
 * <p>与 parlant-agent {@code context.py} 同构（userId/tenantId/membershipId/roles/permissions/attrs），
 * 是跨系统契约的 Java 侧单一事实源；E2E-1 由 {@code /api/v1/auth/me} 与仿真测试产出。
 *
 * @param userId 用户业务 ID（sub）
 * @param tenantId 租户 ID
 * @param membershipId 成员关系 ID
 * @param roles 角色编码（有序）
 * @param permissions 权限点编码（有序）
 * @param attrs 数据属性上下文（dataAttributes；数据策略预留，E2E-1 恒空）
 */
public record AuthorizationContext(
        String userId,
        String tenantId,
        String membershipId,
        List<String> roles,
        List<String> permissions,
        Map<String, List<String>> attrs) {

    public static final String DEFAULT_TENANT = "workspace";

    public static AuthorizationContext of(
            String userId,
            String tenantId,
            String membershipId,
            List<String> roles,
            List<String> permissions) {
        return new AuthorizationContext(userId, tenantId, membershipId, roles, permissions, Map.of());
    }
}

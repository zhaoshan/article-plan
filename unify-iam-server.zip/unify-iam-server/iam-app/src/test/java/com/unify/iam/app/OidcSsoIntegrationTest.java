package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.support.MockOidcProvider;
import com.unify.iam.common.util.JsonUtils;
import java.net.URI;
import java.net.URLDecoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * E2E-2 端到端集成测试（Testcontainers MySQL + Mock OIDC Provider）：
 * OIDC 全链路 authorize→callback→验签→JIT→组映射→签发，验证 SSO 登录 / 域名路由 / 建租户 / 个人租户 / 幂等 / 负向。
 */
class OidcSsoIntegrationTest extends IamIntegrationTestBase {

    private static MockOidcProvider mock;

    @BeforeAll
    static void startMock() {
        mock = MockOidcProvider.start();
    }

    @AfterAll
    static void stopMock() {
        mock.close();
    }

    @BeforeEach
    void prepare() {
        // 测试隔离：清空每次用到的 IdP 配置表（避免多测试共用同一 mock issuer/tenant 撞唯一键）
        jdbcTemplate.update("DELETE FROM gateway_idp_group_mapping");
        jdbcTemplate.update("DELETE FROM gateway_tenant_idp_config");
        // 让 seed 租户 tenant-org-a 可被域名 org-a.com 命中（V2 seed 的 primary_domain 为空）
        jdbcTemplate.update("UPDATE gateway_tenant SET primary_domain = 'org-a.com' WHERE tenant_id = 'tenant-org-a'");
    }

    private void insertIdpConfig(String configId, String tenantId, String providerKey,
                                 String allowedDomainsJson, String joinPolicy) {
        jdbcTemplate.update("""
                INSERT INTO gateway_tenant_idp_config
                  (tenant_idp_config_id, tenant_id, protocol, provider_key, display_name, config_status,
                   issuer, authorization_endpoint, token_endpoint, jwk_set_uri,
                   client_id, client_secret_cipher,
                   scopes_json, claim_mapping_json, allowed_domains_json,
                   pkce_required, email_verified_required, jit_provisioning_enabled, default_join_policy,
                   delete_flag, create_by, update_by)
                VALUES (?, ?, 'OIDC', ?, 'Mock SSO', 'ACTIVE',
                        ?, ?, ?, ?,
                        'iam', 'mock-secret',
                        '["openid","email","profile","groups"]',
                        '{"email":"email","sub":"sub","name":"name","groups":"groups"}', ?,
                        1, 0, 1, ?,
                        0, 'system', 'system')
                """,
                configId, tenantId, providerKey,
                mock.issuer(),
                mock.baseUrl() + "/authorize", mock.baseUrl() + "/token", mock.baseUrl() + "/jwks",
                allowedDomainsJson, joinPolicy);
    }

    private void insertGroupMapping(String configId, String matchValue, String roleId) {
        jdbcTemplate.update("""
                INSERT INTO gateway_idp_group_mapping
                  (idp_group_mapping_id, tenant_idp_config_id, match_mode, match_value, target_role_id, priority, mapping_status,
                   delete_flag, create_by, update_by)
                VALUES (?, ?, 'EXACT', ?, ?, 100, 'ACTIVE', 0, 'system', 'system')
                """, "gm-" + matchValue, configId, matchValue, roleId);
    }

    private void mockUser(String subject, String email, List<String> groups) {
        mock.configure(new MockOidcProvider.UserProfile(subject, email, groups));
    }

    /** 走完 authorize + Mock IdP 两步，拿到回跳 IAM callback 的 code/state。 */
    private Map<String, String> ssoCodeAndState(String tenantId) throws Exception {
        // ① IAM authorize → 302 跳 Mock IdP
        MvcResult authRes = mockMvc.perform(get("/api/v1/auth/oidc/authorize")
                        .param("tenant_id", tenantId))
                .andExpect(status().is3xxRedirection())
                .andReturn();
        String authorizeUrl = authRes.getResponse().getHeader("Location");

        // ② 浏览器（HttpClient）走 Mock IdP authorize → 302 回 IAM callback（带 code/state）
        HttpClient http = HttpClient.newHttpClient();
        HttpResponse<String> idpRes = http.send(
                HttpRequest.newBuilder(URI.create(authorizeUrl)).build(), HttpResponse.BodyHandlers.ofString());
        String location = idpRes.headers().firstValue("Location").orElseThrow();
        return query(location);
    }

    /** 模拟浏览器完整走完 SSO：IAM authorize → Mock IdP → IAM callback（Accept json 拿 LoginResponse）。 */
    private LoginResponse ssoLogin(String tenantId) throws Exception {
        Map<String, String> cb = ssoCodeAndState(tenantId);

        // ③ IAM callback（Accept json 拿 LoginResponse）
        MvcResult cbRes = mockMvc.perform(get("/api/v1/auth/oidc/callback")
                        .param("code", cb.get("code"))
                        .param("state", cb.get("state"))
                        .header("Accept", MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(cbRes.getResponse().getContentAsString(), LoginResponse.class);
    }

    private com.nimbusds.jwt.JWTClaimsSet decode(String token) throws Exception {
        return SignedJWT.parse(token).getJWTClaimsSet();
    }

    private Map<String, String> query(String url) {
        int q = url.indexOf('?');
        Map<String, String> map = new LinkedHashMap<>();
        if (q < 0) {
            return map;
        }
        for (String pair : url.substring(q + 1).split("&")) {
            int eq = pair.indexOf('=');
            if (eq > 0) {
                map.put(URLDecoder.decode(pair.substring(0, eq), StandardCharsets.UTF_8),
                        URLDecoder.decode(pair.substring(eq + 1), StandardCharsets.UTF_8));
            }
        }
        return map;
    }

    /**
     * 浏览器形态回调（无 Accept json）→ 302 回 frontend-redirect，query 同时携带 access_token + refresh_token；
     * 且该 refresh_token 可被 /auth/refresh 消费（轮换）——验证 SSO 签发的 refresh 真实可用（parlant 静默刷新链路）。
     */
    @Test
    void callbackRedirectCarriesAccessAndRefreshToken() throws Exception {
        insertIdpConfig("cfg-redir", "tenant-org-a", "keycloak", "[\"org-a.com\"]", "AUTO_JOIN");
        mockUser("u-oidc-redir", "alice@org-a.com", List.of());

        Map<String, String> cs = ssoCodeAndState("tenant-org-a");
        MvcResult cbRes = mockMvc.perform(get("/api/v1/auth/oidc/callback")
                        .param("code", cs.get("code"))
                        .param("state", cs.get("state")))
                .andExpect(status().is3xxRedirection())
                .andReturn();
        String location = cbRes.getResponse().getHeader("Location");
        Map<String, String> query = query(location);
        assertThat(query).containsKeys("access_token", "refresh_token");
        assertThat(query.get("access_token")).isNotBlank();
        assertThat(query.get("refresh_token")).isNotBlank();

        // refresh_token 轮换消费（parlant BFF /api/auth/refresh 转发同款）
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"" + query.get("refresh_token") + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.access_token").exists())
                .andExpect(jsonPath("$.data.refresh_token").exists());
    }

    private int count(String table, String where) {
        return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM " + table + " WHERE " + where, Integer.class);
    }

    @Test
    void fullOidcFlowDomainsRouteAndGroupToRole() throws Exception {
        insertIdpConfig("cfg-ent", "tenant-org-a", "keycloak", "[\"org-a.com\"]", "AUTO_JOIN");
        insertGroupMapping("cfg-ent", "agent-operators", "r-1001"); // → AgentOperator
        mockUser("u-oidc-1000", "alice@org-a.com", List.of("agent-operators"));

        LoginResponse resp = ssoLogin("tenant-org-a");
        assertThat(resp.accessToken()).isNotBlank();
        assertThat(resp.user().userName()).isEqualTo("alice@org-a.com");

        var claims = decode(resp.accessToken());
        assertThat(claims.getSubject()).isNotBlank();
        assertThat(claims.getClaim("tenantId")).isEqualTo("tenant-org-a");
        assertThat(claims.getAudience()).contains("parlant-agent-server"); // 与 E2E-1 契约同构
        assertThat((List<String>) claims.getClaim("roles")).contains("AgentOperator");
        assertThat((List<String>) claims.getClaim("permissions")).contains("agent:publish"); // 组映射 → AgentOperator 权限
    }

    @Test
    void unprovisionedDomainRejected() throws Exception {
        insertIdpConfig("cfg-new", "tenant-org-a", "keycloak", "[\"newco.com\"]", "AUTO_JOIN");
        mockUser("u-oidc-2000", "carol@newco.com", List.of());

        // S1：域名路由未命中 → 403（企业 SSO 不再 JIT 自建 ORGANIZATION；域名未开通须先建租户再配该租户 IdP）
        Map<String, String> cb = ssoCodeAndState("tenant-org-a");
        mockMvc.perform(get("/api/v1/auth/oidc/callback")
                        .param("code", cb.get("code"))
                        .param("state", cb.get("state"))
                        .header("Accept", MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.detail").value(org.hamcrest.Matchers.containsString("未开通")));
    }

    @Test
    void consumerLoginCreatesPersonalTenant() throws Exception {
        insertIdpConfig("cfg-consumer", "PLATFORM", "google", "[]", "AUTO_JOIN");
        mockUser("u-oidc-3000", "bob@gmail.com", List.of());

        LoginResponse resp = ssoLogin("PLATFORM");
        var claims = decode(resp.accessToken());
        String tenantId = String.valueOf(claims.getClaim("tenantId"));
        String type = jdbcTemplate.queryForObject(
                "SELECT tenant_type FROM gateway_tenant WHERE tenant_id = ?", String.class, tenantId);
        assertThat(type).isEqualTo("PERSONAL");
    }

    @Test
    void idempotentOnRepeatedLogin() throws Exception {
        insertIdpConfig("cfg-ent", "tenant-org-a", "keycloak", "[\"org-a.com\"]", "AUTO_JOIN");
        mockUser("u-oidc-4000", "dave@org-a.com", List.of());

        LoginResponse first = ssoLogin("tenant-org-a");
        LoginResponse second = ssoLogin("tenant-org-a");

        assertThat(decode(first.accessToken()).getSubject()).isEqualTo(decode(second.accessToken()).getSubject());
        assertThat(count("gateway_user", "username='dave@org-a.com'")).isEqualTo(1);
        assertThat(count("gateway_user_identity", "subject='u-oidc-4000'")).isEqualTo(1);
        String tenant = String.valueOf(decode(first.accessToken()).getClaim("tenantId"));
        assertThat(count("gateway_membership", "tenant_id='" + tenant + "' AND user_id=(SELECT user_id FROM gateway_user WHERE username='dave@org-a.com')"))
                .isEqualTo(1);
    }

    @Test
    void blockedDomainRejected() throws Exception {
        insertIdpConfig("cfg-ent", "tenant-org-a", "keycloak", "[\"org-a.com\"]", "AUTO_JOIN");
        mockUser("u-oidc-5000", "alice@evil.com", List.of());

        // 走全流程但用违法域邮箱 → /me 前即 403（callback 阶段）
        MvcResult authRes = mockMvc.perform(get("/api/v1/auth/oidc/authorize")
                        .param("tenant_id", "tenant-org-a"))
                .andExpect(status().is3xxRedirection()).andReturn();
        String authorizeUrl = authRes.getResponse().getHeader("Location");
        HttpClient http = HttpClient.newHttpClient();
        HttpResponse<String> idpRes = http.send(
                HttpRequest.newBuilder(URI.create(authorizeUrl)).build(), HttpResponse.BodyHandlers.ofString());
        String location = idpRes.headers().firstValue("Location").orElseThrow();
        Map<String, String> cb = query(location);

        mockMvc.perform(get("/api/v1/auth/oidc/callback")
                        .param("code", cb.get("code"))
                        .param("state", cb.get("state"))
                        .header("Accept", MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.detail").value(org.hamcrest.Matchers.containsString("域名")));
    }

    @Test
    void invalidStateRejected() throws Exception {
        mockMvc.perform(get("/api/v1/auth/oidc/callback")
                        .param("code", "anything")
                        .param("state", "state-that-never-existed")
                        .header("Accept", MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void anonymousSsoTenantsListsTenantWithIdp() throws Exception {
        insertIdpConfig("cfg-sso-tenants", "tenant-org-a", "keycloak", "[\"org-a.com\"]", "AUTO_JOIN");

        // 匿名（无 token）即可访问：列出已配 ACTIVE OIDC IdP 的 ACTIVE 租户
        mockMvc.perform(get("/api/v1/auth/sso/tenants"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenants[?(@.tenant_id == 'tenant-org-a')].tenant_name")
                        .value(org.hamcrest.Matchers.hasItem("Org A")));

        // 带 app_code：只返回 iam_tenant_application 里启用了该应用的租户（tenant-org-a 已启用 parlant，V6 seed）
        mockMvc.perform(get("/api/v1/auth/sso/tenants").param("app_code", "parlant-agent-server"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenants[?(@.tenant_id == 'tenant-org-a')].tenant_name")
                        .value(org.hamcrest.Matchers.hasItem("Org A")));

        // 未启用该应用的租户不出现
        mockMvc.perform(get("/api/v1/auth/sso/tenants").param("app_code", "no-such-app"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(0));
    }
}
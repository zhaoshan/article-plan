package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.transaction.annotation.Transactional;

/** 真实 MySQL 上验证搜索先于截断、资料投影一致、权限隔离与提交端有效性复核。 */
@Transactional
class TenantMemberSearchIntegrationTest extends IamIntegrationTestBase {
    @Autowired private SqlSessionTemplate sqlSession;

    private String token(String username, String password) throws Exception {
        String json = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64(password)))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return JsonUtils.fromJson(dataJson(json), LoginResponse.class).accessToken();
    }

    private void tenant(String id, String ownerId) {
        jdbcTemplate.update("""
                INSERT INTO gateway_tenant (tenant_id, tenant_code, tenant_name, tenant_type, owner_user_id)
                VALUES (?, ?, '成员搜索测试', 'ORGANIZATION', ?)
                """, id, id, ownerId);
    }

    private void user(String id, String username, String fullName, String displayName, String email,
                      String state, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_user (user_id, username, full_name, display_name, primary_email,
                  user_status, delete_flag, default_tenant_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'unrelated-default')
                """, id, username, fullName, displayName, email, state, deleted);
    }

    private void user(String id, String state, int deleted) {
        user(id, "login-" + id, "全名-" + id, "昵称-" + id, id + "@example.test", state, deleted);
    }

    private void member(String id, String tenantId, String userId, String state, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_membership (membership_id, tenant_id, user_id, membership_status,
                  join_source, is_default, delete_flag) VALUES (?, ?, ?, ?, 'ADMIN', 0, ?)
                """, id, tenantId, userId, state, deleted);
    }

    private MockHttpServletRequestBuilder request(String tenantId, String token) {
        return get("/api/v1/admin/members").param("scope_type", "TENANT").param("scope_id", tenantId)
                .header("Authorization", "Bearer " + token);
    }

    private Map<String, Object> data(MockHttpServletRequestBuilder request) throws Exception {
        sqlSession.clearCache(); // 同一回滚事务内 JDBC fixture 的变更模拟下一独立请求。
        String json = mockMvc.perform(request).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return unwrapData(json);
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> members(Map<String, Object> data) {
        return (List<Map<String, Object>>) data.get("members");
    }

    @Test
    @SuppressWarnings("unchecked")
    void sharedProjectionKeepsRealNamesEmailsRolesAndUnavailableRelationsEvenWithCharPadding() throws Exception {
        String original = jdbcTemplate.queryForObject("SELECT @@session.sql_mode", String.class);
        jdbcTemplate.execute("SET SESSION sql_mode = CONCAT(@@session.sql_mode, ',PAD_CHAR_TO_FULL_LENGTH')");
        try {
            tenant("search-projection", "search-live");
            user("search-live", "ACTIVE", 0);
            user("search-minimal", "numeric-looking-login", null, null, null, "ACTIVE", 0);
            // 重现截图：真实user_id对应逻辑删除用户，有残留username/email也不可返回。
            String screenshotUser = "47a0408e815c4c7487d27d1992ae6db1";
            user(screenshotUser, "DISABLED", 1);
            member("search-ms-live", "search-projection", "search-live", "ACTIVE", 0);
            member("search-ms-minimal", "search-projection", "search-minimal", "ACTIVE", 0);
            member("search-ms-deleted", "search-projection", screenshotUser, "ACTIVE", 0);
            member("search-ms-missing", "search-projection", "absent-user", "PENDING", 0);
            jdbcTemplate.update("""
                    INSERT INTO gateway_role (role_id, scope_type, scope_id, role_code, role_name)
                    VALUES ('search-role', 'TENANT', 'search-projection', 'SearchReader', '真实角色')
                    """);
            jdbcTemplate.update("""
                    INSERT INTO gateway_membership_role (membership_role_id, membership_id, role_id)
                    VALUES ('search-grant', 'search-ms-live', 'search-role')
                    """);
            String bearer = token("admin", "admin123");
            List<Map<String, Object>> listing = members(data(request(" search-projection ", bearer)));
            Map<String, Object> detail = data(get("/api/v1/admin/tenants/search-projection/details")
                    .header("Authorization", "Bearer " + bearer));
            List<Map<String, Object>> detailItems = (List<Map<String, Object>>)
                    ((Map<String, Object>) detail.get("members")).get("items");
            assertThat(listing).hasSize(4);
            for (int i = 0; i < listing.size(); i++) {
                Map<String, Object> normalized = new LinkedHashMap<>(listing.get(i));
                assertThat(normalized.remove("tenant_id")).isEqualTo("search-projection");
                normalized.remove("tenant_name");
                normalized.remove("tenant_type");
                normalized.put("is_default", "1".equals(normalized.get("is_default")));
                assertThat(normalized).isEqualTo(detailItems.get(i));
            }
            assertThat(listing.getFirst()).containsEntry("display_name", "昵称-search-live")
                    .containsEntry("email", "search-live@example.test").containsEntry("is_owner", true)
                    .containsEntry("owner_eligible", false).containsEntry("user_status", "ACTIVE");
            assertThat((List<?>) listing.getFirst().get("roles")).hasSize(1);
            assertThat(listing.get(1)).containsEntry("user_available", true).containsEntry("owner_eligible", true)
                    .containsEntry("username", "numeric-looking-login").doesNotContainKeys("full_name", "email");
            for (int index : List.of(2, 3)) {
                assertThat(listing.get(index)).containsEntry("user_available", false)
                        .containsEntry("owner_eligible", false)
                        .doesNotContainKeys("username", "display_name", "full_name", "email", "user_status");
            }
        } finally {
            jdbcTemplate.update("SET SESSION sql_mode = ?", original);
        }
    }

    @Test
    void memberSourceIsReadFromEachPersistedMembershipInTenantAndPlatformViews() throws Exception {
        tenant("source-tenant", null);
        List<String> sources = List.of("OWNER", "INVITE", "ADMIN", "SSO");
        for (int i = 0; i < sources.size(); i++) {
            String id = "source-" + i;
            user(id, "ACTIVE", 0);
            member(id + "-ms", "source-tenant", id, "ACTIVE", 0);
            jdbcTemplate.update("UPDATE gateway_membership SET join_source=? WHERE membership_id=?",
                    sources.get(i), id + "-ms");
        }
        String bearer = token("admin", "admin123");
        assertThat(members(data(request("source-tenant", bearer))))
                .extracting(row -> row.get("join_source")).containsExactlyElementsOf(sources);
        assertThat(members(data(get("/api/v1/admin/members")
                .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                .param("keyword", "source-").header("Authorization", "Bearer " + bearer))))
                .extracting(row -> row.get("join_source")).containsExactlyElementsOf(sources);
    }

    @Test
    void searchesAllFourRealProfileFieldsWithinTenantAndEscapesLiteralWildcards() throws Exception {
        tenant("search-fields", null);
        tenant("search-foreign", null);
        user("sf-live", "NeedleLogin", "真实姓名", "可读昵称", "mailneedle@example.test", "ACTIVE", 0);
        member("sf-ms", "search-fields", "sf-live", "ACTIVE", 0);
        user("sf-wild", "literal%_!login", null, null, null, "ACTIVE", 0);
        member("sf-wild-ms", "search-fields", "sf-wild", "ACTIVE", 0);
        user("sf-deleted", "ACTIVE", 1);
        member("sf-deleted-ms", "search-fields", "sf-deleted", "ACTIVE", 0);
        user("sf-removed", "NeedleRemoved", null, null, null, "ACTIVE", 0);
        member("sf-removed-ms", "search-fields", "sf-removed", "ACTIVE", 1);
        user("sf-foreign", "NeedleForeign", "真实姓名", "可读昵称", null, "ACTIVE", 0);
        member("sf-foreign-ms", "search-foreign", "sf-foreign", "ACTIVE", 0);
        user("sf-directory-only", "NeedleDirectory", "真实姓名", "可读昵称", null, "ACTIVE", 0);
        String bearer = token("admin", "admin123");
        for (String keyword : List.of("  needlelogin ", "实姓", "读昵", "MAILNEEDLE")) {
            Map<String, Object> result = data(request("search-fields", bearer).param("keyword", keyword));
            assertThat(members(result)).extracting(m -> m.get("membership_id")).containsExactly("sf-ms");
            assertThat(result).containsEntry("total", 1).containsEntry("truncated", false);
        }
        for (String literal : List.of("%", "_", "!", "%_!")) {
            assertThat(members(data(request("search-fields", bearer).param("keyword", literal))))
                    .extracting(m -> m.get("membership_id")).containsExactly("sf-wild-ms");
        }
        for (String absent : List.of("sf-deleted", "sf-foreign", "sf-directory-only", "' OR 1=1 --")) {
            assertThat(members(data(request("search-fields", bearer).param("keyword", absent)))).isEmpty();
        }
        assertThat(members(data(request("search-fields", bearer).param("keyword", "  ")))).hasSize(3);
    }

    @Test
    void ownerCandidatesRequireActiveRealUserAndActiveMembershipAndExcludeCurrentOwner() throws Exception {
        tenant("search-candidates", "sc-owner");
        String[] states = {"ACTIVE", "PENDING", "SUSPENDED", "DISABLED", "DELETED"};
        for (String state : states) {
            user("sc-user-" + state, state, 0);
            member("sc-ms-" + state, "search-candidates", "sc-user-" + state, "ACTIVE", 0);
        }
        user("sc-owner", "ACTIVE", 0);
        member("sc-owner-ms", "search-candidates", "sc-owner", "ACTIVE", 0);
        user("sc-deleted", "ACTIVE", 1);
        member("sc-deleted-ms", "search-candidates", "sc-deleted", "ACTIVE", 0);
        member("sc-missing-ms", "search-candidates", "sc-missing", "ACTIVE", 0);
        for (String state : List.of("PENDING", "SUSPENDED", "REMOVED")) {
            user("sc-member-" + state, "ACTIVE", 0);
            member("sc-member-ms-" + state, "search-candidates", "sc-member-" + state, state, 0);
        }
        user("sc-deleted-relation", "ACTIVE", 0);
        member("sc-deleted-relation-ms", "search-candidates", "sc-deleted-relation", "ACTIVE", 1);
        String bearer = token("admin", "admin123");
        Map<String, Object> candidates = data(request("search-candidates", bearer).param("owner_candidates", "true"));
        assertThat(members(candidates)).extracting(m -> m.get("membership_id")).containsExactly("sc-ms-ACTIVE");
        assertThat(members(candidates).getFirst()).containsEntry("owner_eligible", true);
        assertThat(members(data(request("search-candidates", bearer)))).hasSize(11);
        jdbcTemplate.update("UPDATE gateway_tenant SET owner_user_id=NULL WHERE tenant_id='search-candidates'");
        assertThat(members(data(request("search-candidates", bearer).param("owner_candidates", "true"))))
                .extracting(m -> m.get("membership_id")).containsExactly("sc-ms-ACTIVE", "sc-owner-ms");
    }

    @Test
    void filteringHappensBeforeCapAndStableUnpagedLimitReportsTrueMatchingTotal() throws Exception {
        tenant("search-cap", null);
        List<Object[]> rows = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            rows.add(new Object[]{"search-cap-m-" + i, "search-cap-u-" + i});
        }
        jdbcTemplate.batchUpdate("""
                INSERT INTO gateway_membership (membership_id, tenant_id, user_id, membership_status)
                VALUES (?, 'search-cap', ?, 'ACTIVE')
                """, rows);
        user("search-cap-real", "ACTIVE", 0);
        member("search-cap-last", "search-cap", "search-cap-real", "ACTIVE", 0);
        String bearer = token("admin", "admin123");
        Map<String, Object> capped = data(request("search-cap", bearer));
        assertThat(members(capped)).hasSize(1000);
        assertThat(capped).containsEntry("count", 1000).containsEntry("limit", 1000)
                .containsEntry("total", 1001).containsEntry("truncated", true).doesNotContainKeys("page", "size");
        Map<String, Object> first = data(request("search-cap", bearer).param("limit", "1")
                .param("page", "999").param("size", "999"));
        assertThat(members(first)).extracting(m -> m.get("membership_id")).containsExactly("search-cap-m-0");
        assertThat(first).containsEntry("count", 1).containsEntry("limit", 1).containsEntry("total", 1001)
                .containsEntry("truncated", true);
        for (MockHttpServletRequestBuilder search : List.of(
                request("search-cap", bearer).param("keyword", "昵称-search-cap-real").param("limit", "1"),
                request("search-cap", bearer).param("owner_candidates", "true").param("limit", "1"))) {
            Map<String, Object> result = data(search);
            assertThat(members(result)).extracting(m -> m.get("membership_id")).containsExactly("search-cap-last");
            assertThat(result).containsEntry("total", 1).containsEntry("truncated", false);
        }
    }

    @Test
    void requiresMemberReadAndTenantScopeWithoutGlobalUserReadAndValidatesQuery() throws Exception {
        String admin = token("admin", "admin123");
        mockMvc.perform(get("/api/v1/admin/members").param("scope_type", "TENANT").param("scope_id", "tenant-org-a"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(request("tenant-org-a", token("viewer", "view123")))
                .andExpect(status().isForbidden());
        jdbcTemplate.update("""
                INSERT INTO gateway_role (role_id, scope_type, scope_id, role_code, role_name)
                VALUES ('search-reader', 'TENANT', 'tenant-org-a', 'MemberReader', '成员只读')
                """);
        jdbcTemplate.update("""
                INSERT INTO gateway_membership_role (membership_role_id, membership_id, role_id)
                VALUES ('search-reader-grant', 'ms-3001', 'search-reader')
                """);
        assertThat(jdbcTemplate.update("""
                INSERT INTO gateway_role_permission (role_permission_id, role_id, permission_id)
                SELECT 'search-reader-perm', 'search-reader', permission_id FROM gateway_permission
                WHERE permission_code='iam:member:read' AND delete_flag=0
                """)).isEqualTo(1);
        String scoped = token("viewer", "view123");
        data(request("tenant-org-a", scoped).param("owner_candidates", "true").param("keyword", "op"));
        tenant("search-private", null);
        mockMvc.perform(request("search-private", scoped).param("keyword", "op").param("owner_candidates", "true"))
                .andExpect(status().isForbidden());
        mockMvc.perform(get("/api/v1/admin/members").header("Authorization", "Bearer " + admin))
                .andExpect(status().isBadRequest());
        mockMvc.perform(request(" ", admin)).andExpect(status().isBadRequest());
        for (String limit : List.of("0", "-1", "1001", "invalid")) {
            mockMvc.perform(request("tenant-org-a", admin).param("limit", limit)).andExpect(status().isBadRequest());
        }
        mockMvc.perform(request("search-does-not-exist", admin)).andExpect(status().isNotFound());
    }

    @Test
    void platformScopeAggregatesTenantAttributionAndAppliesStatusBeforeLimit() throws Exception {
        tenant("search-platform-a", "sp-owner-a");
        tenant("search-platform-b", "sp-owner-b");
        user("sp-owner-a", "ACTIVE", 0);
        user("sp-owner-b", "ACTIVE", 0);
        user("sp-active-a", "ACTIVE", 0);
        user("sp-active-b", "ACTIVE", 0);
        user("sp-pending-b", "ACTIVE", 0);
        user("sp-suspended-a", "ACTIVE", 0);
        member("sp-owner-a-ms", "search-platform-a", "sp-owner-a", "ACTIVE", 0);
        member("sp-active-a-ms", "search-platform-a", "sp-active-a", "ACTIVE", 0);
        member("sp-owner-b-ms", "search-platform-b", "sp-owner-b", "ACTIVE", 0);
        member("sp-active-b-ms", "search-platform-b", "sp-active-b", "ACTIVE", 0);
        member("sp-pending-b-ms", "search-platform-b", "sp-pending-b", "PENDING", 0);
        member("sp-suspended-a-ms", "search-platform-a", "sp-suspended-a", "SUSPENDED", 0);
        String bearer = token("admin", "admin123");

        Map<String, Object> activeAndPending = data(get("/api/v1/admin/members")
                .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                .param("keyword", "sp-").param("membership_status", "ACTIVE,PENDING").param("limit", "2")
                .header("Authorization", "Bearer " + bearer));
        assertThat(members(activeAndPending)).extracting(m -> m.get("membership_id"))
                .containsExactly("sp-owner-a-ms", "sp-active-a-ms");
        assertThat(activeAndPending).containsEntry("count", 2).containsEntry("total", 5)
                .containsEntry("truncated", true).doesNotContainKeys("tenant_type", "tenant_name");
        assertThat(members(activeAndPending).getFirst()).containsEntry("tenant_id", "search-platform-a")
                .containsEntry("tenant_name", "成员搜索测试").containsEntry("tenant_type", "ORGANIZATION");

        Map<String, Object> candidates = data(get("/api/v1/admin/members")
                .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                .param("keyword", "sp-").param("owner_candidates", "true")
                .header("Authorization", "Bearer " + bearer));
        assertThat(members(candidates)).extracting(m -> m.get("membership_id"))
                .containsExactly("sp-active-a-ms", "sp-active-b-ms");
        assertThat(members(candidates)).allSatisfy(member -> assertThat(member)
                .containsEntry("owner_eligible", true));
    }

    @Test
    void scopeContractRejectsLegacyAndStatusAliasAndRequiresCompleteTuple() throws Exception {
        String bearer = token("admin", "admin123");
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isBadRequest());
        mockMvc.perform(get("/api/v1/admin/members").param("scope_type", "PLATFORM")
                        .param("scope_id", "PLATFORM").param("status", "ACTIVE")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isBadRequest());
        mockMvc.perform(get("/api/v1/admin/members").param("scope_type", "PLATFORM")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isBadRequest());
        mockMvc.perform(get("/api/v1/admin/members").param("scope_type", "TENANT")
                        .param("scope_id", "tenant-org-a").param("membership_status", "ACTIVE,REMOVED")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isBadRequest());
    }

    @Test
    void transferRechecksUsersAndMembershipsAndDoesNotMutateOnRejectedStaleCandidate() throws Exception {
        tenant("search-transfer", "st-owner");
        tenant("search-transfer-other", null);
        user("st-owner", "ACTIVE", 0);
        member("st-owner-ms", "search-transfer", "st-owner", "ACTIVE", 0);
        member("st-missing-ms", "search-transfer", "st-absent", "ACTIVE", 0);
        user("st-deleted", "ACTIVE", 1);
        member("st-deleted-ms", "search-transfer", "st-deleted", "ACTIVE", 0);
        for (String state : List.of("PENDING", "SUSPENDED", "DISABLED", "DELETED")) {
            user("st-user-" + state, state, 0);
            member("st-ms-" + state, "search-transfer", "st-user-" + state, "ACTIVE", 0);
        }
        user("st-inactive-member", "ACTIVE", 0);
        member("st-inactive-ms", "search-transfer", "st-inactive-member", "SUSPENDED", 0);
        user("st-foreign", "ACTIVE", 0);
        member("st-foreign-ms", "search-transfer-other", "st-foreign", "ACTIVE", 0);
        user("st-stale", "ACTIVE", 0);
        member("st-stale-ms", "search-transfer", "st-stale", "ACTIVE", 0);
        String bearer = token("admin", "admin123");
        assertThat(members(data(request("search-transfer", bearer).param("owner_candidates", "true"))))
                .extracting(m -> m.get("membership_id")).containsExactly("st-stale-ms");
        jdbcTemplate.update("UPDATE gateway_user SET delete_flag=1 WHERE user_id='st-stale'");
        for (String id : List.of("st-owner-ms", "st-missing-ms", "st-deleted-ms", "st-ms-PENDING",
                "st-ms-SUSPENDED", "st-ms-DISABLED", "st-ms-DELETED", "st-inactive-ms", "st-foreign-ms", "st-stale-ms")) {
            sqlSession.clearCache();
            mockMvc.perform(post("/api/v1/admin/tenants/search-transfer/owner")
                            .header("Authorization", "Bearer " + bearer).contentType(MediaType.APPLICATION_JSON)
                            .content(JsonUtils.toJson(Map.of("mode", "EXISTING_MEMBER", "membership_id", id))))
                    .andExpect(status().isBadRequest());
        }
        assertThat(jdbcTemplate.queryForObject("SELECT owner_user_id FROM gateway_tenant WHERE tenant_id='search-transfer'",
                String.class)).isEqualTo("st-owner");
        assertThat(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM gateway_audit_log WHERE tenant_id='search-transfer'",
                Integer.class)).isZero();
        assertThat(jdbcTemplate.queryForObject("SELECT SUM(token_version) FROM gateway_membership WHERE tenant_id='search-transfer'",
                Integer.class)).isZero();
    }
}

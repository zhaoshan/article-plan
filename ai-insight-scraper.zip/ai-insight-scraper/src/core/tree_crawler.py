"""Tree 模式站点链接树爬取器

从 scripts/deep_crawl_nested_links.py 提取 tree 模式 BFS 遍历逻辑，
重构为独立模块，使用 models/utils/storage/parsers 中的组件。
"""

import asyncio
import json
import logging
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Optional

from playwright.async_api import async_playwright, BrowserContext, Page

from src.boundaries.s3_boundary import S3Boundary, S3Error
from src.core.base_crawler import BaseCrawler
from src.models.crawl_result import TreeNode, TreeStructure
from src.models.traversal_config import DomainTraversalConfig
from src.parsers.link_extractor import extract_links_from_page, extract_page_text
from src.storage.file_storage import FileStorage
from src.storage.log_manager import LogManager
from src.utils.url_utils import (
    normalize_url,
    get_domain,
    is_same_domain,
    is_crawlable_url,
    is_valid_url_for_collection,
    is_domain_in_whitelist,
)

logger = logging.getLogger(__name__)


class PageNavigationError(Exception):
    """页面导航（page.goto / wait_for_load_state）重试耗尽后抛出"""


class PartialFailureThresholdError(Exception):
    """实时局部失败率超过阈值时抛出，用于提前中止 tree 阶段"""


class TreeCrawler(BaseCrawler):
    """
    Tree 模式站点链接树爬取器。

    使用 BFS 遍历策略，构建每个 URL 只出现一次的树结构。
    同域名链接继续下钻，外域链接和文件链接作为叶子节点。

    支持两种输出模式：
      - local（默认）：结果写入本地文件，返回本地路径
      - s3：结果写入本地文件后上传到 S3，返回 s3:// 路径
    """

    def __init__(
        self,
        headless: bool = True,
        output_dir: str | Path = "output",
        log_dir: str | Path = "logs",
        traversal_config: DomainTraversalConfig | None = None,
        s3_boundary: S3Boundary | None = None,
        output_type: str = "local",
    ):
        """
        Args:
            headless: 是否无头模式
            output_dir: 输出目录
            log_dir: 日志目录
            traversal_config: 遍历规则配置
            s3_boundary: S3 边界客户端（output_type="s3" 时必须提供）
            output_type: 输出方式 — "local"（本地文件）或 "s3"（上传到 S3）

        Raises:
            ValueError: output_type="s3" 但 s3_boundary 为 None
        """
        if output_type == "s3" and s3_boundary is None:
            raise ValueError("S3 配置不完整，无法以 s3 模式输出")

        self.headless = headless
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)

        self._storage = FileStorage(self._output_dir)
        self._log_manager = LogManager(log_dir)
        self._traversal_config = traversal_config or DomainTraversalConfig()
        self._s3_boundary = s3_boundary
        self._output_type = output_type

        # 运行时状态（每次 crawl 调用时重置）
        self._target_domain: str | None = None
        self._crawled_urls: set[str] = set()
        self._page_links_map: dict[str, list[str]] = {}
        self._tree_map: dict[str, list[str]] = {}
        self._parent_map: dict[str, str | None] = {}
        self._seen_as_node: set[str] = set()
        self._global_unique_links: set[str] = set()
        self._not_found_urls: set[str] = set()
        self._attempted_pages: int = 0
        self._failed_pages: int = 0
        self._aborted_due_to_failure_rate: bool = False

    # ── 公共接口 ──────────────────────────────────────────

    async def crawl(self, start_url: str, max_depth: int | None = None) -> dict:
        """
        执行 tree 模式爬取。

        Args:
            start_url: 起始页面 URL
            max_depth: 爬取层级，传入时覆盖配置文件中的 drill_down_levels；
                       0=不限，None=使用配置值

        Returns:
            dict: 包含 tree_structure、all_links、stats
        """
        self._reset_state()
        self._target_domain = get_domain(start_url)
        self._log_manager.setup()

        # 传入的 max_depth 优先，否则用配置文件中的 drill_down_levels
        effective_depth = (
            max_depth
            if max_depth is not None
            else self._traversal_config.drill_down_levels
        )

        logger.info(
            f"开始 tree 模式爬取，入口 URL: {start_url}，"
            f"目标域名: {self._target_domain}，"
            f"深度限制: {effective_depth}（0=不限），"
            f"外站收集: {self._traversal_config.need_outer_site}，"
            f"白名单: {self._traversal_config.outer_site_whitelist or '无'}"
        )

        try:
            async with async_playwright() as p:
                context = await self._setup_browser_context(p)

                # 执行 tree 模式 BFS 爬取
                await self._crawl_tree(context, start_url, effective_depth)

                # 关闭浏览器
                await self._teardown_browser(context)

            # 构建树 JSON 结构
            tree_structure = self._build_tree_json(start_url)

            # 收集所有链接
            all_links = sorted(self._seen_as_node)

            # 保存输出
            self._save_output(tree_structure, all_links)

            # 完成日志
            total_pages = len(self._page_links_map)
            total_links = sum(len(links) for links in self._page_links_map.values())
            self._log_manager.finalize_summary(
                total_pages=total_pages,
                total_links=total_links,
                global_unique_count=len(self._global_unique_links),
            )

            logger.info(
                f"爬取完成: {total_pages} 个页面，"
                f"{len(self._global_unique_links)} 条去重链接"
            )

            # 构造输出文件路径（供 DatabaseTaskManager 持久化到数据库）
            ts = self._log_manager.timestamp
            links_filename = f"all_unique_links_{ts}.json"
            tree_filename = f"tree_structure_{ts}.json"
            links_path = f"{self._output_dir}/{links_filename}"
            tree_path = f"{self._output_dir}/{tree_filename}"

            # S3 模式：上传文件到 S3，返回 S3 路径
            if self._output_type == "s3":
                s3_links_path = await self._s3_boundary.upload_file(
                    links_path, links_filename
                )
                s3_tree_path = await self._s3_boundary.upload_file(
                    tree_path, tree_filename
                )
                logger.info(
                    f"已上传爬取结果到 S3: links={s3_links_path}, tree={s3_tree_path}"
                )
                return {
                    "tree_structure": tree_structure,
                    "all_links": all_links,
                    "links_path": s3_links_path,
                    "tree_path": s3_tree_path,
                    "stats": {
                        "total_pages": total_pages,
                        "total_links": total_links,
                        "global_unique_links": len(self._global_unique_links),
                        "target_domain": self._target_domain,
                        "attempted_pages": self._attempted_pages,
                        "failed_pages": self._failed_pages,
                        "success_rate": self._compute_success_rate(),
                        "failure_rate": self._compute_failure_rate(),
                        "aborted_due_to_failure_rate": self._aborted_due_to_failure_rate,
                    },
                }

            return {
                "tree_structure": tree_structure,
                "all_links": all_links,
                "links_path": links_path,
                "tree_path": tree_path,
                "stats": {
                    "total_pages": total_pages,
                    "total_links": total_links,
                    "global_unique_links": len(self._global_unique_links),
                    "target_domain": self._target_domain,
                    "attempted_pages": self._attempted_pages,
                    "failed_pages": self._failed_pages,
                    "success_rate": self._compute_success_rate(),
                    "failure_rate": self._compute_failure_rate(),
                    "aborted_due_to_failure_rate": self._aborted_due_to_failure_rate,
                },
            }
        finally:
            self._log_manager.cleanup()

    # ── Tree 模式 BFS 遍历 ──────────────────────────────

    async def _crawl_tree(
        self, context: BrowserContext, start_url: str, max_depth: int = 0
    ) -> None:
        """
        BFS 爬取并构建树结构。

        Args:
            context: 浏览器上下文
            start_url: 起始 URL
            max_depth: 最大爬取深度，0=不限
        """
        unlimited = max_depth == 0

        normalized_root = normalize_url(start_url)
        self._seen_as_node.add(normalized_root)
        self._parent_map[normalized_root] = None

        queue: deque[tuple[str, int]] = deque([(start_url, 0)])

        while queue:
            url, depth = queue.popleft()

            # 深度限制检查
            if not unlimited and depth > max_depth:
                continue

            # 兜底去重
            if normalize_url(url) in self._crawled_urls:
                logger.info(f"[树结构][深度 {depth}][跳过 - 已下钻] {url}")
                continue

            # 爬取单个页面
            existing_links = await self._crawl_single_page(context, url, depth, max_depth)

            # 更新已尝试页面计数并检查实时失败率
            self._attempted_pages += 1
            self._check_partial_failure_threshold()

            # 分配子节点
            children: list[str] = []
            queued_count = 0
            tree_node_count = 0
            cross_domain_count = 0
            cross_domain_filtered = 0
            already_seen_count = 0

            for link in existing_links:
                norm_link = normalize_url(link)

                # 同域名可爬取且未下钻过的链接，加入队列继续下钻
                if (
                    is_same_domain(link, self._target_domain)
                    and (unlimited or depth < max_depth)
                    and is_crawlable_url(link)
                    and norm_link not in self._crawled_urls
                ):
                    queue.append((link, depth + 1))
                    queued_count += 1

                if norm_link in self._seen_as_node:
                    already_seen_count += 1
                    continue

                if not is_same_domain(link, self._target_domain):
                    # 外域链接：根据 need_outer_site + whitelist 决定是否收集
                    if not self._should_collect_outer_site(norm_link):
                        cross_domain_filtered += 1
                        continue
                    self._seen_as_node.add(norm_link)
                    self._parent_map[norm_link] = normalize_url(url)
                    children.append(norm_link)
                    cross_domain_count += 1
                    continue

                # 同域名链接加入树
                self._seen_as_node.add(norm_link)
                self._parent_map[norm_link] = normalize_url(url)
                children.append(norm_link)
                tree_node_count += 1

            if children:
                self._tree_map[normalize_url(url)] = children

            depth_info = f"[树结构][深度 {depth}{'/不限' if unlimited else f'/{max_depth}'}]"
            logger.info(
                f"{depth_info} {url} → "
                f"提取 {len(existing_links)} 条，"
                f"入队 {queued_count} 条，"
                f"新增同域节点 {tree_node_count} 条，"
                f"新增外域叶子 {cross_domain_count} 条，"
                f"外域过滤 {cross_domain_filtered} 条，"
                f"已占位跳过 {already_seen_count} 条，"
                f"队列剩余 {len(queue)}"
            )

            # 增量写入：每完成一个页面就把当前树结构和去重链接列表落盘
            self._save_output_incremental(start_url)

    def _should_collect_outer_site(self, normalized_url: str) -> bool:
        """
        判断是否应收集该外域链接。

        规则：
        - need_outer_site=False → 不收集任何外域
        - need_outer_site=True + whitelist 为空 → 收集所有外域
        - need_outer_site=True + whitelist 非空 → 仅收集白名单内的外域
        """
        if not self._traversal_config.need_outer_site:
            return False

        whitelist = self._traversal_config.outer_site_whitelist
        if not whitelist:
            return True  # 空白名单 = 全部收集

        return is_domain_in_whitelist(normalized_url, whitelist)

    # ── 单页面爬取 ─────────────────────────────────────

    async def _crawl_single_page(
        self,
        context: BrowserContext,
        url: str,
        depth: int,
        max_depth: int,
    ) -> list[str]:
        """爬取单个页面，提取其所有子链接"""
        normalized_url = normalize_url(url)

        # 已爬取检查
        if normalized_url in self._crawled_urls:
            depth_prefix = f"[深度 {depth}/{max_depth}]" if max_depth > 0 else f"[深度 {depth}]"
            logger.info(f"{depth_prefix}[跳过] URL 已爬取：{url}")
            self._log_manager.log_page_result(url, 0, 0, 0, len(self._global_unique_links), skipped_reason="已爬取")
            return self._page_links_map.get(normalized_url, [])

        # 可爬取检查
        if not is_crawlable_url(url):
            logger.info(f"[深度 {depth}][跳过] 不可爬取的 URL（文件类型）: {url}")
            self._log_manager.log_page_result(url, 0, 0, 0, len(self._global_unique_links), skipped_reason="文件类型不可爬取")
            return []

        # 同域名检查
        if not is_same_domain(url, self._target_domain):
            logger.info(f"[深度 {depth}][跳过] 不同域名的 URL: {url}")
            self._log_manager.log_page_result(url, 0, 0, 0, len(self._global_unique_links), skipped_reason="不同域名")
            return []

        logger.info(f"[深度 {depth}][爬取中] 正在爬取页面：{url}")

        page: Page | None = None
        try:
            page = await self._navigate_page_with_retry(
                context, url, self._traversal_config
            )

            # 检测页面是否为"未找到"页面（如 404 页面但返回 200）
            not_found_texts = self._traversal_config.not_found_texts
            if not_found_texts:
                page_text = await extract_page_text(page)
                if any(text in page_text for text in not_found_texts):
                    self._not_found_urls.add(normalized_url)
                    logger.info(f"[Not Found] 页面内容匹配 not_found_texts: {url}")

            links = await extract_links_from_page(page, url)

            self._crawled_urls.add(normalized_url)

            # 收集有效链接
            collected_links = [
                link for link in links if is_valid_url_for_collection(link)
            ]

            # 去重
            seen_normalized: set[str] = set()
            original_links = []
            for link in collected_links:
                norm = normalize_url(link)
                if norm not in seen_normalized:
                    seen_normalized.add(norm)
                    original_links.append(norm)

            self._page_links_map[normalized_url] = original_links

            # 全局去重
            new_count = 0
            for link in original_links:
                if link not in self._global_unique_links:
                    self._global_unique_links.add(link)
                    new_count += 1

            crawlable_count = sum(
                1 for link in original_links
                if is_same_domain(link, self._target_domain) and is_crawlable_url(link)
            )
            external_count = sum(
                1 for link in original_links
                if not is_same_domain(link, self._target_domain)
            )

            logger.info(
                f"[爬取完成] {url} → {len(original_links)} 个子链接"
                f"（可下钻 {crawlable_count}，外域 {external_count}），"
                f"全局新增 {new_count}，累计 {len(self._global_unique_links)}"
            )

            self._log_manager.log_page_result(
                url, len(original_links), len(links) - len(original_links),
                len(links), len(self._global_unique_links),
            )

            return original_links

        except Exception as e:
            logger.error(f"[爬取失败] {url}: {e}")
            self._failed_pages += 1
            self._crawled_urls.add(normalized_url)
            self._log_manager.log_page_result(
                url, 0, 0, 0, len(self._global_unique_links),
                skipped_reason=f"爬取失败：{e}",
            )
            # 首页（depth=0）爬取失败属于致命错误，直接抛出异常
            # 让上层任务标记为失败，不再继续后续阶段
            if depth == 0:
                raise RuntimeError(f"首页爬取失败: {url}, error={e}") from e
            return []
        finally:
            if page is not None and not page.is_closed():
                try:
                    await page.close()
                except Exception:
                    pass

    # ── 树结构构建 ─────────────────────────────────────

    def _build_tree_json(self, root_url: str) -> dict:
        """构建嵌套 JSON 树结构"""
        normalized_root = normalize_url(root_url)
        return self._build_node(normalized_root)

    def _build_node(self, url: str) -> dict:
        """递归构建树节点"""
        is_leaf = (
            not is_same_domain(url, self._target_domain)
            or not is_crawlable_url(url)
        )
        node: dict = {"url": url}
        if is_leaf:
            node["leaf"] = True
            if not is_same_domain(url, self._target_domain):
                node["type"] = "cross_domain"
            else:
                node["type"] = "file"

        # 标记页面内容匹配 not_found_texts 的节点
        if url in self._not_found_urls:
            node["not_found"] = True

        children = self._tree_map.get(url, [])
        if children:
            node["children"] = [self._build_node(child) for child in children]
        return node

    # ── 输出保存 ──────────────────────────────────────

    def _write_tree_files(
        self, tree_structure: dict, all_links: list[str]
    ) -> tuple[Path, Path]:
        """写入树结构与去重链接列表文件（同名覆盖写，幂等）

        时间戳取自 LogManager，保证整次爬取期间文件名不变，
        增量写入与最终写入落盘到同一组文件。
        """
        ts = self._log_manager.timestamp

        tree_path = self._output_dir / f"tree_structure_{ts}.json"
        tree_path.write_text(
            json.dumps(tree_structure, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        links_path = self._output_dir / f"all_unique_links_{ts}.json"
        links_path.write_text(
            json.dumps(all_links, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return tree_path, links_path

    def _save_output_incremental(self, start_url: str) -> None:
        """增量写入：每完成一个页面就更新树结构与去重链接列表文件

        爬取过程中实时落盘，避免中断导致已爬取数据丢失。
        与最终 _save_output 写入同一组文件（同名覆盖）。
        """
        tree_structure = self._build_tree_json(start_url)
        all_links = sorted(self._seen_as_node)
        self._write_tree_files(tree_structure, all_links)
        logger.info(
            f"[增量输出] 已更新树结构与链接列表，累计 {len(self._seen_as_node)} 个节点"
        )

    def _save_output(self, tree_structure: dict, all_links: list[str]) -> None:
        """保存爬取结果到 output 目录（最终写入，覆盖增量文件）"""
        tree_path, links_path = self._write_tree_files(tree_structure, all_links)
        logger.info(f"树结构已保存: {tree_path}")
        logger.info(f"去重链接列表已保存: {links_path}")

    # ── 内部工具 ──────────────────────────────────────

    def _reset_state(self) -> None:
        """重置运行时状态"""
        self._crawled_urls.clear()
        self._page_links_map.clear()
        self._tree_map.clear()
        self._parent_map.clear()
        self._seen_as_node.clear()
        self._global_unique_links.clear()
        self._not_found_urls.clear()
        self._attempted_pages = 0
        self._failed_pages = 0
        self._aborted_due_to_failure_rate = False

    def _compute_success_rate(self) -> float:
        """计算成功率（成功页面数 / 已尝试页面数）"""
        if self._attempted_pages == 0:
            return 0.0
        return len(self._page_links_map) / self._attempted_pages

    def _compute_failure_rate(self) -> float:
        """计算失败率（失败页面数 / 已尝试页面数）"""
        if self._attempted_pages == 0:
            return 0.0
        return self._failed_pages / self._attempted_pages

    def _check_partial_failure_threshold(self) -> None:
        """检查实时局部失败率是否超过阈值"""
        config = self._traversal_config
        if self._attempted_pages < config.min_pages_for_failure_check:
            return
        failure_rate = self._compute_failure_rate()
        if failure_rate > config.max_partial_failure_rate:
            self._aborted_due_to_failure_rate = True
            logger.error(
                f"Tree 阶段失败率过高: "
                f"{self._failed_pages}/{self._attempted_pages}="
                f"{failure_rate:.2%}，阈值 {config.max_partial_failure_rate:.2%}，"
                f"提前中止 tree 阶段"
            )
            raise PartialFailureThresholdError(
                f"Tree 阶段失败率过高: {self._failed_pages}/{self._attempted_pages}="
                f"{failure_rate:.2%}，阈值 {config.max_partial_failure_rate:.2%}"
            )

    async def _navigate_page_with_retry(
        self,
        context: BrowserContext,
        url: str,
        config: DomainTraversalConfig,
    ) -> Page:
        """带重试的页面导航。

        循环 page_retry_count + 1 次执行 page.goto 与 wait_for_load_state，
        每次失败都会关闭当前 Page，等待 page_retry_delay_ms 后创建新页重试。
        全部重试耗尽后抛出 PageNavigationError。

        Args:
            context: 浏览器上下文
            url: 目标 URL
            config: 域名遍历配置

        Returns:
            Page: 导航成功的页面（调用方负责关闭）

        Raises:
            PageNavigationError: 重试耗尽后仍失败
        """
        max_attempts = config.page_retry_count + 1
        last_exception: Exception | None = None

        for attempt in range(max_attempts):
            page = await context.new_page()
            try:
                await page.goto(
                    url,
                    wait_until="domcontentloaded",
                    timeout=config.page_navigation_timeout_ms,
                )
                await page.wait_for_load_state(
                    "domcontentloaded",
                    timeout=config.page_load_state_timeout_ms,
                )
                await page.wait_for_timeout(config.page_load_wait_ms)
                return page
            except Exception as e:
                last_exception = e
                logger.warning(
                    f"[导航重试] {url} 第 {attempt + 1}/{max_attempts} 次失败: {e}"
                )
                try:
                    await page.close()
                except Exception:
                    pass
                if attempt < config.page_retry_count:
                    await asyncio.sleep(config.page_retry_delay_ms / 1000)

        raise PageNavigationError(
            f"页面导航重试耗尽: {url}，共 {max_attempts} 次，"
            f"最后错误: {last_exception}"
        ) from last_exception

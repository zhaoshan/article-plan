package com.unify.iam.app.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.app.infra.persistence.mapper.TenantDomainChallengeMapper;
import com.unify.iam.app.infra.persistence.po.TenantDomainChallengePO;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** 域名验证挑战仓储。 */
@Repository
public class TenantDomainChallengeRepository {

    private final TenantDomainChallengeMapper mapper;

    public TenantDomainChallengeRepository(TenantDomainChallengeMapper mapper) {
        this.mapper = mapper;
    }

    public void insert(TenantDomainChallengePO po) {
        mapper.insert(po);
    }

    public void update(TenantDomainChallengePO po) {
        mapper.updateById(po);
    }

    public Optional<TenantDomainChallengePO> findPendingByDomain(String tenantDomainId) {
        return Optional.ofNullable(mapper.selectOne(new LambdaQueryWrapper<TenantDomainChallengePO>()
                .eq(TenantDomainChallengePO::getTenantDomainId, tenantDomainId)
                .eq(TenantDomainChallengePO::getChallengeStatus, "PENDING")));
    }
}

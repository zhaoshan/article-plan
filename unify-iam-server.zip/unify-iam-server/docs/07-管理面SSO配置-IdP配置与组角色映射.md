# 07. 管理面 SSO 配置（IdP 配置 + 组→角色映射）

> 状态：**已交付（P3.5，2026-10-11，见 §8 实现记录）**。
> 定位：补上管理面「企业 SSO 配置」能力——客户租户/平台管理员**自助配置 IdP 与 IdP 组→内部角色映射**（`gateway_tenant_idp_config` / `gateway_idp_group_mapping` 的管理 API + 管理台页面），当前这两张表只有 SQL seed 脚本维护。
> 依据：docs/03（SSO/JIT/组映射消费端）；docs/04 附录 A.5（平台级 IdP 接入状态）；docs/06（应用角色模板，组映射的 `target_role_id` 正好落在模板灌入的租户预置角色上）。

---

## 0. 阶段归属说明（P3.5：P3 管理面补充增量，非 P4）

- **docs/01 的 P4 = 「租户隔离激活（业务层）」**：parlant 业务按 tenantId 过滤 + IAM context snapshot 接口，依赖 **parlant 业务层改造**、有真实多租户才触发——**本方案不是 P4**。
- **本方案（P3.5）＝「管理面 SSO 配置」**：不依赖 parlant 业务层，是 P3 管理面的自然延伸（P3 只做了管理 API 基础，SSO 配置管理仍缺），作为 **P3 的补充增量**落地。
- 与 P4（租户隔离）**并列、互不阻塞**：本 P3.5 随时可做；P4 按需后置。docs/01 阶段编号不变（P4 仍是租户隔离激活）。

---

## 1. 背景与缺口

| 现状 | 问题 |
|---|---|
| `gateway_tenant_idp_config`（IdP 配置）+ `gateway_idp_group_mapping`（组→角色映射）已在 V3 落库，`OidcSsoService` 消费 | **没有任何管理 API**：controller 层无 IdP 相关端点 |
| 目前靠 `scripts/seed_sso_keycloak_dev.sql` 手动 SQL 插（kc-org-a） | 客户租户无法自助配 IdP / 改组映射，平台管理员成为运维瓶颈 |
| 现有 9 个 `iam:*` 权限点无 IdP 相关码 | 新增管理端点需要定权限点（新增 `iam:idp:*` 或复用） |

**闭环衔接**：组映射的 `target_role_id` 指向 `gateway_role`——正是 docs/06 模板灌入的租户内预置角色（AgentOperator / TenantAdmin / Viewer）。租户管理员配「企业组 → 本租户角色」时，下拉选的就是这些角色，SSO 登录 JIT 即按映射授角色。

---

## 2. 范围决策

| 项 | 是否做 | 说明 |
|---|---|---|
| **IdP 配置管理**（`gateway_tenant_idp_config` CRUD：租户级 + 平台级） | ✅ 做 | 建/改/停用 IdP 连接（protocol/provider_key/issuer/jwks/client/claim 映射），租户级走租户作用域校验（复用 docs/06 `TenantScopeGuard`），平台级（`tenant_id='PLATFORM'`）仅平台管理员 |
| **组→角色映射管理**（`gateway_idp_group_mapping` CRUD） | ✅ 做 | 某 IdP 下的组映射列表 + 增删改（EXACT/REGEX、match_value、target_role_id、priority、启停），`target_role_id` 只允许选目标租户内的角色 |
| **前端「SSO/IdP 配置」页** | ✅ 做 | docs/05 管理台新增页面：IdP 列表/表单 + 组映射子表；两级管理员视图（平台级 IdP 仅平台管理员可见） |
| **权限点** | ✅ 做 | 新增 `iam:idp:read` / `iam:idp:write`（与业务 9 码、管理 9 码并列；平台级 IdP 的写操作再叠加平台管理员校验） |
| **应用模板管理（`iam_application` / `iam_application_role_template` 增删改）** | ❌ **本方案不实现** | 原因：① 应用接入低频（当前仅 parlant 一个，新增应用 = 插数据零改代码，docs/06 §5.3 已满足）；② 属平台配置/运营层，SQL/脚本可维护，进日常管理台收益低；③ 避免为"低频配置"引入一套 CRUD + 权限 + 页面。**如未来应用变多再评估**：加「应用管理」页 + `iam:app:*` 权限点（列为后续候选，不进本方案） |
| 审计 | ✅ 沿用 | IdP/组映射变更写 `gateway_audit_log`（docs/04 已就绪） |

---

## 3. 后端 API 设计（已实现）

权限点：`iam:idp:read` / `iam:idp:write`（新增，见 §4）。

### 3.1 IdP 配置
```
GET    /api/v1/admin/idp-configs?tenant_id={tenantId}      # 列某租户 IdP（仅平台管理员，平台级 tenant_id=PLATFORM）
POST   /api/v1/admin/idp-configs                           # 建 IdP（含 client_secret 明文入参 → 存 client_secret_cipher）
GET    /api/v1/admin/idp-configs/{idpConfigId}
PUT    /api/v1/admin/idp-configs/{idpConfigId}             # 更新（secret 留空则不变）
DELETE /api/v1/admin/idp-configs/{idpConfigId}             # 停用（逻辑删除）
```

### 3.2 组→角色映射（挂某 IdP 下）
```
GET    /api/v1/admin/idp-configs/{idpConfigId}/group-mappings
POST   /api/v1/admin/idp-configs/{idpConfigId}/group-mappings   # body: match_mode/match_value/target_role_id/priority
PUT    /api/v1/admin/idp-configs/{idpConfigId}/group-mappings/{mappingId}
DELETE /api/v1/admin/idp-configs/{idpConfigId}/group-mappings/{mappingId}
```

- 作用域：`target_role_id` 必须属于该 IdP 目标租户（目标租户 = 租户级作用域校验），防把角色映射到别的租户。
- `client_secret_cipher`：沿用现有密文列，接口回显脱敏（只显示是否有值，不回明文）。
- `OidcSsoService` 消费端**不改**（读表逻辑已就绪），本方案只加写端。

---

## 4. 权限点（已实现）

- 新增 2 码：`iam:idp:read` / `iam:idp:write`（`PermissionCodes` + `gateway_permission` seed，**V7 迁移**）。
- **决策：仅授平台管理员**（V7 绑定 r-2001 PlatformAdmin），**不授租户 TenantAdmin**——IdP 配置属平台管控，租户侧暂不开放自助配置。
- 平台级 IdP（`tenant_id='PLATFORM'`）读写：`iam:idp:*` 已限定平台管理员（无租户级持有者，无需再叠加 `assertPlatformAdmin`；若未来开放租户级 `iam:idp:*`，再补 `TenantScopeGuard` 作用域）。

---

## 5. 前端页面（docs/05 增补）

- 管理台新增「SSO 配置」导航（`iam:idp:read` 显隐，docs/05 §7.2）：
  - **IdP 列表/表单**：provider/issuer/client/域名策略/join_policy/pkce/JIT/邮箱验证；secret 只写不读（`has_secret`）。
  - **组映射子表**（IdP 行展开）：映射 CRUD；`target_role_id` 下拉选目标租户内角色（`GET /admin/roles`，即 docs/06 预置角色）。
- 平台管理员操作任意租户（Header 租户选择器选定目标）；租户管理员**无 `iam:idp:*`，不显示入口**（当前按决策仅平台开放）。

---

## 6. 里程碑与依赖（已完成）

1. **B1 后端**（✅）：V7 迁移（`iam:idp:*` 权限点 seed + PlatformAdmin 绑定）+ IdP/组映射管理 API + `target_role_id` 租户内校验 + 重复配置/映射 → 400 + 审计 + 集成测试 `P3IdpConfigIntegrationTest`（CRUD / secret 脱敏 / 越权 403 / 重复 400）。
2. **B2 前端**（✅）：platform-iam-web「SSO 配置」页（IdP 表单 + 组映射子表）接入。
3. 依赖：docs/06 `TenantScopeGuard`（已交付）；docs/04 审计（已交付）。**不依赖 parlant 业务层**。

---

## 7. 明确不实现项（本方案范围外）

- **应用模板管理**（`iam_application` / `iam_application_role_template` 增删改）：**本方案不实现**。当前新增应用 = 插数据零改代码（docs/06 §5.3），低频、属平台配置层，SQL/脚本可维护；若未来应用增多再评估「应用管理」页（`iam:app:*` 权限点 + CRUD），列为后续候选。
- **租户隔离激活（docs/01 P4）**：parlant 业务层 tenantId 过滤，依赖 parlant，另行按需。

---

## 8. 实现记录（2026-10-11 交付）

### 8.1 已实现
- **V7 迁移**：`iam:idp:read/write` 2 码 + PlatformAdmin（r-2001）绑定（rp-5010/5011）。
- **后端**：`AdminIdpController` + `AdminIdpService`（IdP 配置与组映射 CRUD，平台管理员专属）；`IdpConfigRepository`/`IdpGroupMappingRepository` 补 CRUD；`target_role_id` 限目标租户内角色（平台级 IdP → PLATFORM 角色）；重复配置/映射（唯一键冲突）→ **400**（非 500）；secret 回显仅 `has_secret`。
- **前端**：platform-iam-web「SSO 配置」页（`/admin/sso-config`，`iam:idp:read` 守卫）+ 侧导航项。
- **测试**：`P3IdpConfigIntegrationTest`（3 用例）；全量 98 通过。

### 8.2 决策记录
- **`iam:idp:*` 仅授平台管理员**（V7），不授租户 TenantAdmin——IdP 配置归平台管控。
- **`client_secret_cipher` 暂不加密**：当前 DEV 明文直存（沿用 seed 的 `DEV_ONLY:` 占位语义），**加密为待办**——生产上线前须引入对称加密（AES-GCM）落库 + 验签时解密，并同步 CLAUDE.md 安全约束。

### 8.3 待办
- [ ] `client_secret_cipher` 加密（AES-GCM，密钥派生自 `IAM_JWT_PRIVATE_KEY_PATH` 或新增配置）；生产必须。
- [ ] 平台级 IdP（`tenant_id=PLATFORM`，Google/MSA）UI 入口（当前 API 支持，前端仅管租户级；待 docs/04 A.5 平台 IdP 配置后补）。
- [x] **角色变更后的重新校验（无状态 JWT 吊销/新鲜度）**——parlant 等业务方本地 JWKS 验签，IAM 改了角色不即时生效。分级方案（a/b 已落地，c 的 IAM 侧已落地）：
  - [x] **a. 缩短 TTL**：`iam.jwt.ttl-seconds` 已 1800（30min），角色变更最长在 TTL 内自动生效。
  - [x] **b. 静默刷新**：IAM 侧已交付——`OidcController.callback` 302 回跳携带 `refresh_token`、hub `Login.tsx` 外跳转发（`finishLogin(token, refreshToken)`，SSO+本地两路径）；parlant 侧已实施（parlant doc11 附录 A）。401 → parlant 调 `/auth/refresh` 换带当前角色的新 token 重试，失败才重登。
  - [x] **c. 即时吊销（token version，IAM 侧已实施 V10）**：`gateway_membership.token_version`（角色/权限/成员移除时 bump）+ `gateway_membership_version_log` 变更日志 + 版本 feed `GET /api/v1/auth/versions?since=&app_code=`（`X-IAM-Service-Token` 鉴权、app 作用域、增量游标、tombstone 哨兵 `version:-1`）；JWT 增 `ver` claim（签发时快照）。**parlant 侧待实施**（缓存 feed + 请求时比较，parlant doc11 附录 B）——bump 点：成员角色替换/审批、角色权限变更（批量持有者）、IdP 组映射同步（变化才 bump）、成员移除（tombstone）。

---

## 9. 相关文档

- docs/03：SSO/JIT/组映射消费端（本方案只加管理写端）
- docs/04：P3 管理面与账号生命周期（附录 A.5 平台级 IdP 接入状态）；审计就绪
- docs/06：应用角色模板与租户级管理面（`TenantScopeGuard`；`target_role_id` 衔接预置角色）
- docs/05：管理台（本方案为其中「SSO/IdP 配置」页的实现方案）

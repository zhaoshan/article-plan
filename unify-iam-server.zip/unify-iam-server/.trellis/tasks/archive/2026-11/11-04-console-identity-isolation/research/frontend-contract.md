> Closed on 2026-11-04 before implementation. The user explicitly narrowed the request to frontend-only work: no backend logic or seed changes. All backend proposals below are withdrawn historical planning, not an approved or implemented API contract. No implementation approval is requested.

# Frontend identity contract

## Existing verified interfaces
All `/api/v1/**` responses use `{success, code, message, data}` and real HTTP status codes.

- `POST /api/v1/auth/token`: login result includes `data.access_token`, `data.user.roles`, `data.user.permissions` (TokenUser uses explicit JSON properties).
- `GET /api/v1/auth/me`: canonical current authenticated projection exposes `data.userId`, `data.userName`, `data.tenantId`, `data.membershipId`, `data.roles` (string[]), `data.permissions` (string[]), `data.attrs` and own profile fields. Role strings are role codes, not display names. Fields in this response are camelCase.
- JWT payload has `sub`, `tenantId`, `membershipId`, `roles`, `permissions`; validate authentication with the server. The current token covers one membership, not every tenant of the account.
- `GET /api/v1/auth/memberships`: `data.memberships[]` includes snake_case `membership_id`, `tenant_id`, `tenant_name`, `tenant_code`, `tenant_type`, `membership_status`, roles, `is_owner`, `is_current`, timestamps; response includes count. This is a self-service list, not a management permission grant.
- `POST /api/v1/auth/switch-tenant` body `{membership_id: "..."}` returns a replacement login/access+refresh result. Update session then refetch /me and recompute identity; do not union old/new role arrays.

## Exact rule confirmed by user
```ts
const roles = me.roles ?? [];
const identity = roles.includes('PlatformAdmin') ? 'PLATFORM_ADMIN'
  : roles.includes('iMorph-Owner') || roles.includes('iMorph-Admin') ? 'TENANT_ADMIN'
  : 'MEMBER';
```
Case-sensitive exact code matching. PlatformAdmin wins mixed-role arrays. No includes-substring, generic PLATFORM scope, permissions prefix, tenant_type, is_owner flag, template is_admin, tenant owner user ID, or historical TenantAdmin fallback.

| Identity | Menu / direct page access | Console tenant selector |
| --- | --- | --- |
| PLATFORM_ADMIN | My identity, Tenants, Roles, Audit | hidden |
| TENANT_ADMIN | My identity, Members, Apps | visible |
| MEMBER | My identity | hidden |

All unrelated direct page entries show no permission. Server 403 must also show no permission; hiding a menu is insufficient. Treat permission codes only as additional operation constraints where existing server handlers retain them; they cannot grant a page to another identity.

## Proposed server changes awaiting planning approval
- `/admin/roles` and `/admin/permissions` become platform-only. B-side member role options use proposed `/admin/members/assignable-roles?tenant_id=<data.tenantId>`.
- `/admin/members` uses `scope_type=TENANT&scope_id=<data.tenantId>`; PLATFORM search is forbidden. Member mutation IDs must belong to the current tenant.
- `/admin/applications` becomes B-side Apps catalog. Platform Tenants creation uses proposed `/admin/tenants/application-catalog` instead.
- `/admin/tenants/{id}/applications` remains shared role reference data under explicit platform/B-side scope checks; it is not page entry authorization.
- No new application create/update/delete endpoint exists or is proposed; current implementation provides catalog/usage reads.
- `/auth/app-access` and login-target `is_platform_admin` currently inspect ANY active user membership's PLATFORM scope; do not use them as the console identity source. Business login routing has a separate contract and is outside this console bugfix.

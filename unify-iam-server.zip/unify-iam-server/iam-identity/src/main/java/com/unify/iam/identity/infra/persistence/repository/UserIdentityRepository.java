package com.unify.iam.identity.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.unify.iam.identity.common.constant.IdentityProviderType;
import com.unify.iam.identity.infra.persistence.mapper.UserIdentityMapper;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/**
 * 用户身份仓储。E2E-1 只查询本地密码身份（LOCAL/password/ACTIVE）。
 */
@Repository
public class UserIdentityRepository {

    private final UserIdentityMapper userIdentityMapper;

    public UserIdentityRepository(UserIdentityMapper userIdentityMapper) {
        this.userIdentityMapper = userIdentityMapper;
    }

    /** 查询用户的本地密码身份（ACTIVE 且未逻辑删除）。 */
    public Optional<UserIdentityPO> findLocalActive(String userId) {
        return Optional.ofNullable(userIdentityMapper.selectOne(new LambdaQueryWrapper<UserIdentityPO>()
                        .eq(UserIdentityPO::getUserId, userId)
                        .eq(UserIdentityPO::getProviderType, IdentityProviderType.LOCAL.name())
                        .eq(UserIdentityPO::getProviderKey, "password")
                        .eq(UserIdentityPO::getIdentityStatus, "ACTIVE")))
                .map(this::trimBizKeys);
    }

    /** 按 IdP 三元组查身份（OIDC/SAML）：provider + issuer + subject。 */
    public Optional<UserIdentityPO> findByProvider(String providerType, String providerKey,
                                                   String issuer, String subject) {
        return Optional.ofNullable(userIdentityMapper.selectOne(new LambdaQueryWrapper<UserIdentityPO>()
                        .eq(UserIdentityPO::getProviderType, providerType)
                        .eq(UserIdentityPO::getProviderKey, providerKey)
                        .eq(UserIdentityPO::getIssuer, issuer)
                        .eq(UserIdentityPO::getSubject, subject)))
                .map(this::trimBizKeys);
    }

    /** 用户是否有 ACTIVE 的 OIDC 身份（G8 auth_mode 判定：sso 依据）。 */
    public boolean existsOidcActive(String userId) {
        return userIdentityMapper.selectCount(new LambdaQueryWrapper<UserIdentityPO>()
                .eq(UserIdentityPO::getUserId, userId)
                .eq(UserIdentityPO::getProviderType, IdentityProviderType.OIDC.name())
                .eq(UserIdentityPO::getIdentityStatus, "ACTIVE")) > 0;
    }

    /** 新建身份（JIT 用）；唯一键 (provider_type, provider_key, issuer, subject) 冲突视为已存在。 */
    public boolean create(UserIdentityPO po) {
        try {
            return userIdentityMapper.insert(po) > 0;
        } catch (org.springframework.dao.DuplicateKeyException e) {
            return false;
        }
    }

    /** 刷新既有身份的 claims 快照与 IdP 侧邮箱（JIT 每次登录更新，保证 claims_json 反映最新登录）。 */
    public void refreshClaims(String userIdentityId, String claimsJson, String emailAtIdp) {
        userIdentityMapper.update(null, new LambdaUpdateWrapper<UserIdentityPO>()
                .eq(UserIdentityPO::getUserIdentityId, userIdentityId)
                .set(UserIdentityPO::getClaimsJson, claimsJson)
                .set(UserIdentityPO::getEmailAtIdp, emailAtIdp)
                .set(UserIdentityPO::getLastLoginAt, java.time.LocalDateTime.now()));
    }

    private UserIdentityPO trimBizKeys(UserIdentityPO po) {
        if (po.getUserIdentityId() != null) {
            po.setUserIdentityId(po.getUserIdentityId().trim());
        }
        if (po.getUserId() != null) {
            po.setUserId(po.getUserId().trim());
        }
        return po;
    }
}

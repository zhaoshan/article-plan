package com.unify.iam.app.security;

import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.ErrorCode;
import java.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * Redis 登录限流器（{@code iam.redis.enabled=true} 时装配，多副本共享计数）。
 *
 * <p>Key 结构（防跨应用/跨环境冲突，固定 4 段）：<pre>{@code
 *   {env}:iam:login:rl:acct:{account}       账号锁（value="1"，TTL=lock-seconds）
 *   {env}:iam:login:rl:acct:{account}:fail  账号连续失败计数（TTL=lock-seconds 近似「连续」窗口）
 *   {env}:iam:login:rl:ip:{ip}              IP 锁（value="1"，TTL=ip-lock-seconds）
 *   {env}:iam:login:rl:ip:{ip}:fail         IP 窗口失败计数（TTL=ip-window-seconds，固定窗口近似滑动窗口）
 * }</pre>
 * 例：{@code uat:iam:login:rl:acct:alice@corp.com}。env 段隔离多环境共享实例；{@code iam} 段
 * 隔离同实例上的其它应用；{@code login:rl} 段隔离本应用的其它 Redis 用途。
 *
 * <p>Fail-safe：Redis 任何故障一律降级——{@link #assertNotLocked} 放行（不阻断登录主链路）、
 * 计数静默丢弃，WARN 留痕。登录为低频路径，分步命令的微小竞态（计数略偏）可接受，不用 Lua。
 */
@Component
@ConditionalOnProperty(prefix = "iam.redis", name = "enabled", havingValue = "true")
public class RedisLoginRateLimiter implements LoginRateLimiter {

    private static final Logger log = LoggerFactory.getLogger(RedisLoginRateLimiter.class);

    private final IamProperties props;
    private final StringRedisTemplate redis;
    private final String keyPrefix;

    public RedisLoginRateLimiter(IamProperties props,
                                 @Qualifier("iamRedisTemplate") StringRedisTemplate redis) {
        this.props = props;
        this.redis = redis;
        String env = props.getRedis().getEnv() == null || props.getRedis().getEnv().isBlank()
                ? "default" : props.getRedis().getEnv().trim().toLowerCase();
        this.keyPrefix = env + ":iam:login:rl:";
    }

    @Override
    public void assertNotLocked(String username, String ip) {
        IamProperties.LoginRateLimit cfg = props.getLoginRateLimit();
        if (!cfg.isEnabled()) {
            return;
        }
        try {
            if (Boolean.TRUE.equals(redis.hasKey(lockKey("acct", normalize(username))))) {
                log.warn("login rate limited | dimension=ACCOUNT | key={}（redis）", normalize(username));
                throw AuthException.tooManyRequests(ErrorCode.LOGIN_LOCKED);
            }
            if (Boolean.TRUE.equals(redis.hasKey(lockKey("ip", ip)))) {
                log.warn("login rate limited | dimension=IP | key={}（redis）", ip);
                throw AuthException.tooManyRequests(ErrorCode.LOGIN_LOCKED);
            }
        } catch (AuthException e) {
            throw e;
        } catch (RuntimeException e) {
            log.warn("redis rate-limit check failed, degrade to pass | reason={}", e.toString());
        }
    }

    @Override
    public void recordFailure(String username, String ip) {
        IamProperties.LoginRateLimit cfg = props.getLoginRateLimit();
        if (!cfg.isEnabled()) {
            return;
        }
        try {
            boolean accountLocked = incrementAndMaybeLock(
                    failKey("acct", normalize(username)), lockKey("acct", normalize(username)),
                    cfg.getMaxFailures(), cfg.getLockSeconds());
            if (accountLocked) {
                log.warn("login failure threshold reached | dimension=ACCOUNT | key={} | lockedSeconds={}（redis）",
                        normalize(username), cfg.getLockSeconds());
            }
            boolean ipLocked = incrementAndMaybeLock(
                    failKey("ip", ip), lockKey("ip", ip),
                    cfg.getIpMaxFailures(), cfg.getIpLockSeconds());
            if (ipLocked) {
                log.warn("login failure threshold reached | dimension=IP | key={} | lockedSeconds={}（redis）",
                        ip, cfg.getIpLockSeconds());
            }
        } catch (RuntimeException e) {
            log.warn("redis rate-limit record failed, skipped | reason={}", e.toString());
        }
    }

    @Override
    public void recordSuccess(String username, String ip) {
        try {
            redis.delete(java.util.List.of(failKey("acct", normalize(username)), lockKey("acct", normalize(username)),
                    failKey("ip", ip), lockKey("ip", ip)));
        } catch (RuntimeException e) {
            log.warn("redis rate-limit reset failed, skipped | reason={}", e.toString());
        }
    }

    /**
     * 失败计数 +1（首增设窗口 TTL）；达阈值 → 置锁（TTL=锁时长）并清计数。
     * @return 本次失败是否触发锁定
     */
    private boolean incrementAndMaybeLock(String failKey, String lockKey, int maxFailures, long lockSeconds) {
        Long count = redis.opsForValue().increment(failKey);
        if (count != null && count == 1L) {
            redis.expire(failKey, Duration.ofSeconds(Math.max(lockSeconds, 60)));
        }
        if (count != null && count >= maxFailures) {
            redis.opsForValue().set(lockKey, "1", Duration.ofSeconds(lockSeconds));
            redis.delete(failKey);
            return true;
        }
        return false;
    }

    private String lockKey(String dimension, String key) {
        return keyPrefix + dimension + ":" + key;
    }

    private String failKey(String dimension, String key) {
        return keyPrefix + dimension + ":" + key + ":fail";
    }

    /** 规范化登录名：null 安全、trim、小写（避免大小写变体绕过计数）。 */
    private static String normalize(String username) {
        return username == null ? "" : username.trim().toLowerCase();
    }
}

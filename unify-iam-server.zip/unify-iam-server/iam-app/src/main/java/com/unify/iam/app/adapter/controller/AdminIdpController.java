package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.GroupMappingRequest;
import com.unify.iam.api.dto.admin.IdpConfigRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminIdpService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * IAM 管理面：SSO/IdP 配置管理（docs/07 §3，iam:idp:*，仅平台管理员）。
 *
 * <p>平台管理员管理任意租户（tenant_id 参数）或平台级（PLATFORM）IdP 及其组→角色映射。
 */
@RestController
@RequestMapping("/api/v1/admin/idp-configs")
public class AdminIdpController {

    private final AdminIdpService adminIdpService;
    private final AuditService auditService;

    public AdminIdpController(AdminIdpService adminIdpService, AuditService auditService) {
        this.adminIdpService = adminIdpService;
        this.auditService = auditService;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_IDP_READ)
    public Map<String, Object> list(@RequestParam(name = "tenant_id") String tenantId) {
        List<Map<String, Object>> configs = adminIdpService.listConfigs(tenantId.trim());
        return Map.of("idp_configs", configs, "count", configs.size());
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_IDP_WRITE)
    public Map<String, String> create(@Valid @RequestBody IdpConfigRequest request) {
        String configId = String.valueOf(adminIdpService.createConfig(request).get("idp_config_id"));
        auditService.audit().event("ADMIN_CREATE_IDP_CONFIG").actor(CurrentAuth.claims().userId())
                .target("IDP_CONFIG", configId).result("SUCCESS")
                .write(Map.of("tenant_id", request.tenantId() == null ? "PLATFORM" : request.tenantId()));
        return Map.of("idp_config_id", configId);
    }

    @PutMapping("/{configId}")
    @RequirePermission(PermissionCodes.IAM_IDP_WRITE)
    public Map<String, String> update(@PathVariable String configId,
                                      @Valid @RequestBody IdpConfigRequest request) {
        adminIdpService.updateConfig(configId, request);
        auditService.audit().event("ADMIN_UPDATE_IDP_CONFIG").actor(CurrentAuth.claims().userId())
                .target("IDP_CONFIG", configId).result("SUCCESS").write(null);
        return Map.of("idp_config_id", configId);
    }

    @DeleteMapping("/{configId}")
    @RequirePermission(PermissionCodes.IAM_IDP_WRITE)
    public Map<String, String> delete(@PathVariable String configId) {
        adminIdpService.deleteConfig(configId);
        auditService.audit().event("ADMIN_DELETE_IDP_CONFIG").actor(CurrentAuth.claims().userId())
                .target("IDP_CONFIG", configId).result("SUCCESS").write(null);
        return Map.of("idp_config_id", configId);
    }

    @GetMapping("/{configId}/group-mappings")
    @RequirePermission(PermissionCodes.IAM_IDP_READ)
    public Map<String, Object> listMappings(@PathVariable String configId) {
        List<Map<String, String>> mappings = adminIdpService.listMappings(configId);
        return Map.of("group_mappings", mappings, "count", mappings.size());
    }

    @PostMapping("/{configId}/group-mappings")
    @RequirePermission(PermissionCodes.IAM_IDP_WRITE)
    public Map<String, String> createMapping(@PathVariable String configId,
                                             @Valid @RequestBody GroupMappingRequest request) {
        String mappingId = adminIdpService.createMapping(configId, request).get("mapping_id");
        auditService.audit().event("ADMIN_CREATE_GROUP_MAPPING").actor(CurrentAuth.claims().userId())
                .target("IDP_GROUP_MAPPING", mappingId).result("SUCCESS")
                .write(Map.of("idp_config_id", configId));
        return Map.of("mapping_id", mappingId);
    }

    @PutMapping("/{configId}/group-mappings/{mappingId}")
    @RequirePermission(PermissionCodes.IAM_IDP_WRITE)
    public Map<String, String> updateMapping(@PathVariable String configId,
                                             @PathVariable String mappingId,
                                             @Valid @RequestBody GroupMappingRequest request) {
        adminIdpService.updateMapping(configId, mappingId, request);
        auditService.audit().event("ADMIN_UPDATE_GROUP_MAPPING").actor(CurrentAuth.claims().userId())
                .target("GROUP_MAPPING", mappingId).write(Map.of("config_id", configId));
        return Map.of("mapping_id", mappingId);
    }

    @DeleteMapping("/{configId}/group-mappings/{mappingId}")
    @RequirePermission(PermissionCodes.IAM_IDP_WRITE)
    public Map<String, String> deleteMapping(@PathVariable String configId,
                                             @PathVariable String mappingId) {
        adminIdpService.deleteMapping(configId, mappingId);
        auditService.audit().event("ADMIN_DELETE_GROUP_MAPPING").actor(CurrentAuth.claims().userId())
                .target("GROUP_MAPPING", mappingId).write(Map.of("config_id", configId));
        return Map.of("mapping_id", mappingId);
    }
}

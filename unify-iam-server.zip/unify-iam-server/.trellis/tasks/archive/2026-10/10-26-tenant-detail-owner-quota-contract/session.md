# Session record

## 2026-10-26: discovery and implementation start

- Task source: delegated tenant-detail backend request in the current `platform-iam-service` main worktree. Frontend implementation and `.pen` modification are explicitly out of scope for this checkout.
- Starting Git state: branch `feature/v0.10.3-m10w3` already contained unrelated source, documentation, test, and `.trellis/` changes. They are preserved and not reverted.
- Required instruction discovery: hidden-path searches found no `AGENTS.md` and no `.trellis/workflow.md` in this worktree. The actual `CLAUDE.md` and `.claude/rules/security.md` were read. They require additive Flyway migrations, uniform API envelopes, explicit management authorization, scoped tenant operations, and no automatic commits.
- Existing platform tenant creation defaults to `ORGANIZATION` but accepts an explicit `PERSONAL`; this will be closed so platform creation is enterprise-only. Self-service registration and consumer SSO remain unchanged personal-tenant paths.
- There is no quota storage. `gateway_membership`, `gateway_invitation`, and `iam_tenant_application` are the only authoritative IAM sources for Members/Apps usage. The task will not turn the design's sample limits into fake product limits.
- Owner data is represented by `gateway_tenant.owner_user_id`; membership and owner-template roles are authoritative for current access. Existing roles of the former owner will be retained on transfer until a product policy explicitly authorizes demotion/removal.
- Existing invitation persistence stores a token hash but has no mail transport or configured accepting URL. The implementation will require a real configured sender before it creates an owner-transfer email invitation, rather than emitting a token or claiming an email was sent.
- No migration, branch/worktree operation, commit, merge, push, checkout, or reset has been performed.

## 2026-10-26: implementation and validation complete

- Added V12 with `gateway_quota_dimension`, `gateway_tenant_quota`, and purpose/delivery fields on invitations. Platform bootstrap creates only the IAM `members` and `apps` dimension definitions, both with `default_limit=NULL`; no visual sample quota was introduced as production data.
- Added the aggregate `GET /api/v1/admin/tenants/{tenantId}/details` projection with base tenant, resolvable owner, applications, paged members, and real Usage. It requires tenant and member read authority and checks tenant scope.
- Management tenant creation now canonicalizes to `ORGANIZATION`, rejects `PERSONAL`, persists an optional `owner_user_id` before creating the first membership, and rejects unapproved status values outside `ACTIVE`/`DISABLED`.
- Added quota set/reset actions and enforcement at direct-member and invitation creation. Members usage includes active/pending membership rows plus unexpired pending invitations; Apps usage comes from actual tenant/application rows. Tenant-row locking prevents concurrent finite-seat oversubscription.
- Added direct Owner transfer and a purpose-aware accepted Owner invitation flow. The target receives current owner-template roles without stripping existing roles; the former Owner retains current membership/roles pending an explicit product demotion policy. Each transfer bumps the promoted membership's token version and emits a dedicated audit event.
- Added optional SMTP delivery for Owner email invites. Delivery requires an enabled feature flag, a JavaMail sender, sender address, and tokenized accepting URL. If any is absent, the endpoint returns 503 before generating/persisting an invitation. The raw token is never logged, returned, audited, or stored; existing development member invites now audit `invitation_id` instead of the raw token.
- Updated the API manual with all request/response, authorization, quota and mail-delivery semantics. No frontend source or `.pen` file was accessed or changed.
- Validation: `TenantDetailOwnerQuotaIntegrationTest` (5 passed), `OwnerInvitationMailServiceTest` (1 passed), and the existing `P3TenantInitIntegrationTest`, `P3AdminCrudIntegrationTest`, and `AdminProtectionIntegrationTest` regression set (33 passed combined). `git diff --check` passed.
- No migration was edited after execution; no branch/worktree operation, commit, merge, push, checkout, or reset occurred.

# 前端直接接入契约（2026-10-27）

本任务只实施 platform-iam-service 后端；Change Owner tabs 高度/上下间距、成员卡 max-height/overflow 由前端主任务实施。

## 查询与提交

```http
GET /api/v1/admin/members?tenant_id=<tenantId>&keyword=<URL编码搜索词>&owner_candidates=true&limit=1000
Authorization: Bearer <token>
```

- `tenant_id` 必填、去空白；`keyword` 可选、去空白，空串不限资料；`owner_candidates` 默认 false；`limit` 默认1000，整数1..1000，越界400。
- keyword 按数据库排序规则，对真实 display_name/full_name/username/primary_email 做任一字段的包含匹配；不按ID查，不调用全局用户目录；`%/_/!` 为字面值，绑定参数防注入。
- 需要 `iam:member:read` + 目标租户作用域，不需要 `iam:user:read` 或 `iam:tenant:read`。平台级角色可选择任意存在的目标租户；租户级 token 只能选本租户。
- 成功信封 `{success,code,message,data}`；数据如下。数据库先过滤，再 `gateway_membership.id ASC LIMIT`，无分页、无 OFFSET。total 为过滤后截断前真实数量，count 为本次返回数量。

```ts
type Role = { role_id: string; role_code: string; role_name: string }
type MemberProjection = {
  membership_id: string
  user_id: string
  user_available: boolean
  username?: string
  full_name?: string
  display_name?: string
  email?: string
  user_status?: string
  owner_eligible: boolean
  membership_status: string
  is_owner: boolean
  join_source?: string
  roles: Role[]
}
type MemberSearchItem = MemberProjection & { tenant_id: string; is_default: '0' | '1' }
type SearchData = {
  members: MemberSearchItem[]
  count: number
  tenant_type: string
  total: number
  limit: number // 默认1000，1..1000
  truncated: boolean // total > count
}
// 详情同源：data.members.items[] 为 MemberProjection & {is_default:boolean}
// 详情外层仍为 members:{items,total,limit:1000,truncated}，不分页。
```

候选条件：成员未逻辑删除、目标租户内、membership_status 严格为 ACTIVE、用户存在且未逻辑删除、user_status 严格为 ACTIVE、user_id != gateway_tenant.owner_user_id。无Owner时不排除首成员。所有返回候选 owner_eligible=true，用户可能没有全名/昵称/邮箱，但真实username仍可展示。

未设置 owner_candidates 或设 false 时，不按状态/有效性隐式丢弃关系；无 keyword 时保留用户缺失/已删除的关系，其 user_available=false、owner_eligible=false，username/full_name/display_name/email/user_status 省略。不存在/删除用户绝不以user_id填username。非空keyword只匹配未删除用户真实资料，因此 unavailable 不命中。未删除但停用用户仍 user_available=true，user_status 为真实值，owner_eligible=false。

标签按非空 display_name → full_name → username → email；unavailable 显示“用户不可用”，ID仅作辅助信息。Owner 标签只用 is_owner，不用首成员/角色猜测。

详情 truncated=false 时，可以直接在详情 items 里过滤 owner_eligible===true 作为本地候选；若截断或远程模糊搜索，使用上述查询。它会在全体目标租户关系中先筛选再取上限，能查到详情第1001条之后的有效用户。两处复用 TenantMemberProjectionService，姓名/邮箱/角色保持一致。

```http
POST /api/v1/admin/tenants/<tenantId>/owner
Authorization: Bearer <token>
Content-Type: application/json

{"mode":"EXISTING_MEMBER","membership_id":"<选中候选的membership_id>"}
```

需要 `iam:tenant:write` + `iam:member:write` + 目标租户作用域。后端再次校验目标租户、有效 ACTIVE 成员和真实未删除 ACTIVE 用户、非当前Owner。不能传 user_id。不存在成员404，其余无效目标400。成功 data 仍为 `{tenant_id,status:"OWNER_CHANGED",owner_user_id,membership_id}`。拒绝时不会写Owner/角色/token_version/成功审计。

401=未登录；403=权限或租户作用域不足；400=缺少/空白tenant_id、参数类型错误、limit越界；404=有权限但租户不存在/已删除。全局错误仍套统一信封。

## 截图ID的确切证据与边界

仅本项目业务库定向只读 JOIN，事务 READ ONLY，无业务写入：

| 字段 | 当前数据库结果 |
|---|---|
| 截图user_id | 47a0408e815c4c7487d27d1992ae6db1 |
| membership_id | 8dd7fcb005d7422a8cc41f01572768a1 |
| tenant_id / tenant_code | afe7ab11f6894941b40abc6128212f60 / imorph_admin_02 |
| 关系/租户 | ACTIVE成员、关系及租户delete_flag=0 |
| 用户 | 主表存在；delete_flag=1；user_status=DISABLED |
| 可读资料残留 | username和primary_email非空；full_name/display_name为NULL |
| 当前owner_user_id | NULL，当前详情is_owner应false |

所以它不是“从未有可读资料”的用户，而是“用户已删除，资料不能作为可用身份返回”。旧成员接口 findByIds 排除删除用户，随后 getOrDefault(user_id,user_id) 把ID伪装成username，能直接解释数字标签的生成机制。详情原投影会正确给 user_available=false；不能由此断言截图一定来自旧成员接口，前端亦可能自己按user_id回退。

运行服务审计见 runtime-audit.json：PID83256，17:19:09启动；构建前磁盘JAR哈希与既有运行记录一致。该JAR详情类已有full_name/display_name/email/user_available及无分页查询，旧成员Controller无这些字段/keyword。这证实运行产物两个路径的字段差异，而非简单“服务未更新所以无所有姓名字段”。没有现成授权Bearer；本任务未登录写会话、读取私钥签token或重启服务，因此未取得已认证运行响应，不能精确还原截图时刻HTTP/前端映射。新包已构建，运行进程未重启，不代表新契约已在线生效。

没有删除历史成员关系、恢复删除用户或伪造资料。新隔离MySQL回归使用截图同一user_id模拟逻辑删除，验证列表和详情一致保留unavailable而不返回残留身份字段。

"""页面链接提取器（从 scripts/deep_crawl_nested_links.py 提取）"""

import logging
from playwright.async_api import Page

logger = logging.getLogger(__name__)


async def extract_links_from_page(page: Page, base_url: str) -> list[str]:
    """
    从当前页面通过 JS 提取所有链接。

    Args:
        page: Playwright 页面对象
        base_url: 当前页面 URL，用于转换相对链接

    Returns:
        list[str]: 绝对链接列表
    """
    js_code = """
    (() => {
      const collectedLinks = [];
      const seen = new Set();

      for (let i = 0; i < document.links.length; i++) {
        const link = document.links[i];
        if (link.href && link.href.trim()) {
          const href = link.href.trim();
          if (!href.startsWith('javascript:') && !href.startsWith('mailto:') && !href.startsWith('tel:')) {
            if (!seen.has(href)) {
              seen.add(href);
              collectedLinks.push(href);
            }
          }
        }
      }

      console.log('提取到的链接总数：' + collectedLinks.length);
      return collectedLinks;
    })();
    """

    try:
        link_elements: list[str] = await page.evaluate(js_code)
        from src.utils.url_utils import is_valid_url, resolve_url

        absolute_links = []
        for href in link_elements:
            if is_valid_url(href):
                absolute_links.append(href)
            else:
                absolute_links.append(resolve_url(base_url, href))

        logger.info(f"从页面提取到 {len(absolute_links)} 个有效链接")
        return absolute_links
    except Exception as e:
        logger.error(f"提取页面链接失败：{e}")
        return []


async def extract_page_text(page: Page) -> str:
    """
    提取页面 body 的可见文本内容。

    通过 JS 获取 document.body.innerText，用于页面内容匹配判定
    （如检测 not_found_texts 配置的"未找到"文本）。

    Args:
        page: Playwright 页面对象

    Returns:
        str: 页面 body 的 innerText，失败或为空时返回空字符串
    """
    try:
        text: str = await page.evaluate("() => document.body?.innerText || ''")
        return text
    except Exception as e:
        logger.error(f"提取页面文本失败：{e}")
        return ""

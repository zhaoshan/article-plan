package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 令牌响应：{@code access_token} + 元信息 + 当前用户（P3 起含可选 {@code refresh_token}）。
 *
 * <p>{@code must_change_password}（G2）：初始密码账号首登强制改密标记，仅 true 时序列化透出
 * （全局 non_null），前端据此拦截跳改密页。
 */
public record LoginResponse(
        @JsonProperty("access_token") String accessToken,
        @JsonProperty("token_type") String tokenType,
        @JsonProperty("expires_in") Long expiresIn,
        TokenUser user,
        @JsonProperty("refresh_token") String refreshToken,
        @JsonProperty("refresh_expires_in") Long refreshExpiresIn,
        @JsonProperty("must_change_password") Boolean mustChangePassword) {

    /** 兼容便捷构造（无 refresh，向后兼容 E2E-1/2 调用方）。 */
    public static LoginResponse of(String accessToken, String tokenType, Long expiresIn, TokenUser user) {
        return new LoginResponse(accessToken, tokenType, expiresIn, user, null, null, null);
    }

    /** 返回同内容、透出首登改密标记的副本。 */
    public LoginResponse withMustChangePassword(Boolean flag) {
        return new LoginResponse(accessToken, tokenType, expiresIn, user, refreshToken, refreshExpiresIn, flag);
    }
}

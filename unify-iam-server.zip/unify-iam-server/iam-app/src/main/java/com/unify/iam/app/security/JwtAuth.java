package com.unify.iam.app.security;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.common.exception.AuthException;

/**
 * 从 Authorization header 解析并验签 Bearer 令牌（用于 /api/v1/auth/** 下需要认证的用户端点，
 * 如 switch-tenant / memberships / join-request；这些端点不在 /api/v1/admin/** 拦截器保护内）。
 */
public final class JwtAuth {

    private JwtAuth() {
    }

    /** 验签 Authorization header 中的 Bearer，返回 claims；缺失/无效 → 401。 */
    public static JwtClaims verify(JwtSigner jwtSigner, String authorization) {
        String token = extractBearer(authorization);
        if (token == null) {
            throw AuthException.unauthorized(ErrorCode.BEARER_REQUIRED);
        }
        return jwtSigner.verify(token);
    }

    public static String extractBearer(String authorization) {
        if (authorization == null || !authorization.regionMatches(true, 0, "bearer ", 0, 7)) {
            return null;
        }
        return authorization.substring(7).trim();
    }
}

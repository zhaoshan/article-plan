from pydantic import BaseModel
from typing import Any, Optional
from uuid import uuid4

class ResponseData(BaseModel):
    resultId: str | None = str(uuid4())
    result: list | None = []

class DefaultResult(BaseModel):
    code: str | None = "0000"
    message: str | None = "SUCCESS"
    data: Optional[Any] = None
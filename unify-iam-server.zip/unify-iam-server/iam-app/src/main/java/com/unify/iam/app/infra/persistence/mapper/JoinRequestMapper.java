package com.unify.iam.app.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.app.infra.persistence.po.JoinRequestPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_join_request Mapper。 */
@Mapper
public interface JoinRequestMapper extends BaseMapper<JoinRequestPO> {
}

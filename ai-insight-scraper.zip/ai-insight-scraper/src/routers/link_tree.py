"""链接树管理路由 — 增量同步、查询、验证（内部接口）

S3 支持：tree_file 为 s3:// 路径时，从 S3 下载后再同步。
鉴权：内部接口，请求头 Authorization: Bearer <internal_token>
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query

from src.boundaries.s3_boundary import S3Boundary
from src.config.system_config import load_s3_config
from src.core.auth import require_internal_token
from src.core.link_tree_syncer import LinkTreeSyncer
from src.database import LinkTreeRepository
from src.models.api_response import DefaultResult
from src.models.link_tree_request import LinkTreeSyncRequest
from src.models.link_query_request import LinkQueryRequest

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/link-tree",
    tags=["链接树管理"],
    dependencies=[Depends(require_internal_token)],
)


def _build_s3_boundary() -> S3Boundary | None:
    """构建 S3Boundary 实例，配置不完整时返回 None"""
    try:
        return S3Boundary()
    except ValueError:
        logger.warning("S3 配置不完整，S3 功能将不可用")
        return None


@router.post("/sync", response_model=DefaultResult)
async def sync_link_tree(request: LinkTreeSyncRequest) -> DefaultResult:
    """
    根据全量爬取的链接树 JSON 增量更新 crawl_link_tree 表。

    接收两个参数：
      - tree_file: tree_structure_{ts}.json 文件路径（支持 s3:// 路径）
      - site: 所属站点（如 tokyostarbank.co.jp）

    同步规则：
      1. JSON 有 / DB 有 → 跳过
      2. JSON 有 / DB 无 → 新增，update_history="新增"
      3. DB 有 / JSON 无 → 标记"待删除"，逐个页面验证可达性：
         页面正常 → 去掉待删除，custom_tag="验证页面正常"；
         其它情况 → update_history="已删除"

    返回同步统计：新增/跳过/待删除/验证正常/已删除/DB重复等。
    """
    s3_boundary = _build_s3_boundary()

    syncer = LinkTreeSyncer(headless=request.headless, s3_boundary=s3_boundary)
    try:
        stats = await syncer.sync(request.tree_file, request.site)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.exception("链接树增量同步失败")
        raise HTTPException(status_code=500, detail=f"同步失败: {e}")

    return DefaultResult(
        message="链接树增量同步完成",
        data=stats,
    )


@router.post("/links", response_model=DefaultResult)
async def query_links_deprecated(request: LinkQueryRequest) -> DefaultResult:
    """已迁移至 /v2/map（对外接口，public_token 鉴权）。

    保留此内部端点便于内部运维查询，鉴权用 internal_token。
    逻辑与 /v2/map 一致。
    """
    from src.database.repository import TaskRepository
    from src.routers.crawl import _launch_full_site
    from src.utils.url_utils import get_domain

    # 1. 解析站点
    domain = get_domain(request.url)
    if not domain:
        raise HTTPException(
            status_code=400,
            detail=f"无法解析 URL 的域名: {request.url}",
        )

    task_repo = TaskRepository()
    link_repo = LinkTreeRepository()

    # 2. 优先查 completed 的 full_site 任务
    completed_task = await task_repo.find_completed_by_site_and_type(domain, "full_site")
    if completed_task is not None:
        rows = await link_repo.search_by_site(domain, request.search or None, request.limit)
        links = [
            {
                "url": row.url,
                "title": row.page_title or "",
                "description": row.remark or "",
                "level": row.level,
                "type": "html" if (row.link_type or "").upper() == "HTML" else "file",
            }
            for row in rows
        ]
        return DefaultResult(
            data={
                "success": True,
                "task_id": completed_task.task_id,
                "status": "completed",
                "message": "ok",
                "links": links,
            }
        )

    # 3. 无 completed：查最新 full_site 任务
    latest_task = await task_repo.find_latest_by_site_and_type(domain, "full_site")

    if latest_task is None or latest_task.status == "failed":
        master_task = await _launch_full_site(
            domain=domain,
            target_url=request.url,
            headless=True,
            max_depth=None,
        )
        return DefaultResult(
            data={
                "success": True,
                "task_id": master_task.task_id,
                "status": "running",
                "message": "ok",
                "links": [],
            }
        )

    return DefaultResult(
        data={
            "success": True,
            "task_id": latest_task.task_id,
            "status": latest_task.status,
            "message": "ok",
            "links": [],
        }
    )


@router.get("/stats/{site}", response_model=DefaultResult)
async def link_tree_stats(site: str) -> DefaultResult:
    """查询指定站点链接树统计信息（记录数、level 分布、更新履历分布）"""
    repo = LinkTreeRepository()
    total = await repo.count_by_site(site)
    level_dist = await repo.level_distribution(site)
    all_rows = await repo.list_all_by_site(site)

    from collections import Counter
    history_dist = Counter(r.update_history for r in all_rows)

    return DefaultResult(
        data={
            "site": site,
            "total": total,
            "level_distribution": [{"level": lv, "count": c} for lv, c in level_dist],
            "update_history_distribution": dict(history_dist),
        },
    )
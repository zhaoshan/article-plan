package com.unify.iam.app.oidc;

import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import org.springframework.stereotype.Service;

/**
 * JIT 入租户（docs/03 §6）：find-or-create identity → 域名路由成员（幂等）。
 *
 * <p>产出 {@link UserPrincipal} + 待签发令牌的 {@link MembershipPO}。企业 SSO 按邮箱域名路由到已有
 * ORGANIZATION 租户，**域名未命中 → 403，不再 JIT 自建租户**（docs/requirements M10W4-W5 S1 决策）；
 * 平台级 consumer 建专属 PERSONAL 租户。
 */
@Service
public class JitProvisioner {

    private final UserRepository userRepository;
    private final UserIdentityRepository userIdentityRepository;
    private final TenantRepository tenantRepository;
    private final MembershipRepository membershipRepository;

    public JitProvisioner(UserRepository userRepository,
                          UserIdentityRepository userIdentityRepository,
                          TenantRepository tenantRepository,
                          MembershipRepository membershipRepository) {
        this.userRepository = userRepository;
        this.userIdentityRepository = userIdentityRepository;
        this.tenantRepository = tenantRepository;
        this.membershipRepository = membershipRepository;
    }

    /** JIT 编排结果。 */
    public record JitResult(UserPrincipal principal, MembershipPO membership) {
    }

    public JitResult provision(OidcProviderConfig config, VerifiedClaims claims) {
        if (!config.jitEnabled()) {
            throw AuthException.forbidden("JIT 已禁用");
        }
        String email = claims.email() == null ? "" : claims.email().trim().toLowerCase();
        if (email.isEmpty()) {
            throw AuthException.unauthorized("缺少 email claim");
        }
        String domain = domainOf(email);
        if (!config.allowsDomain(domain)) {
            throw AuthException.forbidden("邮箱域名不在允许名单：" + domain);
        }

        UserIdentityPO identity = findOrCreateIdentity(config, claims, email);
        UserPO user = userRepository.findByUserId(identity.getUserId())
                .orElseThrow(() -> AuthException.unauthorized("用户不存在"));
        MembershipPO membership = resolveMembership(config, user, domain);
        return new JitResult(
                new UserPrincipal(user.getUserId(), user.getUsername(), identity.getUserIdentityId()),
                membership);
    }

    private UserIdentityPO findOrCreateIdentity(OidcProviderConfig config, VerifiedClaims claims, String email) {
        String providerType = "OIDC";
        String subject = claims.subject();
        var existing = userIdentityRepository
                .findByProvider(providerType, config.providerKey(), config.issuer(), subject);
        if (existing.isPresent()) {
            // 既有身份：刷新 claims 快照（保证 claims_json 反映最新登录，便于审计/排障）
            userIdentityRepository.refreshClaims(existing.get().getUserIdentityId(),
                    JsonUtils.toJson(claims.all()), email);
            return existing.get();
        }
        UserPO user = new UserPO();
        user.setUserId(IdGenerator.newBizId());
        user.setUsername(email);
        user.setPrimaryEmail(email);
        user.setUserStatus("ACTIVE");
        user.setRegistrationSource("SSO");
        userRepository.create(user); // username 唯一键兜底并发
        UserPO saved = userRepository.findByUsername(email)
                .orElseThrow(() -> AuthException.unauthorized("用户创建失败"));

        UserIdentityPO id = new UserIdentityPO();
        id.setUserIdentityId(IdGenerator.newBizId());
        id.setUserId(saved.getUserId());
        id.setProviderType(providerType);
        id.setProviderKey(config.providerKey());
        id.setIssuer(config.issuer());
        id.setSubject(subject);
        id.setLoginName(email);
        id.setEmailAtIdp(email);
        id.setIdentityStatus("ACTIVE");
        id.setClaimsJson(JsonUtils.toJson(claims.all()));
        if (!userIdentityRepository.create(id)) {
            return userIdentityRepository
                    .findByProvider(providerType, config.providerKey(), config.issuer(), subject)
                    .orElseThrow(() -> AuthException.unauthorized("身份创建失败"));
        }
        return id;
    }

    private MembershipPO resolveMembership(OidcProviderConfig config, UserPO user, String domain) {
        if (config.isPlatformConfig()) {
            return personalMembership(user);
        }
        TenantPO tenant = tenantRepository.findActiveByPrimaryDomain(domain).orElse(null);
        if (tenant == null) {
            // S1：企业 SSO 域名未命中 → 403（不再 JIT 自建 ORGANIZATION；租户必须先建、再配该租户 IdP）
            throw AuthException.forbidden("邮箱域名未开通：该域名没有已开通的组织租户");
        }
        return membershipRepository.findByTenantAndUser(tenant.getTenantId(), user.getUserId())
                .orElseGet(() -> switch (config.defaultJoinPolicy()) {
                    case "AUTO_JOIN" -> ensureMembership(user, tenant, true);
                    case "REQUEST" -> throw AuthException.forbidden("加入申请流程将在 P3 提供");
                    default -> throw AuthException.forbidden("需先被邀请加入该租户"); // INVITE_ONLY / 其它
                });
    }

    private MembershipPO personalMembership(UserPO user) {
        TenantPO personal = tenantRepository
                .findActiveByOwnerAndType(user.getUserId(), "PERSONAL").orElse(null);
        if (personal == null) {
            personal = new TenantPO();
            personal.setTenantId(IdGenerator.newBizId());
            personal.setTenantCode("p-" + user.getUserId().substring(0, Math.min(10, user.getUserId().length())));
            personal.setTenantName("个人空间");
            personal.setTenantType("PERSONAL");
            personal.setTenantStatus("ACTIVE");
            personal.setRegistrationSource("SSO");
            personal.setOwnerUserId(user.getUserId());
            tenantRepository.create(personal);
        }
        return ensureMembership(user, personal, true);
    }

    private MembershipPO ensureMembership(UserPO user, TenantPO tenant, boolean isDefault) {
        String tenantId = tenant.getTenantId().trim();
        MembershipPO po = new MembershipPO();
        po.setMembershipId(IdGenerator.newBizId());
        po.setTenantId(tenantId);
        po.setUserId(user.getUserId().trim());
        po.setMembershipStatus("ACTIVE");
        po.setJoinSource("SSO");
        po.setIsDefault(isDefault ? 1 : 0);
        membershipRepository.create(po); // 唯一键 (tenant_id, user_id) 兜底并发
        userRepository.updateDefaultTenant(user.getUserId(), tenantId);
        return membershipRepository.findByTenantAndUser(tenantId, user.getUserId())
                .orElseThrow(() -> AuthException.badRequest("成员关系创建失败"));
    }

    private String domainOf(String email) {
        int at = email.indexOf('@');
        return at < 0 ? email : email.substring(at + 1);
    }
}
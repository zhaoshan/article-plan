-- ============================================================
-- imorph 应用目录 seed（可重复、幂等；db/seed 位置，所有环境应用）
-- 内容：iam_application(imorph / AI Chat Insight) + 126 业务权限点（app_code=imorph，租户可授）
--       + 3 角色模板（iMorph-Owner=Admin 权限集/is_owner；iMorph-Admin=全量；iMorph-Member=受限）
-- 来源：docs/requirements/iMorph正式版权限码与角色矩阵.xlsx（权限码=正式版权限码；
--       resource_type=二级功能对象；action=三级权限点；Admin/Member 列=授予口径）
-- 口径：app_code=imorph（xlsx 编码与迁移说明）；ai-chat-insight 为后端服务名。
-- 说明：只初始化应用目录；不建 iam_tenant_application / 租户实例角色——
--       租户启用 imorph 时由 TenantAppProvisionService 按模板灌入（docs/06）。
-- 幂等：权限/应用用 INSERT IGNORE；模板用 UPSERT（ON DUPLICATE KEY UPDATE）——
--       已应用环境改 role_code 后重放可真正生效，不会静默跳过。
-- ============================================================

SET NAMES utf8mb4;

-- 1. 应用
INSERT IGNORE INTO `iam_application`
  (`app_id`, `app_code`, `app_name`, `app_status`, `description`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('app-2003', 'imorph', 'AI Chat Insight', 'ACTIVE', 'AI Chat Insight 企业级客服知识/Agent 平台（后端服务 ai-chat-insight）', 0, 'system', 'system');

-- 2. 业务权限点（126 码，p-3001..p-3126；resource_type=二级功能对象 / action=三级权限点）
INSERT IGNORE INTO `gateway_permission`
  (`permission_id`, `permission_code`, `resource_type`, `app_code`, `tenant_grantable`, `action`, `permission_name`,
   `permission_description`, `category`, `is_builtin`, `permission_status`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('p-3001', 'imorph:agent:read', 'Agent', 'imorph', 1, '查看', '查看 Agent',
   'Agent Management / Agent / 查看', 'Agent Management', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3002', 'imorph:agent:create', 'Agent', 'imorph', 1, '新建', '新建 Agent',
   'Agent Management / Agent / 新建', 'Agent Management', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3003', 'imorph:agent:edit', 'Agent', 'imorph', 1, '编辑', '编辑 Agent',
   'Agent Management / Agent / 编辑', 'Agent Management', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3004', 'imorph:agent:delete', 'Agent', 'imorph', 1, '删除', '删除 Agent',
   'Agent Management / Agent / 删除', 'Agent Management', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3005', 'imorph:knowledge:read', 'Knowledge', 'imorph', 1, '查看', '查看 Knowledge',
   'KnowledgeHub / Knowledge / 查看', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3006', 'imorph:knowledge:create-content', 'Knowledge', 'imorph', 1, '新建文章 / Snippet', '新建文章 / Snippet Knowledge',
   'KnowledgeHub / Knowledge / 新建文章 / Snippet', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3007', 'imorph:knowledge:upload-document', 'Knowledge', 'imorph', 1, '上传文档', '上传文档 Knowledge',
   'KnowledgeHub / Knowledge / 上传文档', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3008', 'imorph:knowledge:edit-content', 'Knowledge', 'imorph', 1, '编辑文章 / Snippet', '编辑文章 / Snippet Knowledge',
   'KnowledgeHub / Knowledge / 编辑文章 / Snippet', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3009', 'imorph:knowledge:edit-tags', 'Knowledge', 'imorph', 1, '编辑知识标签', '编辑知识标签 Knowledge',
   'KnowledgeHub / Knowledge / 编辑知识标签', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3010', 'imorph:knowledge:delete', 'Knowledge', 'imorph', 1, '删除', '删除 Knowledge',
   'KnowledgeHub / Knowledge / 删除', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3011', 'imorph:knowledge:download-source', 'Knowledge', 'imorph', 1, '下载文档原文件', '下载文档原文件 Knowledge',
   'KnowledgeHub / Knowledge / 下载文档原文件', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3012', 'imorph:knowledge:configure-index', 'Knowledge', 'imorph', 1, '设置文档索引', '设置文档索引 Knowledge',
   'KnowledgeHub / Knowledge / 设置文档索引', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3013', 'imorph:knowledge-folder:create', 'Folder', 'imorph', 1, '新建文件夹', '新建文件夹 Folder',
   'KnowledgeHub / Folder / 新建文件夹', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3014', 'imorph:knowledge-folder:move', 'Folder', 'imorph', 1, '移动内容', '移动内容 Folder',
   'KnowledgeHub / Folder / 移动内容', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3015', 'imorph:knowledge-folder:delete', 'Folder', 'imorph', 1, '删除文件夹', '删除文件夹 Folder',
   'KnowledgeHub / Folder / 删除文件夹', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3016', 'imorph:knowledge-sync:read', 'Website sync', 'imorph', 1, '查看同步源和任务', '查看同步源和任务 Website sync',
   'KnowledgeHub / Website sync / 查看同步源和任务', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3017', 'imorph:knowledge-sync:create', 'Website sync', 'imorph', 1, '新建同步源', '新建同步源 Website sync',
   'KnowledgeHub / Website sync / 新建同步源', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3018', 'imorph:knowledge-sync:resync', 'Website sync', 'imorph', 1, '重新同步', '重新同步 Website sync',
   'KnowledgeHub / Website sync / 重新同步', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3019', 'imorph:knowledge-sync:delete', 'Website sync', 'imorph', 1, '删除同步源', '删除同步源 Website sync',
   'KnowledgeHub / Website sync / 删除同步源', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3020', 'imorph:knowledge-preview:run', 'Preview', 'imorph', 1, '运行检索预览', '运行检索预览 Preview',
   'KnowledgeHub / Preview / 运行检索预览', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3021', 'imorph:knowledge-preview:read-log', 'Preview', 'imorph', 1, '查看检索日志', '查看检索日志 Preview',
   'KnowledgeHub / Preview / 查看检索日志', 'KnowledgeHub', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3022', 'imorph:build-guidelines:read', 'Guidelines', 'imorph', 1, '查看', '查看 Guidelines',
   'Build / Guidelines / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3023', 'imorph:build-guidelines:create', 'Guidelines', 'imorph', 1, '新建', '新建 Guidelines',
   'Build / Guidelines / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3024', 'imorph:build-guidelines:edit', 'Guidelines', 'imorph', 1, '编辑', '编辑 Guidelines',
   'Build / Guidelines / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3025', 'imorph:build-guidelines:delete', 'Guidelines', 'imorph', 1, '删除', '删除 Guidelines',
   'Build / Guidelines / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3026', 'imorph:build-journey:read', 'Journey', 'imorph', 1, '查看', '查看 Journey',
   'Build / Journey / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3027', 'imorph:build-journey:create', 'Journey', 'imorph', 1, '新建', '新建 Journey',
   'Build / Journey / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3028', 'imorph:build-journey:edit', 'Journey', 'imorph', 1, '编辑', '编辑 Journey',
   'Build / Journey / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3029', 'imorph:build-journey:set-active', 'Journey', 'imorph', 1, '启用 / 停用', '启用 / 停用 Journey',
   'Build / Journey / 启用 / 停用', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3030', 'imorph:build-journey:delete', 'Journey', 'imorph', 1, '删除', '删除 Journey',
   'Build / Journey / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3031', 'imorph:build-relationship:read', 'Relationship', 'imorph', 1, '查看', '查看 Relationship',
   'Build / Relationship / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3032', 'imorph:build-relationship:create', 'Relationship', 'imorph', 1, '新建', '新建 Relationship',
   'Build / Relationship / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3033', 'imorph:build-relationship:edit', 'Relationship', 'imorph', 1, '编辑', '编辑 Relationship',
   'Build / Relationship / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3034', 'imorph:build-relationship:delete', 'Relationship', 'imorph', 1, '删除', '删除 Relationship',
   'Build / Relationship / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3035', 'imorph:build-observation:read', 'Observation', 'imorph', 1, '查看', '查看 Observation',
   'Build / Observation / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3036', 'imorph:build-observation:create', 'Observation', 'imorph', 1, '新建', '新建 Observation',
   'Build / Observation / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3037', 'imorph:build-observation:edit', 'Observation', 'imorph', 1, '编辑', '编辑 Observation',
   'Build / Observation / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3038', 'imorph:build-observation:delete', 'Observation', 'imorph', 1, '删除', '删除 Observation',
   'Build / Observation / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3039', 'imorph:build-variables:read', 'Variables', 'imorph', 1, '查看', '查看 Variables',
   'Build / Variables / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3040', 'imorph:build-variables:create', 'Variables', 'imorph', 1, '新建', '新建 Variables',
   'Build / Variables / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3041', 'imorph:build-variables:edit', 'Variables', 'imorph', 1, '编辑', '编辑 Variables',
   'Build / Variables / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3042', 'imorph:build-variables:delete', 'Variables', 'imorph', 1, '删除', '删除 Variables',
   'Build / Variables / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3043', 'imorph:build-canned-response:read', 'Canned Response', 'imorph', 1, '查看', '查看 Canned Response',
   'Build / Canned Response / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3044', 'imorph:build-canned-response:create', 'Canned Response', 'imorph', 1, '新建', '新建 Canned Response',
   'Build / Canned Response / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3045', 'imorph:build-canned-response:edit', 'Canned Response', 'imorph', 1, '编辑', '编辑 Canned Response',
   'Build / Canned Response / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3046', 'imorph:build-canned-response:delete', 'Canned Response', 'imorph', 1, '删除', '删除 Canned Response',
   'Build / Canned Response / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3047', 'imorph:build-retrievers:read', 'Retrievers', 'imorph', 1, '查看', '查看 Retrievers',
   'Build / Retrievers / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3048', 'imorph:build-retrievers:create', 'Retrievers', 'imorph', 1, '新建', '新建 Retrievers',
   'Build / Retrievers / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3049', 'imorph:build-retrievers:edit', 'Retrievers', 'imorph', 1, '编辑', '编辑 Retrievers',
   'Build / Retrievers / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3050', 'imorph:build-retrievers:delete', 'Retrievers', 'imorph', 1, '删除', '删除 Retrievers',
   'Build / Retrievers / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3051', 'imorph:build-glossary:read', 'Glossary', 'imorph', 1, '查看', '查看 Glossary',
   'Build / Glossary / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3052', 'imorph:build-glossary:create', 'Glossary', 'imorph', 1, '新建', '新建 Glossary',
   'Build / Glossary / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3053', 'imorph:build-glossary:edit', 'Glossary', 'imorph', 1, '编辑', '编辑 Glossary',
   'Build / Glossary / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3054', 'imorph:build-glossary:delete', 'Glossary', 'imorph', 1, '删除', '删除 Glossary',
   'Build / Glossary / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3055', 'imorph:build-tools:read', 'Tools', 'imorph', 1, '查看', '查看 Tools',
   'Build / Tools / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3056', 'imorph:build-tools:create', 'Tools', 'imorph', 1, '新建', '新建 Tools',
   'Build / Tools / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3057', 'imorph:build-tools:edit', 'Tools', 'imorph', 1, '编辑', '编辑 Tools',
   'Build / Tools / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3058', 'imorph:build-tools:delete', 'Tools', 'imorph', 1, '删除', '删除 Tools',
   'Build / Tools / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3059', 'imorph:build-tools:test', 'Tools', 'imorph', 1, '测试工具', '测试工具 Tools',
   'Build / Tools / 测试工具', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3060', 'imorph:build-tags:read', 'Tags', 'imorph', 1, '查看', '查看 Tags',
   'Build / Tags / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3061', 'imorph:build-tags:create', 'Tags', 'imorph', 1, '新建', '新建 Tags',
   'Build / Tags / 新建', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3062', 'imorph:build-tags:edit', 'Tags', 'imorph', 1, '编辑', '编辑 Tags',
   'Build / Tags / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3063', 'imorph:build-tags:delete', 'Tags', 'imorph', 1, '删除', '删除 Tags',
   'Build / Tags / 删除', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3064', 'imorph:build-runtime-config:read', 'Runtime Config', 'imorph', 1, '查看', '查看 Runtime Config',
   'Build / Runtime Config / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3065', 'imorph:build-runtime-config:edit', 'Runtime Config', 'imorph', 1, '编辑', '编辑 Runtime Config',
   'Build / Runtime Config / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3066', 'imorph:build-fallback-response:read', 'Fallback response', 'imorph', 1, '查看', '查看 Fallback response',
   'Build / Fallback response / 查看', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3067', 'imorph:build-fallback-response:edit', 'Fallback response', 'imorph', 1, '编辑', '编辑 Fallback response',
   'Build / Fallback response / 编辑', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3068', 'imorph:build-ai-check:read', 'AI Check', 'imorph', 1, '查看检查结果', '查看检查结果 AI Check',
   'Build / AI Check / 查看检查结果', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3069', 'imorph:build-ai-check:run', 'AI Check', 'imorph', 1, '运行检查', '运行检查 AI Check',
   'Build / AI Check / 运行检查', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3070', 'imorph:build-ai-check:handle-suggestion', 'AI Check', 'imorph', 1, '处理检查建议', '处理检查建议 AI Check',
   'Build / AI Check / 处理检查建议', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3071', 'imorph:build-agent-config:read-full', 'Agent 配置', 'imorph', 1, '查看完整配置', '查看完整配置 Agent 配置',
   'Build / Agent 配置 / 查看完整配置', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3072', 'imorph:build-agent-config:import-append', 'Agent 配置', 'imorph', 1, '追加导入', '追加导入 Agent 配置',
   'Build / Agent 配置 / 追加导入', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3073', 'imorph:build-agent-config:import-overwrite', 'Agent 配置', 'imorph', 1, '覆盖导入', '覆盖导入 Agent 配置',
   'Build / Agent 配置 / 覆盖导入', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3074', 'imorph:build-agent-config:export', 'Agent 配置', 'imorph', 1, '导出', '导出 Agent 配置',
   'Build / Agent 配置 / 导出', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3075', 'imorph:build-agent-config:publish', 'Agent 配置', 'imorph', 1, '发布', '发布 Agent 配置',
   'Build / Agent 配置 / 发布', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3076', 'imorph:build-agent-config:read-history', 'Agent 配置', 'imorph', 1, '查看定义历史', '查看定义历史 Agent 配置',
   'Build / Agent 配置 / 查看定义历史', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3077', 'imorph:build-agent-config:rollback', 'Agent 配置', 'imorph', 1, '回滚定义版本', '回滚定义版本 Agent 配置',
   'Build / Agent 配置 / 回滚定义版本', 'Build', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3078', 'imorph:preview-text:run', 'Text', 'imorph', 1, '运行文字预览', '运行文字预览 Text',
   'Preview / Text / 运行文字预览', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3079', 'imorph:preview-voice:run', 'Voice', 'imorph', 1, '运行语音预览', '运行语音预览 Voice',
   'Preview / Voice / 运行语音预览', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3080', 'imorph:preview-web-widget:run', 'Web Widget', 'imorph', 1, '预览渠道效果', '预览渠道效果 Web Widget',
   'Preview / Web Widget / 预览渠道效果', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3081', 'imorph:preview-runtime:inspect', 'Runtime', 'imorph', 1, '查看调试详情', '查看调试详情 Runtime',
   'Preview / Runtime / 查看调试详情', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3082', 'imorph:preview-self-play:read', 'Self Play', 'imorph', 1, '查看场景', '查看场景 Self Play',
   'Preview / Self Play / 查看场景', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3083', 'imorph:preview-self-play:create', 'Self Play', 'imorph', 1, '新建场景', '新建场景 Self Play',
   'Preview / Self Play / 新建场景', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3084', 'imorph:preview-self-play:edit', 'Self Play', 'imorph', 1, '编辑场景', '编辑场景 Self Play',
   'Preview / Self Play / 编辑场景', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3085', 'imorph:preview-self-play:delete', 'Self Play', 'imorph', 1, '删除场景', '删除场景 Self Play',
   'Preview / Self Play / 删除场景', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3086', 'imorph:preview-self-play:run', 'Self Play', 'imorph', 1, '运行自测', '运行自测 Self Play',
   'Preview / Self Play / 运行自测', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3087', 'imorph:preview-self-play:read-result', 'Self Play', 'imorph', 1, '查看自测结果', '查看自测结果 Self Play',
   'Preview / Self Play / 查看自测结果', 'Preview', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3088', 'imorph:test-groups:read', 'Test groups', 'imorph', 1, '查看', '查看 Test groups',
   'Test / Test groups / 查看', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3089', 'imorph:test-groups:create', 'Test groups', 'imorph', 1, '新建', '新建 Test groups',
   'Test / Test groups / 新建', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3090', 'imorph:test-groups:edit', 'Test groups', 'imorph', 1, '编辑', '编辑 Test groups',
   'Test / Test groups / 编辑', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3091', 'imorph:test-groups:delete', 'Test groups', 'imorph', 1, '删除', '删除 Test groups',
   'Test / Test groups / 删除', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3092', 'imorph:test-questions:read', 'Questions', 'imorph', 1, '查看', '查看 Questions',
   'Test / Questions / 查看', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3093', 'imorph:test-questions:create', 'Questions', 'imorph', 1, '手动新增', '手动新增 Questions',
   'Test / Questions / 手动新增', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3094', 'imorph:test-questions:generate', 'Questions', 'imorph', 1, 'AI 生成', 'AI 生成 Questions',
   'Test / Questions / AI 生成', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3095', 'imorph:test-questions:import', 'Questions', 'imorph', 1, '批量导入', '批量导入 Questions',
   'Test / Questions / 批量导入', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3096', 'imorph:test-questions:delete', 'Questions', 'imorph', 1, '删除', '删除 Questions',
   'Test / Questions / 删除', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3097', 'imorph:test-evaluate-answer:read', 'Evaluate answer', 'imorph', 1, '查看评测结果', '查看评测结果 Evaluate answer',
   'Test / Evaluate answer / 查看评测结果', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3098', 'imorph:test-evaluate-answer:run', 'Evaluate answer', 'imorph', 1, '运行测试', '运行测试 Evaluate answer',
   'Test / Evaluate answer / 运行测试', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3099', 'imorph:test-evaluate-answer:rate', 'Evaluate answer', 'imorph', 1, '评价回答', '评价回答 Evaluate answer',
   'Test / Evaluate answer / 评价回答', 'Test', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3100', 'imorph:deploy-channel-settings:read', 'Channel Settings', 'imorph', 1, '查看渠道配置', '查看渠道配置 Channel Settings',
   'Deploy / Channel Settings / 查看渠道配置', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3101', 'imorph:deploy-channel-settings:edit-widget', 'Channel Settings', 'imorph', 1, '编辑 Web Widget 配置', '编辑 Web Widget 配置 Channel Settings',
   'Deploy / Channel Settings / 编辑 Web Widget 配置', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3102', 'imorph:deploy-channel-settings:edit-voice', 'Channel Settings', 'imorph', 1, '编辑 Voice 配置', '编辑 Voice 配置 Channel Settings',
   'Deploy / Channel Settings / 编辑 Voice 配置', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3103', 'imorph:deploy-channel-settings:toggle', 'Channel Settings', 'imorph', 1, '启用 / 停用渠道', '启用 / 停用渠道 Channel Settings',
   'Deploy / Channel Settings / 启用 / 停用渠道', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3104', 'imorph:deploy-runtime-guardrails:edit', 'Runtime Guardrails', 'imorph', 1, '编辑运行限制', '编辑运行限制 Runtime Guardrails',
   'Deploy / Runtime Guardrails / 编辑运行限制', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3105', 'imorph:deploy-phone-number:purchase-assign', 'Phone number', 'imorph', 1, '购买并分配号码', '购买并分配号码 Phone number',
   'Deploy / Phone number / 购买并分配号码', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3106', 'imorph:deploy-deployment:deploy', 'Deployment', 'imorph', 1, '部署', '部署 Deployment',
   'Deploy / Deployment / 部署', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3107', 'imorph:deploy-deployment:pause', 'Deployment', 'imorph', 1, '暂停', '暂停 Deployment',
   'Deploy / Deployment / 暂停', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3108', 'imorph:deploy-deployment:resume', 'Deployment', 'imorph', 1, '恢复运行', '恢复运行 Deployment',
   'Deploy / Deployment / 恢复运行', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3109', 'imorph:deploy-history:read', 'Deployment History', 'imorph', 1, '查看历史', '查看历史 Deployment History',
   'Deploy / Deployment History / 查看历史', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3110', 'imorph:deploy-history:restore-draft', 'Deployment History', 'imorph', 1, '恢复草稿', '恢复草稿 Deployment History',
   'Deploy / Deployment History / 恢复草稿', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3111', 'imorph:deploy-history:rollback-live', 'Deployment History', 'imorph', 1, '回滚线上版本', '回滚线上版本 Deployment History',
   'Deploy / Deployment History / 回滚线上版本', 'Deploy', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3112', 'imorph:monitor-conversations:read', 'Conversations', 'imorph', 1, '查看会话', '查看会话 Conversations',
   'Monitor / Conversations / 查看会话', 'Monitor', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3113', 'imorph:monitor-logs:read', 'Logs', 'imorph', 1, '查看运行日志', '查看运行日志 Logs',
   'Monitor / Logs / 查看运行日志', 'Monitor', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3114', 'imorph:monitor-logs:sync', 'Logs', 'imorph', 1, '同步运行日志', '同步运行日志 Logs',
   'Monitor / Logs / 同步运行日志', 'Monitor', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3115', 'imorph:suggestions:read', 'Suggestions', 'imorph', 1, '查看建议', '查看建议 Suggestions',
   'Suggestions / Suggestions / 查看建议', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3116', 'imorph:suggestions:create-patch', 'Suggestions', 'imorph', 1, '生成草稿补丁', '生成草稿补丁 Suggestions',
   'Suggestions / Suggestions / 生成草稿补丁', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3117', 'imorph:suggestions:create-test', 'Suggestions', 'imorph', 1, '生成验证测试', '生成验证测试 Suggestions',
   'Suggestions / Suggestions / 生成验证测试', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3118', 'imorph:suggestions:mark-duplicate', 'Suggestions', 'imorph', 1, '标记重复', '标记重复 Suggestions',
   'Suggestions / Suggestions / 标记重复', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3119', 'imorph:suggestions:defer-resume', 'Suggestions', 'imorph', 1, '暂缓 / 恢复处理', '暂缓 / 恢复处理 Suggestions',
   'Suggestions / Suggestions / 暂缓 / 恢复处理', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3120', 'imorph:suggestions:reject', 'Suggestions', 'imorph', 1, '拒绝建议', '拒绝建议 Suggestions',
   'Suggestions / Suggestions / 拒绝建议', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3121', 'imorph:suggestions:reopen', 'Suggestions', 'imorph', 1, '重新打开', '重新打开 Suggestions',
   'Suggestions / Suggestions / 重新打开', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3122', 'imorph:suggestions:complete', 'Suggestions', 'imorph', 1, '标记完成', '标记完成 Suggestions',
   'Suggestions / Suggestions / 标记完成', 'Suggestions', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3123', 'imorph:insights-performance:read', 'Performance', 'imorph', 1, '查看分析', '查看分析 Performance',
   'Insights / Performance / 查看分析', 'Insights', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3124', 'imorph:insights-topic:read', 'Topic Explorer', 'imorph', 1, '查看分析', '查看分析 Topic Explorer',
   'Insights / Topic Explorer / 查看分析', 'Insights', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3125', 'imorph:insights-cx:read', 'CX Dashboard', 'imorph', 1, '查看分析', '查看分析 CX Dashboard',
   'Insights / CX Dashboard / 查看分析', 'Insights', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-3126', 'imorph:insights-conversation-detail:read', 'Conversation Detail', 'imorph', 1, '查看会话明细', '查看会话明细 Conversation Detail',
   'Insights / Conversation Detail / 查看会话明细', 'Insights', 1, 'ACTIVE', 0, 'system', 'system');

-- 3. 应用角色模板（scope_type 默认 TENANT；Owner=Admin 权限集且 is_owner=1）
INSERT IGNORE INTO `iam_application_role_template`
  (`template_id`, `app_code`, `role_code`, `role_name`, `role_description`, `permission_codes_json`,
   `is_owner`, `is_admin`, `priority`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('tpl-3001', 'imorph', 'iMorph-Owner', 'Owner', '租户 Owner（权限集与 Admin 一致；is_owner 首人所有者）',
   JSON_ARRAY('imorph:agent:read', 'imorph:agent:create', 'imorph:agent:edit', 'imorph:agent:delete',
   'imorph:knowledge:read', 'imorph:knowledge:create-content', 'imorph:knowledge:upload-document', 'imorph:knowledge:edit-content',
   'imorph:knowledge:edit-tags', 'imorph:knowledge:delete', 'imorph:knowledge:download-source', 'imorph:knowledge:configure-index',
   'imorph:knowledge-folder:create', 'imorph:knowledge-folder:move', 'imorph:knowledge-folder:delete', 'imorph:knowledge-sync:read',
   'imorph:knowledge-sync:create', 'imorph:knowledge-sync:resync', 'imorph:knowledge-sync:delete', 'imorph:knowledge-preview:run',
   'imorph:knowledge-preview:read-log', 'imorph:build-guidelines:read', 'imorph:build-guidelines:create', 'imorph:build-guidelines:edit',
   'imorph:build-guidelines:delete', 'imorph:build-journey:read', 'imorph:build-journey:create', 'imorph:build-journey:edit',
   'imorph:build-journey:set-active', 'imorph:build-journey:delete', 'imorph:build-relationship:read', 'imorph:build-relationship:create',
   'imorph:build-relationship:edit', 'imorph:build-relationship:delete', 'imorph:build-observation:read', 'imorph:build-observation:create',
   'imorph:build-observation:edit', 'imorph:build-observation:delete', 'imorph:build-variables:read', 'imorph:build-variables:create',
   'imorph:build-variables:edit', 'imorph:build-variables:delete', 'imorph:build-canned-response:read', 'imorph:build-canned-response:create',
   'imorph:build-canned-response:edit', 'imorph:build-canned-response:delete', 'imorph:build-retrievers:read', 'imorph:build-retrievers:create',
   'imorph:build-retrievers:edit', 'imorph:build-retrievers:delete', 'imorph:build-glossary:read', 'imorph:build-glossary:create',
   'imorph:build-glossary:edit', 'imorph:build-glossary:delete', 'imorph:build-tools:read', 'imorph:build-tools:create',
   'imorph:build-tools:edit', 'imorph:build-tools:delete', 'imorph:build-tools:test', 'imorph:build-tags:read',
   'imorph:build-tags:create', 'imorph:build-tags:edit', 'imorph:build-tags:delete', 'imorph:build-runtime-config:read',
   'imorph:build-runtime-config:edit', 'imorph:build-fallback-response:read', 'imorph:build-fallback-response:edit', 'imorph:build-ai-check:read',
   'imorph:build-ai-check:run', 'imorph:build-ai-check:handle-suggestion', 'imorph:build-agent-config:read-full', 'imorph:build-agent-config:import-append',
   'imorph:build-agent-config:import-overwrite', 'imorph:build-agent-config:export', 'imorph:build-agent-config:publish', 'imorph:build-agent-config:read-history',
   'imorph:build-agent-config:rollback', 'imorph:preview-text:run', 'imorph:preview-voice:run', 'imorph:preview-web-widget:run',
   'imorph:preview-runtime:inspect', 'imorph:preview-self-play:read', 'imorph:preview-self-play:create', 'imorph:preview-self-play:edit',
   'imorph:preview-self-play:delete', 'imorph:preview-self-play:run', 'imorph:preview-self-play:read-result', 'imorph:test-groups:read',
   'imorph:test-groups:create', 'imorph:test-groups:edit', 'imorph:test-groups:delete', 'imorph:test-questions:read',
   'imorph:test-questions:create', 'imorph:test-questions:generate', 'imorph:test-questions:import', 'imorph:test-questions:delete',
   'imorph:test-evaluate-answer:read', 'imorph:test-evaluate-answer:run', 'imorph:test-evaluate-answer:rate', 'imorph:deploy-channel-settings:read',
   'imorph:deploy-channel-settings:edit-widget', 'imorph:deploy-channel-settings:edit-voice', 'imorph:deploy-channel-settings:toggle', 'imorph:deploy-runtime-guardrails:edit',
   'imorph:deploy-phone-number:purchase-assign', 'imorph:deploy-deployment:deploy', 'imorph:deploy-deployment:pause', 'imorph:deploy-deployment:resume',
   'imorph:deploy-history:read', 'imorph:deploy-history:restore-draft', 'imorph:deploy-history:rollback-live', 'imorph:monitor-conversations:read',
   'imorph:monitor-logs:read', 'imorph:monitor-logs:sync', 'imorph:suggestions:read', 'imorph:suggestions:create-patch',
   'imorph:suggestions:create-test', 'imorph:suggestions:mark-duplicate', 'imorph:suggestions:defer-resume', 'imorph:suggestions:reject',
   'imorph:suggestions:reopen', 'imorph:suggestions:complete', 'imorph:insights-performance:read', 'imorph:insights-topic:read',
   'imorph:insights-cx:read', 'imorph:insights-conversation-detail:read'),
   1, 0, 10, 0, 'system', 'system'),
  ('tpl-3002', 'imorph', 'iMorph-Admin', 'Admin', '租户管理员（业务功能全量 126 权限点）',
   JSON_ARRAY('imorph:agent:read', 'imorph:agent:create', 'imorph:agent:edit', 'imorph:agent:delete',
   'imorph:knowledge:read', 'imorph:knowledge:create-content', 'imorph:knowledge:upload-document', 'imorph:knowledge:edit-content',
   'imorph:knowledge:edit-tags', 'imorph:knowledge:delete', 'imorph:knowledge:download-source', 'imorph:knowledge:configure-index',
   'imorph:knowledge-folder:create', 'imorph:knowledge-folder:move', 'imorph:knowledge-folder:delete', 'imorph:knowledge-sync:read',
   'imorph:knowledge-sync:create', 'imorph:knowledge-sync:resync', 'imorph:knowledge-sync:delete', 'imorph:knowledge-preview:run',
   'imorph:knowledge-preview:read-log', 'imorph:build-guidelines:read', 'imorph:build-guidelines:create', 'imorph:build-guidelines:edit',
   'imorph:build-guidelines:delete', 'imorph:build-journey:read', 'imorph:build-journey:create', 'imorph:build-journey:edit',
   'imorph:build-journey:set-active', 'imorph:build-journey:delete', 'imorph:build-relationship:read', 'imorph:build-relationship:create',
   'imorph:build-relationship:edit', 'imorph:build-relationship:delete', 'imorph:build-observation:read', 'imorph:build-observation:create',
   'imorph:build-observation:edit', 'imorph:build-observation:delete', 'imorph:build-variables:read', 'imorph:build-variables:create',
   'imorph:build-variables:edit', 'imorph:build-variables:delete', 'imorph:build-canned-response:read', 'imorph:build-canned-response:create',
   'imorph:build-canned-response:edit', 'imorph:build-canned-response:delete', 'imorph:build-retrievers:read', 'imorph:build-retrievers:create',
   'imorph:build-retrievers:edit', 'imorph:build-retrievers:delete', 'imorph:build-glossary:read', 'imorph:build-glossary:create',
   'imorph:build-glossary:edit', 'imorph:build-glossary:delete', 'imorph:build-tools:read', 'imorph:build-tools:create',
   'imorph:build-tools:edit', 'imorph:build-tools:delete', 'imorph:build-tools:test', 'imorph:build-tags:read',
   'imorph:build-tags:create', 'imorph:build-tags:edit', 'imorph:build-tags:delete', 'imorph:build-runtime-config:read',
   'imorph:build-runtime-config:edit', 'imorph:build-fallback-response:read', 'imorph:build-fallback-response:edit', 'imorph:build-ai-check:read',
   'imorph:build-ai-check:run', 'imorph:build-ai-check:handle-suggestion', 'imorph:build-agent-config:read-full', 'imorph:build-agent-config:import-append',
   'imorph:build-agent-config:import-overwrite', 'imorph:build-agent-config:export', 'imorph:build-agent-config:publish', 'imorph:build-agent-config:read-history',
   'imorph:build-agent-config:rollback', 'imorph:preview-text:run', 'imorph:preview-voice:run', 'imorph:preview-web-widget:run',
   'imorph:preview-runtime:inspect', 'imorph:preview-self-play:read', 'imorph:preview-self-play:create', 'imorph:preview-self-play:edit',
   'imorph:preview-self-play:delete', 'imorph:preview-self-play:run', 'imorph:preview-self-play:read-result', 'imorph:test-groups:read',
   'imorph:test-groups:create', 'imorph:test-groups:edit', 'imorph:test-groups:delete', 'imorph:test-questions:read',
   'imorph:test-questions:create', 'imorph:test-questions:generate', 'imorph:test-questions:import', 'imorph:test-questions:delete',
   'imorph:test-evaluate-answer:read', 'imorph:test-evaluate-answer:run', 'imorph:test-evaluate-answer:rate', 'imorph:deploy-channel-settings:read',
   'imorph:deploy-channel-settings:edit-widget', 'imorph:deploy-channel-settings:edit-voice', 'imorph:deploy-channel-settings:toggle', 'imorph:deploy-runtime-guardrails:edit',
   'imorph:deploy-phone-number:purchase-assign', 'imorph:deploy-deployment:deploy', 'imorph:deploy-deployment:pause', 'imorph:deploy-deployment:resume',
   'imorph:deploy-history:read', 'imorph:deploy-history:restore-draft', 'imorph:deploy-history:rollback-live', 'imorph:monitor-conversations:read',
   'imorph:monitor-logs:read', 'imorph:monitor-logs:sync', 'imorph:suggestions:read', 'imorph:suggestions:create-patch',
   'imorph:suggestions:create-test', 'imorph:suggestions:mark-duplicate', 'imorph:suggestions:defer-resume', 'imorph:suggestions:reject',
   'imorph:suggestions:reopen', 'imorph:suggestions:complete', 'imorph:insights-performance:read', 'imorph:insights-topic:read',
   'imorph:insights-cx:read', 'imorph:insights-conversation-detail:read'),
   0, 1, 20, 0, 'system', 'system'),
  ('tpl-3003', 'imorph', 'iMorph-Member', 'Member', '租户成员（读/建/编/运行；不授删除/发布部署回滚/导出下载/号码购买/渠道启停/覆盖导入）',
   JSON_ARRAY('imorph:agent:read', 'imorph:agent:create', 'imorph:agent:edit', 'imorph:knowledge:read',
   'imorph:knowledge:create-content', 'imorph:knowledge:upload-document', 'imorph:knowledge:edit-content', 'imorph:knowledge:edit-tags',
   'imorph:knowledge:configure-index', 'imorph:knowledge-folder:create', 'imorph:knowledge-folder:move', 'imorph:knowledge-sync:read',
   'imorph:knowledge-sync:create', 'imorph:knowledge-sync:resync', 'imorph:knowledge-preview:run', 'imorph:knowledge-preview:read-log',
   'imorph:build-guidelines:read', 'imorph:build-guidelines:create', 'imorph:build-guidelines:edit', 'imorph:build-journey:read',
   'imorph:build-journey:create', 'imorph:build-journey:edit', 'imorph:build-journey:set-active', 'imorph:build-relationship:read',
   'imorph:build-relationship:create', 'imorph:build-relationship:edit', 'imorph:build-observation:read', 'imorph:build-observation:create',
   'imorph:build-observation:edit', 'imorph:build-variables:read', 'imorph:build-variables:create', 'imorph:build-variables:edit',
   'imorph:build-canned-response:read', 'imorph:build-canned-response:create', 'imorph:build-canned-response:edit', 'imorph:build-retrievers:read',
   'imorph:build-retrievers:create', 'imorph:build-retrievers:edit', 'imorph:build-glossary:read', 'imorph:build-glossary:create',
   'imorph:build-glossary:edit', 'imorph:build-tools:read', 'imorph:build-tools:create', 'imorph:build-tools:edit',
   'imorph:build-tools:test', 'imorph:build-tags:read', 'imorph:build-tags:create', 'imorph:build-tags:edit',
   'imorph:build-runtime-config:read', 'imorph:build-runtime-config:edit', 'imorph:build-fallback-response:read', 'imorph:build-fallback-response:edit',
   'imorph:build-ai-check:read', 'imorph:build-ai-check:run', 'imorph:build-ai-check:handle-suggestion', 'imorph:build-agent-config:read-full',
   'imorph:build-agent-config:import-append', 'imorph:build-agent-config:read-history', 'imorph:preview-text:run', 'imorph:preview-voice:run',
   'imorph:preview-web-widget:run', 'imorph:preview-runtime:inspect', 'imorph:preview-self-play:read', 'imorph:preview-self-play:create',
   'imorph:preview-self-play:edit', 'imorph:preview-self-play:run', 'imorph:preview-self-play:read-result', 'imorph:test-groups:read',
   'imorph:test-groups:create', 'imorph:test-groups:edit', 'imorph:test-questions:read', 'imorph:test-questions:create',
   'imorph:test-questions:generate', 'imorph:test-questions:import', 'imorph:test-evaluate-answer:read', 'imorph:test-evaluate-answer:run',
   'imorph:test-evaluate-answer:rate', 'imorph:deploy-channel-settings:read', 'imorph:deploy-channel-settings:edit-widget', 'imorph:deploy-channel-settings:edit-voice',
   'imorph:deploy-runtime-guardrails:edit', 'imorph:deploy-history:read', 'imorph:deploy-history:restore-draft', 'imorph:monitor-conversations:read',
   'imorph:monitor-logs:read', 'imorph:monitor-logs:sync', 'imorph:suggestions:read', 'imorph:suggestions:create-patch',
   'imorph:suggestions:create-test', 'imorph:suggestions:mark-duplicate', 'imorph:suggestions:defer-resume', 'imorph:suggestions:reject',
   'imorph:suggestions:reopen', 'imorph:suggestions:complete', 'imorph:insights-performance:read', 'imorph:insights-topic:read',
   'imorph:insights-cx:read', 'imorph:insights-conversation-detail:read'),
   0, 0, 30, 0, 'system', 'system')
ON DUPLICATE KEY UPDATE
  `role_code` = VALUES(`role_code`), `role_name` = VALUES(`role_name`),
  `role_description` = VALUES(`role_description`), `permission_codes_json` = VALUES(`permission_codes_json`),
  `is_owner` = VALUES(`is_owner`), `is_admin` = VALUES(`is_admin`), `priority` = VALUES(`priority`);

-- G1 配额维度（imorph 应用专属：Members 10 / Apps 20；租户启用 imorph 后随 Usage 视图展示并按其强制）
INSERT IGNORE INTO `gateway_quota_dimension`
  (`dimension_id`, `app_code`, `dimension_key`, `dimension_name`, `unit`, `default_limit`, `source`, `sort_order`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('gd-3001', 'imorph', 'members', 'Members', NULL, 10, 'IAM', 10, 0, 'system', 'system'),
  ('gd-3002', 'imorph', 'apps', 'Apps', NULL, 20, 'IAM', 20, 0, 'system', 'system');

-- category（一级功能模块）存量回填：INSERT IGNORE 不刷新已存在行，此处幂等补偿（数据源自权限矩阵 xlsx 一级模块列）
UPDATE `gateway_permission` SET `category` = CASE `permission_code`
    WHEN 'imorph:agent:create' THEN 'Agent Management'
    WHEN 'imorph:agent:delete' THEN 'Agent Management'
    WHEN 'imorph:agent:edit' THEN 'Agent Management'
    WHEN 'imorph:agent:read' THEN 'Agent Management'
    WHEN 'imorph:build-agent-config:export' THEN 'Build'
    WHEN 'imorph:build-agent-config:import-append' THEN 'Build'
    WHEN 'imorph:build-agent-config:import-overwrite' THEN 'Build'
    WHEN 'imorph:build-agent-config:publish' THEN 'Build'
    WHEN 'imorph:build-agent-config:read-full' THEN 'Build'
    WHEN 'imorph:build-agent-config:read-history' THEN 'Build'
    WHEN 'imorph:build-agent-config:rollback' THEN 'Build'
    WHEN 'imorph:build-ai-check:handle-suggestion' THEN 'Build'
    WHEN 'imorph:build-ai-check:read' THEN 'Build'
    WHEN 'imorph:build-ai-check:run' THEN 'Build'
    WHEN 'imorph:build-canned-response:create' THEN 'Build'
    WHEN 'imorph:build-canned-response:delete' THEN 'Build'
    WHEN 'imorph:build-canned-response:edit' THEN 'Build'
    WHEN 'imorph:build-canned-response:read' THEN 'Build'
    WHEN 'imorph:build-fallback-response:edit' THEN 'Build'
    WHEN 'imorph:build-fallback-response:read' THEN 'Build'
    WHEN 'imorph:build-glossary:create' THEN 'Build'
    WHEN 'imorph:build-glossary:delete' THEN 'Build'
    WHEN 'imorph:build-glossary:edit' THEN 'Build'
    WHEN 'imorph:build-glossary:read' THEN 'Build'
    WHEN 'imorph:build-guidelines:create' THEN 'Build'
    WHEN 'imorph:build-guidelines:delete' THEN 'Build'
    WHEN 'imorph:build-guidelines:edit' THEN 'Build'
    WHEN 'imorph:build-guidelines:read' THEN 'Build'
    WHEN 'imorph:build-journey:create' THEN 'Build'
    WHEN 'imorph:build-journey:delete' THEN 'Build'
    WHEN 'imorph:build-journey:edit' THEN 'Build'
    WHEN 'imorph:build-journey:read' THEN 'Build'
    WHEN 'imorph:build-journey:set-active' THEN 'Build'
    WHEN 'imorph:build-observation:create' THEN 'Build'
    WHEN 'imorph:build-observation:delete' THEN 'Build'
    WHEN 'imorph:build-observation:edit' THEN 'Build'
    WHEN 'imorph:build-observation:read' THEN 'Build'
    WHEN 'imorph:build-relationship:create' THEN 'Build'
    WHEN 'imorph:build-relationship:delete' THEN 'Build'
    WHEN 'imorph:build-relationship:edit' THEN 'Build'
    WHEN 'imorph:build-relationship:read' THEN 'Build'
    WHEN 'imorph:build-retrievers:create' THEN 'Build'
    WHEN 'imorph:build-retrievers:delete' THEN 'Build'
    WHEN 'imorph:build-retrievers:edit' THEN 'Build'
    WHEN 'imorph:build-retrievers:read' THEN 'Build'
    WHEN 'imorph:build-runtime-config:edit' THEN 'Build'
    WHEN 'imorph:build-runtime-config:read' THEN 'Build'
    WHEN 'imorph:build-tags:create' THEN 'Build'
    WHEN 'imorph:build-tags:delete' THEN 'Build'
    WHEN 'imorph:build-tags:edit' THEN 'Build'
    WHEN 'imorph:build-tags:read' THEN 'Build'
    WHEN 'imorph:build-tools:create' THEN 'Build'
    WHEN 'imorph:build-tools:delete' THEN 'Build'
    WHEN 'imorph:build-tools:edit' THEN 'Build'
    WHEN 'imorph:build-tools:read' THEN 'Build'
    WHEN 'imorph:build-tools:test' THEN 'Build'
    WHEN 'imorph:build-variables:create' THEN 'Build'
    WHEN 'imorph:build-variables:delete' THEN 'Build'
    WHEN 'imorph:build-variables:edit' THEN 'Build'
    WHEN 'imorph:build-variables:read' THEN 'Build'
    WHEN 'imorph:deploy-channel-settings:edit-voice' THEN 'Deploy'
    WHEN 'imorph:deploy-channel-settings:edit-widget' THEN 'Deploy'
    WHEN 'imorph:deploy-channel-settings:read' THEN 'Deploy'
    WHEN 'imorph:deploy-channel-settings:toggle' THEN 'Deploy'
    WHEN 'imorph:deploy-deployment:deploy' THEN 'Deploy'
    WHEN 'imorph:deploy-deployment:pause' THEN 'Deploy'
    WHEN 'imorph:deploy-deployment:resume' THEN 'Deploy'
    WHEN 'imorph:deploy-history:read' THEN 'Deploy'
    WHEN 'imorph:deploy-history:restore-draft' THEN 'Deploy'
    WHEN 'imorph:deploy-history:rollback-live' THEN 'Deploy'
    WHEN 'imorph:deploy-phone-number:purchase-assign' THEN 'Deploy'
    WHEN 'imorph:deploy-runtime-guardrails:edit' THEN 'Deploy'
    WHEN 'imorph:insights-conversation-detail:read' THEN 'Insights'
    WHEN 'imorph:insights-cx:read' THEN 'Insights'
    WHEN 'imorph:insights-performance:read' THEN 'Insights'
    WHEN 'imorph:insights-topic:read' THEN 'Insights'
    WHEN 'imorph:knowledge-folder:create' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-folder:delete' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-folder:move' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-preview:read-log' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-preview:run' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-sync:create' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-sync:delete' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-sync:read' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge-sync:resync' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:configure-index' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:create-content' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:delete' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:download-source' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:edit-content' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:edit-tags' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:read' THEN 'KnowledgeHub'
    WHEN 'imorph:knowledge:upload-document' THEN 'KnowledgeHub'
    WHEN 'imorph:monitor-conversations:read' THEN 'Monitor'
    WHEN 'imorph:monitor-logs:read' THEN 'Monitor'
    WHEN 'imorph:monitor-logs:sync' THEN 'Monitor'
    WHEN 'imorph:preview-runtime:inspect' THEN 'Preview'
    WHEN 'imorph:preview-self-play:create' THEN 'Preview'
    WHEN 'imorph:preview-self-play:delete' THEN 'Preview'
    WHEN 'imorph:preview-self-play:edit' THEN 'Preview'
    WHEN 'imorph:preview-self-play:read' THEN 'Preview'
    WHEN 'imorph:preview-self-play:read-result' THEN 'Preview'
    WHEN 'imorph:preview-self-play:run' THEN 'Preview'
    WHEN 'imorph:preview-text:run' THEN 'Preview'
    WHEN 'imorph:preview-voice:run' THEN 'Preview'
    WHEN 'imorph:preview-web-widget:run' THEN 'Preview'
    WHEN 'imorph:suggestions:complete' THEN 'Suggestions'
    WHEN 'imorph:suggestions:create-patch' THEN 'Suggestions'
    WHEN 'imorph:suggestions:create-test' THEN 'Suggestions'
    WHEN 'imorph:suggestions:defer-resume' THEN 'Suggestions'
    WHEN 'imorph:suggestions:mark-duplicate' THEN 'Suggestions'
    WHEN 'imorph:suggestions:read' THEN 'Suggestions'
    WHEN 'imorph:suggestions:reject' THEN 'Suggestions'
    WHEN 'imorph:suggestions:reopen' THEN 'Suggestions'
    WHEN 'imorph:test-evaluate-answer:rate' THEN 'Test'
    WHEN 'imorph:test-evaluate-answer:read' THEN 'Test'
    WHEN 'imorph:test-evaluate-answer:run' THEN 'Test'
    WHEN 'imorph:test-groups:create' THEN 'Test'
    WHEN 'imorph:test-groups:delete' THEN 'Test'
    WHEN 'imorph:test-groups:edit' THEN 'Test'
    WHEN 'imorph:test-groups:read' THEN 'Test'
    WHEN 'imorph:test-questions:create' THEN 'Test'
    WHEN 'imorph:test-questions:delete' THEN 'Test'
    WHEN 'imorph:test-questions:generate' THEN 'Test'
    WHEN 'imorph:test-questions:import' THEN 'Test'
    WHEN 'imorph:test-questions:read' THEN 'Test'
    ELSE `category` END WHERE `app_code` = 'imorph';

-- 2026-10-30 iMorph-Owner 模板 +6 个 iam:* 权限（NOT JSON_CONTAINS 守卫，可重复执行）
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:member:read')
    WHERE `template_id` = 'tpl-3001' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:member:read"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:member:write')
    WHERE `template_id` = 'tpl-3001' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:member:write"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:role:read')
    WHERE `template_id` = 'tpl-3001' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:role:read"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:role:write')
    WHERE `template_id` = 'tpl-3001' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:role:write"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:apps:read')
    WHERE `template_id` = 'tpl-3001' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:apps:read"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:apps:write')
    WHERE `template_id` = 'tpl-3001' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:apps:write"');
-- 2026-10-30 iMorph-Owner 权限集增强存量修正：所有 TENANT 作用域 iMorph-Owner 角色补绑 6 个 iam:* 权限
-- （INSERT IGNORE 只灌新租户；本段幂等覆盖存量租户，MD5 生成 32 位 role_permission_id）
INSERT IGNORE INTO `gateway_role_permission`
  (`role_permission_id`, `role_id`, `permission_id`, `delete_flag`, `create_by`, `update_by`)
SELECT MD5(CONCAT(r.role_id, p.permission_id)), r.role_id, p.permission_id, 0, 'system', 'system'
FROM `gateway_role` r
JOIN `gateway_permission` p
  ON p.permission_code IN ('iam:member:read', 'iam:member:write', 'iam:role:read', 'iam:role:write',
                           'iam:apps:read', 'iam:apps:write')
 AND p.delete_flag = 0
WHERE r.role_code = 'iMorph-Owner' AND r.scope_type = 'TENANT' AND r.delete_flag = 0;

-- 2026-11-03 iMorph-Admin / iMorph-Member 模板补 iam:member:read + iam:role:read（只读管理面入口；
-- NOT JSON_CONTAINS 守卫，可重复执行；INSERT IGNORE 只灌新租户，存量行由本段 APPEND 覆盖）
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:member:read')
    WHERE `template_id` = 'tpl-3002' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:member:read"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:role:read')
    WHERE `template_id` = 'tpl-3002' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:role:read"');
-- 2026-11-06 iMorph-Admin 补 iam:apps:read（应用目录只读；Owner 已有，Member 不补）
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:apps:read')
    WHERE `template_id` = 'tpl-3002' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:apps:read"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:member:read')
    WHERE `template_id` = 'tpl-3003' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:member:read"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:role:read')
    WHERE `template_id` = 'tpl-3003' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:role:read"');
-- 存量修正：所有 TENANT 作用域 iMorph-Admin / iMorph-Member 角色补绑这 2 个只读权限
-- （Owner 的 6 权限回填见上段；MD5 生成 32 位 role_permission_id，幂等）
INSERT IGNORE INTO `gateway_role_permission`
  (`role_permission_id`, `role_id`, `permission_id`, `delete_flag`, `create_by`, `update_by`)
SELECT MD5(CONCAT(r.role_id, p.permission_id)), r.role_id, p.permission_id, 0, 'system', 'system'
FROM `gateway_role` r
JOIN `gateway_permission` p
  ON p.permission_code IN ('iam:member:read', 'iam:role:read')
 AND p.delete_flag = 0
WHERE r.role_code IN ('iMorph-Admin', 'iMorph-Member') AND r.scope_type = 'TENANT' AND r.delete_flag = 0;
-- 2026-11-06 存量修正：iMorph-Admin 角色补绑 iam:apps:read（同上幂等口径）
INSERT IGNORE INTO `gateway_role_permission`
  (`role_permission_id`, `role_id`, `permission_id`, `delete_flag`, `create_by`, `update_by`)
SELECT MD5(CONCAT(r.role_id, p.permission_id)), r.role_id, p.permission_id, 0, 'system', 'system'
FROM `gateway_role` r
JOIN `gateway_permission` p
  ON p.permission_code = 'iam:apps:read'
 AND p.delete_flag = 0
WHERE r.role_code = 'iMorph-Admin' AND r.scope_type = 'TENANT' AND r.delete_flag = 0;

-- 2026-11-06 Tenant role creation is available to iMorph-Admin as well as Owner.
-- Keep Member read-only; repair both new templates and existing tenant role bindings.
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:role:write')
    WHERE `template_id` = 'tpl-3002' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:role:write"');

INSERT INTO `gateway_role_permission`
  (`role_permission_id`, `role_id`, `permission_id`, `delete_flag`, `create_by`, `update_by`)
SELECT MD5(CONCAT(r.role_id, p.permission_id)), r.role_id, p.permission_id, 0, 'system', 'system'
FROM `gateway_role` r
JOIN `gateway_permission` p
  ON p.permission_code = 'iam:role:write' AND p.delete_flag = 0
WHERE r.role_code = 'iMorph-Admin' AND r.scope_type = 'TENANT' AND r.delete_flag = 0
ON DUPLICATE KEY UPDATE `delete_flag` = 0, `update_by` = 'system';

package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

/** 注册请求：{@code POST /api/v1/auth/register}。 */
public record RegisterRequest(
        @NotBlank(message = "username 不能为空") String username,
        String email,
        @NotBlank(message = "password 不能为空") String password,
        /** 可选：从业务应用（如 parlant）跳入注册时带 app_code，注册后给个人租户授该应用 is_owner 角色 */
        @JsonProperty("app_codes") List<String> appCodes) {
}

package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.auth.LoginTarget;
import com.unify.iam.api.dto.auth.LoginTarget.*;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/** 跨身份、租户和应用域的登录后分流；每次解析重新检查授权数据。 */
@Service
public class LoginTargetService {
    private final MembershipResolver memberships;
    private final TenantApplicationRepository tenantApps;
    private final ApplicationRepository applications;
    private final TenantRepository tenants;
    private final RoleRepository roles;
    private final IamProperties props;

    public LoginTargetService(MembershipResolver memberships, TenantApplicationRepository tenantApps,
            ApplicationRepository applications, TenantRepository tenants, RoleRepository roles, IamProperties props) {
        this.memberships = memberships;
        this.tenantApps = tenantApps;
        this.applications = applications;
        this.tenants = tenants;
        this.roles = roles;
        this.props = props;
    }

    public Catalog catalog(String userId) {
        List<MembershipPO> active = memberships.listByUser(userId).stream()
                .filter(m -> "ACTIVE".equals(m.getMembershipStatus())).toList();
        Map<String, List<Membership>> byApp = new LinkedHashMap<>();
        Map<String, List<String>> byTenant = new LinkedHashMap<>();
        for (MembershipPO m : active) {
            String tenantId = m.getTenantId().trim();
            var tenant = tenants.findById(tenantId).orElse(null);
            if (tenant == null || !"ACTIVE".equals(tenant.getTenantStatus())) continue;
            Membership brief = new Membership(m.getMembershipId().trim(), tenantId,
                    tenant.getTenantName(), tenant.getTenantCode());
            for (String code : byTenant.computeIfAbsent(tenantId, tenantApps::findAppCodesByTenant)) {
                if (!"iam".equals(code) && props.getJwt().getAudiences().contains(code)) {
                    byApp.computeIfAbsent(code, ignored -> new ArrayList<>()).add(brief);
                }
            }
        }
        List<Application> available = applications.findActiveByCodes(byApp.keySet()).stream()
                .map(a -> new Application(a.getAppCode().trim(), a.getAppName(), homepage(a),
                        List.copyOf(byApp.get(a.getAppCode().trim()))))
                .sorted(java.util.Comparator.comparing(Application::appCode)).toList();
        boolean admin = active.stream().anyMatch(m -> roles.hasPlatformRoleByMembership(m.getMembershipId().trim()));
        return new Catalog(available, admin);
    }

    public Resolution resolve(JwtClaims claims, LoginTarget.Request request) {
        Catalog catalog = catalog(claims.userId());
        String appCode = clean(request.appCode());
        if (appCode == null) {
            if (clean(request.returnTo()) != null || clean(request.membershipId()) != null) {
                throw AuthException.badRequest(ErrorCode.RETURN_TARGET_APP_REQUIRED);
            }
            if (catalog.applications().isEmpty()) return result(catalog.isPlatformAdmin() ? Decision.IAM_CONSOLE : Decision.DENIED);
            return new Resolution(Decision.CHOOSE_APPLICATION, catalog.applications(), null, null, null);
        }
        Application app = catalog.applications().stream().filter(a -> a.appCode().equals(appCode)).findFirst().orElse(null);
        if (app == null) {
            return result(catalog.isPlatformAdmin() ? Decision.IAM_CONSOLE : Decision.DENIED);
        }
        // 回跳地址先于选租户校验，错误输入不会被带入后续会话。
        String callback = callback(app, clean(request.returnTo()));
        String selectedId = clean(request.membershipId());
        Membership selected;
        if (selectedId != null) {
            selected = app.memberships().stream().filter(m -> m.membershipId().equals(selectedId)).findFirst()
                    .orElseThrow(() -> AuthException.forbidden(ErrorCode.APP_MEMBERSHIP_FORBIDDEN));
        } else if (app.memberships().size() == 1) {
            selected = app.memberships().getFirst();
        } else {
            return new Resolution(Decision.CHOOSE_TENANT, null, app.memberships(), null, null);
        }
        if (!selected.membershipId().equals(claims.membershipId()) || !selected.tenantId().equals(claims.tenantId())) {
            return new Resolution(Decision.SWITCH_TENANT, null, null, selected, null);
        }
        if (!claims.aud().contains(appCode)) {
            throw AuthException.forbidden(ErrorCode.TOKEN_APP_MISMATCH);
        }
        return new Resolution(Decision.REDIRECT, null, null, selected, callback);
    }

    private Resolution result(Decision decision) {
        return new Resolution(decision, null, null, null, null);
    }

    private String homepage(ApplicationPO app) {
        String db = clean(app.getHomepageUrl());
        return db == null ? clean(props.getAppHomepages().get(app.getAppCode().trim())) : db;
    }

    private String callback(Application app, String requested) {
        String home = app.homepageUrl();
        if (home == null) throw AuthException.serviceUnavailable(ErrorCode.APP_HOMEPAGE_MISSING);
        URI base;
        try { base = httpUri(home); }
        catch (IllegalArgumentException e) { throw AuthException.serviceUnavailable(ErrorCode.APP_HOMEPAGE_INVALID); }
        URI target;
        try { target = httpUri(requested == null ? home : requested); }
        catch (IllegalArgumentException e) { throw AuthException.badRequest(ErrorCode.RETURN_URL_INVALID); }
        String origin = origin(target);
        boolean globalAllowed = props.getOidc().getAllowedReturnOrigins().stream().anyMatch(value -> sameOrigin(value, origin));
        boolean appAllowed = origin(base).equals(origin)
                || props.getAppReturnOrigins().getOrDefault(app.appCode(), List.of()).stream()
                        .anyMatch(value -> sameOrigin(value, origin));
        if (!globalAllowed || !appAllowed) throw AuthException.badRequest(ErrorCode.RETURN_ORIGIN_NOT_ALLOWED);
        return target.toASCIIString();
    }

    private static URI httpUri(String value) {
        URI uri = URI.create(value);
        if (!("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))
                || uri.getHost() == null || uri.getRawUserInfo() != null) throw new IllegalArgumentException();
        return uri;
    }

    private static boolean sameOrigin(String configured, String origin) {
        try { return origin(httpUri(configured)).equals(origin); }
        catch (IllegalArgumentException e) { return false; }
    }

    private static String origin(URI uri) {
        String scheme = uri.getScheme().toLowerCase(java.util.Locale.ROOT);
        int port = uri.getPort();
        if (port == ("https".equals(scheme) ? 443 : 80)) port = -1;
        return scheme + "://" + uri.getHost().toLowerCase(java.util.Locale.ROOT) + (port < 0 ? "" : ":" + port);
    }

    private static String clean(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}

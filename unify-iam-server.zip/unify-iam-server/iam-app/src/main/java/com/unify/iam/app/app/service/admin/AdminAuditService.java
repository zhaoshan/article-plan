package com.unify.iam.app.app.service.admin;

import com.unify.iam.app.infra.persistence.po.AuditLogPO;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

/**
 * 管理面审计查询（docs/04 §3.2，iam:audit:read）。
 *
 * <p>平台管理员专属（docs/06 §B.3：租户 TenantAdmin 不授 iam:audit:read），
 * 支持按租户/事件/操作人过滤（docs/05 Audit 页）。
 *
 * <p>列表做**名称富化**（G5 可用性）：事件名、操作人用户名、目标名称（用户/租户/成员/角色），
 * 批量反查避免 N+1；目标实体已删除时回退展示 id。
 */
@Service
public class AdminAuditService {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;
    private final TenantRepository tenantRepository;
    private final MembershipRepository membershipRepository;
    private final RoleRepository roleRepository;

    public AdminAuditService(AuditLogRepository auditLogRepository,
                             UserRepository userRepository,
                             TenantRepository tenantRepository,
                             MembershipRepository membershipRepository,
                             RoleRepository roleRepository) {
        this.auditLogRepository = auditLogRepository;
        this.userRepository = userRepository;
        this.tenantRepository = tenantRepository;
        this.membershipRepository = membershipRepository;
        this.roleRepository = roleRepository;
    }

    /** 事件目录（code + 名称），供筛选下拉。 */
    public List<Map<String, String>> events() {
        return AuditEventCatalog.all();
    }

    /** 匹配记录总数（分页 total）。 */
    public long count(String tenantId, String eventType, String actorUserId) {
        return auditLogRepository.count(tenantId, eventType, actorUserId);
    }

    /** 审计列表（富化后，分页）。 */
    public List<Map<String, Object>> list(String tenantId, String eventType, String actorUserId, int page, int size) {
        List<AuditLogPO> rows = auditLogRepository.list(tenantId, eventType, actorUserId, page, size);

        Set<String> userIds = new HashSet<>();
        Set<String> tenantIds = new HashSet<>();
        Set<String> membershipIds = new HashSet<>();
        Set<String> roleIds = new HashSet<>();
        for (AuditLogPO a : rows) {
            add(userIds, a.getActorUserId());
            add(tenantIds, a.getTenantId());
            String id = a.getTargetId();
            String type = a.getTargetType();
            if (id != null && type != null) {
                switch (type) {
                    case "USER" -> add(userIds, id);
                    case "TENANT" -> add(tenantIds, id);
                    case "MEMBERSHIP" -> add(membershipIds, id);
                    case "ROLE" -> add(roleIds, id);
                    default -> { }
                }
            }
        }
        List<MembershipPO> memberships = membershipRepository.findByIds(membershipIds);
        memberships.forEach(m -> add(userIds, m.getUserId()));

        Map<String, UserPO> users = index(userRepository.findByIds(userIds), UserPO::getUserId);
        Map<String, TenantPO> tenants = index(tenantRepository.findByIds(tenantIds), TenantPO::getTenantId);
        Map<String, MembershipPO> membershipMap = index(memberships, MembershipPO::getMembershipId);
        Map<String, RolePO> roles = index(roleRepository.findByIds(roleIds), RolePO::getRoleId);

        List<Map<String, Object>> out = new ArrayList<>(rows.size());
        for (AuditLogPO a : rows) {
            Map<String, Object> m = new LinkedHashMap<>();
            String tenantIdVal = trim(a.getTenantId());
            // tenant_id 列为空（如成员移除/审批）且目标为 MEMBERSHIP → 由成员推导展示租户
            if (tenantIdVal == null && "MEMBERSHIP".equals(a.getTargetType()) && a.getTargetId() != null) {
                MembershipPO targetMember = membershipMap.get(trim(a.getTargetId()));
                if (targetMember != null) {
                    tenantIdVal = trim(targetMember.getTenantId());
                }
            }
            String actorId = trim(a.getActorUserId());
            m.put("audit_log_id", a.getAuditLogId());
            m.put("tenant_id", tenantIdVal);
            m.put("tenant_name", tenantName(tenants, tenantIdVal));
            m.put("actor_user_id", actorId);
            m.put("actor_username", username(users, actorId));
            m.put("actor_membership_id", a.getActorMembershipId());
            m.put("event_type", a.getEventType());
            m.put("event_name", AuditEventCatalog.nameOf(a.getEventType()));
            m.put("target_type", a.getTargetType());
            m.put("target_id", a.getTargetId());
            m.put("target_display", targetDisplay(a.getTargetType(), a.getTargetId(), users, tenants, membershipMap, roles));
            m.put("result_status", a.getResultStatus());
            m.put("request_id", a.getRequestId());
            m.put("ip_address", a.getIpAddress());
            m.put("user_agent", a.getUserAgent());
            m.put("before_json", a.getBeforeJson());
            m.put("after_json", a.getAfterJson());
            m.put("metadata_json", a.getMetadataJson());
            m.put("trace_id", a.getTraceId());
            m.put("create_time", a.getCreateTime() == null
                    ? null : a.getCreateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            out.add(m);
        }
        return out;
    }

    private String targetDisplay(String type, String rawId, Map<String, UserPO> users, Map<String, TenantPO> tenants,
                                 Map<String, MembershipPO> membershipMap, Map<String, RolePO> roles) {
        String id = trim(rawId);
        if (type == null || id == null) {
            return null;
        }
        return switch (type) {
            case "USER" -> orId(username(users, id), id);
            case "TENANT" -> orId(tenantName(tenants, id), id);
            case "MEMBERSHIP" -> {
                MembershipPO m = membershipMap.get(id);
                String name = m == null ? null : username(users, trim(m.getUserId()));
                yield orId(name, id);
            }
            case "ROLE" -> {
                RolePO r = roles.get(id);
                yield r == null ? id : r.getRoleCode() + "（" + r.getRoleName() + "）";
            }
            default -> id;
        };
    }

    private String username(Map<String, UserPO> users, String id) {
        UserPO u = id == null ? null : users.get(id);
        return u == null ? null : u.getUsername();
    }

    private String tenantName(Map<String, TenantPO> tenants, String id) {
        TenantPO t = id == null ? null : tenants.get(id);
        return t == null ? null : t.getTenantName();
    }

    private String orId(String name, String id) {
        return name != null ? name : id;
    }

    private static void add(Set<String> set, String raw) {
        String v = trim(raw);
        if (v != null) {
            set.add(v);
        }
    }

    private static String trim(String v) {
        if (v == null) {
            return null;
        }
        String t = v.trim();
        return t.isEmpty() ? null : t;
    }

    private static <T> Map<String, T> index(List<T> list, Function<T, String> keyFn) {
        return list.stream().collect(Collectors.toMap(t -> keyFn.apply(t).trim(), Function.identity(), (a, b) -> a));
    }
}

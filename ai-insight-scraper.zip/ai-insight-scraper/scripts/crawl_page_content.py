# -*- coding: utf-8 -*-
"""
爬取 Excel 中 I=Y 的页面内容/PDF 脚本

功能：
1. 读取 all_links_tag_result.xlsx，筛选 I 列为 Y 的行
2. 对 PDF 链接：用浏览器打开后下载 PDF 文件
3. 对 HTML 链接：用浏览器打开，保存 HTML 并转换为 Markdown
4. 按「域名+路径」规则生成存储目录名，保存到 page_content/
5. 在 page_content/ 根目录保存 metadata.jsonl 元数据
6. 在 Excel 中写入 N 列（爬取时间）和 O 列（内容 hash）

目录命名规则：
  去掉协议头，去掉 ? 后参数，将 / 和 . 替换为 _
  例: https://www.tokyostarbank.co.jp/account/feature/3step.html
      → www_tokyostarbank_co_jp_account_feature_3step_html

用法：
    # CDP 模式（连接已运行的 Chrome，推荐）
    python -m app.scripts.crawl_page_content

    # 本地 Chromium 模式
    python -m app.scripts.crawl_page_content --local-chromium

    # 显示浏览器窗口（调试用）
    python -m app.scripts.crawl_page_content --local-chromium --visible

    # 从指定行号继续（断点续查）
    python -m app.scripts.crawl_page_content --start-row 100

    # 指定 Excel 文件路径
    python -m app.scripts.crawl_page_content --excel path/to/file.xlsx
"""

import asyncio
import hashlib
import json
import logging
import os
import random
import re
import sys
import argparse
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List
from urllib.parse import urlparse

from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

# 确保项目根目录在 sys.path 中
_project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from app.utils.html_converter import HtmlConverter

# 解决 Windows 控制台 UTF-8 编码问题
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ==================== 常量配置 ====================

# Excel 文件路径
EXCEL_PATH = Path(__file__).parent.parent.parent.parent / "crawl_result" / "tsb" / "all_links_tag_result.xlsx"

# 输出根目录
OUTPUT_DIR = Path(__file__).parent.parent.parent.parent / "crawl_result" / "tsb" / "page_content"

# 排除标签配置文件
EXCLUDE_TAGS_CONFIG = Path(__file__).parent.parent.parent.parent / "crawl_result" / "tsb" / "exclude_tags.json"

# 浏览器 User-Agent
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)

# CDP 默认调试端口
CDP_DEBUG_PORT = 9222

# 页面超时时间（毫秒）
PAGE_TIMEOUT = 60000

# 等待动态内容加载时间（毫秒）
WAIT_DYNAMIC_MS = 3000

# Chromium 启动参数
CHROMIUM_ARGS = [
    '--disable-blink-features=AutomationControlled',
    '--disable-features=VizDisplayCompositor',
    '--disable-dev-shm-usage',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-software-rasterizer',
    '--disable-gpu',
]

# 定期保存间隔
SAVE_INTERVAL = 50

# ==================== 日志配置 ====================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ==================== 工具函数 ====================

def _find_chrome_path() -> str:
    """查找本地 Chrome 浏览器可执行文件路径"""
    import platform

    system = platform.system()
    if system == "Windows":
        paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
    elif system == "Darwin":
        paths = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        ]
    else:
        paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
        ]

    for path in paths:
        if os.path.exists(path):
            return path
    return ""


def compute_dedup_hash(text: str) -> str:
    """根据内容计算去重哈希"""
    normalized = "".join(text.split())  # 去空白/换行
    return "sha256:" + hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def is_pdf_url(url: str) -> bool:
    """判断 URL 是否指向 PDF 文件"""
    if not url:
        return False
    # 去掉查询参数和锚点后判断
    path = url.split("?")[0].split("#")[0]
    return path.lower().endswith(".pdf")


def is_html_like_url(url: str) -> bool:
    """判断 URL 是否应作为 HTML 页面爬取（.html/.htm 结尾，或无文件后缀）"""
    if not url:
        return True
    path = url.split("?")[0].split("#")[0]
    # 提取最后一个路径段的扩展名
    last_segment = path.rstrip("/").rsplit("/", 1)[-1] if path.rstrip("/") else ""
    if not last_segment:
        return True  # 无路径段，如 https://example.com
    if "." not in last_segment:
        return True  # 无后缀，如 https://example.com/page
    ext = last_segment.rsplit(".", 1)[-1].lower()
    return ext in ("html", "htm")


def ensure_https(url: str) -> str:
    """将 http:// 协议升级为 https://"""
    if url.startswith("http://"):
        return "https://" + url[7:]
    return url


def build_dir_name(url: str) -> str:
    """
    根据 URL 构建存储目录名

    规则：去掉协议头，去掉 ? 后参数，将 / 和 . 替换为 _
    例: https://www.tokyostarbank.co.jp/account/feature/3step.html
        → www_tokyostarbank_co_jp_account_feature_3step_html
    """
    parsed = urlparse(url)
    host = parsed.netloc
    path = parsed.path

    # 去掉查询参数
    path = path.split("?")[0].split("#")[0]

    # 去掉开头的 /
    path = path.lstrip("/")

    # 拼接域名+路径
    if path:
        full = f"{host}/{path}"
    else:
        full = host

    # 替换 / 和 . 为 _
    dir_name = full.replace("/", "_").replace(".", "_")

    # 去掉末尾的 _
    dir_name = dir_name.rstrip("_")

    return dir_name


def extract_filename_from_url(url: str) -> str:
    """
    从 URL 路径中提取文件名

    例: https://example.com/path/to/file.pdf → file.pdf
    """
    path = url.split("?")[0].split("#")[0]
    filename = path.rsplit("/", 1)[-1]
    if not filename:
        filename = f"page_{int(time.time())}"
    return filename


# ==================== PDF 下载 ====================

async def download_pdf_via_browser(page: Page, url: str, save_dir: Path,
                                   ctx: BrowserContext = None) -> Optional[str]:
    """
    下载 PDF 文件

    先导航到 PDF 所在的父页面建立会话，再在页面内通过 fetch API 下载 PDF。
    浏览器的 fetch 自动携带 cookie、走浏览器 SSL 通道，可解决 requests 的
    SSL 兼容性和 400 Bad Request 问题。

    下载后校验 PDF 魔数（%PDF），防止保存非 PDF 内容。

    Args:
        page: Playwright Page 对象
        url: PDF 链接
        save_dir: 保存目录
        ctx: Playwright BrowserContext 对象（备用）

    Returns:
        保存的文件名，失败返回 None
    """
    filename = extract_filename_from_url(url)
    if not filename.lower().endswith(".pdf"):
        filename += ".pdf"

    filepath = save_dir / filename

    try:
        # 先导航到父页面建立会话（去掉 PDF 文件名部分）
        parent_url = url.rsplit("/", 1)[0] + "/"
        try:
            await page.goto(parent_url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
            # 随机等待 2-4 秒
            await page.wait_for_timeout(random.randint(2000, 4000))
            logger.info(f"  已打开父页面建立会话: {parent_url}")
        except Exception as e:
            logger.warning(f"  打开父页面失败: {e}，尝试直接 fetch")

        # 在浏览器内用 fetch 请求 PDF
        body_base64 = await page.evaluate("""
            async (url) => {
                try {
                    const response = await fetch(url, { credentials: 'include' });
                    if (!response.ok) return { error: 'HTTP ' + response.status };
                    const buffer = await response.arrayBuffer();
                    const bytes = new Uint8Array(buffer);
                    let binary = '';
                    const chunkSize = 8192;
                    for (let i = 0; i < bytes.length; i += chunkSize) {
                        const chunk = bytes.subarray(i, i + chunkSize);
                        binary += String.fromCharCode.apply(null, chunk);
                    }
                    return { data: btoa(binary), size: bytes.length };
                } catch (e) {
                    return { error: e.message };
                }
            }
        """, url)

        if not body_base64:
            logger.warning(f"  PDF 下载失败（无返回）: {url}")
            return None

        if isinstance(body_base64, dict) and body_base64.get("error"):
            logger.error(f"  PDF 下载失败（fetch 错误）: {body_base64['error']}, {url}")
            return None

        # 解码 base64
        import base64
        body = base64.b64decode(body_base64["data"])

        if not body:
            logger.warning(f"  PDF 下载内容为空: {url}")
            return None

        # 校验 PDF 魔数
        if len(body) <= 4 or body[:4] != b"%PDF":
            logger.error(f"  下载内容不是有效 PDF（前4字节: {body[:4]!r}，大小: {len(body)} bytes），跳过: {url}")
            return None

        with open(filepath, "wb") as f:
            f.write(body)

        logger.info(f"  PDF 已下载: {filename} ({len(body)} bytes)")
        return filename

    except Exception as e:
        logger.error(f"  PDF 下载失败: {url}, 错误: {e}")
        return None


# ==================== 二进制资源下载 ====================

async def download_binary_via_browser(page: Page, url: str, save_dir: Path,
                                      ctx: BrowserContext = None) -> Optional[str]:
    """
    下载二进制资源文件（图片、文档等非 HTML 内容）

    使用 Playwright 原生 API（ctx.request.get）直接获取原始 bytes，
    共享浏览器 cookie/session，不会损坏二进制数据。

    Args:
        page: Playwright Page 对象
        url: 资源 URL
        save_dir: 保存目录
        ctx: Playwright BrowserContext 对象

    Returns:
        保存的文件名，失败返回 None
    """
    filename = extract_filename_from_url(url)
    if not filename or "." not in filename:
        # 无有效文件名时，使用 URL 路径最后一段
        path = url.split("?")[0].split("#")[0].rstrip("/")
        filename = path.rsplit("/", 1)[-1] if "/" in path else f"resource_{int(time.time())}"

    filepath = save_dir / filename

    try:
        if ctx is None:
            ctx = page.context

        response = await ctx.request.get(url, timeout=PAGE_TIMEOUT)
        if not response.ok:
            logger.error(f"  二进制资源下载失败: {url}, HTTP {response.status}")
            return None

        body = await response.body()
        if not body:
            logger.warning(f"  二进制资源下载内容为空: {url}")
            return None

        with open(filepath, "wb") as f:
            f.write(body)

        logger.info(f"  二进制资源已下载: {filename} ({len(body)} bytes)")
        return filename

    except Exception as e:
        logger.error(f"  二进制资源下载失败: {url}, 错误: {e}")
        return None


# ==================== HTML 爬取 ====================

async def fetch_html_content(page: Page, url: str) -> Optional[str]:
    """
    用浏览器打开页面，获取完整 HTML 内容

    Args:
        page: Playwright Page 对象
        url: 页面 URL

    Returns:
        HTML 字符串，失败返回 None
    """
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
        await page.wait_for_load_state("domcontentloaded", timeout=30000)
        # 随机等待 2-6 秒，等待动态内容加载
        delay_ms = random.randint(2000, 6000)
        await page.wait_for_timeout(delay_ms)

        html = await page.content()
        return html

    except Exception as e:
        logger.error(f"  页面打开失败: {url}, 错误: {e}")
        return None


def load_exclude_tags(config_path: Path) -> List[Dict]:
    """
    从配置文件加载需要排除的 DOM 标签规则

    Args:
        config_path: 配置文件路径

    Returns:
        排除规则列表，每项包含 tag/id/class 等字段
    """
    if not config_path.exists():
        logger.warning(f"排除标签配置文件不存在: {config_path}，将不做任何排除")
        return []
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        rules = config.get("exclude_tags", [])
        logger.info(f"已加载排除标签配置: {len(rules)} 条规则")
        return rules
    except Exception as e:
        logger.error(f"加载排除标签配置失败: {e}")
        return []


def remove_exclude_tags(soup: BeautifulSoup, exclude_rules: List[Dict]) -> int:
    """
    从 BeautifulSoup 对象中删除匹配排除规则的 DOM 标签

    匹配规则：
    - tag: 标签名（必填）
    - id: 匹配 id 属性（可选，精确匹配）
    - class: 匹配 class 属性（可选，精确匹配，标签可有多个 class 时只要包含即匹配）

    Args:
        soup: BeautifulSoup 对象
        exclude_rules: 排除规则列表

    Returns:
        删除的标签数量
    """
    removed = 0
    for rule in exclude_rules:
        tag_name = rule.get("tag", "")
        if not tag_name:
            continue

        rule_id = rule.get("id", "")
        rule_class = rule.get("class", "")

        # 先收集匹配的元素，再统一删除（避免遍历时修改集合）
        matched = []
        for element in soup.find_all(tag_name):
            match = True

            # 匹配 id
            if rule_id:
                elem_id = element.get("id", "")
                if elem_id != rule_id:
                    match = False

            # 匹配 class
            if rule_class and match:
                elem_classes = element.get("class", [])
                if isinstance(elem_classes, str):
                    elem_classes = elem_classes.split()
                if rule_class not in elem_classes:
                    match = False

            if match:
                matched.append(element)

        for element in matched:
            element.decompose()
            removed += 1

    return removed


def save_html_and_markdown(html_content: str, url: str, save_dir: Path,
                           exclude_rules: List[Dict] = None) -> str:
    """
    保存 HTML 和转换后的 Markdown 文件

    Args:
        html_content: HTML 字符串
        url: 页面 URL（用于 base_url 补全）
        save_dir: 保存目录
        exclude_rules: 需要排除的 DOM 标签规则列表

    Returns:
        HTML 内容的 hash 值
    """
    if exclude_rules is None:
        exclude_rules = []

    soup = BeautifulSoup(html_content, "html.parser")

    # 删除匹配排除规则的 DOM 标签
    removed = remove_exclude_tags(soup, exclude_rules)
    if removed > 0:
        logger.info(f"  已删除 {removed} 个排除标签")

    # 清理后的 HTML
    cleaned_html = str(soup)

    # 保存清理后的 HTML
    html_path = save_dir / "page.html"
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(cleaned_html)
    logger.info(f"  HTML 已保存: page.html ({len(cleaned_html)} chars)")

    # 转换为 Markdown（基于清理后的 HTML）
    markdown = HtmlConverter.html_to_markdown(soup, base_url=url)

    # 保存 Markdown
    md_path = save_dir / "page.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(markdown)
    logger.info(f"  Markdown 已保存: page.md ({len(markdown)} chars)")

    # 计算 HTML 内容 hash
    content_hash = compute_dedup_hash(cleaned_html)
    return content_hash


# ==================== 元数据管理 ====================

def append_metadata(metadata: Dict, output_dir: Path):
    """
    追加一条元数据记录到 metadata.jsonl

    如果该 URL 已存在，则更新 crawl_time 等字段，不重复插入。

    Args:
        metadata: 元数据字典
        output_dir: 输出根目录
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    meta_path = output_dir / "metadata.jsonl"

    # 读取已有记录，按 URL 去重
    existing_records = []
    url_set = set()
    if meta_path.exists():
        with open(meta_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                    existing_records.append(record)
                    url_set.add(record.get("url", ""))
                except json.JSONDecodeError:
                    existing_records.append({"_raw": line})

    url = metadata.get("url", "")
    if url in url_set:
        # URL 已存在，更新对应记录
        for i, record in enumerate(existing_records):
            if record.get("url") == url:
                existing_records[i] = metadata
                logger.info(f"  元数据已更新（URL 重复）: {url}")
                break
    else:
        # 新 URL，追加记录
        existing_records.append(metadata)

    # 重写整个文件
    with open(meta_path, "w", encoding="utf-8") as f:
        for record in existing_records:
            if "_raw" in record:
                f.write(record["_raw"] + "\n")
            else:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")


# ==================== 主流程 ====================

async def run_crawl(excel_path: str, use_cdp: bool = True, cdp_port: int = CDP_DEBUG_PORT,
                    headless: bool = True, start_row: int = 2):
    """
    主流程

    Args:
        excel_path: Excel 文件路径
        use_cdp: 是否使用 CDP 连接已运行的 Chrome
        cdp_port: CDP 调试端口
        headless: 是否无头模式
        start_row: 从第几行开始处理
    """
    import openpyxl

    excel_file = Path(excel_path)
    if not excel_file.exists():
        logger.error(f"Excel 文件不存在: {excel_file}")
        return

    # 1. 读取 Excel
    logger.info(f"正在读取 Excel 文件: {excel_file}")
    wb = openpyxl.load_workbook(excel_file)
    ws = wb.active
    max_row = ws.max_row
    logger.info(f"共 {max_row} 行数据")

    # 2. 筛选 I=Y 的行
    target_rows = []
    for row in range(start_row, max_row + 1):
        i_val = str(ws.cell(row=row, column=9).value or '').strip()
        if i_val == 'Y':
            n_val = ws.cell(row=row, column=14).value
            # 跳过已处理的行（N 列已有值）
            if n_val and str(n_val).strip():
                continue
            target_rows.append(row)

    total = len(target_rows)
    logger.info(f"I=Y 且未处理的行共 {total} 条")

    if total == 0:
        logger.info("无需处理，退出")
        wb.close()
        return

    # 3. 加载排除标签配置
    exclude_rules = load_exclude_tags(EXCLUDE_TAGS_CONFIG)

    # 4. 创建输出目录
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logger.info(f"输出目录: {OUTPUT_DIR}")

    # 5. 启动浏览器
    async with async_playwright() as p:
        browser = None
        cdp_browser = None
        ctx = None

        try:
            if use_cdp:
                cdp_url = f"http://127.0.0.1:{cdp_port}"
                logger.info(f"正在通过 CDP 连接已运行的 Chrome: {cdp_url}")
                cdp_browser = await p.chromium.connect_over_cdp(
                    endpoint_url=cdp_url,
                    timeout=30000,
                )
                contexts = cdp_browser.contexts
                if contexts:
                    ctx = contexts[0]
                    logger.info(f"已连接 Chrome，复用现有 context（共 {len(contexts)} 个）")
                else:
                    ctx = await cdp_browser.new_context(
                        viewport={"width": 1920, "height": 1080},
                        user_agent=USER_AGENT,
                    )
                    logger.info("已连接 Chrome，创建新 context")
            else:
                chrome_path = _find_chrome_path()
                if chrome_path:
                    logger.info(f"使用本地 Chrome: {chrome_path}")
                    browser = await p.chromium.launch(
                        executable_path=chrome_path,
                        headless=headless,
                        args=CHROMIUM_ARGS,
                    )
                else:
                    logger.info("使用 Playwright 自带的 Chromium")
                    browser = await p.chromium.launch(
                        headless=headless,
                        args=CHROMIUM_ARGS,
                    )
                ctx = await browser.new_context(
                    viewport={"width": 1920, "height": 1080},
                    user_agent=USER_AGENT,
                )

            page = await ctx.new_page()

            # 5. 逐个处理
            pdf_count = 0
            html_count = 0
            binary_count = 0
            fail_count = 0

            for idx, row in enumerate(target_rows):
                url = str(ws.cell(row=row, column=1).value or '').strip()
                if not url:
                    continue

                # http 升级为 https
                original_url = url
                url = ensure_https(url)
                if url != original_url:
                    logger.info(f"  URL 升级: {original_url} → {url}")

                dir_name = build_dir_name(url)
                save_dir = OUTPUT_DIR / dir_name
                save_dir.mkdir(parents=True, exist_ok=True)

                crawl_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                parsed = urlparse(url)
                domain = parsed.netloc

                logger.info(f"[{idx + 1}/{total}] Row {row}: {url}")

                if is_pdf_url(url):
                    # PDF 处理
                    filename = await download_pdf_via_browser(page, url, save_dir, ctx=ctx)
                    if filename:
                        pdf_count += 1
                        # 写入 Excel: N 列=爬取时间, O 列=空（PDF 不计算 hash）
                        ws.cell(row=row, column=14).value = crawl_time
                        ws.cell(row=row, column=15).value = ""

                        # 追加元数据
                        append_metadata({
                            "url": url,
                            "domain": domain,
                            "type": "pdf",
                            "dir_name": dir_name,
                            "save_path": f"{dir_name}/{filename}",
                            "crawl_time": crawl_time,
                            "content_hash": "",
                        }, OUTPUT_DIR)
                    else:
                        fail_count += 1
                elif not is_html_like_url(url):
                    # 二进制资源处理（图片、文档等）
                    filename = await download_binary_via_browser(page, url, save_dir, ctx=ctx)
                    if filename:
                        binary_count += 1

                        # 生成引用本地文件的 Markdown
                        markdown = f"![{filename}]({filename})"
                        md_path = save_dir / "page.md"
                        with open(md_path, "w", encoding="utf-8") as f:
                            f.write(markdown)
                        logger.info(f"  Markdown 已保存: page.md ({len(markdown)} chars)")

                        content_hash = compute_dedup_hash(markdown)

                        # 写入 Excel: N 列=爬取时间, O 列=hash
                        ws.cell(row=row, column=14).value = crawl_time
                        ws.cell(row=row, column=15).value = content_hash

                        # 追加元数据
                        append_metadata({
                            "url": url,
                            "domain": domain,
                            "type": "binary",
                            "dir_name": dir_name,
                            "save_path": f"{dir_name}/{filename}",
                            "crawl_time": crawl_time,
                            "content_hash": content_hash,
                        }, OUTPUT_DIR)
                    else:
                        fail_count += 1
                else:
                    # HTML 处理
                    html_content = await fetch_html_content(page, url)
                    if html_content:
                        content_hash = save_html_and_markdown(html_content, url, save_dir,
                                                              exclude_rules=exclude_rules)
                        html_count += 1

                        # 写入 Excel: N 列=爬取时间, O 列=hash
                        ws.cell(row=row, column=14).value = crawl_time
                        ws.cell(row=row, column=15).value = content_hash

                        # 追加元数据
                        append_metadata({
                            "url": url,
                            "domain": domain,
                            "type": "html",
                            "dir_name": dir_name,
                            "save_path": f"{dir_name}/page.html",
                            "crawl_time": crawl_time,
                            "content_hash": content_hash,
                        }, OUTPUT_DIR)
                    else:
                        fail_count += 1

                # 定期保存 Excel
                if (idx + 1) % SAVE_INTERVAL == 0:
                    wb.save(excel_file)
                    logger.info(f"已保存 Excel 进度（{idx + 1}/{total}）")

                # 页面间稍作等待
                await page.wait_for_timeout(1000)

            # 最终保存 Excel
            wb.save(excel_file)
            logger.info(f"处理完成！PDF={pdf_count}, HTML={html_count}, 二进制={binary_count}, 失败={fail_count}")

        except Exception as e:
            logger.error(f"处理过程出错: {e}")
            import traceback
            traceback.print_exc()
            try:
                wb.save(excel_file)
                logger.info(f"已保存部分结果到 {excel_file}")
            except Exception as save_err:
                logger.error(f"保存 Excel 失败: {save_err}")
        finally:
            if browser:
                try:
                    await browser.close()
                except Exception:
                    pass
            if cdp_browser:
                try:
                    await cdp_browser.close()
                except Exception:
                    pass
            wb.close()


def main():
    """脚本入口"""
    parser = argparse.ArgumentParser(description="爬取 Excel 中 I=Y 的页面内容/PDF")
    parser.add_argument(
        "--excel",
        type=str,
        default=str(EXCEL_PATH),
        help=f"Excel 文件路径（默认: {EXCEL_PATH}）",
    )
    parser.add_argument(
        "--local-chromium",
        action="store_true",
        help="使用本地 Playwright Chromium（默认通过 CDP 连接已运行的 Chrome）",
    )
    parser.add_argument(
        "--cdp-port",
        type=int,
        default=CDP_DEBUG_PORT,
        help=f"CDP 调试端口（默认 {CDP_DEBUG_PORT}）",
    )
    parser.add_argument(
        "--visible",
        action="store_true",
        help="显示浏览器窗口（仅 --local-chromium 模式生效，调试用）",
    )
    parser.add_argument(
        "--start-row",
        type=int,
        default=2,
        help="从第几行开始处理（默认 2，跳过表头；可用于断点续查）",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=60,
        help="页面超时秒数（默认 60）",
    )

    args = parser.parse_args()

    global PAGE_TIMEOUT
    PAGE_TIMEOUT = args.timeout * 1000

    use_cdp = not args.local_chromium
    headless = not args.visible

    asyncio.run(run_crawl(
        excel_path=args.excel,
        use_cdp=use_cdp,
        cdp_port=args.cdp_port,
        headless=headless,
        start_row=args.start_row,
    ))


if __name__ == "__main__":
    main()

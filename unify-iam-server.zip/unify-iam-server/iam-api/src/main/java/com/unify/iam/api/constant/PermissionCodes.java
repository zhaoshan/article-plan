package com.unify.iam.api.constant;

/** 权限点目录：与 parlant-agent {@code permissions.py} 及 {@code gateway_permission} 同套 code（E2E-1 范围文档 §4.2）。 */
public final class PermissionCodes {

    private PermissionCodes() {
    }

    /** 查看 Agent 定义/版本/旅程布局 */
    public static final String AGENT_READ = "agent:read";
    /** 新建/存草稿、旅程布局编辑 */
    public static final String AGENT_BUILD = "agent:build";
    /** 发布 */
    public static final String AGENT_PUBLISH = "agent:publish";
    /** 删除/卸载/回滚/删版本 */
    public static final String AGENT_DELETE = "agent:delete";
    /** 会话/消息历史查看（含 SSE 事件流） */
    public static final String SESSION_READ = "session:read";
    /** 建会话/发事件/关/删会话 */
    public static final String SESSION_SEND = "session:send";
    /** 客户管理 */
    public static final String CUSTOMER_MANAGE = "customer:manage";
    /** 观测链路历史 */
    public static final String TRACE_READ = "trace:read";
    /** 平台设置查看 */
    public static final String SETTINGS_READ = "settings:read";

    /** E2E-1 权限点全集（恰 9 个，字典序，与 gateway_permission seed 一致）。 */
    public static final java.util.List<String> ALL_PERMISSIONS = java.util.List.of(
            AGENT_BUILD, AGENT_DELETE, AGENT_PUBLISH, AGENT_READ,
            CUSTOMER_MANAGE, SESSION_READ, SESSION_SEND, SETTINGS_READ, TRACE_READ);

    // ── P3 管理面权限点（iam:* 族，与业务 9 码分离；docs/04 §3.1）──
    public static final String IAM_USER_READ = "iam:user:read";
    public static final String IAM_USER_WRITE = "iam:user:write";
    public static final String IAM_TENANT_READ = "iam:tenant:read";
    public static final String IAM_TENANT_WRITE = "iam:tenant:write";
    public static final String IAM_MEMBER_READ = "iam:member:read";
    public static final String IAM_MEMBER_WRITE = "iam:member:write";
    public static final String IAM_ROLE_READ = "iam:role:read";
    public static final String IAM_ROLE_WRITE = "iam:role:write";
    public static final String IAM_AUDIT_READ = "iam:audit:read";

    /** P3.5（docs/07）：管理面 SSO 配置——仅平台管理员（iam:idp:* 不授租户 TenantAdmin）。 */
    public static final String IAM_IDP_READ = "iam:idp:read";
    public static final String IAM_IDP_WRITE = "iam:idp:write";

    /** P3 管理面权限点全集（9 个，authority 目录，供 PlatformAdmin 绑定与断言）。 */
    public static final java.util.List<String> IAM_ADMIN_PERMISSIONS = java.util.List.of(
            IAM_USER_READ, IAM_USER_WRITE, IAM_TENANT_READ, IAM_TENANT_WRITE,
            IAM_MEMBER_READ, IAM_MEMBER_WRITE, IAM_ROLE_READ, IAM_ROLE_WRITE, IAM_AUDIT_READ);
}

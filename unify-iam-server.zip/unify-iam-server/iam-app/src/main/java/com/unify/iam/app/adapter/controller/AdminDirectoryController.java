package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * IAM 管理面：用户目录检索（docs/05 §7.3 添加成员/发邀请选人）。
 *
 * <p>权限：iam:member:read（租户管理员可访问——加成员/邀请需要在本租户找人；
 * 仅返回最小字段 user_id/username/email，不泄露 profile/密码）。检索 username/email 模糊匹配。
 */
@RestController
@RequestMapping("/api/v1/admin/user-directory")
public class AdminDirectoryController {

    private final UserRepository userRepository;

    public AdminDirectoryController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_MEMBER_READ)
    public Map<String, Object> search(@RequestParam(name = "search", required = false) String search,
                                      @RequestParam(name = "limit", defaultValue = "20") int limit) {
        List<Map<String, String>> users = userRepository.searchByKeyword(search, limit)
                .stream().map(this::toBrief).toList();
        return Map.of("users", users, "count", users.size());
    }

    private Map<String, String> toBrief(UserPO u) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("user_id", u.getUserId());
        m.put("username", u.getUsername());
        m.put("email", u.getPrimaryEmail());
        return m;
    }
}

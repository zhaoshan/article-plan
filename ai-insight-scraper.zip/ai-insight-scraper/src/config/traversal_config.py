"""遍历规则配置解析

从 config/traversal_rule_config.json 按域名查找配置，未找到时返回默认值。
"""

from pathlib import Path

from src.config.provider import FileConfigProvider
from src.models.traversal_config import DomainTraversalConfig


# 默认配置值
# 是否保留外站链接（子链接域名与入口域名不一致时）
DEFAULT_NEED_OUTER_SITE = True
# 外站域名白名单，只保留白名单内的外站域名子链接；空列表表示全部收集
DEFAULT_OUTER_SITE_WHITELIST: list[str] = []
# 需要爬取的层数，0 表示不限制（广度优先遍历获取所有页面）
DEFAULT_DRILL_DOWN_LEVELS = 0
# page.goto 导航超时时间（毫秒），控制从发起请求到 domcontentloaded 事件的最大等待时间
DEFAULT_PAGE_NAVIGATION_TIMEOUT_MS = 60000
# wait_for_load_state 超时时间（毫秒），控制等待页面达到 domcontentloaded 状态的最大时间
DEFAULT_PAGE_LOAD_STATE_TIMEOUT_MS = 30000
# 页面加载完成后额外等待时间（毫秒），用于让动态内容执行/渲染
DEFAULT_PAGE_LOAD_WAIT_MS = 2000
# page.goto / wait_for_load_state 失败后的重试次数；0 表示不重试
DEFAULT_PAGE_RETRY_COUNT = 2
# 每次重试之间的间隔（毫秒）
DEFAULT_PAGE_RETRY_DELAY_MS = 1000
# 实时局部失败率上限；BFS 过程中失败数 / 已尝试数超过该值时立即中止 tree 阶段
DEFAULT_MAX_PARTIAL_FAILURE_RATE = 0.5
# 触发实时失败率检查所需的最小已尝试页面数，避免早期少量样本误触发
DEFAULT_MIN_PAGES_FOR_FAILURE_CHECK = 10
# Tree 阶段结束时，成功爬取的页面数下限；仅由 FullSiteCrawler 在 tree 阶段后校验
DEFAULT_MIN_TREE_PAGES_THRESHOLD = 50
# Tree 阶段结束时，成功率下限（成功页面数 / 已尝试页面数）；仅由 FullSiteCrawler 校验
DEFAULT_MIN_TREE_SUCCESS_RATE = 0.8


def load_traversal_config(
    domain: str,
    config_dir: str | Path | None = None,
) -> DomainTraversalConfig:
    """
    按域名查找遍历配置。

    从 config_dir/traversal_rule_config.json 中查找 domain 对应的配置，
    未找到时返回默认值。

    Args:
        domain: 域名（如 'example.com'）
        config_dir: 配置文件目录，默认为项目根目录下的 config/

    Returns:
        DomainTraversalConfig: 域名遍历配置
    """
    if config_dir is None:
        # 默认使用项目根目录下的 config/ 目录
        config_dir = Path(__file__).resolve().parent.parent.parent / "config"

    provider = FileConfigProvider(Path(config_dir))
    all_configs = provider.load_json("traversal_rule_config.json")

    # 按域名精确匹配
    domain_config = all_configs.get(domain, {})

    return DomainTraversalConfig(
        # 链接收集策略
        need_outer_site=_parse_bool(
            domain_config.get("need_outer_site", "True"),
            default=DEFAULT_NEED_OUTER_SITE,
        ),
        outer_site_whitelist=domain_config.get(
            "outer_site_whitelist", DEFAULT_OUTER_SITE_WHITELIST
        ),
        # 爬取深度与页面未找到判定
        drill_down_levels=int(
            domain_config.get("drill_down_levels", DEFAULT_DRILL_DOWN_LEVELS)
        ),
        not_found_texts=domain_config.get("not_found_texts", []),
        # 页面导航与重试参数
        page_navigation_timeout_ms=_parse_int(
            domain_config.get("page_navigation_timeout_ms", DEFAULT_PAGE_NAVIGATION_TIMEOUT_MS),
            default=DEFAULT_PAGE_NAVIGATION_TIMEOUT_MS,
        ),
        page_load_state_timeout_ms=_parse_int(
            domain_config.get("page_load_state_timeout_ms", DEFAULT_PAGE_LOAD_STATE_TIMEOUT_MS),
            default=DEFAULT_PAGE_LOAD_STATE_TIMEOUT_MS,
        ),
        page_load_wait_ms=_parse_int(
            domain_config.get("page_load_wait_ms", DEFAULT_PAGE_LOAD_WAIT_MS),
            default=DEFAULT_PAGE_LOAD_WAIT_MS,
        ),
        page_retry_count=_parse_int(
            domain_config.get("page_retry_count", DEFAULT_PAGE_RETRY_COUNT),
            default=DEFAULT_PAGE_RETRY_COUNT,
        ),
        page_retry_delay_ms=_parse_int(
            domain_config.get("page_retry_delay_ms", DEFAULT_PAGE_RETRY_DELAY_MS),
            default=DEFAULT_PAGE_RETRY_DELAY_MS,
        ),
        # 实时失败率保护（BFS 过程中生效）
        max_partial_failure_rate=_parse_float(
            domain_config.get("max_partial_failure_rate", DEFAULT_MAX_PARTIAL_FAILURE_RATE),
            default=DEFAULT_MAX_PARTIAL_FAILURE_RATE,
        ),
        min_pages_for_failure_check=_parse_int(
            domain_config.get("min_pages_for_failure_check", DEFAULT_MIN_PAGES_FOR_FAILURE_CHECK),
            default=DEFAULT_MIN_PAGES_FOR_FAILURE_CHECK,
        ),
        # 阶段准入阈值（仅 FullSiteCrawler 在 tree 阶段完成后校验）
        min_tree_pages_threshold=_parse_int(
            domain_config.get("min_tree_pages_threshold", DEFAULT_MIN_TREE_PAGES_THRESHOLD),
            default=DEFAULT_MIN_TREE_PAGES_THRESHOLD,
        ),
        min_tree_success_rate=_parse_float(
            domain_config.get("min_tree_success_rate", DEFAULT_MIN_TREE_SUCCESS_RATE),
            default=DEFAULT_MIN_TREE_SUCCESS_RATE,
        ),
    )


def _parse_int(value: str | int | float, default: int) -> int:
    """将字符串或数值解析为整数"""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _parse_float(value: str | int | float, default: float) -> float:
    """将字符串或数值解析为浮点数"""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _parse_bool(value: str | bool, default: bool = True) -> bool:
    """将字符串或布尔值解析为布尔值"""
    if isinstance(value, bool):
        return value
    return value.lower() in ("true", "1", "yes")

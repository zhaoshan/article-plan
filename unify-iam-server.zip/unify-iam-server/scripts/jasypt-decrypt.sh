#!/bin/sh
# jasypt 解密包装：classpath 从本地 .m2 取（jasypt + jasypt-spring-boot，与 iam-app 同版本）
# 用法：JASYPT_ENCRYPTOR_PASSWORD=<密钥> scripts/jasypt-decrypt.sh '<密文>'
# 密钥从环境变量读，避免落 shell 历史。
set -e
M2="${HOME}/.m2/repository"
JASYPT_JAR=$(find "$M2/org/jasypt/jasypt" -name 'jasypt-1.9*.jar' | sort | tail -1)
JSB_JAR=$(find "$M2/com/github/ulisesbocchio" \( -name 'jasypt-spring-boot-4*.jar' -o -name 'jasypt-spring-boot-3*.jar' \) 2>/dev/null | grep -v sources | sort | tail -1)
SPRING_CORE_JAR=$(find "$M2/org/springframework/spring-core" -name 'spring-core-6*.jar' 2>/dev/null | grep -v sources | sort | tail -1)
if [ -z "$JASYPT_JAR" ] || [ -z "$JSB_JAR" ] || [ -z "$SPRING_CORE_JAR" ]; then
  echo "找不到依赖 jar（jasypt/jasypt-spring-boot/spring-core）——先 mvn -q -pl iam-app -am compile 一次" >&2
  exit 1
fi
DIR="$(cd "$(dirname "$0")" && pwd)"
java -cp "$JASYPT_JAR:$JSB_JAR:$SPRING_CORE_JAR" "$DIR/JasyptDecryptTool.java" "$1" "$JASYPT_ENCRYPTOR_PASSWORD"

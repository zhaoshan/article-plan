"""系统配置加载模块 — YAML 配置 + 环境变量覆盖

功能：
  - 加载 YAML 配置文件（默认 config/config.yaml）
  - S3 凭据通过 .env 或环境变量加载（不在 YAML 中存储）
  - 环境变量可覆盖 YAML 中的字段（用于 CI/CD 运行时注入）
  - 向后兼容：提供 S3Config、DatabaseConfig 数据类供各模块使用
  - 数据库配置支持逐字段覆盖，自动拼装连接 URL

环境变量配置：
  APP_ENV                              — 环境名（dev / prod / test），用于加载对应 YAML 文件
  S3_ACCESS_KEY                        — S3 访问密钥（敏感凭据）
  S3_SECRET_ACCESS_KEY                 — S3 秘密密钥（敏感凭据）
  S3_REGION / S3_BUCKET / S3_ENDPOINT / S3_PREFIX_PATH / S3_SIGNATURE_VERSION
                                        — 可覆盖 YAML 中 s3.* 配置
  DATABASE_HOST / DATABASE_PORT / DATABASE_USER / DATABASE_PASSWORD / DATABASE_NAME
  DATABASE_DRIVER / DATABASE_POOL_SIZE / DATABASE_MAX_OVERFLOW / DATABASE_ECHO
                                        — 可覆盖 YAML 中 database.* 配置
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# 加载 .env 文件（优先于环境变量，但不会覆盖已有的环境变量）
load_dotenv()

# ── 默认值 ──────────────────────────────────────────────

_DEFAULT_ENV = "dev"
_CONFIG_DIR = Path(__file__).resolve().parent.parent.parent / "config"
_DEFAULT_DB_PORT = 3306
_DEFAULT_DB_POOL_SIZE = 5
_DEFAULT_DB_MAX_OVERFLOW = 10
_DEFAULT_DB_DRIVER = "mysql+aiomysql"


# ── 环境变量名 ──────────────────────────────────────────

_ENV_APP_ENV = "APP_ENV"

_ENV_S3_ACCESS_KEY = "S3_ACCESS_KEY"
_ENV_S3_SECRET_KEY = "S3_SECRET_ACCESS_KEY"
_ENV_S3_REGION = "S3_REGION"
_ENV_S3_ENDPOINT = "S3_ENDPOINT"
_ENV_S3_BUCKET = "S3_BUCKET"
_ENV_S3_PREFIX_PATH = "S3_PREFIX_PATH"
_ENV_S3_SIGNATURE_VERSION = "S3_SIGNATURE_VERSION"

_ENV_DB_HOST = "DATABASE_HOST"
_ENV_DB_PORT = "DATABASE_PORT"
_ENV_DB_USER = "DATABASE_USER"
_ENV_DB_PASSWORD = "DATABASE_PASSWORD"
_ENV_DB_NAME = "DATABASE_NAME"
_ENV_DB_DRIVER = "DATABASE_DRIVER"
_ENV_DB_POOL_SIZE = "DATABASE_POOL_SIZE"
_ENV_DB_MAX_OVERFLOW = "DATABASE_MAX_OVERFLOW"
_ENV_DB_ECHO = "DATABASE_ECHO"


# ── 数据类定义 ──────────────────────────────────────────


@dataclass(frozen=True)
class S3Config:
    """S3 对象存储配置"""

    access_key: str
    secret_key: str
    region: str = "us-west-2"
    bucket: str = ""
    endpoint: str | None = None
    prefix_path: str = ""
    signature_version: str = "s3v4"

    def __post_init__(self) -> None:
        if not self.access_key:
            raise ValueError("S3_ACCESS_KEY 未配置")
        if not self.secret_key:
            raise ValueError("S3_SECRET_ACCESS_KEY 未配置")
        if not self.bucket:
            raise ValueError("S3_BUCKET 未配置")


@dataclass(frozen=True)
class DatabaseConfig:
    """数据库连接配置

    支持两种连接方式：
      1. 通过 host / port / user / password / database 逐字段配置，自动拼接 URL
      2. 通过完整的 url 直接配置（当 url 非空时优先使用）
    """

    host: str = ""
    port: int = 3306
    user: str = ""
    password: str = ""
    database: str = ""
    driver: str = "mysql+aiomysql"
    pool_size: int = 5
    max_overflow: int = 10
    echo: bool = False
    url: str = ""

    def __post_init__(self) -> None:
        if not self._has_full_url and not self.host:
            raise ValueError("数据库配置不完整：需要提供 url 或 host/database")

    @property
    def full_url(self) -> str:
        """获取完整的数据库连接 URL"""
        if self._has_full_url:
            return self.url
        return f"{self.driver}://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"

    # ── 私有帮助：判断是否通过完整 url 初始化 ──────────
    @property
    def _has_full_url(self) -> bool:
        return bool(self.url)


@dataclass(frozen=True)
class AppConfig:
    """应用通用配置"""

    name: str = "ai-insight-scraper"
    env: str = "dev"
    debug: bool = True


@dataclass(frozen=True)
class CrawlConfig:
    """爬取并发控制配置"""

    max_concurrent_crawlers: int = 1
    max_concurrent_scrapes: int = 1
    scrape_min_available_memory_mb: int = 300


@dataclass(frozen=True)
class AuthConfig:
    """API 鉴权配置

    - public_token: 对外接口（/v2/*）的 Bearer Token
    - internal_token: 内部接口（/api/*）的 Bearer Token
    两类 token 区分，避免对外暴露内部接口。
    """

    public_token: str = ""
    internal_token: str = ""


@dataclass(frozen=True)
class SystemConfig:
    """系统全量配置"""

    app: AppConfig = field(default_factory=AppConfig)
    s3: S3Config | None = None
    database: DatabaseConfig | None = None
    crawl: CrawlConfig = field(default_factory=CrawlConfig)
    auth: AuthConfig = field(default_factory=AuthConfig)


# ── YAML 加载 ───────────────────────────────────────────


def _detect_env() -> str:
    """探测当前环境"""
    return os.getenv(_ENV_APP_ENV, _DEFAULT_ENV).strip()


def _config_file_path(env: str) -> Path:
    """获取 YAML 配置文件路径（统一使用 config/config.yaml）"""
    return _CONFIG_DIR / "config.yaml"


def _load_yaml(file_path: Path) -> dict:
    """加载 YAML 配置文件，文件不存在时返回空字典"""
    if not file_path.is_file():
        logger.warning(f"YAML 配置文件不存在: {file_path}，使用空配置")
        return {}
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data: dict = yaml.safe_load(f)
        logger.info(f"加载 YAML 配置: {file_path}")
        return data if data else {}
    except (yaml.YAMLError, OSError) as e:
        logger.error(f"YAML 配置文件加载失败: {file_path}, error={e}")
        return {}


# ── 环境变量覆盖辅助 ────────────────────────────────────


def _get_str(env_key: str, yaml_value: str | None = None, default: str = "") -> str:
    """获取配置值：环境变量 > YAML > 默认值"""
    env_val = os.getenv(env_key)
    if env_val is not None and env_val.strip():
        return env_val.strip()
    if yaml_value and str(yaml_value).strip():
        return str(yaml_value).strip()
    return default


def _get_int(env_key: str, yaml_value: int | None = None, default: int = 0) -> int:
    """获取整型配置值"""
    env_val = os.getenv(env_key)
    if env_val is not None and env_val.strip():
        try:
            return int(env_val.strip())
        except ValueError:
            logger.warning(f"{env_key} 环境变量值不是有效整数: {env_val}")
    return yaml_value if yaml_value is not None else default


def _get_bool(env_key: str, yaml_value: bool | None = None, default: bool = False) -> bool:
    """获取布尔型配置值"""
    env_val = os.getenv(env_key)
    if env_val is not None and env_val.strip():
        return env_val.strip().lower() in ("1", "true", "yes", "y")
    return yaml_value if yaml_value is not None else default


# ── 公开 API ────────────────────────────────────────────


def load_system_config(env: str | None = None) -> SystemConfig:
    """加载系统配置。

    Args:
        env: 环境名，默认从 APP_ENV 环境变量或 "dev" 读取

    Returns:
        SystemConfig: 全量系统配置
    """
    env = env or _detect_env()
    yaml_data = _load_yaml(_config_file_path(env))

    # ── 1. App 配置 ─────────────────────────────────────
    app_yaml = yaml_data.get("app", {}) if isinstance(yaml_data, dict) else {}
    app_config = AppConfig(
        name=_get_str("APP_NAME", app_yaml.get("name"), "ai-insight-scraper"),
        env=env,
        debug=_get_bool("APP_DEBUG", app_yaml.get("debug"), env == "dev"),
    )

    # ── 2. S3 配置（凭据从 .env / 环境变量加载） ──────
    s3_yaml = yaml_data.get("s3", {}) if isinstance(yaml_data, dict) else {}
    try:
        s3_config = S3Config(
            access_key=_get_str(_ENV_S3_ACCESS_KEY, ""),  # 仅从环境变量
            secret_key=_get_str(_ENV_S3_SECRET_KEY, ""),  # 仅从环境变量
            region=_get_str(_ENV_S3_REGION, s3_yaml.get("region"), "us-west-2"),
            bucket=_get_str(_ENV_S3_BUCKET, s3_yaml.get("bucket")),
            endpoint=_get_str(_ENV_S3_ENDPOINT, s3_yaml.get("endpoint")) or None,
            prefix_path=_get_str(_ENV_S3_PREFIX_PATH, s3_yaml.get("prefix_path"), ""),
            signature_version=_get_str(_ENV_S3_SIGNATURE_VERSION, s3_yaml.get("signature_version"), "s3v4"),
        )
    except ValueError as e:
        logger.warning(f"S3 配置不完整: {e}，S3 功能将不可用")
        s3_config = None

    # ── 3. Database 配置（逐字段，自动拼装 URL） ───────
    db_yaml = yaml_data.get("database", {}) if isinstance(yaml_data, dict) else {}
    try:
        database_config = DatabaseConfig(
            host=_get_str(_ENV_DB_HOST, db_yaml.get("host")),
            port=_get_int(_ENV_DB_PORT, db_yaml.get("port"), _DEFAULT_DB_PORT),
            user=_get_str(_ENV_DB_USER, db_yaml.get("user")),
            password=_get_str(_ENV_DB_PASSWORD, db_yaml.get("password")),
            database=_get_str(_ENV_DB_NAME, db_yaml.get("database")),
            driver=_get_str(_ENV_DB_DRIVER, db_yaml.get("driver"), _DEFAULT_DB_DRIVER),
            pool_size=_get_int(_ENV_DB_POOL_SIZE, db_yaml.get("pool_size"), _DEFAULT_DB_POOL_SIZE),
            max_overflow=_get_int(_ENV_DB_MAX_OVERFLOW, db_yaml.get("max_overflow"), _DEFAULT_DB_MAX_OVERFLOW),
            echo=_get_bool(_ENV_DB_ECHO, db_yaml.get("echo"), False),
        )
    except ValueError as e:
        logger.warning(f"Database 配置不完整: {e}，数据库功能将不可用")
        database_config = None

    # ── 4. Crawl 并发配置 ──────────────────────────────
    crawl_yaml = yaml_data.get("crawl", {}) if isinstance(yaml_data, dict) else {}
    crawl_config = CrawlConfig(
        max_concurrent_crawlers=_get_int(
            "CRAWL_MAX_CONCURRENT_CRAWLERS",
            crawl_yaml.get("max_concurrent_crawlers"),
            1,
        ),
        max_concurrent_scrapes=_get_int(
            "CRAWL_MAX_CONCURRENT_SCRAPES",
            crawl_yaml.get("max_concurrent_scrapes"),
            1,
        ),
        scrape_min_available_memory_mb=_get_int(
            "CRAWL_SCRAPE_MIN_AVAILABLE_MEMORY_MB",
            crawl_yaml.get("scrape_min_available_memory_mb"),
            300,
        ),
    )

    # ── 5. Auth 鉴权配置 ───────────────────────────────
    auth_yaml = yaml_data.get("auth", {}) if isinstance(yaml_data, dict) else {}
    auth_config = AuthConfig(
        public_token=_get_str("AUTH_PUBLIC_TOKEN", auth_yaml.get("public_token")),
        internal_token=_get_str("AUTH_INTERNAL_TOKEN", auth_yaml.get("internal_token")),
    )

    return SystemConfig(
        app=app_config,
        s3=s3_config,
        database=database_config,
        crawl=crawl_config,
        auth=auth_config,
    )


# ── 快捷获取 S3Config（向后兼容 s3_config.py） ─────────


def load_s3_config() -> S3Config:
    """加载 S3 配置（从系统配置中提取，向后兼容）

    Raises:
        ValueError: S3 配置不完整
    """
    config = load_system_config()
    if config.s3 is None:
        raise ValueError("S3 配置不完整（access_key / secret_key / bucket 缺失）")
    return config.s3
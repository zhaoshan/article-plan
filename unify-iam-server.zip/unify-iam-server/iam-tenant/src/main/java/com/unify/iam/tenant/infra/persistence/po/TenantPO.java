package com.unify.iam.tenant.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_tenant 租户主表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_tenant")
public class TenantPO extends BaseEntity {

    /** 租户业务唯一标识 */
    private String tenantId;
    /** 租户编码/slug */
    private String tenantCode;
    /** 租户名称 */
    private String tenantName;
    /** 租户类型：PERSONAL/ORGANIZATION */
    private String tenantType;
    /** 租户状态：PENDING/ACTIVE/SUSPENDED/DELETED */
    private String tenantStatus;
    /** 注册来源 */
    private String registrationSource;
    /** 首个拥有者用户 ID */
    private String ownerUserId;
    /** 主域名 */
    private String primaryDomain;
    /** 加入策略 */
    private String joinPolicy;
    /** 是否强制企业 SSO */
    private Integer ssoRequired;
    /** 计费套餐编码 */
    private String billingPlanCode;
}

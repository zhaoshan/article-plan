package com.unify.iam.app.mail;

/**
 * 通用邮件投递工具（对齐 ai-chat-insight insight-common/mail；第三方实现可替换）。
 *
 * <p>约定：EmailTool 不负责模板渲染/变量替换；调用方应在调用前组装最终的 subject 与 htmlBody。
 */
public interface EmailTool {

    /**
     * 发送 HTML 邮件。
     *
     * @param to       收件人
     * @param subject  邮件主题（已完成渲染）
     * @param htmlBody HTML 正文（已完成渲染）
     */
    void send(String to, String subject, String htmlBody);
}

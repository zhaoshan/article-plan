package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.authorization.infra.persistence.po.PermissionPO;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * IAM 管理面：权限点目录（docs/05 §7.3 ④ 角色授权清单，角色配置权限的勾选来源）。
 * 权限：iam:role:read。
 */
@RestController
@RequestMapping("/api/v1/admin/permissions")
public class AdminPermissionController {

    private final PermissionRepository permissionRepository;

    public AdminPermissionController(PermissionRepository permissionRepository) {
        this.permissionRepository = permissionRepository;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_ROLE_READ)
    public Map<String, Object> list() {
        List<Map<String, String>> permissions = permissionRepository.listActive().stream()
                .map(this::toBrief).toList();
        return Map.of("permissions", permissions, "count", permissions.size());
    }

    private Map<String, String> toBrief(PermissionPO p) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("permission_id", p.getPermissionId());
        m.put("permission_code", p.getPermissionCode());
        m.put("permission_name", p.getPermissionName());
        m.put("resource_type", p.getResourceType());
        m.put("app_code", p.getAppCode() == null ? "" : p.getAppCode());
        m.put("tenant_grantable", p.getTenantGrantable() != null && p.getTenantGrantable() == 1 ? "1" : "0");
        return m;
    }
}

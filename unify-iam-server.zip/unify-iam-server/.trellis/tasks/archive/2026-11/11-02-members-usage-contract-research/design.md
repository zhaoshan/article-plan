# Research design

This is a read-only backend contract investigation. Start at the two HTTP route
declarations, follow the call graph through authorization and service logic, and
then inspect response DTOs, serializers, persistence/configuration, and tests.
Cross-check any member dimension constants against the quota/usage data model.
The final artifact will separate observed facts from frontend recommendations
and include repository-relative evidence paths.

The scope deliberately excludes frontend code, business-code edits, API changes,
database changes, commits, pushes, branch changes, and worktree operations.

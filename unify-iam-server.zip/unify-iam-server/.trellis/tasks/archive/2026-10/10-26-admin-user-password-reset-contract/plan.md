# Administrator user password-reset contract plan

Date: 2026-10-26

Status: Complete.

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, plan, session, and validation records under this repository's `.trellis/` directory.
- Do not inspect or modify any separate frontend project. The requested form and dialog visual changes are frontend-owned and explicitly outside this task.
- Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- The requested `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree, including hidden-path and Git-index searches. The applicable project instructions are `CLAUDE.md` and `.claude/rules/security.md`; no undocumented Trellis confirmation gate can be inferred.

## Confirmed baseline

- `PUT /api/v1/admin/users/{userId}` safely updates profile/status fields but intentionally contains no password field.
- `POST /api/v1/auth/reset-password` is a separate public token-consumption path. It writes a BCrypt hash and revokes all refresh tokens, but it is not an administrator action and requires a reset token.
- The management API is protected by a verified Bearer token and `iam:user:write`; existing permission assignment makes that permission platform-only.
- The project already has a token-version feed for active memberships. It can carry password-reset version changes to downstream consumers without a schema change.
- No project-wide password-strength policy exists today. Existing create/register/reset inputs only require nonblank values. BCrypt must not receive silently truncated input.

## Chosen contract

Add an explicit management action rather than overloading profile `PUT`:

```text
POST /api/v1/admin/users/{userId}/reset-password
Authorization: Bearer <token with iam:user:write>
Content-Type: application/json

{ "password": "..." }
```

- It applies only to a user with an ACTIVE `LOCAL/password` identity; it does not create a local credential for OIDC-only users.
- `password` is required, must contain a non-whitespace character, and is bounded to 72 UTF-8 bytes so BCrypt cannot truncate it. No unapproved complexity rule is introduced. `new_password` is not accepted as an alias on this management endpoint.
- The raw password is neither trimmed nor returned, logged, audited, or persisted. Only `BCryptUtils.hash(...)` is written.
- On success, invalidate active password-reset tokens and all refresh tokens for the target, then bump every active membership's token version with `PASSWORD_RESET` for the existing version feed.
- Record a dedicated success audit event without sensitive before/after/metadata values.

## Validation plan

- MVC coverage for authorization, success envelope, and request validation.
- Service coverage for BCrypt storage, LOCAL identity boundary, reset-token/refresh/version invalidation, and byte-limit enforcement.
- MySQL integration coverage proving the old password and refresh token fail, the new password works, reset tokens are invalidated, active membership version changes, and audit data has no plaintext password.

## Completed implementation

- Added POST /api/v1/admin/users/{userId}/reset-password with AdminResetPasswordRequest.password; existing profile PUT remains unchanged.
- Added the same management permission boundary as user creation/update: verified Bearer token plus iam:user:write.
- Added the LOCAL identity boundary, BCrypt-only storage, UTF-8 byte validation, reset-token invalidation, refresh-token revocation, and active-membership version bumps.
- Added the ADMIN_RESET_USER_PASSWORD audit catalog event. The controller writes only the actor, target, result, and request metadata supplied by the audit service; it passes no raw password, hash, or token into audit fields.
- Documented the direct frontend contract in docs/user-manual/05-API接口梳理.md; no frontend source was accessed or changed.

## Validation result

The sandboxed MVC/unit command compiled successfully but could not initialize Mockito's Byte Buddy agent under JDK 26. The focused commands passed once run with the required JVM process-attachment capability; the integration test also used Docker/Testcontainers:

    mvn -pl iam-app -am test -Dtest='AdminUserControllerTest,AdminUserServiceTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
    18 passed, 0 failures, 0 errors

    mvn -pl iam-app -am test -Dtest='AdminUserPasswordResetIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
    1 passed, 0 failures, 0 errors

## Independent runtime verification

On 2026-10-26, the current worktree was independently rebuilt and rechecked rather
than relying on the earlier task record:

- `AdminUserControllerTest` and `AdminUserServiceTest` passed: 18 tests, 0 failures,
  0 errors. The MVC test proves the exact management route accepts `{password}` and
  that a body containing only `new_password` returns 400 before the reset service is
  invoked.
- `AdminUserPasswordResetIntegrationTest` passed against a fresh Testcontainers MySQL
  database: 1 test, 0 failures, 0 errors. It proves BCrypt storage, old-password
  rejection, new-password login, reset/refresh-token invalidation, active-membership
  version bumps, and password-free audit data.
- The already-running local process on `localhost:8090` returned 200 for
  `/v3/api-docs`, but its live OpenAPI paths did not contain
  `/api/v1/admin/users/{userId}/reset-password`. It is therefore a stale process
  relative to this worktree and cannot serve the new route until it is restarted.
- The listening Vite server on `localhost:5174` forwarded
  `POST /api/v1/auth/token` to the same Java process: an empty JSON request returned
  the byte-identical 400 JSON response through both `5174` and direct `8090`. No
  frontend source was accessed or changed. The proxy prefix is live; its backend must
  be restarted from this worktree for the reset route to become available through
  `5174`.

## Local runtime activation

The stale port-8090 process was confirmed to be a local development process owned by
the current user: its working directory and JAR both belonged to this worktree, and
it used a local MySQL connection. After a current-worktree package build, it was
gracefully stopped. The local restart mechanism launched a replacement process from
the newly built JAR on port 8090.

- The replacement process's live OpenAPI document contains
  `/api/v1/admin/users/{userId}/reset-password`.
- A safe no-credential POST with a non-persistent verification password returns the
  expected 401 authorization envelope both directly on port 8090 and through port
  5174; the responses are byte-identical.
- The temporary port-8091 preflight instance was stopped after validation. It used
  the existing 0600 workspace JWT key and disabled Flyway so it did not apply an
  unrelated pending migration to the local database.

No user Bearer token was read, emitted, or used. The active port-8090 process now
runs the current worktree JAR; its normal local prerequisites remain the reachable
MySQL instance and the persistent workspace JWT key.

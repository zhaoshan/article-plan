"""对外 API v2 路由 — 对外发布的标准化接口

  - POST /v2/map    已爬取数据链接查询（原 /api/link-tree/links）
  - POST /v2/scrape 单页面内容爬取（原 /api/content/crawl）

鉴权：请求头 Authorization: Bearer <public_token>

返回结构（不使用 DefaultResult）：
  成功: {"success": true, "message": "ok", ...其它字段}
  失败: {"success": false, "error": "失败原因", ...其它字段}
"""

import logging

from fastapi import APIRouter, Depends, HTTPException
from fastapi.requests import Request
from fastapi.responses import JSONResponse

from src.boundaries.s3_boundary import S3Boundary
from src.core.auth import require_public_token
from src.core.page_content_crawler import PageContentCrawler
from src.core.scrape_rate_limiter import scrape_rate_limiter
from src.database import LinkTreeRepository
from src.database.repository import TaskRepository
from src.models.link_query_request import LinkQueryRequest
from src.models.page_content_request import PageContentRequest
from src.routers.crawl import _launch_full_site
from src.utils.url_utils import get_domain

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/v2", tags=["对外 API v2"])

# 附件类 link_type（crawl_file_list 仅 1 项，返回 type=file）
_ATTACHMENT_LINK_TYPES = {"PDF", "DOC", "DOCX", "XLS", "XLSX", "PPT", "PPTX",
                          "ZIP", "RAR", "7Z", "TAR", "GZ", "TXT", "CSV",
                          "MP4", "AVI", "MOV"}
# 图片类 link_type
_IMAGE_LINK_TYPES = {"PNG", "JPG", "JPEG", "GIF", "SVG", "WEBP", "BMP", "ICO"}

# formats 参数 → crawl_file_list file_type 映射
_FORMAT_TO_FILE_TYPE = {
    "markdown": "markdown",
    "html": "html",
    "raw_html": "rawHtml",
}


def _build_s3_boundary() -> S3Boundary | None:
    """构建 S3Boundary 实例，配置不完整时返回 None"""
    try:
        return S3Boundary()
    except ValueError:
        logger.warning("S3 配置不完整，S3 功能将不可用")
        return None


def _success(data: dict, status_code: int = 200) -> JSONResponse:
    """构造成功响应：{"success": true, "message": "ok", ...}"""
    payload = {"success": True, "message": "ok"}
    payload.update(data)
    return JSONResponse(status_code=status_code, content=payload)


def _error(error: str, status_code: int = 400, **extra) -> JSONResponse:
    """构造失败响应：{"success": false, "error": "...", ...}"""
    payload = {"success": False, "error": error}
    payload.update(extra)
    return JSONResponse(status_code=status_code, content=payload)


@router.post("/map", dependencies=[Depends(require_public_token)])
async def v2_map(request: LinkQueryRequest) -> JSONResponse:
    """已爬取数据链接查询（对外）

    根据入参 URL 解析站点，按 full_site 任务状态分支处理：
      - 有 completed 任务：从 crawl_link_tree 查询并返回 links（支持 search 模糊匹配）
      - 无 completed 但有 running/pending：返回当前任务状态，不重建
      - 无 completed 且无任务 / 最新为 failed：自动发起全量爬取，返回 running
    """
    # 1. 解析站点
    domain = get_domain(request.url)
    if not domain:
        return _error(f"无法解析 URL 的域名: {request.url}", status_code=400)

    task_repo = TaskRepository()
    link_repo = LinkTreeRepository()

    # 2. 优先查 completed 的 full_site 任务
    try:
        completed_task = await task_repo.find_completed_by_site_and_type(domain, "full_site")
    except Exception as e:
        logger.exception("[v2/map] 查询 completed 任务失败")
        return _error(f"查询任务失败: {e}", status_code=500)

    if completed_task is not None:
        try:
            rows = await link_repo.search_by_site(domain, request.search or None, request.limit)
        except Exception as e:
            logger.exception("[v2/map] 查询链接树失败")
            return _error(f"查询链接树失败: {e}", status_code=500)
        links = [
            {
                "url": row.url,
                "title": row.page_title or "",
                "description": row.remark or "",
                "level": row.level,
                "type": "html" if (row.link_type or "").upper() == "HTML" else "file",
                "parent": row.parent_url or "",
                "need_crawl": (row.download_flag or "").upper() == "Y",
                "status": 0 if (row.update_history or "") == "删除" else 1,
            }
            for row in rows
        ]
        logger.info(
            f"[v2/map] 查询已爬取链接: site={domain}, search={request.search!r}, "
            f"返回 {len(links)} 条"
        )
        return _success({
            "task_id": completed_task.task_id,
            "status": "completed",
            "links": links,
        })

    # 3. 无 completed：查最新 full_site 任务
    try:
        latest_task = await task_repo.find_latest_by_site_and_type(domain, "full_site")
    except Exception as e:
        logger.exception("[v2/map] 查询最新任务失败")
        return _error(f"查询任务失败: {e}", status_code=500)

    # 无任务 或 最新为 failed → 自动发起全量爬取
    if latest_task is None or latest_task.status == "failed":
        logger.info(
            f"[v2/map] 站点无 completed 任务（latest="
            f"{latest_task.status if latest_task else 'None'}），自动发起全量爬取: site={domain}"
        )
        try:
            master_task = await _launch_full_site(
                domain=domain,
                target_url=request.url,
                headless=True,
                max_depth=None,
            )
        except Exception as e:
            logger.exception("[v2/map] 发起全量爬取失败")
            return _error(f"发起全量爬取失败: {e}", status_code=500)
        return _success({
            "task_id": master_task.task_id,
            "status": "running",
            "links": [],
        })

    # 4. running/pending：返回当前任务状态，不重建
    return _success({
        "task_id": latest_task.task_id,
        "status": latest_task.status,
        "links": [],
    })


@router.post(
    "/scrape",
    dependencies=[
        Depends(require_public_token),
        Depends(scrape_rate_limiter),
    ],
)
async def v2_scrape(request: PageContentRequest) -> JSONResponse:
    """单页面内容爬取（对外）

    - 普通网页：返回 type=page，按 formats 从 S3 下载 markdown/html/raw_html
    - 图片链接：返回 type=page，images 含加签 URL，markdown 为图片引用
    - 附件链接：返回 type=file，download_url 为预签名 URL
    """
    s3_boundary = _build_s3_boundary()
    if s3_boundary is None:
        return _error("S3 配置不完整，无法爬取页面内容", status_code=500)

    crawler = PageContentCrawler(headless=True, s3_boundary=s3_boundary)

    try:
        crawl_result = await crawler.crawl(request.url)
    except ValueError as e:
        return _error(str(e), status_code=400)
    except Exception as e:
        logger.exception("[v2/scrape] 页面内容爬取失败")
        return _error(f"爬取失败: {e}", status_code=500)

    link_type = crawl_result["link_type"]
    page_title = crawl_result["page_title"]
    crawl_file_list: list[dict] = crawl_result["crawl_file_list"]

    # ── 附件类型 ─────────────────────────────────────
    if link_type in _ATTACHMENT_LINK_TYPES:
        if not crawl_file_list:
            return _error("附件爬取产物为空", status_code=500)
        file_info = crawl_file_list[0]
        extension = file_info.get("file_type", "")
        try:
            download_url = await s3_boundary.generate_presigned_url(file_info["s3_path"])
        except Exception as e:
            logger.exception("[v2/scrape] 生成预签名 URL 失败")
            return _error(f"生成下载链接失败: {e}", status_code=500)
        return _success({
            "type": "file",
            "file_name": page_title,
            "mime_type": f"application/{extension}" if extension else "application/octet-stream",
            "extension": extension,
            "size": file_info.get("file_size", 0),
            "download_url": download_url,
        })

    # ── 图片类型 ─────────────────────────────────────
    if link_type in _IMAGE_LINK_TYPES:
        if not crawl_file_list:
            return _error("图片爬取产物为空", status_code=500)
        image_file = next(
            (f for f in crawl_file_list if f["file_type"] != "markdown"),
            crawl_file_list[0],
        )
        try:
            stored_url = await s3_boundary.generate_presigned_url(image_file["s3_path"])
        except Exception as e:
            logger.exception("[v2/scrape] 生成预签名 URL 失败")
            return _error(f"生成图片链接失败: {e}", status_code=500)
        markdown = ""
        md_file = next((f for f in crawl_file_list if f["file_type"] == "markdown"), None)
        if md_file:
            try:
                markdown = await s3_boundary.download_text(md_file["s3_path"])
            except Exception as e:
                logger.exception("[v2/scrape] 下载 markdown 失败")
                return _error(f"下载 markdown 失败: {e}", status_code=500)
            if image_file["s3_path"] in markdown:
                markdown = markdown.replace(image_file["s3_path"], stored_url)
        return _success({
            "type": "page",
            "markdown": markdown,
            "html": "",
            "raw_html": "",
            "metadata": {"title": page_title},
            "images": [
                {
                    "source_url": request.url,
                    "stored_url": stored_url,
                }
            ],
        })

    # ── 普通网页 ─────────────────────────────────────
    file_map = {f["file_type"]: f for f in crawl_file_list}
    data: dict = {
        "type": "page",
        "metadata": {"title": page_title},
        "images": [],
    }
    for fmt in request.formats:
        file_type = _FORMAT_TO_FILE_TYPE.get(fmt)
        if not file_type:
            continue
        file_info = file_map.get(file_type)
        if not file_info:
            continue
        try:
            content = await s3_boundary.download_text(file_info["s3_path"])
        except Exception as e:
            logger.exception(f"[v2/scrape] 下载 {fmt} 失败")
            return _error(f"下载 {fmt} 内容失败: {e}", status_code=500)
        if fmt == "markdown":
            data["markdown"] = content
        elif fmt == "html":
            data["html"] = content
        elif fmt == "raw_html":
            data["raw_html"] = content

    return _success(data)

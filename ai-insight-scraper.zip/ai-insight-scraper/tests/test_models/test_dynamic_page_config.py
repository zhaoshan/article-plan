"""DynamicPageEntry / DynamicCrawlRequest 模型校验测试"""

import pytest
from pydantic import ValidationError
from src.models.dynamic_page_config import DynamicPageEntry
from src.models.crawl_request import DynamicCrawlRequest


class TestDynamicPageEntry:
    """DynamicPageEntry 校验测试"""

    def test_valid_entry(self):
        """合法配置"""
        entry = DynamicPageEntry(
            script_name="faq_crawler",
            parent_link="https://example.com/faq/",
            entry_url="https://support.example.com/",
        )
        assert entry.script_name == "faq_crawler"
        assert entry.parent_link == "https://example.com/faq/"
        assert entry.entry_url == "https://support.example.com/"
        assert entry.description is None

    def test_with_description(self):
        """带描述"""
        entry = DynamicPageEntry(
            script_name="faq_crawler",
            parent_link="https://example.com/faq/",
            entry_url="https://support.example.com/",
            description="测试描述",
        )
        assert entry.description == "测试描述"

    def test_empty_script_name_raises(self):
        """script_name 不能为空"""
        with pytest.raises(ValidationError):
            DynamicPageEntry(
                script_name="",
                parent_link="https://example.com/",
                entry_url="https://example.com/",
            )

    def test_empty_parent_link_raises(self):
        """parent_link 不能为空"""
        with pytest.raises(ValidationError):
            DynamicPageEntry(
                script_name="faq",
                parent_link="",
                entry_url="https://example.com/",
            )

    def test_empty_entry_url_raises(self):
        """entry_url 不能为空"""
        with pytest.raises(ValidationError):
            DynamicPageEntry(
                script_name="faq",
                parent_link="https://example.com/",
                entry_url="",
            )

    def test_extra_fields_forbidden(self):
        """不允许额外字段"""
        with pytest.raises(ValidationError):
            DynamicPageEntry(
                script_name="faq",
                parent_link="https://example.com/",
                entry_url="https://example.com/",
                unknown_field="value",
            )


class TestDynamicCrawlRequest:
    """DynamicCrawlRequest 校验测试"""

    def test_valid_request(self):
        """合法请求"""
        req = DynamicCrawlRequest(
            site="tokyostarbank.co.jp",
            page_type="faq",
            static_links_file="output/a.json",
            static_tree_file="output/b.json",
        )
        assert req.site == "tokyostarbank.co.jp"
        assert req.page_type == "faq"
        assert req.static_links_file == "output/a.json"
        assert req.static_tree_file == "output/b.json"

    def test_empty_site_raises(self):
        """site 不能为空"""
        with pytest.raises(ValidationError):
            DynamicCrawlRequest(
                site="",
                page_type="faq",
                static_links_file="output/a.json",
                static_tree_file="output/b.json",
            )

    def test_empty_page_type_raises(self):
        """page_type 不能为空"""
        with pytest.raises(ValidationError):
            DynamicCrawlRequest(
                site="example.com",
                page_type="",
                static_links_file="output/a.json",
                static_tree_file="output/b.json",
            )

    def test_empty_links_file_raises(self):
        """static_links_file 不能为空"""
        with pytest.raises(ValidationError):
            DynamicCrawlRequest(
                site="example.com",
                page_type="faq",
                static_links_file="",
                static_tree_file="output/b.json",
            )

    def test_empty_tree_file_raises(self):
        """static_tree_file 不能为空"""
        with pytest.raises(ValidationError):
            DynamicCrawlRequest(
                site="example.com",
                page_type="faq",
                static_links_file="output/a.json",
                static_tree_file="",
            )

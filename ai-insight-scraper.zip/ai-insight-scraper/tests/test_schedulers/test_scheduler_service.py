"""SchedulerService 单元测试"""

import uuid
from datetime import datetime
from unittest.mock import AsyncMock, patch

import pytest

from src.database.models import CrawlScheduleModel
from src.schedulers.scheduler_service import SchedulerService


@pytest.fixture
def scheduler_service():
    """返回未启动的 SchedulerService 实例"""
    return SchedulerService()


@pytest.fixture
def sample_schedule():
    """返回测试调度配置"""
    return CrawlScheduleModel(
        schedule_id=str(uuid.uuid4()),
        site="example.com",
        target_url="https://example.com/",
        cron_expression="0 2 * * *",
        timezone="Asia/Tokyo",
        enabled=1,
        max_depth=0,
        headless=1,
        output_type="local",
        create_time=datetime.now(),
        update_time=datetime.now(),
    )


class TestSchedulerServiceLifecycle:
    """SchedulerService 生命周期测试"""

    @pytest.mark.asyncio
    async def test_start_and_shutdown(self, scheduler_service):
        """启动和关闭调度器"""
        scheduler_service.start()
        assert scheduler_service._scheduler is not None
        assert scheduler_service._scheduler.running

        await scheduler_service.shutdown()
        assert scheduler_service._scheduler is None

    @pytest.mark.asyncio
    async def test_start_when_already_running(self, scheduler_service):
        """重复启动不应报错"""
        scheduler_service.start()
        scheduler_service.start()  # 第二次应为 no-op
        assert scheduler_service._scheduler.running


class TestSchedulerJobManagement:
    """SchedulerService job 管理测试"""

    @pytest.mark.asyncio
    async def test_add_schedule_job(self, scheduler_service, sample_schedule):
        """注册调度 job"""
        scheduler_service.start()
        scheduler_service.add_schedule_job(sample_schedule)

        job = scheduler_service._scheduler.get_job(sample_schedule.schedule_id)
        assert job is not None
        assert job.id == sample_schedule.schedule_id

    @pytest.mark.asyncio
    async def test_remove_schedule_job(self, scheduler_service, sample_schedule):
        """移除调度 job"""
        scheduler_service.start()
        scheduler_service.add_schedule_job(sample_schedule)
        removed = scheduler_service.remove_schedule_job(sample_schedule.schedule_id)
        assert removed is True
        assert scheduler_service._scheduler.get_job(sample_schedule.schedule_id) is None

    @pytest.mark.asyncio
    async def test_reschedule_job(self, scheduler_service, sample_schedule):
        """重新注册调度 job"""
        scheduler_service.start()
        scheduler_service.add_schedule_job(sample_schedule)

        sample_schedule.cron_expression = "*/5 * * * *"
        scheduler_service.reschedule_job(sample_schedule)

        job = scheduler_service._scheduler.get_job(sample_schedule.schedule_id)
        assert job is not None

    @pytest.mark.asyncio
    async def test_trigger_job_now(self, scheduler_service, sample_schedule):
        """手动立即触发"""
        scheduler_service.start()
        scheduler_service.trigger_job_now(sample_schedule.schedule_id)
        jobs = scheduler_service._scheduler.get_jobs()
        assert len(jobs) >= 1

    @pytest.mark.asyncio
    async def test_get_job_info_not_exists(self, scheduler_service):
        """查询不存在的 job 返回 None"""
        scheduler_service.start()
        assert scheduler_service.get_job_info("not-exist") is None


class TestLoadSchedulesFromDb:
    """从数据库加载调度测试"""

    @pytest.mark.asyncio
    async def test_load_enabled_schedules(self, scheduler_service, sample_schedule):
        """加载启用调度并注册 job"""
        scheduler_service.start()

        repo_mock = AsyncMock()
        repo_mock.list_enabled.return_value = [sample_schedule]
        scheduler_service._schedule_repo = repo_mock

        await scheduler_service.load_schedules_from_db()

        repo_mock.list_enabled.assert_awaited_once()
        job = scheduler_service._scheduler.get_job(sample_schedule.schedule_id)
        assert job is not None

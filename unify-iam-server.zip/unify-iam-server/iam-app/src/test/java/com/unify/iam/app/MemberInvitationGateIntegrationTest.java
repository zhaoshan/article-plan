package com.unify.iam.app;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MvcResult;

/**
 * 成员邀请「严格投递模式」前置闸门负向测试：开闸但投递链路未配齐（基类强制 spring.mail.host=""）
 * → 503 且零落库（不留死邀请占位配额/堵重邀，docs/08 §7）。
 */
class MemberInvitationGateIntegrationTest extends IamIntegrationTestBase {

    @org.springframework.beans.factory.annotation.Autowired
    private com.unify.iam.app.config.IamProperties iamProperties;

    @org.junit.jupiter.api.BeforeEach
    void enableStrictDelivery() {
        iamProperties.getMail().setDeliveryEnabled(true);
    }

    @org.junit.jupiter.api.AfterEach
    void resetStrictDelivery() {
        iamProperties.getMail().setDeliveryEnabled(false);
    }

    @Test
    void strictModeWithoutSmtpReturns503AndPersistsNothing() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String email = "member-gate-" + suffix + "@example.test";

        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email, "tenant_id", "tenant-org-a"))))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value(
                        "Invitation mail delivery is not configured (requires spring.mail.host + spring.mail.username (sender = authorized account) + JavaMailSender)"));

        org.assertj.core.api.Assertions.assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email=?", Integer.class, email)).isZero();
        org.assertj.core.api.Assertions.assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE username=?", Integer.class, email)).isZero();
    }

    private String adminToken() throws Exception {
        MvcResult result = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(result.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }
}

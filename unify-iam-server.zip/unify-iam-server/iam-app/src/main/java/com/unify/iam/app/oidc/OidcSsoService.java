package com.unify.iam.app.oidc;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.authenticator.OidcAuthenticator;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.security.OidcIdTokenVerifier;
import com.unify.iam.authorization.app.service.RoleSyncService;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.identity.infra.persistence.po.IdpGroupMappingPO;
import com.unify.iam.identity.infra.persistence.repository.IdpGroupMappingRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * OIDC SSO 编排：authorize（发起跳转，存临时态）与 callback（换 token → 验签 → JIT → 组映射 → 签发）。
 *
 * <p>令牌签发复用 {@code TokenService.issueFor}（管线零改动）；E2E-2 只换认证来源。
 */
@Service
public class OidcSsoService {

    private final OidcProviderConfigService oidcProviderConfigService;
    private final OidcAuthSessionStore sessionStore;
    private final OidcProviderClient providerClient;
    private final OidcIdTokenVerifier idTokenVerifier;
    private final OidcAuthenticator oidcAuthenticator;
    private final IdpGroupMappingRepository idpGroupMappingRepository;
    private final RoleSyncService roleSyncService;
    private final TokenService tokenService;
    private final TokenVersionService tokenVersionService;
    private final IamProperties props;

    public OidcSsoService(OidcProviderConfigService oidcProviderConfigService,
                          OidcAuthSessionStore sessionStore,
                          OidcProviderClient providerClient,
                          OidcIdTokenVerifier idTokenVerifier,
                          OidcAuthenticator oidcAuthenticator,
                          IdpGroupMappingRepository idpGroupMappingRepository,
                          RoleSyncService roleSyncService,
                          TokenService tokenService,
                          TokenVersionService tokenVersionService,
                          IamProperties props) {
        this.oidcProviderConfigService = oidcProviderConfigService;
        this.sessionStore = sessionStore;
        this.providerClient = providerClient;
        this.idTokenVerifier = idTokenVerifier;
        this.oidcAuthenticator = oidcAuthenticator;
        this.idpGroupMappingRepository = idpGroupMappingRepository;
        this.roleSyncService = roleSyncService;
        this.tokenService = tokenService;
        this.tokenVersionService = tokenVersionService;
        this.props = props;
    }

    /** ① 发起 SSO：生成 state/nonce/PKCE，存临时态，返回跳转 IdP 的 URL。 */
    public String buildAuthRequestUrl(String tenantId) {
        OidcProviderConfig config = oidcProviderConfigService.loadByTenant(tenantId);
        String state = IdGenerator.newBizId();
        String nonce = IdGenerator.newBizId();
        String codeVerifier = randomUrlSafe(64);
        String codeChallenge = s256(codeVerifier);

        sessionStore.put(state, new OidcAuthSession(state, nonce, codeChallenge, codeVerifier,
                config.configId(), config.tenantId(), System.currentTimeMillis()));

        return UriComponentsBuilder.fromUriString(config.authorizationEndpoint())
                .queryParam("response_type", "code")
                .queryParam("client_id", config.clientId())
                .queryParam("redirect_uri", props.getOidc().getRedirectUri())
                .queryParam("scope", String.join(" ", config.scopes()))
                .queryParam("state", state)
                .queryParam("nonce", nonce)
                .queryParam("code_challenge", codeChallenge)
                .queryParam("code_challenge_method", "S256")
                .build()
                .encode()
                .toUriString();
    }

    /** ② 回调：换 token → 验 ID Token → JIT → 组映射 → 签发。 */
    public LoginResponse handleCallback(String code, String state) {
        OidcAuthSession session = sessionStore.take(state);
        if (session == null) {
            throw AuthException.unauthorized(ErrorCode.STATE_INVALID);
        }
        OidcProviderConfig config = oidcProviderConfigService.loadById(session.configId());

        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", "authorization_code");
        form.add("code", code);
        form.add("redirect_uri", props.getOidc().getRedirectUri());
        form.add("client_id", config.clientId());
        form.add("client_secret", config.clientSecret());
        form.add("code_verifier", session.codeVerifier());

        Map<String, Object> tokenResponse = providerClient.postForm(config.tokenEndpoint(), form);
        Object idToken = tokenResponse.get("id_token");
        if (idToken == null) {
            throw AuthException.unauthorized(ErrorCode.IDP_NO_ID_TOKEN);
        }
        VerifiedClaims claims = idTokenVerifier.verify(String.valueOf(idToken), config, session.nonce());

        JitProvisioner.JitResult jit = oidcAuthenticator.authenticate(config, claims);
        syncGroupRoles(config, jit.membership(), claims);
        return tokenService.issueAfterSuccessfulSignIn(jit.principal(), jit.membership(), config.providerKey());
    }

    private void syncGroupRoles(OidcProviderConfig config, MembershipPO membership, VerifiedClaims claims) {
        List<IdpGroupMappingPO> mappings = idpGroupMappingRepository.findActiveByConfig(config.configId());
        List<String> desiredRoleIds = new ArrayList<>();
        for (IdpGroupMappingPO m : mappings) {
            if (groupMatches(m, claims.groups())) {
                desiredRoleIds.add(m.getTargetRoleId().trim());
            }
        }
        // 组映射导致角色绑定变化 → bump 令牌版本（方案 c），本次签发的新 token 带上新 ver
        if (roleSyncService.syncIdpRoles(membership.getMembershipId(), desiredRoleIds)) {
            tokenVersionService.bump(membership.getMembershipId(), "ROLE_CHANGE");
        }
    }

    private boolean groupMatches(IdpGroupMappingPO mapping, List<String> groups) {
        if (groups == null || groups.isEmpty()) {
            return false;
        }
        if ("REGEX".equalsIgnoreCase(mapping.getMatchMode())) {
            Pattern pattern = Pattern.compile(mapping.getMatchValue());
            return groups.stream().anyMatch(g -> g != null && pattern.matcher(g).matches());
        }
        // EXACT：兼容 IdP 组名的两种形态——纯名（agent-operators）或完整组路径（/agent-operators、/a/b/agent-operators）
        String matchValue = mapping.getMatchValue();
        return groups.stream().anyMatch(g -> g != null
                && (g.equals(matchValue) || g.endsWith("/" + matchValue)));
    }

    private String randomUrlSafe(int bytes) {
        byte[] buf = new byte[bytes];
        new SecureRandom().nextBytes(buf);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(buf);
    }

    private String s256(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.US_ASCII));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (Exception e) {
            throw new IllegalStateException("PKCE 生成失败", e);
        }
    }
}

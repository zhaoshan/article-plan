package com.unify.iam.app.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.nimbusds.jose.jwk.RSAKey;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * 私钥来源优先级测试（2026-11-12）：文件存在 → 读文件；文件不存在 → 环境变量 PEM
 * （兼容字面 \n 转义）；两者皆无且路径为空 → 拒绝启动（禁止每重启换钥）。
 */
class RsaKeyManagerSourceTest {

    @TempDir
    Path tempDir;

    /** 生成一把 key 并把 PEM 内容拿到（兼作"环境变量值"素材） */
    private String[] generateKeyAndReadPem(String fileName) throws Exception {
        Path path = tempDir.resolve(fileName);
        RsaKeyManager m = new RsaKeyManager(props(path));
        m.afterPropertiesSet();
        return new String[]{m.signingKey().getModulus().toString(), Files.readString(path)};
    }

    private com.unify.iam.app.config.IamProperties props(Path keyPath) {
        com.unify.iam.app.config.IamProperties props = new com.unify.iam.app.config.IamProperties();
        props.getJwt().setPrivateKeyPath(keyPath == null ? "" : keyPath.toString());
        return props;
    }

    @Test
    void fileWinsWhenBothFileAndEnvPresent() throws Exception {
        String[] fileKey = generateKeyAndReadPem("file-wins.pem");
        // 环境变量给另一把 key：文件必须赢
        String[] envKey = generateKeyAndReadPem("env-loses.pem");
        RsaKeyManager m = new RsaKeyManager(props(tempDir.resolve("file-wins.pem")));
        RSAKey key = m.loadOrCreate(tempDir.resolve("file-wins.pem"), "iam-key-1", envKey[1]);
        assertThat(key.getModulus().toString()).isEqualTo(fileKey[0]);
    }

    @Test
    void envVarUsedWhenFileMissing() throws Exception {
        String[] envKey = generateKeyAndReadPem("env-source.pem");
        Files.delete(tempDir.resolve("env-source.pem"));
        RsaKeyManager m = new RsaKeyManager(props(tempDir.resolve("not-exists.pem")));
        RSAKey key = m.loadOrCreate(tempDir.resolve("not-exists.pem"), "iam-key-1", envKey[1]);
        assertThat(key.getModulus().toString()).isEqualTo(envKey[0]);
    }

    @Test
    void envVarWithEscapedNewlinesWorks() throws Exception {
        String[] envKey = generateKeyAndReadPem("escaped.pem");
        Files.delete(tempDir.resolve("escaped.pem"));
        String escaped = envKey[1].replace("\n", "\\n");
        RsaKeyManager m = new RsaKeyManager(props(tempDir.resolve("not-exists.pem")));
        RSAKey key = m.loadOrCreate(tempDir.resolve("not-exists.pem"), "iam-key-1", escaped);
        assertThat(key.getModulus().toString()).isEqualTo(envKey[0]);
    }

    @Test
    void refusesStartupWhenNeitherSourceAvailable() {
        RsaKeyManager m = new RsaKeyManager(props(null));
        assertThatThrownBy(() -> m.loadOrCreate(null, "iam-key-1", null))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("IAM_JWT_PRIVATE_KEY");
    }
}

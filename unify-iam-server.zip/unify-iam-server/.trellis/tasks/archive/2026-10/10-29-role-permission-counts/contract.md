# 前后端字段约定

实际接口：`GET /api/v1/admin/roles?scope_type=TENANT&scope_id=<tenant_id>`（PLATFORM 同样适用）。原有鉴权、作用域与信封保持现有行为。

成功响应示例（仅列相关字段）：

```json
{"success":true,"code":"...","message":"...","data":{"roles":[{"role_id":"...","permissionCounts":2},{"role_id":"...","permissionCounts":0}],"count":2}}
```

- `permissionCounts` 大小写严格如此，每个角色均包含该字段，JSON 数字且非负；无权限为 0。
- 前端 Permissions 列读取 `role.permissionCounts`。
- 语义等同现有权限回显 permission_ids 的数量：只统计未逻辑删除的直接绑定，不引入运行时 JWT 权限过滤规则。
- 不增加接口请求，不改变原有角色字段。

# 登录服务间令牌配置排查与修复

日期：2026-10-29；当前后端分支 dev/261026_v0.2。

- 遵守当前工作区 CLAUDE.md 与安全规则；AGENTS.md 和 .trellis/workflow.md 仍不存在。
- 保留当前 Git 状态，不提交、切换分支或操作 worktree。
- 已复现 POST /api/v1/auth/user-exists 返回 403，message 为“邮箱判定未启用：请配置 iam.versions.service-token”。
- 后端 application.yml 使用 IAM_VERSIONS_SERVICE_TOKEN 注入；既有 launchd 服务及 launchd 全局环境均未配置该变量。
- 用户提及 Web .env.local，但此前限定只访问后端，已请求允许只读检查 Web 规则与本地代理/env，以复用既有令牌修复本机运行配置；不输出秘密。
- 后续验证目标：已有 token 经 Web 代理访问返回 200；后端无 token/错误 token 仍拒绝；健康状态 UP；记录脱敏结果。

## 最终执行结果

用户随后明确表示已手动添加 Java 配置，并要求重启。按最新请求保留该配置，没有继续读取 Web token 或修改 Web 文件。

- 当前源码 application.yml 已更新，旧 JAR 尚未包含配置；为确保重启生效，停止既有 launchd 服务后执行 mvn package -DskipTests -Dmaven.compiler.proc=full，BUILD SUCCESS。
- 重新加载同一 launchd 服务，PID 93058，监听 8090。health/readiness HTTP 200 UP；JWKS HTTP 200，1 把公钥。
- 使用用户配置的服务间令牌（仅内存读取，不记录值）验证 user-exists：HTTP 200，platform_admin 存在，password 模式。
- 不提供令牌时由之前的配置缺失 403 变为正确的鉴权失败 401，确认配置已生效且鉴权仍启用。
- 未修改用户手动添加的配置，未执行提交、分支或 worktree 操作。未执行浏览器验证；用户可刷新登录页后重试账号判定。

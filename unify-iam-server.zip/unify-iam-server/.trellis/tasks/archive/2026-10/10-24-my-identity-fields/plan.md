# My identity fields implementation plan

Date: 2026-10-24

Status: In progress.

## Scope and constraints

- Work only in the current `platform-iam-service` worktree.
- Keep all task, plan, session, and validation artifacts under this repository's `.trellis/` directory.
- Do not access, modify, create, or inspect another Platform IAM project.
- Do not create or delete a worktree; do not switch, reset, commit, merge, or push a branch.
- Preserve the `/api/v1/**` `{success, code, message, data}` envelope and the existing Bearer-token authentication semantics.
- The current worktree contains no `AGENTS.md` and no `.trellis/workflow.md`, including hidden-path searches. The available project instructions are `CLAUDE.md` and `.claude/rules/security.md`; no undocumented Trellis confirmation gate can be inferred.

## Confirmed contract

The frontend trace confirms that My identity calls:

```text
GET /api/v1/auth/me
Authorization: Bearer <access token>
```

The response remains a flat object inside `data`, using the endpoint's established camelCase names:

```json
{
  "success": true,
  "code": null,
  "message": null,
  "data": {
    "userId": "...",
    "userName": "...",
    "email": "...",
    "registrationSource": "SELF_SERVICE",
    "lastSignInAt": "2026-10-24T12:34:56",
    "tenantId": "...",
    "membershipId": "...",
    "roles": [],
    "permissions": [],
    "attrs": {}
  }
}
```

`email` and `lastSignInAt` are omitted when their database values are null because the existing global Jackson policy is `non_null`. `registrationSource` comes from a non-null schema field for existing accounts. If a still-valid legacy token references a now-missing logical user row, only the original claims context remains and profile fields are omitted; this preserves the endpoint's existing token behavior without looking up another account.

## Data and authorization model

- `email` maps from `gateway_user.primary_email`.
- `registrationSource` maps from `gateway_user.registration_source`.
- `lastSignInAt` maps from `gateway_user.last_login_time`; it is a `LocalDateTime` serialized as local ISO-8601 `yyyy-MM-dd'T'HH:mm:ss` with no UTC offset because the existing MySQL column is `DATETIME`.
- The user lookup takes only `JwtClaims.userId()` from the successfully verified Bearer token. There is no caller-supplied user, tenant, membership, or query parameter to influence the lookup.
- Tenant ID, membership ID, roles, permissions, and attrs remain from the verified token claims. The change does not grant an additional permission and does not query another tenant.
- A successful local-password or OIDC interactive sign-in updates the user-level `last_login_time`; refresh and switch-tenant token issuance do not. Dev-token issuance remains excluded because it is not an end-user sign-in.

## Implementation checklist

- [x] Read project instructions and security constraints; confirm the requested AGENTS/Trellis workflow files are absent.
- [x] Locate the frontend-consumed route and current backend implementation.
- [x] Locate existing account data fields and verify that user-level last-login time has no current write path.
- [x] Add a dedicated `/auth/me` response DTO and self-only mapping.
- [x] Record successful local-password and OIDC sign-ins to `gateway_user.last_login_time`.
- [x] Add MVC and integration tests covering populated values, null omission, self-only lookup, local sign-in tracking, and OIDC sign-in tracking.
- [x] Update API contract documentation with data source, format, and absence behavior.
- [x] Run focused tests and record results in `check.jsonl`.

## Verification target

1. Unit/MVC test checks exact field nesting and camelCase names inside the envelope.
2. Integration test verifies a local successful login writes `last_login_time` and `/auth/me` exposes the caller's email/source/timestamp.
3. OIDC integration test verifies a successful OIDC callback writes the same user-level timestamp.
4. Existing authorization context fields and unauthorized behavior remain unchanged.

## Validation result

The focused Maven run completed successfully with `-Dmaven.compiler.proc=full` under the repository's JDK 26 environment:

```text
mvn -pl iam-app -am test -Dtest='AuthControllerTest,TokenServiceTest,P3LoginUiIntegrationTest,OidcSsoIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
```

`TokenServiceTest` (5), `P3LoginUiIntegrationTest` (4), `AuthControllerTest` (10), and `OidcSsoIntegrationTest` (9) passed: 28 tests total, with no failures or errors. The first sandboxed attempt compiled successfully but could not attach Mockito's Byte Buddy agent; the rerun with the required Docker/JVM capabilities passed.

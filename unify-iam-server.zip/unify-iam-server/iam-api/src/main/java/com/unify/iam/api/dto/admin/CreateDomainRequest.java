package com.unify.iam.api.dto.admin;

import jakarta.validation.constraints.NotBlank;

/** 域名创建请求（管理面）：域名 + 可选验证方式。 */
public record CreateDomainRequest(
        @NotBlank(message = "domain 不能为空") String domain,
        String challengeType) {
}

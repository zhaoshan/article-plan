# Tenant role candidates and member Source

## Goal
Implement the confirmed tenant role query for Invite members/Edit role and verify the real join_source field for the Source column.

## Latest user authorization
The user confirmed `/v1/admin/tenant/roles?tenant_id=<tenantId>` and explicitly instructed implementation now, superseding the prior research-only limit and any further planning/start approval gate. Follow the existing global `/api` prefix. Frontend changes belong elsewhere; only this project's main checkout may be accessed. No commits, merges, pushes, branch changes/resets, worktrees or edits to unrelated tasks. All planning/session records remain under this project's .trellis.

## Requirements / acceptance
- R1: GET `/api/v1/admin/tenant/roles?tenant_id=T` returns non-deleted canonical global PLATFORM non-builtin roles plus all T-scoped TENANT roles except template-defined Owner roles. Include tenant builtin non-Owner and DISABLED rows; do not invent extra filtering or can_assign/disabled rules.
- R2: Authenticate, require iam:member:read, authorize concrete target through TenantScopeGuard before tenant lookup and role query. Non-platform callers can query only their token tenant. Explicit nonblank tenant_id is mandatory; authorized missing/deleted target is 404.
- R3: Stable id ASC, unpaginated response data `{tenant_id,roles,count}`; typed role DTO includes scope/status/builtin/Owner metadata. Preserve existing management role listing and ACTIVE-only runtime query.
- R4: Verify members list exposes persisted join_source for Source after Role. Add regression coverage rather than duplicate fields.
- R5: Verify write compatibility. Do not enable new PLATFORM grants, change platform-admin detection or add unapproved UI禁选 policy. Record the precise existing invitation/edit blockers and security decision separately if safe implementation cannot resolve them.
- R6: Frontend contract remains Edit skeleton during fetch and enabled Invite trigger with pending panel skeleton or completed options; no frontend source access in this task.

## Pending product decision (isolated from approved query implementation)
PLATFORM bindings confer platform scope authority today. The user has not approved the grant-identity implication. A successful candidate read is not a new grant authorization. Invitation PLATFORM support and comprehensive member grant policy cannot be declared complete; report this blocker explicitly rather than pretending returned roles are all safely writable.

## Validation
Endpoint binding/auth/tenant isolation, exact OR union, template Owner exclusion, non-owner builtin retention, soft-delete/disabled/order/count, existing role APIs, Source projection and current write behavior regression. Keep task in_progress if the write policy remains unresolved; no archive/commit.

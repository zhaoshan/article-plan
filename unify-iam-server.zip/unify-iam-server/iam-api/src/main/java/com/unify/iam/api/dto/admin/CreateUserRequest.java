package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 管理员建用户：用户名/邮箱/密码（本地账号）+ 可选全名。 */
public record CreateUserRequest(
        @NotBlank(message = "username 不能为空") String username,
        String email,
        @NotBlank(message = "password 不能为空") String password,
        @JsonProperty("full_name") String fullName) {
}

package com.unify.iam.app.authenticator;

import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.identity.app.service.IdentityVerificationService;
import org.springframework.stereotype.Component;

/**
 * 本地密码认证：username/password → BCrypt 校验 → UserPrincipal（E2E-1 逻辑迁入）。
 */
@Component
public class LocalPasswordAuthenticator implements Authenticator {

    private final IdentityVerificationService identityVerificationService;

    public LocalPasswordAuthenticator(IdentityVerificationService identityVerificationService) {
        this.identityVerificationService = identityVerificationService;
    }

    @Override
    public String mechanism() {
        return "local_password";
    }

    public UserPrincipal authenticate(String username, String password) {
        return identityVerificationService.verify(username, password);
    }
}
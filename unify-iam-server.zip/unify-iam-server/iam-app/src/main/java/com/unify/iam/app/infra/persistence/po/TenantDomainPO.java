package com.unify.iam.app.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_tenant_domain 租户域名表 PO（P3 域名验证）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_tenant_domain")
public class TenantDomainPO extends BaseEntity {

    private String tenantDomainId;
    private String tenantId;
    private String domain;
    private String domainType;
    private String verificationStatus;
    private String joinPolicy;
    private Integer isPrimary;
    private Integer isPublicEmailDomain;
    private LocalDateTime verifiedAt;
    private LocalDateTime lastCheckedAt;
    private String remarks;
}

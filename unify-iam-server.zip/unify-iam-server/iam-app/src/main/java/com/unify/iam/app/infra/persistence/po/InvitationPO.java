package com.unify.iam.app.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_invitation 租户邀请表 PO（P3 登录 UI 后端）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_invitation")
public class InvitationPO extends BaseEntity {

    private String invitationId;
    private String tenantId;
    private String email;
    private String inviteType;
    private String invitationStatus;
    private String inviteTokenHash;
    private String defaultRoleId;
    /** G2 增强：邀请隐含应用参数（redirect_url 解析；缺省默认应用） */
    private String appCode;
    private String invitedByUserId;
    private String acceptedByUserId;
    private String message;
    private LocalDateTime expiresAt;
    private LocalDateTime acceptedAt;
}

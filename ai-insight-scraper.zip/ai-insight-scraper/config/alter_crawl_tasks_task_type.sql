-- ============================================================
-- 修复 task_type 字段长度不足（scheduled_full_site 为 19 字符）
-- 同时补充 crawl_tasks.schedule_id 字段与索引（如尚未添加）
-- 适用于已有数据库的升级
-- 注意：MySQL 不支持 ADD COLUMN IF NOT EXISTS，请按需拆分执行
-- ============================================================

-- 1. 扩长 task_type 字段
ALTER TABLE crawl_tasks
    MODIFY COLUMN task_type VARCHAR(32) NOT NULL
        COMMENT '任务类型: tree / dynamic / full_site / scheduled_full_site / content【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】';

-- 2. 新增 schedule_id 字段（如已存在会报错，请先确认）
ALTER TABLE crawl_tasks
    ADD COLUMN schedule_id VARCHAR(36) NULL
        COMMENT '关联 crawl_schedules.schedule_id，周期性调度任务时填写【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】'
        AFTER finished_at;

-- 3. 新增索引（如已存在会报错，请先确认）
ALTER TABLE crawl_tasks
    ADD INDEX idx_task_schedule_id (schedule_id);

package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/**
 * 登录响应：{@code POST /api/v1/auth/token} 返回体。
 *
 * <p>字段形状与 parlant 登录 BFF（{@code routers/auth.py}）及迷你 IAM 对齐：
 * parlant 读 {@code access_token} / {@code token_type} / {@code expires_in} / {@code user}。
 */
public record TokenUser(
        @JsonProperty("user_id") String userId,
        @JsonProperty("user_name") String userName,
        List<String> roles,
        List<String> permissions) {
}

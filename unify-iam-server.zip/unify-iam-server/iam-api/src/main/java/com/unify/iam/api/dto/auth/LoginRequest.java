package com.unify.iam.api.dto.auth;

import jakarta.validation.constraints.NotBlank;

/**
 * 登录请求：{@code POST /api/v1/auth/token} 请求体（parlant 登录 BFF 原样转发）。
 */
public record LoginRequest(
        @NotBlank(message = "username 不能为空") String username,
        @NotBlank(message = "password 不能为空") String password) {
}

"""API 鉴权依赖

基于 Bearer Token 的鉴权，区分对外接口（/v2/*，public_token）和
内部接口（/api/*，internal_token）。

用法：
    from src.core.auth import require_public_token, require_internal_token

    @router.post("/v2/scrape", dependencies=[Depends(require_public_token)])
    @router.post("/api/crawl/tree", dependencies=[Depends(require_internal_token)])

鉴权机制：请求头 Authorization: Bearer <token>
"""

from __future__ import annotations

import logging

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from src.config.system_config import load_system_config

logger = logging.getLogger(__name__)

# FastAPI 内置 Bearer 解析器，auto_error=False 让我们自定义错误响应
_security_scheme = HTTPBearer(auto_error=False)


def _load_auth_config():
    """加载鉴权配置（每次调用读取，支持运行时热更新）"""
    return load_system_config().auth


def _extract_token(credentials: HTTPAuthorizationCredentials | None) -> str:
    """从请求头提取 Bearer Token，缺失或格式错误返回空串"""
    if credentials is None or not credentials.credentials:
        return ""
    return credentials.credentials.strip()


def _verify_token(token: str, expected: str, scope: str) -> None:
    """校验 token 是否匹配，不匹配抛 401"""
    # 配置为空时直接拒绝（避免无 token 时接口裸奔）
    if not expected:
        logger.error(f"{scope} token 未配置，拒绝访问")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"服务端未配置 {scope} 鉴权 token",
        )
    if not token or token != expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="无效或缺失的鉴权 token",
            headers={"WWW-Authenticate": "Bearer"},
        )


def require_public_token(
    credentials: HTTPAuthorizationCredentials | None = Depends(_security_scheme),
) -> None:
    """对外接口（/v2/*）鉴权依赖：校验 public_token"""
    token = _extract_token(credentials)
    auth = _load_auth_config()
    _verify_token(token, auth.public_token, "public")


def require_internal_token(
    credentials: HTTPAuthorizationCredentials | None = Depends(_security_scheme),
) -> None:
    """内部接口（/api/*）鉴权依赖：校验 internal_token"""
    token = _extract_token(credentials)
    auth = _load_auth_config()
    _verify_token(token, auth.internal_token, "internal")

"""src.routers — FastAPI 路由接口"""

from src.routers.crawl import router as crawl_router
from src.routers.link_tree import router as link_tree_router
from src.routers.content import router as content_router
from src.routers.v2_public import router as v2_public_router
from src.routers.schedules import router as schedule_router

__all__ = [
    "crawl_router",
    "link_tree_router",
    "content_router",
    "v2_public_router",
    "schedule_router",
]

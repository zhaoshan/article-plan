package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** iam_tenant_application 租户启用应用表 PO（docs/06 §2.3，m:n：一个租户可启用多个应用）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("iam_tenant_application")
public class TenantApplicationPO extends BaseEntity {

    /** 租户应用业务唯一标识 */
    private String tenantAppId;
    /** 所属租户 ID */
    private String tenantId;
    /** 启用的应用编码 */
    private String appCode;
}

-- ============================================================
-- 手动插入 tokyostarbank.co.jp 定时调度配置
-- 执行周期：每周三凌晨 2 点（cron: 0 2 * * 3）
-- 输出方式：s3（如需本地输出，请将 output_type 改为 'local'）
-- ============================================================

INSERT INTO crawl_schedules (
    schedule_id,
    site,
    target_url,
    cron_expression,
    timezone,
    enabled,
    max_depth,
    headless,
    output_type,
    description,
    create_time,
    update_time
) VALUES (
    '5b5e7be4-0bc5-46a5-89c2-e8b25ef70c6c',
    'tokyostarbank.co.jp',
    'https://www.tokyostarbank.co.jp/',
    '0 2 * * 3',
    'Asia/Tokyo',
    1,
    NULL,
    1,
    's3',
    'tokyostarbank.co.jp 每周三凌晨 2 点全站链接树定时爬取',
    NOW(),
    NOW()
);

# 成员列表邮箱核验计划

## 范围与约束

- 仅当前 platform-iam-service 主工作区、当前分支 `feature/v0.10.3-m10w3`，处理成员列表邮箱契约。
- 保留启动时已有的 tenant-member-search-projection 任务记录改动；不操作其他项目、分支、worktree 或提交。
- 当前项目不存在 AGENTS.md 和 .trellis/workflow.md；已读取 CLAUDE.md 及 .claude/rules，沿用 .trellis/tasks 计划、实施、验证、会话记录流程。没有发现适用于本次非提交操作的确认门禁。

## 可审阅步骤

1. 核验 Controller → 查询服务 → 共享投影 → UserRepository 的真实主邮箱读取及批量查询。
2. 当前实现已经把 gateway_user.primary_email 映射到 data.members[].email；保留现有 DTO、查询参数、其他响应字段和现有截断行为，不重复修改已满足需求的业务逻辑。
3. 在 API 手册明确 email 的 JSON 路径、真实数据来源、无邮箱时省略字段的现有非 null 序列化语义。
4. 运行现有真实 MySQL 隔离集成回归，覆盖有邮箱、无邮箱、用户缺失/逻辑删除、列表/详情一致性、权限及兼容性；检查 diff，保存验证与交接记录。

## 验收

- 有邮箱返回真实 email；无邮箱不伪造、不回退到用户名，字段省略。
- 用户资料使用单次集合查询，不在成员循环内逐用户读取。
- 当前接口不新增分页，现有请求及其他响应字段保持不变。

## 完成结果

- 四步均完成。现有 DTO、批量查询、Map 映射和真实 HTTP 序列化符合需求，无需改动生产代码。
- API 手册补充 email 来源、JSON 路径和 NULL 省略语义。
- 三个集成测试类共 19 项通过（0 失败/错误/跳过），Maven BUILD SUCCESS，git diff --check 通过。
- 全部本轮改动未暂存、未提交；既有并行改动保留。未重启运行服务，验证结果只对应当前源码。

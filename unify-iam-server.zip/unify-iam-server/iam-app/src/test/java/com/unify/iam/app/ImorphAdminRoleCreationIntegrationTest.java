package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.transaction.annotation.Transactional;

@Transactional
class ImorphAdminRoleCreationIntegrationTest extends IamIntegrationTestBase {
    @Autowired private JwtSigner signer;

    @Test
    void realAdminLoginCanCreateOwnTenantRolesButCannotCrossScopeAndMemberRemainsReadOnly() throws Exception {
        String platform = login("admin", "admin123");
        String tenant = createTenant(platform, "admin-role-create");
        String admin = createMemberAndLogin(platform, tenant, "role_admin", "iMorph-Admin");
        String member = createMemberAndLogin(platform, tenant, "role_member", "iMorph-Member");

        assertThat(signer.verify(admin).tenantId()).isEqualTo(tenant);
        assertThat(signer.verify(admin).roles()).contains("iMorph-Admin").doesNotContain("PlatformAdmin");
        assertThat(signer.verify(admin).permissions()).contains("iam:role:read", "iam:role:write");
        assertThat(signer.verify(member).permissions()).contains("iam:role:read").doesNotContain("iam:role:write");

        String role = write("/api/v1/admin/roles", admin,
                Map.of("scope_type", "TENANT", "scope_id", tenant, "role_name", "Created by tenant Admin"))
                .get("role_id").toString();
        assertThat(jdbcTemplate.queryForMap("SELECT scope_type, scope_id FROM gateway_role WHERE role_id=?", role))
                .containsEntry("scope_type", "TENANT").containsEntry("scope_id", tenant);
        for (Map<String, String> scope : List.of(Map.of("scope_type", "TENANT", "scope_id", "tenant-org-a"),
                Map.of("scope_type", "PLATFORM", "scope_id", "PLATFORM"))) {
            mockMvc.perform(post("/api/v1/admin/roles").header("Authorization", "Bearer " + admin)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(JsonUtils.toJson(Map.of("scope_type", scope.get("scope_type"),
                                    "scope_id", scope.get("scope_id"), "role_name", "Forbidden"))))
                    .andExpect(status().isForbidden());
        }
        mockMvc.perform(post("/api/v1/admin/roles").header("Authorization", "Bearer " + member)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("scope_type", "TENANT", "scope_id", tenant, "role_name", "Forbidden"))))
                .andExpect(status().isForbidden());
    }

    @Test
    void repeatableSeedRepairsMissingAndTombstonedAdminBindingsIdempotentlyWithoutGrantingOtherRoles() throws Exception {
        String platform = login("admin", "admin123");
        String first = createTenant(platform, "admin-backfill-a");
        String second = createTenant(platform, "admin-backfill-b");
        String missing = roleId(first, "iMorph-Admin");
        String tombstoned = roleId(second, "iMorph-Admin");
        jdbcTemplate.update("DELETE FROM gateway_role_permission WHERE role_id=? AND permission_id='p-2008'", missing);
        jdbcTemplate.update("UPDATE gateway_role_permission SET delete_flag=1 WHERE role_id=? AND permission_id='p-2008'", tombstoned);
        String originalBinding = jdbcTemplate.queryForObject("SELECT role_permission_id FROM gateway_role_permission WHERE role_id=? AND permission_id='p-2008'", String.class, tombstoned);
        jdbcTemplate.update("INSERT INTO gateway_role (role_id,scope_type,scope_id,role_code,role_name,role_status,delete_flag) VALUES ('excluded-platform-admin','PLATFORM','PLATFORM','iMorph-Admin','Admin','ACTIVE',0), ('excluded-deleted-admin','TENANT',?,'iMorph-Admin','Admin','ACTIVE',1)", "deleted-admin-tenant");

        for (int replay = 0; replay < 2; replay++) {
            jdbcTemplate.execute((ConnectionCallback<Void>) connection -> {
                ScriptUtils.executeSqlScript(connection, new ClassPathResource("db/seed/R__app_imorph.sql"));
                return null;
            });
            for (String id : List.of(missing, tombstoned)) {
                assertThat(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM gateway_role_permission WHERE role_id=? AND permission_id='p-2008' AND delete_flag=0", Integer.class, id)).isEqualTo(1);
                assertThat(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM gateway_role_permission WHERE role_id=? AND permission_id='p-2008'", Integer.class, id)).isEqualTo(1);
            }
            assertThat(jdbcTemplate.queryForObject("SELECT role_permission_id FROM gateway_role_permission WHERE role_id=? AND permission_id='p-2008'", String.class, tombstoned)).isEqualTo(originalBinding);
            assertThat(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM gateway_role_permission WHERE permission_id='p-2008' AND role_id IN (?, 'excluded-platform-admin','excluded-deleted-admin')", Integer.class, roleId(first, "iMorph-Member"))).isZero();
            String json = jdbcTemplate.queryForObject("SELECT permission_codes_json FROM iam_application_role_template WHERE template_id='tpl-3002'", String.class);
            assertThat(JsonUtils.fromJson(json, List.class)).filteredOn("iam:role:write"::equals).hasSize(1);
            String memberJson = jdbcTemplate.queryForObject("SELECT permission_codes_json FROM iam_application_role_template WHERE template_id='tpl-3003'", String.class);
            assertThat(JsonUtils.fromJson(memberJson, List.class)).doesNotContain("iam:role:write");
        }
    }

    private String createTenant(String platform, String code) throws Exception {
        return write("/api/v1/admin/tenants", platform, Map.of("tenant_code", code,
                "tenant_name", code, "app_codes", List.of("imorph"))).get("tenant_id").toString();
    }

    private String createMemberAndLogin(String platform, String tenant, String username, String roleCode) throws Exception {
        String user = write("/api/v1/admin/users", platform, Map.of("username", username,
                "password", b64("Passw0rd!"))).get("user_id").toString();
        String membership = write("/api/v1/admin/members", platform, Map.of("tenant_id", tenant, "user_id", user,
                "role_ids", List.of(roleId(tenant, roleCode)))).get("membership_id").toString();
        // Admin-added memberships are not default; the login fixture needs an explicit default.
        jdbcTemplate.update("UPDATE gateway_membership SET is_default=1 WHERE membership_id=?", membership);
        return login(username, "Passw0rd!");
    }

    private String roleId(String tenant, String code) {
        return jdbcTemplate.queryForObject("SELECT role_id FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND role_code=? AND delete_flag=0", String.class, tenant, code);
    }

    private String login(String username, String password) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/auth/token").contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64(password)))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString()).get("access_token").toString();
    }

    private Map<String, Object> write(String path, String token, Object body) throws Exception {
        return unwrapData(mockMvc.perform(post(path).header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON).content(JsonUtils.toJson(body)))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    }
}

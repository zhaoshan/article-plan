# Audit query keyword and time-range filters

Date: 2026-10-26

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, plan, session, contract, and validation records under this repository's `.trellis/` directory.
- Do not access another Platform IAM project, create/delete a worktree, switch/reset a branch, commit, merge, or push.
- The requested `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree. The applicable instructions are `CLAUDE.md` and `.claude/rules/security.md`; neither defines an additional confirmation gate for this concrete backward-compatible API extension.

## Confirmed root cause

`AdminAuditController` currently passes only `tenant_id`, exact `event_type`, and exact
`actor_user_id` to `AuditLogRepository`. The repository uses `eq(...)` for each nonblank
value. `event_name` and `actor_username` are projected only after the paged audit rows have
already been selected, so neither can participate in the old database filter. No
`start_time`/`end_time` request parameter exists.

The frontend must issue a fresh `GET /api/v1/admin/audit` whenever any filter changes and reset
`page` to `1`; a server cannot observe a local control-state change unless the browser sends a
new request. This task supplies the missing server-side query contract and does not modify the
separate frontend repository.

## Additive request contract

`GET /api/v1/admin/audit` continues to require a Bearer token with `iam:audit:read` and keeps all
existing optional parameters: `tenant_id`, `event_type`, `actor_user_id`, `page`, and `size`.

| Parameter | Meaning | Validation and composition |
|---|---|---|
| `keyword` | Literal contains search across `event_type`, the catalog-derived `event_name`, `actor_user_id`, and the visible `actor_username`. | Optional; trimmed; blank means absent; at most 100 characters. It is ANDed with all other supplied filters. |
| `start_time` | Range start. | Optional only together with `end_time`; ISO-8601 offset datetime is preferred, for example `2026-10-26T00:00:00+08:00`; legacy offset-less Shanghai local form is also accepted; inclusive. |
| `end_time` | Range end. | Required when `start_time` is supplied; same accepted formats; exclusive; must be strictly after `start_time` after Shanghai normalization. A whole local calendar day is `[YYYY-MM-DDT00:00:00+08:00, next-dayT00:00:00+08:00)`. |

`gateway_audit_log.create_time` is an existing MySQL `DATETIME` and the current datasource is
configured with `serverTimezone=Asia/Shanghai`; it does not persist an offset. Therefore this
extension treats an offset-bearing timestamp as an instant and normalizes it to Shanghai local
time before querying. It also accepts the original offset-less Shanghai local form for backward
compatibility. Existing response field `create_time` stays the current ISO local datetime string.

The success body stays `{audits,total,page,size}`. Existing `event_type` and `actor_user_id`
remain exact-match filters. `keyword` does not change any stored audit data or row field.

## Query and performance design

- `event_type` remains a parameterized contains predicate so catalog-unknown event codes remain searchable.
- The static `AuditEventCatalog` maps a matching display name back to its event code; this makes Chinese
  `event_name` values searchable without denormalizing mutable presentation text into audit rows.
- The audit query joins the user directory only to match the same actor username that the response already
  exposes. It does not add email, profile, secret, or new response data to the search surface.
- Arbitrary contains search (`%keyword%`) is intentionally bounded by the existing page cap and cannot use a
  conventional B-tree index. The time-range UI should send a range by default for large audit histories.
- A new Flyway migration adds `(create_time, id)` and `(tenant_id, create_time, id)` indexes. They support
  global and tenant-scoped time windows with the deterministic `create_time DESC, id DESC` ordering. The
  existing `(tenant_id, event_type, create_time)` index continues to serve combined exact tenant/event filters.

## Checklist

- [x] Read the actual project/security instructions and document the absent requested workflow files.
- [x] Trace controller, service, projection, repository, schema, indexes, and existing audit tests.
- [x] Define the additive request/response contract, time zone, boundaries, validation, and index strategy.
- [x] Implement parsing, keyword resolution, and repository filtering.
- [x] Add Flyway indexes without editing an applied migration.
- [x] Add focused integration coverage for event-code/name, actor-user, time boundaries, and invalid ranges.
- [x] Run focused Maven validation and record results.

## Validation result

```text
mvn -pl iam-app -am -DskipTests compile -Dmaven.compiler.proc=full
# BUILD SUCCESS

mvn -pl iam-app -am test -Dtest='AdminAuditQueryIntegrationTest,P3AdminIntegrationTest,AuditCompletenessIntegrationTest' \
  -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 16 tests passed, 0 failures, 0 errors
```

The initial sandboxed integration-test attempt compiled test sources but could not connect to the
local Docker socket. The same focused test suite passed with the required Testcontainers Docker
access. Flyway applied V11 during the run, so both new indexes and the dynamic query mapper were
exercised against MySQL 8.

## Cross-client offset compatibility

The frontend sends `start_time` and `end_time` such as `2026-10-22T08:00:00+08:00`. The original
`LocalDateTime.parse(..., ISO_LOCAL_DATE_TIME)` rejected that form with `DateTimeParseException`.
The final parser now first accepts `ISO_OFFSET_DATE_TIME` and converts the supplied instant to
`Asia/Shanghai`; only if that form is absent does it parse the legacy offset-less local form.
`AdminAuditQueryIntegrationTest` covers the frontend's `+08:00` input, a UTC representation of
the same Shanghai interval, and the existing local-time test preserves backward compatibility.

## Reopened: date-only contract and live-runtime proof

The primary browser contract is now paired `YYYY-MM-DD` values, not offset-bearing timestamps.
Both dates are inclusive Asia/Shanghai calendar days. The service translates them to a database
half-open interval from the start date at `00:00:00` through the day after the end date at
`00:00:00`, so a request for `2026-10-01` through `2026-10-03` excludes `2026-10-26`.

The previously completed source-only record was insufficient: the process on port 8090 is a
JAR built at 09:28, while the audit source is newer, and its startup log reports schema V10.
Port 5174 relays an IAM 401 for the same no-token audit request as port 8090, establishing the
live proxy chain. Rebuild the current JAR, allow Flyway to apply V11, restart only the verified
PID 4020, and use a locally issued ephemeral token for an aggregate-only HTTP proof through
both 5174 and 8090. No user-supplied bearer is needed or retained.

## Completion evidence

The direct and proxied date-only request both returned successful empty results for
`keyword=创建`, `start_time=2026-10-01`, and `end_time=2026-10-03`; neither response contained an
October 26 row. On the live October 26 data, the unfiltered date request returned 41 rows while
adding `keyword=创建` returned 4, with zero nonmatching rows in that page. This demonstrates that
the parameter binding and database predicates affect the active service rather than merely the
source tree.

During the controlled restart, the original verified PID changed concurrently before a signal
was sent. The final port owner was separately verified by PID, command, and listener before the
read-only checks. It is running the current-worktree JAR, reports health `UP`, and its startup log
reports Flyway schema V11. No frontend source was accessed or changed because this task is scoped
to the service and its local runtime chain.

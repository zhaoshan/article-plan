# 当前用户所属租户名称/编码

1. 读取项目说明并追踪认证、成员查询及租户关联。
2. 在现有 GET /api/v1/auth/memberships 中增量返回 tenant_code，复用 tenant_name 的数据库关联，不改变身份/权限/范围。
3. 以真实 Testcontainers MySQL 和 MockMvc 验证 member-only 用户的当前/其他所属租户、其他用户隔离、无 Bearer 拒绝以及管理端依旧拒绝。
4. 同步接口文档与本任务合同/会话/验证记录，保留未提交状态。

不修改 JWT、登录响应或 /auth/me，不新增权限或端点。保留现有 membership_status/is_default 字符串类型和列表过滤语义。

## 完成情况

四步均完成。新增 3 个 MySQL 集成用例，连同现有 P3SwitchTenantIntegrationTest 的 2 个用例共 5 个通过，0 失败、0 错误、0 跳过；git diff --check 通过。全部改动保留未提交。

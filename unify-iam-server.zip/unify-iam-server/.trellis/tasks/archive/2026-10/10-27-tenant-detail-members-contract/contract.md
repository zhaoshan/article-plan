# 前端交接：租户详情成员（2026-10-27）

## 请求与权限

`GET /api/v1/admin/tenants/{tenantId}/details`，Bearer 认证，仍同时需要 `iam:tenant:read`、`iam:member:read` 和目标租户作用域。旧 `member_page/member_size` 参数删除语义，发送亦被忽略，无须传递。无分页、无 OFFSET，数据库固定读取最多 1000 条，按内部 id 升序。

成功响应保持现有信封；以下是 `data` 的 TypeScript 形状：

```ts
type TenantRoleSummary = { role_id: string; role_code: string; role_name: string }
type TenantMemberSummary = {
  membership_id: string
  user_id: string
  user_available: boolean
  username?: string
  full_name?: string
  display_name?: string
  email?: string
  membership_status: string // 数据库存储的真实状态，包含 ACTIVE/PENDING/SUSPENDED/REMOVED
  is_default: boolean
  is_owner: boolean
  join_source?: string
  roles: TenantRoleSummary[]
}
type TenantMembers = {
  items: TenantMemberSummary[]
  total: number // 未逻辑删除成员关系真实总数，包括超过1000的部分及所有成员状态
  limit: 1000 // 返回上限，不是页大小
  truncated: boolean // total > items.length
}
// data 的 tenant/owner_assigned/owner/usage/applications shape 保持原契约；members 为上述 TenantMembers。
```

空集合是 `{items:[],total:0,limit:1000,truncated:false}`。总计 1000 条时返回1000条且 truncated=false；1001条时返回1000条、total=1001、truncated=true。没有 page/size 字段或下一页能力。不能把上限误称为全部成员。

## 真实数据与显示语义

- 集合来自 `gateway_membership.tenant_id`，逻辑删除关系不返回，其他状态保留。
- 身份资料从 `gateway_user` 按 user_id 批量读取；不使用默认租户字段、登录名/邮箱推测、claims 快照或虚构姓名。
- 用户不存在或逻辑删除：`user_available=false`，资料字段省略；仍保留真实 membership_id/user_id/status/roles。前端可显示“用户不可用”及其 ID，但不可冒充真实姓名。
- 用户存在：`user_available=true`。username 来自必填登录名；full_name/display_name/email 可空，按全局 non_null 省略。不要把缺全名误判为缺用户。
- roles 始终为数组，来自本成员真实绑定和未删除角色；缺失/删除角色或删除绑定不富化，未绑定为 `[]`。
- Owner 权威源是 `gateway_tenant.owner_user_id`。未设置时 `owner_assigned=false`，owner 省略；已设置但用户/成员不可用时 `owner_assigned=true`，owner 仍省略。is_owner 只按 Owner ID 比较，不能用首成员或 TenantAdmin 角色猜测。Owner 在1000条之外仍单独解析，不注入 items 破坏上限或排序。
- Members 使用量来自现有 usage.dimensions：ACTIVE+PENDING成员+有效PENDING邀请；与 members.total（全部状态、无邀请）口径不同，不可互换。

## 本地问题调查证据（仅只读聚合）

7 条未删除成员关系中，2 条用户主表不存在，3 条用户逻辑删除，2 条关联有效用户，其中1条 full_name/display_name 为空。统计含已删除租户历史关系。未删除租户 imorph_admin_02 的用户已删除，p-92f92b8f4b 的用户不存在；imorph_admin_01 的有效用户有登录名和邮箱但无全名/昵称。因此有成员 ID 不等于有可用用户资料；本任务不恢复或伪造业务数据。

现有 UserRepository/MembershipRepository/RoleRepository 已 trim CHAR 业务键，角色绑定键也在聚合中 trim。本地 sql_mode 没有 PAD_CHAR_TO_FULL_LENGTH；隔离 MySQL 回归强制该模式验证 ID/用户/角色/Owner 关联，不能把 CHAR 风险冒称本地已证实根因。

## 租户列表

`GET /api/v1/admin/tenants?limit=1000` 仍返回 `data:{tenants:[...],count:N}`，默认limit=20，上限1000，按id升序。count 仅为返回条数；没有分页或全库total，本任务未新增分页能力。

异常仍由现有统一信封返回真实HTTP状态；前端统一右上角toast，不在表单重复展示请求异常，客户端字段校验保持。

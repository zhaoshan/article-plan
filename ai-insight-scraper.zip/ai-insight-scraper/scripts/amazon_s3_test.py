import boto3
import os
from botocore.config import Config


# ==================== 配置区域 ====================
S3_ACCESS_KEY = "AKIATFBMPRKQJE6YVNE2"
S3_SECRET_ACCESS_KEY = "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"
S3_REGION = "us-west-2"
S3_ENDPOINT = "https://salessavvy-dev-ap-yic4oaa9qxcqpxncyer18okdymb31usw2a-s3alias.s3-accesspoint.us-west-2.amazonaws.com"
S3_BUCKET = "web-scraper"
S3_PREFIX_PATH = "local"
S3_SIGNATURE_VERSION = "s3v4"
# ==================================================


def get_s3_client():
    """创建并返回 S3 客户端"""
    my_config = Config(
        signature_version=S3_SIGNATURE_VERSION,
        region_name=S3_REGION,
    )
    client = boto3.client(
        "s3",
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_ACCESS_KEY,
        endpoint_url=S3_ENDPOINT,
        config=my_config,
    )
    return client


def build_s3_key(filename):
    """根据 prefix 拼接完整的 S3 Object Key"""
    if S3_PREFIX_PATH and S3_PREFIX_PATH.strip("/"):
        return f"{S3_PREFIX_PATH}/{filename}"
    return filename


def upload_file(local_file_path, s3_filename):
    """
    上传本地文件到 S3
    :param local_file_path: 本地文件路径
    :param s3_filename: 上传后在 S3 中显示的文件名
    """
    s3_client = get_s3_client()
    s3_key = build_s3_key(s3_filename)
    try:
        s3_client.upload_file(local_file_path, S3_BUCKET, s3_key)
        print(f"[SUCCESS] 上传完成: {local_file_path} -> s3://{S3_BUCKET}/{s3_key}")
    except Exception as e:
        print(f"[ERROR] 上传失败: {e}")


def download_file(s3_filename, local_save_path):
    """
    从 S3 下载文件到本地
    :param s3_filename: S3 中的文件名
    :param local_save_path: 本地保存路径
    """
    s3_client = get_s3_client()
    # s3_key = build_s3_key(s3_filename)
    s3_key = 'local/demo_test_file.txt'
    try:
        s3_client.download_file(S3_BUCKET, s3_key, local_save_path)
        print(f"[SUCCESS] 下载完成: s3://{S3_BUCKET}/{s3_key} -> {local_save_path}")
    except Exception as e:
        print(f"[ERROR] 下载失败: {e}")


def delete_file(s3_filename):
    """
    从 S3 删除文件
    :param s3_filename: S3 中的文件名
    """
    s3_client = get_s3_client()
    s3_key = build_s3_key(s3_filename)
    try:
        s3_client.delete_object(Bucket=S3_BUCKET, Key=s3_key)
        print(f"[SUCCESS] 删除完成: s3://{S3_BUCKET}/{s3_key}")
    except Exception as e:
        print(f"[ERROR] 删除失败: {e}")


def main():
    """主函数：演示上传、下载、删除的完整流程"""
    test_filename = "demo_test_file.txt"
    local_upload = "./upload_demo.txt"
    local_download = "./download_demo.txt"

    # 1. 创建本地测试文件
    with open(local_upload, "w", encoding="utf-8") as f:
        f.write("这是一段用来测试 S3 上传的示例文本。\nHello S3!====")

    print("========== 开始 S3 功能测试 ==========\n")

    # # 2. 测试上传
    print("--- 1. 测试上传 ---")
    upload_file(local_upload, test_filename)

    # 3. 测试下载
    print("\n--- 2. 测试下载 ---")
    download_file(test_filename, local_download)

    # 验证下载内容
    if os.path.exists(local_download):
        with open(local_download, "r", encoding="utf-8") as f:
            print(f"下载文件内容预览: {f.read()}")

    # 4. 测试删除
    print("\n--- 3. 测试删除 ---")
    delete_file(test_filename)

    # 5. 清理本地临时文件
    print("\n--- 4. 清理本地临时文件 ---")
    for path in [local_upload, local_download]:
        if os.path.exists(path):
            os.remove(path)
            print(f"已删除本地临时文件: {path}")

    print("\n========== 测试结束 ==========")


if __name__ == "__main__":
    main()
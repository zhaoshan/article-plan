# Implementation plan

1. Update request validation, code generation and creation audit atomically.
2. Add service validation and repository SQL filtering; preserve authorization before data queries.
3. Add batched tenant enrichment to list response.
4. Add meaningful controller/service/repository and MySQL integration regressions, including wildcard literals, authorization and old global request behavior.
5. Compile reactor and run focused tests with JDK 21; run role integration regressions with Docker if available. Report failed/blocked checks honestly.
6. Review full task diff and update API documentation/spec. Record results locally; leave all work uncommitted as instructed.

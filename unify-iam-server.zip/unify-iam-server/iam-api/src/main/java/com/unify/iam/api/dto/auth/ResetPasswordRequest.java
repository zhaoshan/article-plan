package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 重置密码请求：{@code POST /api/v1/auth/reset-password}。 */
public record ResetPasswordRequest(
        @NotBlank(message = "token 不能为空") String token,
        @NotBlank(message = "new_password 不能为空") @JsonProperty("new_password") String newPassword) {
}

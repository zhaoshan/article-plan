package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** iam_application_role_template 应用预置角色模板 PO（docs/06 §2.2）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("iam_application_role_template")
public class ApplicationRoleTemplatePO extends BaseEntity {

    /** 模板业务唯一标识 */
    private String templateId;
    /** 所属应用编码 */
    private String appCode;
    /** 角色作用域：TENANT=租户内 deep-copy；PLATFORM=平台级（复用/建全局角色，建租户授 owner） */
    private String scopeType;
    /** 角色编码，如 TenantAdmin */
    private String roleCode;
    private String roleName;
    private String roleDescription;
    /** 权限点 code 数组 JSON（字符串存，应用层反序列化，同 IdpConfigPO.scopesJson 惯例） */
    private String permissionCodesJson;
    /** 首人 owner 角色：0否 1是 */
    private Integer isOwner;
    /** 初始化/展示顺序，小者优先 */
    private Integer priority;
}

package com.unify.iam.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * unify-iam-server 可启动应用（E2E-1）。
 *
 * <p>{@code scanBasePackages = "com.unify.iam"} 跨模块扫描各域（identity/tenant/authorization）
 * 的 {@code @Service/@Repository} 等；{@code @MapperScan} 独立在 {@code IamPersistenceConfig}
 * （避免 WebMvcTest 切片加载 mappers）。
 */
@SpringBootApplication(scanBasePackages = "com.unify.iam")
@ConfigurationPropertiesScan
public class IamApplication {

    public static void main(String[] args) {
        SpringApplication.run(IamApplication.class, args);
    }
}

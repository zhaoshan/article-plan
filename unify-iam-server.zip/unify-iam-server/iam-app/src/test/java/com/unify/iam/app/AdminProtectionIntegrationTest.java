package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G1/G2/G3 安全缺口集成测试：
 *  G1 租户停用即时失效（bump 成员版本 + 停用期登录被拒 + 恢复后可登录）
 *  G2 成员停用/恢复（SUSPENDED + bump + 停用期登录被拒 + 恢复可登录）
 *  G3 最后管理员保护（移除/停用/降权最后一名租户管理员 → 400，状态不变）
 */
class AdminProtectionIntegrationTest extends IamIntegrationTestBase {

    private String adminToken() throws Exception {
        return login("admin", "admin123");
    }

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private long verOf(String token) throws Exception {
        return SignedJWT.parse(token).getJWTClaimsSet().getLongClaim("ver");
    }

    private String adminPost(String url, Object body) throws Exception {
        String token = adminToken();
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    private String createTenant(String code) throws Exception {
        Map<String, Object> t = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", code, "tenant_name", "Protect " + code, "tenant_type", "ORGANIZATION",
                        "app_codes", List.of("parlant-agent-server"))), Map.class);
        return t.get("tenant_id").toString();
    }

    private String createTenantWithOwner(String token, String code, String ownerUserId) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"" + code + "\",\"tenant_name\":\"" + code + "\","
                                + "\"app_codes\":[\"parlant-agent-server\"],\"owner_user_id\":\"" + ownerUserId + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
    }

    private String createMember(String tenantId, String username, List<String> roleIds) throws Exception {
        String token = adminToken();
        String userId = unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + username + "@unify.local\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString()).get("user_id").toString();
        String member = mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"" + tenantId + "\",\"user_id\":\"" + userId + "\",\"role_ids\":" + JsonUtils.toJson(roleIds) + "}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String membershipId = unwrapData(member).get("membership_id").toString();
        jdbcTemplate.update("UPDATE gateway_membership SET is_default = 1 WHERE membership_id = ?", membershipId);
        return membershipId;
    }

    private void setTenantStatus(String tenantId, String status) throws Exception {
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId)
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_status\":\"" + status + "\"}"))
                .andExpect(status().isOk());
    }

    /** G1：租户停用 → 成员 token_version bump + 停用期登录被拒 + 恢复后可登录。 */
    @Test
    void tenantDisableBumpsMembersAndBlocksLogin() throws Exception {
        String tenantId = createTenant("g1t");
        String membershipId = createMember(tenantId, "g1_user", List.of());
        assertThat(verOf(login("g1_user", "Passw0rd!"))).isZero();

        setTenantStatus(tenantId, "DISABLED");
        Integer v = jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId);
        assertThat(v).isEqualTo(1); // G1：即时失效

        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g1_user\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isUnauthorized()); // 停用租户无可用成员关系

        setTenantStatus(tenantId, "ACTIVE"); // 恢复
        assertThat(verOf(login("g1_user", "Passw0rd!"))).isEqualTo(1L); // 重新登录拿当前版本
    }

    /** 登录回落（2026-11-06 修复）：默认租户被禁用 → 登录应落到其他 ACTIVE 租户（而非整体 401）。 */
    @Test
    void loginFallsBackToAnotherActiveTenantWhenDefaultTenantDisabled() throws Exception {
        String token = adminToken();
        String userId = unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g_fallback\",\"email\":\"g-fallback@unify.local\",\"password\":\""
                                + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("user_id").toString();
        String tenantA = createTenantWithOwner(token, "gfA", userId);
        String tenantB = createTenantWithOwner(token, "gfB", userId);
        // A 设为默认，随后禁用 A
        jdbcTemplate.update("UPDATE gateway_membership SET is_default=1 WHERE tenant_id=? AND user_id=?", tenantA, userId);
        setTenantStatus(tenantA, "DISABLED");
        // 登录 → 应回落到 B 租户（修复前：401 User has no available membership）
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g_fallback\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn();
        LoginResponse login = JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class);
        com.nimbusds.jwt.JWTClaimsSet claims = com.nimbusds.jwt.SignedJWT.parse(login.accessToken()).getJWTClaimsSet();
        org.assertj.core.api.Assertions.assertThat(String.valueOf(claims.getClaim("tenantId"))).isEqualTo(tenantB);
    }

    /** 租户停用后 refresh 不可续签（修复：rotate/refresh 均漏查租户状态，停用租户可绕过续签新 token）。 */
    @Test
    void tenantDisableBlocksRefresh() throws Exception {
        String tenantId = createTenant("g1r");
        createMember(tenantId, "g1r_user", List.of());
        MvcResult loginRes = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g1r_user\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn();
        LoginResponse first = JsonUtils.fromJson(
                dataJson(loginRes.getResponse().getContentAsString()), LoginResponse.class);
        assertThat(first.refreshToken()).isNotBlank();

        setTenantStatus(tenantId, "DISABLED");

        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"" + first.refreshToken() + "\"}"))
                .andExpect(status().isUnauthorized()); // 停用租户不可续签（不轮换、不重签）

        setTenantStatus(tenantId, "ACTIVE"); // 恢复后原 refresh 仍可用（rotate 校验前置，失败不消耗）
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"" + first.refreshToken() + "\"}"))
                .andExpect(status().isOk());
    }

    /** G2：成员停用 → SUSPENDED + bump + 停用期登录被拒 + 恢复可登录。 */
    @Test
    void memberSuspendAndRestore() throws Exception {
        String membershipId = createMember("tenant-org-a", "g2_user", List.of("r-1001"));
        assertThat(verOf(login("g2_user", "Passw0rd!"))).isZero();

        mockMvc.perform(post("/api/v1/admin/members/" + membershipId + "/suspend")
                        .header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT membership_status FROM gateway_membership WHERE membership_id = ?", String.class, membershipId))
                .isEqualTo("SUSPENDED");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId))
                .isEqualTo(1); // G2：停用即时失效

        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g2_user\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isUnauthorized()); // 默认成员已停用

        mockMvc.perform(post("/api/v1/admin/members/" + membershipId + "/restore")
                        .header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isOk());
        assertThat(verOf(login("g2_user", "Passw0rd!"))).isEqualTo(1L); // 恢复后重新登录
    }

    /** G3 方式 B ①：is_owner 角色唯一持有者不可移除/停用/降权；有第二持有者可移除。 */
    @Test
    void isOwnerRoleLastHolderCannotBeRemoved() throws Exception {
        String token = adminToken();
        String tenantId = createTenant("g3o");
        // 租户内 deep-copy 的 TenantAdmin（parlant 模板 tpl-2002 is_owner=1）
        String tenantAdminRoleId = jdbcTemplate.queryForObject(
                "SELECT role_id FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND role_code='TenantAdmin'",
                String.class, tenantId);
        String owner1 = createMember(tenantId, "g3_owner1", List.of(tenantAdminRoleId));
        // 唯一 is_owner 持有者 → 移除/停用/降权均 400
        mockMvc.perform(delete("/api/v1/admin/members/" + owner1)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/v1/admin/members/" + owner1 + "/suspend")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isBadRequest());
        mockMvc.perform(put("/api/v1/admin/members/" + owner1 + "/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[]}"))
                .andExpect(status().isBadRequest());
        // 有第二持有者 → 移除第一个放行（并集判定）
        String owner2 = createMember(tenantId, "g3_owner2", List.of(tenantAdminRoleId));
        mockMvc.perform(delete("/api/v1/admin/members/" + owner1)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
    }

    /** G3：最后一名租户管理员不可移除/停用/降权（非变更断言，不影响 seed 数据）。 */
    @Test
    void lastAdminCannotBeRemovedSuspendedOrDemoted() throws Exception {
        String token = adminToken();
        // tenant-org-a 中 admin（ms-1001）是唯一持租户管理能力的成员
        mockMvc.perform(delete("/api/v1/admin/members/ms-1001")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/v1/admin/members/ms-1001/suspend")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isBadRequest());
        mockMvc.perform(put("/api/v1/admin/members/ms-1001/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"r-1001\"]}"))
                .andExpect(status().isBadRequest());

        // 状态未被破坏：ms-1001 仍 ACTIVE 且仍持有 TenantAdmin（管理能力）
        assertThat(jdbcTemplate.queryForObject(
                "SELECT membership_status FROM gateway_membership WHERE membership_id = 'ms-1001'", String.class))
                .isEqualTo("ACTIVE");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role WHERE membership_id='ms-1001' AND role_id='r-1002' AND delete_flag=0",
                Integer.class)).isEqualTo(1);
    }

    // ── G4：业务系统查询租户/成员状态 ──

    @SuppressWarnings("unchecked")
    private Map<String, Object> statusOf(String token) throws Exception {
        MvcResult res = mockMvc.perform(get("/api/v1/auth/session-status")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), Map.class);
    }

    /** G4：session-status 权威反映租户/成员状态（配合 G1/G2 停用后 valid=false）。 */
    @Test
    void sessionStatusReflectsTenantAndMemberState() throws Exception {
        // ① 正常：tenant-org-a 成员 ACTIVE + valid
        Map<String, Object> s1 = statusOf(login("admin", "admin123"));
        assertThat(s1.get("tenant_status")).isEqualTo("ACTIVE");
        assertThat(s1.get("membership_status")).isEqualTo("ACTIVE");
        assertThat(s1.get("valid")).isEqualTo(true);

        // ② 成员停用 → valid=false + membership_status=SUSPENDED；恢复 → valid=true
        String mid = createMember("tenant-org-a", "g4_user", List.of("r-1001"));
        String token = login("g4_user", "Passw0rd!");
        assertThat(statusOf(token).get("valid")).isEqualTo(true);
        mockMvc.perform(post("/api/v1/admin/members/" + mid + "/suspend")
                        .header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isOk());
        Map<String, Object> s3 = statusOf(token);
        assertThat(s3.get("membership_status")).isEqualTo("SUSPENDED");
        assertThat(s3.get("valid")).isEqualTo(false);
        mockMvc.perform(post("/api/v1/admin/members/" + mid + "/restore")
                        .header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isOk());
        assertThat(statusOf(token).get("valid")).isEqualTo(true);

        // ③ 租户停用 → valid=false + tenant_status=DISABLED
        String tenantId = createTenant("g4t");
        String mid2 = createMember(tenantId, "g4_tenant_user", List.of());
        String token2 = login("g4_tenant_user", "Passw0rd!");
        setTenantStatus(tenantId, "DISABLED");
        Map<String, Object> s4 = statusOf(token2);
        assertThat(s4.get("tenant_status")).isEqualTo("DISABLED");
        assertThat(s4.get("valid")).isEqualTo(false);
    }

    /** G4：tenant-status 限调用者自己的成员关系（防枚举）；无 token 401。 */
    @Test
    void tenantStatusScopedToOwnMemberships() throws Exception {
        String token = adminToken();
        mockMvc.perform(get("/api/v1/auth/tenant-status").header("Authorization", "Bearer " + token)
                        .param("tenant_id", "tenant-org-a"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenant_status").value("ACTIVE"));
        // 未加入的租户 → 403（防枚举）
        mockMvc.perform(get("/api/v1/auth/tenant-status").header("Authorization", "Bearer " + token)
                        .param("tenant_id", "unknown-tenant-xyz"))
                .andExpect(status().isForbidden());
        // 无 token → 401
        mockMvc.perform(get("/api/v1/auth/session-status"))
                .andExpect(status().isUnauthorized());
    }

    /** G4 服务间 status-check：后台任务执行前校验（X-IAM-Service-Token，无用户 token）。 */
    @Test
    void statusCheckServiceToService() throws Exception {
        // 无/错令牌 → 401
        mockMvc.perform(post("/api/v1/auth/status-check")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"membership_id\":\"ms-1001\"}"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/v1/auth/status-check")
                        .header("X-IAM-Service-Token", "wrong")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"membership_id\":\"ms-1001\"}"))
                .andExpect(status().isUnauthorized());

        // 有效：tenant-org-a + ms-1001 → valid=true
        mockMvc.perform(post("/api/v1/auth/status-check")
                        .header("X-IAM-Service-Token", "it-service-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"membership_id\":\"ms-1001\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.valid").value(true));

        // 成员停用 → valid=false
        String mid = createMember("tenant-org-a", "g4s_user", List.of("r-1001"));
        mockMvc.perform(post("/api/v1/admin/members/" + mid + "/suspend")
                        .header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/auth/status-check")
                        .header("X-IAM-Service-Token", "it-service-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"membership_id\":\"" + mid + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.valid").value(false))
                .andExpect(jsonPath("$.data.membership_status").value("SUSPENDED"));

        // 租户停用 → valid=false
        String tenantId = createTenant("g4st");
        String mid2 = createMember(tenantId, "g4st_user", List.of());
        setTenantStatus(tenantId, "DISABLED");
        mockMvc.perform(post("/api/v1/auth/status-check")
                        .header("X-IAM-Service-Token", "it-service-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"" + tenantId + "\",\"membership_id\":\"" + mid2 + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.valid").value(false))
                .andExpect(jsonPath("$.data.tenant_status").value("DISABLED"));
    }
}

package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.QuotaDimensionMapper;
import com.unify.iam.authorization.infra.persistence.po.QuotaDimensionPO;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** G1 配额维度注册表仓储。 */
@Repository
public class QuotaDimensionRepository {

    private final QuotaDimensionMapper mapper;

    public QuotaDimensionRepository(QuotaDimensionMapper mapper) {
        this.mapper = mapper;
    }

    /** 归属应用集合内的全部维度（全局 iam + 租户已启用应用）。 */
    public List<QuotaDimensionPO> listByAppCodes(Collection<String> appCodes) {
        if (appCodes == null || appCodes.isEmpty()) {
            return List.of();
        }
        return mapper.selectList(new LambdaQueryWrapper<QuotaDimensionPO>()
                .in(QuotaDimensionPO::getAppCode, appCodes)
                .orderByAsc(QuotaDimensionPO::getSortOrder)
                .orderByAsc(QuotaDimensionPO::getDimensionId));
    }

    /** 按归属应用 + 维度键查（强制点用）。 */
    public Optional<QuotaDimensionPO> findByAppCodeAndKey(String appCode, String dimensionKey) {
        return Optional.ofNullable(mapper.selectOne(new LambdaQueryWrapper<QuotaDimensionPO>()
                .eq(QuotaDimensionPO::getAppCode, appCode)
                .eq(QuotaDimensionPO::getDimensionKey, dimensionKey)
                .last("LIMIT 1")));
    }

    /** 按业务键查（注意：主键是 BaseEntity.id，不能用 selectById）。 */
    public Optional<QuotaDimensionPO> findById(String dimensionId) {
        return Optional.ofNullable(mapper.selectOne(new LambdaQueryWrapper<QuotaDimensionPO>()
                .eq(QuotaDimensionPO::getDimensionId, dimensionId.trim())
                .last("LIMIT 1")));
    }
}

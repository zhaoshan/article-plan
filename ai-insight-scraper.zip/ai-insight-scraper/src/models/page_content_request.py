"""单页面内容爬取请求模型"""

from pydantic import BaseModel, Field, field_validator


class PageContentRequest(BaseModel):
    """单页面内容爬取请求参数"""

    model_config = {"extra": "forbid", "str_strip_whitespace": True}

    url: str = Field(
        ...,
        description="目标页面 URL（必须在 crawl_link_tree 表中已存在）",
        min_length=1,
        max_length=2048,
    )
    formats: list[str] = Field(
        default_factory=lambda: ["markdown", "html"],
        description="网页类型需要返回的内容格式：markdown / html / raw_html",
    )
    only_main_content: bool = Field(
        default=True,
        description="是否仅返回主要内容（保留参数，当前未启用过滤）",
    )

    @field_validator("url")
    @classmethod
    def validate_url_scheme(cls, v: str) -> str:
        """校验 URL 必须以 http:// 或 https:// 开头"""
        if not v.startswith(("http://", "https://")):
            raise ValueError("url 必须以 http:// 或 https:// 开头")
        return v

    @field_validator("formats")
    @classmethod
    def validate_formats(cls, v: list[str]) -> list[str]:
        """校验 formats 取值"""
        allowed = {"markdown", "html", "raw_html"}
        for f in v:
            if f not in allowed:
                raise ValueError(f"formats 仅支持 {allowed}，得到: {f}")
        return v

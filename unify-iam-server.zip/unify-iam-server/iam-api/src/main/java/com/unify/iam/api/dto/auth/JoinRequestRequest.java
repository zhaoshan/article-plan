package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 加入租户申请请求：{@code POST /api/v1/memberships/join-request}。 */
public record JoinRequestRequest(
        @NotBlank(message = "tenant_id 不能为空") @JsonProperty("tenant_id") String tenantId) {
}

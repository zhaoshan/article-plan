package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.dto.auth.RefreshRequest;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.app.service.RefreshTokenService;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * refresh token 端点（docs/04 §3.3）：
 * {@code POST /api/v1/auth/refresh}（轮换：旧作废+新生效+重签 access）、{@code /logout}（撤销）。
 *
 * <p>位于公开的 /api/v1/auth/**（认证本身由 refresh token 凭证承载，非 Bearer）。
 */
@RestController
@RequestMapping("/api/v1/auth")
public class RefreshController {

    private final RefreshTokenService refreshTokenService;
    private final TokenService tokenService;
    private final UserRepository userRepository;
    private final MembershipResolver membershipResolver;

    public RefreshController(RefreshTokenService refreshTokenService,
                             TokenService tokenService,
                             UserRepository userRepository,
                             MembershipResolver membershipResolver) {
        this.refreshTokenService = refreshTokenService;
        this.tokenService = tokenService;
        this.userRepository = userRepository;
        this.membershipResolver = membershipResolver;
    }

    /** 刷新：用 refresh token 换新 access + 新 refresh（轮换）。 */
    @PostMapping("/refresh")
    public LoginResponse refresh(@Valid @RequestBody RefreshRequest request) {
        RefreshTokenService.Rotated rotated = refreshTokenService.rotate(request.refreshToken());
        UserPO user = userRepository.findByUserId(rotated.userId())
                .orElseThrow(() -> AuthException.unauthorized("refresh token 无效或已过期"));
        // 租户必须 ACTIVE：与 rotate 同源校验，漏查会让停用租户绕过续签签出新 token（防停用绕过）
        MembershipPO membership = membershipResolver.findActiveById(rotated.membershipId())
                .filter(m -> "ACTIVE".equals(m.getMembershipStatus()))
                .orElseThrow(() -> AuthException.unauthorized("refresh token 无效或已过期"));
        // 重签 access（同一 membership，重新解析 RBAC）
        LoginResponse access = tokenService.issueFor(
                new UserPrincipal(user.getUserId(), user.getUsername(), null), membership);
        return new LoginResponse(access.accessToken(), access.tokenType(), access.expiresIn(), access.user(),
                rotated.newRefreshToken(), refreshTokenService.refreshTtlSeconds(),
                (user.getMustChangePassword() != null && user.getMustChangePassword() == 1));
    }

    /** 登出：撤销该 refresh token（后续不可用）。 */
    @PostMapping("/logout")
    public void logout(@Valid @RequestBody RefreshRequest request) {
        refreshTokenService.revoke(request.refreshToken());
    }
}
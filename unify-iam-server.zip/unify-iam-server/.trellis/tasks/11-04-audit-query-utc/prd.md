# Audit query UTC timestamp contract

## Goal
Allow the audit page to submit browser-local calendar bounds as UTC instants.

## Requirements
- Only GET /api/v1/admin/audit time filtering changes; retain start_time/end_time names.
- ISO-8601 UTC Z timestamps are the primary contract; explicit offsets represent equivalent instants.
- Each bound is optional (blank means absent). Start is inclusive; end is exclusive. If both exist, end must be strictly later.
- Preserve existing YYYY-MM-DD compatibility: Asia/Shanghai start-of-day, inclusive final date advanced by one calendar day. Preserve existing unzoned ISO local timestamps as legacy Shanghai wall time.
- Invalid values return HTTP 400 with the existing TIME_FORMAT_INVALID code; invalid windows use END_TIME_AFTER_START.
- Preserve permissions, tenant filters, keyword, pagination, stable sorting and response format.

## Acceptance
Verify parsing, UTC/offset equivalence, open bounds, blanks, malformed dates/timestamps, reversed/equal instants, exact start/end database boundaries and legacy dates. Reuse existing permission/pagination regression coverage; do not add broad duplicate tests. Update API documentation and executable project specs. Do not alter database timezone configuration or migrate historical rows.

## Constraints
Work only in the current main workspace on feature/lee-1102. No commits, pushes, merges, branch/worktree changes. Retain task records here. Planning review gate remains required.

"""Chrome 浏览器工具函数（从 scripts/deep_crawl_nested_links.py 提取）"""

import platform
import os

# 通用 User-Agent，模拟 Windows Chrome 122
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)


def find_chrome_path() -> str:
    """
    查找本地 Chrome 浏览器可执行文件路径。

    Returns:
        str: Chrome 可执行文件路径，未找到返回空字符串
    """
    system = platform.system()

    if system == "Windows":
        paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
    elif system == "Darwin":
        paths = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        ]
    else:  # Linux
        paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
        ]

    for path in paths:
        if os.path.exists(path):
            return path
    return ""

package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/** 设置角色权限点（覆盖式：先清后插）。 */
public record SetPermissionsRequest(@JsonProperty("permission_ids") List<String> permissionIds) {

    public SetPermissionsRequest {
        permissionIds = permissionIds == null ? List.of() : permissionIds;
    }
}

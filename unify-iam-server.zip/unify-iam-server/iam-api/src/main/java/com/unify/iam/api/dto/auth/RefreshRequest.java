package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** refresh 令牌请求：{@code POST /api/v1/auth/refresh} / {@code /logout}。 */
public record RefreshRequest(
        @NotBlank(message = "refresh_token 不能为空") @JsonProperty("refresh_token") String refreshToken) {
}

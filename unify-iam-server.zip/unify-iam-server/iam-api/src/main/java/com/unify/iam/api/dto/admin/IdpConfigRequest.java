package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Map;

/**
 * 管理面 IdP 配置请求（docs/07 §3.1，建/改共用；建时必填 tenant_id，改时按路径 id 忽略 tenant_id）。
 * {@code client_secret} 明文入参，落库存 client_secret_cipher——当前 DEV 明文直存（加密为待办，docs/07 §7）。
 */
public record IdpConfigRequest(
        @JsonProperty("tenant_id") String tenantId,
        String protocol,
        @JsonProperty("provider_key") String providerKey,
        @JsonProperty("display_name") String displayName,
        @JsonProperty("config_status") String configStatus,
        String issuer,
        @JsonProperty("discovery_uri") String discoveryUri,
        @JsonProperty("jwk_set_uri") String jwkSetUri,
        @JsonProperty("authorization_endpoint") String authorizationEndpoint,
        @JsonProperty("token_endpoint") String tokenEndpoint,
        @JsonProperty("userinfo_endpoint") String userinfoEndpoint,
        @JsonProperty("client_id") String clientId,
        @JsonProperty("client_secret") String clientSecret,
        @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using = StringListDeserializer.class)
        List<String> scopes,
        @JsonProperty("claim_mapping") Map<String, String> claimMapping,
        @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using = StringListDeserializer.class)
        @JsonProperty("allowed_domains") List<String> allowedDomains,
        @JsonProperty("pkce_required") Boolean pkceRequired,
        @JsonProperty("email_verified_required") Boolean emailVerifiedRequired,
        @JsonProperty("jit_provisioning_enabled") Boolean jitProvisioningEnabled,
        @JsonProperty("default_join_policy") String defaultJoinPolicy) {
}

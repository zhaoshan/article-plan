package com.unify.iam.app.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.app.infra.persistence.po.InvitationPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_invitation Mapper。 */
@Mapper
public interface InvitationMapper extends BaseMapper<InvitationPO> {
}

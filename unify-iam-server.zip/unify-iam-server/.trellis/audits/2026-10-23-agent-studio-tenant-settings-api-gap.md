# Agent / Agent Studio / 租户设置接口盘点

> ## 历史勘误（2026-10-23）
>
> **状态：历史保留，不再是当前 IAM Web 的活跃接口缺口清单。** 已确认顶层
> `/admin/agents`（Agent 管理）和 `/admin/agent-studio`（Agent Studio）属于
> `ai-insight-web` / Imorph，且已从当前 IAM Web 移除。因此本文“一、Agent 与 Agent
> Studio”中关于 IAM 没有 Agent 实体、草稿、运行时等接口的源码事实仍然成立，但其中的
> 最小契约和“当前缺失”**不得**再进入 IAM Web 或本仓库的开发 backlog。
>
> `/admin/tenant-settings/:tenantId/agents` 是不同的、仍在 IAM Web 范围内的租户设置
> 子视图；它只可由 IAM 的租户已启用应用、角色、成员和权限治理数据支持，不能被理解为
> 顶层 Agent 业务页面。当前可执行的范围、准确字段与真实 IAM 缺口以
> [2026-10-23-iam-real-page-api-matrix-corrigendum.md](2026-10-23-iam-real-page-api-matrix-corrigendum.md)
> 为准。

**调研日期：** 2026-10-23  
**范围：** `platform-iam-service` 当前主工作区；仅只读调研，未修改业务源码、配置、分支或 worktree。  
**基线：** `main`（`da062d0`）。开始调研前工作区已存在未跟踪的 `.trellis/`；本报告仅新增于该目录。

## 流程与证据边界

- 项目根及当前项目内递归搜索均未找到 `AGENTS.md`，`.trellis/workflow.md` 也不存在。因此无法读取或执行其中未落盘的 Trellis 门禁；已完整读取项目实际存在的 `CLAUDE.md`，并遵守其中“不自动提交”的规则。
- OpenAPI 由 springdoc 自动生成：依赖在 `iam-app/pom.xml:72-75`，路径为 `/v3/api-docs`、Swagger UI 为 `/swagger-ui.html`（`iam-app/src/main/resources/application.yml:70-75`），而 `OpenApiConfig` 只提供标题、描述和版本（`iam-app/src/main/java/com/unify/iam/app/config/OpenApiConfig.java:8-18`）。生产源码未发现 `@Operation` / `@Tag` / `@Schema` 注解，且多数 controller 返回 `Map`；因此 OpenAPI 可用来发现路由，但不能替代下列 controller、DTO 和 service 的字段契约。
- 静态枚举了 `iam-app` 全部 controller 映射，并对所有业务源码（不含 `target`）搜索 `agent`、`agentId`、`/admin/agents` 和 Agent Studio 变体。没有 Agent 实体 controller、DTO、service、repository 或测试；`agent` 在主源码中的实际业务含义主要是权限码。
- 运行验证：允许 Docker socket 后执行
  `mvn -pl iam-app -am test -Dtest='P3IdpConfigIntegrationTest,P3TenantScopeIntegrationTest,P3AdminCrudIntegrationTest,AppAccessIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full`。
  15 项通过：CRUD 6、租户作用域 2、IdP 4、app-access 3。第一次受沙箱 Docker socket 限制未能初始化 Testcontainers；授权后重跑通过。测试报告在 `iam-app/target/surefire-reports/`（忽略文件，不是交付物）。
- 本机 `127.0.0.1:8090` 在本次检查时未监听，所以没有把运行中的 `/v3/api-docs` 当作当前源码的证据；本报告以已检出的源码和上述集成测试为准。

## 历史总结（保留原调研事实；不构成当前 IAM Web 开发范围）

`platform-iam-service` 是 IAM 控制面，不是 Agent 资源或 Agent 运行时。它已能直接提供 Agent 页面所需的登录身份、当前租户、业务权限和应用可访问性；但没有 Agent 列表、定义、草稿、版本、发布、测试、执行或运行记录接口。`/admin/agents` 与 `/admin/agent-studio` 不能直接接到本项目的业务端点。

`/admin/tenant-settings/*` 不是后端已定义的路由前缀。它可以由现有的租户、已启用应用、成员/角色、IdP/组映射、域名和审计资源拼装，但各子页面的完整性不同，尤其是应用启停、域名管理、IdP 连通性测试、统一分页筛选和扩展设置字段仍缺失。

所有下文 `/api/v1/**` 的成功结果应从 `data` 解包，形态为 `{success,code,message,data}`；错误保留真实 HTTP 状态并使用同一信封。依据为 `ApiEnvelopeAdvice.java:12-36`、`EnvelopePaths.java:4-27` 与 `GlobalExceptionHandler.java:19-78`。

## 一、Agent 与 Agent Studio（历史范围调查；不构成当前 IAM Web backlog）

### 1. 可直接调用：身份、租户和权限上下文

| 页面能力 | HTTP 接口与入参 | `data` 关键字段 | 可直接满足的边界 | 证据 |
| --- | --- | --- | --- | --- |
| 初始化当前操作者与页面显隐 | `GET /api/v1/auth/me`，Bearer | `userId`, `tenantId`, `membershipId`, `roles[]`, `permissions[]`, `attrs` | 以 `agent:read/build/publish/delete` 和 `settings:read` 等权限做前端显示与后端业务服务的授权输入 | `AuthController.java:122-131`；`AuthorizationContext.java:19-25`；`PermissionCodes.java:9-31` |
| 多租户选择 | `GET /api/v1/auth/memberships`，Bearer | `memberships[]:{membership_id,tenant_id,tenant_name,membership_status,is_default}` | 为 Agent 页面选择工作租户 | `SwitchTenantController.java:74-91` |
| 切换工作租户 | `POST /api/v1/auth/switch-tenant`，Bearer，`{membership_id}` | 新 `access_token` / refresh 登录响应 | 用目标成员关系重新签发单租户 token；不是仅修改前端 `tenant_id` | `SwitchTenantController.java:55-72` |
| 判断业务应用入口是否可用 | `GET /api/v1/auth/app-access?app_code=`，Bearer | `memberships[]:{membership_id,tenant_id,tenant_name,tenant_code}`, `is_platform_admin` | 判断用户是否拥有启用该业务应用的活动成员关系 | `AppAccessController.java:52-88`；`AppAccessIntegrationTest.java:33-70` |
| 当前会话/租户是否仍有效 | `GET /api/v1/auth/session-status`，Bearer | `tenant_id`, `tenant_status`, `membership_id`, `membership_status`, `valid` | 打开或恢复 Agent 工作台前的 IAM 状态检查 | `SessionStatusController.java:60-80` |

上述接口只解决 IAM 上下文，不返回任何 Agent 或 Studio 配置。特别是 token 保持单租户语义，跨租户必须调用 `switch-tenant`，不能拿 URL 参数代替。

### 2. 现有但合同/语义不匹配

| 看似可复用的接口 | 实际合同 | 为什么不能充当 Agent API |
| --- | --- | --- |
| `GET /api/v1/admin/applications` | 活跃业务应用目录：`applications[]:{app_code,app_name,description,roles[]}`；需 `iam:tenant:read` | `Application` 是应用接入模板，不是单个 Agent；没有 `agent_id`、状态、草稿、版本、模型或运行数据。`AdminApplicationController.java:29-52`。 |
| `GET /api/v1/admin/tenants/{tenantId}/applications` | 某租户已启用应用的只读 `applications[]:{app_code,app_name}`；需 `iam:role:read` 且做租户作用域检查 | 可显示该租户可用的产品，不可列出/启停其中的 Agent。`AdminTenantController.java:56-79`。 |
| `GET /api/v1/admin/permissions` 及角色授权接口 | 权限目录与 RBAC 绑定，权限 ID 是角色授权用的 opaque ID | `agent:*` 是业务权限码，而非 Agent 记录；可治理“谁可操作”，不能返回或修改“操作什么”。`AdminPermissionController.java:28-45`、`AdminRoleService.java:84-98`。 |
| `GET /api/v1/admin/audit` | IAM 管理操作审计，可按租户/事件/操作人分页 | 不包含 Agent 运行、测试输入输出、模型调用、会话 trace 或发布版本。`AdminAuditController.java:24-42`。 |

### 3. 历史缺失与假设最小可行契约（非当前 IAM 开发项）

这些是**本 IAM 后端中缺失**，不是断言全系统没有对应服务。按当前仓库约束，Agent 领域应由 Agent 业务服务或其网关路由拥有；IAM 继续提供 Bearer/JWKS、`AuthorizationContext` 和 RBAC，不应在此项目复制 Agent 的领域状态。

| 页面能力 | 最小可行契约 | 可否由现有 IAM 接口扩展解决 |
| --- | --- | --- |
| `/admin/agents` 列表、筛选、详情 | `GET /api/v1/admin/agents?page=&size=&keyword=&status=` -> `{items:[{agent_id,name,description,status,current_version,updated_at,created_by}],total,page,size}`；`GET /api/v1/admin/agents/{agentId}` -> 完整只读投影 | **否（领域缺失）**。IAM 没有 Agent 模型、存储或 controller；应由 Agent 业务服务实现，并以 token 的 `tenantId` 和 `permissions` 作强制鉴权。 |
| 创建、编辑、删除、启停、发布/回滚 | `POST /api/v1/admin/agents`、`PATCH /api/v1/admin/agents/{id}`、`POST /api/v1/admin/agents/{id}/publish`、`POST /api/v1/admin/agents/{id}/suspend`、`DELETE /api/v1/admin/agents/{id}`，均返回版本/状态和更新时间 | **否**。可复用 `agent:build/publish/delete` 作为授权语义，但 CRUD 不能落在 IAM。 |
| Agent Studio 草稿、版本、提示词、工具、知识引用、模型配置保存 | `GET/PUT /api/v1/admin/agents/{id}/draft`，请求/响应至少含 `{version,definition,prompt,model_config,tools,knowledge_refs,input_schema}`，`PUT` 用 `If-Match` 或 `version` 乐观锁 | **否**。没有对应 DTO/service/persistence；敏感 provider secret 不应回显，需由业务服务单独保管。 |
| 测试/执行及结果 | `POST /api/v1/admin/agents/{id}/test-runs` -> `{run_id,status}`；`GET /api/v1/admin/test-runs/{runId}` -> `{status,output,error,trace_id,started_at,finished_at}`。长任务可另提供受鉴权事件流 | **否**。IAM 的 `session-status` 只验证成员/租户状态，不执行 Agent。 |
| 运行历史、trace、指标 | 带时间、状态、用户/会话等过滤的 Agent 运行查询；返回去敏后的 trace/统计 | **否**。`trace:read` 只是权限码，IAM 没有 trace 资源端点。 |

## 二、`/admin/tenant-settings/*` 能力矩阵

### 1. 现有且可直接调用

| 子页面能力 | 接口、入参、返回 | 权限/作用域 | 备注与证据 |
| --- | --- | --- | --- |
| 租户列表 | `GET /api/v1/admin/tenants?limit=20` -> `tenants[]:{tenant_id,tenant_code,tenant_name,tenant_type,tenant_status,primary_domain}`, `count` | `iam:tenant:read` | 可直接展示基础列表；`limit` 1..1000，无 `page/total/search/sort`。`AdminTenantController.java:81-93`，`TenantRepository.java:86-95`。 |
| 租户详情 | `GET /api/v1/admin/tenants/{tenantId}` -> 同上 | `iam:tenant:read` | 可直接作为基础设置读取。 |
| 创建租户 | `POST /api/v1/admin/tenants`，`{tenant_code*,tenant_name*,tenant_type?,primary_domain?,owner_user_id?,app_codes*[]}` -> `{tenant_id}` | `iam:tenant:write` | `app_codes` 至少一个，创建时按模板灌入角色并登记租户应用。`CreateTenantRequest.java:13-20`，`AdminTenantService.java:57-75`。 |
| 基础设置保存/启停 | `PUT /api/v1/admin/tenants/{tenantId}`，当前是裸对象；实际仅处理 `tenant_name`、`tenant_status`、`primary_domain` -> `{tenant_id}` | `iam:tenant:write`；目标租户作用域 | 适合这三项的保存和状态变更，非 ACTIVE 会 bump 租户成员 token 版本。`AdminTenantController.java:104-110`，`AdminTenantService.java:82-116`。 |
| 删除租户 | `DELETE /api/v1/admin/tenants/{tenantId}` -> `{tenant_id}` | 同上 | 逻辑删除并失效租户成员 token。`AdminTenantService.java:118-126`。 |
| 建租户时选择应用 | `GET /api/v1/admin/applications` -> 活跃应用与角色模板 | `iam:tenant:read` | 只读选择源；角色模板含 `is_owner`，不是应用 CRUD。`AdminApplicationController.java:29-52`。 |
| 已启用应用查看 | `GET /api/v1/admin/tenants/{tenantId}/applications` -> `applications[]:{app_code,app_name}`, `count` | `iam:role:read` + `TenantScopeGuard` | 可直接展示。`AdminTenantController.java:60-79`。 |
| 成员/用户选择、成员生命周期 | `GET /api/v1/admin/members?tenant_id=`；`POST /api/v1/admin/members` `{tenant_id,user_id,role_ids?}`；`GET/PUT /api/v1/admin/members/{membershipId}/roles`；`POST .../suspend` / `restore`；`DELETE ...` | `iam:member:read/write` + 租户作用域 | 列表已有用户名、状态、角色；创建/授角色均为覆盖/替换语义。`AdminMemberController.java:58-160`，DTO 为 `CreateMemberRequest.java:8-12`、`SetRolesRequest.java:6-12`。 |
| 角色及权限保存 | `GET /api/v1/admin/roles?scope_type=TENANT&scope_id={tenantId}`；`POST /api/v1/admin/roles`（创建体见下）；`GET/PUT /api/v1/admin/roles/{roleId}/permissions`；`GET /api/v1/admin/permissions`；`DELETE /api/v1/admin/roles/{roleId}` | `iam:role:read/write` + 作用域 | 前端必须显式传 `scope_type=TENANT` 与 `scope_id`；写权限是**替换整个 ID 集合**。`AdminRoleController.java:38-90`，`AdminRoleService.java:60-98`。 |
| 用户目录检索（添加成员/邀请选人） | `GET /api/v1/admin/user-directory?search=&limit=20` -> `{user_id,username,email}` | `iam:member:read` | 模糊匹配用户名/邮箱，最大 20。`AdminDirectoryController.java:31-46`、`UserRepository.java:70-82`。 |
| IdP 配置与组映射保存 | `GET /api/v1/admin/idp-configs?tenant_id=`；`POST /api/v1/admin/idp-configs`（体见下）；`PUT/DELETE /api/v1/admin/idp-configs/{configId}`；`GET/POST/PUT/DELETE /api/v1/admin/idp-configs/{configId}/group-mappings` | `iam:idp:read/write` | IdP list 返回脱敏完整配置，`has_secret` 不回传 secret；组映射约束目标角色属于该 IdP 租户。`AdminIdpController.java:40-113`，`IdpConfigRequest.java:11-33`，`AdminIdpService.java:142-224`。集成测试覆盖 CRUD、脱敏、跨租户角色拒绝与 403。 |
| 审计与筛选 | `GET /api/v1/admin/audit?tenant_id=&event_type=&actor_user_id=&page=1&size=20`；`GET /api/v1/admin/audit/events` | `iam:audit:read` | 真正的服务端分页，最大 200，返回 `total/page/size` 和富化审计记录。`AdminAuditController.java:24-42`，`AuditLogRepository.java:26-52`。 |

### 1.1 关键字段补充

- **角色：** 创建体为 `{scope_type,scope_id,role_code*,role_name*,role_description?}`，返回 `{role_id}`；列表元素为 `{role_id,role_code,role_name,scope_type,scope_id,role_status}`。`PUT /api/v1/admin/roles/{roleId}/permissions` 的体为 `{permission_ids:[]}`，返回 `{role_id}`；读取返回 `{permission_ids:[]}`。DTO/投影证据：`CreateRoleRequest.java:7-13`、`SetPermissionsRequest.java:6-12`、`AdminRoleController.java:47-89`。
- **成员：** 成员列表元素为 `{membership_id,tenant_id,user_id,username,membership_status,is_default,roles:[{role_id,role_code,role_name}]}`；`GET /members/{membershipId}/roles` 返回同一角色简表。`POST`/`PUT` 均只返回 `{membership_id}`。`AdminMemberController.java:96-160`。
- **IdP：** create/update 请求体为 `{tenant_id,protocol,provider_key,display_name,config_status,issuer,discovery_uri,jwk_set_uri,authorization_endpoint,token_endpoint,userinfo_endpoint,client_id,client_secret(write-only),scopes[],claim_mapping{},allowed_domains[],pkce_required,email_verified_required,jit_provisioning_enabled,default_join_policy}`。list 元素回传除 secret 外的上述配置，并给出 `idp_config_id`、`has_secret`；create/update controller 仅回 `{idp_config_id}`。组映射请求是 `{match_mode,match_value,target_role_id,priority,mapping_status}`，列表元素另含 `mapping_id,idp_config_id`；写操作仅回 `{mapping_id}`。`IdpConfigRequest.java:11-33`、`GroupMappingRequest.java:6-12`、`AdminIdpService.java:188-224`。
- **审计：** 每个 `audits[]` 元素至少含 `audit_log_id,tenant_id,tenant_name,actor_user_id,actor_username,actor_membership_id,event_type,event_name,target_type,target_id,target_display,result_status,request_id,ip_address,user_agent,before_json,after_json,metadata_json,trace_id,create_time`。`AdminAuditService.java:95-130`。

### 2. 现有但合同/语义不匹配

| 页面能力 | 可见现有接口 | 不匹配点 | 最小补齐方向 |
| --- | --- | --- | --- |
| 完整租户设置表单 | `GET/PUT /api/v1/admin/tenants/{id}` | update 没有 DTO，未知字段不会成为设置；详情不含 owner、配额、时区、品牌、通知、SSO 策略等。 | 可在既有 `PUT` 引入显式 `UpdateTenantSettingsRequest`（保持三字段兼容），或增加 `GET/PUT /api/v1/admin/tenants/{id}/settings`；返回完整、已定义的设置投影与版本号。 |
| 已启用应用的启停/保存 | 应用目录及租户应用 `GET` | 当前写路径只在创建/注册期间通过 `TenantAppProvisionService.recordTenantApps` 调用；没有管理端 PUT/PATCH/DELETE。 | 可扩展现有 `/api/v1/admin/tenants/{id}/applications`：`PUT {app_codes:[...]}` 或动作式 enable/disable；必须定义新增应用时的角色模板灌入、移除时存量角色/成员/token/运行中资源如何处理。 |
| 域名设置页 | `POST /api/v1/admin/tenants/{id}/domains` `{domain,challengeType?}` -> `{tenant_domain_id,challenge_type,challenge_token}`；`POST /api/v1/admin/domains/{id}/verify` -> `{status,domain}` | 没有域名列表、详情、删除、设主域名、挑战状态查询；`verify` 当前直接标记 VERIFIED，service 注释明确生产应另做 DNS/HTTP 校验。 | 可在同资源扩展 `GET/DELETE /api/v1/admin/tenants/{id}/domains`、`GET /api/v1/admin/domains/{id}` 与真实 `POST /api/v1/admin/domains/{id}/verification-check`；返回 `verification_status`, `is_primary`, `verified_at`, challenge 过期信息。 |
| IdP 编辑页的单条加载和“测试连接” | IdP list / create / update / delete | 没有 `GET /api/v1/admin/idp-configs/{id}`；没有 discovery、client credentials 或 issuer/JWKS 连通性测试。另：当前 service 注释表明 `client_secret` 是 DEV 明文直存，生产安全条件未满足。 | 可扩展 `GET /api/v1/admin/idp-configs/{id}` 与 `POST /api/v1/admin/idp-configs/{id}/validate`，验证结果应去敏；生产前必须完成密钥加密。 |
| 角色编辑、状态和安全信息 | 角色 list、permission IDs、delete | 没有 `GET /api/v1/admin/roles/{id}` 或角色更新/启停；列表不含 description、`is_builtin`、已分配人数或 owner 标志。不要以 role code 猜 owner。 | 可扩展角色详情/更新投影，并让后端给出可否删除及占用数；这是既有 role resource 的合理扩展。 |
| 成员、角色、租户、IdP 的大数据表格 | 各列表 GET | 除审计外没有服务端 `page/total`；tenant 和 user 只有 limit，members/roles/IdP 无分页。目录搜索最大 20。 | 对既有 list 增加可选 `page,size,keyword,sort`，返回统一 `{items,total,page,size}`；为兼容可保留旧数组字段直到前端迁完。 |
| 审计时间范围 | `GET /api/v1/admin/audit` | 支持 tenant/event/actor，不支持开始/结束时间、全文或目标筛选。 | 可给现有 audit list 增加 `from/to/target_type/target_id`；不需要新资源。 |

### 3. 当前缺失（不是“可直接调用”）

- 没有应用（`iam_application`）或应用角色模板的管理 CRUD、状态切换或租户后续启停接口。当前文档也把应用模板管理列为未实现范围；不能把应用目录当成可编辑的租户设置。
- 没有租户用量/配额、订阅计划、计费、通知、品牌化、数据保留、外部 webhook 或审计导出契约。是否需要这些字段尚未从前端页面得到确认。
- 没有统一“目标租户授权投影”接口。前端可用 `/api/v1/auth/me` 做当前 token 的显示，用 `/api/v1/auth/switch-tenant` 切换后由受保护 API 的 403 作权威判定；不能以任意 `tenant_id` URL 参数推断有管理资格。

## 三、分页、筛选、权限与错误处理

| 维度 | 已有行为 | 前端接入结论 |
| --- | --- | --- |
| 真实服务端分页 | 仅审计支持 `page/size/total`，`size` 钳制为 1..200 | 审计可直接使用服务端分页。 |
| 有限列表 | tenants `limit` 1..1000；users `limit` 1..100；user-directory `search` + `limit` 1..20；members/roles/IdP 没有分页 | 不能将这些 `limit` 伪装成完整分页或服务端排序；超量数据是明确缺口。 |
| 管理面认证 | `/api/v1/admin/**` 拦截器要求 Bearer；缺/坏 token 401，缺 `iam:*` 权限 403 | 统一处理 401 重新登录、403 无权限；不要只依赖导航隐藏。`ManagementAuthorizationInterceptor.java:13-64`。 |
| 租户作用域 | 平台角色可跨租户；租户管理员只能操作 token 当前租户 | 使用 `TenantScopeGuard` 作为后端权威边界，`P3TenantScopeIntegrationTest` 已覆盖本租户成功和跨租户/平台 403。`TenantScopeGuard.java:9-44`。 |
| 输入/业务错误 | 校验/格式错误 400、资源不存在 404、认证/授权 401/403、未捕获异常 500，均为 API 信封 | 在字段或操作附近展示 `message`；不能以本地乐观状态假定成功。`GlobalExceptionHandler.java:34-78`。 |
| IdP 权限 | `iam:idp:*` 在 seed 中为非租户可授，仅 PlatformAdmin 绑定 | 当前租户管理员应隐藏 IdP 设置入口；集成测试验证其 403。`R__platform_bootstrap.sql:12-50`，`P3IdpConfigIntegrationTest.java:170-190`。 |

## 四、待确认事项

1. 前端候选路由没有对应前端源码可供本任务读取，因此本报告按“通常页面能力 + 已知路由名称”分类，不能确认实际列、表单字段、Agent 归属服务或 UX 优先级。
2. `agent:*`、`session:*`、`trace:read` 是 IAM 签发到 token 的权限码，不等于本项目承载这些业务 API。需要前端协调方确认 Agent 的实际业务服务、网关前缀和领域数据归属后，再将“缺失于 IAM”的契约分配给正确服务。
3. `/admin/tenant-settings/*` 是前端组织方式，后端没有同名资源组。应先把每个子路由映射到上表具体资源，再决定是否需要新增统一 settings 投影。
4. `GET /api/v1/admin/roles` 缺省参数在当前实现会落成 `scope_type=TENANT`、`scope_id=PLATFORM`；前端不要依赖缺省值，必须显式传 scope。
5. 运行时 OpenAPI 未做活服务比对，因为本机 8090 当时未监听；静态 springdoc 配置和通过的 controller 集成测试仍支持本次源码结论。

## 历史结论（已由替代矩阵取代）

前端可以立即接入 IAM 的上下文、RBAC、租户基础设置、成员/角色、IdP、审计和有限的域名登记能力。Agent 和 Agent Studio 页面只能接入 IAM 的授权上下文，不能接入业务数据；其最小 API 应在 Agent 业务服务中补齐。租户设置若包含应用启停、完整域名管理、IdP 验证或大规模列表，应按第二节的最小扩展契约排入后端工作，而不是用现有目录/列表接口伪造完成。

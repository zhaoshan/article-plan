package com.unify.iam.identity.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_tenant_idp_config 租户 IdP/SSO 配置表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_tenant_idp_config")
public class IdpConfigPO extends BaseEntity {

    /** 配置业务唯一标识 */
    private String tenantIdpConfigId;
    /** 所属租户 ID；平台级 consumer 用 PLATFORM */
    private String tenantId;
    /** 协议：OIDC/SAML */
    private String protocol;
    /** 提供方标识：google/microsoft/okta/keycloak/auth0/custom */
    private String providerKey;
    private String displayName;
    /** 配置状态：DRAFT/ACTIVE/DISABLED */
    private String configStatus;
    private String issuer;
    private String discoveryUri;
    private String jwkSetUri;
    private String authorizationEndpoint;
    private String tokenEndpoint;
    private String userinfoEndpoint;
    private String clientId;
    private String clientSecretCipher;
    /** scopes JSON（字符串存，应用层反序列化） */
    private String scopesJson;
    /** claim 映射 JSON */
    private String claimMappingJson;
    /** allowed_domains JSON */
    private String allowedDomainsJson;
    private Integer pkceRequired;
    private Integer emailVerifiedRequired;
    private Integer jitProvisioningEnabled;
    /** 首登默认加入策略：REQUEST/AUTO_JOIN/INVITE_ONLY */
    private String defaultJoinPolicy;
    private String metadataXml;
}
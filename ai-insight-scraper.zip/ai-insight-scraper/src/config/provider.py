"""配置提供者抽象"""

from abc import ABC, abstractmethod
from pathlib import Path
import json


class ConfigProvider(ABC):
    """配置提供者抽象基类"""

    @abstractmethod
    def load_json(self, filename: str) -> dict:
        """加载 JSON 配置文件，返回字典"""
        ...


class FileConfigProvider(ConfigProvider):
    """基于本地文件的配置提供者"""

    def __init__(self, config_dir: Path):
        """
        Args:
            config_dir: 配置文件目录路径
        """
        self._config_dir = Path(config_dir)
        if not self._config_dir.is_dir():
            raise FileNotFoundError(f"配置目录不存在: {self._config_dir}")

    def load_json(self, filename: str) -> dict:
        """
        加载指定 JSON 配置文件。

        Args:
            filename: JSON 文件名（如 'traversal_rule_config.json'）

        Returns:
            dict: 配置字典，文件不存在时返回空字典
        """
        file_path = self._config_dir / filename
        if not file_path.exists():
            return {}
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)

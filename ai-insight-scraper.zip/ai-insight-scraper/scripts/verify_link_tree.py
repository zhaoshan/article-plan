"""迁移后数据一致性验证脚本

对比 crawl_link_tree 表与 Excel / tree_structure 三方数据，输出一致性报告。

用法:
    python scripts/verify_link_tree.py [--site tokyostarbank.co.jp]
                                        [--excel config/all_links_tag_result.xlsx]
                                        [--tree output/tree_structure_20260701_161852.json]
"""

import argparse
import asyncio
import json
import logging
import sys
from collections import Counter
from pathlib import Path

import openpyxl

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.database import LinkTreeRepository
from src.utils.url_utils import normalize_url

if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("verify_link_tree")

DEFAULT_SITE = "tokyostarbank.co.jp"
DEFAULT_EXCEL = "config/all_links_tag_result.xlsx"
DEFAULT_TREE = "output/tree_structure_20260701_161852.json"


def collect_tree_urls(tree_path: Path) -> tuple[set[str], dict[str, dict]]:
    """收集 tree_structure 全部 URL 及其层级信息"""
    with open(tree_path, "r", encoding="utf-8") as f:
        root = json.load(f)
    urls: set[str] = set()
    info: dict[str, dict] = {}

    def walk(node: dict, level: int, parent_url: str | None) -> None:
        url = node.get("url")
        if not url:
            return
        norm = normalize_url(url)
        urls.add(norm)
        if norm not in info:
            info[norm] = {
                "level": level,
                "parent_url": parent_url,
                "is_leaf": 1 if node.get("leaf") else 0,
                "node_type": node.get("type"),
                "not_found": 1 if node.get("not_found") else 0,
                "raw_url": url,
            }
        for child in node.get("children", []):
            walk(child, level + 1, url)

    walk(root, 0, None)
    return urls, info


def collect_excel_urls(excel_path: Path) -> set[str]:
    """收集 Excel A 列全部 URL（normalize 后）"""
    wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
    ws = wb.active
    urls: set[str] = set()
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row and row[0]:
            urls.add(normalize_url(str(row[0]).strip()))
    wb.close()
    return urls


async def verify(site: str, excel_path: Path, tree_path: Path) -> int:
    """执行验证，返回发现问题数"""
    repo = LinkTreeRepository()

    # 1. DB 总记录数
    db_count = await repo.count_by_site(site)
    db_urls = set(await repo.list_urls_by_site(site))
    logger.info("=" * 60)
    logger.info("数据一致性验证报告")
    logger.info("=" * 60)
    logger.info(f"站点: {site}")
    logger.info(f"DB 总记录数: {db_count}")
    logger.info(f"DB url 去重数: {len(db_urls)}")

    # 2. Excel / tree 数据
    excel_urls = collect_excel_urls(excel_path)
    tree_urls, tree_info = collect_tree_urls(tree_path)
    logger.info(f"Excel url 去重数: {len(excel_urls)}")
    logger.info(f"tree url 去重数: {len(tree_urls)}")

    issues = 0

    # 3. 集合一性性
    db_excel_diff = db_urls - excel_urls
    excel_db_diff = excel_urls - db_urls
    db_tree_diff = db_urls - tree_urls
    tree_db_diff = tree_urls - db_urls

    logger.info("-" * 60)
    logger.info("【集合一致性】")
    logger.info(f"DB有/Excel无: {len(db_excel_diff)} (期望 0)")
    logger.info(f"Excel有/DB无: {len(excel_db_diff)} (期望 0)")
    logger.info(f"DB有/tree无: {len(db_tree_diff)} (期望 0)")
    logger.info(f"tree有/DB无: {len(tree_db_diff)} (期望 0)")

    if db_excel_diff:
        issues += 1
        for u in list(db_excel_diff)[:10]:
            logger.warning(f"  DB有/Excel无: {u}")
    if excel_db_diff:
        issues += 1
        for u in list(excel_db_diff)[:10]:
            logger.warning(f"  Excel有/DB无: {u}")
    if db_tree_diff:
        issues += 1
        for u in list(db_tree_diff)[:10]:
            logger.warning(f"  DB有/tree无: {u}")
    if tree_db_diff:
        issues += 1
        for u in list(tree_db_diff)[:10]:
            logger.warning(f"  tree有/DB无: {u}")

    # 4. level 分布
    level_dist = await repo.level_distribution(site)
    logger.info("-" * 60)
    logger.info("【level 分布】")
    for level, count in level_dist:
        logger.info(f"  level {level}: {count} 条")
    root_count = next((c for lv, c in level_dist if lv == 0), 0)
    logger.info(f"根节点（level=0）数: {root_count} (期望 ≥ 1)")
    if root_count < 1:
        issues += 1

    # 5. parent_url 完整性
    all_rows = await repo.list_all_by_site(site)
    level0_with_parent = sum(1 for r in all_rows if r.level == 0 and r.parent_url is not None)
    non_level0_no_parent = sum(1 for r in all_rows if r.level != 0 and r.parent_url is None)
    logger.info("-" * 60)
    logger.info("【parent_url 完整性】")
    logger.info(f"level=0 但 parent_url 非空: {level0_with_parent} (期望 0)")
    logger.info(f"level>0 但 parent_url 为空: {non_level0_no_parent} (期望 0)")
    if level0_with_parent:
        issues += 1
    if non_level0_no_parent:
        issues += 1

    # 6. 树字段抽样核对（is_leaf / node_type / not_found）
    logger.info("-" * 60)
    logger.info("【树字段抽样核对（DB vs tree JSON）】")
    mismatch_count = 0
    for r in all_rows:
        norm = normalize_url(r.url)
        ti = tree_info.get(norm)
        if not ti:
            continue
        if r.is_leaf != ti["is_leaf"]:
            mismatch_count += 1
            if mismatch_count <= 5:
                logger.warning(f"  is_leaf 不一致: {r.url} DB={r.is_leaf} tree={ti['is_leaf']}")
        if (r.node_type or None) != (ti["node_type"] or None):
            mismatch_count += 1
            if mismatch_count <= 5:
                logger.warning(f"  node_type 不一致: {r.url} DB={r.node_type!r} tree={ti['node_type']!r}")
        if r.not_found != ti["not_found"]:
            mismatch_count += 1
            if mismatch_count <= 5:
                logger.warning(f"  not_found 不一致: {r.url} DB={r.not_found} tree={ti['not_found']}")
        if r.level != ti["level"]:
            mismatch_count += 1
            if mismatch_count <= 5:
                logger.warning(f"  level 不一致: {r.url} DB={r.level} tree={ti['level']}")
    logger.info(f"树字段不一致条数: {mismatch_count} (期望 0)")
    if mismatch_count:
        issues += 1

    # 7. 删除标记行
    deleted_count = sum(1 for r in all_rows if r.update_history == "删除")
    logger.info("-" * 60)
    logger.info("【业务字段核对】")
    logger.info(f"update_history='删除' 的行数: {deleted_count} (期望 6)")
    if deleted_count != 6:
        issues += 1

    # 8. site_owner / link_type 分布（信息性）
    owner_dist = Counter(r.site_owner for r in all_rows)
    type_dist = Counter(r.link_type for r in all_rows)
    logger.info(f"site_owner 分布: {dict(owner_dist)}")
    logger.info(f"link_type 分布(top8): {dict(type_dist.most_common(8))}")

    # 9. 总结
    logger.info("=" * 60)
    if issues == 0:
        logger.info("✅ 验证通过，数据一致性良好")
    else:
        logger.error(f"❌ 验证发现 {issues} 类问题，请检查上方明细")
    logger.info("=" * 60)
    return issues


def main() -> None:
    parser = argparse.ArgumentParser(description="crawl_link_tree 数据一致性验证")
    parser.add_argument("--site", default=DEFAULT_SITE)
    parser.add_argument("--excel", default=DEFAULT_EXCEL)
    parser.add_argument("--tree", default=DEFAULT_TREE)
    args = parser.parse_args()

    excel_path = Path(args.excel)
    tree_path = Path(args.tree)
    if not excel_path.exists():
        logger.error(f"Excel 文件不存在: {excel_path}")
        sys.exit(1)
    if not tree_path.exists():
        logger.error(f"tree_structure 文件不存在: {tree_path}")
        sys.exit(1)

    issues = asyncio.run(verify(args.site, excel_path, tree_path))
    sys.exit(1 if issues else 0)


if __name__ == "__main__":
    main()

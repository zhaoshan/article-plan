package com.unify.iam.authorization.infra.persistence.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * RBAC 联合查询 Mapper：按 membership 计算角色与权限点（一次 join，去重 + 字典序）。
 */
@Mapper
public interface AuthorizationQueryMapper {

    /**
     * 计算成员的角色编码集合（跨角色、状态过滤、逻辑删除过滤，字典序）。
     * membership_role 有 (membership_id, role_id) 唯一键，故角色天然无重复。
     */
    @Select("""
            SELECT r.role_code
              FROM gateway_membership_role mr
              JOIN gateway_role r ON r.role_id = mr.role_id AND r.role_status = 'ACTIVE' AND r.delete_flag = 0
             WHERE mr.membership_id = #{membershipId} AND mr.delete_flag = 0
             ORDER BY r.role_code
            """)
    List<String> selectRoleCodesByMembership(@Param("membershipId") String membershipId);

    /**
     * 计算成员的权限点编码集合（跨角色 union 后去重，状态过滤，字典序）。
     */
    @Select("""
            SELECT DISTINCT p.permission_code
              FROM gateway_membership_role mr
              JOIN gateway_role r          ON r.role_id = mr.role_id AND r.role_status = 'ACTIVE' AND r.delete_flag = 0
              JOIN gateway_role_permission rp ON rp.role_id = r.role_id AND rp.delete_flag = 0
              JOIN gateway_permission p    ON p.permission_id = rp.permission_id AND p.permission_status = 'ACTIVE' AND p.delete_flag = 0
             WHERE mr.membership_id = #{membershipId} AND mr.delete_flag = 0
             ORDER BY p.permission_code
            """)
    List<String> selectPermissionCodesByMembership(@Param("membershipId") String membershipId);
}

package com.unify.iam.app.security;

import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.ErrorCode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * 进程内登录限流器（默认实现，{@code iam.redis.enabled=false} 或未配置时装配）：
 * ConcurrentHashMap + 惰性过期。单实例保护力完整；多副本时各节点独立计数
 * （保护力减弱但不失效）——多副本部署应开启 iam.redis 切换共享计数。
 */
@Component
@ConditionalOnProperty(prefix = "iam.redis", name = "enabled", havingValue = "false", matchIfMissing = true)
public class InMemoryLoginRateLimiter implements LoginRateLimiter {

    private static final Logger log = LoggerFactory.getLogger(InMemoryLoginRateLimiter.class);

    private final IamProperties props;

    /** 账号维度：key=规范化登录名（小写 trim） */
    private final Map<String, AccountState> accounts = new ConcurrentHashMap<>();
    /** IP 维度：key=客户端 IP */
    private final Map<String, IpState> ips = new ConcurrentHashMap<>();

    public InMemoryLoginRateLimiter(IamProperties props) {
        this.props = props;
    }

    @Override
    public void assertNotLocked(String username, String ip) {
        IamProperties.LoginRateLimit cfg = props.getLoginRateLimit();
        if (!cfg.isEnabled()) {
            return;
        }
        long now = now();
        String accountKey = normalize(username);
        AccountState a = accounts.get(accountKey);
        if (a != null && a.lockedUntil > now) {
            log.warn("login rate limited | dimension=ACCOUNT | key={} | retryAfterSeconds={}",
                    accountKey, (a.lockedUntil - now) / 1000);
            throw AuthException.tooManyRequests(ErrorCode.LOGIN_LOCKED);
        }
        IpState s = ips.get(ip);
        if (s != null && s.lockedUntil > now) {
            log.warn("login rate limited | dimension=IP | key={} | retryAfterSeconds={}", ip, (s.lockedUntil - now) / 1000);
            throw AuthException.tooManyRequests(ErrorCode.LOGIN_LOCKED);
        }
    }

    @Override
    public void recordFailure(String username, String ip) {
        IamProperties.LoginRateLimit cfg = props.getLoginRateLimit();
        if (!cfg.isEnabled()) {
            return;
        }
        long now = now();
        // 账号维度：连续失败达阈值 → 锁定并重置计数
        String accountKey = normalize(username);
        AccountState a = accounts.compute(accountKey, (k, v) -> {
            AccountState st = (v == null || v.lockedUntil > now) ? new AccountState() : v;
            st.failures++;
            if (st.failures >= cfg.getMaxFailures()) {
                st.lockedUntil = now + cfg.getLockSeconds() * 1000;
                st.failures = 0;
            }
            return st;
        });
        if (a.lockedUntil > now) {
            log.warn("login failure threshold reached | dimension=ACCOUNT | key={} | lockedSeconds={}",
                    accountKey, cfg.getLockSeconds());
        }
        // IP 维度：滑动窗口
        ips.compute(ip, (k, v) -> {
            IpState st = (v == null || v.lockedUntil > now) ? new IpState() : v;
            if (now - st.windowStart > cfg.getIpWindowSeconds() * 1000) {
                st.windowStart = now;
                st.failures = 0;
            }
            st.failures++;
            if (st.failures >= cfg.getIpMaxFailures()) {
                st.lockedUntil = now + cfg.getIpLockSeconds() * 1000;
                st.failures = 0;
                st.windowStart = now;
            }
            return st;
        });
        IpState s = ips.get(ip);
        if (s != null && s.lockedUntil > now) {
            log.warn("login failure threshold reached | dimension=IP | key={} | lockedSeconds={}", ip, cfg.getIpLockSeconds());
        }
    }

    @Override
    public void recordSuccess(String username, String ip) {
        accounts.remove(normalize(username));
        ips.remove(ip);
    }

    /** 规范化登录名：null 安全、trim、小写（避免大小写变体绕过计数）。 */
    private static String normalize(String username) {
        return username == null ? "" : username.trim().toLowerCase();
    }

    protected long now() {
        return System.currentTimeMillis();
    }

    private static final class AccountState {
        int failures;
        long lockedUntil;
    }

    private static final class IpState {
        int failures;
        long windowStart;
        long lockedUntil;
    }
}

package com.unify.iam.app.config;

import io.lettuce.core.api.StatefulConnection;
import jakarta.annotation.PostConstruct;
import java.util.List;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.StringRedisTemplate;

/**
 * 可选 Redis 中间件装配（P1-02 登录限流共享计数等多副本场景；参考 ai-chat-insight RedisMiddlewareConfiguration）。
 *
 * <p>仅 {@code iam.redis.enabled=true} 时装配（{@link ConditionalOnProperty}）；默认关——
 * 本地/单实例不创建任何 Redis Bean，登录限流自动落入进程内实现（InMemoryLoginRateLimiter）。
 */
@Configuration
@ConditionalOnProperty(prefix = "iam.redis", name = "enabled", havingValue = "true")
@EnableConfigurationProperties(IamProperties.class)
public class RedisConfig {

    private final IamProperties props;

    public RedisConfig(IamProperties props) {
        this.props = props;
    }

    @PostConstruct
    void validateWhenEnabled() {
        if ("cluster".equalsIgnoreCase(props.getRedis().getMode())) {
            List<String> nodes = props.getRedis().getCluster().getNodes();
            if (nodes == null || nodes.isEmpty()) {
                throw new IllegalStateException(
                        "iam.redis.mode=cluster 时必须配置 iam.redis.cluster.nodes（形如 host:port）");
            }
            for (String node : nodes) {
                if (node == null || !node.contains(":")) {
                    throw new IllegalStateException("非法的 cluster 节点配置: " + node + "，应为 host:port");
                }
            }
        }
    }

    @Bean(destroyMethod = "destroy")
    public LettuceConnectionFactory iamRedisConnectionFactory() {
        IamProperties.Redis r = props.getRedis();
        GenericObjectPoolConfig<StatefulConnection<?, ?>> poolConfig = new GenericObjectPoolConfig<>();
        poolConfig.setMaxTotal(r.getPool().getMaxActive());
        poolConfig.setMaxIdle(r.getPool().getMaxIdle());
        poolConfig.setMinIdle(r.getPool().getMinIdle());
        LettucePoolingClientConfiguration.LettucePoolingClientConfigurationBuilder builder =
                LettucePoolingClientConfiguration.builder()
                        .poolConfig(poolConfig)
                        .commandTimeout(r.getTimeout());
        // useSsl() 无参，返回 SSL 专用 builder——true 时才切 SSL 链
        LettuceClientConfiguration clientConfig = r.isSsl() ? builder.useSsl().build() : builder.build();
        if ("cluster".equalsIgnoreCase(r.getMode())) {
            RedisClusterConfiguration cluster = new RedisClusterConfiguration();
            for (String node : r.getCluster().getNodes()) {
                String[] hp = node.split(":");
                cluster.clusterNode(hp[0].trim(), Integer.parseInt(hp[1].trim()));
            }
            cluster.setMaxRedirects(r.getCluster().getMaxRedirects());
            applyUsername(cluster, r.getCluster().getUsername());
            cluster.setPassword(toRedisPassword(r.getCluster().getPassword()));
            return new LettuceConnectionFactory(cluster, clientConfig);
        }
        RedisStandaloneConfiguration standalone = new RedisStandaloneConfiguration();
        standalone.setHostName(r.getStandalone().getHost());
        standalone.setPort(r.getStandalone().getPort());
        standalone.setDatabase(r.getStandalone().getDatabase());
        applyUsername(standalone, r.getStandalone().getUsername());
        standalone.setPassword(toRedisPassword(r.getStandalone().getPassword()));
        return new LettuceConnectionFactory(standalone, clientConfig);
    }

    @Bean
    public StringRedisTemplate iamRedisTemplate(LettuceConnectionFactory iamRedisConnectionFactory) {
        return new StringRedisTemplate(iamRedisConnectionFactory);
    }

    private static void applyUsername(RedisStandaloneConfiguration cfg, String username) {
        if (username != null && !username.isEmpty()) {
            cfg.setUsername(username);
        }
    }

    private static void applyUsername(RedisClusterConfiguration cfg, String username) {
        if (username != null && !username.isEmpty()) {
            cfg.setUsername(username);
        }
    }

    private static RedisPassword toRedisPassword(String raw) {
        return (raw == null || raw.isEmpty()) ? RedisPassword.none() : RedisPassword.of(raw);
    }
}

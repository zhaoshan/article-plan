package com.unify.iam.app.config;

import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.BizException;
import com.unify.iam.common.result.CommonResponse;
import com.unify.iam.common.result.ResultCode;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 全局异常处理（信封，docs/user-manual/05）：
 *
 * <ul>
 *   <li>{@link EnvelopePaths} 作用域内路径 → 真实 HTTP 状态 + {@code CommonResponse} 信封
 *       （{@code {success:false, code, message, data:null}}）；</li>
 *   <li>作用域外（OIDC 重定向流程 / 非 API）→ 真实 HTTP 状态 + {@code {"detail": msg}}；</li>
 *   <li>未捕获异常 → 500 + 相应形态的失败体。</li>
 * </ul>
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(AuthException.class)
    public ResponseEntity<?> handleAuth(AuthException e) {
        return error(e.getHttpStatus(), ResultCode.AUTH_ERROR, e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidation(MethodArgumentNotValidException e) {
        String detail = e.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(fe -> fe.getDefaultMessage() != null ? fe.getDefaultMessage() : "参数错误")
                .orElse("参数错误");
        return error(HttpStatus.BAD_REQUEST.value(), ResultCode.PARAM_ERROR, detail);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<?> handleUnreadable(HttpMessageNotReadableException e) {
        return error(HttpStatus.BAD_REQUEST.value(), ResultCode.PARAM_ERROR, "请求体格式错误");
    }

    /** 缺失的静态资源（如 Chrome DevTools 探测 /.well-known/...）→ 404，而非 500。 */
    @ExceptionHandler(org.springframework.web.servlet.resource.NoResourceFoundException.class)
    public ResponseEntity<?> handleNoResource(org.springframework.web.servlet.resource.NoResourceFoundException e) {
        return error(HttpStatus.NOT_FOUND.value(), ResultCode.BIZ_ERROR, "资源不存在");
    }

    @ExceptionHandler(BizException.class)
    public ResponseEntity<CommonResponse<Void>> handleBiz(BizException e) {
        HttpStatus status = e.getHttpStatus() == 200 ? HttpStatus.OK : HttpStatus.valueOf(e.getHttpStatus());
        return ResponseEntity.status(status).body(CommonResponse.fail(e.getCode(), e.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleOther(Exception e) {
        log.error("未捕获异常", e);
        return error(HttpStatus.INTERNAL_SERVER_ERROR.value(), ResultCode.SYSTEM_ERROR, "系统错误");
    }

    /** 按请求路径输出信封或 detail 失败体。 */
    private ResponseEntity<?> error(int status, String code, String message) {
        String path = currentPath();
        if (EnvelopePaths.inScope(path)) {
            return ResponseEntity.status(status).body(CommonResponse.fail(code, message));
        }
        return ResponseEntity.status(status).body(Map.of("detail", message));
    }

    private String currentPath() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes a) {
            return a.getRequest().getRequestURI();
        }
        return null;
    }
}

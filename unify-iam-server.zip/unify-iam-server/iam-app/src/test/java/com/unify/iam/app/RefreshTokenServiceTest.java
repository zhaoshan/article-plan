package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.unify.iam.app.app.service.RefreshTokenService;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.infra.persistence.po.RefreshTokenPO;
import com.unify.iam.app.infra.persistence.repository.RefreshTokenRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class RefreshTokenServiceTest {

    @Mock
    private RefreshTokenRepository refreshTokenRepository;
    @Mock
    private MembershipResolver membershipResolver;

    private final IamProperties props = new IamProperties();
    private RefreshTokenService service;

    @BeforeEach
    void setUp() {
        service = new RefreshTokenService(refreshTokenRepository, membershipResolver, props);
    }

    private MembershipPO membership(String userId) {
        MembershipPO m = new MembershipPO();
        m.setMembershipId("ms-2001");
        m.setTenantId("tenant-org-a");
        m.setUserId(userId);
        m.setMembershipStatus("ACTIVE");
        return m;
    }

    private RefreshTokenPO activePo(String userId) {
        RefreshTokenPO po = new RefreshTokenPO();
        po.setId(1L);
        po.setRefreshTokenId("rt-1");
        po.setUserId(userId);
        po.setTenantId("tenant-org-a");
        po.setMembershipId("ms-2001");
        po.setRefreshTokenHash("hash");
        po.setExpiresAt(LocalDateTime.now().plusDays(10));
        return po;
    }

    @Test
    void issueStoresHashNotPlaintext() {
        String plain = service.issue("u-1", membership("u-1"));

        ArgumentCaptor<RefreshTokenPO> captor = ArgumentCaptor.forClass(RefreshTokenPO.class);
        verify(refreshTokenRepository).insert(captor.capture());
        assertThat(captor.getValue().getRefreshTokenHash()).isNotEqualTo(plain);
        assertThat(captor.getValue().getUserId()).isEqualTo("u-1");
        assertThat(captor.getValue().getMembershipId()).isEqualTo("ms-2001");
    }

    @Test
    void rotateRevokesOldAndIssuesNew() {
        when(refreshTokenRepository.findActiveByHash(any())).thenReturn(Optional.of(activePo("u-1")));
        when(membershipResolver.findActiveById("ms-2001")).thenReturn(Optional.of(membership("u-1")));

        RefreshTokenService.Rotated rotated = service.rotate("some-plain");

        verify(refreshTokenRepository).markRevoked(1L);
        assertThat(rotated.userId()).isEqualTo("u-1");
        assertThat(rotated.membershipId()).isEqualTo("ms-2001");
        assertThat(rotated.newRefreshToken()).isNotBlank();
        // 新 refresh 也落库（哈希）
        verify(refreshTokenRepository).insert(any(RefreshTokenPO.class));
    }

    @Test
    void rotateInvalidTokenThrows401() {
        when(refreshTokenRepository.findActiveByHash(any())).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.rotate("bad"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
        verify(refreshTokenRepository, never()).markRevoked(any());
    }

    @Test
    void rotateMembershipMismatchThrows401() {
        when(refreshTokenRepository.findActiveByHash(any())).thenReturn(Optional.of(activePo("u-1")));
        // 该成员属于另一个用户
        when(membershipResolver.findActiveById("ms-2001")).thenReturn(Optional.of(membership("u-999")));

        assertThatThrownBy(() -> service.rotate("x"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
        verify(refreshTokenRepository, never()).markRevoked(any());
    }

    @Test
    void revokeMarksOld() {
        when(refreshTokenRepository.findActiveByHash(any())).thenReturn(Optional.of(activePo("u-1")));

        service.revoke("some-plain");

        verify(refreshTokenRepository).markRevoked(1L);
    }
}
# 20261013-Gateway-DDD 包结构与演进评估

> 状态：**评估完成，待决策**（2026-10-13）。
> 定位：评估当前 6 模块的 package 划分在 **DDD（Domain-Driven Design）** 视角下的优化空间——重点是「是否补 domain 领域层」「controller 是否拆分到各模块」「iam-app 与其他模块的差异是否合理」。
> 依据：当前包结构实况 + 互联网检索（StackOverflow / SE / hexagonal 实践，见 §8）+ 既有约束（CLAUDE.md 依赖方向、docs/01 `domain/` 预留）。
> 关联：docs/01（总体模块与阶段拆分）；CLAUDE.md（依赖方向、认证器可插拔）。

---

## 0. 结论速览

- **当前骨架是对的**：模块 = 有界上下文（BC），依赖只向下，iam-app 做跨上下文编排 + 接口适配 —— 已是"简化 hexagonal + 模块化单体"。
- **iam-app 与其他模块的差异是刻意分工，不是坏味道**：业务模块是"领域内核 + 出端口"，iam-app 是"组合根 + 进端口（controller）+ 横切设施"。
- **controller 不建议拆分到各业务模块**：违背依赖方向（业务模块互不依赖、跨上下文 controller 无处安放）、单应用事实下拿不到独立部署收益、HTTP/安全/审计是全局横切关注点。
- **最值得做的是两项**：① 轻量补 `domain` 层（仓储接口依赖倒置，影响小、机械为主）；② `iam-api` 收敛为共享契约。端口重命名/全 DDD 暂缓。

---

## 1. 当前结构与 DDD 概念映射

```
模块 = 有界上下文（Bounded Context）
  iam-identity / iam-tenant / iam-authorization   ← 领域模块（业务规则 + 持久化）
  iam-app                                        ← 组合根：跨上下文编排 + 接口适配 + 横切设施
  iam-api / iam-common                           ← 共享内核 / 跨上下文契约

各业务模块内：
  app/     应用层（用例：app/service）
  infra/   基础设施（po / mapper / repository）
  缺少     domain/（领域模型层）

iam-app 内：
  adapter/controller  接口适配（进端口）
  app/service(.admin) 跨上下文编排 + 管理面用例
  oidc / authenticator / security / config / infra  横切设施与出端口
```

**映射判断**：
- ✅ 模块即 BC、依赖只向下（domain 模块不互依）——符合 DDD 战略设计。
- ✅ 应用层跨上下文编排（`TokenService` / `AdminTenantService` 等）——DDD 允许应用层做聚合/上下文编排。
- ✅ 认证器可插拔（`Authenticator` 接口）——已是端口思想。
- ⚠️ 缺显式 `domain` 层：PO 是贫血数据类，业务不变量（role_code 作用域唯一、成员默认、租户必含 owner 等）散在应用服务 + DB 唯一键。
- ⚠️ repository 是具体类（无接口），应用服务直接依赖 MyBatis 仓储 → 单元测试难 mock。
- ⚠️ `iam-api` 是 `dto.admin/dto.auth/dto.jwks/model/constant` 大杂烩，把三个域的入参 DTO 全塞进一个模块，边界不清。

> docs/01 已注明 `domain/` 是"未来阶段随复杂度引入"的预留——本评估即对该预留的落地评估。

---

## 2. DDD 最佳实践要点（互联网检索）

| 主题 | 结论 | 来源 |
|---|---|---|
| 包结构 | **先按 Feature / Bounded Context 分包，BC 内再按层**——每个 BC 是垂直切片 | StackOverflow |
| Hexagonal | **domain 是六边形内核（纯业务，无框架）**；ports（接口）在 domain；适配器在 infrastructure（in=controller，out=jpa/mail/oidc 等） | tbuss / allegro / johnjqc |
| 仓储 | **Repository 接口放 domain 层，实现放 infrastructure**（依赖倒置） | SE / SO / LinkedIn |
| 模块 | BC 与 Java 模块（JPMS）天然对应，强封装 | Baeldung / tangly |

---

## 3. 优化空间评估（按价值排序）

### 3.1 controller 拆分到各业务模块 → **不做**（负收益）

| 理由 | 说明 |
|---|---|
| 依赖方向锁死 | 业务模块互不依赖；跨上下文 controller（如成员页要 identity 用户目录 + authorization 角色）无处安放，只能放更高层 |
| 单应用事实 | 仍是**一个** `@SpringBootApplication`；controller 拆进模块也得被 iam-app 组件扫描，拿不到"独立部署"收益 |
| 横切关注点 | HTTP 鉴权（JWT verify/拦截器）、错误处理、审计全局一套，集中 iam-app 更合理 |
| DDD 合法性 | "应用层在模块内、REST 适配器在组合根"是 Ports & Adapters 的**合法变体**；adapter.in 每模块化是给可独立部署的模块（微服务）用的 |

> 正确关系：controller（iam-app，薄）→ 各模块 application 用例（service）→ 模块 domain/infra。

### 3.2 轻量补 `domain` 层（**建议做**，影响小-中）

每个业务模块新增：
```
domain/model      # 聚合根/实体/值对象（把关键不变量上收，可先只上收"规则集中点"）
domain/service    # 领域服务（跨聚合规则）
domain/repository # 仓储接口
infra/.../repository → 改名为 *Impl（实现）
```
- 价值：依赖倒置 → 应用服务面向接口，单元测试可 mock，降低对 MyBatis 的耦合；为未来把业务不变量从"应用服务 + DB 约束"上收到领域层铺路。
- 影响：接口提取 + 实现改名，**机械改动为主，不改业务行为，测试基本不动**。

### 3.3 `iam-api` 收敛为共享契约/反腐层（**建议做**，影响中）

- 现状：`dto.admin / dto.auth / dto.jwks / model / constant` 大杂烩，三个域的入参 DTO 塞进一个模块。
- 目标：`iam-api` 只留**真正跨上下文**的契约（`JwtClaims` / `AuthorizationContext` / `PermissionCodes` / LoginResponse 等）；各域应用 DTO 移入各业务模块的 `app` 层。
- 影响：import 跟随改动，但边界立刻清晰。

### 3.4 端口/适配器显式命名（**暂缓**，纯结构）

`oidc / security / authenticator / infra` 按"技术"命名，可按 hexagonal 调整为 `infrastructure.adapter.in/out` + domain 端口接口（`TokenSigner`、`IdpClient`）。纯结构、零业务价值，等真有"换实现 / 接新 IdP / 独立部署"需求时再顺势做。

### 3.5 聚合边界与不变量（后置）

跨表编排（`AdminTenantService.create` 编排 tenant+role+membership+tenant_application）由应用服务做——DDD 一致；"新租户必含 owner"这类不变量最终应由聚合/领域服务保证。当前规模不必急着抽。

---

## 4. 影响评估（分级）

| 改造 | 影响 | 是否建议 |
|---|---|---|
| 轻量 domain 层（仓储接口 + Impl + 少量领域服务） | **小-中**、机械为主、不改行为 | ✅ 建议（分步） |
| iam-api 收敛 | **中**（import 跟随） | ✅ 建议 |
| controller 拆分 | **负收益** | ❌ 不做 |
| 端口/适配器重命名 | 小、纯结构 | ⏸ 暂缓 |
| 全 DDD（PO/实体彻底分离 + 事件 + mapper 转换） | **大**、测试重写 | ❌ 当前规模不值 |

---

## 5. 目标结构（不推倒重来）

```
每个业务模块：  domain/(model, service, repository接口) + app/service + infra/persistence(*Impl)
iam-app：       adapter/controller（薄，调模块用例）
                + app/service（跨上下文编排 / 管理面用例）
                + security / config / authenticator / oidc（组合根设施）
iam-api：       收敛为 共享契约 + 跨上下文 model/constant
iam-common：    通用工具 / 基类（不变）
```

演进顺序建议：**先 3.2 仓储接口化（最小成本拿到依赖倒置）→ 再 3.3 iam-api 收敛 → 视复杂度逐步上收领域不变量**；3.4/3.5 留到有真实诉求（接新 IdP / 独立部署 / 业务复杂度上升）再动。

---

## 6. 参考来源

- Stack Overflow — [Package by feature vs layer with DDD](https://stackoverflow.com/questions/55245747/should-we-use-package-by-feature-structure-with-ddd)
- tbuss — [Package structure in Ports & Adapters](https://tbuss.de/posts/2023/9-how-to-do-the-package-structure-in-a-ports-and-adapter-architecture/)
- allegro.tech — [Hexagonal Architecture by example](https://blog.allegro.tech/2020/05/hexagonal-architecture-by-example.html)
- johnjqc — [hexagonal-architecture-ports-adapters（adapter.in/out 约定）](https://github.com/johnjqc/hexagonal-architecture-ports-adapters)
- Software Engineering SE — [Which layer do DDD Repositories belong to?](https://softwareengineering.stackexchange.com/questions/396151/which-layer-do-ddd-repositories-belong-to)
- Baeldung — [DDD Bounded Contexts and Java Modules](https://www.baeldung.com/java-modules-ddd-bounded-contexts)

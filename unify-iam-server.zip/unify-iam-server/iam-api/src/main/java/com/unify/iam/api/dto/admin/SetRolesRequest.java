package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

/** 设置成员角色（覆盖式）。 */
public record SetRolesRequest(@JsonProperty("role_ids") List<String> roleIds) {

    public SetRolesRequest {
        roleIds = roleIds == null ? List.of() : roleIds;
    }
}

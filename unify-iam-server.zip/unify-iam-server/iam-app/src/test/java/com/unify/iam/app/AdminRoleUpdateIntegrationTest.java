package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

class AdminRoleUpdateIntegrationTest extends IamIntegrationTestBase {

    private String adminToken() throws Exception {
        MvcResult result = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(result.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private Map<String, Object> adminPost(String url, Object body, String token) throws Exception {
        MvcResult result = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return unwrapData(result.getResponse().getContentAsString());
    }

    @SuppressWarnings("unchecked")
    @Test
    void metadataUpdatePersistsAuditsKeepsRoleCodeAndLeavesPermissionVersionRulesIntact() throws Exception {
        String token = adminToken();
        String tenantId = adminPost("/api/v1/admin/tenants", Map.of(
                "tenant_code", "role-update-tenant", "tenant_name", "Role Update Tenant",
                "tenant_type", "ORGANIZATION", "app_codes", List.of("parlant-agent-server")), token)
                .get("tenant_id").toString();
        String userId = adminPost("/api/v1/admin/users", Map.of(
                "username", "role_update_user", "email", "role-update-user@unify.local", "password", b64("Passw0rd!")), token)
                .get("user_id").toString();
        String roleId = adminPost("/api/v1/admin/roles", Map.of(
                "scope_type", "TENANT", "scope_id", tenantId,
                "role_code", "SupportOperator", "role_name", "Initial support", "role_description", "Initial description"), token)
                .get("role_id").toString();
        String membershipId = adminPost("/api/v1/admin/members", Map.of(
                "tenant_id", tenantId, "user_id", userId, "role_ids", List.of(roleId)), token)
                .get("membership_id").toString();
        Integer versionBefore = jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId);

        mockMvc.perform(put("/api/v1/admin/roles/" + roleId)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_name\":\" Updated support \",\"role_description\":\"Updated description\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.role_id").value(roleId));

        Map<String, Object> stored = jdbcTemplate.queryForMap(
                "SELECT role_code, role_name, role_description FROM gateway_role WHERE role_id = ?", roleId);
        assertThat(stored.get("role_code")).isEqualTo("SupportOperator");
        assertThat(stored.get("role_name")).isEqualTo("Updated support");
        assertThat(stored.get("role_description")).isEqualTo("Updated description");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId))
                .isEqualTo(versionBefore);

        String rolesBody = mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        List<Map<String, Object>> roles = (List<Map<String, Object>>) unwrapData(rolesBody).get("roles");
        Map<String, Object> updated = roles.stream()
                .filter(role -> roleId.equals(role.get("role_id")))
                .findFirst().orElseThrow();
        assertThat(updated.get("role_description")).isEqualTo("Updated description");

        Map<String, Object> audit = jdbcTemplate.queryForMap(
                "SELECT tenant_id, before_json, after_json FROM gateway_audit_log "
                        + "WHERE event_type = 'ADMIN_UPDATE_ROLE' AND target_id = ? ORDER BY id DESC LIMIT 1", roleId);
        assertThat(audit.get("tenant_id").toString().trim()).isEqualTo(tenantId);
        assertThat(String.valueOf(audit.get("before_json"))).contains("Initial support");
        assertThat(String.valueOf(audit.get("after_json"))).contains("Updated support");
        mockMvc.perform(get("/api/v1/admin/audit/events").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.events[?(@.code == 'ADMIN_UPDATE_ROLE')].name").exists());

        mockMvc.perform(put("/api/v1/admin/roles/" + roleId)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_code\":\"Renamed\",\"role_name\":\"Should not persist\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("role_code cannot be updated"));
        assertThat(jdbcTemplate.queryForObject(
                "SELECT role_code FROM gateway_role WHERE role_id = ?", String.class, roleId))
                .isEqualTo("SupportOperator");

        mockMvc.perform(put("/api/v1/admin/roles/" + roleId)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_name\":\"Updated support\",\"role_description\":null}"))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT role_description FROM gateway_role WHERE role_id = ?", String.class, roleId)).isNull();
        String clearedRolesBody = mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        List<Map<String, Object>> clearedRoles = (List<Map<String, Object>>) unwrapData(clearedRolesBody).get("roles");
        assertThat(clearedRoles.stream().filter(role -> roleId.equals(role.get("role_id"))).findFirst().orElseThrow())
                .doesNotContainKey("role_description");

        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"permission_ids\":[\"p-1001\"]}"))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId))
                .isGreaterThan(versionBefore);
    }
}

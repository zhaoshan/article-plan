package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.StatusCheckRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.security.JwtAuth;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import jakarta.validation.Valid;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 会话/租户状态查询端点（G4，docs/requirements M10W3 能力盘点 §4.4）：
 * 供业务系统在登录/关键操作前**权威**查询当前租户/成员是否仍有效（读库，而非 token claims 快照）。
 *
 * <ul>
 *   <li>{@code GET /api/v1/auth/session-status}（Bearer）：当前 token 上下文的租户 + 成员状态与 {@code valid}；</li>
 *   <li>{@code GET /api/v1/auth/tenant-status?tenant_id=}（Bearer）：查询某租户状态，限调用者自己的成员关系（防枚举）；</li>
 *   <li>{@code POST /api/v1/auth/status-check}（服务间，{@code X-IAM-Service-Token}）：按任务提交时存的
 *       {@code tenant_id + membership_id} 权威校验，供业务系统后台任务执行前判断「是否仍有效」。</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/v1/auth")
public class SessionStatusController {

    private final JwtSigner jwtSigner;
    private final MembershipRepository membershipRepository;
    private final TenantRepository tenantRepository;
    private final MembershipResolver membershipResolver;
    private final IamProperties props;

    public SessionStatusController(JwtSigner jwtSigner,
                                   MembershipRepository membershipRepository,
                                   TenantRepository tenantRepository,
                                   MembershipResolver membershipResolver,
                                   IamProperties props) {
        this.jwtSigner = jwtSigner;
        this.membershipRepository = membershipRepository;
        this.tenantRepository = tenantRepository;
        this.membershipResolver = membershipResolver;
        this.props = props;
    }

    /** 当前 token 上下文的权威状态（G4）：成员/租户是否仍 ACTIVE。 */
    @GetMapping("/session-status")
    public Map<String, Object> sessionStatus(
            @RequestHeader(value = "Authorization", required = false) String authorization) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        MembershipPO m = membershipRepository.findById(claims.membershipId()).orElse(null);
        TenantPO t = (m == null) ? null : tenantRepository.findById(m.getTenantId()).orElse(null);
        String membershipStatus = (m == null) ? null : m.getMembershipStatus();
        String tenantStatus = (t == null) ? null : t.getTenantStatus();
        boolean valid = m != null && t != null
                && "ACTIVE".equals(membershipStatus) && "ACTIVE".equals(tenantStatus);

        Map<String, Object> r = new LinkedHashMap<>();
        r.put("tenant_id", t == null ? (m == null ? claims.tenantId() : m.getTenantId()) : t.getTenantId());
        r.put("tenant_code", t == null ? null : t.getTenantCode());
        r.put("tenant_status", tenantStatus);
        r.put("membership_id", m == null ? claims.membershipId() : m.getMembershipId());
        r.put("membership_status", membershipStatus);
        r.put("valid", valid);
        return r;
    }

    /** 查询某租户状态（G4）：限调用者自己的成员关系；删除/不存在 → 404。 */
    @GetMapping("/tenant-status")
    public Map<String, Object> tenantStatus(
            @RequestHeader(value = "Authorization", required = false) String authorization,
            @RequestParam(value = "tenant_id") String tenantId) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        boolean isMember = membershipResolver.listByUser(claims.userId()).stream()
                .anyMatch(mm -> mm.getTenantId().trim().equals(tenantId.trim()));
        if (!isMember) {
            throw AuthException.forbidden("无权查询该租户状态");
        }
        TenantPO t = tenantRepository.findById(tenantId.trim())
                .orElseThrow(() -> AuthException.notFound("租户不存在"));
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("tenant_id", t.getTenantId());
        r.put("tenant_code", t.getTenantCode());
        r.put("tenant_name", t.getTenantName());
        r.put("tenant_status", t.getTenantStatus());
        return r;
    }

    /**
     * 服务间状态校验（G4）：业务系统后台任务执行前，按提交时存的 {@code tenant_id + membership_id}
     * 权威判断租户/成员是否仍有效（读库）。鉴权同版本 feed：{@code X-IAM-Service-Token}。
     * 成员被移除/停用、租户被停用/删除 → {@code valid=false}。
     */
    @PostMapping("/status-check")
    public Map<String, Object> statusCheck(
            @RequestHeader(value = "X-IAM-Service-Token", required = false) String serviceToken,
            @Valid @RequestBody StatusCheckRequest request) {
        String expected = props.getVersions().getServiceToken();
        if (expected == null || expected.isBlank()) {
            throw AuthException.forbidden("服务间状态校验未启用：请配置 iam.versions.service-token");
        }
        if (serviceToken == null
                || !MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
                serviceToken.getBytes(StandardCharsets.UTF_8))) {
            throw AuthException.unauthorized("服务间令牌校验失败");
        }
        MembershipPO m = membershipRepository.findById(request.membershipId().trim()).orElse(null);
        TenantPO t = tenantRepository.findById(request.tenantId().trim()).orElse(null);
        boolean tenantMatch = m != null && t != null
                && m.getTenantId().trim().equals(t.getTenantId().trim());
        boolean valid = m != null && t != null && tenantMatch
                && "ACTIVE".equals(m.getMembershipStatus()) && "ACTIVE".equals(t.getTenantStatus());

        Map<String, Object> r = new LinkedHashMap<>();
        r.put("tenant_id", request.tenantId());
        r.put("tenant_status", t == null ? null : t.getTenantStatus());
        r.put("membership_id", request.membershipId());
        r.put("membership_status", m == null ? null : m.getMembershipStatus());
        r.put("valid", valid);
        return r;
    }
}

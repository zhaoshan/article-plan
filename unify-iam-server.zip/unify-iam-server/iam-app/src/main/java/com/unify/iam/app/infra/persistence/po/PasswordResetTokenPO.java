package com.unify.iam.app.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_password_reset_token 表 PO（P3 登录 UI 后端）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_password_reset_token")
public class PasswordResetTokenPO extends BaseEntity {

    private String passwordResetTokenId;
    private String userId;
    private String email;
    private String tokenHash;
    private LocalDateTime expiresAt;
    private LocalDateTime usedAt;
    private LocalDateTime invalidatedAt;
    private Integer isLatest;
}

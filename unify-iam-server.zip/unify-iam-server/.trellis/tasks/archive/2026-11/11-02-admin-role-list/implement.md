# Execution plan

1. Add isolated admin query and route the service after existing scope guards.
2. Add MySQL/MockMvc regression tests using isolated test data and real database-backed scope guards.
3. Synchronize role-list documentation and the backend spec.
4. Run focused tests under JDK 21, full Maven checks if possible, and diff checks.

Status: implementation authorized by the user's explicit correction and instruction to continue; no further scope confirmation required.

## Validation and session record

- Initial branch and final branch: feature/lee-1102. Initial working tree clean.
- Implemented a management-only query; retained the shared ACTIVE-only path.
- Controller now batches tenant applications/templates so Owner flags remain correct in global results.
- JDK 21 focused regression run: 19 tests, zero failures/errors/skips.
- JDK 21 `mvn clean install`: BUILD SUCCESS; iam-app 267 tests, zero failures/errors/skips.
- Initial sandboxed execution compiled all code but could not attach Mockito/use Docker; rerun outside sandbox succeeded.
- Updated the backend database spec and role API/business documentation.
- No production data operations, commit, branch switch, merge, push, or worktree changes performed.
- All task files and session notes remain in this task directory. Changes intentionally remain uncommitted.

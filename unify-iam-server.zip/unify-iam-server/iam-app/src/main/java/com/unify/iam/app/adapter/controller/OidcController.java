package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.oidc.OidcSsoService;
import java.net.URI;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * OIDC SSO 端点（企业 SSO / 平台级个人账号登录）。
 *
 * <p>authorize：302 跳 IdP（带 state/nonce/PKCE）。callback：换 token → 验签 → JIT → 签发；
 * 请求带 {@code Accept: application/json} 时返回 {@link LoginResponse}（测试/前端接入），
 * 否则 302 回前端，query 携带 access_token + refresh_token（docs/03 §13.1）。
 */
@RestController
@RequestMapping("/api/v1/auth/oidc")
public class OidcController {

    private final OidcSsoService oidcSsoService;
    private final IamProperties props;

    public OidcController(OidcSsoService oidcSsoService, IamProperties props) {
        this.oidcSsoService = oidcSsoService;
        this.props = props;
    }

    /** 发起 SSO：跳转 IdP 授权端点。 */
    @GetMapping("/authorize")
    public ResponseEntity<Void> authorize(@RequestParam("tenant_id") String tenantId) {
        String url = oidcSsoService.buildAuthRequestUrl(tenantId);
        return ResponseEntity.status(HttpStatus.FOUND).location(URI.create(url)).build();
    }

    /** IdP 回调。 */
    @GetMapping("/callback")
    public ResponseEntity<Object> callback(
            @RequestParam("code") String code,
            @RequestParam("state") String state,
            @RequestHeader(value = "Accept", defaultValue = "*/*") String accept) {
        LoginResponse response = oidcSsoService.handleCallback(code, state);
        if (accept.contains("application/json")) {
            return ResponseEntity.ok(response);
        }
        // 302 回跳携带 access_token + refresh_token（docs/03 §13.1；refresh_token 供业务应用 401 静默刷新，
        // 交付形态与 access_token 一致走 URL query——泄漏面与缓解见 parlant doc11 附录 A 项①）
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(props.getOidc().getFrontendRedirect())
                .queryParam("access_token", response.accessToken());
        if (response.refreshToken() != null) {
            builder.queryParam("refresh_token", response.refreshToken());
        }
        URI target = builder.build().encode().toUri();
        return ResponseEntity.status(HttpStatus.FOUND).location(target).build();
    }
}
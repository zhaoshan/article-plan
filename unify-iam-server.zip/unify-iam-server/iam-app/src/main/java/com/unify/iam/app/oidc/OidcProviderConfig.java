package com.unify.iam.app.oidc;

import java.util.List;
import java.util.Map;

/**
 * 解析后的 OIDC IdP 配置（供 OIDC 客户端消费，不含机密解析以外的落库细节）。
 *
 * @param configId            配置业务 ID
 * @param tenantId            所属租户；平台级 consumer 为 {@code PLATFORM}
 * @param providerKey         提供方标识（keycloak/google/microsoft/...）
 * @param issuer              OIDC issuer
 * @param authorizationEndpoint 授权端点
 * @param tokenEndpoint       换 token 端点
 * @param jwkSetUri           JWKS 地址
 * @param clientId            OAuth 客户端 ID
 * @param clientSecret        OAuth 客户端密钥（P2 直取；生产走加解密）
 * @param scopes              scopes（默认 openid email profile）
 * @param claimMapping        内部字段 → 外部 claim 名
 * @param allowedDomains      允许的邮箱域名（空 = 不限制，仅平台级 consumer）
 * @param pkceRequired        是否要求 PKCE
 * @param emailVerifiedRequired 是否强制 email_verified
 * @param jitEnabled          是否允许 JIT 自动建号/建成员
 * @param defaultJoinPolicy   首登默认加入策略：AUTO_JOIN / REQUEST / INVITE_ONLY
 */
public record OidcProviderConfig(
        String configId,
        String tenantId,
        String providerKey,
        String issuer,
        String authorizationEndpoint,
        String tokenEndpoint,
        String jwkSetUri,
        String clientId,
        String clientSecret,
        List<String> scopes,
        Map<String, String> claimMapping,
        List<String> allowedDomains,
        boolean pkceRequired,
        boolean emailVerifiedRequired,
        boolean jitEnabled,
        String defaultJoinPolicy) {

    /** 是否平台级 consumer IdP（个人账号登录）。 */
    public boolean isPlatformConfig() {
        return "PLATFORM".equalsIgnoreCase(tenantId);
    }

    /** 该邮箱域名是否在允许名单（空名单 = 不限制）。 */
    public boolean allowsDomain(String domain) {
        return allowedDomains.isEmpty() || allowedDomains.contains(domain.toLowerCase());
    }

    /** 取某内部字段对应的外部 claim 名（未配置则同名）。 */
    public String externalClaim(String internalKey) {
        return claimMapping.getOrDefault(internalKey, internalKey);
    }
}
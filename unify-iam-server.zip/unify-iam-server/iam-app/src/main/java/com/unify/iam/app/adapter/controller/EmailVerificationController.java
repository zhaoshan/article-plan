package com.unify.iam.app.adapter.controller;

import com.unify.iam.app.app.service.EmailVerificationService;
import com.unify.iam.app.mail.RegistrationVerificationMailService;
import com.unify.iam.common.log.LogPayload;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 注册邮箱验证码（2026-11-05，docs/08 §16）：发码 / 校码，均无需登录。
 * 错误码：IAM-AUTH-011 过于频繁 / 012 验证码错误 / 013 已过期。
 */
@RestController
@RequestMapping("/api/v1/auth/email-verification-codes")
public class EmailVerificationController {

    private final EmailVerificationService emailVerificationService;

    public EmailVerificationController(EmailVerificationService emailVerificationService) {
        this.emailVerificationService = emailVerificationService;
    }

    /** 发送注册验证码（10 分钟有效；60s 冷却 + 24h 10 次上限；SMTP 未配置时验证码走日志兜底）。 */
    @PostMapping
    @LogPayload // body 仅 email，无凭据
    public Map<String, String> send(@Valid @RequestBody SendVerificationCodeRequest request) {
        emailVerificationService.send(request.email());
        // 防枚举：统一受理，不暴露邮箱是否已注册/已存在
        return Map.of("status", "SENT");
    }

    /** 校码：通过 → 200；错码/过期/作废 → 400 细分错误码（前端据此引导重发）。 */
    @PostMapping("/verify")
    @LogPayload // body 仅 email + 6 位数字码
    public Map<String, String> verify(@Valid @RequestBody VerifyVerificationCodeRequest request) {
        emailVerificationService.verify(request.email(), request.code());
        return Map.of("status", "VERIFIED");
    }

    public record SendVerificationCodeRequest(
            @NotBlank(message = "email is required") @Email(message = "email format is invalid") String email) {
    }

    public record VerifyVerificationCodeRequest(
            @NotBlank(message = "email is required") @Email(message = "email format is invalid") String email,
            @NotBlank(message = "code is required") String code) {
    }
}

package com.unify.iam.common.util;

import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.ErrorCode;
import java.nio.charset.StandardCharsets;

/**
 * 统一后端密码策略（P1-03）：UTF-8 字节长度 8–72。
 *
 * <p>所有「设置新密码」链路必须调用（base64 解码后、BCrypt 哈希前）：注册、忘记密码重置、
 * 自助改密、管理员重置、管理员建用户。上限 72 字节对齐 BCrypt 实现边界（超长会静默截断，
 * 造成「设了什么密码」与「哈希了什么」不一致）；下限 8 字节防弱口令；按字节而非字符计量，
 * 多字节密码（如中文）不会变相降低门槛。不依赖前端校验——后端为唯一事实源。
 */
public final class PasswordPolicy {

    /** 下限（UTF-8 字节） */
    public static final int MIN_BYTES = 8;
    /** 上限（UTF-8 字节，BCrypt 72 字节边界） */
    public static final int MAX_BYTES = 72;

    private PasswordPolicy() {
    }

    /**
     * 校验明文密码（须已 base64 解码）。
     * @throws AuthException 400：PASSWORD_REQUIRED / PASSWORD_TOO_SHORT / PASSWORD_TOO_LONG
     */
    public static void validate(String password) {
        if (password == null || password.isBlank()) {
            throw AuthException.badRequest(ErrorCode.PASSWORD_REQUIRED);
        }
        int bytes = password.getBytes(StandardCharsets.UTF_8).length;
        if (bytes < MIN_BYTES) {
            throw AuthException.badRequest(ErrorCode.PASSWORD_TOO_SHORT, MIN_BYTES);
        }
        if (bytes > MAX_BYTES) {
            throw AuthException.badRequest(ErrorCode.PASSWORD_TOO_LONG);
        }
    }
}

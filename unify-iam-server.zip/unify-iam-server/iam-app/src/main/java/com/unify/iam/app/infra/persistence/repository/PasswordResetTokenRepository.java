package com.unify.iam.app.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.unify.iam.app.infra.persistence.mapper.PasswordResetTokenMapper;
import com.unify.iam.app.infra.persistence.po.PasswordResetTokenPO;
import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** 密码重置令牌仓储（同邮箱仅最新有效）。 */
@Repository
public class PasswordResetTokenRepository {

    private final PasswordResetTokenMapper mapper;

    public PasswordResetTokenRepository(PasswordResetTokenMapper mapper) {
        this.mapper = mapper;
    }

    public void insert(PasswordResetTokenPO po) {
        mapper.insert(po);
    }

    /** 按哈希查最新、未使用、未过期的重置令牌。 */
    public Optional<PasswordResetTokenPO> findByHashLatestActive(String hash) {
        return Optional.ofNullable(mapper.selectOne(new LambdaQueryWrapper<PasswordResetTokenPO>()
                        .eq(PasswordResetTokenPO::getTokenHash, hash)
                        .eq(PasswordResetTokenPO::getIsLatest, 1)
                        .isNull(PasswordResetTokenPO::getUsedAt)
                        .gt(PasswordResetTokenPO::getExpiresAt, LocalDateTime.now())));
    }

    /** 使该邮箱旧的重置令牌失效（is_latest=0）。 */
    public void invalidateByEmail(String email) {
        mapper.update(null, new LambdaUpdateWrapper<PasswordResetTokenPO>()
                .eq(PasswordResetTokenPO::getEmail, email)
                .eq(PasswordResetTokenPO::getIsLatest, 1)
                .set(PasswordResetTokenPO::getIsLatest, 0)
                .set(PasswordResetTokenPO::getInvalidatedAt, LocalDateTime.now()));
    }

    /** 标记已使用。 */
    public void markUsed(Long id) {
        mapper.update(null, new LambdaUpdateWrapper<PasswordResetTokenPO>()
                .eq(PasswordResetTokenPO::getId, id)
                .set(PasswordResetTokenPO::getUsedAt, LocalDateTime.now()));
    }
}

package com.unify.iam.common.util;

import java.util.UUID;

/** 业务主键生成：32 位无横线 UUID（与 DDL 中 {@code CHAR(32)} 业务键约定一致）。 */
public final class IdGenerator {

    private IdGenerator() {
    }

    /** 生成 32 位无横线 UUID 业务主键。 */
    public static String newBizId() {
        return UUID.randomUUID().toString().replace("-", "");
    }
}

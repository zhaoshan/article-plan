package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.authorization.app.model.AppCatalog;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.authorization.app.service.ApplicationTemplateService;
import com.unify.iam.app.security.RequirePermission;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * IAM 管理面：应用目录（docs/05 §7.3 建租户表单——app_codes 必选，前端只读勾选启用应用）。
 * 权限：iam:tenant:read（平台管理员）。
 */
@RestController
@RequestMapping("/api/v1/admin/applications")
public class AdminApplicationController {

    private final ApplicationTemplateService applicationTemplateService;

    public AdminApplicationController(ApplicationTemplateService applicationTemplateService) {
        this.applicationTemplateService = applicationTemplateService;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public Map<String, Object> list() {
        List<Map<String, Object>> applications = applicationTemplateService.listCatalog().stream()
                .map(this::toBrief).toList();
        return Map.of("applications", applications, "count", applications.size());
    }

    private Map<String, Object> toBrief(AppCatalog c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("app_code", c.appCode());
        m.put("app_name", c.appName());
        m.put("description", c.description());
        m.put("roles", c.roles().stream().map(this::roleBrief).toList());
        return m;
    }

    private Map<String, String> roleBrief(AppRoleTemplate t) {
        Map<String, String> r = new LinkedHashMap<>();
        r.put("role_code", t.roleCode());
        r.put("role_name", t.roleName());
        r.put("permission_count", String.valueOf(t.permissionCodes().size()));
        r.put("is_owner", t.isOwner() ? "1" : "0");
        return r;
    }
}

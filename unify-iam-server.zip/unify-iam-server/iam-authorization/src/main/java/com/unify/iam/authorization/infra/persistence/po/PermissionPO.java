package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_permission 权限字典表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_permission")
public class PermissionPO extends BaseEntity {

    /** 权限业务唯一标识 */
    private String permissionId;
    /** 权限编码（如 agent:publish） */
    private String permissionCode;
    /** 资源类型（如 AGENT/SESSION） */
    private String resourceType;
    /** 归属应用：业务应用 app_code；IAM 自身管理权限为 iam（docs/07/V8 权限隔离） */
    private String appCode;
    /** 是否可被 TENANT 作用域角色授予：1可 0仅平台 */
    private Integer tenantGrantable;
    /** 动作（如 READ/BUILD） */
    private String action;
    private String permissionName;
    private String permissionDescription;
    /** 是否内置权限 */
    private Integer isBuiltin;
    /** 权限状态：ACTIVE/DISABLED */
    private String permissionStatus;
}

# Authenticated session avatar contract plan

Date: 2026-10-26

Status: Complete.

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, plan, session, and validation artifacts under this repository's `.trellis/` directory.
- Do not access another Platform IAM project or alter frontend source.
- Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- The requested `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree, including hidden-path and Git-index searches. `trellis workflow` reports no active template. Follow the available `CLAUDE.md`, `.claude/rules/security.md`, and established local Trellis task-record convention; no undocumented confirmation gate can be inferred.

## Confirmed baseline

- `gateway_user.avatar_url VARCHAR(512) NULL` was created by the existing `V1__init_schema.sql` migration and is documented as a user-profile or external-IdP avatar address.
- MyBatis maps that column to the existing `UserPO.avatarUrl` property. No migration, database field, or synthetic URL is required.
- `TokenService.issueFor` constructs the shared `TokenUser` projection used by local login, OIDC JSON login, refresh reissuance, tenant switching, and dev-token issuance. It currently omits avatar data.
- `GET /api/v1/auth/me` already performs an authenticated self-only `UserRepository.findByUserId(claims.userId())` lookup, but its dedicated `AuthIdentityResponse` currently omits `avatarUrl`.
- Existing response naming is intentionally mixed by boundary: login/session `TokenUser` uses snake-case JSON (`user_id`, `user_name`), while the `/auth/me` profile projection uses camel-case JSON (`userId`, `userName`, `registrationSource`). The global Jackson configuration omits null fields.

## Intended contract

- `POST /api/v1/auth/token`, JSON-form OIDC login, `POST /api/v1/auth/refresh`, and `POST /api/v1/auth/switch-tenant` return `data.user.avatar_url` when `gateway_user.avatar_url` is non-null.
- `GET /api/v1/auth/me` returns `data.avatarUrl` when that same source is non-null.
- The frontend's application-level semantic is `avatarUrl`; callers must treat a missing/undefined field as no avatar and render their own uppercase-initial fallback.
- No avatar value is put into JWT claims. It remains a response-profile projection only, avoiding a profile URL becoming stale in an already-issued token and avoiding unrelated claim expansion.
- The common token construction reloads the authoritative user row each time a response is rebuilt, so refresh and tenant switch cannot drop a stored avatar URL.

## Implementation checklist

- [x] Read available project and security instructions; record the missing requested AGENTS/Trellis workflow files.
- [x] Locate the existing authoritative avatar field, persistence mapping, and API naming conventions.
- [x] Add the nullable avatar field to the login session and current-identity DTOs with their established JSON conventions.
- [x] Resolve the avatar from `gateway_user.avatar_url` inside the common token-response assembly path.
- [x] Map the same field in the authenticated self-only `/auth/me` projection.
- [x] Add focused positive/absent and no-sensitive-field-leakage tests.
- [x] Run focused validation and record results.

## Out of scope

- Avatar upload, URL validation/download/proxying, external IdP picture-claim synchronization, or new admin profile mutation APIs.
- Any schema migration or inferred avatar URL.
- Changing JWT claims, user-directory/admin-list projections, or frontend rendering code.

## Validation result

The initial sandboxed test process compiled the changed production and test sources successfully, but JDK 26 blocked Mockito's Byte Buddy process attachment. The same focused commands passed with the required JVM attachment capability:

```text
mvn -pl iam-app -am test -Dtest='AuthControllerTest,TokenServiceTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 15 passed, 0 failures, 0 errors

mvn -pl iam-app -am test -Dtest='AvatarSessionContractIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 1 passed, 0 failures, 0 errors
```

The integration test uses a fresh Testcontainers MySQL schema, starts with a null `avatar_url`, writes a stored avatar URL, then proves that local login, refresh, `/auth/me`, and tenant switching all expose the correct boundary-specific JSON field without leaking `password_hash` or `passwordHash`.

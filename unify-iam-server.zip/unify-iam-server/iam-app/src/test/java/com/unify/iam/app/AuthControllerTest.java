package com.unify.iam.app;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.api.dto.auth.TokenUser;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.AuthController;
import com.unify.iam.app.app.service.DevTokenService;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(AuthController.class)
@Import(GlobalExceptionHandler.class)
class AuthControllerTest {

    private static String b64(String raw) {
        return com.unify.iam.common.util.PasswordCodecs.encodeBase64(raw);
    }

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private TokenService tokenService;
    @MockitoBean
    private DevTokenService devTokenService;
    @MockitoBean
    private JwtSigner jwtSigner;
    @MockitoBean
    private com.unify.iam.identity.infra.persistence.repository.UserRepository userRepository;
    @MockitoBean
    private com.unify.iam.identity.infra.persistence.repository.IdpConfigRepository idpConfigRepository;
    @MockitoBean
    private com.unify.iam.tenant.infra.persistence.repository.TenantRepository tenantRepository;
    @MockitoBean
    private com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository tenantApplicationRepository;
    @MockitoBean
    private IamProperties props;

    @MockitoBean
    private com.unify.iam.app.security.LoginRateLimiter loginRateLimiter;

    @org.junit.jupiter.api.BeforeEach
    void stubRateLimitProps() {
        // clientIp() 读 props.getLoginRateLimit()——mock 默认返 null 会 NPE，补默认实例
        org.mockito.Mockito.when(props.getLoginRateLimit())
                .thenReturn(new IamProperties.LoginRateLimit());
    }

    private static final String LOGIN_BODY = """
            {"username":"operator","password":"%s"}
            """.formatted(b64("op123"));

    private LoginResponse response() {
        return LoginResponse.of("jwt-token", "bearer", 7200L,
                new TokenUser("u-1001", "operator", "https://cdn.example.test/avatar.png",
                        List.of("AgentOperator"), List.of("agent:read")));
    }

    @Test
    void tokenSuccessReturns200WithContractShape() throws Exception {
        when(tokenService.issue(any())).thenReturn(response());

        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(LOGIN_BODY))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.access_token").value("jwt-token"))
                .andExpect(jsonPath("$.data.token_type").value("bearer"))
                .andExpect(jsonPath("$.data.expires_in").value(7200))
                .andExpect(jsonPath("$.data.user.user_id").value("u-1001"))
                .andExpect(jsonPath("$.data.user.user_name").value("operator"))
                .andExpect(jsonPath("$.data.user.avatar_url").value("https://cdn.example.test/avatar.png"))
                .andExpect(jsonPath("$.data.user.password_hash").doesNotExist())
                .andExpect(jsonPath("$.data.user.roles[0]").value("AgentOperator"));
    }

    @Test
    void tokenBadPasswordReturns401WithDetail() throws Exception {
        when(tokenService.issue(any())).thenThrow(AuthException.unauthorized("Incorrect username or password"));

        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(LOGIN_BODY))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Incorrect username or password"));
    }

    @Test
    void tokenBlankParamsReturns400WithDetail() throws Exception {
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(containsString("is required")));
    }

    @Test
    void devTokenUnknownUserReturns404() throws Exception {
        when(devTokenService.issueDev(any())).thenThrow(AuthException.notFound("User not found"));

        mockMvc.perform(post("/api/v1/auth/dev-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"user_id\":\"u-9999\"}"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("User not found"));
    }

    @Test
    void devTokenDisabledReturns403() throws Exception {
        when(devTokenService.issueDev(any())).thenThrow(AuthException.forbidden("dev-token 已禁用"));

        mockMvc.perform(post("/api/v1/auth/dev-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"user_id\":\"u-1001\"}"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("dev-token 已禁用"));
    }

    @Test
    void devTokenMissingUserRefReturns400() throws Exception {
        when(devTokenService.issueDev(any())).thenThrow(AuthException.badRequest("userId 与 username 至少提供一个"));

        mockMvc.perform(post("/api/v1/auth/dev-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("userId 与 username 至少提供一个"));
    }

    @Test
    void meWithValidTokenReturnsContext() throws Exception {
        JwtClaims claims = new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1001",
                "tenant-org-a", "ms-2001", List.of("AgentOperator"),
                List.of("agent:read", "agent:publish"), Map.of(), 9999999999L, 1000000000L, "jti", 0L);
        UserPO user = new UserPO();
        user.setUsername("operator");
        user.setAvatarUrl("https://cdn.example.test/avatar.png");
        user.setPrimaryEmail("operator@org-a.com");
        user.setRegistrationSource("SELF_SERVICE");
        user.setPasswordHash("never-expose-this");
        when(jwtSigner.verify("jwt-token")).thenReturn(claims);
        when(userRepository.findByUserId("u-1001")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userId").value("u-1001"))
                .andExpect(jsonPath("$.data.userName").value("operator"))
                .andExpect(jsonPath("$.data.avatarUrl").value("https://cdn.example.test/avatar.png"))
                .andExpect(jsonPath("$.data.email").value("operator@org-a.com"))
                .andExpect(jsonPath("$.data.registrationSource").value("SELF_SERVICE"))
                .andExpect(jsonPath("$.data.lastSignInAt").doesNotExist())
                .andExpect(jsonPath("$.data.passwordHash").doesNotExist())
                .andExpect(jsonPath("$.data.password_hash").doesNotExist())
                .andExpect(jsonPath("$.data.tenantId").value("tenant-org-a"))
                .andExpect(jsonPath("$.data.membershipId").value("ms-2001"))
                .andExpect(jsonPath("$.data.roles[0]").value("AgentOperator"))
                .andExpect(jsonPath("$.data.permissions").isArray())
                .andExpect(jsonPath("$.data.attrs").isMap());
        verify(userRepository).findByUserId("u-1001");
    }

    @Test
    void meOmitsNullableEmailWithoutChangingClaimsContext() throws Exception {
        JwtClaims claims = new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1001",
                "tenant-org-a", "ms-2001", List.of("AgentOperator"),
                List.of("agent:read"), Map.of(), 9999999999L, 1000000000L, "jti", 0L);
        UserPO user = new UserPO();
        user.setUsername("operator");
        user.setRegistrationSource("ADMIN");
        when(jwtSigner.verify("jwt-token")).thenReturn(claims);
        when(userRepository.findByUserId("u-1001")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer jwt-token"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userId").value("u-1001"))
                .andExpect(jsonPath("$.data.userName").value("operator"))
                .andExpect(jsonPath("$.data.registrationSource").value("ADMIN"))
                .andExpect(jsonPath("$.data.avatarUrl").doesNotExist())
                .andExpect(jsonPath("$.data.email").doesNotExist())
                .andExpect(jsonPath("$.data.tenantId").value("tenant-org-a"));
    }

    @Test
    void meWithoutTokenReturns401() throws Exception {
        mockMvc.perform(get("/api/v1/auth/me"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value(containsString("Missing token")));
    }


    @Test
    void returnOriginsReturnsWhitelist() throws Exception {
        IamProperties.Oidc oidc = new IamProperties.Oidc();
        oidc.setAllowedReturnOrigins(List.of("http://localhost:5173", "http://localhost:5175"));
        when(props.getOidc()).thenReturn(oidc);
        mockMvc.perform(get("/api/v1/auth/return-origins"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.origins[0]").value("http://localhost:5173"))
                .andExpect(jsonPath("$.data.origins[1]").value("http://localhost:5175"));
    }
}

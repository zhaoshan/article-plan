-- --------------------------------------------
-- unify-iam-server IAM 自身应用注册 + 平台级角色模板（V9，整合 V10）
-- 目标（2026-10-14）：可建「只适配 IAM 应用本身」的租户——建租户时选 app_code='iam'，
-- TenantAppProvisionService 按模板给 owner 授全局 PlatformAdmin（scope=PLATFORM，V5 seed r-2001），
-- 而非在租户内 deep-copy 业务角色。
--
-- 作用域说明（整合后，V9 只保留正确意图）：
--   - iam 应用只有【平台级】PlatformAdmin 模板（scope_type=PLATFORM）：建 IAM 自身租户时
--     把全局 PlatformAdmin 授给 owner（平台管理员不管理业务租户角色）。
--   - 不再有租户级 IamTenantAdmin/IamTenantViewer（此前 V9 误加，V11 前由手动 SQL/后续迁移清理）。
--   - iam:user/tenant/audit/idp 为平台专属（tenant_grantable=0，V8 防提权），走平台角色。
--
-- 本迁移相对旧版变化：
--   ① 删除了旧 V9 的 tpl-2004（IamTenantAdmin）/ tpl-2005（IamTenantViewer）两个租户级模板；
--   ② 合并旧 V10 的 scope_type 列 + tpl-2006（PlatformAdmin，PLATFORM）。
-- 已应用旧 V9/V10 的库：执行 flyway repair 并运行 docs/user-manual 附录的清理 SQL 即可（见迁移尾部说明）。
-- --------------------------------------------

SET NAMES utf8mb4;

-- 1. iam_application_role_template 加 scope_type（TENANT=租户内 deep-copy；PLATFORM=平台级复用/建全局角色）
ALTER TABLE `iam_application_role_template`
  ADD COLUMN `scope_type` VARCHAR(16) NOT NULL DEFAULT 'TENANT'
  COMMENT '角色作用域：TENANT=租户内 deep-copy（建租户按租户复制角色+权限）；PLATFORM=平台级（复用/建全局角色，建租户授 owner）'
  AFTER `app_code`;

-- [seed 已剥离] 原 seed 数据移至 db/seed / db/seed-dev（R__ 幂等）；本迁移只留 schema。

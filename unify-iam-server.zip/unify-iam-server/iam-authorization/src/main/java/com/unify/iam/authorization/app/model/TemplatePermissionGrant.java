package com.unify.iam.authorization.app.model;

/**
 * 应用角色模板新增权限点命令（运维接口入参的授权域形态，避免服务层参数膨胀）。
 *
 * @param createPermission 权限点不在字典时是否自动登记（需 name/resourceType/action）
 * @param permissionName   createPermission=true 时必填
 * @param resourceType     createPermission=true 时必填
 * @param action           createPermission=true 时必填
 * @param category         可选：一级功能模块分组
 */
public record TemplatePermissionGrant(
        String appCode,
        String roleCode,
        String permissionCode,
        String operator,
        boolean createPermission,
        String permissionName,
        String resourceType,
        String action,
        String category) {
}

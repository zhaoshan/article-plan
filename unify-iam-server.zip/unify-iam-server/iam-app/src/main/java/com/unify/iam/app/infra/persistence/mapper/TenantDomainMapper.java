package com.unify.iam.app.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.app.infra.persistence.po.TenantDomainPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_tenant_domain Mapper。 */
@Mapper
public interface TenantDomainMapper extends BaseMapper<TenantDomainPO> {
}

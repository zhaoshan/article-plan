"""遍历规则配置模型"""

from pydantic import BaseModel, Field, ConfigDict


class DomainTraversalConfig(BaseModel):
    """单个域名的遍历配置"""

    model_config = ConfigDict(extra="forbid")

    need_outer_site: bool = Field(
        default=True,
        description="是否需要保留外站链接（子链接域名与入口域名不一致时）",
    )
    outer_site_whitelist: list[str] = Field(
        default_factory=list,
        description="外站域名白名单，只保留白名单内的外站域名子链接",
    )
    drill_down_levels: int = Field(
        default=0,
        ge=0,
        description="需要爬取的层数，0 表示不限制（广度优先遍历获取所有）",
    )
    not_found_texts: list[str] = Field(
        default_factory=list,
        description="页面未找到判定文本列表，页面 body.innerText 包含任一文本时在树结构中标记为 not_found",
    )
    page_navigation_timeout_ms: int = Field(
        default=60000,
        ge=1000,
        le=300000,
        description="page.goto 导航超时时间（毫秒）",
    )
    page_load_state_timeout_ms: int = Field(
        default=30000,
        ge=1000,
        le=300000,
        description="wait_for_load_state 超时时间（毫秒）",
    )
    page_load_wait_ms: int = Field(
        default=2000,
        ge=0,
        le=60000,
        description="页面加载完成后额外等待时间（毫秒）",
    )
    page_retry_count: int = Field(
        default=2,
        ge=0,
        le=10,
        description="page.goto / wait_for_load_state 失败后的重试次数",
    )
    page_retry_delay_ms: int = Field(
        default=1000,
        ge=0,
        le=60000,
        description="重试间隔（毫秒）",
    )
    max_partial_failure_rate: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="实时局部失败率上限，超过后中止 tree 阶段",
    )
    min_pages_for_failure_check: int = Field(
        default=10,
        ge=1,
        le=10000,
        description="触发实时失败率检查所需的最小已尝试页面数",
    )
    min_tree_pages_threshold: int = Field(
        default=50,
        ge=0,
        le=100000,
        description="Tree 阶段成功爬取的页面数下限",
    )
    min_tree_success_rate: float = Field(
        default=0.8,
        ge=0.0,
        le=1.0,
        description="Tree 阶段成功率下限",
    )

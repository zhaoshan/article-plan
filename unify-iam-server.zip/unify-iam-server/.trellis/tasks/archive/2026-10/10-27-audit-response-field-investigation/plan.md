# 审计列表字段来源调查

日期：2026-10-27。范围：当前 platform-iam-service 主工作区，仅后端只读调查。

- [x] 尝试读取 AGENTS.md 和 .trellis/workflow.md，确认两者不存在；读取 CLAUDE.md、.claude/rules/security.md、.claude/rules/migrations.md 和本项目既有 Trellis 记录。
- [x] 追踪五个字段的采集、数据库、查询、Map 和响应序列化路径。
- [x] 核对实际 before/after 写点、请求元信息处理、权限、日志关联和 tenant_name 富化。
- [x] 检查版本历史及现有测试源码作为补充证据，区分设计与已实现行为。
- [x] 形成 investigation.md，比较三个裁剪/删除方案。

确认边界：用户只授权调查，尚未决定删除；任何字段裁剪、详情端点新增、日志/IP 修复、采集策略或 schema 修改均不在本次授权内。本次不实施，不启动/重启服务、不运行测试、不登录或查询运行中的数据库、不更改 Git 分支/worktree、不提交/合并/推送。前端列由主任务处理，本任务仅提供已有 tenant_name 契约证据，不访问其他项目。

指令缺失：本工作区没有 AGENTS.md 和 .trellis/workflow.md，不能声称已执行不存在的 Trellis 脚本或确认门禁；使用实际存在的仓库规则和 .trellis/tasks 记录格式，所有新增记录留在本项目 .trellis 下。

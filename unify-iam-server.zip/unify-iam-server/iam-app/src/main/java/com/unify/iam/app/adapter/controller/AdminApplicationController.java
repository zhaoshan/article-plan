package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.AddTemplatePermissionRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.TemplatePermissionAdminService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.authorization.app.model.AppCatalog;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.authorization.app.service.ApplicationTemplateService;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * IAM 管理面：应用目录（docs/05 §7.3 建租户表单——app_codes 必选，前端只读勾选启用应用）。
 * 权限：iam:tenant:read（平台管理员）。
 */
@RestController
@RequestMapping("/api/v1/admin/applications")
public class AdminApplicationController {

    private final ApplicationTemplateService applicationTemplateService;
    private final TemplatePermissionAdminService templatePermissionAdminService;
    private final AuditService auditService;

    public AdminApplicationController(ApplicationTemplateService applicationTemplateService,
                                      TemplatePermissionAdminService templatePermissionAdminService,
                                      AuditService auditService) {
        this.applicationTemplateService = applicationTemplateService;
        this.templatePermissionAdminService = templatePermissionAdminService;
        this.auditService = auditService;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public Map<String, Object> list() {
        List<Map<String, Object>> applications = applicationTemplateService.listCatalog().stream()
                .map(this::toBrief).toList();
        return Map.of("applications", applications, "count", applications.size());
    }

    /**
     * 应用角色模板新增权限点（运维接口，curl 可直达）：模板为权限集唯一事实源。
     * 默认只改模板；sync_tenants=true 时同步补齐存量租户 deep-copy 角色（补绑 + 持有者
     * token_version bump，幂等）；create_permission=true 时权限点不在字典则先自动登记
     * （需 permission_name/resource_type/action）再挂载，默认对字典外权限点 400。
     * 已含该权限点时幂等返回 added=false。API 口径对齐
     * scripts/grant_template_permission_to_tenants.sql。
     * 权限：iam:tenant:write（租户编辑，即平台管理员）。
     */
    @PostMapping("/role-templates/permissions")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, Object> addTemplatePermission(@RequestBody @Valid AddTemplatePermissionRequest request) {
        TemplatePermissionAdminService.TemplatePermissionChange change = templatePermissionAdminService.add(request);
        var result = change.template();
        auditService.audit().event("ADMIN_ADD_TEMPLATE_PERMISSION")
                .actor(CurrentAuth.claims().userId())
                .target("APP_ROLE_TEMPLATE", result.appCode() + ":" + result.roleCode())
                .result("SUCCESS")
                .write(Map.ofEntries(
                        Map.entry("app_code", result.appCode()),
                        Map.entry("role_code", result.roleCode()),
                        Map.entry("permission_code", result.permissionCode()),
                        Map.entry("added", result.added()),
                        Map.entry("permission_count", result.permissionCount()),
                        Map.entry("operator", request.operator()),
                        Map.entry("sync_tenants", request.syncTenants()),
                        Map.entry("synced_role_count", change.syncedRoles()),
                        Map.entry("bumped_membership_count", change.bumpedMembers()),
                        Map.entry("create_permission", request.createPermission()),
                        Map.entry("created_permission", result.permissionCreated())));
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("app_code", result.appCode());
        body.put("role_code", result.roleCode());
        body.put("permission_code", result.permissionCode());
        body.put("added", result.added());
        body.put("permission_count", result.permissionCount());
        body.put("created_permission", result.permissionCreated());
        body.put("sync_tenants", request.syncTenants());
        body.put("synced_role_count", change.syncedRoles());
        body.put("bumped_membership_count", change.bumpedMembers());
        return body;
    }

    private Map<String, Object> toBrief(AppCatalog c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("app_code", c.appCode());
        m.put("app_name", c.appName());
        m.put("description", c.description());
        m.put("roles", c.roles().stream().map(this::roleBrief).toList());
        return m;
    }

    private Map<String, String> roleBrief(AppRoleTemplate t) {
        Map<String, String> r = new LinkedHashMap<>();
        r.put("role_code", t.roleCode());
        r.put("role_name", t.roleName());
        r.put("permission_count", String.valueOf(t.permissionCodes().size()));
        r.put("is_owner", t.isOwner() ? "1" : "0");
        return r;
    }
}

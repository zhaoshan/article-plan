-- ============================================================
-- 存量修复：指定租户补灌 iMorph-Owner / iMorph-Admin 租户角色 + 补绑指定 membership
-- 背景：2026-11-09 租户 a1b2c3d4... 初始化漏灌 imorph 模板角色，导致成员缺 Owner/Admin 角色
-- 口径：与 TenantAppProvisionService.seedTemplates 一致——模板表 iam_application_role_template
--       为权限集唯一事实源（Owner 含 126+6 iam:*，Admin 含 iam:member/role/apps:read 等），
--       权限集自动对齐最新模板，不手工罗列权限码
-- 幂等：全程 INSERT IGNORE / 先 UPDATE 复活（唯一键判重），可重复执行
-- 用法：改下方两个变量后【整段顺序执行】——变量在赋值时定 collation，单独重跑某段会因
--       变量仍是旧 collation 再报 1267；其他租户同漏灌问题换 @tenant_id 重跑即可
-- 注意：① JWT claims 为签发时快照，手动 SQL 不 bump token_version——目标成员需重新登录
--          （或 switch-tenant/refresh 重签）后新角色才进 token
--       ② iMorph-Owner 是 is_owner=1 模板角色（单持有者约束在应用层）——补绑前确认该成员
--          是该租户合法 Owner，本脚本不校验持有者唯一性
-- ============================================================

SET NAMES utf8mb4;
-- 变量带连接默认 collation（0900_ai_ci）且为「隐式」优先级，与表列（unicode_ci）比较会 1267——
-- 赋值时显式归一到表侧 collation，全文比较即兼容（若你的库表同为 0900_ai_ci，此 COLLATE 也无害）
SET @tenant_id     := 'a1b2c3d4e5f67890abcdef1234567111'   COLLATE utf8mb4_unicode_ci;
SET @membership_id := 'd0aa749d9c1f48669c862f416906fa97'   COLLATE utf8mb4_unicode_ci;

-- 0. 前置检查（先跑这三条确认输入没问题；membership 必须属于该租户且 ACTIVE）
SELECT tenant_id, tenant_code, tenant_name, tenant_status FROM gateway_tenant
 WHERE tenant_id = @tenant_id;
SELECT membership_id, user_id, tenant_id, membership_status FROM gateway_membership
 WHERE membership_id = @membership_id;  -- 期望 tenant_id = @tenant_id 且 status='ACTIVE'
SELECT role_code FROM gateway_role
 WHERE scope_type = 'TENANT' AND scope_id = @tenant_id AND delete_flag = 0;  -- 期望缺 iMorph-Owner/iMorph-Admin

-- 1. 登记租户↔imorph 应用（若 iam_tenant_application 也漏登记；已有软删行则复活）
UPDATE iam_tenant_application SET delete_flag = 0, update_by = 'system'
 WHERE tenant_id = @tenant_id AND app_code = 'imorph';
INSERT IGNORE INTO iam_tenant_application
  (tenant_app_id, tenant_id, app_code, delete_flag, create_by, update_by)
SELECT REPLACE(UUID(), '-', ''), @tenant_id, 'imorph', 0, 'system', 'system';

-- 2. 建两个租户角色（按模板；唯一键 scope_type+scope_id+role_code 判重，已存在自动跳过）
INSERT IGNORE INTO gateway_role
  (role_id, scope_type, scope_id, role_code, role_name, role_description, is_builtin, role_status, delete_flag, create_by, update_by)
SELECT REPLACE(UUID(), '-', ''), 'TENANT', @tenant_id, t.role_code, t.role_name, t.role_description, 1, 'ACTIVE', 0, 'system', 'system'
  FROM iam_application_role_template t
 WHERE t.app_code = 'imorph' AND t.delete_flag = 0
   AND t.role_code IN ('iMorph-Owner', 'iMorph-Admin');

-- 3. 按模板 permission_codes_json 展开绑权限（JSON_TABLE；唯一键 role_id+permission_id 判重）
INSERT IGNORE INTO gateway_role_permission
  (role_permission_id, role_id, permission_id, delete_flag, create_by, update_by)
SELECT MD5(CONCAT(r.role_id, ':', p.permission_id)), r.role_id, p.permission_id, 0, 'system', 'system'
  FROM gateway_role r
  JOIN iam_application_role_template t
    -- COLLATE 双保险：防运行库该表 collation 与仓库 DDL（unicode_ci）漂移
    ON t.role_code = r.role_code COLLATE utf8mb4_unicode_ci AND t.app_code = 'imorph' AND t.delete_flag = 0
  JOIN JSON_TABLE(t.permission_codes_json, '$[*]' COLUMNS (perm_code VARCHAR(128) PATH '$')) jt
  JOIN gateway_permission p
    -- COLLATE：JSON_TABLE 导出列继承连接默认 collation（如 utf8mb4_0900_ai_ci），与表的
    -- utf8mb4_unicode_ci 比较会报 1267；显式归一到表侧 collation
    ON p.permission_code = jt.perm_code COLLATE utf8mb4_unicode_ci AND p.delete_flag = 0
 WHERE r.scope_type = 'TENANT' AND r.scope_id = @tenant_id AND r.delete_flag = 0
   AND r.role_code IN ('iMorph-Owner', 'iMorph-Admin');

-- 4. 补绑 membership 的 DIRECT 角色（唯一键 membership_id+role_id 判重）
INSERT IGNORE INTO gateway_membership_role
  (membership_role_id, membership_id, role_id, grant_source, delete_flag, create_by, update_by)
SELECT REPLACE(UUID(), '-', ''), @membership_id, r.role_id, 'DIRECT', 0, 'system', 'system'
  FROM gateway_role r
 WHERE r.scope_type = 'TENANT' AND r.scope_id = @tenant_id AND r.delete_flag = 0
   AND r.role_code IN ('iMorph-Owner', 'iMorph-Admin');

-- 5. 结果核验
SELECT r.role_code, COUNT(rp.permission_id) AS perm_count
  FROM gateway_role r LEFT JOIN gateway_role_permission rp
    ON rp.role_id = r.role_id AND rp.delete_flag = 0
 WHERE r.scope_type = 'TENANT' AND r.scope_id = @tenant_id AND r.delete_flag = 0
   AND r.role_code IN ('iMorph-Owner', 'iMorph-Admin')
 GROUP BY r.role_code;
-- 期望：两行；perm_count 以模板展开为准（Owner=126+6=132，Admin=126+若干 iam:*，与模板 JSON 长度一致）

SELECT mr.membership_id, r.role_code
  FROM gateway_membership_role mr
  JOIN gateway_role r ON r.role_id = mr.role_id
 WHERE mr.membership_id = @membership_id AND mr.delete_flag = 0
   AND r.role_code IN ('iMorph-Owner', 'iMorph-Admin');
-- 期望：两行（Owner + Admin）

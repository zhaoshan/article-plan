# IAM 安全问题整改台账

- **问题来源**：`docs/security/IAM统一安全评估报告.md`（扫描 + 动态验证产出；逐项细节以该报告为准，本台账只跟踪进展）
- **最近更新**：2026-11-11（P1-05/P1-06 落地；P1-15 同日，P1-02/03/D01 于 2026-11-10）
- **状态图例**：✅ 已整改 · 🔶 部分缓解/待核查 · ⬜ 待办 · ⏸️ 待评审（设计/产品决策）

## 总览

| 编号 | 优先级 | 问题 | 状态 | 整改方式 / 计划 | 落地 |
|---|---|---|---|---|---|
| P0-07 | P0 | 默认启用开发 Token + 默认基础设施凭据 | ✅ | devTokenEnabled 默认 false + 启动 WARN；yml 可预测凭据默认值全部移除，强制环境注入 | 2026-11-09 `e184e50` |
| P0-08 | P0 | 忘记密码接口直接返回重置 Token | ✅ | 统一 `{"status":"SENT"}` 防枚举；token 仅日志模式返，生产只走邮件；60s 冷却 | 2026-11-09 `e184e50` |
| P1-16 | P1 | 管理面依赖 JWT 旧权限快照 | ✅ | 方案 c 消费侧闭环：管理面拦截器比对 token `ver` vs 库内版本，落后即 401 `IAM-AUTH-015 TOKEN_STALE` | 2026-11-09 `c5e71bc`/`6a2d577` |
| P1-01 | P1 | 密码传输与日志保护核实 | ✅ | 已确认线上全链路 HTTPS（2026-11-09 部署面核实）；应用侧 base64 为审计形式合同 + 日志侧凭证端点永不声明 `@LogPayload`、`LogMasks` 无条件打码。风险关闭 | 2026-11-09 确认 |
| P1-02 | P1 | 登录无暴力破解防护 | ✅ | 账号/IP 双维度失败计数 + 冷却锁定（429 `IAM-AUTH-020`）；不存在账号同样计数；成功清零；存储双实现（默认进程内，开 `iam.redis.enabled` 走共享计数） | 2026-11-10 |
| P1-03 | P1 | 注册/重置/改密缺统一密码策略 | ✅ | `PasswordPolicy`（iam-common）：UTF-8 字节 8–72 统一校验，五条设密链路全覆盖（注册/忘记密码重置/自助改密/管理员重置/管理员建用户） | 2026-11-10 |
| P1-15 | P1 | 自助改密未撤销其他会话 | ✅ | 改密 = 撤全部旧 refresh + 全部成员 bump（旧 access 立即 stale）+ 重签新会话随响应返回 + 审计事件 | 2026-11-11 `42aaf42` |
| P1-05 | P1 | JWT 验证缺 iss/aud 等校验 | ✅ | `JwtSigner.verify` 补 claims 校验：iss 逐字相等、aud 非空、nbf/iat 未来时间拒绝（60s 容忍）、kid 格式白名单；签发侧本就以这些值签发，零兼容期 | 2026-11-11 |
| P1-D01 | P1 | refresh 并发轮换可多次成功 | ✅ | 原子条件消费：单条 UPDATE 抢占（行数=1 才签发新值），「先查后改」竞态关闭 | 2026-11-10 |
| P1-04 | P1 | OIDC 回调 URL 传 token | ⏸️ | 现状为 SPA 标准时序（docs/08）；改一次性授权码交换需前后端同步改造，排期评审 | — |
| P1-06 | P1 | IdP client_secret 明文落库 | ✅ | `IdpSecretCipher` 密文落库（复用 jasypt 主密钥）；查询本就只回 `has_secret`；存量明文读取宽容、保存即迁移 | 2026-11-11 |
| P1-14 | P1 | 访问日志记录路径中的邀请 Token | ⬜ | 计划：访问日志对路径参数（token/邀请码）打码或改记路由模板 | — |
| P2-05 | P2 | 匿名 SSO 租户目录披露组织信息 | ⏸️ | 产品决策：是否匿名返回 / 字段最小化（现状匿名返回名称+编码+数量） | — |
| P2-09 | P2 | OIDC 临时状态存内存、无限额 | ⬜ | 计划：带 TTL+容量上限的存储（Redis）+ 创建限流 | — |
| P2-10 | P2 | 角色权限读取缺租户归属校验 | ⬜ | 计划：`/admin/roles/{id}/permissions` 查询前 `assertRoleScope` + 跨租户拒绝测试 | — |
| P2-07 | P2 | 登录失败日志记录完整用户名 | ⬜ | 计划：失败日志用户名/邮箱掩码（现状 `login failed \| user={}` 裸打） | — |
| P2-11 | P2 | 脱敏日志 JSON 解析失败回退原文 | ⬜ | 计划：`AccessLogFilter` 解析失败只记固定错误标记+长度，不回退原文 | — |

## 已整改明细

### P0-07 开发 Token 默认开启 + 默认基础设施凭据（2026-11-09，`e184e50`）

1. `IamProperties.devTokenEnabled` 代码默认 `true → false`；生产未显式开启即 403 `IAM-AUTH-007`
2. `DevTokenService.warnIfEnabled()`：开启时启动日志醒目 WARN（运维误配置兜底）
3. `application.yml` 可预测默认值全部移除：数据源账号、`iam.versions.service-token`、jasypt 密钥、SMTP——空默认强制环境注入，缺即拒启
4. 本地/测试通过 `IamIntegrationTestBase` 显式开启/注入保持可用
5. **风险接受项**：开关无法阻止「生产有意配 true」（纯配置拦不住有意配置）——需 profile 硬闸或构建期切除才能根治，当前以默认关 + WARN + 403 + 流程评审兜底（2026-11-09 决策：维持现状）

### P0-08 忘记密码接口直接返回重置 Token（2026-11-09，`e184e50`）

1. forgot 统一 `{"status":"SENT"}`，已知/未知邮箱同构（原 detail 形态差异 = 枚举辅助，已消除）
2. token 仅在 SMTP 未配置（日志模式）时附加返回；生产配置 SMTP 后 token 只经邮件交付（`EmailTool.isMailConfigured()` 判别）
3. 同邮箱 60s 冷却（重复提交 400 `IAM-AUTH-011`）
4. 保持不变（报告验收要点）：旧 token 即时失效、重置后撤销全部 refresh、单次使用 + 15min 过期
5. 回归测试：`PasswordResetMailIntegrationTest` +3 用例

### P1-16 管理面依赖 JWT 旧权限快照（2026-11-09，`c5e71bc`/`6a2d577`）

- 方案 c 消费侧闭环：`ManagementAuthorizationInterceptor` 对 `/api/v1/admin/**` 比对 token `ver` vs 库内 `token_version`，落后即 401 `IAM-AUTH-015 TOKEN_STALE`；前端「401→静默 refresh→原地重试」零改动接管
- 与 P1-05 是不同根因：本项管「权限变更即时生效」，P1-05 管「JWT 基本 claims 校验」，分别跟踪

### P1-02 登录暴力破解防护（2026-11-10）

- 账号维度：连续失败 5 次（默认）锁 10 分钟；IP 维度：10 分钟窗内 20 次失败锁 15 分钟——锁定均返回 429 `IAM-AUTH-020`，文案统一不防枚举泄露
- 挂在登录统一 401 出口计数：**用户不存在的尝试同样计数**（否则造随机账号名绕过）；base64 解码失败也计；成功登录清零两维
- 存储双实现按 `iam.redis.enabled` 切换（默认 false = 进程内 `InMemoryLoginRateLimiter`；true = `RedisLoginRateLimiter` Lettuce 共享计数，key 结构 `{env}:iam:login:rl:{acct|ip}:{key}[:fail]` 防跨环境/跨应用冲突）
- fail-safe：Redis 故障自动降级放行 + WARN，不阻断登录主链路
- 配置 `iam.login.rate-limit.*`（阈值/窗口）+ `iam.redis.*`（standalone/cluster、池、ssl；密码推荐 ENC()）；`trust-xff` 默认关（防伪造）
- 回归测试：`LoginRateLimitIntegrationTest` 4 用例（进程内路径）+ `RedisLoginRateLimiterTest` 5 单测（锁判定/阈值置锁/降级/清键）
- **部署项**：多副本部署时设 `iam.redis.enabled=true` 指向共享 Redis 即全局计数；单实例保持默认进程内

### P1-03 统一密码策略（2026-11-10）

- `PasswordPolicy.validate()`（iam-common，解码后、BCrypt 哈希前调用）：UTF-8 字节 8–72；上限对齐 BCrypt 72 字节边界（防静默截断不一致），下限 8 字节防弱口令，按字节计量（多字节密码不变相降门槛），后端为唯一事实源不依赖前端
- 覆盖五条链路：注册 / 忘记密码重置 / 自助改密 / 管理员重置 / 管理员建用户（管理员重置原私有 72 字节校验收敛到统一策略）
- 错误码细分：`IAM-VALID-013 PASSWORD_TOO_SHORT`（复用既有 011 过长/010 必填）
- 回归测试：`PasswordPolicyIntegrationTest` 5 用例（下限/上限/边界 8 字节放行/忘记密码重置/改密/管理端两链路）

### P1-D01 refresh 并发轮换原子化（2026-11-10）

- 原实现「先查 active → 标记作废 → 签发新」存在竞态：同一 refresh 并发多请求可同时通过校验多次成功（报告 D4 实证 3/3 均 200）
- 修复：`RefreshTokenRepository.revokeIfActive(hash)` 单条条件 UPDATE（`revoked_at IS NULL AND 未过期`）作消费闸，DB 行锁保证全局仅一个消费者成功（行数=0 → 401、不发新）；校验在前、消费在后——校验失败不烧毁 token（停用租户恢复后 refresh 仍可用），多次成功防护由条件 UPDATE 单独保证
- 回归测试：`RefreshRotationConcurrencyIntegrationTest`——4 线程同步轮换同一 token，断言恰好 1 成功 3 个 401，旧 token 再轮换 401、胜出新 token 单次可用

### P1-15 自助改密撤销会话（2026-11-11，`42aaf42`）

- 自助改密语义对齐忘记密码/管理员重置：撤该用户全部 refresh + 全部 ACTIVE 成员 bump `token_version`（旧 access 按方案 c 立即 stale）——密码泄露场景改密即踢攻击者
- 响应纯增量携带重签新会话（`status=CHANGED` + `access_token/refresh_token/user`）：前端可后续独立消费（替换 store 则本人无感），不消费则下次刷新回登录页——与产品确认「账号单人使用，重登可接受」
- 审计补齐：`USER_CHANGE_PASSWORD`（自助改密）+ `USER_RESET_PASSWORD`（忘记密码重置，此前零审计）；metadata 只记事实标记
- 回归测试：`ChangePasswordRevocationIntegrationTest`——旧 refresh 401 / 旧 access TOKEN_STALE / 新会话可用 / 两审计事件落库

### P1-05 JWT claims 校验（2026-11-11）

- `JwtSigner.verify`（IAM 自身 Bearer 验证）补 claims 校验：iss 与 `iam.jwt.issuer` 逐字相等（IAM-AUTH-008）、aud 存在且非空（IAM-AUTH-006，IAM 自身非 audience，只防畸形 token；业务资源服务器仍按自身 app_code ∈ aud 校验）、nbf/iat 未来时间拒绝（IAM-AUTH-021，60s 时钟容忍防误杀）、kid 格式白名单（IAM-AUTH-012，拒路径样式 kid）
- 零兼容期：签发管线从第一天就写入正确 iss/aud，存量 token 天然通过；纵深防御点 = 密钥复用/多签发者场景防跨系统 token 混淆（原评审判断的前提型风险）
- 多 kid 支持不是本次前置：验证恒用当前签名钥，claims 校验与选钥无关
- 回归测试：JwtSignerTest +7 负向用例（错误/缺失 iss、空 aud、未来 nbf/iat、路径 kid、容忍窗内不误杀）+ 正向 round-trip 保持

### P1-06 IdP client_secret 加密存储（2026-11-11）

- `IdpSecretCipher`：复用 jasypt-spring-boot 的 StringEncryptor（主密钥 = JASYPT_ENCRYPTOR_PASSWORD，与配置 ENC() 同一密钥体系，不新增密钥管理面）
- 写入（管理端 create/update）密文落 `client_secret_cipher`；读取（OIDC 换 token）解密；**存量明文行宽容回落**——解密失败按明文用并 WARN 一次，下次保存自动迁移，无需停机迁移脚本
- 查询响应本就只回 `has_secret` 布尔（不回显任何形态的秘密）——验收要点天然满足
- 回归测试：`IdpClientSecretCipherIntegrationTest`（密文落库可还原/update 换密/响应无泄露/存量回落）+ `OidcSsoIntegrationTest` 全链路（seed 明文配置走宽容路径）

## 下一步建议顺序

1. P1-04（待产品评审）/ P1-14 / P2 各项按迭代排期

> 本台账与报告同步维护：报告侧问题定义/证据不动，整改状态以本台账为准；每项整改完成后回填总览表「落地」列。

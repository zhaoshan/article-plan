# 实施计划

1. 审计成员接口/详情和截图指定ID；本库仅定向只读查询，核对运行JAR。
2. 复用 GET /admin/members，增加 keyword、owner_candidates、limit<=1000；先过滤再截断，稳定排序，无分页。
3. 详情和列表共用成员投影，不伪造 username；保留历史关系；提交端校验有效用户。
4. 隔离 MySQL 集成测试、打包、diff检查；更新API手册和精确交接契约。

## 完成

四步均已完成；精确契约见contract.md，调查证据见data-audit及runtime-audit，验证见validation.json。26测试通过，打包及diff检查通过。代码被外部并行操作纳入784c255，本轮无Git写入，收尾记录未提交。

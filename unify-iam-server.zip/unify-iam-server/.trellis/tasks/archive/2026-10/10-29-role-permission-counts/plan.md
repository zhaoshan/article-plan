# 角色列表权限点统计计划

日期：2026-10-29（Asia/Shanghai）

## 范围与规则

仅在当前 platform-iam-service 主工作区、现有分支 feature/v0.10.5-m10w5 实现后端。AGENTS.md 与 .trellis/workflow.md 均不存在；读取 CLAUDE.md 和 .claude/rules/{security,migrations}.md，未发现实现前确认门禁。用户已明确授权实现。任务与验证记录全部保留于本目录。不访问其他项目，不提交、合并、推送、切换/重置分支，不操作 worktree。保留原有 application.yml 及其他任务改动。

## 实现方案

- 实际路由 GET /api/v1/admin/roles 的 data.roles 每项新增 permissionCounts，JSON 数字，无权限为 0。
- 与 GET /roles/{roleId}/permissions 一致，统计 gateway_role_permission 中 delete_flag=0 的直接绑定；不额外按权限状态、应用或成员进行过滤。唯一键 (role_id, permission_id) 已保证同一权限不会重复计数。
- 先按原有作用域授权查询角色，再对本列表 role_id 批量 IN + GROUP BY + COUNT(*)，避免 N+1；空列表跳过权限查询。保持现有角色字段和响应信封。
- 验证 MVC 数字字段/零值、MySQL 真实聚合、撤权与重授、空列表，以及既有角色 CRUD/作用域回归。无需迁移。

## 完成结果

已完成仓储批量聚合、服务与控制器接线、API 文档及契约记录。测试命令：

```sh
mvn -pl iam-app -am test -Dtest='AdminRoleControllerTest,AdminRoleServiceTest,AdminRolePermissionCountsIntegrationTest,P3AdminCrudIntegrationTest,P3TenantScopeIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
```

22 tests 全部通过，无失败/错误/跳过；`git diff --check` 通过。源码与任务记录全部保留为未提交状态。

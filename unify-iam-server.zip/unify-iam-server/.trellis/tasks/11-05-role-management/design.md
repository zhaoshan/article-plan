# Design

## Boundaries
CreateRoleRequest removes required-code validation; AdminRoleService generates missing codes using existing IdGenerator. Move creation audit to service using actual persisted metadata (including default scope), retaining role_id response and avoiding null Map.of values; use a transaction for creation/audit.
AdminRoleController retains scope_type/scope_id, adds independent filter_scope_type/filter_scope_id/keyword. Service validates filters and authorizes before repository query. Repository applies scope constraints AND optional filters and groups keyword OR clauses. Use bound LIKE with explicit ! escape following the member-search pattern; never alter runtime listByScope.
Tenant names are enriched for authorized result roles through existing TenantRepository.findByIds with distinct nonblank tenant scope IDs. Names for non-tenant scopes never resolve. Global NON_NULL serialization may omit unavailable tenant_name.

## Contracts
GET /api/v1/admin/roles?scope_type=PLATFORM&scope_id=PLATFORM&filter_scope_type=TENANT,PLATFORM&filter_scope_id=<id>&keyword=<text>.
Scope CSV is uppercase, trimmed/deduplicated, rejects empty/unknown tokens. Tenant and keyword trim; empty means absent. Type OR, dimensions AND, keyword name/description OR. A platform-only type plus tenant filter yields no rows. A foreign tenant filter in tenant authorization scope cannot return foreign roles.
POST omits role_code; generated code is role_ plus a 32-character UUID (37 < VARCHAR(64)); explicit codes preserved. Response remains {role_id}; list exposes persisted role_code.

## Compatibility and rollback
No DDL or pagination changes. Keep unfiltered overloads where existing callers need them. Runtime authorization remains ACTIVE-only. Revert only task-owned changes if rollback is needed.

package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 服务间状态校验请求（G4：后台任务执行前校验任务归属的租户/成员是否仍有效）。 */
public record StatusCheckRequest(
        @NotBlank(message = "tenant_id 不能为空") @JsonProperty("tenant_id") String tenantId,
        @NotBlank(message = "membership_id 不能为空") @JsonProperty("membership_id") String membershipId) {
}

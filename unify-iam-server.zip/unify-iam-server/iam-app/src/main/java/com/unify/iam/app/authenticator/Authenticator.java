package com.unify.iam.app.authenticator;

/**
 * 认证来源接缝（docs/03 §3）：本地密码、OIDC、SAML 各自实现，产出 {@code UserPrincipal} 后统一走
 * {@code TokenService.issueFor} —— 令牌管线对认证来源零感知，保证"只换认证来源"。
 */
public interface Authenticator {

    /** 认证机制标识：local_password / oidc / saml。 */
    String mechanism();
}
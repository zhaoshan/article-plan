package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * docs/06 增量 1 集成测试：建租户自动灌入应用角色模板（AgentOperator/TenantAdmin/Viewer
 * + 权限绑定），可选 owner_user_id 建首人成员并授 TenantAdmin。
 */
class P3TenantInitIntegrationTest extends IamIntegrationTestBase {

    private String adminToken() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminPost(String url, Object body, String token) throws Exception {
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    /** 注册验证码（2026-11-05）：预置 PENDING 码并返回明文码。 */
    private String issueCode(String email) {
        issueVerificationCode(email);
        return "123456";
    }

    @Test
    void createTenantSeedsTemplatesAndOwner() throws Exception {
        String token = adminToken();

        // ① 建首人用户（owner）
        String createdUser = adminPost("/api/v1/admin/users",
                Map.of("username", "init_owner1", "email", "owner1@unify.local", "password", b64("Passw0rd!")), token);
        String ownerUserId = JsonUtils.fromJson(createdUser, Map.class).get("user_id").toString();

        // ② 建租户（带 owner_user_id + 启用 parlant）
        String createdTenant = adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "init-tenant-1", "tenant_name", "Init Tenant 1",
                        "tenant_type", "ORGANIZATION", "owner_user_id", ownerUserId,
                        "app_codes", List.of("parlant-agent-server")), token);
        String tenantId = JsonUtils.fromJson(createdTenant, Map.class).get("tenant_id").toString();

        // ③ 角色列表 API：自带 AgentOperator / TenantAdmin / Viewer
        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(3))
                .andExpect(jsonPath("$.data.roles[?(@.role_code == 'AgentOperator')]").exists())
                .andExpect(jsonPath("$.data.roles[?(@.role_code == 'TenantAdmin')]").exists())
                .andExpect(jsonPath("$.data.roles[?(@.role_code == 'Viewer')]").exists());

        // ④ 成员列表 API：首人成员存在
        mockMvc.perform(get("/api/v1/admin/members").param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.members[?(@.user_id == '" + ownerUserId + "')]").exists());

        // ⑤ DB 深校验：三角色均 is_builtin=1，且无重复（幂等语义：scope+code 唯一）
        Integer roleCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND delete_flag=0",
                Integer.class, tenantId);
        assertThat(roleCount).isEqualTo(3);
        Integer builtinCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND is_builtin=1 AND delete_flag=0",
                Integer.class, tenantId);
        assertThat(builtinCount).isEqualTo(3);

        // ⑥ 权限绑定：TenantAdmin 13（9 业务 + 4 租户内 iam:*）、AgentOperator 9 全量、Viewer 3 只读
        assertPermissionBindings(token, tenantId, "TenantAdmin", 13);
        assertPermissionBindings(token, tenantId, "AgentOperator", 9);
        assertPermissionBindings(token, tenantId, "Viewer", 3);

        // ⑦ 首人成员：join_source=OWNER，is_default=1（可登录），绑定 TenantAdmin 角色
        String ownerMembershipId = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id=? AND user_id=? AND delete_flag=0",
                String.class, tenantId, ownerUserId);
        assertThat(ownerMembershipId).isNotNull();
        String ownerJoinSource = jdbcTemplate.queryForObject(
                "SELECT join_source FROM gateway_membership WHERE membership_id=?", String.class, ownerMembershipId);
        assertThat(ownerJoinSource).isEqualTo("OWNER");
        Integer ownerIsDefault = jdbcTemplate.queryForObject(
                "SELECT is_default FROM gateway_membership WHERE membership_id=?", Integer.class, ownerMembershipId);
        assertThat(ownerIsDefault).isEqualTo(1);
        Integer ownerRoleBindings = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_role r ON mr.role_id=r.role_id "
                        + "WHERE mr.membership_id=? AND r.role_code='TenantAdmin' AND mr.delete_flag=0 AND r.delete_flag=0",
                Integer.class, ownerMembershipId);
        assertThat(ownerRoleBindings).isEqualTo(1);
    }

    @Test
    void createTenantWithoutOwnerStillSeedsRoles() throws Exception {
        String token = adminToken();
        String createdTenant = adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "init-tenant-2", "tenant_name", "Init Tenant 2",
                        "app_codes", List.of("parlant-agent-server")), token);
        String tenantId = JsonUtils.fromJson(createdTenant, Map.class).get("tenant_id").toString();

        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(3));

        Integer memberCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership WHERE tenant_id=? AND delete_flag=0",
                Integer.class, tenantId);
        assertThat(memberCount).isZero();
    }

    @Test
    void createTenantRequiresAppCodes() throws Exception {
        String token = adminToken();
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_code", "no-app", "tenant_name", "No App"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createTenantWithUnknownAppRejected() throws Exception {
        String token = adminToken();
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_code", "bad-app", "tenant_name", "Bad App",
                                "app_codes", List.of("no-such-app")))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createTenantRejectsRoleCodeConflict() throws Exception {
        String token = adminToken();
        // 注入第二个应用：复用 role_code=Viewer 但权限集与 parlant 不一致 → 应 400（gateway_role 租户内 role_code 唯一）
        jdbcTemplate.update("INSERT INTO iam_application "
                + "(app_id, app_code, app_name, app_status, delete_flag, create_by, update_by) "
                + "VALUES ('app-9cf', 'conflict-app', 'Conflict App', 'ACTIVE', 0, 'system', 'system')");
        jdbcTemplate.update("INSERT INTO iam_application_role_template "
                + "(template_id, app_code, role_code, role_name, role_description, permission_codes_json, "
                + " is_owner, priority, delete_flag, create_by, update_by) "
                + "VALUES ('tpl-9cf1', 'conflict-app', 'Viewer', 'Viewer', '只读（冲突版）', "
                + " JSON_ARRAY('agent:read'), 0, 10, 0, 'system', 'system')");

        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_code", "role-cf", "tenant_name", "Role Conflict",
                                "app_codes", List.of("parlant-agent-server", "conflict-app")))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createTenantRejectsUnknownPermissionInTemplate() throws Exception {
        String token = adminToken();
        // 注入应用：模板引用不存在的权限点 → 应 400（防静默丢权限）
        jdbcTemplate.update("INSERT INTO iam_application "
                + "(app_id, app_code, app_name, app_status, delete_flag, create_by, update_by) "
                + "VALUES ('app-9bp', 'bad-perm-app', 'Bad Perm App', 'ACTIVE', 0, 'system', 'system')");
        jdbcTemplate.update("INSERT INTO iam_application_role_template "
                + "(template_id, app_code, role_code, role_name, role_description, permission_codes_json, "
                + " is_owner, priority, delete_flag, create_by, update_by) "
                + "VALUES ('tpl-9bp1', 'bad-perm-app', 'BadRole', 'Bad Role', '坏权限', "
                + " JSON_ARRAY('no-such-perm-code'), 0, 10, 0, 'system', 'system')");

        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_code", "bad-perm", "tenant_name", "Bad Perm",
                                "app_codes", List.of("bad-perm-app")))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createTenantWithMultipleAppsSeedsAllTemplates() throws Exception {
        String token = adminToken();
        // ① 注入第二个应用 ai-chat-insight + 模板（模拟「新增应用 = 插数据不改代码」）
        jdbcTemplate.update("INSERT INTO iam_application "
                + "(app_id, app_code, app_name, app_status, delete_flag, create_by, update_by) "
                + "VALUES ('app-9test', 'ai-chat-insight', 'AI Chat Insight', 'ACTIVE', 0, 'system', 'system')");
        jdbcTemplate.update("INSERT INTO iam_application_role_template "
                + "(template_id, app_code, role_code, role_name, role_description, permission_codes_json, "
                + " is_owner, priority, delete_flag, create_by, update_by) "
                + "VALUES "
                + "('tpl-9test1', 'ai-chat-insight', 'Analyst', 'Analyst', '分析员', "
                + " JSON_ARRAY('trace:read','settings:read'), 0, 20, 0, 'system', 'system'),"
                + "('tpl-9test2', 'ai-chat-insight', 'ChatAdmin', 'Chat Admin', '聊天管理员', "
                + " JSON_ARRAY('session:read','session:send','trace:read'), 1, 10, 0, 'system', 'system')");

        // ② 建 owner + 租户（启用两个应用）
        String ownerUserId = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                Map.of("username", "init_owner2", "email", "owner2@unify.local", "password", b64("Passw0rd!")), token),
                Map.class).get("user_id").toString();
        String tenantId = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "multi-app", "tenant_name", "Multi App",
                        "owner_user_id", ownerUserId,
                        "app_codes", List.of("parlant-agent-server", "ai-chat-insight")), token),
                Map.class).get("tenant_id").toString();

        // ③ 两个应用的角色全部灌入（parlant 3 + ai-chat 2）
        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(5))
                .andExpect(jsonPath("$.data.roles[?(@.role_code == 'AgentOperator')]").exists())
                .andExpect(jsonPath("$.data.roles[?(@.role_code == 'ChatAdmin')]").exists())
                .andExpect(jsonPath("$.data.roles[?(@.role_code == 'Analyst')]").exists());

        // ④ 租户启用应用登记 2 条
        Integer tenantApps = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM iam_tenant_application WHERE tenant_id=? AND delete_flag=0",
                Integer.class, tenantId);
        assertThat(tenantApps).isEqualTo(2);

        // ⑤ owner 授两个应用的 is_owner 角色（TenantAdmin + ChatAdmin）
        Integer ownerRoleBindings = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership mr "
                        + "JOIN gateway_membership_role mrr ON mrr.membership_id=mr.membership_id "
                        + "JOIN gateway_role r ON r.role_id=mrr.role_id "
                        + "WHERE mr.tenant_id=? AND mr.user_id=? AND r.role_code IN ('TenantAdmin','ChatAdmin') "
                        + "AND mr.delete_flag=0 AND mrr.delete_flag=0 AND r.delete_flag=0",
                Integer.class, tenantId, ownerUserId);
        assertThat(ownerRoleBindings).isEqualTo(2);
    }

    @Test
    void registerWithAppGrantsOwnerRoleInPersonalTenant() throws Exception {
        // ① 注册带 app_code=parlant-agent-server（模拟从 parlant 跳注册）
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", "reg_app_owner", "email", "reg-app@unify.local",
                                "password", b64("Passw0rd!"), "verification_code", issueCode("reg-app@unify.local"),
                                "app_codes", List.of("parlant-agent-server")))))
                .andExpect(status().isOk());

        // ② 该用户的个人租户被灌入模板角色（AgentOperator/TenantAdmin/Viewer）
        String tenantId = jdbcTemplate.queryForObject(
                "SELECT tenant_id FROM gateway_tenant WHERE tenant_type='PERSONAL' AND delete_flag=0 "
                        + "AND owner_user_id=(SELECT user_id FROM gateway_user WHERE username='reg_app_owner')",
                String.class);
        Integer roleCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND delete_flag=0",
                Integer.class, tenantId);
        assertThat(roleCount).isEqualTo(3);

        // ③ owner 成员被授 is_owner 角色（TenantAdmin）
        Integer ownerGrant = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership mr "
                        + "JOIN gateway_membership_role mrr ON mrr.membership_id=mr.membership_id "
                        + "JOIN gateway_role r ON r.role_id=mrr.role_id "
                        + "WHERE mr.tenant_id=? AND r.role_code='TenantAdmin' AND mr.delete_flag=0 "
                        + "AND mrr.delete_flag=0 AND r.delete_flag=0",
                Integer.class, tenantId);
        assertThat(ownerGrant).isEqualTo(1);

        // ④ 登记租户↔应用（角色配置页按应用隔离的数据源）
        Integer tenantApps = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM iam_tenant_application WHERE tenant_id=? AND app_code='parlant-agent-server' AND delete_flag=0",
                Integer.class, tenantId);
        assertThat(tenantApps).isEqualTo(1);
    }

    @Test
    void registerWithUnknownAppStillSucceedsWithoutRoles() throws Exception {
        // 无效 app_code → 注册仍成功，个人租户不灌角色（app 只是 onboarding 提示）
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", "reg_bad_app", "email", "reg-bad@unify.local",
                                "password", b64("Passw0rd!"), "verification_code", issueCode("reg-bad@unify.local"),
                                "app_codes", List.of("no-such-app")))))
                .andExpect(status().isOk());
        String tenantId = jdbcTemplate.queryForObject(
                "SELECT tenant_id FROM gateway_tenant WHERE tenant_type='PERSONAL' AND delete_flag=0 "
                        + "AND owner_user_id=(SELECT user_id FROM gateway_user WHERE username='reg_bad_app')",
                String.class);
        Integer roleCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND delete_flag=0",
                Integer.class, tenantId);
        assertThat(roleCount).isZero();
    }

    @Test
    void personalTenantCanAddAndInviteMembers() throws Exception {
        String token = adminToken();
        // 注册个人租户（带 app）
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", "reg_pers_owner", "email", "reg-pers@unify.local",
                                "password", b64("Passw0rd!"), "verification_code", issueCode("reg-pers@unify.local"),
                                "app_codes", List.of("parlant-agent-server")))))
                .andExpect(status().isOk());
        String tenantId = jdbcTemplate.queryForObject(
                "SELECT tenant_id FROM gateway_tenant WHERE tenant_type='PERSONAL' AND delete_flag=0 "
                        + "AND owner_user_id=(SELECT user_id FROM gateway_user WHERE username='reg_pers_owner')",
                String.class);

        // 产品决策：个人租户可添加成员（作为协作空间）→ 200
        mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", tenantId, "user_id", "u-1001"))))
                .andExpect(status().isOk());

        // 个人租户可邀请 → 200
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", "someone@unify.local", "tenant_id", tenantId))))
                .andExpect(status().isOk());
    }

    @Test
    void sameUserOwnerOfMultipleTenantsStillLogsIn() throws Exception {
        String token = adminToken();
        // admin（u-1000）已是 tenant-org-a 成员且为默认；再建两个租户 owner=admin
        for (String code : new String[] { "multi-owner-1", "multi-owner-2" }) {
            adminPost("/api/v1/admin/tenants", Map.of(
                    "tenant_code", code, "tenant_name", "Multi Owner " + code,
                    "owner_user_id", "u-1000", "app_codes", List.of("parlant-agent-server")), token);
        }

        // 登录仍正常（findDefaultActive 不歧义）
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk());

        // 一用户至多一个 is_default=1（后建的 owner 成员为 0）
        Integer defaultCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership WHERE user_id='u-1000' AND is_default=1 AND delete_flag=0",
                Integer.class);
        assertThat(defaultCount).isEqualTo(1);
    }

    @Test
    void deletedTenantNotSwitchableOrListed() throws Exception {
        String token = adminToken();
        // 建租户 + owner=admin（u-1000，成为成员）
        String tenantId = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "del-tenant", "tenant_name", "Del Tenant",
                        "owner_user_id", "u-1000", "app_codes", List.of("parlant-agent-server")), token),
                Map.class).get("tenant_id").toString();
        String membershipId = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id=? AND user_id='u-1000' AND delete_flag=0",
                String.class, tenantId);

        // 删除前：成员列表可见 + 可切换
        mockMvc.perform(get("/api/v1/auth/memberships").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.memberships[?(@.tenant_id == '" + tenantId + "')]").exists());

        // 逻辑删除租户
        mockMvc.perform(delete("/api/v1/admin/tenants/" + tenantId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());

        // 删除后：成员列表不再含该租户
        mockMvc.perform(get("/api/v1/auth/memberships").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.memberships[?(@.tenant_id == '" + tenantId + "')]").doesNotExist());

        // 直接 switch-tenant 到该成员 → 403（防绕过）
        mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("membership_id", membershipId))))
                .andExpect(status().isForbidden());
    }

    @Test
    void ownerLoginRecoversAfterDefaultTenantDeleted() throws Exception {
        String token = adminToken();
        // 新用户 U（无任何成员）→ 建租户 T1 owner=U → U 的 T1 成员为默认
        String uid = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                Map.of("username", "rec_owner", "email", "rec-owner@unify.local", "password", b64("Passw0rd!")), token),
                Map.class).get("user_id").toString();
        String t1 = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "rec-t1", "tenant_name", "Rec T1",
                        "owner_user_id", uid, "app_codes", List.of("parlant-agent-server")), token),
                Map.class).get("tenant_id").toString();
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"rec_owner\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk());

        // 删除 T1（U 当前默认租户）→ U 登录失败
        mockMvc.perform(delete("/api/v1/admin/tenants/" + t1)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"rec_owner\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isUnauthorized());

        // 2026-11-06 孤儿级联：T1 删除后 U 已被软删（原断言登录失败仍成立，原因变为账号不存在）；
        // 恢复路径 = 同邮箱重新注册（V22 生成列唯一键）→ 以新 uid 建 T2 owner → 登录成功
        assertThat(jdbcTemplate.queryForObject(
                "SELECT delete_flag FROM gateway_user WHERE user_id=?", Integer.class, uid)).isEqualTo(1);
        issueVerificationCode("rec-owner@unify.local");
        String newUid = unwrapData(mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", "rec_owner",
                                "email", "rec-owner@unify.local",
                                "password", b64("Passw0rd!"),
                                "verification_code", "123456"))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("user_id").toString();
        adminPost("/api/v1/admin/tenants", Map.of(
                "tenant_code", "rec-t2", "tenant_name", "Rec T2",
                "owner_user_id", newUid, "app_codes", List.of("parlant-agent-server")), token);
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"rec_owner\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk());
    }

    /** 校验某角色在网关权限字典中实际绑定的业务权限点数（按 code→id 解析）。 */
    private void assertPermissionBindings(String token, String tenantId, String roleCode, int expected) throws Exception {
        MvcResult rolesRes = mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + token))
                .andReturn();
        List<Map<String, Object>> roles = (List<Map<String, Object>>) unwrapData(
                rolesRes.getResponse().getContentAsString()).get("roles");
        String roleId = roles.stream()
                .filter(r -> roleCode.equals(r.get("role_code")))
                .map(r -> r.get("role_id").toString())
                .findFirst().orElseThrow();
        Integer bindings = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_role_permission WHERE role_id=? AND delete_flag=0",
                Integer.class, roleId);
        assertThat(bindings).isEqualTo(expected);
    }
}

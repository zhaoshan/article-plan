package com.unify.iam.app.mail;

import com.unify.iam.app.config.IamProperties;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

/**
 * 注册验证码邮件投递（2026-11-05）：渲染 {@code templates/email-verification-email.html}
 * （{{Full_Name}} / {{verification_code}} 变量）经 {@link EmailTool} 投递；
 * SMTP 未配置时日志兜底输出验证码（dev 联调直接取用）。
 */
@Service
public class RegistrationVerificationMailService {

    private static final Logger log = LoggerFactory.getLogger(RegistrationVerificationMailService.class);

    private final EmailTool emailTool;
    private final IamProperties props;

    public RegistrationVerificationMailService(EmailTool emailTool, IamProperties props) {
        this.emailTool = emailTool;
        this.props = props;
    }

    /** 发送注册验证码邮件。 */
    public void sendCode(String to, String code, LocalDateTime expiresAt) {
        Map<String, String> vars = new LinkedHashMap<>();
        vars.put("Full_Name", to.substring(0, to.indexOf('@')));
        vars.put("verification_code", code);
        emailTool.send(to, props.getMail().getEmailVerificationSubject(),
                MailTemplateRenderer.render(loadTemplate(), vars));
        log.info("verification code email submitted | email={} | expiresAt={}",
                com.unify.iam.common.util.LogMasks.maskEmail(to), expiresAt);
    }

    private String loadTemplate() {
        try {
            return new String(new ClassPathResource(props.getMail().getEmailVerificationTemplate())
                    .getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("load email verification template failed", e);
        }
    }
}

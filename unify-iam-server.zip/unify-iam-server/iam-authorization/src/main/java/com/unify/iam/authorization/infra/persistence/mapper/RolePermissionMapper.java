package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.RolePermissionPO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/** gateway_role_permission Mapper。 */
@Mapper
public interface RolePermissionMapper extends BaseMapper<RolePermissionPO> {

    /**
     * 复活逻辑删除的角色-权限绑定（软删后唯一键 (role_id, permission_id) 仍占位，重授需复活；参照 TenantApplicationMapper.restore）。
     *
     * @return 命中的行数（0 表示无墓碑，调用方改走 insert）
     */
    @Update("UPDATE gateway_role_permission SET delete_flag = 0, update_time = NOW() "
            + "WHERE role_id = #{roleId} AND permission_id = #{permissionId} AND delete_flag = 1")
    int revive(@Param("roleId") String roleId, @Param("permissionId") String permissionId);
}

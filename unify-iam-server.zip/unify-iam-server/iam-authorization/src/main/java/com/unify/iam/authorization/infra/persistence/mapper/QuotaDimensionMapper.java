package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.QuotaDimensionPO;

/** G1 配额维度 Mapper。 */
public interface QuotaDimensionMapper extends BaseMapper<QuotaDimensionPO> {
}

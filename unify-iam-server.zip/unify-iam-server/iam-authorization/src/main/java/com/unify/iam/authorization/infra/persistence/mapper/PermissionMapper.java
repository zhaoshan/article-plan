package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.PermissionPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_permission Mapper。 */
@Mapper
public interface PermissionMapper extends BaseMapper<PermissionPO> {
}

# Audit multi-tenant filter contract plan

Date: 2026-10-27

Status: Complete.

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, plan, session, contract, and validation records under this repository's `.trellis/` directory.
- Do not access, inspect, or modify another Platform IAM project or frontend repository.
- Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- `AGENTS.md` and `.trellis/workflow.md` are absent from this worktree. `CLAUDE.md` and `.claude/rules/security.md` are the applicable project instructions. They introduce no additional confirmation gate for this explicitly requested additive API contract.

## Confirmed baseline

1. `GET /api/v1/admin/audit` requires `iam:audit:read` before entering the controller and already returns the standard `/api/v1/**` envelope with `data.{audits,total,page,size}`.
2. The completed audit-filter implementation has one parameterized SQL path shared by page and count. It supports legacy exact `tenant_id`, `event_type`, and `actor_user_id`, plus keyword and paired date-only/legacy-timestamp time bounds.
3. The active filter path currently has a singleton `tenant_id` property. Adding a list there ensures the exact same OR predicate applies to both page rows and `total`, avoiding post-pagination filtering.
4. Audit history can outlive a tenant's active directory record. Unknown or removed tenant IDs must remain queryable as literal historical IDs, rather than being rejected through a live tenant lookup.

## Chosen contract

```text
GET /api/v1/admin/audit?tenant_ids=tenant-a&tenant_ids=tenant-b
Authorization: Bearer <token with iam:audit:read>
```

- `tenant_ids` is an additive, repeated query parameter. The frontend must use `URLSearchParams.append('tenant_ids', id)` once per selected checkbox value. It must not use `tenant_ids[]` or a comma-joined string.
- The service reads raw repeated query values so Spring's automatic comma-to-collection conversion cannot weaken the contract. It trims values, drops blanks, preserves first-seen order, and deduplicates. A maximum of 100 distinct IDs prevents an unbounded `IN` clause. An embedded comma, `tenant_ids[]`, and more than 100 distinct IDs return the standard HTTP 400 envelope.
- The existing optional `tenant_id` remains fully supported. If both forms are supplied, their values form one OR set. Existing callers that send only `tenant_id` retain exact singleton semantics.
- If no nonblank tenant value remains, there is no tenant predicate: this is the explicit all-tenants state. An unknown/deleted nonblank ID is a valid exact historical query and simply returns no matching audit rows when absent.
- The tenant OR predicate is ANDed with `event_type`, `actor_user_id`, keyword, and time conditions. Date-only bounds remain inclusive business days in `Asia/Shanghai`; `total` is calculated from the same filter as the page.
- Authorization and response shape remain unchanged. Missing/invalid Bearer is 401; a valid token without `iam:audit:read` is 403; only a caller with the existing audit permission can use all-tenants or multi-tenant scope.

## Implementation checklist

- [x] Read available project/security instructions and record the missing requested workflow files.
- [x] Trace controller, service, shared SQL/count path, authorization interceptor, existing audit contract, and Testcontainers coverage.
- [x] Publish the stable frontend parameter contract to the delegating session.
- [x] Add list normalization and a parameterized `IN` predicate shared by list/count.
- [x] Document encoding, legacy compatibility, empty selection, invalid/duplicate values, and confirmed-date request timing.
- [x] Run focused compile/integration checks and record evidence.
- [x] Inspect running port 8090, then perform a guarded rebuild/restart and credential-free HTTP verification.

## Out of scope

- Frontend implementation, control state, rendering, or request-timing source changes.
- Any schema migration, audit-data rewrite, new authorization policy, branch/worktree action, commit, merge, or push.

## Implementation and validation result

- The controller now reads the raw repeated `tenant_ids` values. This prevents Spring MVC from silently treating a single comma-packed value as a collection, and explicitly rejects both that form and `tenant_ids[]` after the existing permission interceptor runs.
- `AdminAuditService` merges legacy `tenant_id` and new values into a trimmed, insertion-ordered, deduplicated list. Blank values create no tenant predicate; nonblank unknown values remain literal historical queries. More than 100 unique selections return 400.
- `AuditLogSqlProvider` emits a parameterized `a.tenant_id IN (...)` predicate only when that list is nonempty. It is built into the shared SQL fragment used by both `SELECT` and `COUNT`, so page data and `total` cannot diverge. Keyword, time, event, and actor conditions remain ANDed.
- `AdminAuditQueryIntegrationTest` now proves two-tenant OR matching, duplicate/unknown input handling, the all-tenants blank state, legacy singleton compatibility, singleton-plus-list union, date-only/keyword composition, stable pagination total, invalid formats/size limit, and 401/403 boundaries. The focused suite passed 18 tests with no failures or errors against Testcontainers MySQL.
- The pre-existing 8090 owner was verified as PID 92225 running the current-worktree JAR built before this task. After a fresh package, only that verified PID received `TERM`; a replacement PID 29067 then appeared on the same port with the freshly built JAR. Credential-free checks returned health `200` and protected audit-route `401`. No user credentials or audit payloads were accessed or emitted.

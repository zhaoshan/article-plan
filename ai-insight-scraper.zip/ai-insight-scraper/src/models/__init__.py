"""src.models — 跨模块共享的 Pydantic V2 模型定义"""

from src.models.api_response import DefaultResult
from src.models.crawl_request import CrawlRequest
from src.models.crawl_task import CrawlTask, TaskProgress
from src.models.crawl_result import TreeNode, TreeStructure, PageCrawlStats, CrawlTaskResult
from src.models.traversal_config import DomainTraversalConfig
from src.models.content_crawl_config import ContentCrawlConfig, ExcludeTag
from src.models.dynamic_page_config import DynamicPageEntry
from src.models.crawl_request import DynamicCrawlRequest
from src.models.crawl_schedule import (
    CrawlScheduleCreate,
    CrawlScheduleUpdate,
    CrawlScheduleResponse,
    CrawlScheduleLogResponse,
)

__all__ = [
    "DefaultResult",
    "CrawlRequest",
    "DynamicCrawlRequest",
    "CrawlTask",
    "TaskProgress",
    "TreeNode",
    "TreeStructure",
    "PageCrawlStats",
    "CrawlTaskResult",
    "DomainTraversalConfig",
    "ContentCrawlConfig",
    "ExcludeTag",
    "DynamicPageEntry",
    "CrawlScheduleCreate",
    "CrawlScheduleUpdate",
    "CrawlScheduleResponse",
    "CrawlScheduleLogResponse",
]

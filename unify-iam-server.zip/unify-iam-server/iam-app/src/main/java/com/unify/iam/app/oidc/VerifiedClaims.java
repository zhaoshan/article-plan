package com.unify.iam.app.oidc;

import java.util.List;
import java.util.Map;

/**
 * 验签 + claim 映射后的已验证 OIDC 身份声明。
 *
 * @param subject OIDC subject（唯一）
 * @param email   映射后的邮箱（可能为空，SSO 后置处理）
 * @param name    展示名
 * @param groups  IdP 组（映射后；可能为空）
 * @param all     全部映射后的 claims（内部字段 → 值，供产物/排障）
 */
public record VerifiedClaims(
        String subject,
        String email,
        String name,
        List<String> groups,
        Map<String, Object> all) {
}
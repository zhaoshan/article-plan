# unify-iam-server

Gateway 权限体系 IAM 服务（Java 21 / Spring Boot 3.5.9 / Maven 多模块）。

- 总体设计与功能模块拆分（含开发阶段拆分 Roadmap）：`docs/01-总体设计与功能模块拆分.md`
- 首阶段（E2E-1）实现方案：`docs/02-E2E1-首阶段实现方案.md`
- 第二阶段（E2E-2）企业 SSO 详细设计 + 实现记录：`docs/03-E2E2-企业SSO与组织接入.md`（含附录 A）
- 第三阶段（E2E-3）管理面与账号生命周期设计：`docs/04-E2E3-P3管理面与账号生命周期设计.md`
- IAM 前端管理台与统一登录（platform-iam-web）设计：`docs/05-IAM前端管理台与统一登录设计.md`
- 应用角色模板与租户级管理面设计：`docs/06-应用角色模板与租户级管理面设计.md`
- 管理面 SSO 配置（IdP/组映射，P3.5）：`docs/07-管理面SSO配置-IdP配置与组角色映射.md`
- 用户操作手册：`docs/user-manual/`（00 索引 + 01 平台管理员 + 02 租户管理员 + 03 业务系统接入指南 + 04 业务逻辑流程 + 05 API 接口梳理）
- 业务需求与能力差距（iMorph M10W3）：`docs/requirements/`（CommonCapabilities_M10W3.md 需求 PRD + M10W3-能力盘点与IAM差距分析.md）
- 范围与三方契约：`docs/original-design/20261008-Gateway-E2E1-首阶段最小实现范围.md`

## 定位

统一身份与权限控制面：登录签发 RS256 JWT（暴露 JWKS），业务应用（如 parlant-agent）本地验签，
只消费已授权上下文（`AuthorizationContext`）。E2E-1 交付最小闭环：

**IAM 极简登录 → RS256 JWT → parlant-agent gateway Provider 验签翻译 → 401/403/200 正确。**

## 模块

| 模块 | 职责 |
|---|---|
| `iam-common` | 横切基础设施：BaseEntity / CommonResponse / 异常 / 工具 |
| `iam-api` | 契约层：AuthorizationContext / JwtClaims / DTO / 权限点目录 |
| `iam-identity` | Identity 域：用户 / 本地身份 / 凭据校验 |
| `iam-tenant` | Tenant 域：租户 / 成员关系 |
| `iam-authorization` | Authorization 域：角色 / 权限点 / RBAC 解析 |
| `iam-app` | 可启动应用：auth/jwks/me 端点 + 令牌签发编排 + Flyway |

## 环境要求

- JDK 21+，Maven 3.9+
- MySQL 8.x（本地 Docker：`root/root123456`；schema `unify_iam` 自动创建）
- 集成测试需 Docker（Testcontainers 起临时 `mysql:8.0`）

## 构建与测试

```bash
# 全量构建 + 测试（单元 + Web + Testcontainers 集成）
mvn clean install

# 只跑集成测试（E2E-1 + E2E-2；Testcontainers MySQL，需 Docker）
mvn -pl iam-app -am test -Dtest='IamFlowIntegrationTest,OidcSsoIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false

# 跑除集成外的全部测试（单元 + Web，快速，不依赖 Docker）
mvn -pl iam-app -am test -Dtest='!IamFlowIntegrationTest,!OidcSsoIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false
```

## 本地运行

```bash
mvn install -DskipTests
cd iam-app && mvn spring-boot:run        # 默认 local profile：连 127.0.0.1:3306/unify_iam，端口 8090
```

启动后 Flyway 自动建 **10 张表**（V1-V3，含 SSO 两张）并写入 seed；首次启动生成 RSA 私钥到
`keys/rsa-private.pem`（0600；路径由 `IAM_JWT_PRIVATE_KEY_PATH` 固定为根目录绝对路径，**重启不换钥**，避免不同启动目录各生成一把导致 token 失配）。

### 验证四连（curl）

```bash
# 1. JWKS
curl -s localhost:8090/.well-known/jwks.json

# 2. 登录（operator/op123）
curl -s -X POST localhost:8090/api/v1/auth/token \
  -H 'Content-Type: application/json' \
  -d '{"username":"operator","password":"op123"}'

# 3. 错误密码 → 401 {"detail":"用户名或密码错误"}
curl -si -X POST localhost:8090/api/v1/auth/token \
  -H 'Content-Type: application/json' \
  -d '{"username":"operator","password":"wrong"}'

# 4. /me（Bearer 验签 → AuthorizationContext）
curl -s localhost:8090/api/v1/auth/me -H "Authorization: Bearer <access_token>"
```

Seed 账号：`admin/admin123`（TenantAdmin，全 9 权限）、`operator/op123`（AgentOperator，全 9 权限）、
`viewer/view123`（Viewer，仅 agent:read / session:read / settings:read，用于 403 演示）。

## 与 parlant-agent 联调（E2E-1）

parlant-agent-server `.env` 切 gateway 模式并指向本服务（路由代码零改动）：

```dotenv
AUTH_MODE=gateway
JWT_JWKS_URL=http://127.0.0.1:8090/.well-known/jwks.json
IAM_TOKEN_URL=http://127.0.0.1:8090/api/v1/auth/token
# 可选：开启 iss 校验（与本服务签发 iss 一致）
# JWT_ISSUER=https://www.identityfabric.com
```

web 用 `operator/op123` 登录，逐条跑 E2E 验收 1–7（无令牌 401 / AgentOperator 200 / Viewer publish 403 /
TenantAdmin 全通 / 篡改过期 401 / 全链路 / 换角色 seed 授权立即变化）。

## 企业 SSO 登录（E2E-2，OIDC）

认证来源可插拔（`Authenticator`：本地密码 / OIDC），**令牌管线不变**，与 E2E-1 的令牌完全同构。

| 端点 | 说明 |
|---|---|
| `GET /api/v1/auth/oidc/authorize?tenant_id=xxx` | 302 跳 IdP 授权端点（state/nonce/PKCE） |
| `GET /api/v1/auth/oidc/callback?code=&state=` | 换 token → 验签 → JIT 入租户 → 组映射 → 签发 |

使用前提：`gateway_tenant_idp_config` 有一行 ACTIVE OIDC 配置（指向某 IdP，含 issuer/jwks/client/claim_mapping/allowed_domains）。集成测试用内置 Mock OIDC Provider（真实 HTTP）自动化；本地人工联调见 `docs/03 §12.2`（Keycloak）＋ 用 `scripts/seed_sso_keycloak_dev.sql`（幂等手动脚本，非迁移）预置配置；实现记录见 `docs/03` 附录 A。

## 配置（application.yml）

| key | 说明 | 默认 |
|---|---|---|
| `iam.jwt.kid` | kid（固定） | `iam-key-1` |
| `iam.jwt.issuer` | 签发 iss（与 parlant `JWT_ISSUER` 对齐） | `https://www.identityfabric.com` |
| `iam.jwt.audience` | 签发 aud（parlant 默认校验该值，勿改） | `parlant-agent-server` |
| `iam.jwt.ttl-seconds` | 令牌有效期 | `7200` |
| `iam.jwt.private-key-path` | RSA 私钥持久化路径（`IAM_JWT_PRIVATE_KEY_PATH` 覆盖；建议固定绝对路径） | `/Users/zhaoshan/workspace/unify-iam-server/keys/rsa-private.pem` |
| `iam.oidc.redirect-uri` | IAM 的 OIDC 回调地址（Keycloak client 需白名单） | `http://localhost:8090/api/v1/auth/oidc/callback` |
| `iam.oidc.frontend-redirect` | 登录成功回跳前端地址（`?access_token=`） | `http://localhost:5173/login` |
| `iam.oidc.allowed-algorithms` | ID Token 算法白名单 | `RS256,ES256` |
| `iam.dev-token-enabled` | dev-token 端点开关（prod 关闭） | `true` |

> 私钥 `keys/*.pem` 已 gitignore，严禁提交；生产用 `IAM_JWT_PRIVATE_KEY_PATH` 指向密钥挂载卷 / KMS。

## 开发协作（Claude Code harness）

- `CLAUDE.md`：项目指令（架构/契约/安全约束/踩坑）。
- `.claude/rules/`：路径限定规则（Flyway 迁移、IAM 安全约束）。
- `.claude/commands/`：斜杠命令 `/verify`（构建测试）、`/sso`（SSO/Keycloak/JWKS 链路检查）、`/db`（数据库状态）、`/key`（私钥与 JWKS 一致性）。
- `.claude/settings.json`：环境（私钥路径/代理）+ 权限（保护 `keys/`，`git push` 需确认）。

## 相关文档

- IAM 前端管理台与统一登录（platform-iam-web）：`docs/05-IAM前端管理台与统一登录设计.md`
- parlant-agent 接入方案：`/Users/zhaoshan/workspace/parlant-agent/docs/06-dev-process/11-parlant-agent接入unify-iam-server方案-企业SSO与个人账号.md`

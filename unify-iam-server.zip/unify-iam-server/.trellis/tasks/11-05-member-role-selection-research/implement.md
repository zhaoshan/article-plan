# Execution plan

1. User explicitly approved implementation of route/collection and Source; update artifacts then task.py start. Keep unresolved global grant policy separate.
2. Implement isolated repository query, DTOs, service, controller and meaningful focused tests through trellis-implement. Preserve others' current RoleRepository changes.
3. Verify existing members join_source SQL/projection and add a real field regression. Recheck invitation/member write paths, preserve existing semantics where global grant policy is not authorized, record blocker with evidence.
4. Run JDK 21 Maven compile/unit tests and MySQL Testcontainers integration tests where Docker is available; failures/skips remain failures/blocked. Inspect regression behavior for old role listing and tenant scoping.
5. trellis-check review/fix, then capture the approved read contract in backend specs. Record results/session only under .trellis. User prohibits Git mutations and cross-project work; no commit/archive or finish hook that autocommits.

Expected source changes: new TenantRoleController/TenantRoleQueryService and API DTOs, additive RoleRepository method, tests. Source already exists, so avoid needless projection changes. Writes/admin guard remain unchanged absent explicit identity decision. No dependency/DB/frontend change planned.

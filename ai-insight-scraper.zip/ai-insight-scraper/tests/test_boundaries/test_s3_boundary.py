"""S3 边界服务测试

测试策略：
  1. 路径工具与配置加载（纯单元测试，无网络）
  2. upload/download/exists 的 mock 测试（用 unittest.mock 拦截 boto3 调用）
  3. 真实连通性测试（标记 @pytest.mark.live，默认跳过，需显式开启）

真实测试需配置 S3 环境变量后运行：
    pytest tests/test_boundaries/test_s3_boundary.py -m live -v
"""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from src.boundaries.s3_boundary import S3Boundary, S3Error
from src.config.system_config import S3Config, load_s3_config


# ── 测试用 S3 配置 fixture ────────────────────────────


@pytest.fixture
def s3_config() -> S3Config:
    """测试用 S3 配置（不依赖真实环境变量）"""
    return S3Config(
        access_key="test-access-key",
        secret_key="test-secret-key",
        region="us-west-2",
        bucket="web-scraper",
        endpoint="https://example-s3alias.s3-accesspoint.us-west-2.amazonaws.com",
        prefix_path="local",
        signature_version="s3v4",
    )


@pytest.fixture
def s3_config_no_endpoint() -> S3Config:
    """无 endpoint 的标准 bucket 配置"""
    return S3Config(
        access_key="test-access-key",
        secret_key="test-secret-key",
        region="us-west-2",
        bucket="web-scraper",
        endpoint=None,
        prefix_path="local",
        signature_version="s3v4",
    )


@pytest.fixture
def mock_boto_client():
    """mock boto3.client 返回的伪客户端"""
    return MagicMock()


@pytest.fixture
def s3_boundary(s3_config, mock_boto_client):
    """注入 mock 客户端的 S3Boundary 实例（访问点场景）"""
    with patch("src.boundaries.s3_boundary.boto3.client", return_value=mock_boto_client):
        boundary = S3Boundary(config=s3_config)
    boundary._client = mock_boto_client
    return boundary


@pytest.fixture
def s3_boundary_no_endpoint(s3_config_no_endpoint, mock_boto_client):
    """无 endpoint 的标准 bucket S3Boundary"""
    with patch("src.boundaries.s3_boundary.boto3.client", return_value=mock_boto_client):
        boundary = S3Boundary(config=s3_config_no_endpoint)
    boundary._client = mock_boto_client
    return boundary


# ── 1. 配置与路径工具测试 ─────────────────────────────


class TestS3Config:
    """S3 配置测试"""

    def test_config_creation(self, s3_config):
        """配置实例化字段正确"""
        assert s3_config.access_key == "test-access-key"
        assert s3_config.bucket == "web-scraper"
        assert s3_config.region == "us-west-2"
        assert s3_config.prefix_path == "local"
        assert s3_config.signature_version == "s3v4"

    def test_config_missing_access_key(self):
        """缺少必填项抛异常"""
        with pytest.raises(ValueError, match="S3_ACCESS_KEY"):
            S3Config(
                access_key="",
                secret_key="x",
                region="us-west-2",
                bucket="b",
            )

    def test_config_missing_bucket(self):
        """缺少 bucket 抛异常"""
        with pytest.raises(ValueError, match="S3_BUCKET"):
            S3Config(
                access_key="a",
                secret_key="s",
                region="us-west-2",
                bucket="",
            )

    def test_load_s3_config_from_env(self, monkeypatch):
        """环境变量加载配置（无配置文件时完全回退到环境变量）"""
        monkeypatch.setenv("S3_ACCESS_KEY", "env-ak")
        monkeypatch.setenv("S3_SECRET_ACCESS_KEY", "env-sk")
        monkeypatch.setenv("S3_REGION", "ap-northeast-1")
        monkeypatch.setenv("S3_ENDPOINT", "https://ep.example.com")
        monkeypatch.setenv("S3_BUCKET", "env-bucket")
        monkeypatch.setenv("S3_PREFIX_PATH", "prod")
        monkeypatch.setenv("S3_SIGNATURE_VERSION", "s3v4")

        config = load_s3_config()
        assert config.access_key == "env-ak"
        assert config.secret_key == "env-sk"
        assert config.region == "ap-northeast-1"
        assert config.bucket == "env-bucket"
        assert config.endpoint == "https://ep.example.com"
        assert config.prefix_path == "prod"

    def test_load_s3_config_env_overrides_file(self, monkeypatch, tmp_path):
        """环境变量覆盖配置文件中的同名字段"""
        # 创建临时 YAML 配置文件
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
s3:
  region: "us-east-1"
  bucket: "file-bucket"
  prefix_path: "file-prefix"
  signature_version: "s3v4"
""", encoding="utf-8")

        # mock _config_file_path 返回临时配置
        with patch("src.config.system_config._config_file_path", return_value=config_file):
            # 环境变量覆盖 access_key 和 endpoint
            monkeypatch.setenv("S3_ACCESS_KEY", "env-override-ak")
            monkeypatch.setenv("S3_SECRET_ACCESS_KEY", "file-sk")
            monkeypatch.setenv("S3_ENDPOINT", "https://env-endpoint.com")

            config = load_s3_config()
            assert config.access_key == "env-override-ak"  # 环境变量覆盖
            assert config.secret_key == "file-sk"           # 环境变量
            assert config.bucket == "file-bucket"            # 来自 YAML
            assert config.region == "us-east-1"              # 来自 YAML
            assert config.endpoint == "https://env-endpoint.com"  # 环境变量覆盖
            assert config.prefix_path == "file-prefix"       # 来自 YAML

    def test_load_s3_config_file_only(self, monkeypatch, tmp_path):
        """仅使用 YAML 配置文件（无环境变量）"""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
s3:
  access_key: "only-file-ak"
  secret_key: "only-file-sk"
  region: "eu-west-1"
  bucket: "only-bucket"
  endpoint: "https://file-endpoint.com"
  prefix_path: "only/prefix"
""", encoding="utf-8")

        # 清除环境变量干扰
        for key in ["S3_ACCESS_KEY", "S3_SECRET_ACCESS_KEY", "S3_BUCKET",
                     "S3_REGION", "S3_ENDPOINT", "S3_PREFIX_PATH", "S3_SIGNATURE_VERSION"]:
            monkeypatch.delenv(key, raising=False)

        with patch("src.config.system_config._config_file_path", return_value=config_file):
            config = load_s3_config()
            assert config.access_key == "only-file-ak"
            assert config.secret_key == "only-file-sk"
            assert config.region == "eu-west-1"
            assert config.bucket == "only-bucket"
            assert config.endpoint == "https://file-endpoint.com"
            assert config.prefix_path == "only/prefix"


# ── 2. 路径拼接测试 ───────────────────────────────────


class TestS3Key:
    """S3 key 拼接/解析测试"""

    def test_full_key_with_prefix(self, s3_boundary):
        """有 prefix_path 时拼接完整 key"""
        assert s3_boundary._full_key("output/result.json") == "local/output/result.json"

    def test_full_key_strips_leading_slash(self, s3_boundary):
        """去除传入 key 的前导斜杠"""
        assert s3_boundary._full_key("/output/result.json") == "local/output/result.json"

    def test_resolve_key_s3_path(self, s3_boundary):
        """s3:// 路径提取 key 段"""
        key = s3_boundary._resolve_key("s3://web-scraper/local/output/x.json")
        assert key == "local/output/x.json"

    def test_resolve_key_plain_key(self, s3_boundary):
        """普通 key 自动拼接 prefix"""
        key = s3_boundary._resolve_key("output/x.json")
        assert key == "local/output/x.json"

    def test_resolve_key_invalid_s3_path(self, s3_boundary):
        """无效 s3:// 路径抛异常"""
        with pytest.raises(S3Error, match="缺少 key"):
            s3_boundary._resolve_key("s3://web-scraper")

    def test_resolve_key_s3_path_no_endpoint(self, s3_boundary_no_endpoint):
        """无 endpoint 场景：s3:// 路径提取 key"""
        key = s3_boundary_no_endpoint._resolve_key("s3://web-scraper/local/output/x.json")
        assert key == "local/output/x.json"


# ── 3. upload / download / exists mock 测试 ──────────


class TestS3BoundaryMock:
    """S3Boundary 核心接口 mock 测试"""

    async def test_upload_text_returns_s3_path(self, s3_boundary, mock_boto_client):
        """上传文本返回 s3:// 路径"""
        path = await s3_boundary.upload("hello", "output/test.txt")
        assert path == "s3://web-scraper/local/output/test.txt"
        mock_boto_client.put_object.assert_called_once()
        call_kwargs = mock_boto_client.put_object.call_args.kwargs
        assert call_kwargs["Bucket"] == "web-scraper"
        assert call_kwargs["Key"] == "local/output/test.txt"
        assert call_kwargs["Body"] == b"hello"

    async def test_upload_bytes(self, s3_boundary, mock_boto_client):
        """上传字节内容"""
        path = await s3_boundary.upload(b"\x00\x01", "bin.dat")
        assert path == "s3://web-scraper/local/bin.dat"
        call_kwargs = mock_boto_client.put_object.call_args.kwargs
        assert call_kwargs["Body"] == b"\x00\x01"

    async def test_upload_error_wrapped(self, s3_boundary, mock_boto_client):
        """上传失败包装为 S3Error"""
        from botocore.exceptions import ClientError

        mock_boto_client.put_object.side_effect = ClientError(
            {"Error": {"Code": "AccessDenied", "Message": "denied"}},
            "PutObject",
        )
        with pytest.raises(S3Error, match="S3 上传失败"):
            await s3_boundary.upload("x", "a.txt")

    async def test_download_returns_bytes(self, s3_boundary, mock_boto_client):
        """下载返回字节内容"""
        body_mock = MagicMock()
        body_mock.read.return_value = b"downloaded"
        mock_boto_client.get_object.return_value = {"Body": body_mock}

        data = await s3_boundary.download("s3://web-scraper/local/output/x.txt")
        assert data == b"downloaded"
        mock_boto_client.get_object.assert_called_once_with(
            Bucket="web-scraper", Key="local/output/x.txt"
        )

    async def test_download_text_decodes(self, s3_boundary, mock_boto_client):
        """download_text 解码为字符串"""
        body_mock = MagicMock()
        body_mock.read.return_value = "中文内容".encode("utf-8")
        mock_boto_client.get_object.return_value = {"Body": body_mock}

        text = await s3_boundary.download_text("s3://web-scraper/local/x22.txt")
        assert text == "中文内容"

    async def test_download_not_found(self, s3_boundary, mock_boto_client):
        """下载不存在的对象抛 S3Error"""
        from botocore.exceptions import ClientError

        mock_boto_client.get_object.side_effect = ClientError(
            {"Error": {"Code": "NoSuchKey", "Message": "not found"}},
            "GetObject",
        )
        with pytest.raises(S3Error, match="S3 下载失败"):
            await s3_boundary.download("s3://web-scraper/local/missing.txt")

    async def test_download_file_saves_locally(self, s3_boundary, mock_boto_client, tmp_path):
        """download_file 调用 boto3 download_file"""
        dest = tmp_path / "out.txt"
        result = await s3_boundary.download_file(
            "s3://web-scraper/local/output/x.txt", str(dest)
        )
        assert result == str(dest)
        mock_boto_client.download_file.assert_called_once_with(
            Bucket="web-scraper", Key="local/output/x.txt", Filename=str(dest)
        )

    async def test_upload_file_missing_local(self, s3_boundary, tmp_path):
        """本地文件不存在抛 S3Error"""
        with pytest.raises(S3Error, match="本地文件不存在"):
            await s3_boundary.upload_file(tmp_path / "nope.txt", "x.txt")

    async def test_upload_file_success(self, s3_boundary, mock_boto_client, tmp_path):
        """upload_file 调用 boto3 upload_file"""
        local = tmp_path / "test.txt"
        local.write_text("hello s3")
        result = await s3_boundary.upload_file(str(local), "demo_test_file.txt")
        assert result == "s3://web-scraper/local/demo_test_file.txt"
        mock_boto_client.upload_file.assert_called_once_with(
            Filename=str(local), Bucket="web-scraper", Key="local/demo_test_file.txt"
        )

    async def test_upload_file_default_key_uses_filename(
        self, s3_boundary, mock_boto_client, tmp_path
    ):
        """upload_file 不传 object_key 时用本地文件名"""
        local = tmp_path / "myfile.txt"
        local.write_text("data")
        result = await s3_boundary.upload_file(str(local))
        assert result == "s3://web-scraper/local/myfile.txt"
        mock_boto_client.upload_file.assert_called_once_with(
            Filename=str(local), Bucket="web-scraper", Key="local/myfile.txt"
        )

    async def test_exists_true(self, s3_boundary, mock_boto_client):
        """对象存在"""
        mock_boto_client.head_object.return_value = {"ContentLength": 10}
        assert await s3_boundary.exists("s3://web-scraper/local/x.txt") is True

    async def test_exists_false(self, s3_boundary, mock_boto_client):
        """对象不存在"""
        from botocore.exceptions import ClientError

        mock_boto_client.head_object.side_effect = ClientError(
            {"Error": {"Code": "404", "Message": "Not Found"}},
            "HeadObject",
        )
        assert await s3_boundary.exists("s3://web-scraper/local/missing.txt") is False


# ── 4. 真实连通性测试（默认跳过）──────────────────────


@pytest.mark.live
class TestS3BoundaryLive:
    """真实 S3 连通性测试（需配置环境变量，默认跳过）。

    运行方式：pytest tests/test_boundaries/test_s3_boundary.py -m live -v
    前置条件：已设置 S3_ACCESS_KEY / S3_SECRET_ACCESS_KEY / S3_BUCKET 等环境变量。
    """

    @pytest.fixture(autouse=True)
    def _check_env(self):
        """无环境变量时跳过"""
        if not os.getenv("S3_ACCESS_KEY"):
            pytest.skip("未配置 S3 环境变量，跳过真实测试")

    async def test_live_round_trip(self):
        """真实上传 → 下载 → 存在性 → 兜底清理 完整链路

        上传/下载/exists 须通过；IAM 无删除权限，不测试 delete。
        """
        boundary = S3Boundary()
        key = "demo_test_file.txt"
        payload = "这是一段用来测试 S3 上传的 1223"

        try:
            # s3_path = f"s3://{boundary._config.bucket}/local/{key}"
            #
            # # 1. 上传
            # s3_path = await boundary.upload(payload, key)
            # assert s3_path == f"s3://{boundary._config.bucket}/local/{key}"

            # 2. 下载验证
            s3_path = "s3://web-scraper/local/page_content/www_tokyostarbank_co_jp_feature_education_trends_20240226_2_html/page.html"
            # text = await boundary.download_text(s3_path)
            await boundary.download_file(s3_path,"./page.html")
            # assert text == payload

            # 3. 存在性
            assert await boundary.exists(s3_path) is True
        finally:
            # 兜底清理（无权限也会安静失败）
            try:
                await boundary._client.delete_object(
                    Bucket=boundary._config.bucket,
                    Key=f"local/{key}",
                )
            except Exception:
                pass
"""S3 边界服务 — 基于 boto3 的对象存储客户端

提供文件上传（返回 S3 路径）与下载两个基础接口，供 storage 层、
爬取结果归档等场景使用。

设计要点：
  - 同步 boto3 客户端（boto3 本身为同步 SDK）；为避免阻塞事件循环，
    在异步上下文中通过 asyncio.to_thread 调用。
  - 配置由 S3Config 提供（环境变量加载），支持访问点（Access Point）端点：
    将 endpoint_url 设为访问点别名端点后，boto3 API 的 Bucket 参数直接传
    逻辑 bucket 名即可（已通过 scripts/amazon_s3_test.py 验证可正常上传/下载），
    无需提取或替换为访问点别名。
  - 上传时自动拼接 prefix_path 与传入 object_key，返回统一格式的
    "s3://{bucket}/{full_key}" 路径。
  - 删除操作因 IAM 账号无 s3:DeleteObject 权限，不再提供。
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import BotoCoreError, ClientError

from src.config.system_config import load_s3_config, S3Config

logger = logging.getLogger(__name__)

# S3 路径协议前缀
_S3_PATH_PREFIX = "s3://"


class S3Error(Exception):
    """S3 边界服务异常（统一包装 boto3 错误）"""


class S3Boundary:
    """S3 对象存储边界客户端

    封装 boto3 client，提供 upload / download 基础能力。
    所有方法均为 async（内部用 asyncio.to_thread 包裹同步调用）。
    """

    def __init__(self, config: S3Config | None = None):
        """
        Args:
            config: S3 配置，默认从环境变量加载
        """
        self._config = config or load_s3_config()
        self._client = self._build_client(self._config)

    # ── 客户端构建 ─────────────────────────────────────

    @staticmethod
    def _build_client(config: S3Config):
        """构建 boto3 S3 client"""
        boto_config = BotoConfig(
            signature_version=config.signature_version,
            region_name=config.region,
            retries={"max_attempts": 3, "mode": "standard"},
        )
        client_kwargs: dict = {
            "service_name": "s3",
            "aws_access_key_id": config.access_key,
            "aws_secret_access_key": config.secret_key,
            "config": boto_config,
        }
        if config.endpoint:
            # 访问点（Access Point）别名端点或自定义端点；
            # 访问点场景下 Bucket 参数仍传逻辑 bucket 名（见模块 docstring）
            client_kwargs["endpoint_url"] = config.endpoint
        return boto3.client(**client_kwargs)

    # ── 路径工具 ───────────────────────────────────────

    def _full_key(self, object_key: str) -> str:
        """拼接全局前缀，得到完整对象 key"""
        prefix = self._config.prefix_path.strip("/")
        key = object_key.lstrip("/")
        if prefix:
            return f"{prefix}/{key}"
        return key

    @staticmethod
    def _format_s3_path(bucket: str, full_key: str) -> str:
        """格式化返回的 S3 路径（用于人类阅读）"""
        return f"{_S3_PATH_PREFIX}{bucket}/{full_key}"

    def _resolve_key(self, path: str) -> str:
        """将输入路径解析为完整 S3 key（含 prefix_path）。

        - "s3://bucket/key" 形式：提取 key（其中已含 prefix，不再重复拼接）
        - 普通 key：自动拼接 prefix_path

        Returns:
            完整对象 key

        Raises:
            S3Error: s3:// 路径缺少 key 段
        """
        if path.startswith(_S3_PATH_PREFIX):
            body = path[len(_S3_PATH_PREFIX):]
            if "/" not in body:
                raise S3Error(f"无效的 S3 路径（缺少 key）: {path}")
            _, key = body.split("/", 1)
            return key
        return self._full_key(path)

    # ── 公共接口 ───────────────────────────────────────

    async def upload(self, content: str | bytes, object_key: str) -> str:
        """上传文本/字节内容到 S3，返回 S3 路径。

        Args:
            content: 文本或字节内容
            object_key: 对象 key（相对路径，会自动拼接 prefix_path）

        Returns:
            str: S3 路径，如 "s3://web-scraper/local/output/result.json"

        Raises:
            S3Error: 上传失败
        """
        full_key = self._full_key(object_key)
        body = content.encode("utf-8") if isinstance(content, str) else content
        bucket = self._config.bucket
        logger.info(f"上传到 S3: bucket={bucket}, key={full_key}, size={len(body)} bytes")
        try:
            await asyncio.to_thread(
                self._client.put_object,
                Bucket=bucket,
                Key=full_key,
                Body=body,
            )
        except (BotoCoreError, ClientError) as e:
            logger.error(f"S3 上传失败: key={full_key}, error={e}")
            raise S3Error(f"S3 上传失败: {e}") from e
        return self._format_s3_path(bucket, full_key)

    async def upload_to_path(self, content: str | bytes, s3_path: str) -> str:
        """上传内容到指定的 S3 路径（覆盖写），返回 S3 路径。

        与 upload() 的区别：upload() 接受相对 key 并自动拼接 prefix_path，
        本方法接受完整的 s3:// 路径（或已含 prefix 的 key），直接解析后写入，
        不会再拼接 prefix_path。适用于覆盖已存在对象的场景（如动态爬取合并后回写）。

        Args:
            content: 文本或字节内容
            s3_path: S3 路径（"s3://bucket/key"）或已含 prefix 的 key

        Returns:
            str: S3 路径

        Raises:
            S3Error: 上传失败
        """
        full_key = self._resolve_key(s3_path)
        body = content.encode("utf-8") if isinstance(content, str) else content
        bucket = self._config.bucket
        logger.info(f"覆盖上传到 S3: bucket={bucket}, key={full_key}, size={len(body)} bytes")
        try:
            await asyncio.to_thread(
                self._client.put_object,
                Bucket=bucket,
                Key=full_key,
                Body=body,
            )
        except (BotoCoreError, ClientError) as e:
            logger.error(f"S3 覆盖上传失败: key={full_key}, error={e}")
            raise S3Error(f"S3 上传失败: {e}") from e
        return self._format_s3_path(bucket, full_key)

    async def upload_file(self, local_path: str | Path, object_key: str | None = None) -> str:
        """上传本地文件到 S3，返回 S3 路径。

        Args:
            local_path: 本地文件路径
            object_key: 对象 key，默认用本地文件名（含 prefix_path）

        Returns:
            str: S3 路径

        Raises:
            S3Error: 本地文件不存在或上传失败
        """
        local = Path(local_path)
        if not local.is_file():
            raise S3Error(f"本地文件不存在: {local_path}")
        key = object_key or local.name
        full_key = self._full_key(key)
        bucket = self._config.bucket
        logger.info(f"上传本地文件到 S3: {local} → bucket={bucket}, key={full_key}")
        try:
            await asyncio.to_thread(
                self._client.upload_file,
                Filename=str(local),
                Bucket=bucket,
                Key=full_key,
            )
        except (BotoCoreError, ClientError) as e:
            logger.error(f"S3 上传文件失败: {local}, error={e}")
            raise S3Error(f"S3 上传文件失败: {e}") from e
        return self._format_s3_path(bucket, full_key)

    async def download(self, s3_path: str) -> bytes:
        """下载 S3 对象内容。

        Args:
            s3_path: S3 路径（"s3://bucket/key"）或相对 key

        Returns:
            bytes: 对象内容（字节）

        Raises:
            S3Error: 下载失败或对象不存在
        """
        key = self._resolve_key(s3_path)
        bucket = self._config.bucket
        logger.info(f"从 S3 下载: bucket={bucket}, key={key}")
        try:
            response = await asyncio.to_thread(
                self._client.get_object,
                Bucket=bucket,
                Key=key,
            )
            return response["Body"].read()
        except (BotoCoreError, ClientError) as e:
            logger.error(f"S3 下载失败: {s3_path}, error={e}")
            raise S3Error(f"S3 下载失败: {e}") from e

    async def download_text(self, s3_path: str, encoding: str = "utf-8") -> str:
        """下载 S3 对象并解码为文本"""
        body = await self.download(s3_path)
        return body.decode(encoding)

    async def download_file(self, s3_path: str, local_path: str | Path) -> str:
        """下载 S3 对象到本地文件。

        Args:
            s3_path: S3 路径
            local_path: 本地保存路径

        Returns:
            str: 本地文件路径

        Raises:
            S3Error: 下载失败
        """
        key = self._resolve_key(s3_path)
        bucket = self._config.bucket
        local = Path(local_path)
        local.parent.mkdir(parents=True, exist_ok=True)
        logger.info(f"从 S3 下载到本地: {s3_path} → {local}")
        try:
            await asyncio.to_thread(
                self._client.download_file,
                Bucket=bucket,
                Key=key,
                Filename=str(local),
            )
        except (BotoCoreError, ClientError) as e:
            logger.error(f"S3 下载文件失败: {s3_path}, error={e}")
            raise S3Error(f"S3 下载文件失败: {e}") from e
        return str(local)

    async def exists(self, s3_path: str) -> bool:
        """判断 S3 对象是否存在

        Args:
            s3_path: S3 路径或相对 key

        Returns:
            bool: 存在返回 True，对象不存在返回 False

        Raises:
            S3Error: head_object 调用失败（非 404 异常）
        """
        key = self._resolve_key(s3_path)
        bucket = self._config.bucket
        try:
            await asyncio.to_thread(
                self._client.head_object,
                Bucket=bucket,
                Key=key,
            )
            return True
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("404", "NoSuchKey"):
                return False
            logger.error(f"S3 head_object 失败: {s3_path}, error={e}")
            raise S3Error(f"S3 检查存在失败: {e}") from e
        except BotoCoreError as e:
            raise S3Error(f"S3 检查存在失败: {e}") from e

    async def generate_presigned_url(self, s3_path: str, expires: int = 3600) -> str:
        """为 S3 对象生成预签名 GET URL（临时可访问链接）。

        用于附件/图片下载场景：返回的 URL 在 expires 秒内可直接访问，
        无需调用方持有 AWS 凭据。

        Args:
            s3_path: S3 路径（"s3://bucket/key"）或相对 key
            expires: URL 有效期（秒），默认 1 小时

        Returns:
            str: 预签名 GET URL

        Raises:
            S3Error: 生成失败
        """
        key = self._resolve_key(s3_path)
        bucket = self._config.bucket
        try:
            url = await asyncio.to_thread(
                self._client.generate_presigned_url,
                "get_object",
                Params={"Bucket": bucket, "Key": key},
                ExpiresIn=expires,
            )
            return url
        except (BotoCoreError, ClientError) as e:
            logger.error(f"S3 生成预签名 URL 失败: {s3_path}, error={e}")
            raise S3Error(f"S3 生成预签名 URL 失败: {e}") from e

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G9 租户切换菜单数据增强（{@code GET /auth/memberships}）集成测试：
 * tenant_type/roles/is_owner/is_current/last_opened_at/tenant_created_at + 刷新语义（登录/切换刷、refresh 不刷）。
 */
class TenantSwitchMenuIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("access_token").toString();
    }

    private String adminPost(String url, String body) throws Exception {
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + login("admin", "admin123"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk()).andReturn();
        return JsonUtils.toJson(unwrapData(res.getResponse().getContentAsString()));
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> memberships(String token) throws Exception {
        MvcResult res = mockMvc.perform(get("/api/v1/auth/memberships")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk()).andReturn();
        return (List<Map<String, Object>>) unwrapData(res.getResponse().getContentAsString()).get("memberships");
    }

    private Map<String, Object> rowOf(List<Map<String, Object>> rows, String tenantId) {
        return rows.stream().filter(r -> tenantId.equals(r.get("tenant_id"))).findFirst()
                .orElseThrow(() -> new AssertionError("未找到租户行 " + tenantId));
    }

    /** SUSPENDED 成员不出现在切换菜单（2026-11-06：与 switch-tenant 403 口径对齐）。 */
    @Test
    void suspendedMembershipIsHiddenFromMenu() throws Exception {
        String admin = login("admin", "admin123");
        // hermetic（2026-11-09 修复隐性顺序依赖）：给 operator 先造第二个 ACTIVE 成员关系——
        // 登录解析 = 默认 ACTIVE → 兜底其它 ACTIVE，suspend 掉唯一成员关系会 401，与本测试意图无关；
        // 全量套件靠前置用例的残留数据侥幸通过，单跑/子集跑必失败。
        String fallbackTenant = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                "{\"tenant_code\":\"g9fb\",\"tenant_name\":\"G9 Fallback\",\"app_codes\":[\"parlant-agent-server\"],\"owner_user_id\":\"u-1001\"}"),
                Map.class).get("tenant_id").toString();
        String msId = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id='tenant-org-a' AND user_id='u-1001'",
                String.class).trim();
        mockMvc.perform(post("/api/v1/admin/members/" + msId + "/suspend")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
        String token = login("operator", "op123");
        String body = mockMvc.perform(get("/api/v1/auth/memberships")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        org.assertj.core.api.Assertions.assertThat(body).doesNotContain("tenant-org-a")
                .contains(fallbackTenant); // 兜底租户仍在菜单
        // 恢复（共享库）
        mockMvc.perform(post("/api/v1/admin/members/" + msId + "/restore")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
    }

    @Test
    void membershipsExposeMenuFieldsAndRefreshDoesNotTouchLastOpenedAt() throws Exception {
        // ① 造数据：新用户 g9user → 租户 T2（owner）+ 租户 T3（普通成员无角色）
        String uid = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                "{\"username\":\"g9user\",\"email\":\"g9@unify.local\",\"password\":\"" + b64("Passw0rd!") + "\"}"),
                Map.class).get("user_id").toString();
        String t2 = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                "{\"tenant_code\":\"g9-t2\",\"tenant_name\":\"G9 T2\","
                        + "\"app_codes\":[\"parlant-agent-server\"],\"owner_user_id\":\"" + uid + "\"}"),
                Map.class).get("tenant_id").toString();
        String t3 = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                "{\"tenant_code\":\"g9-t3\",\"tenant_name\":\"G9 T3\",\"app_codes\":[\"parlant-agent-server\"]}"),
                Map.class).get("tenant_id").toString();
        adminPost("/api/v1/admin/members",
                "{\"tenant_id\":\"" + t3 + "\",\"user_id\":\"" + uid + "\",\"role_ids\":[]}");

        // ② 登录（初始打开 T2）→ 菜单字段
        String g9 = login("g9user", "Passw0rd!");
        List<Map<String, Object>> rows = memberships(g9);
        Map<String, Object> r2 = rowOf(rows, t2);
        assertThat(r2.get("tenant_type")).isEqualTo("ORGANIZATION");
        assertThat((List<String>) r2.get("roles")).contains("TenantAdmin"); // owner 角色
        assertThat(r2.get("is_owner")).isEqualTo(true);
        assertThat(r2.get("is_current")).isEqualTo(true);      // 默认成员 = 当前
        assertThat(r2.get("last_opened_at")).isNotNull();       // 登录已刷
        assertThat(r2.get("tenant_created_at")).isNotNull();    // 租户创建时间
        assertThat(r2.get("joined_at")).isNotNull();
        Map<String, Object> r3 = rowOf(rows, t3);
        assertThat(r3.get("roles")).isEqualTo(List.of());       // 无角色
        assertThat(r3.get("is_owner")).isEqualTo(false);
        assertThat(r3.get("is_current")).isEqualTo(false);
        assertThat(r3.get("last_opened_at")).isNull();          // 未打开过

        // ③ 切换 T3 → is_current 翻转 + last_opened_at 刷新
        String t3Membership = r3.get("membership_id").toString();
        MvcResult sw = mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + g9)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"membership_id\":\"" + t3Membership + "\"}"))
                .andExpect(status().isOk()).andReturn();
        String switched = unwrapData(sw.getResponse().getContentAsString()).get("access_token").toString();
        String switchedRefresh = unwrapData(sw.getResponse().getContentAsString()).get("refresh_token").toString();

        List<Map<String, Object>> afterSwitch = memberships(switched);
        assertThat(rowOf(afterSwitch, t3).get("is_current")).isEqualTo(true);
        assertThat(rowOf(afterSwitch, t2).get("is_current")).isEqualTo(false);
        Object t3LastOpened = rowOf(afterSwitch, t3).get("last_opened_at");
        assertThat(t3LastOpened).isNotNull();

        // ④ 静默刷新不刷 last_opened_at（值保持不变）
        MvcResult refreshed = mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"" + switchedRefresh + "\"}"))
                .andExpect(status().isOk()).andReturn();
        String newAccess = unwrapData(refreshed.getResponse().getContentAsString()).get("access_token").toString();
        List<Map<String, Object>> afterRefresh = memberships(newAccess);
        assertThat(rowOf(afterRefresh, t3).get("last_opened_at")).isEqualTo(t3LastOpened);
    }
}

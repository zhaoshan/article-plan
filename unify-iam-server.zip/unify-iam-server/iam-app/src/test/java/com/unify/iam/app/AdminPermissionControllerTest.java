package com.unify.iam.app;

import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.AdminPermissionController;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.config.WebMvcConfig;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import com.unify.iam.authorization.infra.persistence.po.PermissionPO;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(AdminPermissionController.class)
@Import({GlobalExceptionHandler.class, WebMvcConfig.class, ManagementAuthorizationInterceptor.class})
class AdminPermissionControllerTest {
    @Autowired private MockMvc mvc;
    @MockitoBean private PermissionRepository permissions;
    @MockitoBean private JwtSigner signer;
    @MockitoBean private AuditLogRepository auditLogs;

    @Test
    void sharedCatalogExposesStringGrantabilityAndApplicationGroupingForTenantTrees() throws Exception {
        when(signer.verify("t")).thenReturn(claims(List.of("iam:role:read")));
        when(permissions.listActive()).thenReturn(List.of(
                permission("tenant", "iam:role:write", 1),
                permission("platform", "iam:user:write", 0),
                permission("unset", "iam:legacy", null)));

        mvc.perform(get("/api/v1/admin/permissions").header("Authorization", "Bearer t"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(3))
                .andExpect(jsonPath("$.data.permissions[0].permission_id").value("tenant"))
                .andExpect(jsonPath("$.data.permissions[0].permission_code").value("iam:role:write"))
                .andExpect(jsonPath("$.data.permissions[0].permission_name").value("Manage role"))
                .andExpect(jsonPath("$.data.permissions[0].resource_type").value("IAM"))
                .andExpect(jsonPath("$.data.permissions[0].app_code").value("iam"))
                .andExpect(jsonPath("$.data.permissions[0].category").value("Role"))
                .andExpect(jsonPath("$.data.permissions[0].tenant_grantable").value("1"))
                .andExpect(jsonPath("$.data.permissions[1].tenant_grantable").value("0"))
                .andExpect(jsonPath("$.data.permissions[2].tenant_grantable").value("0"));
    }

    @Test
    void memberReadAloneDoesNotAuthorizeTheRolePermissionCatalog() throws Exception {
        when(signer.verify("t")).thenReturn(claims(List.of("iam:member:read")));
        mvc.perform(get("/api/v1/admin/permissions").header("Authorization", "Bearer t"))
                .andExpect(status().isForbidden());
        verifyNoInteractions(permissions);
    }

    private PermissionPO permission(String id, String code, Integer grantable) {
        PermissionPO permission = new PermissionPO();
        permission.setPermissionId(id);
        permission.setPermissionCode(code);
        permission.setPermissionName("Manage role");
        permission.setResourceType("IAM");
        permission.setAppCode("iam");
        permission.setCategory(" Role ");
        permission.setTenantGrantable(grantable);
        return permission;
    }

    private JwtClaims claims(List<String> permissions) {
        long now = Instant.now().getEpochSecond();
        return new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"),
                "u-1", "tenant-org-a", "ms-1", List.of(), permissions, Map.of(),
                now + 3600, now, "permission-catalog", 0L);
    }
}

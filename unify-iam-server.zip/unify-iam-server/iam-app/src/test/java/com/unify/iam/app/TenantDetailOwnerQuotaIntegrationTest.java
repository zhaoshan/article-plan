package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.common.util.SecureToken;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * Tenant details drawer contracts: enterprise-only management creation, real usage/quota data,
 * owner transfer, and purpose-aware invitation acceptance.
 */
class TenantDetailOwnerQuotaIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult result = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64(password)))))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(result.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminToken() throws Exception {
        return login("admin", "admin123");
    }

    private Map<String, Object> adminPost(String path, Object body, String token) throws Exception {
        MvcResult result = mockMvc.perform(post(path)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return unwrapData(result.getResponse().getContentAsString());
    }

    private String createUser(String username, String email, String token) throws Exception {
        return adminPost("/api/v1/admin/users", Map.of(
                "username", username, "email", email, "password", b64("Passw0rd!")), token)
                .get("user_id").toString();
    }

    private String createTenant(String code, String name, String ownerUserId, String token) throws Exception {
        Map<String, Object> request = ownerUserId == null
                ? Map.of("tenant_code", code, "tenant_name", name, "app_codes", List.of("parlant-agent-server"))
                : Map.of("tenant_code", code, "tenant_name", name, "owner_user_id", ownerUserId,
                        "app_codes", List.of("parlant-agent-server"));
        return adminPost("/api/v1/admin/tenants", request, token).get("tenant_id").toString();
    }

    private String addMember(String tenantId, String userId, String token) throws Exception {
        return adminPost("/api/v1/admin/members", Map.of("tenant_id", tenantId, "user_id", userId), token)
                .get("membership_id").toString();
    }

    @Test
    void platformCreatesOnlyEnterpriseTenantsAndDetailContainsAuthoritativeUsage() throws Exception {
        String token = adminToken();
        String ownerId = createUser("drawer_owner", "drawer-owner@unify.local", token);
        // 2026-11-03：details usage 与 GET /usage 口径对齐（租户已启用应用的维度）——parlant 无配额维度，
        // 改用 imorph 租户使 usage 断言有意义（iam 维度不再无条件出现）
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_code", "drawer-enterprise",
                                "tenant_name", "Drawer Enterprise", "owner_user_id", ownerId,
                                "app_codes", java.util.List.of("imorph")))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();

        assertThat(jdbcTemplate.queryForObject(
                "SELECT tenant_type FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo("ORGANIZATION");
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_status\":\"SUSPENDED\"}"))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_code", "drawer-personal-rejected",
                                "tenant_name", "Rejected", "tenant_type", "PERSONAL",
                                "app_codes", List.of("parlant-agent-server")))))
                .andExpect(status().isBadRequest());

        mockMvc.perform(get("/api/v1/admin/tenants/" + tenantId + "/details")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenant.tenant_type").value("ORGANIZATION"))
                .andExpect(jsonPath("$.data.owner_assigned").value(true))
                .andExpect(jsonPath("$.data.owner.user_id").value(ownerId))
                .andExpect(jsonPath("$.data.owner.email").value("drawer-owner@unify.local"))
                .andExpect(jsonPath("$.data.members.total").value(1))
                // 2026-10-30/11-03 口径：有效席位（有角色且非 Owner）owner-only 租户=0；
                // used = 有效 0 + 未接受邀请 1（owner_user_id 直选分支的通知邀请）= 1
                .andExpect(jsonPath("$.data.usage.dimensions[?(@.dimension_key == 'members')].used_count")
                        .value(org.hamcrest.Matchers.hasItem(1)))
                .andExpect(jsonPath("$.data.usage.dimensions[?(@.dimension_key == 'members')].active_count")
                        .value(org.hamcrest.Matchers.hasItem(0)))
                .andExpect(jsonPath("$.data.usage.dimensions[?(@.dimension_key == 'members')].pending_count")
                        .value(org.hamcrest.Matchers.hasItem(1)))
                // imorph 维度有默认上限（10）→ limited=true（旧 iam 维度对非 iam 租户才恒 false）
                .andExpect(jsonPath("$.data.usage.dimensions[?(@.dimension_key == 'members')].limited")
                        .value(org.hamcrest.Matchers.hasItem(true)))
                .andExpect(jsonPath("$.data.usage.dimensions[?(@.dimension_key == 'apps')].used_count")
                        .value(org.hamcrest.Matchers.hasItem(1)));
    }

    @Test
    void boundedMemberQuotaReservesSeatsForMembersAndInvitations() throws Exception {
        String token = adminToken();
        String ownerId = createUser("quota_owner", "quota-owner@unify.local", token);
        String memberId = createUser("quota_member", "quota-member@unify.local", token);
        // G1 口径（2026-10-28 产品决策）：配额跟随租户已启用应用——imorph 租户用 imorph 维度施压，
        // iam 全局维度仅显式启用 iam 应用的租户适用（邀请链路单路径化后统一按此口径强制）。
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_code", "quota-enterprise",
                                "tenant_name", "Quota Enterprise", "owner_user_id", ownerId,
                                "app_codes", java.util.List.of("imorph")))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        String imorphMembers = jdbcTemplate.queryForObject(
                "SELECT dimension_id FROM gateway_quota_dimension WHERE app_code='imorph' AND dimension_key='members'",
                String.class).trim();

        // 同事端点（/quotas/{dimensionKey}）：iam 维度覆盖——成员加入仍被它拦截
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/quotas/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"limit_value\":1}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.limit_value").value(1))
                // 展示口径（2026-11-03）：有效席位排除 Owner(0) + 未接受邀请 pending(1：owner 通知邀请)
                // → used=1 → remaining=0
                .andExpect(jsonPath("$.data.remaining").value(0))
                .andExpect(jsonPath("$.data.limited").value(true));
        // 我方端点（/usage/{dimensionId}）：imorph 维度覆盖——强制口径=非 Owner 成员（owner-only 租户=0），
        // 压 0 使「used(0) >= limit(0)」拦住下一次邀请/加成员
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + imorphMembers)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"limit_value\":0}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.limit").value(0))
                .andExpect(jsonPath("$.data.override").value(true));

        mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", tenantId, "user_id", memberId))))
                .andExpect(status().isBadRequest());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", tenantId, "email", "quota-invite@unify.local"))))
                .andExpect(status().isBadRequest());

        // 两侧都复位后成员加入放行
        mockMvc.perform(delete("/api/v1/admin/tenants/" + tenantId + "/quotas/members")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                // 2026-11-03：/quotas 现解析到租户启用应用的 imorph 维度——清除覆盖后回落其默认上限 10（仍 limited）
                .andExpect(jsonPath("$.data.limited").value(true))
                .andExpect(jsonPath("$.data.limit_value").value(10));
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + imorphMembers)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.override").value(false));
        addMember(tenantId, memberId, token);
    }

    @Test
    void existingMemberOwnerTransferGrantsTargetAndStepsFormerOwnerDown() throws Exception {
        String token = adminToken();
        String formerOwnerId = createUser("transfer_former", "transfer-former@unify.local", token);
        String targetUserId = createUser("transfer_target", "transfer-target@unify.local", token);
        String tenantId = createTenant("owner-transfer", "Owner Transfer", formerOwnerId, token);
        String targetMembershipId = addMember(tenantId, targetUserId, token);
        String formerMembershipId = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id=? AND user_id=?", String.class,
                tenantId, formerOwnerId);

        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("mode", "EXISTING_MEMBER",
                                "membership_id", targetMembershipId))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("OWNER_CHANGED"))
                .andExpect(jsonPath("$.data.owner_user_id").value(targetUserId));

        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo(targetUserId);
        Integer targetOwnerRoles = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_role r ON r.role_id=mr.role_id "
                        + "WHERE mr.membership_id=? AND r.scope_id=? AND r.role_code='TenantAdmin' "
                        + "AND mr.delete_flag=0 AND r.delete_flag=0",
                Integer.class, targetMembershipId, tenantId);
        Integer formerOwnerRoles = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_role r ON r.role_id=mr.role_id "
                        + "WHERE mr.membership_id=? AND r.scope_id=? AND r.role_code='TenantAdmin' "
                        + "AND mr.delete_flag=0 AND r.delete_flag=0",
                Integer.class, formerMembershipId, tenantId);
        assertThat(targetOwnerRoles).isEqualTo(1);
        // G3 我方语义（docs/08 §6）：parlant TenantAdmin 是 owner 即 admin 同角色 → 旧 Owner 卸角色让位
        assertThat(formerOwnerRoles).isZero();

        mockMvc.perform(get("/api/v1/admin/tenants/" + tenantId + "/details")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.owner.user_id").value(targetUserId));
    }

    @Test
    void ownerEmailInviteAllowedInLogModeAndCreatesPendingInvitation() throws Exception {
        // 统一语义（docs/08 §15）：开关关 = dev 日志模式，Owner 邮件邀请照常创建（邮件落日志，E2E 免 SMTP）；
        // 「开闸未配齐 → 503 零落库」由 MemberInvitationGateIntegrationTest 覆盖，
        // 「开闸 SMTP 失败 → 503 回滚」由 EnterpriseTenantOwnerInvitationIntegrationTest 覆盖。
        String token = adminToken();
        String ownerId = createUser("mail_owner", "mail-owner@unify.local", token);
        String tenantId = createTenant("mail-disabled", "Mail Disabled", ownerId, token);

        mockMvc.perform(post("/api/v1/admin/tenants/" + tenantId + "/owner")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("mode", "INVITE_BY_EMAIL", "email", "incoming-owner@unify.local"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("OWNER_INVITATION_SENT"));

        Integer invitations = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE tenant_id=? AND invitation_purpose='OWNER_TRANSFER'",
                Integer.class, tenantId);
        assertThat(invitations).isEqualTo(1);
    }

    @Test
    void acceptedOwnerTransferInvitationPromotesMatchingAccount() throws Exception {
        String token = adminToken();
        String formerOwnerId = createUser("accept_former", "accept-former@unify.local", token);
        String tenantId = createTenant("accept-owner-transfer", "Accepted Owner Transfer", formerOwnerId, token);
        String operatorId = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE username='operator'", String.class);
        String operatorEmail = jdbcTemplate.queryForObject(
                "SELECT primary_email FROM gateway_user WHERE username='operator'", String.class);
        String rawToken = "owner-transfer-accept-token";
        jdbcTemplate.update("INSERT INTO gateway_invitation "
                        + "(invitation_id, tenant_id, email, invite_type, invitation_purpose, invitation_status, "
                        + "delivery_status, invite_token_hash, invited_by_user_id, expires_at, delete_flag, create_by, update_by) "
                        + "VALUES (?, ?, ?, 'EMAIL', 'OWNER_TRANSFER', 'PENDING', 'DELIVERED', ?, ?, ?, 0, 'test', 'test')",
                "owner-transfer-accept-001", tenantId, operatorEmail, SecureToken.hash(rawToken), formerOwnerId,
                LocalDateTime.now().plusDays(1));

        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken + "/accept")
                        .header("Authorization", "Bearer " + login("operator", "op123")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"));

        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo(operatorId);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT invitation_status FROM gateway_invitation WHERE invitation_id='owner-transfer-accept-001'",
                String.class)).isEqualTo("ACCEPTED");
        Integer auditCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_audit_log WHERE tenant_id=? "
                        + "AND event_type='OWNER_TRANSFER_INVITATION_ACCEPTED'",
                Integer.class, tenantId);
        assertThat(auditCount).isEqualTo(1);
    }
}

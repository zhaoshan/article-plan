package com.unify.iam.app.adapter.controller;

import com.nimbusds.jose.jwk.RSAKey;
import com.unify.iam.api.constant.ClaimConstants;
import com.unify.iam.api.dto.jwks.Jwk;
import com.unify.iam.api.dto.jwks.JwksResponse;
import com.unify.iam.app.security.RsaKeyManager;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * JWKS 端点：暴露 RS256 公钥（kid 标识）。
 *
 * <p>parlant GatewayProvider 的 {@code PyJWKClient} 拉取并按 kid 缓存（lifespan=300s），
 * 故响应头加 {@code Cache-Control: public, max-age=300} 与之对齐。
 */
@RestController
public class JwksController {

    private final RsaKeyManager keyManager;

    public JwksController(RsaKeyManager keyManager) {
        this.keyManager = keyManager;
    }

    @GetMapping(value = "/.well-known/jwks.json", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<JwksResponse> jwks() {
        RSAKey publicKey = keyManager.signingKey().toPublicJWK();
        // nimbus 10.x：getModulus/getPublicExponent 返回 Base64URL（JWK 的 n/e 即 Base64URL 编码）
        Jwk jwk = Jwk.of(
                publicKey.getKeyType().getValue(),
                publicKey.getKeyID() != null ? publicKey.getKeyID() : ClaimConstants.DEFAULT_KID,
                publicKey.getModulus().toString(),
                publicKey.getPublicExponent().toString(),
                ClaimConstants.ALG_RS256,
                "sig");
        return ResponseEntity.ok()
                .cacheControl(CacheControl.maxAge(300, TimeUnit.SECONDS).cachePublic())
                .body(new JwksResponse(List.of(jwk)));
    }
}

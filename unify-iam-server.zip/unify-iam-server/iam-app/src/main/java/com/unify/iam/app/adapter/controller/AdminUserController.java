package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateUserRequest;
import com.unify.iam.api.dto.admin.UpdateUserRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminUserService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * IAM 管理面：用户 CRUD（docs/04 §3.2，iam:user:*）。受 `/api/v1/admin/**` 拦截器保护。
 */
@RestController
@RequestMapping("/api/v1/admin/users")
public class AdminUserController {

    private final UserRepository userRepository;
    private final AdminUserService adminUserService;
    private final AuditService auditService;

    public AdminUserController(UserRepository userRepository,
                               AdminUserService adminUserService,
                               AuditService auditService) {
        this.userRepository = userRepository;
        this.adminUserService = adminUserService;
        this.auditService = auditService;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_USER_READ)
    public Map<String, Object> list(@RequestParam(name = "limit", defaultValue = "20") int limit) {
        List<Map<String, String>> users = userRepository.search(limit).stream().map(this::toBrief).toList();
        auditService.audit().event("ADMIN_LIST_USERS").actor(CurrentAuth.claims().userId())
                .target("USER", "").result("SUCCESS").write(Map.of("count", users.size()));
        return Map.of("users", users, "count", users.size());
    }

    @GetMapping("/{userId}")
    @RequirePermission(PermissionCodes.IAM_USER_READ)
    public Map<String, String> detail(@PathVariable String userId) {
        return toBrief(userRepository.findByUserId(userId)
                .orElseThrow(() -> AuthException.notFound("用户不存在")));
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_USER_WRITE)
    public Map<String, String> create(@Valid @RequestBody CreateUserRequest request) {
        String userId = adminUserService.create(request);
        auditService.audit().event("ADMIN_CREATE_USER").actor(CurrentAuth.claims().userId())
                .target("USER", userId).result("SUCCESS").write(Map.of("username", request.username()));
        return Map.of("user_id", userId);
    }

    @PutMapping("/{userId}")
    @RequirePermission(PermissionCodes.IAM_USER_WRITE)
    public Map<String, String> update(@PathVariable String userId,
                                      @Valid @RequestBody UpdateUserRequest request) {
        adminUserService.update(userId, request);
        auditService.audit().event("ADMIN_UPDATE_USER").actor(CurrentAuth.claims().userId())
                .target("USER", userId).write(Map.of());
        return Map.of("user_id", userId);
    }

    @DeleteMapping("/{userId}")
    @RequirePermission(PermissionCodes.IAM_USER_WRITE)
    public Map<String, String> delete(@PathVariable String userId) {
        adminUserService.delete(userId);
        auditService.audit().event("ADMIN_DELETE_USER").actor(CurrentAuth.claims().userId())
                .target("USER", userId).result("SUCCESS").write(null);
        return Map.of("user_id", userId);
    }

    private Map<String, String> toBrief(UserPO u) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("user_id", u.getUserId());
        m.put("username", u.getUsername());
        m.put("email", u.getPrimaryEmail());
        m.put("status", u.getUserStatus());
        return m;
    }
}

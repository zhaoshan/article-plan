# 03. E2E-2：企业 SSO 与组织接入（P2）

> 状态：**已实施完成（OIDC 首期，P2）**（2026-10-08）。实现与测试记录见本文「附录 A」。SAML 后置、域名验证 UI / 审批流 / switch-tenant 属后续阶段（见 `docs/04-E2E3-P3管理面与账号生命周期设计`）。
> 依据：《Gateway 权限体系架构设计》§12 第二阶段、§7.2（企业 SSO 登录与角色同步）；E2E-1 范围 §2.2 / §8（延后 E2E-2，**只换认证来源，令牌管线不动**）；阶段拆分见 `docs/01-总体设计与功能模块拆分.md` 第二部分。
> 定位：本文件是 P2 的独立详细设计；E2E-1 已完成 P1，本阶段在其基础上叠加**认证接入域**。

---

## 1. 目标（一句话）

**接入企业 IdP（OIDC 先行），让企业用户经 SSO 登录 → IAM 完成 claim/group 映射与 JIT 入租户 → 复用既有令牌签发管线产出与 E2E-1 完全同构的 claims → parlant 授权结果不变。**

并兼容**平台级个人账号登录**（Gmail / 微软个人号等消费者账号）。

## 2. 范围

### 2.1 做（P2 范围）

| 域 | 内容 |
|---|---|
| 认证接入域 | `gateway_tenant_idp_config`、`gateway_idp_group_mapping` 落库（Flyway V3） |
| OIDC 登录（首期） | Authorization Code + PKCE → 回调验签（IdP JWKS）→ issuer/aud 校验 → claim 映射 → 查找/创建 `gateway_user_identity`（provider_type=OIDC） |
| JIT 入租户 | 首登自动建用户 + membership；按域名路由已有租户，或新建租户（企业自助接入 / 个人 PERSONAL 租户） |
| group→role | `gateway_idp_group_mapping` 白名单映射 → 同步 `gateway_membership_role` |
| 平台级个人账号 | 平台级 Google / Microsoft OAuth 客户端 → 个人账号（Gmail/MSA）登录；**JIT 为每人建独立 PERSONAL 租户**（架构 §7.1 场景 A，见 §8.1） |
| 本地账号并存 | 本地密码登录保留，一个用户可多 identity |

### 2.2 不做（延后）

- **SAML**（协议不同，复用同一 `Authenticator` 抽象，后置）。
- 租户管理 UI / 邀请 / 域名验证完整化 → P3。
- 数据策略 attrs 消费（`gateway_idp_data_scope_mapping` 可顺带建表，消费在 P5）。
- 多因素 / refresh token → P3。
- 加入申请审批流与多租户切换端点 → P3（契约与生命周期见 §8.1）。

---

## 3. 认证来源可插拔（核心解耦：只换认证来源，令牌管线不动）

把 E2E-1 的 `IdentityVerificationService`（本地密码，硬编码）抽象为 **`Authenticator` 接口**：

```
Authenticator.authenticate(凭证) ──▶ UserPrincipal{ userId, username, userIdentityId }
        │
        ├── LocalPasswordAuthenticator   （现有逻辑迁入；username/password → BCrypt 校验）
        ├── OidcAuthenticator            （OIDC 回调凭证 → IdP 验签/映射 → find-or-create identity）
        └── SamlAuthenticator            （后置；断言验签 → 同上）
```

三种实现都产出 `UserPrincipal` → 之后全部走既有 **`TokenService.issueFor`（零改动）**：
`membership → RBAC → claims → sign`。这就是"只换认证来源，令牌管线不重写"。

- `Authenticator` 装配点：新增 `AuthenticationService`（按登录入口选择实现），或由 `iam-app` 组合层按端点注入。
- 职责边界：`Authenticator` 只负责"认证 + 产出身份"，**授权仍由 RBAC 解析**（E2E-1 不变）。

### 3.1 `OidcAuthenticator` 内部步骤（细化）

```
1. 回调入参 code + state
2. state 校验（与发起时存储比对，见 §5.2）→ 不符拒绝
3. client 换 token：POST IdP token_endpoint（grant_type=authorization_code + code + code_verifier）
4. 解析 ID Token：JWKS 验签（kid 选钥）→ 校验 alg∈{RS256,ES256} / iss / aud / exp / nonce
5. claim 映射（§5.3）→ 提取 email / sub / name / groups / email_verified
6. find-or-create gateway_user_identity（幂等，§6.2）→ 返回 UserPrincipal
```

---

## 4. 数据模型与 Flyway V3

### 4.1 `gateway_tenant_idp_config`（字段级）

| 字段 | 说明 |
|---|---|
| `tenant_idp_config_id` / `tenant_id` | 主键；**企业 SSO 挂 ORGANIZATION 租户**；平台级 consumer IdP 预留 PLATFORM 作用域（见 §4.4） |
| `protocol` / `provider_key` / `display_name` | OIDC / keycloak·google·microsoft·okta·auth0·custom / 前端展示名 |
| `issuer` / `discovery_uri` / `jwk_set_uri` | OIDC issuer、discovery、JWKS 地址 |
| `authorization_endpoint` / `token_endpoint` / `userinfo_endpoint` | 可经 discovery 自动发现，亦可显式覆盖 |
| `client_id` / `client_secret_cipher` | 客户端凭据；secret 加密存储（§11.3） |
| `scopes_json` | `["openid","email","profile","groups"]` |
| `claim_mapping_json` | 外部 claim → 内部字段映射（§4.2） |
| `allowed_domains_json` | 允许使用该 IdP 的邮箱域名白名单（§4.2） |
| `pkce_required` / `email_verified_required` | 默认 1 / 0 |
| `jit_provisioning_enabled` / `default_join_policy` | JIT 开关 / 首登默认加入策略（AUTO_JOIN / REQUEST / INVITE_ONLY） |
| `metadata_xml` | SAML 专用（后置） |

### 4.2 JSON 配置 schema（claim_mapping / allowed_domains）

`claim_mapping_json` —— **内部字段 → 外部 claim 名**：

```json
{
  "email": "email",
  "name": "name",
  "sub": "sub",
  "groups": "groups",
  "email_verified": "email_verified"
}
```

- `sub` 默认取 ID Token 标准 `sub`；自定义 issuer 可映射到其它 claim。
- `groups` 可缺省（无组映射的 IdP）；映射值按 §7 处理。
- 实现约定：映射表中的外部 claim 名若缺失，对应内部字段留空并**按安全策略决定是否拒绝**（关键字段 email/sub 缺失 → 401）。

`allowed_domains_json`：

```json
["org-a.com", "org-a.cn"]
```

- 用于域名路由（JIT）与"使用该 IdP 的邮箱后缀"校验；空数组 = 不限制（仅平台级 consumer 允许）。

### 4.3 V3 迁移与 seed

- `V3__sso_tables.sql`：`gateway_tenant_idp_config`、`gateway_idp_group_mapping` 两张表（源 DDL）。
- `V4__seed_sso_dev.sql`（联调 seed，仅 local/test）：
  - `tenant-org-a` 挂 Keycloak IdP：`provider_key=keycloak`、issuer/discovery/jwks 指向 `http://localhost:8099/realms/org-a`（Keycloak §9.2）。
  - `gateway_idp_group_mapping`：`agent-operators → AgentOperator`（EXACT，priority=100）。
  - client_secret 用 Keycloak 联调值（`ENC(...)` 或 dev 明文标记 `DEV_ONLY`）。

### 4.4 平台级 consumer IdP 承载

`gateway_tenant_idp_config.tenant_id` 以租户为主键，需补"平台级 IdP"承载方式——预留 **PLATFORM 作用域**（`tenant_id='PLATFORM'`）承载 SaaS 自己的 Google/Microsoft OAuth 客户端；JIT 时按 §8.1 建 PERSONAL 租户。

**单配置假设（现状）**：`findActiveOidcByTenant(PLATFORM)` 当前按「取唯一一条 ACTIVE OIDC 配置」实现——**同一时刻平台级个人登录只支持一个 IdP**（Google 或微软，二选一）；插两行会撞 selectOne 抛错。

**多提供商扩展路径（后续）**：若个人登录需同时支持 Google + 微软，
1. PLATFORM 下允许多条 ACTIVE OIDC 配置（`findActiveOidcByTenant` 改查 LIST）；
2. `authorize` 支持按提供商选择：`authorize?tenant_id=PLATFORM&provider_key=google|microsoft`（或 `idp_config_id=...`）；
3. 前端登录 hub（docs/05）从配置动态列出个人入口。
> 「共享平台级 IdP」= 所有个人用户共用同一种接入，不意味着只能有一个提供商。

---

## 5. OIDC 协议与回调端点设计

### 5.1 端点清单

| 端点 | 说明 |
|---|---|
| `GET /api/v1/auth/oidc/authorize?tenant_id=org-a`（或 `idp_config_id`） | 发起 SSO：校验租户 IdP 配置 → 生成 state + nonce + PKCE → 302 跳 IdP authorization_endpoint |
| `GET /api/v1/auth/oidc/callback?code=..&state=..` | IdP 回调：state 校验 → 换 token → 验 ID Token → claim 映射 → JIT → 签发 → 302 回前端（§13.1） |
| `GET /api/v1/auth/oidc/logout`（预留） | 登出（后端 IdP 会话登出，P3 完善） |

### 5.2 state + nonce + PKCE（临时存储方案，E2E-1 无 Redis）

| 机制 | 防什么 | 存储/校验 |
|---|---|---|
| **state** | CSRF（回调伪造） | 发起时生成随机 state，回调时比对；存储见下 |
| **nonce** | 重放 | 放入 ID Token 的 nonce claim，验签后比对 |
| **PKCE code_challenge** | 授权码被截获后换 token | `S256` challenge；code_verifier 服务端暂存 |

**临时存储方案（无 Redis）**：内存 `ConcurrentHashMap<String, OidcAuthSession>`（state → {nonce, code_challenge, idpConfigId, tenantId, createdAt}）+ 过期清理（TTL 10 分钟 + 定时/惰性清理）。
- 单实例可用；**多实例部署时切换 Redis/DB**（P3 与 refresh token 一并引入 Redis 则迁移）。
- 不落库的原因：会话态短暂、敏感度低（只承载进行中的登录）；回调失败即清除。

### 5.3 claims 提取规则（细化）

1. **数据源**：优先 **ID Token**（OIDC 规范、已验签）；仅当需要 ID Token 没有的属性时才调 userinfo（多数 IdP ID Token 已含 email/profile）。
2. **sub 唯一性**：同一 IdP（provider_key + issuer）下 sub 唯一 → `gateway_user_identity` 唯一键 `(provider_type, provider_key, issuer, subject)` 兜底（§6.2 幂等）。
3. **email 规范化**：trim + lowercase 后写 `primary_email` / `email_at_idp`。
4. **email_verified**：`email_verified_required=1` 时强制 `email_verified=true`，否则 401。
5. **groups**：取映射后的 groups claim；无则空集（§7）。
6. **关键字段缺失**（email / sub）→ 401（不落身份），防脏数据。

### 5.4 回调错误处理

| 场景 | 处理 |
|---|---|
| state 不匹配 / 过期 | 401，清除会话态，不落身份 |
| code 已用 / 换 token 失败 | 401 + 明确 detail |
| ID Token iss/aud/exp/alg 不符 | 401（§11.1） |
| IdP 不可达 / JWKS 拉取失败 | **503 降级**（不崩，提示稍后再试） |
| email 域名不在 allowed_domains | 403（该域不允许使用此 IdP） |

---

## 6. SSO 登录与 JIT 流程（决策树）

### 6.1 JIT 决策树（细化）

```
ID Token 已验证 → 提取 claims(email/sub/groups)
→ ① find-or-create gateway_user_identity（provider_key+issuer+sub）
    ├─ 命中 → 取 gateway_user
    └─ 未命中 → JIT 建 user + identity（§6.2 幂等）
→ ② 定位租户
    ├─ 企业 SSO（租户级 IdP）：
    │   按 email 域名 → 查 gateway_tenant.primary_domain / gateway_tenant_domain
    │   ├─ 命中已有 ORGANIZATION 租户 → 查 membership
    │   │   ├─ 有 → 复用
    │   │   └─ 无 → 按 join_policy：
    │   │       ├─ DOMAIN_AUTO_JOIN → 直接建 membership(ACTIVE)
    │   │       ├─ DOMAIN_REQUEST   → 建 gateway_join_request(PENDING)，本次不放行（待审批，P3）
    │   │       └─ INVITE_ONLY      → 拒绝（需先被邀请）
    │   └─ 未命中 → 企业自助接入：先域名验证（§6.3），通过后 JIT 新建租户，首人成 Owner
    └─ 平台级个人登录 → 默认/PERSONAL 租户（命中已有 personal 或新建），Owner（§8.1）
→ ③ group→role 同步（§7）
→ ④ TokenService.issueFor 签发
```

**JIT 字段赋值**：
- `gateway_user`：`username`=email 前缀（冲突则 email）、`primary_email`=email、`user_status=ACTIVE`、`registration_source=SSO|JIT`、`default_tenant_id`=命中/新建租户。
- `gateway_user_identity`：`provider_type=OIDC`、`provider_key`、`issuer`、`subject`、`login_name`=email、`email_at_idp`、`identity_status=ACTIVE`、`claims_json`=裁剪后的 claims 快照（审计/排障）。
- `gateway_membership`：`join_source=SSO|JIT`、`membership_status=ACTIVE`、`is_default` 按 `default_tenant_id` 策略。

### 6.2 JIT 并发幂等

- 两次并发首登同一用户 → `gateway_user_identity` 唯一键 `(provider_type, provider_key, issuer, subject)` 兜底。
- 实现：**先查后插 + 唯一键约束 + 冲突回查复用**（`INSERT ... ON DUPLICATE KEY` 或 catch DuplicateKeyException 后重查）；membership `uk(tenant_id, user_id)` 同理。
- 目标：JIT 是**幂等**的——重复首登不产生重复用户/成员，返回同一 `UserPrincipal`。

### 6.3 企业自助接入的域名验证先决条件

- 新建租户前**必须先验证域名归属**（`gateway_tenant_domain` + `gateway_tenant_domain_challenge`：DNS_TXT / HTTP_FILE / EMAIL），防止任意域 JIT 建租户被滥用（架构 §11.1）。
- P2 首期可先做"命中已有租户"的 JIT；"未命中 → 自助建租户"依赖域名验证流程（P3 完整化 UI），P2 先留接缝。

---

## 7. group→role 同步语义

- **计算**：登录时按 `gateway_idp_group_mapping`（EXACT/REGEX + priority）把 IdP groups 白名单映射为内部角色。
- **同步策略：覆盖式全量同步（IDP_SYNC）**：
  - 以本次 IdP 组为准，重算应得角色；
  - 应得 = 既有 IDP_SYNC 角色 ∪ 本次新增（幂等 upsert）；
  - **移除**本次不再命中的 IDP_SYNC 角色（防僵尸角色）；
  - **`grant_source=DIRECT` 的手工授予不回收**（与 IDP_SYNC 分层）。
- **变更传播**：每次登录实时重算、**无缓存**——IdP 组变更后下次登录即生效（与 E2E-1 验收#7 一致）。
- 竞态：组同步与并发登录在 membership_role 唯一键 `(membership_id, role_id)` 兜底。

---

## 8. 平台级个人账号登录（Gmail / 微软个人号）vs 租户级企业 SSO

协议相同（OIDC），**差异在 IdP 配置作用域与租户路由规则**：

| | 企业 SSO（租户级 IdP） | 平台级个人账号登录（consumer） |
|---|---|---|
| IdP 配置挂载 | ORGANIZATION 租户 | 平台级（PLATFORM 作用域） |
| 客户端 | 该企业自己的 IdP 应用 | SaaS 自己的 Google/Microsoft OAuth 应用 |
| 租户路由 | email 域名 → 该租户，JIT 加入/新建 | 默认 / PERSONAL 租户 |
| group→role | 企业组 → 内部角色（白名单） | 一般不映射组 |
| 典型 IdP | Google Workspace / Entra ID / Okta | Google 个人（External）/ Microsoft MSA |

### 8.1 个人租户、加入申请与多租户切换（生命周期）

个人账号（consumer）登录后，数据模型天然支持「一人一 PERSONAL 租户 → 后续申请加入企业租户 → 多租户切换」（架构 §7.1 场景 A + `gateway_join_request` + 多 membership）：

```
consumer 首次 Gmail 登录
  └─ JIT：gateway_user + user_identity(OIDC) + PERSONAL 租户(tenant-p-*) + membership(Owner, is_default=1)
  └─ 登录返回：默认 token(个人租户) + user.tenants[] = [{个人租户}]

用户想加入企业租户 org-a（邮箱域名命中或主动发现）
  ├─ join_policy=DOMAIN_AUTO_JOIN  → 域名自动加入（免审批）
  ├─ join_policy=DOMAIN_REQUEST    → 发起 gateway_join_request(PENDING) → 管理员审批
  └─ join_policy=INVITE_ONLY       → 只能走 gateway_invitation 邀请
     └─ 审批/邀请通过 → 建 gateway_membership(org-a, 默认角色) → 下次登录 tenants[] 含 org-a

多租户切换（令牌仍是「单租户」语义）
  ├─ 登录/SSO 成功 → 默认 token（is_default 租户）+ user.tenants[]（该用户全部 membership）
  └─ 用户选择某租户 → POST /api/v1/auth/switch-tenant { membership_id }
                  → 校验该 membership 归属当前用户 → 复用 TokenService.issueFor 重签
                  → 新 token 的 tenantId / membershipId / roles / permissions = 目标租户
```

关键设计：

1. **令牌保持「单租户」语义**：JWT 只承载当前激活的 membership（`tenantId` + `membershipId`），不与 parlant 契约冲突（parlant 从 claims 读 tenantId）；不把多个租户塞进一个 token。
2. **switch-tenant 复用签发管线**：只是换一个 membership 再走 `TokenService.issueFor`，令牌管线零改动（延续"只换上下文、不重写管线"的解耦原则）。
3. **PERSONAL 租户仅限 consumer 登录**：企业 SSO 用户直接进企业租户，不建个人租户。
4. **审批后角色**：申请通过默认角色 = 申请时指定 / 租户默认角色 / 审批人选，落 `gateway_membership_role`。
5. **默认租户**：`default_tenant_id` / `is_default` 决定下次登录默认进哪个租户，切换时可"设为默认"。

> **阶段归属**：JIT 建 PERSONAL 租户在 **P2**；`gateway_join_request` 申请 + 审批、`switch-tenant` 端点、
> 登录响应 `user.tenants[]`、登录页多租户选择在 **P3**（见 `docs/01-总体设计与功能模块拆分.md` §9 P3）。

---

## 9. account linking（身份绑定）

**场景**：SSO 邮箱命中已有本地密码账号（用户之前用密码登录过）。

**策略（默认不自动绑定，防邮箱冒充/账号接管）**：

| 情形 | 处理 |
|---|---|
| 命中本地账号且本地已有密码 | **不自动绑定**：SSO 首登建独立 OIDC identity（不合并）；或要求用户先本地登录后手动绑定（P3 UI + 绑定验证） |
| 命中本地账号但本地无密码（纯 SSO 域） | 可自动绑定（邮箱 + email_verified=true 为充分证据） |
| 无命中 | 正常 JIT 建新用户 |

- 一个用户可多 identity（LOCAL + OIDC 并存），登录来源决定认证路径；绑定后 `UserPrincipal` 指向同一 `userId`，后续 claims 合并。
- 绑定/合并属**高安全敏感操作**，需审计（`gateway_audit_log`，P3 起步）。

---

## 10. 常见 OIDC 接入方式

OIDC 是统一协议，`gateway_tenant_idp_config` 配好 discovery/jwks/client/claim_mapping 后，同一套 `OidcAuthenticator` 全兼容：

| IdP | 授权端点 | JWKS / issuer | 接入要点 |
|---|---|---|---|
| Google | `accounts.google.com/o/oauth2/v2/auth` | `googleapis.com/oauth2/v3/certs`，issuer=`accounts.google.com` | Cloud Console 建 OAuth Web client；User type=External → **任意 Google 账号（含 @gmail.com 个人）**；Internal 可限 Workspace |
| Microsoft | `login.microsoftonline.com/{authority}/v2.0/...`（`.well-known` 发现） | 每租户动态 issuer | App registration；authority=`common`（工作+个人）/ `consumers`（仅个人 MSA）/ `organizations`（仅工作） |
| Keycloak | 自托管标准 OIDC | realm 内 | **本地联调首选**（Testcontainers），后续无缝换真 IdP |
| Okta / Auth0 | 标准 OIDC | 标准 | 商业 IdP |
| GitHub 个人 | — | — | ⚠️ 非标准 OIDC（无 ID token），不走本套，需单独处理或不用 |

---

## 11. 安全约束与硬落地（架构 §11.1）

1. claim 映射**必须显式配置**（`claim_mapping_json`），不隐式信任任意 claim。
2. group→role 映射**必须白名单**（`gateway_idp_group_mapping`），不允许外部组直接映射任意内部角色。
3. `allowed_domains_json` 限制可使用该 IdP 的邮箱域名；`email_verified_required` 可按需开启。
4. JIT 按域名路由租户时校验域名归属（§6.3）。

### 11.1 ID Token 验签与算法白名单

- 仅接受 `alg ∈ {RS256, ES256}`（**显式白名单，拒绝 `none` / HS 系**，防算法混淆）。
- 校验 `iss == configured issuer`、`aud` 含本 client_id、`exp` 未过期、`nonce` 匹配。
- IdP JWKS 按 `kid` 选钥；未知 kid 回源重拉。

### 11.2 IdP JWKS 缓存与轮换

- 缓存 IdP 公钥（如 TTL 5 分钟 + 未知 kid 强制回源），与 parlant `PyJWKClient(lifespan=300)` 同一策略。
- 轮换：新 kid 出现 → 回源拉取；旧 key 缓存短窗口（存量 ID Token 短时，无长尾）。

### 11.3 client_secret 加密

- `client_secret_cipher` 用加密存储（jasypt `ENC(...)`，与 ai-chat-insight 一致）；生产用环境变量/密钥管理注入，不落明文。
- Keycloak 联调 seed 用 dev 值并显式标记 `DEV_ONLY`。

---

## 12. 联调环境与 Keycloak 操作手册

### 12.1 两级联调策略

1. **Keycloak（Testcontainers / docker，首选）**：本地/CI 可重复，可编程建 realm/用户/组/claims，
   完全可控地模拟企业 IdP 与 JIT 数据（alice@org-a.com + group `agent-operators` → `AgentOperator`）。
2. **云端免费开发者版（可选，验证公网真链路）**：Okta Developer / Auth0 免费档 / Azure AD B2C 免费档 /
   Google OAuth（External）。免费档限额以官网为准。

### 12.2 Keycloak 本地联调（docker，端口 8099）— 具体步骤

**① 启动 Keycloak**（`start-dev` 便于本地；dev 模式不强制 HTTPS）

```bash
docker run -d --name iam-kc \
  -p 8099:8080 \
  -e KEYCLOAK_ADMIN=admin -e KEYCLOAK_ADMIN_PASSWORD=admin \
  quay.io/keycloak/keycloak:latest start-dev
```

**② 登录 Admin Console**：`http://localhost:8099` → Administration Console → `admin/admin`

**③ 建 realm（模拟一个"企业 IdP 租户"）**
- 左侧 **Realm → Create realm** → Realm name=`org-a` → Create

**④ 建 client（OIDC 应用，对应 IAM 回调）**
- **Clients → Create client** → Client ID=`iam`，**Client authentication=ON**（要拿 client_secret）→ Next
- **Standard flow=ON**（Authorization Code）→ Save
- Client → **Settings**：Valid redirect URIs=`http://localhost:8090/api/v1/auth/oidc/callback`
  （IAM 的回调端点；若浏览器用 `127.0.0.1` 访问，redirect 也要写 `http://127.0.0.1:8090/...`）
- Client → **Credentials**：复制 **Client secret**（IAM 的 `client_secret_cipher` 用）

**⑤ 建用户（模拟企业成员，邮箱后缀=企业域）**
- **Users → Create user**：username=`alice`、email=`alice@org-a.com`、**Email verified=ON** → Create
- 再进入该用户 → **Credentials → Set password**：`alice123`、**Temporary=OFF**
- （同理建 `bob@org-a.com`，用于域名路由 / 多成员 / 403 场景）

**⑥ 建组并映射 claims（测 group→role）**
- **Groups → Create group**：`agent-operators`；Users → alice → **Group membership** → join `agent-operators`
- 让 ID Token 携带 `groups` claim：**Client scopes → Create client scope** → name=`groups` →
  **Add mapper → Group Membership** → Token Claim Name=`groups`、**Add to ID token=ON**、Add to access token=OFF → Save
- 回到 Client → **Client scopes** → 把 `groups` scope 加入 **Assigned client scopes（Default）**

**⑦ 取 discovery / JWKS（IAM 配置的来源）**
```bash
curl -s http://localhost:8099/realms/org-a/.well-known/openid-configuration
curl -s http://localhost:8099/realms/org-a/protocol/openid-connect/certs   # IdP JWKS
```

**⑧ IAM 侧配置（V4 seed 写入 `gateway_tenant_idp_config`，scoped 到租户 org-a）**
- `protocol=OIDC`、`provider_key=keycloak`、`issuer=http://localhost:8099/realms/org-a`
- `discovery_uri=.../.well-known/openid-configuration`、`jwk_set_uri=.../certs`
- `client_id=iam`、`client_secret_cipher=ENC(...)`（加密存储）
- `claim_mapping_json`：`{ "email": "email", "sub": "sub", "name": "name", "groups": "groups" }`
- `allowed_domains_json=["org-a.com"]`、`pkce_required=1`、`jit_provisioning_enabled=1`、`default_join_policy=DOMAIN_AUTO_JOIN`
- `gateway_idp_group_mapping`：`agent-operators → AgentOperator`

**⑨ 浏览器全链路验证**
- 访问 IAM SSO 入口（如 `GET /api/v1/auth/oidc/authorize?tenant_id=org-a`）→ 302 跳 Keycloak
- Keycloak 登录 `alice@org-a.com / alice123` → 同意 → 回调 IAM → 验签 + JIT → 签发 token
- `GET /api/v1/auth/me` 断言 claims：`sub`=alice 的 userId、`tenantId`=tenant-org-a（域名命中）、
  `roles` 含 `AgentOperator`（group 映射）、`attrs={}`

**⑩ 边界用例验证**
- 未登录访问受保护接口 → 401；改 callback `code`/`state` 重放 → 拒绝；IdP 不可达 → 503 降级不崩

### 12.3 Testcontainers / CI（脚本化、可重复）

- Java 侧用 `org.testcontainers:keycloak` 的 `KeycloakContainer`，**realm 导入文件**秒级起停：
  ```java
  static KeycloakContainer KC = new KeycloakContainer("quay.io/keycloak/keycloak:latest")
          .withRealmImportFile("test-realm.json");   // 从 12.2 配置好的 Keycloak 导出的 realm JSON
  ```
- **realm JSON 获取**：本地按 12.2 配好后，Admin Console → Realm settings → **Action → Partial export**（导出用户/组/客户端配置，测试用）；client secret 含于 JSON 的 `clients[].secret`。
- **或完全脚本化（不用 UI）**：Keycloak Admin REST（`/admin/realms`）在测试前置脚本里建 realm/client/用户/组/mapper：
  ```bash
  TOKEN=$(curl -s -X POST http://localhost:8099/realms/master/protocol/openid-connect/token \
    -d client_id=admin-cli -d username=admin -d password=admin -d grant_type=password | jq -r .access_token)
  curl -s -X POST http://localhost:8099/admin/realms -H "Authorization: Bearer $TOKEN" \
    -H 'Content-Type: application/json' -d '{"realm":"org-a","enabled":true}'
  # clients / users / groups / client-scopes(mapper) 同理
  ```
- 生产**不要**复用测试导出的 realm JSON/secret；用环境变量/密钥管理注入。

### 12.4 云端免费开发者版（可选）

- 配置方式与 Keycloak 完全一致（discovery/jwks/client/claim_mapping），仅 issuer/端点换成对应 IdP。
- Okta：Developer 控制台 → Applications → Create App Integration → OIDC Web → redirect 同 IAM 回调；Groups 声明可在 Authorization Server 配置。
- Microsoft：App registration → Authentication → Web redirect；authority 用 `common`（测个人 MSA）或具体租户（测工作账号）。
- 免费档限额以官网为准。

---

## 13. 前端与契约扩展

### 13.1 SSO 入口承载（parlant BFF vs IAM 直连）

- **SSO 必须浏览器直连 IAM**：回调是浏览器 302 跳转，无法走 parlant BFF（JSON 代理）——这与 E2E-1 本地密码登录走 BFF（`/api/auth/login`）不同。
- 分工：
  - 本地密码 → parlant BFF 转发 IAM `/api/v1/auth/token`（E2E-1 现状，保留）。
  - **企业 SSO → parlant web 提供「企业 SSO 登录」入口 → 跳 IAM `/authorize` → IdP → 回调 → IAM 302 回 parlant web**。
- **token 回传形态**（需在实现时锁定，倾向）：
  - dev：回调后 302 回 web 登录页，`?access_token=<jwt>`（短时 query，符合项目"query 传 ASCII"约定）；
  - 生产：HttpOnly cookie（`access_token`）或短时一次性 code 由 BFF 兑换。

### 13.2 登录响应契约扩展（`user.tenants[]`，向后兼容）

```json
{
  "access_token": "...", "token_type": "bearer", "expires_in": 7200,
  "user": {
    "user_id": "u-1001", "user_name": "alice",
    "roles": ["AgentOperator"], "permissions": ["agent:read", "..."],
    "tenants": [
      { "tenant_id": "tenant-p-xxx", "tenant_name": "Alice 的个人空间", "tenant_type": "PERSONAL",
        "membership_id": "ms-1001", "is_default": true,  "roles": ["Owner"] },
      { "tenant_id": "tenant-org-a", "tenant_name": "Org A", "tenant_type": "ORGANIZATION",
        "membership_id": "ms-2001", "is_default": false, "roles": ["AgentOperator"] }
    ]
  }
}
```

- **兼容性**：E2E-1 的 `user` 对象字段不变，`tenants[]` 为新增可选字段（parlant 旧前端不受影响）。
- `POST /api/v1/auth/switch-tenant` 请求 `{ "membership_id": "ms-2001" }` → 返回与登录同构的 `LoginResponse`（新 token 绑定该租户）。

---

## 14. P2 测试用例矩阵

### 14.1 单元测试

| 层 | 用例 | 期望 |
|---|---|---|
| claim 映射 | email 大小写/空白规范化、sub 提取、groups 缺失 | 正确映射；关键字段缺失 → 401 |
| ID Token 校验 | iss/aud/exp/alg 白名单/nonce 逐个错误 | 拒绝 |
| state/非ce | 回调 state 不符、nonce 不符 | 拒绝、不落身份 |
| JIT 决策 | 域名命中已有租户 / 未命中 / 个人→PERSONAL | 正确分支 + 字段赋值 |
| group→role | 白名单 EXACT/REGEX、覆盖式同步、DIRECT 保留 | 应得角色正确、僵尸角色移除、DIRECT 不回收 |
| 并发幂等 | 两次 JIT 同用户 | 唯一键兜底，同一 UserPrincipal |

### 14.2 集成测试（Testcontainers Keycloak，端到端）

| 用例 | 步骤 | 期望 |
|---|---|---|
| 完整 OIDC 流 | authorize → Keycloak 登录 alice → callback → JIT | 签发 token；/me 的 claims 与 E2E-1 同构（tenantId/roles/perms） |
| 域名路由 | alice@org-a.com 命中 tenant-org-a | membership 复用/新增正确 |
| JIT 新建租户 | 新域 user（如 carol@org-b.com） | 新建 ORGANIZATION 租户 + 首人 Owner（域名验证先决） |
| 个人账号 | consumer 登录（Google 模拟） | 建 PERSONAL 租户 + Owner |
| group→role 生效 | alice 在 Keycloak 加/减组 → 重登 | roles 立即变化（验收#7 同构） |
| 本地账号回归 | 本地密码登录 | 不回归 |

### 14.3 契约与负向

- **契约**：claims 与 E2E-1 比对（sub/tenantId/membershipId/roles/permissions/attrs）；parlant 验签复用 E2E-1 的仿真/真实 PyJWKClient 路径。
- **负向**：code 复用拒绝、issuer/aud 错 401、alg 混淆拒绝、IdP 不可达 503、email 域名不在白名单 403。

---

## 15. 退出标准

- [ ] 企业用户经 IdP SSO 登录 → 产出与 E2E-1 **完全同构**的 claims（iss/aud/sub/tenantId/membershipId/roles/permissions/attrs）
- [ ] **JIT**：首登自动建用户 + membership +（按域名）加入已有租户或新建租户；域名无对应租户时新建租户且首人成 Owner
- [ ] **group→role**：IdP 组按白名单映射内部角色；变更后重新登录授权立即变化（与 E2E-1 验收#7 一致）
- [ ] 平台级个人账号（Gmail/MSA）登录成功，落入默认/PERSONAL 租户（P2）
- [ ] 本地账号登录回归通过；一个用户多 identity 并存
- [ ] 并发 JIT 幂等：重复首登不产生重复用户/成员
- [ ] 安全负向：state 重放 / code 复用 / iss·aud·alg 不符 / IdP 不可达 均按 §5.4 / §11 拒绝或降级
- [ ] parlant 切 `AUTH_MODE=gateway` 后，用 SSO 登录拿到的令牌走通 E2E 验收 1–7（路由代码零改动）

> 多租户申请与切换（个人加入企业租户、`switch-tenant`、登录页租户选择）属 P3，不在 P2 验收范围（见 §8.1）。

## 16. 集成坑与风险

- **Microsoft `common` 的 issuer 是每用户动态值**：验 iss 需容忍（接受该 authority 下任一 tenant issuer）或改验 aud。
- **Google External vs Internal**：要"任意 Google 账号"选 External；只要本组织选 Internal。
- **JIT 建租户的域名验证**：企业自助接入必须先做域名归属验证（`gateway_tenant_domain_challenge`，P3 完整化），防止任意域 JIT 建租户被滥用。
- **客户端密钥**：`client_secret_cipher` 需加密存储（接入密钥管理，勿明文）；生产用 `IAM_*` 环境变量注入。
- **state/nonce/PKCE 临时存储**：无 Redis 用内存 + TTL；多实例部署前必须迁移 Redis/DB（P3）。
- **回调 token 回传**：dev 用 query 短时代码、生产 HttpOnly cookie，需在 §13.1 实现时锁定。
- **IdP 选型**：Keycloak 联调基线不依赖任何免费档；云端免费档限额以官网为准。

---

# 附录 A：E2E-2 实现记录（P2）

> 状态：**已实施完成**（2026-10-08）。单元 + 集成测试全绿。概述：落地认证接入域（OIDC），**只换认证来源，令牌签发管线（`TokenService.issueFor`）零改动**。

## A.1 实现范围

| 交付 | 说明 |
|---|---|
| Flyway V3 | `gateway_tenant_idp_config`、`gateway_idp_group_mapping` 两张表 |
| OIDC 登录全流程 | `authorize`（state/nonce/PKCE + 跳转 IdP）、`callback`（换 token → 验 ID Token → JIT → 组映射 → 签发） |
| JIT 入租户 | find-or-create identity + 域名路由 / 新建租户（企业 ORGANIZATION / consumer PERSONAL），幂等 |
| group→role | IdP 组白名单映射 → 覆盖式同步 `IDP_SYNC` 角色（`DIRECT` 保留） |
| 认证可插拔 | `Authenticator` 抽象（`LocalPasswordAuthenticator` / `OidcAuthenticator`） |

## A.2 新增文件

```
iam-app/resources/db/migration/V3__sso_tables.sql
iam-identity/.../po/{IdpConfigPO,IdpGroupMappingPO} + mapper + repository
iam-tenant/.../repository/{TenantRepository, MembershipRepository.create/findByTenantAndUser}
iam-identity/.../repository/{UserRepository.create/updateDefaultTenant, UserIdentityRepository.findByProvider/create}
iam-authorization/.../app/service/RoleSyncService.java
iam-app/.../oidc/{OidcProviderConfig,OidcProviderConfigService,OidcProviderClient,OidcAuthSession(+Store),VerifiedClaims,JitProvisioner,OidcSsoService}.java
iam-app/.../security/OidcIdTokenVerifier.java
iam-app/.../authenticator/{Authenticator,LocalPasswordAuthenticator,OidcAuthenticator}.java
iam-app/.../adapter/controller/OidcController.java
（IamProperties 增 iam.oidc.*）
```

## A.3 端点（对外契约，与 E2E-1 令牌同构）

| 端点 | 行为 |
|---|---|
| `GET /api/v1/auth/oidc/authorize?tenant_id=xxx` | 302 跳 IdP 授权端点（带 state/nonce/PKCE） |
| `GET /api/v1/auth/oidc/callback?code=&state=` | 换 token → 验 ID Token → JIT → 组映射 → 签发；`Accept: application/json` 返回 `LoginResponse`，否则 302 回前端 `?access_token=` |
| 错误 | state 无效 401、域名不在白名单 403、iss/aud/alg/exp/nonce 不符 401、IdP 不可达 503 |

## A.4 测试（全绿）

- **单元**：`OidcIdTokenVerifierTest`（验签/篡改/iss/aud/exp/alg/nonce/kid）、`OidcAuthSessionStoreTest`、`JitProvisionerTest`（域名路由/建租户/consumer/INVITE_ONLY/白名单/幂等）、`RoleSyncServiceTest`（覆盖式同步/DIRECT 保留）。
- **集成**（Testcontainers MySQL + **内置 Mock OIDC Provider**，见 `support/MockOidcProvider`）：完整 OIDC 流+域名路由+group→AgentOperator；企业新域建 ORGANIZATION 租户；consumer 建 PERSONAL 租户；重复登录幂等；负向（非法域名 403 / state 无效 401）。
- **回归**：E2E-1（`IamFlowIntegrationTest`）本地密码登录不受影响。

## A.5 集成测试环境

- **Mock OIDC Provider**（`support/MockOidcProvider.java`）：独立 JDK HttpServer（随机端口），提供 discovery/jwks/authorize/token，签 RS256 ID Token（可配 subject/email/groups/issuer/exp）——真实驱动 IAM 的 `OidcSsoService` 全链路，无外网/无镜像。
- **Keycloak 人工联调**：本地起 Keycloak 建 realm 验证真 IdP（见 §12.2），可用 `V4__seed_sso_keycloak_dev.sql` 预置配置。

## A.6 与正文的对应与取舍

- **OIDC 客户端按规范实现**（Authorization Code + PKCE + ID Token 验签），只换 IdP 即可接 Google/Microsoft/Okta/Keycloak。
- **临时态用内存**（单实例可用；多实例迁移 Redis 见 §5.2）。
- **JIT 新建租户**首期不建角色（令牌带该租户但权限为空），域名验证流程留 P3 接缝。
- **`gateway_join_request` 审批流 / `switch-tenant` / 登录响应 `user.tenants[]`** 属 P3（docs/01 §9），P2 只实现 SSO + JIT + 组映射。
- **联调已知修正**：`TenantRepository` 按非唯一列（primary_domain/owner+type）选租户改用 `LIMIT 1`（避免多行时 `selectOne` 抛 500）；`NoResourceFoundException` 兜底返回 404 而非 500。

## A.7 快速验证（本地 + Mock provider 需测试外启动）

```bash
# 1. 起 IAM（默认 local profile，连 127.0.0.1:3306/unify_iam）
cd iam-app && mvn spring-boot:run
# 2. 需先有 ACTIVE 的 gateway_tenant_idp_config 指向某个 OIDC provider（Keycloak 见 §12.2 / V4 seed）
# 3. 浏览器访问 SSO 入口：
#    http://localhost:8090/api/v1/auth/oidc/authorize?tenant_id=tenant-org-a
#    用 IdP 账号登录 → 回调 → 拿 token → /api/v1/auth/me 验 claims
```

package com.unify.iam.app.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.app.infra.persistence.po.RefreshTokenPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_refresh_token Mapper。 */
@Mapper
public interface RefreshTokenMapper extends BaseMapper<RefreshTokenPO> {
}
-- ============================================================
-- 模板参数化：给某应用角色模板新增权限点，并同步补齐所有租户内对应角色
-- 背景：iam_application_role_template 是权限集唯一事实源，建租户时 deep-copy 出
--       gateway_role（scope_type=TENANT, is_builtin=1, 同名 role_code）——改模板不会回流
--       已建租户，存量租户角色需本脚本补齐；新建租户走 TenantAppProvisionService 自动含新权限
-- 口径：① 模板 permission_codes_json 追加（JSON_CONTAINS 判重）；
--       ② 租户角色补绑 gateway_role_permission（唯一键判重，MD5 确定性 id 与 repair 脚本同惯例）；
--       ③ 受影响角色持有者的 membership.token_version +1 并记 gateway_membership_version_log
--          （对齐 TokenVersionService.bumpForRoleHolders 的 PERM_CHANGE，方案 c 即时吊销 feed
--          数据源——不 bump 的话旧 token 要等 TTL 过期/刷新才带上新权限）
-- 幂等：重复执行全程无效果（模板 JSON_CONTAINS 判重；补绑先收集「尚缺该权限」的角色到
--       临时表，bump 只认临时表——二次执行临时表为空即整体 no-op）
-- 用法：改下方 4 个参数后【整段顺序执行】；先单独跑第 0 步三条确认输入
-- 注意：① 只覆盖 is_builtin=1 的模板灌入角色；租户自建同名自定义角色（is_builtin=0）不动
--       ② 若某租户管理员曾在管理台把该角色权限「改少」过（updatePermissions 全量替换），
--          本脚本会把新权限补回去——这是对齐模板的预期语义，如对个别租户要保留裁剪，
--          执行前把该租户从第 2 步结果中剔除
--       ③ 全新权限点必须先保证 PermissionCodes / gateway_permission 同套 code（0b 可选块），
--          否则补绑时 JOIN 不上，权限进不了任何角色
--       ④ 变量在赋值时定 collation，勿单独重跑某段
-- ============================================================

SET NAMES utf8mb4;

-- ★ 按需替换的 4 个参数（其余勿动）
SET @app_code  := 'imorph'          COLLATE utf8mb4_unicode_ci;  -- 应用编码（iam_application_role_template.app_code）
SET @role_code := 'iMorph-Admin'    COLLATE utf8mb4_unicode_ci;  -- 模板角色编码（role_code）
SET @perm_code := 'agent.xxx.yyy'   COLLATE utf8mb4_unicode_ci;  -- 新增权限点 code（gateway_permission 同套）
SET @operator  := 'sql-template'    COLLATE utf8mb4_unicode_ci;  -- 落 create_by/update_by，便于审计回溯

-- 0. 前置检查（先单独跑这三条确认；② 必须存在且 ACTIVE，否则先跑 0b 可选块）
-- ① 模板存在？
SELECT template_id, app_code, role_code, JSON_LENGTH(permission_codes_json) AS perm_count
  FROM iam_application_role_template
 WHERE app_code = @app_code AND role_code = @role_code AND delete_flag = 0;
-- ② 权限点已在全局字典？
SELECT permission_id, permission_code, resource_type, action, permission_status
  FROM gateway_permission
 WHERE permission_code = @perm_code AND delete_flag = 0;
-- ③ 将影响哪些租户（预览；expected_role_count = 该角色已建租户数）
SELECT r.scope_id AS tenant_id, r.role_id, r.role_code, r.role_status
  FROM gateway_role r
 WHERE r.scope_type = 'TENANT' AND r.role_code = @role_code
   AND r.is_builtin = 1 AND r.delete_flag = 0;

-- 0b.（可选）权限点尚不在全局字典时登记——通常新权限点随版本代码 seed，仅应急用
-- SET @resource_type := 'AGENT'          COLLATE utf8mb4_unicode_ci;
-- SET @action        := 'DEPLOY'         COLLATE utf8mb4_unicode_ci;
-- SET @perm_name     := '部署 Agent'     COLLATE utf8mb4_unicode_ci;
-- INSERT IGNORE INTO gateway_permission
--   (permission_id, permission_code, resource_type, action, permission_name, is_builtin, permission_status, delete_flag, create_by, update_by)
-- SELECT REPLACE(UUID(), '-', ''), @perm_code, @resource_type, @action, @perm_name, 1, 'ACTIVE', 0, @operator, @operator;

-- 1. 模板权限集追加（幂等：JSON_CONTAINS 判重，已含则不重复追加）
UPDATE iam_application_role_template
   SET permission_codes_json = IF(
         JSON_CONTAINS(permission_codes_json, JSON_QUOTE(@perm_code)),
         permission_codes_json,
         JSON_ARRAY_APPEND(permission_codes_json, '$', @perm_code)),
       update_by = @operator
 WHERE app_code = @app_code AND role_code = @role_code AND delete_flag = 0;

-- 2. 收集「尚缺该权限」的受影响租户角色（deep-copy 签名：TENANT + is_builtin=1 + 同名 role_code）
DROP TEMPORARY TABLE IF EXISTS tmp_grant_roles;
CREATE TEMPORARY TABLE tmp_grant_roles (
  role_id   CHAR(32) NOT NULL PRIMARY KEY,
  tenant_id CHAR(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO tmp_grant_roles (role_id, tenant_id)
SELECT r.role_id, r.scope_id
  FROM gateway_role r
 WHERE r.scope_type = 'TENANT'
   AND r.role_code = @role_code
   AND r.is_builtin = 1
   AND r.delete_flag = 0
   -- 可选：只补「当前仍启用该应用」的租户（取消下一行注释开启）
   -- AND EXISTS (SELECT 1 FROM iam_tenant_application ta
   --              WHERE ta.tenant_id = r.scope_id AND ta.app_code = @app_code AND ta.delete_flag = 0)
   AND NOT EXISTS (
         SELECT 1
           FROM gateway_role_permission rp
           JOIN gateway_permission gp
             ON gp.permission_id = rp.permission_id  -- CHAR(32) 等值比较自带 PAD SPACE
          WHERE rp.role_id = r.role_id AND rp.delete_flag = 0
            AND gp.permission_code = @perm_code AND gp.delete_flag = 0);

-- 预览：将补绑的租户角色（为空 = 已全部覆盖，后续步骤 no-op）
SELECT * FROM tmp_grant_roles ORDER BY tenant_id;

-- 3. 租户角色补绑权限（唯一键 role_id+permission_id 判重；MD5 确定性 id 与 repair 脚本同惯例）
INSERT IGNORE INTO gateway_role_permission
  (role_permission_id, role_id, permission_id, delete_flag, create_by, update_by)
SELECT MD5(CONCAT(t.role_id, ':', p.permission_id)), t.role_id, p.permission_id, 0, @operator, @operator
  FROM tmp_grant_roles t
  JOIN gateway_permission p ON p.permission_code = @perm_code AND p.delete_flag = 0;

-- 4. 即时吊销（方案 c）：受影响角色持有者的 token_version +1，并记 feed 日志（PERM_CHANGE）
--    对齐 TokenVersionService.bumpForRoleHolders 语义（不按成员状态过滤，与库内行为一致）
UPDATE gateway_membership m
  JOIN gateway_membership_role mr
    ON mr.membership_id = m.membership_id AND mr.delete_flag = 0
  JOIN tmp_grant_roles t ON t.role_id = mr.role_id
   SET m.token_version = m.token_version + 1,
       m.update_by = @operator
 WHERE m.delete_flag = 0;

INSERT INTO gateway_membership_version_log
  (log_id, membership_id, tenant_id, token_version, change_type, delete_flag, create_by, update_by)
SELECT REPLACE(UUID(), '-', ''), m.membership_id, m.tenant_id, m.token_version, 'PERM_CHANGE', 0, @operator, @operator
  FROM gateway_membership m
  JOIN gateway_membership_role mr
    ON mr.membership_id = m.membership_id AND mr.delete_flag = 0
  JOIN tmp_grant_roles t ON t.role_id = mr.role_id
 WHERE m.delete_flag = 0;

-- 5. 验证（期望：每个 tmp_grant_roles 租户角色各 1 行且 pair_count=1）
SELECT t.tenant_id, rp.role_id, COUNT(*) AS pair_count
  FROM tmp_grant_roles t
  JOIN gateway_role_permission rp
    ON rp.role_id = t.role_id AND rp.delete_flag = 0
  JOIN gateway_permission p ON p.permission_id = rp.permission_id
 WHERE p.permission_code = @perm_code
 GROUP BY t.tenant_id, rp.role_id;

DROP TEMPORARY TABLE IF EXISTS tmp_grant_roles;

# 审计列表字段来源与删除权衡

调查日期：2026-10-27；分支：`feature/v0.10.3-m10w3`。

结论：五个字段来自主动采集/业务快照，落库后通过全列查询读回，再由 `AdminAuditService.enrich` 逐个 `Map.put` 放进列表。不是 Jackson 意外暴露整个 PO，也没有字段级权限裁剪。保存审计证据有理由，但现有代码/文档不能证明必须在每次列表响应中全部下发。

本报告仅依据当前工作区代码、文档、版本历史和测试源码；未调用运行中的 API、未查询数据库，不能据此给出用户当前十条记录的实际空值比例或已部署版本结论。这里的“有值/为空”指可由实现确定的填充条件。

## 1. 从采集到 JSON 的共同路径

1. HTTP 请求：请求编号由 [RequestIdFilter.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/config/RequestIdFilter.java:26) 在最高优先级 Filter 中生成或清洗透传；IP/UA 由 [RequestMeta.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/RequestMeta.java:36) 读取。业务操作显式调用 before/after，见第 3 节。
2. 写入： [AuditService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/AuditService.java:108) 建立 AuditLogPO；119/120 行把 before/after 序列化为字符串，122–124 行设置 requestId/ipAddress/userAgent；129 行 insert。
3. 表与映射： [V5__p3_admin_lifecycle.sql](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/resources/db/migration/V5__p3_admin_lifecycle.sql:170) 的 `gateway_audit_log`，181–185 行为五个 nullable 列。 [AuditLogPO.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/infra/persistence/po/AuditLogPO.java:23) 对应五个 String 属性；[application.yml](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/resources/application.yml:25) 开启下划线转驼峰。 [AuditLogRepository.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/infra/persistence/repository/AuditLogRepository.java:18) 委托 BaseMapper.insert。
4. 查询： [AdminAuditController.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminAuditController.java:17) 的真实后端路径是 `GET /api/v1/admin/audit`（本仓库不能证明外部 `/v1` 的代理改写）。41 行调用 service；[AdminAuditService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminAuditService.java:90) 创建 filter、count/list；[AuditLogRepository.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/infra/persistence/repository/AuditLogRepository.java:23) → [AuditLogMapper.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/infra/persistence/mapper/AuditLogMapper.java:15) → [AuditLogSqlProvider.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/infra/persistence/mapper/AuditLogSqlProvider.java:9)，执行 `SELECT a.*`，按 create_time/id 倒序分页。过滤 tenant_ids 只限制行，不限制列。
5. 列表投影： [AdminAuditService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminAuditService.java:160) 的 160/161/162/163/164 行分别显式放入 request_id/ip_address/user_agent/before_json/after_json。条目是 `List<Map<String,Object>>`，没有独立的审计条目 DTO；AuditPage 只是页包装。这里也显式返回 metadata_json 和 trace_id。
6. 响应：controller 44 行返回 audits/total/page/size；[ApiEnvelopeAdvice.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/config/ApiEnvelopeAdvice.java:26) 仅套 `{success,code,message,data}`，没有清洗/投影字段。 [application.yml](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/resources/application.yml:4) 的 non_null 会省略 Map 中的 null；空字符串、空数组的 JSON 字符串等非 null 值仍会返回。before/after 是 JSON 文本字符串，并未解析为响应中的嵌套对象，所以会有字符串转义。

## 2. 逐字段结论

| 字段 | 真实来源及写入 → 列/PO → Map 行号 | 填充、清洗与空值 | 保留理由及实际局限 |
|---|---|---|---|
| user_agent | RequestMeta:49–51 读取 User-Agent → AuditService:124 → V5:183 VARCHAR(512)/AuditLogPO:25 → AdminAuditService:162 | 无请求上下文或缺 header 则 null；无脱敏、无应用层截断。512 是数据库列上限，不代表实现会安全裁切超长输入；超长行为取决于数据库模式，未实测。 | 已实现采集、保存、下发，可人工判断客户端/排障；未发现自动解析、风控或业务判断使用它。客户端可伪造。不是列表必要字段。 |
| before_json | 调用者 `.before(value)` → AuditService:119 + JsonUtils:22 → V5:184 JSON/AuditLogPO:26 → AdminAuditService:163 | 未调用/值为 null 则 SQL NULL；只序列化调用者选择的对象，无通用脱敏、截断、大小限制或自动 diff。 | 已实现部分操作的旧值记录，可核验改动。不是全实体快照，也不是 JSON Patch。不同事件结构不同，不能据此自动还原整个对象。 |
| after_json | 调用者 `.after(value)` → AuditService:120 + JsonUtils:22 → V5:185 JSON/AuditLogPO:27 → AdminAuditService:164 | 同 before；写点通常成对记录，但 builder 不强制成对。 | 已实现部分操作的新值记录；与 before 对照人工看变化。当前没有自动回滚/重放消费者。 |
| ip_address | RequestMeta:37–46 优先 X-Forwarded-For 首项，否则 remoteAddr → AuditService:123 → V5:182 VARCHAR(64)/AuditLogPO:24 → AdminAuditService:161 | 无请求上下文则 null；header 路径只 split/trim，无地址合法性校验、代理白名单、脱敏或长度裁切。 | 已实现来源线索保存，可用于人工排障；不能当可靠身份/位置证据。代理不覆盖/清洗 XFF 时可伪造；无 XFF 时可能只是代理地址。 |
| request_id | RequestIdFilter:29–35 请求 header/新业务 ID → request attribute → RequestMeta:27–33 → AuditService:122 → V5:181 VARCHAR(64)/AuditLogPO:23 → AdminAuditService:160 | Filter 内正常请求有值；无请求上下文/未经过 Filter 则 null。去首尾空白，删除除字母数字及 ._- 外的字符，最长 64；清洗后空值重新生成，不是任何不合法字符都整串拒绝。 | 已实现响应头与同次请求审计记录的关联；是排障编号。未实现去重/幂等，允许客户端重用同一编号；完整日志与跨服务链路关联未证实，见第 4 节。 |

以上短名均对应第 1 节中已给出的绝对文件路径。[JsonUtils.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-common/src/main/java/com/unify/iam/common/util/JsonUtils.java:11) 只是普通 ObjectMapper.writeValueAsString；不能把业务选字段当成全局脱敏机制。当前已检查的快照写点不含密码/token/client secret，但名称、描述、域名等值原样保存；未来写入任意对象也无统一秘密过滤保护。

## 3. before/after 的实际覆盖

| 当前写点 | before/after 具体内容 | 证据 |
|---|---|---|
| ADMIN_UPDATE_TENANT | tenant_status、tenant_name、primary_domain 三字段前后状态；即便只改一个字段也记录这三个字段，不是仅变化字段的补丁 | [AdminTenantService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminTenantService.java:129)，149–159 行 |
| ADMIN_SET_MEMBER_ROLES | 旧角色 ID 列表、新 request.roleIds 列表；记录集合值，不是 add/remove 差分。旧值读取 listByMembership，新值走 replaceDirectRoles，不能仅凭 before/after 注释保证二者一定是相同授权来源口径 | [AdminMemberService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminMemberService.java:121)，126–133 行 |
| ADMIN_SUSPEND_MEMBER / ADMIN_RESTORE_MEMBER | membership_status 一个字段 | [AdminMemberService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminMemberService.java:159)，164–191 行 |
| ADMIN_UPDATE_ROLE（已有未提交改动） | role_name、role_description | [AdminRoleService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminRoleService.java:98)，104–106、160–164 行 |
| ADMIN_UPDATE_TENANT_QUOTA（已有未提交改动） | 修改/重置配额前后的 TenantUsageDimension DTO，含统计值、上限等，不是完整租户 | [AdminTenantController.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminTenantController.java:144)，150–167 行；[TenantUsageDimension.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/admin/TenantUsageDimension.java:6) |
| Owner 更换/邀请接受（已有未跟踪代码） | owner_user_id 一个字段；初始 Owner 接受时同时改 tenant_status，但快照仅保存 Owner | [TenantOwnershipService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/TenantOwnershipService.java:104)，118–129 行 |

其余当前审计写点不调用 before/after，不能因为字段存在就假定有快照。例如 [AdminUserController.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminUserController.java:47) 的用户列表/创建/修改/重置密码/删除均没有 before/after；[AdminIdpController.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminIdpController.java:59) 的 IdP 配置修改也没有。历史上尚未实现元信息/快照采集的记录不会因查询而被回填。

现有 [AuditCompletenessIntegrationTest.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/test/java/com/unify/iam/app/AuditCompletenessIntegrationTest.java:66) 有租户更新后落库 request_id、IP、ACTIVE→DISABLED 的断言；这里仅阅读，未重跑，不把测试源码当作本次实际通过结果。

## 4. 请求编号、日志和 IP 的可信度

- RequestIdFilter 确实写入 request attribute、响应 X-Request-Id 及 MDC `requestId`，finally 删除 MDC。AuditService 从 attribute 获取，因此相同请求中的多条审计可以共用编号。
- [logback-spring.xml](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/resources/logback-spring.xml:17) 的 FILE pattern 没有 `%X{requestId}`；CONSOLE 引用 Spring Boot defaults，仓库中没有 requestId 的日志 pattern override；源码也未发现主动把 RequestMeta.requestId 写进日志消息的调用。故能证明“MDC 已注入”，不能证明“当前文件日志按此编号可检索”。外部部署若另有日志配置本次不可证实。没有发现 request ID 的跨服务出站透传实现，也没有 `.trace(...)` 业务调用；trace_id 的未来设计不等于已建立链路。
- IP 的 XFF 优先逻辑没有验证连接对端是否为可信代理。仅当部署代理清除外来头、规范重写且服务只能经可信入口访问时首项才可能可信；仓库未提供可证明这些条件成立的代理策略。采集 IP 不会自动提供风控或反欺诈能力。
- 除 request ID 的白名单/长度处理之外，采集链路没有统一脱敏/截断。UI 不显示字段不等于 API 已裁剪。

## 5. 权限与是否实际裁剪

[WebMvcConfig.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/config/WebMvcConfig.java:25) 将拦截器注册到 `/api/v1/admin/**`；[ManagementAuthorizationInterceptor.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/ManagementAuthorizationInterceptor.java:35) 验证 Bearer JWT，并在 39–41 行检查方法注解需要的权限。列表和 events 均要求 IAM_AUDIT_READ（controller:27、50）。无/坏 token 401，缺该权限 403。

平台引导把 `iam:audit:read` 标记为 tenant_grantable=0，绑定 PlatformAdmin：[R__platform_bootstrap.sql](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/resources/db/seed/R__platform_bootstrap.sql:25)，48 行；正常租户角色授权也检查该标记：[AdminRoleService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminRoleService.java:184)。因此正常授权模型下它是平台专属能力。

但审计控制器/service 没有调用 assertPlatformAdmin 或 assertTenantScope：运行时实质门禁是 token 是否含 iam:audit:read，不是另行检查角色名。传 tenant_ids 只是可选筛选；省略可查所有未删除记录，不会自动加 token.tenantId。获准读取者都会收到同样的显式字段集合，没有细粒度字段权限或内容脱敏；non_null 省略空键不算权限裁剪。

## 6. tenant_name 对前端列的支持

已有 `audits[].tenant_name`，无需为了新增 tenant 列而改后端契约。来源路径：审计行 tenant_id → AdminAuditService:115 收集本页租户 ID → 132 行批量 TenantRepository.findByIds → [TenantRepository.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-tenant/src/main/java/com/unify/iam/tenant/infra/persistence/repository/TenantRepository.java:39) 查 gateway_tenant → [TenantPO.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-tenant/src/main/java/com/unify/iam/tenant/infra/persistence/po/TenantPO.java:18) 的 tenantName（[V1__init_schema.sql](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/resources/db/migration/V1__init_schema.sql:61)）→ [AdminAuditService.java](/Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminAuditService.java:150) 输出，306–308 行取名。

这是查询时的当前名称富化，不是事件发生时名称快照；改名后历史列表会显示新名。无 tenant_id 的平台级事件、实体删除/缺失时可无 tenant_name，序列化时省略；显示侧可用 tenant_id 或占位符兜底。tenant_name 本身没有 ID 回退（target_display 另有回退逻辑，不能混淆）。

还存在已实现但不完整的回退：140–145 行尝试从 MEMBERSHIP 目标推导 tenant_id，但推导出的 ID 没补到此前 132 行的批量租户查询。如果本页其他行未提前提供该租户 ID，即使成员还存在也可能查不到 tenant_name；数据库 tenant_ids 筛选发生在此推导之前，也不会匹配 tenant_id 本来为空的历史行。这些是现状说明，本次未修复。

本任务未访问另一个 Platform IAM 项目，未实施“Actor user 前增加 tenant”前端列；仅提供本项目既有字段及边界供主任务使用。

## 7. 为什么原实现要加这些字段

- 原始 schema 已包含这些列（[原始 DDL](/Users/ramiro.li/root/apps/work/platform-iam-service/docs/original-design/20260825-Gateway-Tenant-IAM-schema-mysql.sql:483)），V5 落地为审计表。设计明确希望记录前后值、请求编号，并为未来跨系统审计关联打底：[P3 设计](/Users/ramiro.li/root/apps/work/platform-iam-service/docs/04-E2E3-P3管理面与账号生命周期设计.md:105)；[能力差距文档](/Users/ramiro.li/root/apps/work/platform-iam-service/docs/requirements/M10W3-能力盘点与IAM差距分析.md:101)。这是存储与追溯设计理由，不是列表必须返回的证明。
- `git blame` 确认 AdminAuditService:160–164 的显式 Map.put 来自 `89c98648b3c0d128107b3e99452d87902bebfb83`（2026-10-21，“G4 服务间状态校验 + G5 审计补全/富化/分页 + 审计页可用性”）；该提交同时增加自动采集和 before/after 记录。此前 `61d2dc2` 是 P3 审计起步，`0344a06` 增加管理台支撑，后续 `8b95d3a` 扩展审计查询筛选。
- 因此准确原因是：当时的审计可用性实现把证据字段一并显式投影到了唯一列表接口，而没有拆出列表摘要和详情。没有找到“每次列表必须下发 UA/IP/完整快照”的强制设计要求，也未找到这五字段作为自动业务决策输入的生产代码。前端是否另有展开显示/导出消费，本任务禁止访问其他项目，不能判断。
- 设计中的“登录失败、401/403、跨系统关联”等不能一概当作已实现。当前源码未发现 FAILED/DENIED 写点；[差距文档](/Users/ramiro.li/root/apps/work/platform-iam-service/docs/requirements/M10W3-能力盘点与IAM差距分析.md:107) 也列为待补强。审计并非完整的安全事件平台。

## 8. 保留/删除的选择

| 方案 | 实际改变 | 收益 | 代价/限制 |
|---|---|---|---|
| 仅列表移除，详情按需查询 | 列表使用摘要字段；证据字段交给按条读取的详情 | 列表响应更小，避免浏览列表就下发全部证据，同时保留人工核验入口 | 当前仅有列表 GET `/api/v1/admin/audit` 和目录 GET `/events`，没有 `/{id}` 详情接口。必须新增并鉴权详情接口及按 ID 查询；不能宣称现成可用。前端/API 消费者和现有断言需适配；详情仍需脱敏策略。 |
| 存储保留，响应裁剪 | 继续采集落库，在现有列表 Map/列表投影中移除字段 | 不丢历史和未来证据；可先减少网络暴露 | 当前没有详情，裁剪后 API 暂无读取这些证据的入口。若 SQL 仍 SELECT a.*，数据库读取、存储量不变；想减少读取还需显式查询列。对依赖字段的消费者属于契约变化。 |
| 彻底停止采集/删除 | 停采只影响未来；清历史/删列是另外的动作，需要明确范围和新增迁移 | 同时减少隐私收集和未来存储；删历史可进一步减少留存数据 | 丢失请求来源、旧新值/请求关联线索；停采不自动清历史，删响应也不自动停采。删除历史/列不可通过恢复响应补回；不能编辑已应用 V5。需协调 PO、写入、查询、响应、消费者、测试和留存策略。 |

建议作为用户决策依据：before/after 对“谁把什么改成什么”已有实际价值，适合保留存储并按需查看；request_id 已有 HTTP 响应与审计关联价值，但日志输出链路仍缺一段；IP 在完善可信代理规则之前只能当线索；UA 的现有用途最弱，只能证明已保存客户端自报信息。若目标只是简化列表，优先考虑保留存储、裁剪列表；若还需要在产品内核验证据，再单独授权补详情。不存在为了这些用途就必须把五项全塞进列表的理由。

以上均为评估，用户未决定，本次没有移除任何字段或改变契约。

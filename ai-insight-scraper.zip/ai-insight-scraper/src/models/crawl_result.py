"""爬取结果模型 — 树结构 + 统计"""

from pydantic import BaseModel, Field


class TreeNode(BaseModel):
    """树节点"""

    url: str = Field(..., description="节点 URL（已标准化）")
    children: list["TreeNode"] = Field(default_factory=list, description="子节点列表")
    leaf: bool = Field(default=False, description="是否为叶子节点")
    type: str | None = Field(
        default=None,
        description="叶子节点类型：cross_domain（外域）/ file（文件）",
    )


class TreeStructure(BaseModel):
    """嵌套 JSON 树结构"""

    root: TreeNode = Field(..., description="树根节点")


class PageCrawlStats(BaseModel):
    """单个页面爬取统计"""

    page_url: str = Field(..., description="页面 URL")
    crawl_time: str = Field(..., description="爬取时间")
    raw_links_count: int = Field(default=0, description="原始链接数")
    saved_links_count: int = Field(default=0, description="保存链接数（去重后）")
    duplicate_links_count: int = Field(default=0, description="重复链接数")
    skipped: bool = Field(default=False, description="是否被跳过")
    skipped_reason: str | None = Field(default=None, description="跳过原因")


class CrawlTaskResult(BaseModel):
    """爬取任务完整结果"""

    task_id: str = Field(..., description="任务 ID")
    tree_structure: dict | None = Field(default=None, description="嵌套 JSON 树结构")
    all_links: list[str] = Field(default_factory=list, description="所有去重链接列表")
    stats: dict = Field(default_factory=dict, description="爬取统计汇总")

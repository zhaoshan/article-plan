# Role basic-information update contract plan

Date: 2026-10-27

Status: Complete.

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, planning, session, direct frontend contract, and validation records under this repository's `.trellis/` directory.
- Do not access, inspect, or modify a separate frontend project. This task exposes a backend contract only.
- Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- The requested `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree or its ancestors. The applicable instructions are `CLAUDE.md` and `.claude/rules/security.md`; no undocumented Trellis confirmation gate can be inferred. The user has already explicitly selected the backend-extension option.

## Confirmed baseline

1. `gateway_role` already owns `role_name VARCHAR(128)` and nullable `role_description VARCHAR(512)` in `V1__init_schema.sql`; `RolePO` and `RoleRepository.update(...)` already map and persist both columns. A schema migration is neither required nor appropriate.
2. Existing role APIs are `GET/POST /api/v1/admin/roles`, `GET/PUT /api/v1/admin/roles/{roleId}/permissions`, and `DELETE /api/v1/admin/roles/{roleId}`. There is no endpoint for modifying role metadata. The list projection currently omits `role_description`.
3. Every existing role mutation requires `iam:role:write`, loads the target role, and applies `TenantScopeGuard`: `PLATFORM` requires a platform administrator; `TENANT` requires the caller's target tenant unless the caller has a platform role.
4. All `/api/v1/**` success and failure bodies use the standard `{success, code, message, data}` envelope with real HTTP statuses. Validation/domain errors are `400`, absent role is `404`, absent/invalid Bearer is `401`, and missing permission or out-of-scope target is `403`.
5. `role_code` is unique within `(scope_type, scope_id)`, emitted into JWT `roles`, and used to reconcile application templates and owner-role behavior. Existing write code only assigns it at creation. It must remain stable: changing it would alter an authorization-facing claim and could break code-based template/owner semantics. The role-to-member, role-to-permission, and IdP mapping tables use `role_id`, but that does not make code renames a safe metadata-only operation.
6. Existing `PUT /roles/{roleId}/permissions` already validates tenant grantability and increments token versions for all holders because permissions are authorization data. Name and description are presentation metadata and are not JWT claims; their update must not trigger token-version churn.

## Chosen contract

Add a typed metadata-only update endpoint:

```text
PUT /api/v1/admin/roles/{roleId}
Authorization: Bearer <access token with iam:role:write>
Content-Type: application/json

{
  "role_name": "Support operator",
  "role_description": "Handles customer support workflows"
}
```

- `role_name` is required, nonblank after validation, and at most 128 characters. The service stores its trimmed value, matching role creation behavior.
- `role_description` is nullable and at most 512 characters. This is a PUT replacement of the mutable metadata: omitted or JSON `null` clears it; a non-null string is persisted without inventing extra normalization beyond the existing create behavior.
- The response is the standard success envelope whose `data` is `{ "role_id": "..." }`, consistent with the existing role/user/tenant update style.
- The list role projection will add `role_description` when it has a value so a list-to-detail UI can hydrate the editable metadata without changing the current list route. The global `non_null` setting omits this key for a null description. No unrelated role-detail read route is added in this minimal change.
- `role_code`, `scope_type`, `scope_id`, `is_builtin`, and `role_status` are immutable through this endpoint. A non-null `role_code` supplied on this route is rejected with `400` (`role_code does not support updates`) instead of being silently ignored. Existing role creation remains the only assignment path for a code.
- Built-in roles are not given a new special restriction because existing permission and deletion operations already permit the same scope-authorized actor to modify them. The frontend may present product guidance, but the backend does not introduce an unrequested divergent policy.
- Permission persistence remains the existing separate `PUT /api/v1/admin/roles/{roleId}/permissions` endpoint with `permission_ids`. The two writes are intentionally not bundled into one cross-resource transaction; an editor saves metadata through the new route and permissions through the existing route. Permission updates retain their existing holder-version bump behavior.
- Successful metadata updates write `ADMIN_UPDATE_ROLE` audit records containing the role target, target tenant for tenant roles, and before/after name/description snapshots. No schema change is needed for the audit record.

## Error and authorization contract

| Condition | HTTP | Standard envelope behavior |
| --- | --- | --- |
| Missing/invalid Bearer token | 401 | Existing authentication message and `data:null` |
| Authenticated caller lacks `iam:role:write` | 403 | Existing permission message and `data:null` |
| Tenant administrator targets another tenant role, or non-platform actor targets a platform role | 403 | Existing scope message and `data:null` |
| Role does not exist | 404 | `role not found` domain message and `data:null` |
| Blank/oversized `role_name`, oversized description, or non-null `role_code` | 400 | Validation/domain message and `data:null` |
| Valid update | 200 | `data:{role_id}` |

## Implementation checklist

- [x] Read the available project and security instructions; record the absence of the requested AGENTS/Trellis workflow files and the already-satisfied option-selection gate.
- [x] Trace the role data model, authorization guard, current endpoints, token-version semantics, error envelope, audit convention, migration ownership, and tests.
- [x] Add the typed update DTO and the metadata update service/controller path.
- [x] Add description to the existing role-list projection and register/write the update audit event.
- [x] Add focused MVC, service, and integration coverage for contract, validation, scope, immutability, persistence, audit, and unchanged permission behavior.
- [x] Update the API reference and complete the Trellis contract/session/check records after validation.

## Out of scope

- Any frontend source, routing, form implementation, or frontend project inspection.
- Renaming `role_code`, moving roles between scopes, changing status/built-in flags, or modifying application role templates.
- Combining basic-info and permission writes into a new transaction or changing existing permission isolation/token-version behavior.
- Any Flyway migration, data rewrite, branch/worktree operation, commit, merge, or push.

## Implementation and validation result

- Added `UpdateRoleRequest` and `PUT /api/v1/admin/roles/{roleId}`. It requires a verified Bearer with `iam:role:write`, validates name/description bounds, rejects a non-null `role_code`, loads the target role, and applies the existing tenant/platform scope guard.
- Added `RoleRepository.updateBasicInfo(...)`, an explicit two-column update that deliberately writes `role_description = NULL`. The generic MyBatis `updateById` strategy omits null properties, so using it would have broken the documented clear-description contract; the Testcontainers test proved the corrected behavior against MySQL.
- Added `role_description` to the existing list projection when non-null, registered and wrote `ADMIN_UPDATE_ROLE` before/after audit snapshots, and documented the frontend contract in both the user-facing API reference and this task's `contract.md`.
- Basic-information writes do not alter `role_code` or permissions and therefore do not bump token versions. Existing permission replacement remains separate and continues to bump all role holders with `PERM_CHANGE`.

Focused validation passed with the local process-attachment capability required by JDK 26 Mockito tests:

```text
mvn -pl iam-app -am test -Dtest='AdminRoleControllerTest,AdminRoleServiceTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 11 passed, 0 failures, 0 errors

mvn -pl iam-app -am test -Dtest='AdminRoleUpdateIntegrationTest,P3TenantScopeIntegrationTest,P3AdminCrudIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 10 passed, 0 failures, 0 errors
```

The integration suite used a fresh Testcontainers MySQL schema and verified metadata persistence, description clearing, description omission from the list when null, audit/catalog visibility, immutable code rejection, token-version distinction, existing CRUD regression, and tenant/platform scope denials. `git diff --check` passed.

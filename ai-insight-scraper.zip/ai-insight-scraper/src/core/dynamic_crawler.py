"""DynamicCrawler — 动态页面爬取编排器

负责：
  1. 按 (site, page_type) 加载动态脚本配置
  2. 按 site 加载遍历规则（外链过滤）
  3. 从注册表获取脚本实现类
  4. 管理 Playwright 浏览器生命周期（复用 chrome_utils + TreeCrawler 模式）
  5. 执行脚本 → 外链过滤 → 合并到静态文件

S3 支持：
  - static_links_file / static_tree_file 为 s3:// 路径时，自动下载 → 合并 → 上传覆盖
  - 临时文件保存在 output/ 目录，合并后清理
"""

import hashlib
import json
import logging
from pathlib import Path

from playwright.async_api import async_playwright

from src.boundaries.s3_boundary import S3Boundary, S3Error
from src.config.dynamic_page_config import load_dynamic_page_config
from src.config.traversal_config import load_traversal_config
from src.core.base_crawler import BaseCrawler
from src.core.dynamic_scripts import get_script
from src.utils.url_utils import normalize_url, is_same_domain, is_domain_in_whitelist

logger = logging.getLogger(__name__)


class DynamicCrawler(BaseCrawler):
    """动态页面爬取编排器"""

    def __init__(self, headless: bool = True, s3_boundary: S3Boundary | None = None):
        """
        Args:
            headless: 是否无头模式
            s3_boundary: S3 边界客户端（用于处理 s3:// 路径的文件的下载和上传）
        """
        self.headless = headless
        self._browser = None
        self._s3_boundary = s3_boundary
        self._output_dir = Path("output")
        self._output_dir.mkdir(parents=True, exist_ok=True)

    # ── 公共接口 ──────────────────────────────────────

    async def crawl_dynamic(
        self,
        site: str,
        page_type: str,
        static_links_file: str | Path,
        static_tree_file: str | Path,
        config_dir: str | Path | None = None,
    ) -> dict:
        """
        执行动态页面爬取，并将发现的链接合并到静态文件中。

        Args:
            site: 站点域名（如 'tokyostarbank.co.jp'）
            page_type: 动态页面类型（如 'faq'）
            static_links_file: all_unique_links_{ts}.json 文件路径
            static_tree_file: tree_structure_{ts}.json 文件路径
            config_dir: 配置文件目录（默认项目根 config/）

        Returns:
            dict: stats, merged_links_count, tree_updated

        Raises:
            ValueError: 配置缺失或脚本未注册
        """
        # 1. 加载动态页面配置
        entry = load_dynamic_page_config(site, page_type, config_dir)
        if entry is None:
            raise ValueError(
                f"未找到动态页面配置: site='{site}', page_type='{page_type}'"
            )

        # 2. 加载遍历规则（外链过滤）
        traversal_config = load_traversal_config(site, config_dir)

        # 3. 获取脚本类并实例化
        script_cls = get_script(entry.script_name)
        script = script_cls()

        logger.info(
            f"开始动态爬取: site={site}, page_type={page_type}, "
            f"script={entry.script_name}, entry_url={entry.entry_url}"
        )

        # 4. 启动 Playwright 并执行脚本
        async with async_playwright() as p:
            context = await self._setup_browser_context(p)
            try:
                result = await script.execute(
                    context=context,
                    parent_link=entry.parent_link,
                    entry_url=entry.entry_url,
                )
            finally:
                await self._teardown_browser(context)

        discovered_links = result.get("discovered_links", [])

        # 5. 外链过滤
        if not traversal_config.need_outer_site:
            # 不收集外站链接：只保留同域名的链接
            filtered_links = [
                link for link in discovered_links
                if is_same_domain(link, site)
            ]
        elif traversal_config.outer_site_whitelist:
            # 仅收集白名单内的外站链接
            filtered_links = [
                link for link in discovered_links
                if is_same_domain(link, site)
                or is_domain_in_whitelist(link, traversal_config.outer_site_whitelist)
            ]
        else:
            # 收集所有外站链接
            filtered_links = discovered_links

        filtered_count = len(discovered_links) - len(filtered_links)
        if filtered_count > 0:
            logger.info(f"外链过滤: {len(discovered_links)} → {len(filtered_links)} （过滤 {filtered_count} 条）")

        # 6. 将相对路径解析为绝对路径（基于 CWD），或从 S3 下载
        #    避免因调用方传入相对路径而 CWD 与预期不一致时出现 FileNotFoundError
        links_local = await self._ensure_local_file(static_links_file)
        tree_local = await self._ensure_local_file(static_tree_file)
        logger.info(f"合并文件路径: links={links_local}, tree={tree_local}")

        merged_links_count = self._merge_into_links_file(
            links_local, filtered_links
        )
        tree_updated = self._merge_into_tree_file(
            tree_local, entry.parent_link, filtered_links
        )

        # 7. 如果是 S3 路径，将合并后的结果上传覆盖
        links_result = await self._upload_result(links_local, static_links_file)
        tree_result = await self._upload_result(tree_local, static_tree_file)

        logger.info(
            f"动态爬取完成: site={site}, page_type={page_type}, "
            f"发现 {len(discovered_links)} 条链接, "
            f"合并 {merged_links_count} 条到链接列表, "
            f"树更新={tree_updated}"
        )

        return {
            "stats": result.get("stats", {}),
            "discovered_count": len(discovered_links),
            "merged_links_count": merged_links_count,
            "tree_updated": tree_updated,
            "links_path": links_result,
            "tree_path": tree_result,
        }

    # ── S3 辅助方法 ─────────────────────────────────

    async def _ensure_local_file(self, path: str) -> Path:
        """确保文件在本地可访问：s3:// 路径下载到临时文件，本地路径直接返回。

        Args:
            path: 文件路径（本地路径或 s3:// 路径）

        Returns:
            Path: 本地文件路径
        """
        if path.startswith("s3://") and self._s3_boundary is not None:
            content = await self._s3_boundary.download_text(path)
            # 用路径哈希生成临时文件名，避免同名冲突
            suffix = ".json"
            name_hash = hashlib.md5(path.encode("utf-8")).hexdigest()[:12]
            tmp_path = self._output_dir / f"tmp_{name_hash}{suffix}"
            tmp_path.write_text(content, encoding="utf-8")
            logger.info(f"已从 S3 下载到临时文件: {path} → {tmp_path}")
            return tmp_path
        return Path(path).resolve()

    async def _upload_result(self, local_path: Path, original_path: str) -> str:
        """将合并后的结果上传到 S3（覆盖原路径），或保留本地路径。

        Args:
            local_path: 本地合并后的文件路径
            original_path: 原始传入路径（可能为 s3:// 或本地路径）

        Returns:
            str: 最终文件路径（s3:// 路径或本地路径）
        """
        if original_path.startswith("s3://") and self._s3_boundary is not None:
            content = local_path.read_text(encoding="utf-8")
            # 直接覆盖原 s3 路径；upload_to_path 内部用 _resolve_key 解析完整 key，
            # 不会再拼接 prefix_path，避免出现 local/local/... 双重前缀
            await self._s3_boundary.upload_to_path(content, original_path)
            logger.info(f"已上传合并结果覆盖 S3 文件: {original_path}")
            # 清理临时文件
            try:
                local_path.unlink()
            except OSError:
                pass
            return original_path
        return str(local_path)

    # ── 文件合并 ─────────────────────────────────────

    def _merge_into_links_file(
        self, links_path: Path, new_links: list[str]
    ) -> int:
        """读取已有去重链接列表，去重后追加新链接，写回文件。

        Returns:
            实际新增的链接数
        """
        existing: list[str] = []
        if links_path.exists():
            try:
                existing = json.loads(links_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, Exception):
                logger.warning(f"读取链接文件失败，将覆盖写入: {links_path}")
                existing = []

        # 构建已有链接的标准化集合
        existing_norm = {normalize_url(link) for link in existing}

        # 去重
        new_unique: list[str] = []
        for link in new_links:
            norm = normalize_url(link)
            if norm not in existing_norm:
                existing_norm.add(norm)
                new_unique.append(norm)

        if not new_unique:
            return 0

        existing.extend(new_unique)
        links_path.write_text(
            json.dumps(existing, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        logger.info(f"链接列表已更新: +{len(new_unique)} 条，总计 {len(existing)} 条")
        return len(new_unique)

    def _merge_into_tree_file(
        self, tree_path: Path, parent_link: str, new_links: list[str]
    ) -> bool:
        """在树文件中找到 parent_link 节点，将新链接挂为子节点。

        如果 parent_link 原来是叶子节点，移除 leaf 标记。
        动态链接全部标记为 leaf + type="dynamic"。

        Returns:
            是否成功修改树
        """
        if not tree_path.exists():
            logger.warning(f"树文件不存在，跳过树合并: {tree_path}")
            return False

        try:
            data = json.loads(tree_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, Exception) as e:
            logger.error(f"读取树文件失败: {e}")
            return False

        parent_norm = normalize_url(parent_link)

        # 收集树中已有的所有 URL（用于去重）
        existing_urls = self._collect_all_urls(data)

        # 去重：只添加不在树中的链接
        new_children = [
            normalize_url(link) for link in new_links
            if normalize_url(link) not in existing_urls
        ]

        if not new_children:
            logger.info("所有动态链接已存在于树中，无需更新")
            return False

        # 递归查找父节点并添加子节点
        modified = self._add_children_to_node(data, parent_norm, new_children)
        if not modified:
            logger.warning(
                f"在树中未找到父节点 '{parent_link}'（标准化='{parent_norm}'），"
                f"链接已追加到链接列表但未加入树结构"
            )
            return False

        tree_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        logger.info(f"树结构已更新: 在 '{parent_link}' 下新增 {len(new_children)} 个子节点")
        return True

    def _collect_all_urls(self, node: dict) -> set[str]:
        """递归收集树中所有节点的标准化 URL"""
        urls: set[str] = set()
        url = node.get("url")
        if url:
            urls.add(normalize_url(url))
        for child in node.get("children", []):
            urls.update(self._collect_all_urls(child))
        return urls

    def _add_children_to_node(
        self, node: dict, target_norm: str, new_children: list[str]
    ) -> bool:
        """递归查找目标节点并添加子节点。

        找到后：
          - 移除 leaf 和 type 标记（不再叶子）
          - 追加新子节点（leaf=true, type="dynamic"）

        Returns:
            是否找到目标节点并成功添加
        """
        node_url = node.get("url", "")
        if normalize_url(node_url) == target_norm:
            # 去掉 leaf 标记
            if node.pop("leaf", None):
                node.pop("type", None)

            if "children" not in node:
                node["children"] = []

            existing_child_urls = {
                normalize_url(c.get("url", "")) for c in node["children"]
            }
            for url in new_children:
                if normalize_url(url) not in existing_child_urls:
                    node["children"].append({
                        "url": url,
                        "leaf": True,
                        "type": "dynamic",
                    })
                    existing_child_urls.add(normalize_url(url))
            return True

        for child in node.get("children", []):
            if self._add_children_to_node(child, target_norm, new_children):
                return True

        return False

# 05. IAM 前端管理台与统一登录（platform-iam-web）设计

> 状态：**方案定稿（交互设计见 §7）**（2026-10-09；栈定稿 2026-10-10）。
> 定位：IAM 控制面 UI——**统一登录界面（login hub）+ 后台管理台（admin console）**，作为独立前端应用放在 `/Users/zhaoshan/workspace/platform-iam-web`，与 `unify-iam-server`（后端）解耦、独立部署。
> 与 P3 后端关系：**本文件只设计前端**；P3 后端（`docs/04-E2E3-P3管理面与账号生命周期设计`）保持纯后端不动，本 web 是其消费方。
> 决策背景：parlant 先出极简登录页跑通双账号（`parlant-agent/docs/06-dev-process/11`）；**本 web 是 P3 收敛的宿主**——届时 parlant 只留「去登录」跳转到 `IAM_BASE/login`。

---

## 1. 目标（一句话）

**一个独立小前端应用 `platform-iam-web`：托管统一登录界面（企业 SSO / 个人账号 / 本地账号 / 注册找回 / 多租户切换）＋ IAM 后台管理（用户/租户/成员/角色/审计），消费 `unify-iam-server` 的公开与管理 API。**

## 2. 可行性结论

✅ **可行**，理由：
- 本机 Node v23 + pnpm 10，React/Vite/TS 生态成熟（parlant-web 同栈 React19+Vite8+TS6+zustand5）。
- IAM 后端是纯 API：登录用浏览器跳转（顶层导航，无 CORS 问题）、管理用 Bearer API——前端只是消费方，**不要求改后端任何代码**。
- 现在就能起「最小登录 hub」（用 P2 已有 API）；管理台待 P3 后端 `/api/v1/admin/**` 就绪后逐个接。
- 与 parlant 完全正交：两个前端应用各管各的，parlant 后续可跳过来登录（P3 收敛）。

## 3. 技术选型（2026-10-10 定稿）

> 工程模式对齐 `parlant-agent-web`（client.ts 取 token 的 fetch 封装、zustand store、路由守卫、oxlint、npm）；
> **UI 组件取 Ant Design 5**（仅此处偏离 parlant 的 Tailwind——管理台 CRUD 密集，AntD 表格/表单/弹窗/分页开箱即用，更快交付）。

| 项 | 选型 | 理由 |
|---|---|---|
| 构建 | Vite 8 + TypeScript 6 | 与 parlant-agent-web 同栈，快、热更新好 |
| 框架 | React 19 | 生态成熟 |
| 路由 | react-router-dom v7 | 登录/管理台多路由 + 守卫 |
| 状态 | zustand 5（auth 持久化 localStorage） | 与 client.ts 联动取 token；数据请求用轻量封装（§7 组件映射） |
| UI | **Ant Design 5** | 管理台表格/表单/权限配置弹窗/分页开箱即用 |
| 请求 | fetch 封装 `api/client.ts` | 对齐 parlant-agent-web client.ts 模式（zustand 取 token、自动带 Bearer、401 跳登录），不用 axios |
| Lint | oxlint | 对齐 parlant-agent-web |
| 包管理 | npm | 对齐 parlant-agent-web（package-lock） |
| 端口 | 5174（dev） | 避开 parlant 5173 / IAM 8090 |

## 4. 应用结构与路由

```
platform-iam-web/
├── src/
│   ├── main.tsx / App.tsx / router.tsx
│   ├── api/            # axios 实例 + /auth /admin 接口封装
│   ├── store/auth.ts   # token + user + tenants 持久化（zustand）
│   ├── pages/
│   │   ├── Login.tsx        # 统一登录 hub：企业SSO/个人/本地 三入口 + 回跳 token
│   │   ├── Register.tsx / ForgotPassword.tsx / ResetPassword.tsx
│   │   ├── TenantSwitch.tsx # 多租户选择器（user.tenants[] → switch-tenant）
│   │   ├── Me.tsx
│   │   └── admin/
│   │       ├── Users.tsx / Tenants.tsx / Members.tsx / Roles.tsx / Audit.tsx
│   ├── components/    # 布局/守卫（RequireAuth / RequirePermission）/
│   └── config.ts      # IAM_BASE（dev: /api 走 Vite proxy → 8090）
└── vite.config.ts     # server.proxy: /api → http://localhost:8090
```

### 路由与守卫
| 路由 | 访问 | 守卫 |
|---|---|---|
| `/login` | 公开 | 无 |
| `/register` `/forgot-password` `/reset-password` | 公开 | 无 |
| `/me` `/tenant-switch` | 登录后 | RequireAuth |
| `/admin/*` | 登录后 + 对应 `iam:*` | RequireAuth + RequirePermission(`iam:user:read` 等，见 docs/04 §3.1) |

## 5. 统一登录界面（login hub）

**前端只负责「跳转」与「收 token」，不碰密码（SSO）**：
1. 按钮 → `window.location = IAM_BASE/api/v1/auth/oidc/authorize?tenant_id=...`（企业=`tenant-org-a`、个人=`PLATFORM`）
2. IAM 回调后 302 回 `/login?access_token=...` → `Login.tsx` 读 query → `setAuth(token, userFromToken(token))`
3. 本地账号：表单 → `POST /api/v1/auth/token`（经 Vite proxy 同源）
4. 多租户：登录后若 `user.tenants[]` 有多个 → 显示租户选择器 → `POST /api/v1/auth/switch-tenant` → 更新 token（P3）

> 这就是「统一登录页」的宿主：企业 + 个人 + 本地 + 注册/找回 + 多租户，全部在这里。parlant 等业务应用后续跳到这里登录（P3 收敛）。

## 6. 后台管理台（admin console）

| 页面 | 数据源（docs/04 §3.2） | 权限点 |
|---|---|---|
| 用户列表/新建 | `GET/POST /api/v1/admin/users` | `iam:user:read/write` |
| 租户列表/新建/域名 | `GET/POST /api/v1/admin/tenants` + 域名验证 | `iam:tenant:*` |
| 成员/邀请/移除 | `GET/POST/DELETE /api/v1/admin/members` | `iam:member:*` |
| 角色/授权 | `GET/POST /api/v1/admin/roles` + `roles/{id}/permissions` | `iam:role:*` |
| 加入申请审批 | `POST /api/v1/admin/join-requests/{id}/approve|reject` | `iam:member:write` |
| 审计 | `GET /api/v1/admin/audit` | `iam:audit:read` |

- 导航按权限点动态显隐（无 `iam:*` 的登录用户只见 `/me`，管理台入口隐藏）。
- 表单/表格统一 Ant Design；分页对接后端分页插件。
- **新建租户表单（docs/06 §5.3 契约，必读）**：必选 `app_codes`（勾选要启用的应用，≥1，租户按启用应用灌入预置角色）；可选 `owner_user_id`（首人管理员，建租户即授模板 `is_owner` 角色并可直接登录）；应用清单由平台配置模板提供，前端只读勾选。

### 6.1 两级管理员承载（平台级 / 租户级）

**一个 platform-iam-web 同时服务两类管理员**（不做两个前端），靠「token 上下文 + 后端作用域校验」区分入口与范围：

| | 平台管理员（PlatformAdmin） | 租户管理员（当前租户 TenantAdmin） |
|---|---|---|
| 登录后上下文 | `/me` → roles 含 PlatformAdmin、permissions 含平台 `iam:*` | switch 到本租户 → token.tenantId=本租户、permissions 含租户内管理权限（`iam:member/role:*`） |
| 界面入口 | 平台管理：**全部租户**、平台用户、审计、跨租户成员/角色 | 租户管理：**本租户**成员、角色、邀请、加入申请审批 |
| 操作范围 | 任意租户（后端平台级放行） | 仅当前租户（后端校验 `目标.tenant_id == token.tenantId`，否则 403） |

- **租户上下文**：登录后从 `/auth/memberships` 取可切换租户；租户管理员进入本租户（switch-tenant），管理页操作带当前 tenantId；平台管理员有「全部租户」视图（选中任一租户操作）。
- **页面参数化**：成员/角色/邀请/加入申请页参数化 `tenant_id`——租户管理员传「当前租户」，平台管理员传「选中租户」；同一套页面复用。
- **前端只做 UX 分层，不承担安全边界**：真正的"租户管理员只能管本租户"由后端作用域校验保证（docs/06 §3.3），前端误显跨租户入口也会被后端 403。

---

## 7. 页面交互设计（轻量线框）

> 目标：开工前把关键屏幕与交互流定下来，防返工。覆盖登录 hub、管理台布局（两级入口）、建租户表单（docs/06 §5.3 新契约）、主要管理页；组件映射见 §7.4。

### 7.1 登录 hub（/login，公开）

```
┌──────────────────────────────────────────────────┐
│                  IAM 统一登录                      │
│                                                  │
│   ┌────────────┐   ┌────────────┐   ┌──────────┐ │
│   │   企业 SSO  │   │  本地账号   │   │  个人账号 │ │
│   │            │   │ [username] │   │          │ │
│   │  使用企业    │   │ [password] │   │  未配置   │ │
│   │  账号登录    │   │ [ 登 录 ]  │   │  （置灰） │ │
│   └────────────┘   └────────────┘   └──────────┘ │
│                                                  │
│     还没有账号？注册  ·  忘记密码                    │
└──────────────────────────────────────────────────┘
```

- **企业 SSO 卡**：按钮 → `window.location = IAM_BASE/api/v1/auth/oidc/authorize?tenant_id=org-a`（顶层导航，无 CORS）→ IAM 认证后 302 回 `/login?access_token=...` → `Login.tsx` 读 query → 存 token → 跳 `/me`（或 `return_to`）。
- **本地账号卡**：表单 → `POST /api/v1/auth/token`（Vite proxy 同源）→ 存 token + user → 跳。
- **个人账号卡**：依赖平台级 IdP（未配置，docs/04 A.5）→ **渲染但置灰 + tooltip「暂未开放」**，配好 IdP 后启用。
- **注册 / 忘记密码**：跳转 `/register`、`/forgot-password`（公开路由，§4）。

### 7.2 管理台布局（两级管理员，/admin/*）

**整体版式**（平台管理员视角）：

```
┌──────────┬──────────────────────────────────────────┐
│  IAM ▍   │  [org-a ▾]                      admin ▾   │  ← Header：租户选择器 + 用户菜单
│──────────┤──────────────────────────────────────────┤
│ 全部租户  │   成员管理                                │
│ 平台用户  │  ┌────────────────────────────────────────┐│
│ 租户管理  │  │ [搜索用户名…]                  [+ 添加成员]││
│ 审计      │  │ ┌─ Table ──────────────────────────────┐││
│ SSO 配置  │  │ │用户名 │ 角色 │ 加入方式 │ 状态 │ 操作    │││
│          │  │ │…     │     │         │     │ 移除    │││
│          │  │ └──────────────────────────────────────┘││
│          │  │                      ◀ 1 2 3 ▶ (分页)   ││
│          │  └────────────────────────────────────────┘│
└──────────┴──────────────────────────────────────────┘
```

**两级管理员入口差异**（按 `permissions` 动态渲染侧导航）：

| 侧导航项 | 平台管理员 | 租户管理员（TenantAdmin） |
|---|---|---|
| 全部租户 / 平台用户 / 审计 / SSO 配置 | 显示 | **隐藏**（无 `iam:tenant:*`/`iam:audit:read`/`iam:idp:*`） |
| 租户管理（成员/角色/邀请/审批） | 显示，「选中租户」上下文 | 显示，「当前租户」上下文 |

- **租户选择器**：平台管理员可从「全部租户」选任意租户作为操作上下文；租户管理员固定当前租户（或隐藏选择器）。
- 无 `iam:*` 的普通用户：不渲染 `/admin` 入口，只见 `/me`。
- **页面参数化**：成员/角色/邀请/审批页统一 `tenant_id` 参数——租户管理员传当前租户、平台管理员传选中租户（§6.1）。

### 7.3 各管理页线框

**① 建租户（重点，docs/06 §5.3 契约）**

```
新建租户
  基础信息
    租户编码 *          租户名称 *
    租户类型 *          主域名(可选)
  启用应用 *（必选，≥1）
    ☐ parlant-agent-server      ☐ …（来自 iam_application，只读勾选）
  首人管理员（可选）
    [搜索用户…]  → 选中后显示「user 名 · 建租户即授 TenantAdmin」
  域名（可选，可添加多行）
    [域名] [类型▾COMPANY] [策略▾REQUEST]   [+ 添加]
  [取消]  [创建]
```
- `app_codes` 为空 → 前端即校验拦截（后端也 400，双保险）。
- `owner_user_id` 选人下拉：`GET /admin/users` 搜索。
- 创建成功 → 跳转该租户详情/成员页（提示"已灌入 3 个预置角色"）。

**② 用户管理**（平台管理员）：表格（用户名/邮箱/状态/注册来源/操作：编辑·禁用）+ `+ 新建用户`。

**③ 成员管理**（§7.2 主图）：表格 + `+ 添加成员`（选用户 + 选角色）/ 行操作（授角色、移除）；`邀请`按钮（填邮箱 + 选默认角色）跳转邀请流程；`加入申请`子 Tab（列表 + 通过/拒绝）。

**④ 角色管理**：左侧角色列表（scope 内）+ 右侧权限配置（权限点 Tree 勾选，保存 → `PUT /roles/{id}/permissions`）；租户管理员只能改本租户角色（后端 403 兜底）。

**⑤ 审计**：顶部筛选（租户/事件类型/操作人/时间）+ 表格（时间/事件/操作者/目标/结果）+ 分页；平台管理员专属。

**⑥ Me / 租户切换**：`/me` 显示当前身份 + `user.tenants[]`；多租户时 `/tenant-switch` 列表选择 → `POST /auth/switch-tenant` 换 token。

### 7.4 AntD 组件映射

| 场景 | 组件 |
|---|---|
| 应用布局 / 侧导航 / 头部 | `Layout(Sider/Header/Content)` + `Menu` + `Dropdown` |
| 各列表页 | `Table` + `Pagination` + `Input.Search` + `Button` |
| 表单（建租户/建用户/邀请） | `Form` + `Input` / `Select` / `Radio.Group` / `InputNumber` |
| 应用多选（建租户） | `Checkbox.Group`（应用少时）或 `Select mode="multiple"` |
| 角色/权限配置 | `Tree checkable`（权限点树）或 `Transfer` |
| 选人 / 选角色 | `Select showSearch`（远程搜索 `/admin/users`、`/admin/roles`） |
| 弹窗确认（移除成员/禁用用户） | `Modal.confirm` / `Modal` |
| 反馈 | `message.success/error` / `Alert` |
| 权限守卫 | 自实现 `RequireAuth` / `RequirePermission`（components/，读 zustand） |

### 7.5 关键交互流

1. **企业 SSO**：点卡 → 顶层跳 `oidc/authorize?tenant_id=...` → 回调 `302 → /login?access_token=...` → 存 token → 跳目标页。
2. **本地登录**：表单 → `POST /auth/token` → 存 token + user（roles/permissions）→ 按权限跳 `/admin` 或 `/me`。
3. **多租户切换**：`GET /auth/memberships` → 选择 → `POST /auth/switch-tenant` → 重存 token → 管理页 `tenant_id` 上下文刷新。
4. **入口显隐**：登录后按 `user.permissions` 渲染侧导航（§7.2 表）；**显隐只是 UX**，越权操作由后端 403（前端统一 403 提示页）。

### 7.6 收敛接线（形态 B：业务应用经 hub 登录，2026-10-11 已实现）

**模型**：parlant 等业务应用不再直连 `/oidc/authorize`，一律跳本 hub 登录；hub 是 SSO 回调**唯一**接收方，登录后带 token 回跳业务应用。

**配置 / 代码变更**：
| 项 | 值 / 动作 |
|---|---|
| IAM 后端 `frontend-redirect` | 默认固定 `http://localhost:5174/login`（hub 为唯一回调接收方） |
| hub `Login.tsx` | `return_to` **白名单**（`ALLOWED_RETURN_ORIGINS`，dev=`http://localhost:5173`）→ 存 sessionStorage（跨 SSO 往返保留）→ 登录成功后白名单源**外跳带 `?access_token=`**（`window.location.replace`，防 token 进历史）；否则内部跳 `/me` |
| parlant-agent-web `Login.tsx` | 企业 SSO 按钮改为跳 `VITE_IAM_HUB_BASE/login?return_to=<parlant origin>/login`（dev 默认 5174）；本页已有 `/login?access_token=` 收 token 逻辑复用 |
| parlant-agent-server `.env` | `AUTH_MODE=gateway` + `JWT_JWKS_URL=.../.well-known/jwks.json` + `IAM_TOKEN_URL=...`（CLAUDE.md） |

**链路**：parlant「企业 SSO」→ `hub/login?return_to=parlant` → 用户登录（本地 / SSO）→ hub 带 token 外跳 `parlant/login?access_token=` → parlant 收 token 进工作台（server 用同一 JWT + JWKS 验签）。

**安全**：`return_to` 仅白名单源可外跳（防 open redirect）；token 经 query 携带是 dev 形态，parlant 收后立即 `replaceState` 清 URL；生产可评估 HttpOnly cookie / postMessage 回传。

---

## 8. 与后端对接模式

- **dev**：Vite proxy `/api → http://localhost:8090`（同源，免 CORS；SSO 顶层导航本就无 CORS）。
- **prod**：nginx 反代 `/api → IAM:8090`；`IAM_BASE` 由部署环境注入。
- **鉴权**：axios 拦截器自动带 `Authorization: Bearer <token>`；401 → 清 token → 跳 `/login`。
- **SSE**：本 web 不消费 SSE；parlant 的 SSE 走各自 query token，与本 web 无关。

## 9. 与 parlant / IAM 后端的分工

| 应用 | 职责 |
|---|---|
| `unify-iam-server`（后端） | 身份/租户/RBAC/SSO/JWKS/令牌 + P3 管理 API（纯后端） |
| **`platform-iam-web`（本应用）** | **统一登录 hub + 后台管理台**（消费 IAM API） |
| parlant-agent（业务） | 业务 + 自己的极简登录页（先行）；P3 收敛后跳 `IAM_BASE/login?return_to=...` |

## 10. 里程碑（依赖 P3 后端）

1. **M1 脚手架 + 登录 hub**：Vite 工程 + `Login.tsx`（企业SSO/个人/本地三入口 + 回跳 token）+ `Me.tsx`——**用 P2 现有 API 即可跑通双账号**。
2. **M2 管理台骨架**：布局 + RequireAuth/RequirePermission + 用户/租户页（接 docs/04 §3.2 端点的第一批）。
3. **M3 补全管理功能**：成员/角色/审计/域名/审批 + 多租户切换（随 P3 后端交付逐项接入）。
4. **M4 生产化**：nginx 反代、token 安全（评估 HttpOnly cookie 回退）、审计埋点打通。

## 11. 风险与注意

- **CORS**：dev 用 Vite proxy 规避；prod 统一 nginx 反代，勿开 `*`。
- **token 存储**：本地先 localStorage（简单）；生产评估 HttpOnly cookie（SSE/跨域更稳），见 docs/03 §13.1。
- **权限展示**：管理台按 `iam:*` 动态显隐，避免给无权限用户看到 403 噪音。
- **与 parlant 的登录页并存**：P3 收敛前两处都有登录页，属预期；收敛后 parlant 只留跳转。
- **依赖顺序**：管理台强依赖 P3 后端（docs/04）；登录 hub 不依赖（P2 即可）。
- **独立仓库**：`platform-iam-web` 独立 git 仓库，与 unify-iam-server 解耦、各自演进。

## 12. 相关文档

- IAM 后端 P3：`docs/04-E2E3-P3管理面与账号生命周期设计.md`（本 web 消费的管理 API 与 `iam:*` 权限点）
- IAM SSO/登录流：`docs/03-E2E2-企业SSO与组织接入.md`（§8.1 个人租户、§13.1 前端承载）
- parlant 先行方案：`/Users/zhaoshan/workspace/parlant-agent/docs/06-dev-process/11-parlant-agent接入unify-iam-server方案-企业SSO与个人账号.md`

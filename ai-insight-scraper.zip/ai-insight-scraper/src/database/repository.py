"""任务仓储层 + 链接树仓储层

封装对 crawl_tasks / crawl_link_tree 表的所有数据库操作。
- TaskRepository: 任务表，输入输出使用 Pydantic CrawlTask 模型
- LinkTreeRepository: 链接树表，直接操作 ORM 模型（迁移/查询场景）
"""

import asyncio
import logging
from datetime import datetime

from sqlalchemy import select, update, delete, func
from sqlalchemy.exc import OperationalError

from src.database.connection import get_session
from src.database.models import (
    CrawlTaskModel,
    CrawlLinkTreeModel,
    CrawlScheduleModel,
    CrawlScheduleLogModel,
)
from src.models.crawl_task import CrawlTask, TaskProgress

logger = logging.getLogger(__name__)

# ── 重试配置 ──────────────────────────────────────────

MAX_RETRIES = 3
RETRY_BASE_DELAY = 1.0  # 基础重试延迟（秒）


def _retry_on_connection_error(func):
    """装饰器：对 SQLAlchemy OperationalError 自动重试（递增退避）。

    处理场景：
      - MySQL 连接超时断开后首次查询失败
      - 瞬时网络抖动
      - pool_pre_ping 失效后的边界情况
    """
    async def wrapper(self, *args, **kwargs):
        last_error = None
        for attempt in range(MAX_RETRIES):
            try:
                return await func(self, *args, **kwargs)
            except OperationalError as e:
                last_error = e
                if attempt < MAX_RETRIES - 1:
                    delay = RETRY_BASE_DELAY * (attempt + 1)
                    logger.warning(
                        f"数据库操作失败，第 {attempt + 1}/{MAX_RETRIES} 次重试 "
                        f"（{delay:.0f}s 后）: {e}"
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(
                        f"数据库操作失败，已重试 {MAX_RETRIES} 次: {e}"
                    )
        raise last_error
    return wrapper


class TaskRepository:
    """爬取任务仓储"""

    # ── ORM ↔ Pydantic 转换 ──────────────────────────

    @staticmethod
    def _model_to_pydantic(model: CrawlTaskModel) -> CrawlTask:
        """ORM 模型 → Pydantic 模型"""
        return CrawlTask(
            task_id=model.task_id,
            task_type=model.task_type,
            status=model.status,
            site=model.site,
            target_url=model.target_url,
            max_depth=model.max_depth,
            headless=model.headless,
            output_type=model.output_type,
            schedule_id=model.schedule_id,
            links_path=model.links_path,
            tree_path=model.tree_path,
            progress=TaskProgress(
                pages_crawled=model.pages_crawled,
                links_found=model.links_found,
            ),
            error_message=model.error_message,
            create_time=model.create_time,
            update_time=model.update_time,
            finished_at=model.finished_at,
        )

    @staticmethod
    def _pydantic_to_model(task: CrawlTask) -> CrawlTaskModel:
        """Pydantic 模型 → ORM 模型"""
        return CrawlTaskModel(
            task_id=task.task_id,
            task_type=task.task_type,
            status=task.status,
            site=task.site,
            target_url=task.target_url,
            max_depth=task.max_depth,
            headless=task.headless,
            output_type=task.output_type,
            schedule_id=task.schedule_id,
            links_path=task.links_path,
            tree_path=task.tree_path,
            pages_crawled=task.progress.pages_crawled,
            links_found=task.progress.links_found,
            error_message=task.error_message,
            create_time=task.create_time,
            update_time=task.update_time,
            finished_at=task.finished_at,
        )

    # ── CRUD 操作 ─────────────────────────────────────

    @_retry_on_connection_error
    async def create(self, task: CrawlTask) -> CrawlTask:
        """创建任务记录"""
        model = self._pydantic_to_model(task)
        async with get_session() as session:
            session.add(model)
            await session.commit()
            await session.refresh(model)
            logger.info(f"任务记录已创建: task_id={model.task_id}, type={model.task_type}, site={model.site}")
            return self._model_to_pydantic(model)

    async def find_by_id(self, task_id: str) -> CrawlTask | None:
        """根据 task_id 查询任务"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlTaskModel).where(CrawlTaskModel.task_id == task_id)
            )
            model = result.scalar_one_or_none()
            if model is None:
                return None
            return self._model_to_pydantic(model)

    @_retry_on_connection_error
    async def update_status(self, task_id: str, status: str) -> None:
        """更新任务状态"""
        async with get_session() as session:
            stmt = (
                update(CrawlTaskModel)
                .where(CrawlTaskModel.task_id == task_id)
                .values(status=status)
            )
            await session.execute(stmt)
            await session.commit()
            logger.info(f"任务状态更新: {task_id} → {status}")

    @_retry_on_connection_error
    async def update_progress(
        self, task_id: str, pages_crawled: int, links_found: int
    ) -> None:
        """更新任务进度"""
        async with get_session() as session:
            stmt = (
                update(CrawlTaskModel)
                .where(CrawlTaskModel.task_id == task_id)
                .values(pages_crawled=pages_crawled, links_found=links_found)
            )
            await session.execute(stmt)
            await session.commit()

    @_retry_on_connection_error
    async def mark_running(self, task_id: str) -> None:
        """标记任务为执行中"""
        async with get_session() as session:
            stmt = (
                update(CrawlTaskModel)
                .where(CrawlTaskModel.task_id == task_id)
                .values(status="running")
            )
            await session.execute(stmt)
            await session.commit()
            logger.info(f"任务开始执行: {task_id}")

    @_retry_on_connection_error
    async def mark_completed(
        self,
        task_id: str,
        links_path: str | None = None,
        tree_path: str | None = None,
        pages_crawled: int = 0,
        links_found: int = 0,
    ) -> None:
        """标记任务为完成，同时写入输出文件路径和进度"""
        now = datetime.now()
        values: dict = {
            "status": "completed",
            "finished_at": now,
            "pages_crawled": pages_crawled,
            "links_found": links_found,
        }
        if links_path is not None:
            values["links_path"] = links_path
        if tree_path is not None:
            values["tree_path"] = tree_path

        async with get_session() as session:
            stmt = (
                update(CrawlTaskModel)
                .where(CrawlTaskModel.task_id == task_id)
                .values(**values)
            )
            await session.execute(stmt)
            await session.commit()
            logger.info(f"任务完成: {task_id}, links_path={links_path}, tree_path={tree_path}")

    @_retry_on_connection_error
    async def mark_failed(self, task_id: str, error_message: str) -> None:
        """标记任务为失败"""
        now = datetime.now()
        async with get_session() as session:
            stmt = (
                update(CrawlTaskModel)
                .where(CrawlTaskModel.task_id == task_id)
                .values(
                    status="failed",
                    error_message=error_message,
                    finished_at=now,
                )
            )
            await session.execute(stmt)
            await session.commit()
            logger.error(f"任务失败: {task_id}, 错误: {error_message}")

    # ── 查询操作 ─────────────────────────────────────

    async def list_by_site(
        self, site: str, limit: int = 20, offset: int = 0
    ) -> list[CrawlTask]:
        """按站点查询任务列表（按创建时间倒序）"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlTaskModel)
                .where(CrawlTaskModel.site == site)
                .order_by(CrawlTaskModel.create_time.desc())
                .limit(limit)
                .offset(offset)
            )
            models = result.scalars().all()
            return [self._model_to_pydantic(m) for m in models]

    async def list_by_status(
        self, status: str, limit: int = 20, offset: int = 0
    ) -> list[CrawlTask]:
        """按状态查询任务列表"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlTaskModel)
                .where(CrawlTaskModel.status == status)
                .order_by(CrawlTaskModel.create_time.desc())
                .limit(limit)
                .offset(offset)
            )
            models = result.scalars().all()
            return [self._model_to_pydantic(m) for m in models]

    async def list_all(
        self, limit: int = 50, offset: int = 0
    ) -> list[CrawlTask]:
        """查询所有任务（按创建时间倒序）"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlTaskModel)
                .order_by(CrawlTaskModel.create_time.desc())
                .limit(limit)
                .offset(offset)
            )
            models = result.scalars().all()
            return [self._model_to_pydantic(m) for m in models]

    async def find_latest_by_site_and_type(
        self, site: str, task_type: str
    ) -> CrawlTask | None:
        """按 site + task_type 查询最新一条任务（按创建时间倒序）"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlTaskModel)
                .where(CrawlTaskModel.site == site)
                .where(CrawlTaskModel.task_type == task_type)
                .order_by(CrawlTaskModel.create_time.desc())
                .limit(1)
            )
            model = result.scalar_one_or_none()
            return self._model_to_pydantic(model) if model else None

    async def find_completed_by_site_and_type(
        self, site: str, task_type: str
    ) -> CrawlTask | None:
        """按 site + task_type 查询最新一条 status=completed 的任务"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlTaskModel)
                .where(CrawlTaskModel.site == site)
                .where(CrawlTaskModel.task_type == task_type)
                .where(CrawlTaskModel.status == "completed")
                .order_by(CrawlTaskModel.create_time.desc())
                .limit(1)
            )
            model = result.scalar_one_or_none()
            return self._model_to_pydantic(model) if model else None


class LinkTreeRepository:
    """全量链接树仓储

    直接操作 CrawlLinkTreeModel ORM 模型，供迁移脚本与查询场景使用。
    不引入 Pydantic 实体层（链接树主要用于查询展示，无复杂业务逻辑）。
    """

    # ── 写操作 ─────────────────────────────────────────

    @_retry_on_connection_error
    async def bulk_create(self, models: list[CrawlLinkTreeModel]) -> int:
        """批量插入链接树节点。

        每批一个事务，失败时由 _retry_on_connection_error 装饰器重试。
        调用方负责分批（建议每批 500 条），避免单事务过大。

        Args:
            models: ORM 模型对象列表

        Returns:
            实际插入条数
        """
        if not models:
            return 0
        async with get_session() as session:
            session.add_all(models)
            await session.commit()
            return len(models)

    @_retry_on_connection_error
    async def delete_by_site(self, site: str) -> int:
        """删除指定站点的全部链接树节点（迁移前重置用）。

        Args:
            site: 站点域名

        Returns:
            删除条数
        """
        async with get_session() as session:
            result = await session.execute(
                delete(CrawlLinkTreeModel).where(CrawlLinkTreeModel.site == site)
            )
            await session.commit()
            return result.rowcount or 0

    @_retry_on_connection_error
    async def update_fields_by_url(self, url: str, **values) -> bool:
        """按 URL 更新指定字段（增量同步用）。

        Args:
            url: 链接 URL（业务唯一键）
            **values: 待更新字段，如 update_history="新增"、update_time_tag=datetime

        Returns:
            是否命中并更新了一行
        """
        if not values:
            return False
        async with get_session() as session:
            stmt = (
                update(CrawlLinkTreeModel)
                .where(CrawlLinkTreeModel.url == url)
                .values(**values)
            )
            result = await session.execute(stmt)
            await session.commit()
            return (result.rowcount or 0) > 0

    # ── 查询操作 ─────────────────────────────────────

    async def find_by_url(self, url: str) -> CrawlLinkTreeModel | None:
        """按 URL 查询节点（用于迁移前校验是否已存在）"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlLinkTreeModel).where(CrawlLinkTreeModel.url == url)
            )
            return result.scalar_one_or_none()

    async def count_by_site(self, site: str) -> int:
        """统计指定站点的节点数"""
        async with get_session() as session:
            result = await session.execute(
                select(func.count()).select_from(CrawlLinkTreeModel)
                .where(CrawlLinkTreeModel.site == site)
            )
            return result.scalar_one()

    async def list_urls_by_site(self, site: str) -> list[str]:
        """列出指定站点的全部 URL（用于一致性比对）"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlLinkTreeModel.url)
                .where(CrawlLinkTreeModel.site == site)
            )
            return [row[0] for row in result.all()]

    async def list_by_urls(self, urls: list[str]) -> list[CrawlLinkTreeModel]:
        """按 URL 列表批量查询节点（增量同步时取待删除集合用）。

        Args:
            urls: URL 列表

        Returns:
            命中的 ORM 模型列表
        """
        if not urls:
            return []
        async with get_session() as session:
            result = await session.execute(
                select(CrawlLinkTreeModel).where(CrawlLinkTreeModel.url.in_(urls))
            )
            return list(result.scalars().all())

    async def list_all_by_site(self, site: str) -> list[CrawlLinkTreeModel]:
        """按站点列出全部节点（验证/导出用）"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlLinkTreeModel)
                .where(CrawlLinkTreeModel.site == site)
                .order_by(CrawlLinkTreeModel.id)
            )
            return list(result.scalars().all())

    async def search_by_site(
        self,
        site: str,
        search: str | None = None,
        limit: int = 5000,
    ) -> list[CrawlLinkTreeModel]:
        """按站点查询链接节点，支持对 url/page_title 模糊匹配。

        Args:
            site: 站点域名
            search: 模糊关键词，为空时返回站点下全部节点（受 limit 限制）
            limit: 返回条数上限

        Returns:
            匹配的 ORM 模型列表，按 id 升序
        """
        async with get_session() as session:
            stmt = select(CrawlLinkTreeModel).where(CrawlLinkTreeModel.site == site)
            if search:
                keyword = f"%{search}%"
                stmt = stmt.where(
                    (CrawlLinkTreeModel.url.like(keyword))
                    | (CrawlLinkTreeModel.page_title.like(keyword))
                )
            stmt = stmt.order_by(CrawlLinkTreeModel.id).limit(limit)
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def level_distribution(self, site: str) -> list[tuple[int, int]]:
        """统计指定站点的 level 分布（验证树结构用）。

        Returns:
            [(level, count), ...] 按 level 升序
        """
        async with get_session() as session:
            result = await session.execute(
                select(CrawlLinkTreeModel.level, func.count())
                .where(CrawlLinkTreeModel.site == site)
                .group_by(CrawlLinkTreeModel.level)
                .order_by(CrawlLinkTreeModel.level)
            )
            return [(row[0], row[1]) for row in result.all()]


class ScheduleRepository:
    """定时调度配置仓储"""

    @_retry_on_connection_error
    async def create(self, model: CrawlScheduleModel) -> CrawlScheduleModel:
        """创建调度配置"""
        async with get_session() as session:
            session.add(model)
            await session.commit()
            await session.refresh(model)
            logger.info(f"调度配置已创建: schedule_id={model.schedule_id}, site={model.site}")
            return model

    async def find_by_id(self, schedule_id: str) -> CrawlScheduleModel | None:
        """按 schedule_id 查询调度配置"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlScheduleModel).where(CrawlScheduleModel.schedule_id == schedule_id)
            )
            return result.scalar_one_or_none()

    @_retry_on_connection_error
    async def update(self, model: CrawlScheduleModel) -> CrawlScheduleModel:
        """更新调度配置（model 必须已存在）"""
        async with get_session() as session:
            merged = await session.merge(model)
            await session.commit()
            await session.refresh(merged)
            logger.info(f"调度配置已更新: schedule_id={model.schedule_id}")
            return merged

    @_retry_on_connection_error
    async def delete(self, schedule_id: str) -> bool:
        """删除调度配置"""
        async with get_session() as session:
            result = await session.execute(
                delete(CrawlScheduleModel).where(CrawlScheduleModel.schedule_id == schedule_id)
            )
            await session.commit()
            deleted = (result.rowcount or 0) > 0
            if deleted:
                logger.info(f"调度配置已删除: schedule_id={schedule_id}")
            return deleted

    async def list_all(
        self,
        site: str | None = None,
        enabled: bool | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[CrawlScheduleModel]:
        """列表查询调度配置"""
        async with get_session() as session:
            stmt = select(CrawlScheduleModel).order_by(CrawlScheduleModel.create_time.desc())
            if site:
                stmt = stmt.where(CrawlScheduleModel.site == site)
            if enabled is not None:
                stmt = stmt.where(CrawlScheduleModel.enabled == (1 if enabled else 0))
            stmt = stmt.limit(limit).offset(offset)
            result = await session.execute(stmt)
            return list(result.scalars().all())

    async def list_enabled(self) -> list[CrawlScheduleModel]:
        """查询所有启用的调度配置"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlScheduleModel)
                .where(CrawlScheduleModel.enabled == 1)
                .order_by(CrawlScheduleModel.create_time.desc())
            )
            return list(result.scalars().all())


class ScheduleLogRepository:
    """定时调度执行日志仓储"""

    @_retry_on_connection_error
    async def delete(self, log_id: str) -> bool:
        """按 log_id 删除执行日志"""
        async with get_session() as session:
            result = await session.execute(
                delete(CrawlScheduleLogModel).where(CrawlScheduleLogModel.log_id == log_id)
            )
            await session.commit()
            deleted = (result.rowcount or 0) > 0
            if deleted:
                logger.info(f"调度日志已删除: log_id={log_id}")
            return deleted

    @_retry_on_connection_error
    async def create(self, model: CrawlScheduleLogModel) -> CrawlScheduleLogModel:
        """创建执行日志"""
        async with get_session() as session:
            session.add(model)
            await session.commit()
            await session.refresh(model)
            logger.info(f"调度日志已创建: log_id={model.log_id}, schedule_id={model.schedule_id}")
            return model

    async def find_by_id(self, log_id: str) -> CrawlScheduleLogModel | None:
        """按 log_id 查询执行日志"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlScheduleLogModel).where(CrawlScheduleLogModel.log_id == log_id)
            )
            return result.scalar_one_or_none()

    @_retry_on_connection_error
    async def update_status(
        self,
        log_id: str,
        status: str,
        **kwargs,
    ) -> None:
        """更新日志状态及附加字段"""
        values: dict = {"status": status, **kwargs}
        async with get_session() as session:
            stmt = (
                update(CrawlScheduleLogModel)
                .where(CrawlScheduleLogModel.log_id == log_id)
                .values(**values)
            )
            await session.execute(stmt)
            await session.commit()
            logger.info(f"调度日志状态更新: log_id={log_id} → {status}")

    @_retry_on_connection_error
    async def mark_running(self, log_id: str) -> None:
        """标记日志为执行中"""
        await self.update_status(log_id, "running", started_at=datetime.now())

    @_retry_on_connection_error
    async def mark_completed(
        self,
        log_id: str,
        task_id: str | None = None,
        links_path: str | None = None,
        tree_path: str | None = None,
        pages_crawled: int = 0,
        links_found: int = 0,
    ) -> None:
        """标记日志为完成"""
        values: dict = {
            "status": "completed",
            "finished_at": datetime.now(),
            "pages_crawled": pages_crawled,
            "links_found": links_found,
        }
        if task_id is not None:
            values["task_id"] = task_id
        if links_path is not None:
            values["links_path"] = links_path
        if tree_path is not None:
            values["tree_path"] = tree_path
        await self.update_status(log_id, **values)

    @_retry_on_connection_error
    async def mark_failed(
        self,
        log_id: str,
        error_message: str,
        task_id: str | None = None,
    ) -> None:
        """标记日志为失败"""
        values: dict = {
            "status": "failed",
            "finished_at": datetime.now(),
            "error_message": error_message,
        }
        if task_id is not None:
            values["task_id"] = task_id
        await self.update_status(log_id, **values)

    @_retry_on_connection_error
    async def mark_skipped(
        self,
        log_id: str,
        error_message: str = "",
    ) -> None:
        """标记日志为跳过"""
        await self.update_status(
            log_id,
            "skipped",
            finished_at=datetime.now(),
            error_message=error_message,
        )

    async def list_by_schedule(
        self,
        schedule_id: str,
        limit: int = 20,
        offset: int = 0,
    ) -> list[CrawlScheduleLogModel]:
        """按 schedule_id 查询执行日志（按创建时间倒序）"""
        async with get_session() as session:
            result = await session.execute(
                select(CrawlScheduleLogModel)
                .where(CrawlScheduleLogModel.schedule_id == schedule_id)
                .order_by(CrawlScheduleLogModel.create_time.desc())
                .limit(limit)
                .offset(offset)
            )
            return list(result.scalars().all())

# Fix tenant list scope filtering

## Goal

Make `GET /api/v1/admin/tenants` honor its scope query contract so a tenant-scoped request returns only the requested tenant while the existing platform list, permission checks, pagination limit, application enrichment, and response envelope remain correct.

## Background and confirmed facts

- The current branch is `feature/lee-1102`; the working tree was clean when this task started.
- `AdminTenantController#list` currently accepts only `limit` and always calls `AdminTenantService#list(limit)`.
- `TenantRepository#listAll(limit)` currently orders by database id and applies the existing 1..1000 limit clamp, but has no scope predicate.
- The endpoint is protected by `iam:tenant:read`, which the platform bootstrap assigns to the platform role. Member-only users do not receive this permission and are rejected before list data is returned.
- Repository and user-manual conventions use snake_case request names (`scope_type`, `scope_id`) and scope values `PLATFORM` and `TENANT`. `PLATFORM` uses the fixed scope id `PLATFORM`; `TENANT` uses a concrete tenant id.
- Existing role-list behavior establishes the domain meaning: platform scope is the global management view; tenant scope identifies one tenant. Tenant list filtering must not weaken the endpoint's existing permission isolation.

## Requirements

1. Add optional `scope_type` and `scope_id` query parameters to `GET /api/v1/admin/tenants`.
2. Preserve the current unfiltered behavior when neither scope parameter is supplied.
3. For `scope_type=PLATFORM&scope_id=PLATFORM`, return the platform list using the existing limit/order/enrichment behavior.
4. For `scope_type=TENANT&scope_id=<tenant_id>`, apply the tenant id predicate before the limit and return only that tenant when it exists; return an empty list for a missing/deleted tenant without leaking another tenant.
5. Validate the scope contract at the API boundary: values are exact uppercase `PLATFORM` or `TENANT`; `scope_id` is required when `scope_type` is supplied; `PLATFORM` requires `scope_id=PLATFORM`; `TENANT` requires a non-blank tenant id. Invalid combinations return the project's standard 400 error envelope.
6. Keep snake_case names as the supported field names. A camelCase/incorrectly cased name must not be treated as a supported scope filter; regression coverage must make this contract explicit.
7. Keep authorization, application summaries, count semantics, and the current limit clamp unchanged.

## Acceptance Criteria

- [x] A correctly named platform query returns the same complete platform list semantics as an unfiltered request.
- [x] A correctly named tenant query returns only the requested tenant and preserves its application summaries and count.
- [x] Missing scope parameters preserve the existing list behavior.
- [x] Lowercase/mixed-case scope values and invalid scope combinations return 400.
- [x] Incorrect field names such as `scopeType` are not accepted as scope filters and are covered by a regression test.
- [x] Existing permissions still gate the endpoint; the existing permission regression remains in `SelfMembershipTenantCodeIntegrationTest`.
- [x] Focused integration coverage and diff/static checks are complete; Maven execution is blocked by the environment's Java 26/Lombok baseline failure recorded in the session report.

## Out of scope

- Adding keyword/status/type search, page/size pagination, or a new total-count contract described as future G4 work.
- Changing tenant creation, role scope authorization, response field names, or frontend code.
- Committing, pushing, merging, switching branches, or creating/deleting worktrees.

## Open questions

None. The requested scope semantics and strict parameter contract are resolved from the repository conventions and the user’s acceptance requirements.

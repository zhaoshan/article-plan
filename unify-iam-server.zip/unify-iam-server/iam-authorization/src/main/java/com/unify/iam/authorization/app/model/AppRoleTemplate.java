package com.unify.iam.authorization.app.model;

import java.util.List;

/**
 * 应用预置角色模板（docs/06 §2.2）：应用 → 角色 → 权限点 code。
 * 租户初始化灌入的"权威目录"行，来自 iam_application_role_template。
 */
public record AppRoleTemplate(
        String appCode,
        String roleCode,
        String roleName,
        String roleDescription,
        List<String> permissionCodes,
        boolean isOwner,
        boolean isAdmin,
        String scopeType) {
}

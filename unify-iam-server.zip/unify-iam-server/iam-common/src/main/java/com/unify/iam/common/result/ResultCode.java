package com.unify.iam.common.result;

/** 常用结果码。 */
public final class ResultCode {

    private ResultCode() {
    }

    /** 成功 */
    public static final String SUCCESS = "0";
    /** 通用业务错误 */
    public static final String BIZ_ERROR = "IAM-BUSI-000";
    /** 参数错误 */
    public static final String PARAM_ERROR = "IAM-PARAM-000";
    /** 认证失败 */
    public static final String AUTH_ERROR = "IAM-AUTH-000";
    /** 系统错误 */
    public static final String SYSTEM_ERROR = "IAM-SYST-000";
}

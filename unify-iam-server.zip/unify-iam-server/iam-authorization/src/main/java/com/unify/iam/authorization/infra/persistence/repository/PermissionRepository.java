package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.PermissionMapper;
import com.unify.iam.authorization.infra.persistence.po.PermissionPO;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Repository;

/** 权限点仓储（租户初始化灌入用：code → id 映射）。 */
@Repository
public class PermissionRepository {

    private final PermissionMapper permissionMapper;

    public PermissionRepository(PermissionMapper permissionMapper) {
        this.permissionMapper = permissionMapper;
    }

    /** 按权限 code 集查 ACTIVE 权限点，返回 code → permission_id。 */
    public Map<String, String> findIdByCodes(List<String> codes) {
        if (codes == null || codes.isEmpty()) {
            return Map.of();
        }
        return permissionMapper.selectList(new LambdaQueryWrapper<PermissionPO>()
                        .in(PermissionPO::getPermissionCode, codes)
                        .eq(PermissionPO::getPermissionStatus, "ACTIVE"))
                .stream()
                .collect(Collectors.toMap(PermissionPO::getPermissionCode, PermissionPO::getPermissionId,
                        (a, b) -> a));
    }

    /** 全部 ACTIVE 权限点（管理台角色授权清单，docs/05 §7.3 ④）。 */
    public List<PermissionPO> listActive() {
        return permissionMapper.selectList(new LambdaQueryWrapper<PermissionPO>()
                .eq(PermissionPO::getPermissionStatus, "ACTIVE")
                .orderByAsc(PermissionPO::getId));
    }

    /** 按 permission_id 集查（角色授权校验用，V8 权限隔离）。 */
    public List<PermissionPO> findByIds(Collection<String> permissionIds) {
        if (permissionIds == null || permissionIds.isEmpty()) {
            return List.of();
        }
        return permissionMapper.selectList(new LambdaQueryWrapper<PermissionPO>()
                .in(PermissionPO::getPermissionId, permissionIds));
    }
}

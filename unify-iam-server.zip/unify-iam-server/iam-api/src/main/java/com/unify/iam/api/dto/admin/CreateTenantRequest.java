package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

/**
 * 建租户（管理面）：编码/名称/类型/可选主域名/可选首人用户 + 必选启用的应用。
 *
 * <p>{@code app_codes} 显式填写（docs/06 §2.3 / §5.3）：租户按启用的应用初始化灌入预置角色。
 */
public record CreateTenantRequest(
        @NotBlank(message = "tenant_code 不能为空") @JsonProperty("tenant_code") String tenantCode,
        @NotBlank(message = "tenant_name 不能为空") @JsonProperty("tenant_name") String tenantName,
        @JsonProperty("tenant_type") String tenantType,
        @JsonProperty("primary_domain") String primaryDomain,
        @JsonProperty("owner_user_id") String ownerUserId,
        /** G2 A-02「Create and send invite」：任意 Owner 邮箱（与 owner_user_id 二选一；邮箱不存在则 JIT 建号+初始密码） */
        @JsonProperty("owner_email") String ownerEmail,
        @NotEmpty(message = "app_codes 不能为空：至少选择一个应用") @JsonProperty("app_codes") List<String> appCodes) {
}

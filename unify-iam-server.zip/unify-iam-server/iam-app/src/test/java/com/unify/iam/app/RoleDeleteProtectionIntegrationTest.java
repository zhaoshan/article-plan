package com.unify.iam.app;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G6 角色删除保护：① 预置角色（is_builtin=1）不可删；② 仍被成员持有不可删（清空绑定后可删）。
 */
class RoleDeleteProtectionIntegrationTest extends IamIntegrationTestBase {

    private String adminToken() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("access_token").toString();
    }

    private String createCustomRole(String token, String tenantId, String code) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"" + tenantId + "\","
                                + "\"role_code\":\"" + code + "\",\"role_name\":\"" + code + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("role_id").toString();
    }

    @Test
    void builtinRoleCannotBeDeleted() throws Exception {
        String token = adminToken();
        // r-1002 TenantAdmin：seed 预置角色（is_builtin=1）
        mockMvc.perform(delete("/api/v1/admin/roles/r-1002").header("Authorization", "Bearer " + token))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("Builtin role")));
        // 模板灌入的角色同样 is_builtin=1：给 org-a 再灌一个模板角色不可删（用 r-1001 AgentOperator 验证）
        mockMvc.perform(delete("/api/v1/admin/roles/r-1001").header("Authorization", "Bearer " + token))
                .andExpect(status().isBadRequest());
    }

    @Test
    void heldRoleCannotBeDeletedUntilUnbound() throws Exception {
        String token = adminToken();
        String roleId = createCustomRole(token, "tenant-org-a", "DeletableRole");
        // 未持有 → 可删
        mockMvc.perform(delete("/api/v1/admin/roles/" + roleId).header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());

        // 重新建并绑定给 operator（ms-2001）→ 持有中不可删
        String roleId2 = createCustomRole(token, "tenant-org-a", "HeldRole");
        mockMvc.perform(put("/api/v1/admin/members/ms-2001/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"" + roleId2 + "\"]}"))
                .andExpect(status().isOk());
        mockMvc.perform(delete("/api/v1/admin/roles/" + roleId2).header("Authorization", "Bearer " + token))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("member(s)")));
        // 清空绑定 → 可删
        mockMvc.perform(put("/api/v1/admin/members/ms-2001/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[]}"))
                .andExpect(status().isOk());
        mockMvc.perform(delete("/api/v1/admin/roles/" + roleId2).header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
        // 还原 operator 原角色绑定（共享库，防影响其他用例）
        mockMvc.perform(put("/api/v1/admin/members/ms-2001/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"r-1001\"]}"))
                .andExpect(status().isOk());
    }
}

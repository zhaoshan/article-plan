"""CrawlSchedule Pydantic 模型单元测试"""

import pytest

from src.models.crawl_schedule import (
    CrawlScheduleCreate,
    CrawlScheduleUpdate,
)


class TestCrawlScheduleCreate:
    """CrawlScheduleCreate 创建请求校验"""

    def test_valid_minimal_schedule(self):
        """最小合法调度配置"""
        data = CrawlScheduleCreate(
            site="tokyostarbank.co.jp",
            target_url="https://www.tokyostarbank.co.jp/",
            cron_expression="0 2 * * *",
        )
        assert data.site == "tokyostarbank.co.jp"
        assert data.timezone == "Asia/Tokyo"
        assert data.enabled is True
        assert data.output_type == "s3"

    def test_valid_local_output(self):
        """local 输出方式合法"""
        data = CrawlScheduleCreate(
            site="example.com",
            target_url="https://example.com/",
            cron_expression="*/5 * * * *",
            output_type="local",
        )
        assert data.output_type == "local"

    def test_invalid_url_scheme(self):
        """URL 协议非法应报错"""
        with pytest.raises(ValueError):
            CrawlScheduleCreate(
                site="example.com",
                target_url="ftp://example.com/",
                cron_expression="0 2 * * *",
            )

    def test_invalid_cron_expression(self):
        """cron 表达式非法应报错"""
        with pytest.raises(ValueError):
            CrawlScheduleCreate(
                site="example.com",
                target_url="https://example.com/",
                cron_expression="invalid",
            )

    def test_invalid_output_type(self):
        """output_type 不是 local/s3 应报错"""
        with pytest.raises(ValueError):
            CrawlScheduleCreate(
                site="example.com",
                target_url="https://example.com/",
                cron_expression="0 2 * * *",
                output_type="ftp",
            )


class TestCrawlScheduleUpdate:
    """CrawlScheduleUpdate 更新请求校验"""

    def test_partial_update(self):
        """部分字段更新"""
        data = CrawlScheduleUpdate(enabled=False)
        assert data.enabled is False
        assert data.site is None

    def test_invalid_url_in_update(self):
        """更新时 URL 协议非法应报错"""
        with pytest.raises(ValueError):
            CrawlScheduleUpdate(target_url="ftp://example.com/")

    def test_invalid_cron_in_update(self):
        """更新时 cron 非法应报错"""
        with pytest.raises(ValueError):
            CrawlScheduleUpdate(cron_expression="not-a-cron")

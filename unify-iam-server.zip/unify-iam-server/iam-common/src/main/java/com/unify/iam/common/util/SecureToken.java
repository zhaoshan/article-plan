package com.unify.iam.common.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/** 一次性令牌工具：随机 token（明文返回一次）+ SHA-256 哈希（落库）。 */
public final class SecureToken {

    private SecureToken() {
    }

    /** 生成 48 字节随机 URL-safe token。 */
    public static String random() {
        byte[] buf = new byte[48];
        new SecureRandom().nextBytes(buf);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(buf);
    }

    /** SHA-256 → Base64URL（存哈希用）。 */
    public static String hash(String value) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
        } catch (Exception e) {
            throw new IllegalStateException("token 哈希失败", e);
        }
    }
}

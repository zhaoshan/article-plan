package com.unify.iam.common.exception;

import com.unify.iam.common.result.ResultCode;
import lombok.Getter;

/**
 * 业务异常基类。
 *
 * <p>携带可选的 {@code httpStatus}：默认 200（沿用 ai-chat-insight"业务失败 200 信封"约定，
 * 供未来内部管理接口使用）；派生类 {@link AuthException} 强制真实 HTTP 状态（对外契约端点）。
 */
@Getter
public class BizException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String code;
    private final int httpStatus;

    public BizException(String message) {
        this(ResultCode.BIZ_ERROR, 200, message);
    }

    public BizException(String code, String message) {
        this(code, 200, message);
    }

    public BizException(String code, int httpStatus, String message) {
        super(message);
        this.code = code;
        this.httpStatus = httpStatus;
    }

    public BizException(ErrorCode errorCode) {
        this(errorCode.getCode(), 200, errorCode.getMessage());
    }
}

import asyncio
import logging
from collections import deque
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext, Page
from typing import Set, List, Dict, Callable, Optional, Tuple
from urllib.parse import urlparse, urljoin
import json
from datetime import datetime

from common_response import DefaultResult


class DeepNestedLinksCrawler:
    """
    深度下钻页面链接爬虫

    功能特性：
    1. 给定一个链接和深度，逐级下钻获取所有子页面链接
    2. 只下钻链接域名内的子页面，对于.pdf 类的文件链接，不需要下钻
    3. 全局记录某个链接是否下钻过，如果下钻过，就不需要再次下钻
    4. 下钻获取到的子页面链接，去重存储，每完成一个页面就存储一个页面的所有子页面
    """

    # 不需要下钻的文件扩展名
    NON_CRAWLABLE_EXTENSIONS = {'.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
                                 '.zip', '.rar', '.tar', '.gz', '.7z',
                                 '.jpg', '.jpeg', '.png', '.gif', '.svg', '.webp', '.bmp', '.ico',
                                 '.mp3', '.mp4', '.avi', '.mov', '.wmv', '.flv',
                                 '.txt', '.csv', '.xml', '.json'}

    def __init__(self,
                 headless: bool = True,
                 chrome_executable_path: Optional[str] = None,
                 user_data_dir: Optional[str] = None,
                 debug_port: int = 9222,
                 on_page_completed: Optional[Callable[[str, List[str]], None]] = None,
                 log_dir: Optional[str] = None,
                 global_links_file: Optional[str] = None,
                 log_file: Optional[str] = None):
        """
        初始化爬虫

        Args:
            headless: 是否无头模式
            chrome_executable_path: Chrome 可执行文件路径
            user_data_dir: Chrome 用户数据目录（持久化会话）
            debug_port: Chrome 调试端口
            on_page_completed: 回调函数，当单个页面爬取完成时调用，参数为 (page_url, links)
            log_dir: 日志文件输出目录
            global_links_file: 全局去重链接文件路径
            log_file: 日志文件路径（可选，不提供则使用 log_dir 自动生成）
        """
        self.headless = headless
        self.chrome_executable_path = chrome_executable_path
        self.user_data_dir = user_data_dir
        self.debug_port = debug_port
        self.on_page_completed = on_page_completed
        self.log_dir = log_dir
        self.global_links_file = Path(global_links_file) if global_links_file else None
        self.log_file = Path(log_file) if log_file else None

        # 页面爬取统计信息
        self.page_stats: Dict[str, dict] = {}

        self.user_agent = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        )

        # 全局已爬取的 URL 集合（标准化后）
        self.crawled_urls: Set[str] = set()

        # 保存最终结果存储每个页面的子链接：{page_url: [child_urls]}
        self.page_links_map: Dict[str, List[str]] = {}

        # 目标域名（用于过滤）
        self.target_domain: Optional[str] = None

        # 爬取开始时间
        self.crawl_start_time: Optional[str] = None

        # 保存最终结果全局去重链接集合（所有页面爬取到的链接）
        self.global_unique_links: Set[str] = set()

        # 树结构：父→子映射（每个 URL 只出现一次作为子节点）
        self.tree_map: Dict[str, List[str]] = {}

        # 树结构：子→父映射（用于回溯路径）
        self.parent_map: Dict[str, Optional[str]] = {}

        # 已作为树节点占位的 URL 集合
        self.seen_as_node: Set[str] = set()

        # tree 模式增量输出目录（如果设置，每完成一个页面就写入文件）
        self.tree_output_dir: Optional[str] = None

        # tree 模式输出文件时间戳后缀
        self._tree_output_timestamp: Optional[str] = None

        # 日志文件处理器
        self._file_handler: Optional[logging.FileHandler] = None

    def _find_chrome_path(self) -> str:
        """查找本地 Chrome 浏览器可执行文件路径"""
        import platform
        import os

        system = platform.system()
        if system == "Windows":
            paths = [
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            ]
        elif system == "Darwin":
            paths = [
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            ]
        else:  # Linux
            paths = [
                "/usr/bin/google-chrome",
                "/usr/bin/google-chrome-stable",
            ]

        for path in paths:
            if os.path.exists(path):
                return path
        return ""

    def _setup_file_handler(self):
        """
        设置日志文件处理器，将日志输出到文件
        """
        if self.log_dir:
            log_path = Path(self.log_dir)
            log_path.mkdir(parents=True, exist_ok=True)

            # 使用开始时间作为日志文件名
            log_file = self.log_file or (log_path / f"crawl_{self.crawl_start_time}.log")
            log_file.parent.mkdir(parents=True, exist_ok=True)

            # 创建文件处理器
            self._file_handler = logging.FileHandler(log_file, encoding='utf-8')
            self._file_handler.setLevel(logging.INFO)

            # 设置日志格式
            formatter = logging.Formatter('[%(asctime)s] %(levelname)s - %(message)s',
                                         datefmt='%d/%b/%Y %H:%M:%S')
            self._file_handler.setFormatter(formatter)

            # 添加到根日志记录器
            logging.getLogger().addHandler(self._file_handler)
            logging.info(f"日志文件已设置：{log_file}")

    def _cleanup_file_handler(self):
        """
        清理日志文件处理器
        """
        if self._file_handler:
            self._file_handler.close()
            logging.getLogger().removeHandler(self._file_handler)
            self._file_handler = None

    # 保留 www. 前缀的域名列表（这些域名的 www 与裸域名指向不同内容）
    KEEP_WWW_DOMAINS = {'www.tokyostarbank.co.jp'}

    def normalize_url(self, url_string: str) -> str:
        """
        标准化 URL 用于去重比较
        忽略查询参数和哈希，只保留协议、域名和路径

        Args:
            url_string: 原始 URL 字符串

        Returns:
            str: 标准化后的 URL（不包含查询参数和哈希）
        """
        try:
            url = urlparse(url_string)

            # 只处理 http/https 协议
            if url.scheme not in ['http', 'https']:
                return url_string.lower()

            # 1. 统一协议和主机名（移除 www，但排除保留 www. 的域名）
            host = url.netloc
            # 检查当前 host 是否属于需要保留 www. 的域名
            if not any(host == domain or host.endswith('.' + domain.split('.', 1)[1])
                       for domain in self.KEEP_WWW_DOMAINS if host.startswith('www.')):
                host = host.replace('www.', '')

            # 2. 统一路径（移除末尾斜杠）
            pathname = url.path.rstrip('/')

            # 返回标准化 URL（忽略查询参数和哈希）
            result = f"{url.scheme}://{host}{pathname}"

            return result.lower()
        except Exception as e:
            logging.warning(f"URL 标准化失败：{url_string}, 错误：{e}")
            return url_string.lower()

    def get_domain(self, url_string: str) -> Optional[str]:
        """
        提取 URL 的域名

        Args:
            url_string: URL 字符串

        Returns:
            str: 域名（不含 www），如果解析失败则返回 None
        """
        try:
            parsed = urlparse(url_string)
            if parsed.scheme not in ['http', 'https']:
                return None
            # 移除 www. 前缀
            host = parsed.netloc.replace('www.', '')
            return host.lower()
        except Exception:
            return None

    def is_same_domain(self, url_string: str) -> bool:
        """
        检查 URL 是否与目标域名相同

        Args:
            url_string: URL 字符串

        Returns:
            bool: 是否同域名
        """
        if not self.target_domain:
            return True  # 如果没有设置目标域名，则认为都符合

        url_domain = self.get_domain(url_string)
        if not url_domain:
            return False

        # 精确匹配或子域名匹配
        return url_domain == self.target_domain or url_domain.endswith('.' + self.target_domain)

    def is_crawlable_url(self, url_string: str) -> bool:
        """
        检查 URL 是否可以继续下钻爬取（PDF 等文件返回 False，但会被收集）

        Args:
            url_string: URL 字符串

        Returns:
            bool: 是否可继续下钻
        """
        try:
            parsed = urlparse(url_string)
            path = parsed.path.lower()

            # PDF 等文件不继续下钻
            for ext in self.NON_CRAWLABLE_EXTENSIONS:
                if path.endswith(ext):
                    return False

            # 检查是否是 http/https 协议
            if parsed.scheme not in ['http', 'https']:
                return False

            return True
        except Exception:
            return False

    def is_valid_url_for_collection(self, url_string: str) -> bool:
        """
        检查 URL 是否是有效的可收集链接（包括 PDF）

        Args:
            url_string: URL 字符串

        Returns:
            bool: 是否是有效链接
        """
        try:
            parsed = urlparse(url_string)
            # 只检查是否是 http/https 协议且有域名
            return parsed.scheme in ['http', 'https'] and bool(parsed.netloc)
        except Exception:
            return False

    def is_valid_url(self, url_string: str) -> bool:
        """检查 URL 是否有效（只处理 http/https 链接）"""
        try:
            parsed = urlparse(url_string)
            return parsed.scheme in ['http', 'https'] and bool(parsed.netloc)
        except Exception:
            return False

    def resolve_url(self, base_url: str, link: str) -> str:
        """将相对链接转换为绝对链接"""
        return urljoin(base_url, link)

    async def extract_links_from_page(self, page: Page, base_url: str) -> List[str]:
        """
        从当前页面提取所有链接

        Args:
            page: Playwright 页面对象
            base_url: 当前页面 URL，用于转换相对链接

        Returns:
            List[str]: 绝对链接列表
        """
        js_code = """
        (() => {
          const collectedLinks = [];
          const seen = new Set();

          for (let i = 0; i < document.links.length; i++) {
            const link = document.links[i];
            if (link.href && link.href.trim()) {
              const href = link.href.trim();
              if (!href.startsWith('javascript:') && !href.startsWith('mailto:') && !href.startsWith('tel:')) {
                if (!seen.has(href)) {
                  seen.add(href);
                  collectedLinks.push(href);
                }
              }
            }
          }

          console.log('提取到的链接总数：' + collectedLinks.length);
          return collectedLinks;
        })();
        """

        try:
            link_elements = await page.evaluate(js_code)
            # 转换为绝对链接并过滤
            absolute_links = []
            for href in link_elements:
                if self.is_valid_url(href):
                    absolute_links.append(href)
                else:
                    absolute_links.append(self.resolve_url(base_url, href))

            logging.info(f"从页面提取到 {len(absolute_links)} 个有效链接")
            return absolute_links
        except Exception as e:
            logging.error(f"提取页面链接失败：{e}")
            return []

    async def crawl_single_page(self, context: BrowserContext, url: str, depth: Optional[int] = None, max_depth: Optional[int] = None) -> List[str]:
        """
        爬取单个页面，提取其所有子链接

        Args:
            context: 浏览器上下文
            url: 页面 URL
            depth: 当前深度（可选）
            max_depth: 最大深度（可选）

        Returns:
            List[str]: 提取到的链接列表
        """
        normalized_url = self.normalize_url(url)

        # 检查是否已经爬取过
        if normalized_url in self.crawled_urls:
            depth_prefix = f"[深度 {depth}/{max_depth}]" if depth is not None else ""
            logging.info(f"{depth_prefix}[跳过] URL 已爬取：{url}")
            self._log_page_crawl_result(url, 0, 0, 0, skipped_reason="已爬取")
            return self.page_links_map.get(normalized_url, [])

        # 检查是否可爬取（非.pdf 等文件）
        if not self.is_crawlable_url(url):
            depth_prefix = f"[深度 {depth}/{max_depth}]" if depth is not None else ""
            logging.info(f"{depth_prefix}[跳过] 不可爬取的 URL（文件类型）: {url}")
            self._log_page_crawl_result(url, 0, 0, 0, skipped_reason="文件类型不可爬取")
            return []

        # 检查是否同域名
        if not self.is_same_domain(url):
            depth_prefix = f"[深度 {depth}/{max_depth}]" if depth is not None else ""
            logging.info(f"{depth_prefix}[跳过] 不同域名的 URL: {url}")
            self._log_page_crawl_result(url, 0, 0, 0, skipped_reason="不同域名")
            return []

        depth_prefix = f"[深度 {depth}/{max_depth}]" if depth is not None else ""
        logging.info(f"{depth_prefix}[爬取中] 正在爬取页面：{url}")

        try:
            page = await context.new_page()
            await page.goto(url, wait_until="domcontentloaded", timeout=60000)
            await page.wait_for_load_state("domcontentloaded", timeout=30000)
            await page.wait_for_timeout(2000)  # 等待动态内容

            # 提取链接
            links = await self.extract_links_from_page(page, url)

            await page.close()

            # 记录已爬取
            self.crawled_urls.add(normalized_url)

            # 收集所有有效链接（包括外部链接和 PDF 等文件）
            collected_links = []
            for link in links:
                if self.is_valid_url_for_collection(link):
                    collected_links.append(link)

            # 去重（基于标准化后的 URL）
            seen_normalized = set()
            original_links = []
            for link in collected_links:
                norm = self.normalize_url(link)
                if norm not in seen_normalized:
                    seen_normalized.add(norm)
                    original_links.append(norm)

            # 存储到映射中
            self.page_links_map[normalized_url] = original_links

            # 全局去重：将新链接添加到全局集合（包括外部链接）
            new_links_count = 0
            for link in original_links:
                normalized_link = self.normalize_url(link)
                if normalized_link not in self.global_unique_links:
                    self.global_unique_links.add(normalized_link)
                    new_links_count += 1

            # 保存到全局文件
            if self.global_links_file:
                self._save_global_links()

            # 计算可继续下钻的链接数量（只计算同域名且可爬取的链接）
            crawlable_count = sum(1 for link in original_links if self.is_same_domain(link) and self.is_crawlable_url(link))
            external_count = sum(1 for link in original_links if not self.is_same_domain(link))
            duplicate_count = len(links) - len(original_links)

            logging.info(f"[爬取完成] 页面 {url} 提取到 {len(original_links)} 个有效子链接（可下钻：{crawlable_count}，外部链接：{external_count}，文件：{len(original_links) - crawlable_count - external_count}），全局去重后新增 {new_links_count} 条，累计 {len(self.global_unique_links)} 条")

            # 记录日志（实时写入文件）
            self._log_page_crawl_result(url, len(original_links), duplicate_count, len(links))

            # 调用回调函数
            if self.on_page_completed:
                await self.on_page_completed(url, original_links)

            return original_links

        except Exception as e:
            logging.error(f"[爬取失败] 页面 {url}: {e}")
            self.crawled_urls.add(normalized_url)  # 标记为已爬取（即使失败）
            self._log_page_crawl_result(url, 0, 0, len(links) if 'links' in dir() else 0, skipped_reason=f"爬取失败：{e}")
            return []

    def _log_page_crawl_result(self, page_url: str, saved_links_count: int, duplicate_links_count: int,
                                raw_links_count: int, skipped_reason: Optional[str] = None):
        """
        记录单个页面的爬取统计信息（不记录详细链接）

        Args:
            page_url: 页面 URL
            saved_links_count: 保存的子链接数量（去重后）
            duplicate_links_count: 重复的子链接数量
            raw_links_count: 原始提取的链接总数
            skipped_reason: 跳过原因（如果被跳过）
        """
        if not self.log_dir:
            return

        log_path = Path(self.log_dir)
        log_path.mkdir(parents=True, exist_ok=True)

        # 使用开始时间作为文件名，确保每次爬取只有一个文件
        summary_file = log_path / f"crawl_summary_{self.crawl_start_time}.json"

        log_data = {
            "page_url": page_url,
            "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "raw_links_count": raw_links_count,
            "saved_links_count": saved_links_count,
            "duplicate_links_count": duplicate_links_count,
            "skipped": skipped_reason is not None,
            "skipped_reason": skipped_reason,
            "global_unique_links_count": len(self.global_unique_links)  # 新增：全局累计去重数量
        }

        # 添加到内存列表
        self.page_stats[page_url] = log_data

        # 实时追加写入到文件（如果文件存在则读取后合并，否则创建新文件）
        try:
            if summary_file.exists():
                with open(summary_file, 'r', encoding='utf-8') as f:
                    summary = json.load(f)
            else:
                summary = {
                    "crawl_start_time": self.crawl_start_time,
                    "pages": []
                }

            # 添加当前页面日志
            summary["pages"].append(log_data)

            # 更新统计信息
            summary["crawl_end_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            summary["total_pages_crawled"] = len(summary["pages"])
            summary["total_links_found"] = sum(p.get("saved_links_count", 0) for p in summary["pages"])
            summary["global_unique_links_count"] = len(self.global_unique_links)

            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(summary, f, ensure_ascii=False, indent=2)

            logging.info(f"[页面日志] 页面 {page_url}: 原始 {raw_links_count} 条，保存 {saved_links_count} 条，重复 {duplicate_links_count} 条，全局累计 {len(self.global_unique_links)} 条")
        except Exception as e:
            logging.error(f"[页面日志] 写入失败 {page_url}: {e}")

    async def crawl_depth(self, context: BrowserContext, start_url: str, max_depth: int, current_depth: int = 0) -> Set[str]:
        """
        递归深度爬取（DFS 模式）

        Args:
            context: 浏览器上下文
            start_url: 起始 URL
            max_depth: 最大深度，0 表示不限深度（爬完所有可达链接）
            current_depth: 当前深度

        Returns:
            Set[str]: 所有爬取到的链接集合
        """
        unlimited = max_depth == 0

        if not unlimited and current_depth > max_depth:
            return set()

        normalized_url = self.normalize_url(start_url)

        # 检查是否已爬取
        if normalized_url in self.crawled_urls:
            return set(self.page_links_map.get(normalized_url, []))

        # 爬取当前页面
        current_links = await self.crawl_single_page(context, start_url, current_depth, max_depth)
        all_links = set(current_links)

        # 如果还有深度，继续爬取子页面（只下钻同域名的链接）
        if unlimited or current_depth < max_depth:
            logging.info(f"[深度 {current_depth}/{max_depth}] 继续爬取 {len(current_links)} 个子链接")
            for link in current_links:
                normalized_link = self.normalize_url(link)
                if not self.is_same_domain(link):
                    logging.info(f"[深度 {current_depth}/{max_depth}][跳过 - 不同域名] {link}")
                    continue
                if normalized_link in self.crawled_urls:
                    logging.info(f"[深度 {current_depth}/{max_depth}][跳过 - 已爬取] {link}")
                    continue
                sub_links = await self.crawl_depth(context, link, max_depth, current_depth + 1)
                all_links.update(sub_links)

        return all_links

    async def crawl_bfs(self, context: BrowserContext, start_url: str, max_depth: int = 2) -> Set[str]:
        """
        广度优先爬取站点内所有链接

        Args:
            context: 浏览器上下文
            start_url: 起始 URL
            max_depth: 最大深度，0 表示不限深度（爬完所有可达链接）

        Returns:
            Set[str]: 所有爬取到的链接集合
        """
        all_links = set()
        # 队列：(url, depth)
        queue = deque([(start_url, 0)])
        unlimited = max_depth == 0

        while queue:
            url, depth = queue.popleft()
            normalized_url = self.normalize_url(url)

            # 超过深度限制，停止（不限深度时跳过此判断）
            if not unlimited and depth > max_depth:
                continue

            # 检查是否已爬取
            if normalized_url in self.crawled_urls:
                logging.info(f"[深度 {depth}][跳过 - 已爬取] {url}")
                # 已爬取过的页面，直接使用之前保存的子链接
                existing_links = self.page_links_map.get(normalized_url, [])
                all_links.update(existing_links)
                continue

            # 爬取当前页面
            logging.info(f"开始爬取单个页面，当前队列长度： {len(queue)}")
            current_links = await self.crawl_single_page(context, url, depth, max_depth)
            all_links.update(current_links)

            # 如果还有深度，将新链接加入队列（不限深度时始终入队）
            if (unlimited or depth < max_depth) and current_links:
                logging.info(f"[深度 {depth}{'/不限' if unlimited else f'/{max_depth}'}] 继续爬取 {len(current_links)} 个子链接")
                other_domain_count = 0
                finish_count = 0
                for link in current_links:
                    normalized_link = self.normalize_url(link)
                    if not self.is_same_domain(link):
                        other_domain_count = other_domain_count + 1
                        continue
                    if normalized_link in self.crawled_urls:
                        finish_count = finish_count + 1
                        continue
                    queue.append((link, depth + 1))
                logging.info(f"[深度 {depth}] 跳过 [不同域名 数量：{other_domain_count}] [已爬取 数量：{finish_count}]")

        return all_links

    async def crawl_tree(self, context: BrowserContext, start_url: str, max_depth: int = 2) -> Dict[str, List[str]]:
        """
        BFS 爬取并构建树结构（每个 URL 只在树中出现一次）

        与 crawl_bfs 不同的是，如果某个 URL 已经作为树中的节点存在，
        则不会作为其他父节点的子节点重复出现，从而构成一棵真正的树而非 DAG。

        Args:
            context: 浏览器上下文
            start_url: 起始 URL
            max_depth: 最大深度，0 表示不限深度（爬完所有可达链接）

        Returns:
            Dict[str, List[str]]: tree_map 父→子映射
        """
        # 重置树结构状态
        self.tree_map.clear()
        self.parent_map.clear()
        self.seen_as_node.clear()

        normalized_root = self.normalize_url(start_url)
        self.seen_as_node.add(normalized_root)
        self.parent_map[normalized_root] = None

        # 队列：(url, depth)
        queue = deque([(start_url, 0)])
        unlimited = max_depth == 0

        while queue:
            url, depth = queue.popleft()
            normalized_url = self.normalize_url(url)

            # 超过深度限制，停止（不限深度时跳过此判断）
            if not unlimited and depth > max_depth:
                continue

            # 爬取当前页面（seen_as_node 已保证入队前去重，此处为兜底检查）
            if normalized_url in self.crawled_urls:
                logging.info(f"[树结构][深度 {depth}][跳过 - 已下钻] {url}")
                continue

            # 爬取当前页面
            existing_links = await self.crawl_single_page(context, url, depth, max_depth)

            # 为当前节点分配子节点（未在树中出现过的同域名链接 + 外域链接作为叶子节点）
            children = []
            queued_count = 0
            tree_node_count = 0
            cross_domain_count = 0
            already_seen_count = 0

            for link in existing_links:
                norm_link = self.normalize_url(link)

                # 同域名且可爬取且未下钻过的链接，加入队列继续下钻（必须在 seen_as_node 检查之前）
                # 不限深度时始终入队，有限深度时受 depth < max_depth 限制
                if self.is_same_domain(link) and (unlimited or depth < max_depth) and self.is_crawlable_url(link) and norm_link not in self.crawled_urls:
                    queue.append((link, depth + 1))
                    queued_count += 1

                if norm_link in self.seen_as_node:
                    # 已在树中占位，不重复添加为子节点
                    already_seen_count += 1
                    continue

                if not self.is_same_domain(link):
                    # 外域链接加入树作为叶子节点，不继续下钻
                    self.seen_as_node.add(norm_link)
                    self.parent_map[norm_link] = normalized_url
                    children.append(norm_link)
                    cross_domain_count += 1
                    continue

                # 同域名链接加入树
                self.seen_as_node.add(norm_link)
                self.parent_map[norm_link] = normalized_url
                children.append(norm_link)
                tree_node_count += 1

            if children:
                self.tree_map[normalized_url] = children

            depth_info = f"[树结构][深度 {depth}{'/不限' if unlimited else f'/{max_depth}'}]"
            logging.info(
                f"{depth_info} {url} → "
                f"提取 {len(existing_links)} 条，"
                f"入队 {queued_count} 条，"
                f"新增同域树节点 {tree_node_count} 条，"
                f"新增外域叶子 {cross_domain_count} 条，"
                f"已占位跳过 {already_seen_count} 条，"
                f"队列剩余 {len(queue)}"
            )

            # 增量输出：每完成一个页面就写入文件
            if self.tree_output_dir and self._tree_output_timestamp:
                self._save_tree_incremental()

        return self.tree_map

    async def crawl_nested_links(self,
                                  start_url: str,
                                  max_depth: int = 2,
                                  use_cdp: bool = False,
                                  crawl_mode: str = "tree") -> DefaultResult:
        """
        爬取下钻多层的页面链接

        Args:
            start_url: 起始页面 URL
            max_depth: 最大下钻深度
            use_cdp: 是否使用 CDP 连接到已运行的 Chrome
            crawl_mode: 爬取模式，"bfs"、"dfs" 或 "tree"，默认使用 BFS。"tree" 模式构建树结构，每个 URL 只出现一次

        Returns:
            DefaultResult: 包含所有去重后的链接列表
        """
        # 设置目标域名
        self.target_domain = self.get_domain(start_url)
        self.crawl_start_time = datetime.now().strftime("%Y%m%d_%H%M%S")
        logging.info(f"开始爬取，起始 URL: {start_url}, 目标域名：{self.target_domain}, 最大深度：{max_depth}, 模式：{crawl_mode.upper()}")

        # 重置状态
        self.crawled_urls.clear()
        self.page_links_map.clear()
        self.page_stats.clear()

        # tree 模式：设置增量输出时间戳
        if crawl_mode == "tree":
            self._tree_output_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # 初始化日志目录并设置文件处理器
        if self.log_dir:
            log_path = Path(self.log_dir)
            log_path.mkdir(parents=True, exist_ok=True)
            self._setup_file_handler()

        context = None
        browser = None
        cdp_browser = None

        try:
            async with async_playwright() as p:
                if use_cdp:
                    cdp_url = f"http://127.0.0.1:{self.debug_port}"
                    logging.info(f"正在连接到已运行的 Chrome: {cdp_url}")
                    cdp_browser = await p.chromium.connect_over_cdp(
                        endpoint_url=cdp_url,
                        timeout=30000
                    )
                    contexts = cdp_browser.contexts
                    context = contexts[0] if contexts else await cdp_browser.new_context(
                        viewport={"width": 1920, "height": 1080},
                        user_agent=self.user_agent,
                    )
                    logging.info("成功连接到 Chrome")
                elif self.user_data_dir:
                    logging.info(f"使用持久化上下文，用户数据目录：{self.user_data_dir}")
                    context = await asyncio.wait_for(
                        p.chromium.launch_persistent_context(
                            user_data_dir=self.user_data_dir,
                            executable_path=self.chrome_executable_path or self._find_chrome_path(),
                            headless=self.headless,
                            args=[
                                '--disable-blink-features=AutomationControlled',
                                '--disable-features=VizDisplayCompositor',
                                '--disable-dev-shm-usage',
                                '--no-sandbox',
                                '--disable-gpu',
                            ],
                            viewport={"width": 1920, "height": 1080},
                            user_agent=self.user_agent,
                        ),
                        timeout=60.0
                    )
                else:
                    if self.chrome_executable_path:
                        logging.info(f"使用本地 Chrome: {self.chrome_executable_path}")
                        browser = await p.chromium.launch(
                            executable_path=self.chrome_executable_path,
                            headless=self.headless,
                            args=[
                                '--disable-blink-features=AutomationControlled',
                                '--disable-features=VizDisplayCompositor',
                                '--disable-dev-shm-usage',
                                '--no-sandbox',
                            ]
                        )
                    else:
                        logging.info("使用 Playwright 自带的 Chromium")
                        browser = await p.chromium.launch(
                            headless=self.headless,
                            args=[
                                '--disable-blink-features=AutomationControlled',
                                '--disable-features=VizDisplayCompositor',
                                '--disable-dev-shm-usage',
                                '--no-sandbox',
                            ]
                        )
                    context = await browser.new_context(
                        viewport={"width": 1920, "height": 1080},
                        user_agent=self.user_agent,
                    )

                # 根据模式选择爬取方式
                if crawl_mode == "bfs":
                    all_links = await self.crawl_bfs(context, start_url, max_depth)
                elif crawl_mode == "tree":
                    await self.crawl_tree(context, start_url, max_depth)
                    # tree 模式：收集树中所有节点 URL + 嵌套 JSON 树结构
                    all_link_set = {self.normalize_url(start_url)}
                    for children in self.tree_map.values():
                        all_link_set.update(children)
                    all_links = all_link_set
                    tree_json = self.build_tree_json(start_url)
                    return DefaultResult(
                        data=list(all_links),
                        message=json.dumps(tree_json, ensure_ascii=False)
                    )
                else:
                    all_links = await self.crawl_depth(context, start_url, max_depth, 0)

                # 清理资源
                if browser:
                    await browser.close()
                if cdp_browser:
                    await cdp_browser.close()
                elif context:
                    await context.close()

                logging.info(f"爬取完成，共获取 {len(all_links)} 个去重链接")

                # 保存汇总统计日志
                if self.log_dir:
                    self._save_crawl_summary()

                return DefaultResult(data=list(all_links))

        except asyncio.TimeoutError as e:
            logging.error(f"爬取超时：{e}")
            raise
        except Exception as e:
            logging.error(f"爬取失败：{e}")
            import traceback
            traceback.print_exc()
            raise
        finally:
            # 确保资源清理
            if browser:
                try:
                    await browser.close()
                except:
                    pass
            if cdp_browser:
                try:
                    await cdp_browser.close()
                except:
                    pass
            # 清理日志文件处理器
            self._cleanup_file_handler()

    def get_crawled_pages(self) -> Dict[str, List[str]]:
        """
        获取所有已爬取页面及其子链接

        Returns:
            Dict[str, List[str]]: {page_url: [child_urls]}
        """
        return self.page_links_map

    def get_page_stats(self) -> Dict[str, dict]:
        """
        获取所有页面的爬取统计信息

        Returns:
            Dict[str, dict]: {page_url: stats_dict}
        """
        return self.page_stats

    def build_tree_json(self, root_url: str) -> dict:
        """
        构建嵌套 JSON 树结构

        Args:
            root_url: 根节点 URL

        Returns:
            嵌套字典，格式如：
            {
                "url": "https://...",
                "children": [
                    {
                        "url": "https://...",
                        "children": [...]
                    }
                ]
            }
        """
        normalized_root = self.normalize_url(root_url)
        return self._build_node(normalized_root)

    def _build_node(self, url: str) -> dict:
        """
        递归构建树节点，外域和文件链接标记为叶子节点

        Args:
            url: 节点 URL（已标准化）

        Returns:
            dict: 节点字典
        """
        is_leaf = not self.is_same_domain(url) or not self.is_crawlable_url(url)
        node = {"url": url}
        if is_leaf:
            node["leaf"] = True
            if not self.is_same_domain(url):
                node["type"] = "cross_domain"
            else:
                node["type"] = "file"
        children = self.tree_map.get(url, [])
        if children:
            node["children"] = [self._build_node(child) for child in children]
        return node

    def get_path_to_root(self, url: str) -> List[str]:
        """
        回溯从当前 URL 到根节点的路径

        Args:
            url: 目标 URL

        Returns:
            List[str]: 从根到当前节点的路径列表
        """
        normalized = self.normalize_url(url)
        path = []
        current = normalized
        while current is not None:
            path.append(current)
            current = self.parent_map.get(current)
        path.reverse()
        return path

    def save_tree_json(self, root_url: str, output_path: str):
        """
        保存嵌套 JSON 树结构到文件

        Args:
            root_url: 根节点 URL
            output_path: 输出文件路径
        """
        tree = self.build_tree_json(root_url)
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        with open(output, 'w', encoding='utf-8') as f:
            json.dump(tree, f, ensure_ascii=False, indent=2)
        logging.info(f"树结构已保存到 {output_path}")

    def _save_tree_incremental(self):
        """
        tree 模式增量输出：每完成一个页面就更新两个输出文件
        - tree_structure_{timestamp}.json: 当前完整嵌套 JSON 树
        - all_unique_links_{timestamp}.json: 当前所有去重链接列表
        """
        ts = self._tree_output_timestamp
        output_path = Path(self.tree_output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        # 找到根节点（parent_map 中值为 None 的节点）
        root_url = None
        for url, parent in self.parent_map.items():
            if parent is None:
                root_url = url
                break

        # 写入嵌套 JSON 树结构
        if root_url:
            tree = self.build_tree_json(root_url)
            with open(output_path / f"tree_structure_{ts}.json", 'w', encoding='utf-8') as f:
                json.dump(tree, f, ensure_ascii=False, indent=2)

        # 写入去重链接列表
        all_links = sorted(self.seen_as_node)
        with open(output_path / f"all_unique_links_{ts}.json", 'w', encoding='utf-8') as f:
            json.dump(all_links, f, ensure_ascii=False, indent=2)

        logging.info(f"[tree增量输出] 已写入 tree_structure_{ts}.json + all_unique_links_{ts}.json，累计 {len(self.seen_as_node)} 个节点")

    def _save_global_links(self):
        """
        保存全局去重链接到文件
        """
        if not self.global_links_file:
            return

        # 确保父目录存在
        self.global_links_file.parent.mkdir(parents=True, exist_ok=True)

        # 保存为 JSON 格式
        with open(self.global_links_file, 'w', encoding='utf-8') as f:
            # 保存为列表格式
            json.dump(sorted(list(self.global_unique_links)), f, ensure_ascii=False, indent=2)

        logging.info(f"[全局文件] 已保存 {len(self.global_unique_links)} 条去重链接到 {self.global_links_file}")

    def _save_crawl_summary(self):
        """
        保存爬取汇总统计到文件（最终确认，日志已实时写入）
        """
        if not self.log_dir:
            return

        log_path = Path(self.log_dir)
        log_path.mkdir(parents=True, exist_ok=True)

        # 读取已存在的日志文件，更新最终统计
        summary_file = log_path / f"crawl_summary_{self.crawl_start_time}.json"

        if summary_file.exists():
            with open(summary_file, 'r', encoding='utf-8') as f:
                summary = json.load(f)
        else:
            summary = {
                "crawl_start_time": self.crawl_start_time,
                "target_domain": self.target_domain,
                "pages": []
            }

        # 更新最终统计信息
        summary["crawl_end_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        summary["total_pages_crawled"] = len(self.page_links_map)
        summary["total_links_found"] = sum(len(links) for links in self.page_links_map.values())
        summary["global_unique_links_count"] = len(self.global_unique_links)
        summary["status"] = "completed"

        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)

        logging.info(f"[汇总] 爬取完成，共 {len(self.page_links_map)} 个页面，{len(self.global_unique_links)} 条去重链接")

    def save_to_file(self, output_path: str, format: str = 'json'):
        """
        保存爬取结果到文件

        Args:
            output_path: 输出文件路径
            format: 输出格式 ('json' 或 'text')
        """
        if format == 'json':
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(self.page_links_map, f, ensure_ascii=False, indent=2)
            logging.info(f"结果已保存到 {output_path}")
        else:
            with open(output_path, 'w', encoding='utf-8') as f:
                for page_url, links in self.page_links_map.items():
                    f.write(f"\n=== 页面：{page_url} ===\n")
                    for link in links:
                        f.write(f"  - {link}\n")
            logging.info(f"结果已保存到 {output_path}")


async def execute_deep_nested_links_crawl(crawl_request, result_id: str,
                                          output_dir: Optional[str] = None,
                                          log_dir: Optional[str] = None,
                                          log_file: Optional[str] = None,
                                          global_links_file: Optional[str] = None,
                                          crawl_mode: str = "bfs") -> DefaultResult:
    """
    执行深度下钻链接爬取任务

    Args:
        crawl_request: 爬取请求对象，包含 targetUrl、maxDepth 等参数
        result_id: 结果 ID
        output_dir: 输出目录（如果提供，则每完成一个页面就保存一次）
        log_dir: 日志文件输出目录（如果提供，则每完成一个页面就记录一次日志）
        log_file: 日志文件路径（可选）
        global_links_file: 全局去重链接文件路径
        crawl_mode: 爬取模式，"bfs" 或 "dfs"，默认使用 BFS

    Returns:
        DefaultResult: 包含去重链接列表
    """
    logging.info(f"request: {crawl_request}, resultId: {result_id}")

    target_url = crawl_request.paramMap.get("targetUrl")
    if not target_url:
        raise ValueError("paramMap 中必须包含 targetUrl 参数")

    max_depth = crawl_request.paramMap.get("maxDepth", 2)

    # 创建输出目录
    if output_dir:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

    # 定义页面完成回调
    async def on_page_completed(page_url: str, links: List[str]):
        if output_dir:
            # 每完成一个页面就保存
            crawler.save_to_file(str(output_path / f"{hash(page_url) & 0xFFFFFFFF}.json"), format='json')
            logging.info(f"已保存页面 {page_url} 的 {len(links)} 个子链接")

    crawler = DeepNestedLinksCrawler(headless=True, on_page_completed=on_page_completed, log_dir=log_dir,
                                      log_file=log_file, global_links_file=global_links_file)
    if crawl_mode == "tree" and output_dir:
        crawler.tree_output_dir = output_dir
    result = await crawler.crawl_nested_links(start_url=target_url, max_depth=max_depth, crawl_mode=crawl_mode)
    result.resultId = result_id

    # 保存最终结果
    if output_dir:
        crawler.save_to_file(str(output_path / "final_result.json"), format='json')

    # tree 模式额外保存：嵌套 JSON 树结构 + 去重链接列表
    if output_dir and crawl_mode == "tree":
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        crawler.save_tree_json(target_url, str(output_path / f"tree_structure_{timestamp}.json"))
        all_links_list = sorted(list(set(crawler.normalize_url(link) for link in result.data)))
        with open(output_path / f"all_unique_links_{timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(all_links_list, f, ensure_ascii=False, indent=2)
        logging.info(f"[tree模式] 嵌套树结构已保存到 tree_structure_{timestamp}.json，去重链接列表已保存到 all_unique_links_{timestamp}.json")

    logging.info(f"爬取完成，共获取 {len(result.data)} 个去重链接")

    return result


async def crawl_multiple_urls(urls: List[str], max_depth: int = 2,
                              headless: bool = False, debug_port: int = 9222,
                              use_cdp: bool = True,
                              output_dir: Optional[str] = None,
                              log_dir: Optional[str] = None,
                              global_links_file: Optional[str] = None) -> DefaultResult:
    """
    爬取多个 URL 的下钻链接，并对最终结果去重

    Args:
        urls: 起始 URL 列表
        max_depth: 最大下钻深度
        headless: 是否无头模式
        debug_port: Chrome 调试端口
        use_cdp: 是否使用 CDP 连接
        output_dir: 输出目录
        log_dir: 日志文件输出目录
        global_links_file: 全局去重链接文件路径

    Returns:
        DefaultResult: 包含所有去重后的链接列表
    """
    logging.info(f"开始爬取 {len(urls)} 个 URL，最大深度：{max_depth}")

    all_unique_links = set()
    global_page_links_map = {}

    for idx, url in enumerate(urls):
        logging.info(f"[{idx + 1}/{len(urls)}] 正在爬取：{url}")

        # 定义页面完成回调
        async def on_page_completed(page_url: str, links: List[str]):
            global_page_links_map[page_url] = links
            if output_dir:
                output_path = Path(output_dir)
                output_path.mkdir(parents=True, exist_ok=True)
                with open(output_path / f"page_{hash(page_url) & 0xFFFFFFFF}.json", 'w', encoding='utf-8') as f:
                    json.dump({page_url: links}, f, ensure_ascii=False, indent=2)

        crawler = DeepNestedLinksCrawler(headless=headless, debug_port=debug_port,
                                          on_page_completed=on_page_completed, log_dir=log_dir,
                                          global_links_file=global_links_file)
        try:
            result = await crawler.crawl_nested_links(
                start_url=url,
                max_depth=max_depth,
                use_cdp=use_cdp
            )
            # 合并结果
            for link in result.data:
                all_unique_links.add(crawler.normalize_url(link))

            # 合并页面链接映射
            global_page_links_map.update(crawler.get_crawled_pages())

            logging.info(f"[{idx + 1}/{len(urls)}] 爬取完成，当前累计去重链接数：{len(all_unique_links)}")
        except Exception as e:
            logging.error(f"[{idx + 1}/{len(urls)}] 爬取失败 {url}: {e}")
            continue

    # 保存最终汇总结果
    if output_dir and global_page_links_map:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        with open(output_path / "final_summary.json", 'w', encoding='utf-8') as f:
            json.dump(global_page_links_map, f, ensure_ascii=False, indent=2)

    logging.info(f"所有 URL 爬取完成，最终去重链接总数：{len(all_unique_links)}")
    return DefaultResult(data=list(all_unique_links))


async def main():
    """测试入口"""
    test_url = "https://www.tokyostarbank.co.jp/"

    output_dir = "../crawl_output"
    log_dir = "../crawl_logs"
    crawl_mode = "tree"  # "bfs", "dfs", "tree"
    max_depth = 0  # 0 表示不限深度

    # 生成基于当前时间的文件名
    crawl_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    async def on_page_completed(page_url: str, links: List[str]):
        logging.info(f"[回调] 页面完成：{page_url}, 子链接数：{len(links)}")

    crawler = DeepNestedLinksCrawler(
        headless=False,
        on_page_completed=on_page_completed,
        log_dir=log_dir,
        global_links_file=f"{output_dir}/all_links_{crawl_timestamp}.json"
    )

    # tree 模式设置增量输出目录
    if crawl_mode == "tree":
        crawler.tree_output_dir = output_dir

    result = await crawler.crawl_nested_links(start_url=test_url, max_depth=max_depth, use_cdp=True, crawl_mode=crawl_mode)

    logging.info(f"测试完成，共获取 {len(result.data)} 个链接")

    # 保存最终结果
    crawler.save_to_file(f"{output_dir}/final_result.json", format='json')

    # tree 模式额外保存
    if crawl_mode == "tree":
        crawler.save_tree_json(test_url, f"{output_dir}/tree_structure_{crawl_timestamp}.json")
        all_links_list = sorted(list(set(crawler.normalize_url(link) for link in result.data)))
        with open(f"{output_dir}/all_unique_links_{crawl_timestamp}.json", 'w', encoding='utf-8') as f:
            json.dump(all_links_list, f, ensure_ascii=False, indent=2)
        logging.info(f"[tree模式] 树结构已保存到 tree_structure_{crawl_timestamp}.json，去重链接已保存到 all_unique_links_{crawl_timestamp}.json")

    # 打印前 10 个链接
    for idx, link in enumerate(result.data[:10]):
        logging.info(f"  {idx + 1}: {link}")

    # 打印页面链接映射
    logging.info(f"\n共爬取了 {len(crawler.get_crawled_pages())} 个页面")

    # 打印爬取统计
    logging.info(f"\n爬取统计汇总:")
    for page_url, stats in crawler.get_page_stats().items():
        logging.info(f"  页面：{page_url}")
        logging.info(f"    原始链接数：{stats['raw_links_count']}")
        logging.info(f"    保存链接数：{stats['saved_links_count']}")
        logging.info(f"    重复链接数：{stats['duplicate_links_count']}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())

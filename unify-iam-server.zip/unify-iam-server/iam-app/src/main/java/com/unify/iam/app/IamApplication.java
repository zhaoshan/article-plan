package com.unify.iam.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * unify-iam-server 可启动应用（E2E-1）。
 *
 * <p>{@code scanBasePackages = "com.unify.iam"} 跨模块扫描各域（identity/tenant/authorization）
 * 的 {@code @Service/@Repository} 等；{@code @MapperScan} 独立在 {@code IamPersistenceConfig}
 * （避免 WebMvcTest 切片加载 mappers）。
 */
@SpringBootApplication(scanBasePackages = "com.unify.iam")
@ConfigurationPropertiesScan
public class IamApplication {

    public static void main(String[] args) {
        // 2026-11-04 时间契约：JVM 默认时区钉为 UTC（先于一切初始化）。
        // MyBatis-Plus MetaObjectHandler 用 LocalDateTime.now() 填充 create_time/update_time——
        // 若跟随 JVM/机器时区，写入语义随部署环境漂移（本地 +8、服务器 UTC 差 8 小时的根因）。
        // 此处钉死后与 yml 的 connectionTimeZone=UTC（DB 侧 NOW()/CURRENT_TIMESTAMP）形成双保险，
        // 存储层契约 = 一律 UTC；展示层按设备时区转换（IamJacksonConfig 输出带 Z）。
        java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone(java.time.ZoneOffset.UTC));
        SpringApplication.run(IamApplication.class, args);
    }
}

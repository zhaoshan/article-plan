# 角色列表后端重启

日期：2026-10-29（Asia/Shanghai）

范围：当前 platform-iam-service 主工作区。按既有 `com.platform-iam.service` launchd 配置重编译并重启后端，验证健康状态与 roles 接口。

约束：保留现有源码、文档与 Trellis 改动；不提交、合并、推送、切换或重置分支；不创建或删除 worktree；不访问其他 Platform IAM 项目；不记录凭证。

执行：
- [x] 当前服务、端口和启动配置核对
- [x] 当前工作区干净重编译
- [x] 重启既有 launchd 服务
- [x] 健康、JWKS、roles 接口验证并记录

结果：当前 `com.platform-iam.service` 已加载新生成的 `iam-app` JAR，运行于 `127.0.0.1:8090`。启动与接口证据见 `runtime-verification.txt`；零权限角色的 0 语义由本次重启前已通过的角色权限统计测试覆盖（`.trellis/tasks/10-29-role-permission-counts/check.jsonl`）。

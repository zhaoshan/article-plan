# Design

## Evidence and change boundary
AdminAuditController binds String request parameters directly; there is no external DTO. AdminAuditService.AuditSearchCriteria owns validation and normalization. AuditLogFilter holds LocalDateTime values, and AuditLogSqlProvider already emits >= start and < end independently for list/count. gateway_audit_log.create_time is MySQL DATETIME (V1), with UTC wall-clock storage intended by IamApplication and IamJacksonConfig. Do not add another offset or change SQL/storage/global timezone configuration. Historical pre-UTC rows are not migrated.

## Contract
Primary ISO_OFFSET_DATE_TIME input normalizes directly via withOffsetSameInstant(UTC).toLocalDateTime(). Optional legacy ISO_LOCAL_DATE (Shanghai date bounds) and ISO_LOCAL_DATE_TIME (Shanghai wall clock) remain separate fallback paths; old dates must never be silently interpreted as UTC. Reject malformed/overflow values consistently before repository access. Missing/blank bounds are independent; validate ordering only if both exist.

Example Shanghai 2026-11-04 day: start_time=2026-11-03T16:00:00Z and end_time=2026-11-04T16:00:00Z. Equivalent +08:00 timestamps require URL-encoded +. Frontend advances local calendar before converting to UTC (23/25-hour DST days supported by instant bounds).

## Files
AdminAuditService: simplify normalization and remove pair requirement. ErrorCode: update only TIME_FORMAT_INVALID message. API manual/controller docs: contract/examples/error catalog codes. Audit tests: standalone HTTP/service contract plus MySQL boundary/regression cases. Backend spec: persist time contract.

## Compatibility / risk / rollback
Retain date-only and local-timestamp semantics for existing clients; new frontend uses offset-bearing values. No schema migration. Revert only this task's edits if needed. Existing datasource URL still mentions serverTimezone=Asia/Shanghai despite comments mentioning connectionTimeZone=UTC; this task does not claim to fix deployment/session timezone or historical data.

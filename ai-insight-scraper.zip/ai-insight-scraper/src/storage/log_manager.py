"""日志文件管理器"""

import json
import logging
from datetime import datetime
from pathlib import Path


class LogManager:
    """爬取日志管理器，负责日志文件设置、页面统计记录和汇总输出"""

    def __init__(self, log_dir: str | Path):
        """
        Args:
            log_dir: 日志输出目录
        """
        self._log_dir = Path(log_dir)
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._timestamp: str = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._file_handler: logging.FileHandler | None = None
        self._page_stats: list[dict] = []
        self._summary_file: Path | None = None

    @property
    def timestamp(self) -> str:
        """获取日志时间戳"""
        return self._timestamp

    @property
    def log_dir(self) -> Path:
        """获取日志目录"""
        return self._log_dir

    def setup(self) -> None:
        """设置日志文件处理器，将后续日志同时输出到文件"""
        log_file = self._log_dir / f"crawl_{self._timestamp}.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)

        self._file_handler = logging.FileHandler(log_file, encoding='utf-8')
        self._file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(
            '[%(asctime)s] %(levelname)s - %(message)s',
            datefmt='%d/%b/%Y %H:%M:%S',
        )
        self._file_handler.setFormatter(formatter)
        logging.getLogger().addHandler(self._file_handler)

        # 初始化汇总文件
        self._summary_file = self._log_dir / f"crawl_summary_{self._timestamp}.json"
        self._init_summary()

    def _init_summary(self) -> None:
        """初始化汇总日志文件"""
        summary = {
            "crawl_start_time": self._timestamp,
            "pages": [],
        }
        self._summary_file.parent.mkdir(parents=True, exist_ok=True)
        self._summary_file.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def log_page_result(
        self,
        page_url: str,
        raw_links_count: int,
        saved_links_count: int,
        duplicate_links_count: int,
        global_unique_count: int,
        skipped_reason: str | None = None,
    ) -> None:
        """
        记录单个页面的爬取结果。

        Args:
            page_url: 页面 URL
            raw_links_count: 原始链接数
            saved_links_count: 保存链接数
            duplicate_links_count: 重复链接数
            global_unique_count: 全局去重累计数
            skipped_reason: 跳过原因（如有）
        """
        log_data = {
            "page_url": page_url,
            "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "raw_links_count": raw_links_count,
            "saved_links_count": saved_links_count,
            "duplicate_links_count": duplicate_links_count,
            "skipped": skipped_reason is not None,
            "skipped_reason": skipped_reason,
            "global_unique_links_count": global_unique_count,
        }
        self._page_stats.append(log_data)
        self._update_summary(log_data)

    def _update_summary(self, page_log: dict) -> None:
        """增量更新汇总文件"""
        if not self._summary_file or not self._summary_file.exists():
            return
        summary = json.loads(self._summary_file.read_text(encoding="utf-8"))
        summary["pages"].append(page_log)
        summary["crawl_end_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        summary["total_pages_crawled"] = len(summary["pages"])
        summary["total_links_found"] = sum(
            p.get("saved_links_count", 0) for p in summary["pages"]
        )
        self._summary_file.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def finalize_summary(
        self,
        total_pages: int,
        total_links: int,
        global_unique_count: int,
        status: str = "completed",
    ) -> None:
        """写入最终汇总统计"""
        if not self._summary_file:
            return
        summary = json.loads(self._summary_file.read_text(encoding="utf-8"))
        summary["crawl_end_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        summary["total_pages_crawled"] = total_pages
        summary["total_links_found"] = total_links
        summary["global_unique_links_count"] = global_unique_count
        summary["status"] = status
        self._summary_file.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def cleanup(self) -> None:
        """清理日志文件处理器"""
        if self._file_handler:
            self._file_handler.close()
            logging.getLogger().removeHandler(self._file_handler)
            self._file_handler = None

    def get_page_stats(self) -> list[dict]:
        """获取所有页面统计信息"""
        return list(self._page_stats)

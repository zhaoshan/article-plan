package com.unify.iam.app.adapter.controller;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.app.app.service.admin.AdminAuditService;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.common.exception.AuthException;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：审计查询（iam:audit:read，平台管理员专属，docs/05 Audit 页）。 */
@RestController
@RequestMapping("/api/v1/admin/audit")
public class AdminAuditController {

    private final AdminAuditService adminAuditService;

    public AdminAuditController(AdminAuditService adminAuditService) {
        this.adminAuditService = adminAuditService;
    }

    /** Optional UTC/offset time bounds use [start_time, end_time); legacy dates remain Shanghai days. */
    @GetMapping
    @RequirePermission(PermissionCodes.IAM_AUDIT_READ)
    public Map<String, Object> list(@RequestParam(name = "tenant_id", required = false) String tenantId,
                                    HttpServletRequest request,
                                    @RequestParam(name = "event_type", required = false) String eventType,
                                    @RequestParam(name = "actor_user_id", required = false) String actorUserId,
                                    @RequestParam(name = "keyword", required = false) String keyword,
                                    @RequestParam(name = "start_time", required = false) String startTime,
                                    @RequestParam(name = "end_time", required = false) String endTime,
                                    @RequestParam(name = "page", defaultValue = "1") int page,
                                    @RequestParam(name = "size", defaultValue = "20") int size) {
        if (request.getParameterMap().containsKey("tenant_ids[]")) {
            throw AuthException.badRequest(ErrorCode.TENANT_IDS_REPEATED_PARAMS);
        }
        String[] tenantIds = request.getParameterValues("tenant_ids");
        AdminAuditService.AuditPage result = adminAuditService.search(
                tenantId, tenantIds == null ? List.of() : List.of(tenantIds), eventType, actorUserId,
                keyword, startTime, endTime, page, size);
        return Map.of("audits", result.audits(), "total", result.total(),
                "page", result.page(), "size", result.size());
    }

    /** 事件类型目录（code + 名称），供管理台筛选下拉。 */
    @GetMapping("/events")
    @RequirePermission(PermissionCodes.IAM_AUDIT_READ)
    public Map<String, Object> events() {
        List<Map<String, String>> events = adminAuditService.events();
        return Map.of("events", events, "count", events.size());
    }

}

package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.auth.RegisterRequest;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.identity.common.constant.IdentityProviderType;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 注册（docs/04 §3.5）：建用户 + 本地身份 + 个人租户（Owner，架构 §7.1 场景 A）。
 *
 * <p>带 {@code app_codes} 时（从业务应用如 parlant 跳入注册）：把个人租户作为该应用的
 * 「个人工作台」，deep-copy 其预置角色并授 owner {@code is_owner} 角色——注册者即该应用管理员。
 */
@Service
public class RegisterService {

    private final UserRepository userRepository;
    private final UserIdentityRepository userIdentityRepository;
    private final PersonalTenantService personalTenantService;
    private final TenantAppProvisionService tenantAppProvisionService;
    private final com.unify.iam.app.config.IamProperties props;
    private final EmailVerificationService emailVerificationService;

    public RegisterService(UserRepository userRepository,
                           UserIdentityRepository userIdentityRepository,
                           PersonalTenantService personalTenantService,
                           TenantAppProvisionService tenantAppProvisionService,
                           com.unify.iam.app.config.IamProperties props,
                              EmailVerificationService emailVerificationService) {
        this.emailVerificationService = emailVerificationService;
        this.userRepository = userRepository;
        this.userIdentityRepository = userIdentityRepository;
        this.personalTenantService = personalTenantService;
        this.tenantAppProvisionService = tenantAppProvisionService;
        this.props = props;
    }

    @Transactional
    public String register(RegisterRequest request) {
        // P1-03 统一密码策略（解码后、哈希前；注册是「设置新密码」链路之一）
        com.unify.iam.common.util.PasswordPolicy.validate(request.password());
        String username = request.username().trim();
        if (userRepository.findByUsername(username).isPresent()) {
            throw AuthException.badRequest(ErrorCode.USERNAME_EXISTS);
        }
        String email = request.email() == null ? null : request.email().trim().toLowerCase();
        if (email != null && userRepository.findByPrimaryEmail(email).isPresent()) {
            throw AuthException.badRequest(ErrorCode.EMAIL_EXISTS);
        }
        // 2026-11-05 注册邮箱验证：事务内消费验证码（10 分钟有效；错/过期/缺 → 细分 400）
        if (email == null) {
            throw AuthException.badRequest(ErrorCode.EMAIL_REQUIRED);
        }
        emailVerificationService.consumeForRegister(email, request.verificationCode());
        String userId = IdGenerator.newBizId();
        UserPO user = new UserPO();
        user.setUserId(userId);
        user.setUsername(username);
        user.setPrimaryEmail(email);
        user.setPasswordHash(BCryptUtils.hash(request.password()));
        user.setUserStatus("ACTIVE");
        user.setEmailVerified(1); // 注册必经验证码消费 → 创建即已验证（登录闸门④的正面口径）
        user.setRegistrationSource("SELF_SERVICE");
        userRepository.create(user);

        UserIdentityPO identity = new UserIdentityPO();
        identity.setUserIdentityId(IdGenerator.newBizId());
        identity.setUserId(userId);
        identity.setProviderType(IdentityProviderType.LOCAL.name());
        identity.setProviderKey("password");
        identity.setSubject(username);
        identity.setLoginName(username);
        identity.setEmailAtIdp(email);
        identity.setIdentityStatus("ACTIVE");
        userIdentityRepository.create(identity);

        MembershipPO membership = personalTenantService.ensurePersonalTenantAndOwner(user);
        provisionApps(membership, request.appCodes());
        return userId;
    }

    /**
     * 按 app_codes 给个人租户灌入应用模板角色 + owner 授 is_owner；未知应用忽略（不阻断注册）。
     *
     * <p>2026-11-02 修复：app_codes 缺省时回落**平台注册默认应用**（iam.enterprise-tenant-provisioning.
     * default-app-codes，现值 imorph）——与 JIT 分支（a31162a）同口径。否则 hub 直接注册（不带 ?app）
     * 的个人租户无应用记录：token aud 不含 imorph → 登录目录（/available-apps）为空 → DENIED，
     * 注册完进不了 imorph 工作台。
     */
    private void provisionApps(MembershipPO membership, List<String> appCodes) {
        if (membership == null) {
            return;
        }
        List<String> effective = (appCodes == null || appCodes.isEmpty())
                ? props.getEnterpriseTenantProvisioning().getDefaultAppCodes()
                : appCodes;
        if (effective == null || effective.isEmpty()) {
            return;
        }
        appCodes = effective;
        List<AppRoleTemplate> templates;
        try {
            templates = tenantAppProvisionService.loadForApps(appCodes);
        } catch (AuthException e) {
            // 未知/未启用应用：app 只是 onboarding 提示，忽略（不阻断注册）
            return;
        }
        String tenantId = membership.getTenantId().trim();
        tenantAppProvisionService.seedTemplates(tenantId, templates);
        tenantAppProvisionService.recordTenantApps(tenantId, appCodes);
        tenantAppProvisionService.grantOwnerRoles(membership.getMembershipId().trim(), tenantId, templates);
    }
}

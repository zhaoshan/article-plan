"""全量链接树迁移脚本 — Excel + tree_structure JSON → crawl_link_tree 表

以 config/all_links_tag_result.xlsx 为基准，按 Excel 行顺序逐条入库；
树层级信息（level/parent_url/is_leaf/node_type/not_found）从
output/tree_structure_{ts}.json 查询获取。站点统一用 tokyostarbank.co.jp。

用法:
    python scripts/import_excel_to_link_tree.py [--site tokyostarbank.co.jp]
                                                 [--excel config/all_links_tag_result.xlsx]
                                                 [--tree output/tree_structure_20260701_161852.json]
                                                 [--batch-size 500]
                                                 [--reset]
"""

import argparse
import asyncio
import json
import logging
import sys
from datetime import datetime
from pathlib import Path

import openpyxl

# 项目根目录加入 sys.path（脚本可直接运行）
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.database import init_db, LinkTreeRepository
from src.database.models import CrawlLinkTreeModel
from src.utils.url_utils import normalize_url

# Windows 控制台中文输出
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s - %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("import_excel_to_link_tree")

# 默认配置
DEFAULT_SITE = "tokyostarbank.co.jp"
DEFAULT_EXCEL = "config/all_links_tag_result.xlsx"
DEFAULT_TREE = "output/tree_structure_20260701_161852.json"
DEFAULT_BATCH_SIZE = 500


# ── tree_structure 解析 ──────────────────────────────


def build_tree_index(tree_root: dict) -> dict[str, dict]:
    """递归遍历 tree_structure，构建 url → 树层级信息的索引。

    约定: 同一 URL 首次出现时记录其 level/parent（树已无全局重复，
    4161 节点全部唯一，不存在冲突）。

    Returns:
        {normalize_url(url): {level, parent_url, is_leaf, node_type, not_found}}
    """
    index: dict[str, dict] = {}

    def walk(node: dict, level: int, parent_url: str | None) -> None:
        url = node.get("url")
        if not url:
            return
        norm = normalize_url(url)
        if norm not in index:
            index[norm] = {
                "level": level,
                "parent_url": parent_url,
                "is_leaf": 1 if node.get("leaf") else 0,
                "node_type": node.get("type"),
                "not_found": 1 if node.get("not_found") else 0,
            }
        for child in node.get("children", []):
            walk(child, level + 1, url)

    walk(tree_root, 0, None)
    return index


# ── Excel 读取 ───────────────────────────────────────


def parse_datetime(value) -> datetime | None:
    """解析 Excel 日期单元格，空值返回 None"""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return None
        # 尝试常见格式
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S"):
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue
        logger.warning(f"无法解析日期: {value!r}")
        return None
    return None


def str_or_none(value, max_len: int | None = None) -> str | None:
    """转字符串，空值返回 None；可选截断"""
    if value is None:
        return None
    s = str(value).strip()
    if s == "":
        return None
    if max_len and len(s) > max_len:
        s = s[:max_len]
    return s


def read_excel_rows(excel_path: Path) -> list[dict]:
    """读取 Excel，返回每行字段的 dict 列表（按 Excel 行顺序）。

    Excel 列顺序（15 列）:
      A 原始链接 / B 域名 / C 子路径 / D 文件名 / E 链接类型 /
      F 网站归属 / G 服务大类别 / H 服务小类别 / I 是否下载 /
      J 说明 / K 自定义标记 / L 更新履历 / M 更新时间 /
      N 最后爬取时间 / O content_hash
    """
    wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
    ws = wb.active
    rows: list[dict] = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[0]:
            continue
        rows.append({
            "url": str(row[0]).strip(),
            "domain": str_or_none(row[1]) or "",
            "sub_path": str_or_none(row[2], 1024),
            "file_name": str_or_none(row[3], 512),
            "link_type": str_or_none(row[4]) or "",
            "site_owner": str_or_none(row[5]) or "",
            "service_category": str_or_none(row[6], 64),
            "service_subcategory": str_or_none(row[7], 64),
            "download_flag": str_or_none(row[8], 4),
            "remark": str_or_none(row[9], 256),
            "custom_tag": str_or_none(row[10], 64),
            "update_history": str_or_none(row[11], 64),
            "update_time_tag": parse_datetime(row[12]),
            "last_crawl_time": parse_datetime(row[13]),
            "content_hash": str_or_none(row[14], 64),
        })
    wb.close()
    return rows


# ── 迁移主流程 ───────────────────────────────────────


async def migrate(
    site: str,
    excel_path: Path,
    tree_path: Path,
    batch_size: int,
    reset: bool,
) -> None:
    """执行迁移"""
    # 1. 加载 tree_structure，构建 url → 层级信息索引
    logger.info(f"加载树结构: {tree_path}")
    with open(tree_path, "r", encoding="utf-8") as f:
        tree_root = json.load(f)
    tree_index = build_tree_index(tree_root)
    logger.info(f"树节点总数: {len(tree_index)}")

    # 2. 读 Excel
    logger.info(f"读取 Excel: {excel_path}")
    excel_rows = read_excel_rows(excel_path)
    logger.info(f"Excel 行数: {len(excel_rows)}")

    # 3. 建表（幂等）
    logger.info("初始化数据库表（幂等）...")
    await init_db()

    repo = LinkTreeRepository()

    # 4. 可选重置
    if reset:
        deleted = await repo.delete_by_site(site)
        logger.info(f"已清空 site={site} 旧记录: {deleted} 条")

    # 5. 逐条构造 ORM 模型，分批写入
    total = len(excel_rows)
    imported = 0
    matched = 0
    unmatched = 0
    unmatched_samples: list[str] = []
    buffer: list[CrawlLinkTreeModel] = []

    for i, row in enumerate(excel_rows, start=1):
        url = row["url"]
        norm = normalize_url(url)
        tree_info = tree_index.get(norm)

        if tree_info is not None:
            matched += 1
            level = tree_info["level"]
            parent_url = tree_info["parent_url"]
            is_leaf = tree_info["is_leaf"]
            node_type = tree_info["node_type"]
            not_found = tree_info["not_found"]
        else:
            # Excel 有但树中无：理论上 0 条（已对齐）。降级为 level=0 根节点处理并告警
            unmatched += 1
            if len(unmatched_samples) < 20:
                unmatched_samples.append(url)
            level = 0
            parent_url = None
            is_leaf = 1
            node_type = None
            not_found = 0

        buffer.append(CrawlLinkTreeModel(
            site=site,
            url=url,  # 用 Excel 原始 URL（已标准化，与树对齐）
            level=level,
            parent_url=parent_url,
            is_leaf=is_leaf,
            node_type=node_type,
            not_found=not_found,
            domain=row["domain"],
            sub_path=row["sub_path"],
            file_name=row["file_name"],
            link_type=row["link_type"],
            site_owner=row["site_owner"],
            service_category=row["service_category"],
            service_subcategory=row["service_subcategory"],
            download_flag=row["download_flag"],
            remark=row["remark"],
            custom_tag=row["custom_tag"],
            update_history=row["update_history"],
            update_time_tag=row["update_time_tag"],
            last_crawl_time=row["last_crawl_time"],
            content_hash=row["content_hash"],
        ))

        # 分批提交
        if len(buffer) >= batch_size:
            count = await repo.bulk_create(buffer)
            imported += count
            buffer.clear()
            logger.info(f"进度: {i}/{total}（已写入 {imported} 条）")

    # 提交剩余
    if buffer:
        count = await repo.bulk_create(buffer)
        imported += count
        buffer.clear()

    # 6. 汇总
    logger.info("=" * 60)
    logger.info("迁移完成汇总")
    logger.info("=" * 60)
    logger.info(f"站点: {site}")
    logger.info(f"Excel 总行数: {total}")
    logger.info(f"成功导入: {imported}")
    logger.info(f"树匹配成功: {matched}")
    logger.info(f"树匹配失败（降级 level=0）: {unmatched}")
    if unmatched_samples:
        logger.warning(f"匹配失败样本（前20）:")
        for u in unmatched_samples:
            logger.warning(f"  {u}")

    # DB 实际计数
    db_count = await repo.count_by_site(site)
    logger.info(f"DB 实际记录数（site={site}）: {db_count}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Excel + tree JSON → crawl_link_tree 迁移")
    parser.add_argument("--site", default=DEFAULT_SITE, help=f"站点域名（默认 {DEFAULT_SITE}）")
    parser.add_argument("--excel", default=DEFAULT_EXCEL, help=f"Excel 路径（默认 {DEFAULT_EXCEL}）")
    parser.add_argument("--tree", default=DEFAULT_TREE, help=f"tree_structure JSON 路径（默认 {DEFAULT_TREE}）")
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE, help=f"批量提交大小（默认 {DEFAULT_BATCH_SIZE}）")
    parser.add_argument("--reset", action="store_true", help="迁移前清空该 site 的旧数据")
    args = parser.parse_args()

    excel_path = Path(args.excel)
    tree_path = Path(args.tree)
    if not excel_path.exists():
        logger.error(f"Excel 文件不存在: {excel_path}")
        sys.exit(1)
    if not tree_path.exists():
        logger.error(f"tree_structure 文件不存在: {tree_path}")
        sys.exit(1)

    asyncio.run(migrate(
        site=args.site,
        excel_path=excel_path,
        tree_path=tree_path,
        batch_size=args.batch_size,
        reset=args.reset,
    ))


if __name__ == "__main__":
    main()

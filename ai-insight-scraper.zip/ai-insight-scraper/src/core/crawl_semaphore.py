"""全局爬取并发信号量

控制同时运行的 Chrome/Chromium 爬取任务数量，避免进程过多耗尽机器性能。
并发上限由 config.yaml 的 crawl.max_concurrent_crawlers 控制（默认 1）。
"""

from __future__ import annotations

import asyncio
import logging
import os

from src.config.system_config import load_system_config

logger = logging.getLogger(__name__)

# 模块级全局信号量，首次调用时按配置初始化
_semaphore: asyncio.Semaphore | None = None
# 当前持有信号量的任务标识集合（用于调试并发问题，支持多并发）
_holders: set[str] = set()


def get_crawl_semaphore() -> asyncio.Semaphore:
    """获取全局爬取信号量（惰性初始化）。

    首次调用时从系统配置读取 max_concurrent_crawlers 创建信号量；
    后续调用复用同一实例，保证全进程共享。

    Returns:
        asyncio.Semaphore: 全局爬取信号量
    """
    global _semaphore
    if _semaphore is None:
        cfg = load_system_config()
        limit = cfg.crawl.max_concurrent_crawlers if cfg.crawl else 1
        if limit < 1:
            limit = 1
        _semaphore = asyncio.Semaphore(limit)
        logger.info(
            f"初始化爬取并发信号量: max_concurrent_crawlers={limit}, "
            f"pid={os.getpid()}"
        )
    return _semaphore


class CrawlSemaphoreGuard:
    """信号量上下文管理器，带获取/释放日志，便于调试并发问题。

    用法：
        async with CrawlSemaphoreGuard(task_id):
            ...
    """

    def __init__(self, task_id: str):
        self._task_id = task_id
        self._sem = get_crawl_semaphore()

    async def __aenter__(self) -> "CrawlSemaphoreGuard":
        global _holders
        logger.info(
            f"[信号量] 等待获取: task={self._task_id}, "
            f"当前持有={list(_holders) or '无'}"
        )
        await self._sem.acquire()
        _holders.add(self._task_id)
        logger.info(
            f"[信号量] 已获取: task={self._task_id}, "
            f"当前持有={list(_holders)}"
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        global _holders
        _holders.discard(self._task_id)
        self._sem.release()
        logger.info(
            f"[信号量] 已释放: task={self._task_id}, "
            f"当前持有={list(_holders) or '无'}"
        )

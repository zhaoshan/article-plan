package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateTenantRequest;
import com.unify.iam.api.dto.admin.SetQuotaRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.QuotaService;
import com.unify.iam.app.app.service.admin.AdminTenantService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：租户 CRUD（iam:tenant:*）+ 租户已开通应用（iam:role:read，角色配置用）。 */
@RestController
@RequestMapping("/api/v1/admin/tenants")
public class AdminTenantController {

    private final TenantRepository tenantRepository;
    private final AdminTenantService adminTenantService;
    private final AuditService auditService;
    private final TenantScopeGuard tenantScopeGuard;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final ApplicationRepository applicationRepository;
    private final QuotaService quotaService;

    public AdminTenantController(TenantRepository tenantRepository,
                                 AdminTenantService adminTenantService,
                                 AuditService auditService,
                                 TenantScopeGuard tenantScopeGuard,
                                 TenantApplicationRepository tenantApplicationRepository,
                                 ApplicationRepository applicationRepository,
                                 QuotaService quotaService) {
        this.tenantRepository = tenantRepository;
        this.adminTenantService = adminTenantService;
        this.auditService = auditService;
        this.tenantScopeGuard = tenantScopeGuard;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.applicationRepository = applicationRepository;
        this.quotaService = quotaService;
    }

    /** G1 Usage 视图（A-03 抽屉/成员管理配额条）：全局 iam 维度 + 租户已启用应用维度。 */
    @GetMapping("/{tenantId}/usage")
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public Map<String, Object> usage(@PathVariable String tenantId) {
        return quotaService.usage(CurrentAuth.claims(), tenantId);
    }

    /** G1 租户调额（limit_value 缺省/null → 清除覆盖回落模板默认）。 */
    @PutMapping("/{tenantId}/usage/{dimensionId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, Object> setUsageLimit(@PathVariable String tenantId,
                                             @PathVariable String dimensionId,
                                             @RequestBody(required = false) SetQuotaRequest request) {
        return quotaService.setLimit(CurrentAuth.claims(), tenantId, dimensionId,
                request == null ? null : request.limitValue());
    }

    /**
     * 某租户已开通的应用（角色配置按应用隔离的数据源，docs/05 §7.3 ④）。
     * 权限：iam:role:read（租户管理员可访问本租户；平台管理员任意租户）。
     */
    @GetMapping("/{tenantId}/applications")
    @RequirePermission(PermissionCodes.IAM_ROLE_READ)
    public Map<String, Object> applications(@PathVariable String tenantId) {
        tenantScopeGuard.assertTenantScope(CurrentAuth.claims(), tenantId.trim());
        List<String> appCodes = tenantApplicationRepository.findAppCodesByTenant(tenantId.trim());
        Map<String, ApplicationPO> appByCode = applicationRepository.findActiveByCodes(appCodes).stream()
                .collect(java.util.stream.Collectors.toMap(ApplicationPO::getAppCode, java.util.function.Function.identity(),
                        (a, b) -> a));
        List<Map<String, String>> apps = appCodes.stream()
                .filter(appByCode::containsKey)
                .map(code -> {
                    ApplicationPO app = appByCode.get(code);
                    Map<String, String> m = new LinkedHashMap<>();
                    m.put("app_code", code);
                    m.put("app_name", app.getAppName());
                    return m;
                })
                .toList();
        return Map.of("applications", apps, "count", apps.size());
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public Map<String, Object> list(@RequestParam(name = "limit", defaultValue = "20") int limit) {
        List<Map<String, String>> tenants = adminTenantService.list(limit).stream().map(this::toBrief).toList();
        return Map.of("tenants", tenants, "count", tenants.size());
    }

    @GetMapping("/{tenantId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_READ)
    public Map<String, String> detail(@PathVariable String tenantId) {
        return toBrief(tenantRepository.findById(tenantId)
                .orElseThrow(() -> AuthException.notFound("租户不存在")));
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, String> create(@Valid @RequestBody CreateTenantRequest request) {
        String tenantId = adminTenantService.create(request);
        auditService.audit().event("ADMIN_CREATE_TENANT").actor(CurrentAuth.claims().userId())
                .target("TENANT", tenantId).result("SUCCESS").write(Map.of("tenant_code", request.tenantCode()));
        return Map.of("tenant_id", tenantId);
    }

    @PutMapping("/{tenantId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, String> update(@PathVariable String tenantId,
                                      @RequestBody Map<String, String> fields) {
        adminTenantService.update(CurrentAuth.claims(), tenantId, fields);
        return Map.of("tenant_id", tenantId);
    }

    @DeleteMapping("/{tenantId}")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, String> delete(@PathVariable String tenantId) {
        adminTenantService.delete(CurrentAuth.claims(), tenantId);
        return Map.of("tenant_id", tenantId);
    }

    private Map<String, String> toBrief(TenantPO t) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("tenant_id", t.getTenantId());
        m.put("tenant_code", t.getTenantCode());
        m.put("tenant_name", t.getTenantName());
        m.put("tenant_type", t.getTenantType());
        m.put("tenant_status", t.getTenantStatus());
        m.put("primary_domain", t.getPrimaryDomain());
        return m;
    }
}

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.security.JwtSigner;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

/** The combined global/tenant member catalog must not survive as a registered API. */
class TenantRoleApiRemovalIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    @Qualifier("requestMappingHandlerMapping")
    private RequestMappingHandlerMapping handlers;
    @Autowired
    private JwtSigner signer;

    @Test
    void obsoleteCatalogHasNoHandlerAndAuthenticatedRequestReturns404() throws Exception {
        String path = "/api/v1/admin/tenant/roles";
        assertThat(handlers.getHandlerMethods().keySet().stream()
                .flatMap(mapping -> mapping.getPatternValues().stream()))
                .doesNotContain(path);
        long now = Instant.now().getEpochSecond();
        String token = signer.sign(new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"),
                "u-1000", "tenant-org-a", "ms-1001", List.of("PlatformAdmin"),
                List.of("iam:member:read", "iam:role:read"), Map.of(),
                now + 3600, now, "removed-tenant-role-catalog", 0L));

        mockMvc.perform(get(path).param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isNotFound());
    }
}

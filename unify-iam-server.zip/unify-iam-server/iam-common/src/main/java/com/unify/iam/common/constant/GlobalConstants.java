package com.unify.iam.common.constant;

/** 全局常量。 */
public final class GlobalConstants {

    private GlobalConstants() {
    }

    /** 逻辑删除：正常 */
    public static final int DELETE_FLAG_NORMAL = 0;
    /** 逻辑删除：已删除 */
    public static final int DELETE_FLAG_DELETED = 1;

    /** 系统操作者占位（E2E-1 无用户上下文时自动填充用） */
    public static final String SYSTEM_OPERATOR = "system";
}

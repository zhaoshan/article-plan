"""content_crawl_config 配置解析测试"""

import pytest
from pydantic import ValidationError

from src.config.content_crawl_config import load_content_crawl_config
from src.models.content_crawl_config import ContentCrawlConfig, ExcludeTag


class TestLoadContentCrawlConfig:
    """load_content_crawl_config 测试"""

    def test_finds_config_by_domain(self, sample_config_dir):
        """按域名找到配置"""
        config = load_content_crawl_config("tokyostarbank.co.jp", sample_config_dir)
        assert isinstance(config, ContentCrawlConfig)
        assert len(config.exclude_tags) == 2

    def test_exclude_tags_parsed_with_class_alias(self, sample_config_dir):
        """class 别名正确解析"""
        config = load_content_crawl_config("example.com", sample_config_dir)
        assert len(config.exclude_tags) == 1
        rule = config.exclude_tags[0]
        assert rule.tag == "nav"
        assert rule.class_ == "main-nav"

    def test_id_field_parsed(self, sample_config_dir):
        """id 字段正确解析"""
        config = load_content_crawl_config("tokyostarbank.co.jp", sample_config_dir)
        header_rule = config.exclude_tags[0]
        assert header_rule.tag == "header"
        assert header_rule.id == "header"
        assert header_rule.class_ is None

    def test_returns_defaults_for_unknown_domain(self, sample_config_dir):
        """未知域名返回默认空配置"""
        config = load_content_crawl_config("unknown-domain.com", sample_config_dir)
        assert isinstance(config, ContentCrawlConfig)
        assert config.exclude_tags == []

    def test_real_config_loads(self):
        """加载项目真实的 content_crawl_config.json"""
        config = load_content_crawl_config("tokyostarbank.co.jp")
        assert len(config.exclude_tags) == 6
        # 验证第一条规则结构
        first = config.exclude_tags[0]
        assert first.tag == "header"
        assert first.id == "header"


class TestExcludeTag:
    """ExcludeTag 模型测试"""

    def test_tag_required(self):
        """tag 为必填字段"""
        with pytest.raises(ValidationError):
            ExcludeTag()

    def test_tag_min_length(self):
        """tag 不能为空字符串"""
        with pytest.raises(ValidationError):
            ExcludeTag(tag="")

    def test_class_alias(self):
        """class 别名构造"""
        rule = ExcludeTag(tag="div", **{"class": "footer"})
        assert rule.class_ == "footer"

    def test_optional_fields(self):
        """id/class 可选"""
        rule = ExcludeTag(tag="p")
        assert rule.id is None
        assert rule.class_ is None

    def test_extra_fields_allowed(self):
        """允许扩展字段（未来兼容）"""
        rule = ExcludeTag(tag="div", **{"class": "x", "data-role": "banner"})
        assert rule.tag == "div"

# Enterprise tenant Owner invitation plan

Date: 2026-10-27

Status: Complete.

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, plan, session, and validation records in this repository's `.trellis/` directory.
- Do not inspect or change a frontend repository or supplied UI design.
- Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- Hidden-path searches confirm that `AGENTS.md` and `.trellis/workflow.md` are absent in this worktree. `CLAUDE.md` and `.claude/rules/security.md` are the applicable instructions; no undocumented Trellis confirmation gate can be inferred.

## Confirmed baseline

1. The current admin create request requires caller-provided `tenant_code` and `app_codes`, and can optionally bind an existing `owner_user_id`.
2. The existing Owner-transfer action already has a real SMTP sender gate and accepts an invitation only after the target account authenticates with the matching email.
3. The current built-in `iam` application has a PLATFORM-scope `PlatformAdmin` Owner template. It must never become the implicit default for a customer enterprise tenant.
4. `imorph` is the current seeded business application with a tenant-scoped Owner role template. It is the initial explicit platform default application policy.
5. SMTP is an external side effect. A failed sender must return 503 and leave no persisted tenant/invitation created by this request. The transaction therefore includes creation, invitation persistence, and the synchronous sender call.

## Chosen contract

- `POST /api/v1/admin/tenants` accepts the form payload `{tenant_name, owner_email}`. This form branch rejects legacy creation fields so the UI cannot retain or fabricate applications, an initial administrator, a tenant code, or tenant type.
- Existing legacy admin callers remain supported only when `owner_email` is absent. This compatibility path is not used by the form.
- The service generates an internal `org-<uuid>` tenant code, fixes `tenant_type=ORGANIZATION`, persists `tenant_status=PENDING`, and provisions only the configured tenant-scoped default applications.
- The transaction creates a `TENANT_OWNER_SETUP` invitation and sends it through the existing Owner mail transport. A success response accurately reports that the tenant and invitation are pending; it does not claim that ownership has already transferred.
- On matching-email acceptance, the existing authoritative invitation action creates the member if needed, grants Owner template roles, writes `owner_user_id`, changes the tenant to `ACTIVE`, and writes an audit event.
- Missing SMTP configuration and actual sender failures return 503. The create transaction rolls back, so it leaves no ownerless tenant. The same actual-delivery rollback rule is covered for the edit Owner invite action.

## Implementation checklist

- [x] Read repository instructions, relevant Owner/tenant design documents, current invitation flow, authorization, seed policy, and tests.
- [x] Record the absent requested workflow files and the direct-user authorization basis.
- [x] Add the form DTO/response contract and route branching with platform-admin authorization.
- [x] Add tenant-code/default-application policy validation and transactional enterprise Owner invitation provisioning.
- [x] Add initial Owner invitation acceptance/activation without changing the Owner-transfer semantics.
- [x] Cover validation, default app safety, SMTP 503 rollback, successful pending state, and authoritative acceptance with focused integration tests.
- [x] Update API documentation and task validation/session records.

## Validation target

```text
mvn -pl iam-app -am test -Dtest='EnterpriseTenantOwnerInvitationIntegrationTest,TenantDetailOwnerQuotaIntegrationTest,OwnerInvitationMailServiceTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
git diff --check
```

## Validation result

```text
mvn -pl iam-app -am -DskipTests compile -Dmaven.compiler.proc=full
# passed

mvn -pl iam-app -am test -Dtest='EnterpriseTenantOwnerInvitationIntegrationTest,TenantDetailOwnerQuotaIntegrationTest,OwnerInvitationMailServiceTest' \
  -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 9 passed, 0 failures, 0 errors

mvn -pl iam-app -am test -Dtest='P3TenantInitIntegrationTest,P3AdminCrudIntegrationTest,P3TenantScopeIntegrationTest,AdminProtectionIntegrationTest,EnterpriseTenantOwnerInvitationIntegrationTest,TenantDetailOwnerQuotaIntegrationTest,OwnerInvitationMailServiceTest' \
  -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 39 passed, 0 failures, 0 errors
```

The integration suite used the local Docker socket for Testcontainers. `git diff --check` passed.
No branch/worktree operation, commit, merge, push, checkout, or reset was performed.

"""爬取服务路由 — 站点链接树爬取接口

S3 支持：
  - /api/crawl/tree 的 output_type="s3" 时，自动将结果上传到 S3
  - /api/crawl/dynamic 的 static_links_file / static_tree_file 为 s3:// 路径时，
    自动从 S3 下载后合并并上传覆盖
  - /api/crawl/full-site 全量爬取，自动编排 tree→dynamic→link_tree_sync
"""

import asyncio
import logging

from fastapi import APIRouter, Depends, HTTPException, Query

from src.boundaries.s3_boundary import S3Boundary
from src.config.system_config import load_s3_config
from src.config.traversal_config import load_traversal_config
from src.core.auth import require_internal_token
from src.core.full_site_crawler import FullSiteCrawler
from src.core.tree_crawler import TreeCrawler
from src.core.dynamic_crawler import DynamicCrawler
from src.core.task_manager import DatabaseTaskManager
from src.database.repository import TaskRepository
from src.models.api_response import DefaultResult
from src.models.crawl_request import (
    CrawlRequest,
    DynamicCrawlRequest,
    FullSiteCrawlRequest,
)
from src.models.crawl_task import CrawlTask
from src.utils.url_utils import get_domain

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/crawl",
    tags=["站点链接树爬取"],
    dependencies=[Depends(require_internal_token)],
)

# 全局任务管理器（单例，由 main.py 注入）
_task_manager: DatabaseTaskManager | None = None


def get_task_manager() -> DatabaseTaskManager:
    """获取任务管理器实例"""
    global _task_manager
    if _task_manager is None:
        _task_manager = DatabaseTaskManager()
    return _task_manager


def _build_s3_boundary() -> S3Boundary | None:
    """构建 S3Boundary 实例，配置不完整时返回 None"""
    try:
        return S3Boundary()
    except ValueError:
        logger.warning("S3 配置不完整，S3 功能将不可用")
        return None


@router.post("/tree", response_model=DefaultResult)
async def start_crawl_tree(request: CrawlRequest) -> DefaultResult:
    """
    启动 tree 模式站点链接树爬取任务。

    提交爬取参数，返回 task_id，任务在后台异步执行。
    output_type="s3" 时结果文件将上传到 S3。
    """
    task_manager = get_task_manager()

    # 解析域名
    domain = get_domain(request.target_url)
    if not domain:
        raise HTTPException(
            status_code=400,
            detail=f"无法解析目标 URL 的域名: {request.target_url}",
        )

    # 创建任务实体
    task = task_manager.create_task(
        task_type="tree",
        site=domain,
        target_url=request.target_url,
        max_depth=request.max_depth,
        headless=request.headless,
        output_type=request.output_type,
    )

    # 加载遍历配置
    traversal_config = load_traversal_config(domain)

    # 构建 S3Boundary（s3 模式时需要）
    s3_boundary = None
    if request.output_type == "s3":
        s3_boundary = _build_s3_boundary()
        if s3_boundary is None:
            raise HTTPException(
                status_code=500,
                detail="S3 配置不完整，无法以 s3 模式输出爬取结果",
            )

    # 创建爬虫实例
    crawler = TreeCrawler(
        headless=request.headless,
        output_dir="output",
        log_dir="logs",
        traversal_config=traversal_config,
        s3_boundary=s3_boundary,
        output_type=request.output_type,
    )

    # 计算有效爬取层级
    effective_depth = (
        request.max_depth
        if request.max_depth is not None
        else traversal_config.drill_down_levels
    )

    # 启动异步爬取任务
    await task_manager.start_task(
        task,
        crawler.crawl(request.target_url, max_depth=request.max_depth),
    )

    logger.info(
        f"爬取任务已启动: task_id={task.task_id}, "
        f"target_url={request.target_url}, "
        f"domain={domain}, "
        f"max_depth={effective_depth}（0=不限），"
        f"output_type={request.output_type}，"
        f"来源={'用户传入' if request.max_depth is not None else '配置文件'}"
    )

    return DefaultResult(
        data={
            "task_id": task.task_id,
            "status": task.status,
        }
    )


@router.post("/dynamic", response_model=DefaultResult)
async def start_dynamic_crawl(request: DynamicCrawlRequest) -> DefaultResult:
    """
    启动动态页面链接爬取任务。

    根据 site + page_type 查找对应的动态脚本配置，
    执行脚本获取链接后合并到指定的静态文件中。

    static_links_file / static_tree_file 支持 s3:// 路径，
    自动从 S3 下载后合并并上传覆盖。

    任务在后台异步执行，通过 /status/{task_id} 和 /result/{task_id} 查询进度和结果。
    """
    task_manager = get_task_manager()

    # 根据入参文件路径判断输出类型：s3:// 路径走 S3 模式，否则本地模式
    is_s3 = (
        request.static_links_file.startswith("s3://")
        or request.static_tree_file.startswith("s3://")
    )
    output_type = "s3" if is_s3 else "local"

    # 创建任务实体
    task = task_manager.create_task(
        task_type="dynamic",
        site=request.site,
        target_url=f"{request.site}/{request.page_type}",
        headless=request.headless,
        output_type=output_type,
    )

    s3_boundary = _build_s3_boundary()
    crawler = DynamicCrawler(headless=request.headless, s3_boundary=s3_boundary)

    # 启动异步爬取任务
    await task_manager.start_task(
        task,
        crawler.crawl_dynamic(
            site=request.site,
            page_type=request.page_type,
            static_links_file=request.static_links_file,
            static_tree_file=request.static_tree_file,
        ),
    )

    logger.info(
        f"动态爬取任务已启动: task_id={task.task_id}, "
        f"site={request.site}, page_type={request.page_type}, "
        f"links_file={request.static_links_file}, "
        f"tree_file={request.static_tree_file}"
    )

    return DefaultResult(
        data={
            "task_id": task.task_id,
            "status": task.status,
        }
    )


@router.post("/full-site", response_model=DefaultResult)
async def start_full_site_crawl(request: FullSiteCrawlRequest) -> DefaultResult:
    """
    启动全量链接树爬取任务。

    自动完成以下步骤：
      1. 创建主任务（task_type=full_site）
      2. 解析域名，加载该站点的遍历规则和动态页面配置
      3. 调度 TreeCrawler（S3 模式）执行全量静态链接爬取
      4. 如有动态页面配置，调度 DynamicCrawler
      5. 同步到 crawl_link_tree 表
      6. 更新主任务状态

    任务在后台异步执行，主任务 ID 立即返回。
    """
    # 校验 URL 可解析域名
    domain = get_domain(request.target_url)
    if not domain:
        raise HTTPException(
            status_code=400,
            detail=f"无法解析目标 URL 的域名: {request.target_url}",
        )

    master_task = await _launch_full_site(
        domain=domain,
        target_url=request.target_url,
        headless=request.headless,
        max_depth=request.max_depth,
    )

    logger.info(
        f"全量爬取任务已启动: task_id={master_task.task_id}, "
        f"target_url={request.target_url}, domain={domain}"
    )

    return DefaultResult(
        data={
            "task_id": master_task.task_id,
            "status": "running",
        }
    )


async def _launch_full_site(
    domain: str,
    target_url: str,
    headless: bool,
    max_depth: int | None,
) -> CrawlTask:
    """创建全量爬取主任务并启动后台编排（供 /full-site 和链接查询接口复用）。

    Args:
        domain: 已解析的站点域名
        target_url: 站点首页 URL
        headless: 是否无头模式
        max_depth: 爬取深度，None=用配置默认值

    Returns:
        CrawlTask: 已持久化并标记为 running 的主任务实体
    """
    task_manager = get_task_manager()
    master_task = task_manager.create_task(
        task_type="full_site",
        site=domain,
        target_url=target_url,
        max_depth=max_depth,
        headless=headless,
        output_type="s3",
    )
    repo = TaskRepository()
    await repo.create(master_task)
    await repo.mark_running(master_task.task_id)

    asyncio.create_task(
        _run_full_site_background(
            master_task=master_task,
            target_url=target_url,
            headless=headless,
            max_depth=max_depth,
        )
    )
    return master_task


async def _run_full_site_background(
    master_task: CrawlTask,
    target_url: str,
    headless: bool,
    max_depth: int | None,
) -> None:
    """全量爬取后台执行（在路由层创建任务后调用）"""
    repo = TaskRepository()
    try:
        crawler = FullSiteCrawler(
            headless=headless,
            max_depth=max_depth,
        )
        # 传入已在路由层创建好的主任务
        result = await crawler.run(target_url, master_task=master_task)
        logger.info(f"全量爬取后台执行完成: task_id={master_task.task_id}")
    except Exception as e:
        logger.exception(f"全量爬取后台执行失败: {master_task.task_id}")
        await repo.mark_failed(master_task.task_id, error_message=str(e))


@router.get("/status/{task_id}", response_model=DefaultResult)
async def get_task_status(task_id: str) -> DefaultResult:
    """查询爬取任务状态"""
    task_manager = get_task_manager()
    task = await task_manager.get_status(task_id)

    if task is None:
        raise HTTPException(status_code=404, detail=f"任务不存在: {task_id}")

    return DefaultResult(
        data={
            "task_id": task.task_id,
            "task_type": task.task_type,
            "site": task.site,
            "status": task.status,
            "progress": {
                "pages_crawled": task.progress.pages_crawled,
                "links_found": task.progress.links_found,
            },
            "links_path": task.links_path,
            "tree_path": task.tree_path,
            "create_time": task.create_time,
            "update_time": task.update_time,
            "finished_at": task.finished_at,
            "error_message": task.error_message,
        }
    )


@router.get("/result/{task_id}", response_model=DefaultResult)
async def get_task_result(task_id: str) -> DefaultResult:
    """获取爬取任务结果"""
    task_manager = get_task_manager()
    task = await task_manager.get_status(task_id)

    if task is None:
        raise HTTPException(status_code=404, detail=f"任务不存在: {task_id}")

    if task.status == "pending":
        raise HTTPException(status_code=400, detail="任务尚未开始执行")

    if task.status == "running":
        return DefaultResult(
            code="1000",
            message="任务执行中，请稍后再试",
            data={
                "task_id": task_id,
                "status": "running",
                "progress": {
                    "pages_crawled": task.progress.pages_crawled,
                    "links_found": task.progress.links_found,
                },
            },
        )

    if task.status == "failed":
        error = task.error_message or "未知错误"
        return DefaultResult(
            code="9999",
            message=f"任务执行失败: {error}",
            data={"task_id": task_id, "status": "failed"},
        )

    # 任务完成
    result = await task_manager.get_result(task_id)
    if result is None:
        raise HTTPException(status_code=500, detail="任务结果丢失")

    return DefaultResult(
        data={
            "task_id": result.task_id,
            "links_path": task.links_path,
            "tree_path": task.tree_path,
            "tree_structure": result.tree_structure,
            "all_links": result.all_links,
            "stats": result.stats,
        }
    )


@router.get("/tasks", response_model=DefaultResult)
async def list_tasks(
    site: str | None = Query(default=None, description="按站点域名过滤"),
    status: str | None = Query(default=None, description="按状态过滤"),
    limit: int = Query(default=20, ge=1, le=100, description="每页数量"),
    offset: int = Query(default=0, ge=0, description="偏移量"),
) -> DefaultResult:
    """查询任务列表，支持按站点和状态过滤"""
    task_manager = get_task_manager()

    if site:
        tasks = await task_manager.list_by_site(site, limit, offset)
    elif status:
        tasks = await task_manager.list_by_status(status, limit, offset)
    else:
        tasks = await task_manager.list_all(limit, offset)

    return DefaultResult(
        data={
            "tasks": [
                {
                    "task_id": t.task_id,
                    "task_type": t.task_type,
                    "site": t.site,
                    "status": t.status,
                    "target_url": t.target_url,
                    "links_path": t.links_path,
                    "tree_path": t.tree_path,
                    "progress": {
                        "pages_crawled": t.progress.pages_crawled,
                        "links_found": t.progress.links_found,
                    },
                    "create_time": t.create_time,
                    "finished_at": t.finished_at,
                }
                for t in tasks
            ],
            "total": len(tasks),
            "limit": limit,
            "offset": offset,
        }
    )
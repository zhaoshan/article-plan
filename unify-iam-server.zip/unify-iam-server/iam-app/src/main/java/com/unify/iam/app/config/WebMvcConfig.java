package com.unify.iam.app.config;

import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web MVC 配置：注册管理面鉴权拦截器（仅保护 `/api/v1/admin/**`，不动公开端点）。
 *
 * <p>用 {@code ObjectProvider} 容错：全量上下文有拦截器 bean 则注册；{@code @WebMvcTest} 切片不扫描
 * 该 @Component（无 bean）时跳过，避免上下文加载失败。
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final ObjectProvider<ManagementAuthorizationInterceptor> interceptorProvider;

    public WebMvcConfig(ObjectProvider<ManagementAuthorizationInterceptor> interceptorProvider) {
        this.interceptorProvider = interceptorProvider;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        ManagementAuthorizationInterceptor interceptor = interceptorProvider.getIfAvailable();
        if (interceptor != null) {
            registry.addInterceptor(interceptor).addPathPatterns("/api/v1/admin/**");
        }
    }
}
package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * 应用可用性能力端点（docs/user-manual 03 §3.2）：返回「启用该应用的成员」+「是否平台管理员」，
 * hub 据此做选租户 / 跳 IAM 控制台 / 阻断分流。
 */
class AppAccessIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> appAccess(String token, String appCode) throws Exception {
        MvcResult res = mockMvc.perform(get("/api/v1/auth/app-access")
                        .header("Authorization", "Bearer " + token)
                        .param("app_code", appCode))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), Map.class);
    }

    @Test
    void returnsUsableMembershipsAndPlatformFlag() throws Exception {
        // admin：tenant-org-a 启用 parlant + PlatformAdmin 角色
        Map<String, Object> admin = appAccess(login("admin", "admin123"), "parlant-agent-server");
        assertThat(((List<Map<String, Object>>) admin.get("memberships")))
                .anyMatch(m -> "ms-1001".equals(m.get("membership_id")));
        assertThat(admin.get("is_platform_admin")).isEqualTo(true);

        // viewer：tenant-org-a 启用 parlant，但无平台角色
        Map<String, Object> viewer = appAccess(login("viewer", "view123"), "parlant-agent-server");
        assertThat(((List<Map<String, Object>>) viewer.get("memberships")))
                .anyMatch(m -> "ms-3001".equals(m.get("membership_id")));
        assertThat(viewer.get("is_platform_admin")).isEqualTo(false);
    }

    @Test
    void unseededAppReturnsEmptyMemberships() throws Exception {
        // ai-chat-insight 未注册/未启用 → 无可选租户（但仍能判平台管理员）
        Map<String, Object> admin = appAccess(login("admin", "admin123"), "ai-chat-insight");
        assertThat(((List<?>) admin.get("memberships"))).isEmpty();
        assertThat(admin.get("is_platform_admin")).isEqualTo(true);

        Map<String, Object> viewer = appAccess(login("viewer", "view123"), "ai-chat-insight");
        assertThat(((List<?>) viewer.get("memberships"))).isEmpty();
        assertThat(viewer.get("is_platform_admin")).isEqualTo(false);
    }

    @Test
    void missingTokenReturns401() throws Exception {
        mockMvc.perform(get("/api/v1/auth/app-access").param("app_code", "parlant-agent-server"))
                .andExpect(status().isUnauthorized());
    }
}

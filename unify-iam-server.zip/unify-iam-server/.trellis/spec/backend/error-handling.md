# Error Handling

> How errors are handled in this project.

---

## Overview

<!--
Document your project's error handling conventions here.

Questions to answer:
- What error types do you define?
- How are errors propagated?
- How are errors logged?
- How are errors returned to clients?
-->

(To be filled by the team)

## Tenant list scope contract

`GET /api/v1/admin/tenants` accepts the optional query tuple `scope_type` and
`scope_id` in addition to `limit`:

| Request | Meaning | Result |
| --- | --- | --- |
| no scope parameters | Existing platform management list | All visible tenants, bounded by `limit` |
| `scope_type=PLATFORM&scope_id=PLATFORM` | Platform scope | All visible tenants, bounded by `limit` |
| `scope_type=TENANT&scope_id=<tenant_id>` | Tenant scope | Only the requested tenant |

Scope values are case-sensitive and use the exact snake_case field names shown
above. A partial tuple, blank `scope_id`, lowercase/mixed-case scope value, or
`PLATFORM` paired with a non-`PLATFORM` id raises `AuthException.badRequest` and
is rendered as the standard management API 400 envelope. Filtering must be
applied in the tenant repository query before the existing limit and before
application-summary enrichment; validation in the controller alone is
insufficient because it can leave a broader data query behind.

Required regression assertions cover the tenant-scoped result, the platform and
no-parameter compatibility paths, an unknown tenant returning an empty list,
invalid casing/tuples returning 400, and the existing permission gate.

---

## Error Types

<!-- Custom error classes/types -->

(To be filled by the team)

---

## Error Handling Patterns

<!-- Try-catch patterns, error propagation -->

(To be filled by the team)

---

## API Error Responses

<!-- Standard error response format -->

(To be filled by the team)

---

## Common Mistakes

<!-- Error handling mistakes your team has made -->

(To be filled by the team)

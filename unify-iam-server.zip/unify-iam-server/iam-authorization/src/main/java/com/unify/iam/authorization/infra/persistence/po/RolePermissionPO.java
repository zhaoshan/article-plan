package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_role_permission 角色与权限关联表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_role_permission")
public class RolePermissionPO extends BaseEntity {

    /** 角色权限关系业务唯一标识 */
    private String rolePermissionId;
    /** 角色 ID */
    private String roleId;
    /** 权限 ID */
    private String permissionId;
}

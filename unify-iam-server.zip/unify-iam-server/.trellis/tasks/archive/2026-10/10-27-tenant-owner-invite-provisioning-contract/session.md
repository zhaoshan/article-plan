# Session record

## 2026-10-27: discovery and implementation start

- Task source: delegated backend-only request for the current `platform-iam-service` main worktree. The tenant form will be changed elsewhere; no frontend source is in scope here.
- Starting Git state: the worktree already contains unrelated source, docs, tests, and Trellis task changes, including a prior tenant-detail/Owner-transfer implementation. Those changes are preserved and not reverted.
- Required instruction discovery: `AGENTS.md` and `.trellis/workflow.md` are not present in this worktree. `CLAUDE.md` and `.claude/rules/security.md` were read and require additive migrations, explicit administrative authorization, uniform API envelopes, and no automatic commits.
- Existing `POST /api/v1/admin/tenants` is a legacy explicit-app contract. The new Owner-email form branch will use the same route but reject all legacy data whenever `owner_email` is provided, preserving old internal calls only when it is absent.
- `iam` is a PLATFORM-scoped `PlatformAdmin` template and cannot be an enterprise default. The seeded `imorph` business application is the initial configured default and will be validated as tenant-scoped before use.
- The new create path will create a PENDING tenant and a `TENANT_OWNER_SETUP` invitation. Acceptance by the matching authenticated account will become the authoritative Owner assignment and tenant activation. SMTP misconfiguration or a real delivery exception will return 503 and roll back all newly created records.
- No branch/worktree operation, commit, merge, push, checkout, reset, or frontend access has been performed.

## 2026-10-27: validation repair

- The first Docker-backed integration run reached the new endpoint and exposed that `gateway_tenant.registration_source`
  is shorter than the initially chosen marker. The marker was reduced to `OWNER_INVITE`, which fits the existing schema;
  no migration is needed and no applied migration was changed.

## 2026-10-27: implementation and validation complete

- Added a two-field `POST /api/v1/admin/tenants` branch. Requests containing `owner_email` reject the old caller-owned
  tenant code, tenant type, primary domain, owner user ID, and application fields; they are platform-admin-only.
- The server creates `org-<uuid>` codes, writes only `ORGANIZATION`, validates the configured business default app policy
  (`imorph` by default), and rejects `iam` or PLATFORM-scoped templates before provisioning.
- Successful requests return a PENDING tenant plus an Owner invitation with `delivery_status=DELIVERED`. The matching
  account accepting the invitation creates the membership when necessary, receives Owner roles, becomes `owner_user_id`,
  and activates the tenant. A PENDING tenant can be recovered by the existing authoritative Owner email action.
- Missing SMTP configuration and actual mail delivery exceptions return 503. The tenant, role/application setup, invitation,
  and audit write share one transaction, so a failed create does not persist an ownerless tenant. Existing Owner-transfer
  invitations use the same rollback behavior.
- Updated the API manual, configuration documentation, audit catalog, and focused integration coverage. No frontend source
  or separate Platform IAM worktree was accessed.
- Validation passed: compile; focused Owner contract regression (9 tests); final tenant-create/authorization regression
  (39 tests); and `git diff --check`.
- No branch/worktree operation, commit, merge, push, checkout, or reset was performed.

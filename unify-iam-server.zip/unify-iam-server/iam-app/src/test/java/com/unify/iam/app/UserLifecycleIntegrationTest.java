package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * 用户生命周期级联集成测试（2026-11-06）：
 * ① 移除最后一名成员 → 孤儿用户软删（+身份）→ 邮箱可重新注册（V22 生成列唯一键）；
 * ② 多租户用户移除单个成员不被误删；③ 删除租户级联成员/角色/邀请/孤儿用户；
 * ④ 成员被移除后同用户可重新加入（membership 生成列唯一键）。
 */
class UserLifecycleIntegrationTest extends IamIntegrationTestBase {

    private String adminToken() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return com.unify.iam.common.util.JsonUtils.fromJson(
                dataJson(res.getResponse().getContentAsString()),
                com.unify.iam.api.dto.auth.LoginResponse.class).accessToken();
    }

    private String sfx() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    private static final String OTHER_OWNER = "u-1000";

    private String createUser(String token, String username) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + username + "@unify.local\",\"password\":\""
                                + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("user_id").toString();
    }

    private String createTenant(String token, String code, String ownerUserId) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"" + code + "\",\"tenant_name\":\"" + code + "\","
                                + "\"app_codes\":[\"parlant-agent-server\"],\"owner_user_id\":\"" + ownerUserId + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
    }

    private String addMember(String token, String tenantId, String userId) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"" + tenantId + "\",\"user_id\":\"" + userId + "\",\"role_ids\":[]}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("membership_id").toString();
    }

    private String membershipOf(String tenantId, String userId) {
        return jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id=? AND user_id=? AND delete_flag=0",
                String.class, tenantId, userId.trim()).trim();
    }

    private void removeMember(String token, String membershipId) throws Exception {
        mockMvc.perform(delete("/api/v1/admin/members/" + membershipId)
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());
    }

    private int userFlag(String userId) {
        Integer f = jdbcTemplate.queryForObject(
                "SELECT delete_flag FROM gateway_user WHERE user_id=?", Integer.class, userId.trim());
        return f == null ? -1 : f;
    }

    @Test
    void removingLastMembershipSoftDeletesUserAndEmailBecomesReusable() throws Exception {
        String admin = adminToken();
        String username = "orphan_" + sfx();
        String userId = createUser(admin, username);
        String tenantId = createTenant(admin, "orph_" + sfx(), OTHER_OWNER);
        addMember(admin, tenantId, userId);
        removeMember(admin, membershipOf(tenantId, userId));

        // 用户 + 身份软删
        assertThat(userFlag(userId)).isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user_identity WHERE user_id=? AND delete_flag=0",
                Integer.class, userId.trim())).isZero();

        // 邮箱可重新注册（V22 active_email 生成列唯一键；注册需验证码）
        issueVerificationCode(username + "@unify.local");
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", username + "_v2",
                                "email", username + "@unify.local",
                                "password", b64("New123456!"),
                                "verification_code", "123456"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.user_id").isNotEmpty());
    }

    @Test
    void userWithOtherTenantMembershipSurvivesMemberRemoval() throws Exception {
        String admin = adminToken();
        String username = "survivor_" + sfx();
        String userId = createUser(admin, username);
        String t1 = createTenant(admin, "sv1_" + sfx(), OTHER_OWNER);
        addMember(admin, t1, userId);
        createTenant(admin, "sv2_" + sfx(), userId);
        removeMember(admin, membershipOf(t1, userId));
        assertThat(userFlag(userId)).isEqualTo(0);
    }

    @Test
    void deletingTenantCascadesMembersRolesInvitesAndOrphanedUsers() throws Exception {
        String admin = adminToken();
        // 孤儿用户：只属于将被删除的租户
        String orphanName = "casc_orphan_" + sfx();
        String orphanId = createUser(admin, orphanName);
        String tenantId = createTenant(admin, "casc_" + sfx(), OTHER_OWNER);
        addMember(admin, tenantId, orphanId);
        // 多租户用户：本租户 + tenant-org-a
        String survivorName = "casc_surv_" + sfx();
        String survivorId = createUser(admin, survivorName);
        addMember(admin, tenantId, survivorId);
        addMember(admin, "tenant-org-a", survivorId); // 第二租户成员关系：级联后用户应保留
        // 角色绑定 + 待定邀请
        String roleId = unwrapData(mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"" + tenantId + "\","
                                + "\"role_code\":\"CascRole\",\"role_name\":\"Casc\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("role_id").toString();
        String orphanMs = membershipOf(tenantId, orphanId);
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .put("/api/v1/admin/members/" + orphanMs + "/roles")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"" + roleId.trim() + "\"]}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"casc-pending-" + sfx() + "@unify.local\",\"tenant_id\":\"" + tenantId + "\"}"))
                .andExpect(status().isOk());

        mockMvc.perform(delete("/api/v1/admin/tenants/" + tenantId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());

        assertThat(jdbcTemplate.queryForObject(
                "SELECT delete_flag FROM gateway_tenant WHERE tenant_id=?", Integer.class, tenantId)).isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership WHERE tenant_id=? AND delete_flag=0",
                Integer.class, tenantId)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "WHERE m.tenant_id=? AND mr.delete_flag=0", Integer.class, tenantId)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE tenant_id=? AND invitation_status='PENDING'",
                Integer.class, tenantId)).isZero(); // 待定邀请已撤销
        assertThat(userFlag(orphanId)).isEqualTo(1);   // 孤儿用户已软删
        assertThat(userFlag(survivorId)).isEqualTo(0); // 多租户用户保留
    }

    @Test
    void removedMemberCanRejoinSameTenant() throws Exception {
        String admin = adminToken();
        String username = "rejoin_" + sfx();
        String userId = createUser(admin, username);
        String tenantId = createTenant(admin, "rj_" + sfx(), OTHER_OWNER);
        addMember(admin, tenantId, userId);
        removeMember(admin, membershipOf(tenantId, userId));
        // 用户已成孤儿被软删 → 先恢复用户（管理端恢复语义），再验证同租户重新加入（membership 生成列唯一键）：
        jdbcTemplate.update("UPDATE gateway_user SET delete_flag=0 WHERE user_id=?", userId.trim());
        addMember(admin, tenantId, userId); // V22 前会撞 uk_gateway_membership_tenant_user 500
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership WHERE tenant_id=? AND user_id=? AND delete_flag=0",
                Integer.class, tenantId, userId.trim())).isEqualTo(1);
    }
}

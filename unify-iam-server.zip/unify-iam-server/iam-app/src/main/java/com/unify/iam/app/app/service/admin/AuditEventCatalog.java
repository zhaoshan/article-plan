package com.unify.iam.app.app.service.admin;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 审计事件目录（code → 中文名称），供管理台筛选下拉与列表展示（G5 可用性）。
 * 与代码中的 {@code audit().event("...")} 写点保持一致；新增事件时在此登记。
 */
public final class AuditEventCatalog {

    private static final Map<String, String> NAMES = new LinkedHashMap<>();

    static {
        reg("ADMIN_CREATE_TENANT", "创建租户");
        reg("ADMIN_UPDATE_TENANT", "更新租户（启停/改名/域名）");
        reg("ADMIN_DELETE_TENANT", "删除租户");
        reg("ADMIN_CREATE_USER", "创建用户");
        reg("ADMIN_UPDATE_USER", "更新用户");
        reg("ADMIN_DELETE_USER", "删除（禁用）用户");
        reg("ADMIN_LIST_USERS", "查询用户列表");
        reg("ADMIN_CREATE_ROLE", "创建角色");
        reg("ADMIN_SET_ROLE_PERMISSIONS", "设置角色权限");
        reg("ADMIN_DELETE_ROLE", "删除角色");
        reg("ADMIN_ADD_MEMBER", "添加成员");
        reg("ADMIN_REMOVE_MEMBER", "移除成员");
        reg("ADMIN_SET_MEMBER_ROLES", "设置成员角色");
        reg("ADMIN_SUSPEND_MEMBER", "停用成员");
        reg("ADMIN_RESTORE_MEMBER", "恢复成员");
        reg("ADMIN_INVITE", "创建邀请");
        reg("ADMIN_APPROVE_JOIN", "通过加入申请");
        reg("ADMIN_REJECT_JOIN", "拒绝加入申请");
        reg("ADMIN_CREATE_IDP_CONFIG", "创建 IdP 配置");
        reg("ADMIN_UPDATE_IDP_CONFIG", "更新 IdP 配置");
        reg("ADMIN_DELETE_IDP_CONFIG", "删除 IdP 配置");
        reg("ADMIN_CREATE_GROUP_MAPPING", "创建组→角色映射");
        reg("ADMIN_UPDATE_GROUP_MAPPING", "更新组→角色映射");
        reg("ADMIN_DELETE_GROUP_MAPPING", "删除组→角色映射");
    }

    private AuditEventCatalog() {
    }

    private static void reg(String code, String name) {
        NAMES.put(code, name);
    }

    /** code → 名称；未登记 → 原样返回 code。 */
    public static String nameOf(String code) {
        return code == null ? null : NAMES.getOrDefault(code, code);
    }

    /** 全部事件（有序）：[{code, name}]。 */
    public static List<Map<String, String>> all() {
        return NAMES.entrySet().stream()
                .map(e -> Map.of("code", e.getKey(), "name", e.getValue()))
                .toList();
    }
}

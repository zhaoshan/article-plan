package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.MembershipRoleMapper;
import com.unify.iam.authorization.infra.persistence.po.MembershipRolePO;
import com.unify.iam.common.util.IdGenerator;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Repository;

/**
 * 成员-角色绑定仓储（管理面授角色）。覆盖式替换（补缺+回收），DIRECT 授予。
 */
@Repository
public class MembershipRoleRepository {

    private final MembershipRoleMapper membershipRoleMapper;

    public MembershipRoleRepository(MembershipRoleMapper membershipRoleMapper) {
        this.membershipRoleMapper = membershipRoleMapper;
    }

    public List<MembershipRolePO> listByMembership(String membershipId) {
        return membershipRoleMapper.selectList(new LambdaQueryWrapper<MembershipRolePO>()
                .eq(MembershipRolePO::getMembershipId, membershipId));
    }

    /** 成员是否持有「租户管理能力」角色（G3 最后管理员保护）。 */
    public boolean membershipHasAdminCapability(String membershipId) {
        return membershipRoleMapper.countAdminCapableRolesByMembership(membershipId.trim()) > 0;
    }

    /** 某租户外、除指定成员外仍持「租户管理能力」的 ACTIVE 成员数>0（G3 触底判定）。 */
    public boolean tenantHasAnotherActiveAdmin(String tenantId, String excludeMembershipId) {
        return membershipRoleMapper.countAdminCapableMembersExcluding(tenantId.trim(), excludeMembershipId.trim()) > 0;
    }

    /** 角色是否具备「租户管理能力」（降权校验：新角色集含管理能力则不算降权，G3）。 */
    public boolean roleHasAdminCapability(String roleId) {
        return membershipRoleMapper.countAdminCapableByRole(roleId.trim()) > 0;
    }

    /** 某角色（租户内唯一）除指定成员外是否仍有 ACTIVE 持有者（G3 方式 B：is_owner 角色保护）。 */
    public boolean roleHasAnotherActiveHolder(String roleId, String excludeMembershipId) {
        return membershipRoleMapper.countActiveMembersByRoleExcluding(roleId.trim(), excludeMembershipId.trim()) > 0;
    }

    /** 持有某角色的成员关系 id 集（角色权限变更时批量 bump 令牌版本用，方案 c）。 */
    public List<String> findMembershipIdsByRole(String roleId) {
        return membershipRoleMapper.selectList(new LambdaQueryWrapper<MembershipRolePO>()
                        .eq(MembershipRolePO::getRoleId, roleId.trim()))
                .stream().map(MembershipRolePO::getMembershipId).toList();
    }

    /** 批量按 membership_id 集查（成员列表补角色用，避免 N+1，docs/user-manual 02 §1）。 */
    public List<MembershipRolePO> listByMemberships(Collection<String> membershipIds) {
        if (membershipIds == null || membershipIds.isEmpty()) {
            return List.of();
        }
        return membershipRoleMapper.selectList(new LambdaQueryWrapper<MembershipRolePO>()
                .in(MembershipRolePO::getMembershipId, membershipIds));
    }

    /** 覆盖式设置成员的 DIRECT 角色集合。 */
    public void replaceDirectRoles(String membershipId, Collection<String> roleIds) {
        String membershipIdT = membershipId.trim();
        List<MembershipRolePO> existing = membershipRoleMapper.selectList(
                new LambdaQueryWrapper<MembershipRolePO>().eq(MembershipRolePO::getMembershipId, membershipIdT));
        Set<String> existingRoleIds = existing.stream()
                .map(MembershipRolePO::getRoleId).collect(Collectors.toSet());
        Set<String> desired = roleIds.stream().map(String::trim).collect(Collectors.toSet());

        for (String roleId : desired) {
            if (existingRoleIds.contains(roleId)) {
                continue;
            }
            // 重授：软删后唯一键 (membership_id, role_id) 仍占位，先复活墓碑，无墓碑才新插
            if (membershipRoleMapper.revive(membershipIdT, roleId, "DIRECT") == 0) {
                MembershipRolePO po = new MembershipRolePO();
                po.setMembershipRoleId(IdGenerator.newBizId());
                po.setMembershipId(membershipIdT);
                po.setRoleId(roleId);
                po.setGrantSource("DIRECT");
                try {
                    membershipRoleMapper.insert(po);
                } catch (DuplicateKeyException ignored) {
                    // 并发兜底
                }
            }
        }
        // 回收：逻辑删除必须走 deleteById/delete（@TableLogic 字段会从 updateById 的 SET 剔除，
        // setDeleteFlag+updateById 是静默空操作——曾致撤权不生效，成员角色永远只增不减）
        for (MembershipRolePO po : existing) {
            if (!desired.contains(po.getRoleId())) {
                membershipRoleMapper.deleteById(po.getId());
            }
        }
    }
}

package com.unify.iam.app.oidc;

import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

/**
 * OIDC 登录临时态存储（内存，TTL 10 分钟；无 Redis，单实例可用）。
 *
 * <p>docs/03 §5.2：多实例部署需迁 Redis/DB。会话为一次性（take 后即删），防重放。
 */
@Component
public class OidcAuthSessionStore {

    private static final long TTL_MS = 600_000L; // 10 min

    private final ConcurrentHashMap<String, OidcAuthSession> sessions = new ConcurrentHashMap<>();

    public void put(String state, OidcAuthSession session) {
        sessions.put(state, session);
    }

    /** 取走并删除（一次性，防重放）；过期则返回 null。 */
    public OidcAuthSession take(String state) {
        expire();
        return state == null ? null : sessions.remove(state);
    }

    private void expire() {
        long now = System.currentTimeMillis();
        sessions.entrySet().removeIf(e -> now - e.getValue().createdAtMs() > TTL_MS);
    }

    public int size() {
        return sessions.size();
    }
}
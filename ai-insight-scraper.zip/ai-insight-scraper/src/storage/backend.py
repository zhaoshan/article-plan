"""数据存储抽象"""

from abc import ABC, abstractmethod
from pathlib import Path


class StorageBackend(ABC):
    """存储后端抽象基类"""

    @abstractmethod
    async def save(self, content: str, path: str | Path) -> str:
        """
        保存内容。

        Args:
            content: 文本内容
            path: 存储路径（相对于存储根目录）

        Returns:
            str: 完整存储路径
        """
        ...

    @abstractmethod
    async def load(self, path: str | Path) -> str:
        """
        加载内容。

        Args:
            path: 存储路径

        Returns:
            str: 文件内容
        """
        ...

    @abstractmethod
    def list_files(self, prefix: str = "") -> list[str]:
        """
        列出存储路径下的文件。

        Args:
            prefix: 路径前缀

        Returns:
            list[str]: 文件路径列表
        """
        ...

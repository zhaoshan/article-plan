package com.unify.iam.app.app.service;

import com.unify.iam.api.dto.auth.RegisterRequest;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.identity.common.constant.IdentityProviderType;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 注册（docs/04 §3.5）：建用户 + 本地身份 + 个人租户（Owner，架构 §7.1 场景 A）。
 *
 * <p>带 {@code app_codes} 时（从业务应用如 parlant 跳入注册）：把个人租户作为该应用的
 * 「个人工作台」，deep-copy 其预置角色并授 owner {@code is_owner} 角色——注册者即该应用管理员。
 */
@Service
public class RegisterService {

    private final UserRepository userRepository;
    private final UserIdentityRepository userIdentityRepository;
    private final PersonalTenantService personalTenantService;
    private final TenantAppProvisionService tenantAppProvisionService;

    public RegisterService(UserRepository userRepository,
                           UserIdentityRepository userIdentityRepository,
                           PersonalTenantService personalTenantService,
                           TenantAppProvisionService tenantAppProvisionService) {
        this.userRepository = userRepository;
        this.userIdentityRepository = userIdentityRepository;
        this.personalTenantService = personalTenantService;
        this.tenantAppProvisionService = tenantAppProvisionService;
    }

    @Transactional
    public String register(RegisterRequest request) {
        String username = request.username().trim();
        if (userRepository.findByUsername(username).isPresent()) {
            throw AuthException.badRequest("用户名已存在");
        }
        String email = request.email() == null ? null : request.email().trim().toLowerCase();
        if (email != null && userRepository.findByPrimaryEmail(email).isPresent()) {
            throw AuthException.badRequest("邮箱已被使用");
        }
        String userId = IdGenerator.newBizId();
        UserPO user = new UserPO();
        user.setUserId(userId);
        user.setUsername(username);
        user.setPrimaryEmail(email);
        user.setPasswordHash(BCryptUtils.hash(request.password()));
        user.setUserStatus("ACTIVE");
        user.setRegistrationSource("SELF_SERVICE");
        userRepository.create(user);

        UserIdentityPO identity = new UserIdentityPO();
        identity.setUserIdentityId(IdGenerator.newBizId());
        identity.setUserId(userId);
        identity.setProviderType(IdentityProviderType.LOCAL.name());
        identity.setProviderKey("password");
        identity.setSubject(username);
        identity.setLoginName(username);
        identity.setEmailAtIdp(email);
        identity.setIdentityStatus("ACTIVE");
        userIdentityRepository.create(identity);

        MembershipPO membership = personalTenantService.ensurePersonalTenantAndOwner(user);
        provisionApps(membership, request.appCodes());
        return userId;
    }

    /** 按 app_codes 给个人租户灌入应用模板角色 + owner 授 is_owner；未知应用忽略（不阻断注册）。 */
    private void provisionApps(MembershipPO membership, List<String> appCodes) {
        if (membership == null || appCodes == null || appCodes.isEmpty()) {
            return;
        }
        List<AppRoleTemplate> templates;
        try {
            templates = tenantAppProvisionService.loadForApps(appCodes);
        } catch (AuthException e) {
            // 未知/未启用应用：app 只是 onboarding 提示，忽略（不阻断注册）
            return;
        }
        String tenantId = membership.getTenantId().trim();
        tenantAppProvisionService.seedTemplates(tenantId, templates);
        tenantAppProvisionService.recordTenantApps(tenantId, appCodes);
        tenantAppProvisionService.grantOwnerRoles(membership.getMembershipId().trim(), tenantId, templates);
    }
}

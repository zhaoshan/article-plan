# 会话记录

## 2026-10-23：本地 MySQL 服务恢复

- 任务来源：用户明确要求恢复当前工作区已停止的 `platform-iam-service-mysql` 本地 MySQL 服务，并禁止不必要的代码或配置变更。
- 初始 Git 状态：`main...origin/main`，仅有既存的未跟踪 `.trellis/`；未修改任何已跟踪文件。
- 约束发现：当前工作区未找到 `AGENTS.md` 或 `.trellis/workflow.md`。已读取 `CLAUDE.md`，后续仅按其本地运行与 Git 规则执行。
- 容器检查：`platform-iam-service-mysql` 是当前项目既有 `mysql:8.0` 容器，持久化数据卷仍在；配置保留 `127.0.0.1:3306` 端口绑定、`unify_iam` 初始化数据库和健康检查。停止状态为 exit 137，但 Docker 标记 `OOMKilled=false`；日志显示先收到关闭信号，不能据此归因于数据库内部故障。
- 恢复动作：使用既有容器的正确恢复命令 `docker start platform-iam-service-mysql`。未重建容器、未更改其启动参数、端口、卷、环境变量或重启策略。
- 验证：容器状态为 `running`、health 为 `healthy`；MySQL 日志出现新的 `ready for connections`。宿主机 `127.0.0.1:3306` 由 Docker 监听，受控 TCP 探测成功；容器内经 TCP 的只读认证查询返回连接成功值并确认 `unify_iam` 数据库存在。

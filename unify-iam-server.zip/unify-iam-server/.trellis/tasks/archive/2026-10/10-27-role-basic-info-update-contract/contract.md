# Frontend role editor contract

This artifact is the backend contract for the role create/view/edit flow. It applies only to the current IAM service.

## Read and create

- `GET /api/v1/admin/roles?scope_type=TENANT&scope_id={tenantId}` requires `iam:role:read` and the existing target-scope guard. Each `data.roles[]` item includes `role_id`, `role_code`, `role_name`, `scope_type`, `scope_id`, and `role_status`; it includes `role_description` when that value is non-null. The global `non_null` setting omits the key for a null description.
- `POST /api/v1/admin/roles` is unchanged. It creates a role with required `role_code` and `role_name`, optional `role_description`, scope fields, and returns `data:{role_id}`.

## Update basic information

```http
PUT /api/v1/admin/roles/{roleId}
Authorization: Bearer <access token with iam:role:write>
Content-Type: application/json

{
  "role_name": "Support operator",
  "role_description": "Handles customer support workflows"
}
```

Successful response:

```json
{
  "success": true,
  "data": {"role_id": "r-..."}
}
```

The global `non_null` setting omits the null success `code` and `message` properties. `role_name` is required, nonblank, and at most 128 characters. `role_description` may be null and is at most 512 characters. Because this is a PUT replacement of the editable metadata, an omitted or null `role_description` clears the stored description. The server trims `role_name`; it otherwise preserves a supplied description.

`role_code` is not editable. It is a stable, scope-unique authorization-facing identifier that appears in JWT roles and is used by application-template/owner-role logic. Sending a non-null `role_code` to this route returns `400`; the frontend must display it read-only. `scope_type`, `scope_id`, `is_builtin`, and `role_status` are also not mutable on this route.

## Update permissions

```http
PUT /api/v1/admin/roles/{roleId}/permissions
Authorization: Bearer <access token with iam:role:write>
Content-Type: application/json

{"permission_ids": ["p-1001", "p-1003"]}
```

This existing endpoint remains the permission-save operation and returns `data:{role_id}`. Tenant-role grantability checks and holder token-version increments remain unchanged. The basic-info and permission writes are separate requests, not one atomic combined update.

## Errors and scope

- `401`: no valid Bearer token.
- `403`: caller lacks `iam:role:write`, targets another tenant's role without platform scope, or targets a platform role without platform-admin scope.
- `404`: target role does not exist.
- `400`: invalid basic-info input, an attempted `role_code` update, or the existing permission endpoint's invalid permission set.

Every response above uses the IAM standard `/api/v1/**` envelope with a real HTTP status. Successful basic-info edits create an `ADMIN_UPDATE_ROLE` audit event. Basic-info updates do not bump token versions because they do not change role codes or permissions.

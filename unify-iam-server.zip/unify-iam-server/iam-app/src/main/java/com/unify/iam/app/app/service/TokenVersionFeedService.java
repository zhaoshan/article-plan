package com.unify.iam.app.app.service;

import com.unify.iam.app.config.IamProperties;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.MembershipVersionLogPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.MembershipVersionLogRepository;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 版本 feed（方案 c 即时吊销，docs/07 §8.3；parlant doc11 附录 B 契约）。
 *
 * <p>{@code GET /api/v1/auth/versions?since=<cursor>&app_code=X}（服务间令牌鉴权）：
 * <ul>
 *   <li>since 缺省/0 → 全量快照：app 作用域租户的全部 ACTIVE 成员当前版本，cursor = 当前日志最大 id；</li>
 *   <li>since&gt;0 → 增量：id&gt;since 的版本变更，MEMBERSHIP_REMOVE 行 → version=-1（tombstone 哨兵，parlant 清缓存）；</li>
 *   <li>membership_id → 点查单个：活跃则当前版本，否则保守 tombstone（version=-1，删除/未知一律不信 token）。</li>
 * </ul>
 */
@Service
public class TokenVersionFeedService {

    /** tombstone 哨兵版本（成员已删/未知）：-1 永不自然出现（token_version 自 0 递增），
     *  且避开全局 NON_NULL 序列化丢弃 null——parlant 见 version<0 即拒。 */
    public static final int TOMBSTONE = -1;

    private final MembershipRepository membershipRepository;
    private final MembershipVersionLogRepository versionLogRepository;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final IamProperties props;

    public TokenVersionFeedService(MembershipRepository membershipRepository,
                                   MembershipVersionLogRepository versionLogRepository,
                                   TenantApplicationRepository tenantApplicationRepository,
                                   IamProperties props) {
        this.membershipRepository = membershipRepository;
        this.versionLogRepository = versionLogRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.props = props;
    }

    /** 服务端返回结构：{cursor, items:[{membership_id, version|null}]}。 */
    @Transactional(readOnly = true)
    public Map<String, Object> feed(String appCode, Long since, String membershipId) {
        List<String> tenantIds = tenantApplicationRepository.findTenantIdsByAppCode(appCode);
        if (membershipId != null && !membershipId.isBlank()) {
            return pointQuery(membershipId, tenantIds);
        }
        if (since == null || since <= 0) {
            return snapshot(tenantIds);
        }
        return delta(since, tenantIds);
    }

    private Map<String, Object> snapshot(List<String> tenantIds) {
        // 一致快照：先取日志游标再读成员（同一只读事务 REPEATABLE READ，两者同一快照，
        // 快照后发生的变更其日志 id > cursor，下一次增量必然补到）
        long cursor = versionLogRepository.maxId();
        List<Map<String, Object>> items = membershipRepository.listActiveByTenants(tenantIds).stream()
                .map(m -> item(m.getMembershipId(), m.getTokenVersion() == null ? 0 : m.getTokenVersion()))
                .toList();
        return result(cursor, items);
    }

    private Map<String, Object> delta(Long since, List<String> tenantIds) {
        List<MembershipVersionLogPO> rows = versionLogRepository.listAfter(since, tenantIds, props.getVersions().getFeedLimit());
        long cursor = since;
        List<Map<String, Object>> items = new ArrayList<>();
        for (MembershipVersionLogPO row : rows) {
            cursor = row.getId();
            boolean tombstone = "MEMBERSHIP_REMOVE".equals(row.getChangeType());
            items.add(item(row.getMembershipId(), tombstone ? TOMBSTONE : row.getTokenVersion()));
        }
        return result(cursor, items);
    }

    private Map<String, Object> pointQuery(String membershipId, List<String> tenantIds) {
        Optional<MembershipPO> m = membershipRepository.findById(membershipId.trim());
        if (m.isPresent() && tenantIds.contains(m.get().getTenantId().trim())
                && "ACTIVE".equals(m.get().getMembershipStatus())) {
            int version = m.get().getTokenVersion() == null ? 0 : m.get().getTokenVersion();
            return result(0L, List.of(item(m.get().getMembershipId(), version)));
        }
        // 删除/不在 app 作用域/未知 → 保守 tombstone：对该 membership 的一切 token 不予信任
        return result(0L, List.of(item(membershipId.trim(), TOMBSTONE)));
    }

    private Map<String, Object> item(String membershipId, Integer version) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("membership_id", membershipId);
        m.put("version", version); // -1 = tombstone（全局 NON_NULL 会丢 null，用哨兵显式表达）
        return m;
    }

    private Map<String, Object> result(long cursor, List<Map<String, Object>> items) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("cursor", cursor);
        r.put("items", items);
        return r;
    }
}

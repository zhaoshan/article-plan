package com.unify.iam.app.app.service;

import com.unify.iam.app.infra.persistence.po.AuditLogPO;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.app.security.RequestMeta;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import org.springframework.stereotype.Service;

/**
 * 审计服务（docs/04 §3.6）：管理面/认证/授权决策埋点到 gateway_audit_log。
 *
 * <p>提供 builder 式写审计：{@code audit().event("ROLE_GRANTED").actor(uid).target("USER", id).write(meta)}。
 * 粗粒度起步；后续可细到操作级。
 */
@Service
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    public AuditService(AuditLogRepository auditLogRepository) {
        this.auditLogRepository = auditLogRepository;
    }

    /** 开启一次审计写入（可链式填充）。 */
    public AuditEntry audit() {
        return new AuditEntry(auditLogRepository);
    }

    /** 一次性快捷写入。 */
    public void write(String eventType, String actorUserId, String targetType, String targetId,
                      String result, Map<String, Object> metadata) {
        audit().event(eventType).actor(actorUserId).target(targetType, targetId)
                .result(result).write(metadata);
    }

    /** 审计条目 builder（静态，便于测试构造）。 */
    public static class AuditEntry {
        private final AuditLogRepository repo;
        private String eventType;
        private String actorUserId;
        private String actorMembershipId;
        private String tenantId;
        private String targetType;
        private String targetId;
        private String result = "SUCCESS";
        private String traceId;
        private String requestId;
        private Object before;
        private Object after;

        public AuditEntry(AuditLogRepository repo) {
            this.repo = repo;
        }

        public AuditEntry event(String eventType) {
            this.eventType = eventType;
            return this;
        }

        public AuditEntry actor(String userId) {
            this.actorUserId = userId;
            return this;
        }

        public AuditEntry actor(String userId, String membershipId) {
            this.actorUserId = userId;
            this.actorMembershipId = membershipId;
            return this;
        }

        public AuditEntry target(String type, String id) {
            this.targetType = type;
            this.targetId = id;
            return this;
        }

        /** 目标租户（tenant 级操作填；平台级可空）。 */
        public AuditEntry tenant(String tenantId) {
            this.tenantId = tenantId;
            return this;
        }

        /** 变更前快照（JSON 序列化落 before_json）。 */
        public AuditEntry before(Object before) {
            this.before = before;
            return this;
        }

        /** 变更后快照（JSON 序列化落 after_json）。 */
        public AuditEntry after(Object after) {
            this.after = after;
            return this;
        }

        public AuditEntry result(String result) {
            this.result = result;
            return this;
        }

        public AuditEntry trace(String traceId) {
            this.traceId = traceId;
            return this;
        }

        /** 落库。 */
        public void write(Map<String, Object> metadata) {
            AuditLogPO po = new AuditLogPO();
            po.setAuditLogId(IdGenerator.newBizId());
            po.setEventType(eventType);
            po.setActorUserId(actorUserId);
            po.setActorMembershipId(actorMembershipId);
            po.setTargetType(targetType);
            po.setTargetId(targetId);
            po.setTenantId(tenantId);
            po.setResultStatus(result);
            po.setTraceId(traceId);
            po.setBeforeJson(before == null ? null : JsonUtils.toJson(before));
            po.setAfterJson(after == null ? null : JsonUtils.toJson(after));
            // 请求元信息自动补（G5-a）：request_id / ip / user_agent / actor membership
            po.setRequestId(requestId != null ? requestId : RequestMeta.requestId());
            po.setIpAddress(RequestMeta.ip());
            po.setUserAgent(RequestMeta.userAgent());
            if (po.getActorMembershipId() == null) {
                po.setActorMembershipId(RequestMeta.actorMembershipId());
            }
            po.setMetadataJson(metadata == null || metadata.isEmpty() ? null : JsonUtils.toJson(metadata));
            repo.insert(po);
        }
    }
}
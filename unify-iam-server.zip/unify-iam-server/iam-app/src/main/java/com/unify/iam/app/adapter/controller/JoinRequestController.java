package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.JoinRequestRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.app.service.JoinRequestService;
import com.unify.iam.app.security.JwtAuth;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import jakarta.validation.Valid;
import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 用户侧加入申请（docs/04 §3.4）：POST /api/v1/memberships/join-request（凭 Bearer 认证）。
 */
@RestController
@RequestMapping("/api/v1/memberships")
public class JoinRequestController {

    private final JwtSigner jwtSigner;
    private final JoinRequestService joinRequestService;
    private final UserRepository userRepository;

    public JoinRequestController(JwtSigner jwtSigner,
                                 JoinRequestService joinRequestService,
                                 UserRepository userRepository) {
        this.jwtSigner = jwtSigner;
        this.joinRequestService = joinRequestService;
        this.userRepository = userRepository;
    }

    @PostMapping("/join-request")
    public Map<String, String> request(@RequestHeader(value = "Authorization", required = false) String authorization,
                                       @Valid @RequestBody JoinRequestRequest request) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        String email = userRepository.findByUserId(claims.userId())
                .map(UserPO::getPrimaryEmail).orElse(claims.userId());
        String result = joinRequestService.request(claims.userId(), email, request.tenantId());
        return Map.of("status", result);
    }
}

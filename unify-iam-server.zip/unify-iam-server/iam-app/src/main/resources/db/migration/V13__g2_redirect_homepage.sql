-- G2 增强（前端极简）：accept 响应带 redirect_url——应用主页入库管理 + 邀请记录隐含应用参数
ALTER TABLE `iam_application`
  ADD COLUMN `homepage_url` VARCHAR(512) DEFAULT NULL COMMENT '应用主页地址（G2 增强：accept 后跳转目标；空 → yml iam.app-homepages.<code> → 邀请链接基址兜底）' AFTER `description`;

ALTER TABLE `gateway_invitation`
  ADD COLUMN `app_code` VARCHAR(64) DEFAULT NULL COMMENT '邀请隐含应用参数（G2 增强：缺省 iam.mail.invitation-default-app）' AFTER `default_role_id`;

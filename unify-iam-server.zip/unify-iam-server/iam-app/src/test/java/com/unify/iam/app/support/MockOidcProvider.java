package com.unify.iam.app.support;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jose.util.Base64URL;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;

/**
 * 测试用 Mock OIDC Provider：独立 JDK HttpServer（随机端口），模拟 IdP 侧（docs/03 §12.3 简化版）。
 *
 * <p>暴露 discovery / jwks / authorize / token；authorize 发一次性 code，token 校验 code_verifier（PKCE）
 * 后签发 RS256 ID Token（可配置 subject/email/groups/issuer/exp）。真实驱动 IAM 的 OidcAuthenticator 全链路。
 */
public class MockOidcProvider implements AutoCloseable {

    public static final String KID = "mock-idp-1";

    private final HttpServer server;
    private final int port;
    private final String baseUrl;
    private final RSAKey signingKey;
    private final Map<String, CodeRecord> codes = new ConcurrentHashMap<>();

    /** 当前模拟用户（测试在 authorize 前配置）。 */
    private volatile UserProfile user;
    private volatile long ttlSeconds = 3600;

    public MockOidcProvider() {
        try {
            this.signingKey = new RSAKeyGenerator(2048).keyID(KID).generate();
            this.port = 18000 + (int) (Math.random() * 2000); // 避免常用端口
            this.baseUrl = "http://127.0.0.1:" + port + "/oidc-test";
            this.user = new UserProfile("mock-sub", "mock@example.com", List.of());
            this.server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
            server.createContext("/oidc-test/", this::handle);
            server.setExecutor(Executors.newCachedThreadPool());
            server.start();
        } catch (Exception e) {
            throw new IllegalStateException("MockOidcProvider 启动失败", e);
        }
    }

    public static MockOidcProvider start() {
        return new MockOidcProvider();
    }

    public String baseUrl() {
        return baseUrl;
    }

    /** 配置在 discovery 中返回的 issuer（= baseUrl + "/oidc-test"）。 */
    public String issuer() {
        return baseUrl;
    }

    public String discoveryUrl() {
        return baseUrl + "/.well-known/openid-configuration";
    }

    public void configure(UserProfile user) {
        if (user != null) {
            this.user = user;
        }
    }

    public void setTtlSeconds(long ttlSeconds) {
        this.ttlSeconds = ttlSeconds;
    }

    /** 供测试断言用：issuer 是否与配置一致、生成的 ID token 等由 IAM 侧证伪。 */
    public UserProfile currentUser() {
        return user;
    }

    /** 直接签发 ID Token（OidcIdTokenVerifier 单元测试用，绕过 code 流）。 */
    public String issueIdToken(String nonce, String clientId) {
        return issueIdToken(nonce, clientId, Instant.now().getEpochSecond() + ttlSeconds);
    }

    public String issueIdToken(String nonce, String clientId, long expEpochSec) {
        long now = Instant.now().getEpochSecond();
        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .issuer(issuer())
                .audience(clientId)
                .subject(user.subject())
                .claim("email", user.email())
                .claim("groups", user.groups())
                .claim("nonce", nonce)
                .expirationTime(Date.from(Instant.ofEpochSecond(expEpochSec)))
                .issueTime(Date.from(Instant.ofEpochSecond(now)))
                .jwtID(UUID.randomUUID().toString())
                .build();
        try {
            SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(KID).build(), claimsSet);
            jwt.sign(new RSASSASigner(signingKey));
            return jwt.serialize();
        } catch (Exception e) {
            throw new IllegalStateException("签发 ID Token 失败", e);
        }
    }

    private void handle(HttpExchange exchange) throws IOException {
        try {
            String path = exchange.getRequestURI().getPath();
            if (path.endsWith("/.well-known/openid-configuration")) {
                respondJson(exchange, 200, discoveryJson());
            } else if (path.endsWith("/jwks")) {
                respondJson(exchange, 200, jwksJson());
            } else if (path.endsWith("/authorize")) {
                handleAuthorize(exchange);
            } else if (path.endsWith("/token")) {
                handleToken(exchange);
            } else {
                respond(exchange, 404, "not found");
            }
        } catch (Exception e) {
            respond(exchange, 500, "mock idp error: " + e.getMessage());
        } finally {
            exchange.close();
        }
    }

    private void handleAuthorize(HttpExchange exchange) throws IOException {
        Map<String, String> q = parseQuery(exchange.getRequestURI());
        String redirectUri = q.get("redirect_uri");
        String state = q.get("state");
        String code = UUID.randomUUID().toString().replace("-", "");
        codes.put(code, new CodeRecord(state, q.get("nonce"), q.get("code_challenge"), q.get("client_id")));
        if (redirectUri != null) {
            String loc = redirectUri + "?code=" + code + "&state=" + state;
            exchange.getResponseHeaders().set("Location", loc);
            exchange.sendResponseHeaders(302, -1);
        } else {
            // 测试便捷：直接返回 code
            respondJson(exchange, 200, "{\"code\":\"" + code + "\",\"state\":\"" + state + "\"}");
        }
    }

    private void handleToken(HttpExchange exchange) throws IOException {
        Map<String, String> form = parseForm(readBody(exchange));
        String code = form.get("code");
        CodeRecord rec = code == null ? null : codes.get(code);
        if (rec == null) {
            respondJson(exchange, 400, "{\"error\":\"invalid_grant\"}");
            return;
        }
        // PKCE code_verifier 校验
        String verifier = form.get("code_verifier");
        if (rec.codeChallenge() != null && !s256(verifier).equals(rec.codeChallenge())) {
            respondJson(exchange, 400, "{\"error\":\"invalid_grant\",\"description\":\"pkce\"}");
            return;
        }
        codes.remove(code);
        long now = Instant.now().getEpochSecond();
        String clientId = form.getOrDefault("client_id", rec.clientId());
        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .issuer(issuer())
                .audience(clientId)
                .subject(user.subject())
                .claim("email", user.email())
                .claim("groups", user.groups())
                .claim("nonce", rec.nonce())
                .expirationTime(Date.from(Instant.ofEpochSecond(now + ttlSeconds)))
                .issueTime(Date.from(Instant.ofEpochSecond(now)))
                .jwtID(UUID.randomUUID().toString())
                .build();
        String idToken;
        try {
            SignedJWT jwt = new SignedJWT(new JWSHeader.Builder(JWSAlgorithm.RS256).keyID(KID).build(), claimsSet);
            jwt.sign(new RSASSASigner(signingKey));
            idToken = jwt.serialize();
        } catch (Exception e) {
            respondJson(exchange, 500, "{\"error\":\"sign\"}");
            return;
        }
        respondJson(exchange, 200, "{\"id_token\":\"" + idToken + "\",\"token_type\":\"Bearer\"}");
    }

    private String discoveryJson() {
        return "{\"issuer\":\"" + issuer() + "\","
                + "\"authorization_endpoint\":\"" + baseUrl + "/authorize\","
                + "\"token_endpoint\":\"" + baseUrl + "/token\","
                + "\"jwks_uri\":\"" + baseUrl + "/jwks\","
                + "\"response_types_supported\":[\"code\"],"
                + "\"subject_types_supported\":[\"public\"],"
                + "\"id_token_signing_alg_values_supported\":[\"RS256\"]}";
    }

    private String jwksJson() {
        RSAKey pub = signingKey.toPublicJWK();
        Map<String, Object> jwk = new LinkedHashMap<>();
        jwk.put("kty", pub.getKeyType().getValue());
        jwk.put("kid", pub.getKeyID());
        jwk.put("n", pub.getModulus().toString());
        jwk.put("e", pub.getPublicExponent().toString());
        jwk.put("alg", "RS256");
        jwk.put("use", "sig");
        return "{\"keys\":[" + toJson(jwk) + "]}";
    }

    private void respondJson(HttpExchange exchange, int status, String body) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        respond(exchange, status, body);
    }

    private void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String readBody(HttpExchange exchange) throws IOException {
        return new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    private Map<String, String> parseQuery(URI uri) {
        String raw = uri.getRawQuery();
        Map<String, String> map = new LinkedHashMap<>();
        if (raw == null) {
            return map;
        }
        for (String pair : raw.split("&")) {
            int eq = pair.indexOf('=');
            if (eq < 0) {
                continue;
            }
            map.put(decode(pair.substring(0, eq)), decode(pair.substring(eq + 1)));
        }
        return map;
    }

    private Map<String, String> parseForm(String body) {
        Map<String, String> map = new LinkedHashMap<>();
        for (String pair : body.split("&")) {
            int eq = pair.indexOf('=');
            if (eq < 0) {
                continue;
            }
            map.put(decode(pair.substring(0, eq)), decode(pair.substring(eq + 1)));
        }
        return map;
    }

    private String decode(String s) {
        return URLDecoder.decode(s, StandardCharsets.UTF_8);
    }

    private String s256(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.US_ASCII));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private String toJson(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (var e : map.entrySet()) {
            if (!first) {
                sb.append(",");
            }
            first = false;
            sb.append("\"").append(e.getKey()).append("\":\"").append(e.getValue()).append("\"");
        }
        return sb.append("}").toString();
    }

    @Override
    public void close() {
        server.stop(0);
    }

    public record UserProfile(String subject, String email, List<String> groups) {
    }

    private record CodeRecord(String state, String nonce, String codeChallenge, String clientId) {
    }
}
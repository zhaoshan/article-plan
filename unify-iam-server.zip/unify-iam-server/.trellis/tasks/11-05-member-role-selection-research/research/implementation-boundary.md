# Latest implementation boundary and write compatibility

The latest user instruction approves the exact read API and Source work, explicitly superseding research-only scope. It does not approve any PLATFORM grant identity policy. Current active PRD/design/implementation plan supersede research/original-proposal.md; no can_assign/unavailable_reason policy is accepted or implemented.

## Final route
Existing controller routes include `/api`, not a server-global servlet context path. Thus `/v1/admin/tenant/roles` requested by the user is exposed as **GET `/api/v1/admin/tenant/roles?tenant_id=T`**. This is the singular tenant resource path, not `/tenants/{id}/roles` or `/members/role-options`. Member read permission plus target tenant scope guard; no requirement for unrelated role-management read permission.

## Source is already real
`iam-app/src/main/java/com/unify/iam/app/infra/persistence/mapper/TenantMemberQueryMapper.java:35` uses SELECT m.*, so persisted gateway_membership.join_source populates MembershipPO. `TenantMemberProjectionService.java:84-86` passes member.getJoinSource into TenantMemberSummary. `TenantMemberQueryService.java:112` emits join_source. Source should read this raw value; examples include OWNER, INVITE, ADMIN, SSO, SELF_REGISTER. It is not membership_role.grant_source. Added regression covers real distinct sources in tenant/global views and passthrough for the same user with separate membership records.

## Invitation blocker
`InvitationService.java:223-237,322-327`: issueForTenant checks an existing role is TENANT scoped to target. A custom PLATFORM candidate fails with DEFAULT_ROLE_TENANT_MISMATCH, HTTP400 / IAM-ROLE-011, even for a platform administrator. Invite POST uses singular role_id. Query support does not imply PLATFORM invite support. Existing explicit target-tenant non-Owner roles use this validation without requiring is_builtin=0. Omitted role_id triggers legacy Owner/admin defaults; frontend must not silently omit it during loading/errors.

## Member edit gap and identity risk
`AdminMemberService.java:130-143` checks membership target and existing last-admin/Owner rules, then replaces submitted roles. `MembershipRoleRepository.java:90-121` does not check role target/status or grant authority and removes absent bindings. Existing add similarly binds supplied role_ids at AdminMemberService.java:121-122. Therefore edit acceptance alone does not establish that the global grant was authorized.

`RoleMapper.java:17-21` counts any non-deleted PLATFORM binding as platform identity; TenantScopeGuard.java:26-45 trusts it for target scope bypass. Effective roles/permissions filter ACTIVE separately in AuthorizationQueryMapper.java:18-35, so disabling a role is not equivalent to removing this scope identity. Endpoint permissions still apply. Automatically accepting all new PLATFORM assignments would change who may act across tenants.

## Pending user decision
Should custom global roles deliberately confer platform administrator scope to their tenant holders, or should reusable global business roles have a separate authority model? Which actors may grant them? Neither question is answered by route approval. Do not silently permit elevation, reinterpret builtin/name as administrator identity, or invent frontend禁选. Approved query/Source work can be delivered; full invitation/Edit role global-write compatibility remains blocked and must be reported as incomplete.

## No production write/security changes
No invitation/default/acceptance, membership grant, platform scope guard, or permission-union implementation is changed in this task. Tests may exercise existing behavior in rollback transactions. This limits the change to the authorized read contract and avoids representing an unresolved security design as a small filter patch. Never advertise all returned roles as writable until that decision and shared server-side validation are implemented.

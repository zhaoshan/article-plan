package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 登录态改密请求（G2 首登强制改密）：{@code POST /api/v1/auth/change-password}。 */
public record ChangePasswordRequest(
        @NotBlank(message = "old_password 不能为空") @JsonProperty("old_password") String oldPassword,
        @NotBlank(message = "new_password 不能为空") @JsonProperty("new_password") String newPassword) {
}

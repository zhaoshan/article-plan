package com.unify.iam.app.adapter.controller;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.dto.auth.SwitchTenantRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.app.security.JwtAuth;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 多租户切换（docs/04 §3.4）：令牌仍单租户语义，切换 = 用目标 membership 重签。
 *
 * <p>位于 /api/v1/auth/**（不拦截），凭 Bearer 认证（JwtAuth 验签）。
 */
@RestController
@RequestMapping("/api/v1/auth")
public class SwitchTenantController {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SwitchTenantController.class);

    private final JwtSigner jwtSigner;
    private final TokenService tokenService;
    private final MembershipResolver membershipResolver;
    private final UserRepository userRepository;
    private final TenantRepository tenantRepository;
    private final com.unify.iam.app.app.service.MembershipMenuService membershipMenuService;

    public SwitchTenantController(JwtSigner jwtSigner,
                                  TokenService tokenService,
                                  MembershipResolver membershipResolver,
                                  UserRepository userRepository,
                                  TenantRepository tenantRepository,
                              com.unify.iam.app.app.service.MembershipMenuService membershipMenuService) {
        this.jwtSigner = jwtSigner;
        this.tokenService = tokenService;
        this.membershipResolver = membershipResolver;
        this.userRepository = userRepository;
        this.tenantRepository = tenantRepository;
        this.membershipMenuService = membershipMenuService;
    }

    /** 切换到目标租户（校验该 membership 属于当前用户），返回新 access + refresh。 */
    @PostMapping("/switch-tenant")
    public LoginResponse switchTenant(@RequestHeader(value = "Authorization", required = false) String authorization,
                                      @Valid @RequestBody SwitchTenantRequest request) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        String uid = claims.userId() == null ? "" : claims.userId().trim();
        // 2026-11-09：三条件拆分 + 分原因 WARN——原 filter 三合一，403 日志看不出是哪个条件失败
        // （偶发 "No permission to switch" 排查全靠猜）。客户端仍统一 403 防枚举，原因只落服务端日志。
        String mid = request.membershipId().trim();
        MembershipPO membership = membershipResolver.findById(mid).orElse(null);
        if (membership == null) {
            log.warn("tenant switch rejected | reason=MEMBERSHIP_NOT_FOUND（成员关系不存在或已逻辑删除——被移除/租户删除级联/孤儿级联）"
                    + " | userId={} | membershipId={}", uid, mid);
            throw AuthException.forbidden(ErrorCode.TENANT_SWITCH_FORBIDDEN);
        }
        String ownerId = membership.getUserId() == null ? "" : membership.getUserId().trim();
        if (!ownerId.equals(claims.userId())) {
            log.warn("tenant switch rejected | reason=MEMBERSHIP_NOT_OWNER（成员关系属于他人——前端传错 membership_id？）"
                    + " | userId={} | membershipId={} | membershipOwner={}", uid, mid, ownerId);
            throw AuthException.forbidden(ErrorCode.TENANT_SWITCH_FORBIDDEN);
        }
        String status = membership.getMembershipStatus();
        if (!"ACTIVE".equals(status)) {
            log.warn("tenant switch rejected | reason=MEMBERSHIP_NOT_ACTIVE（状态={}——SUSPENDED 被停用/PENDING 待加入未生效）"
                    + " | userId={} | membershipId={} | tenantId={}", status, uid, mid,
                    membership.getTenantId());
            throw AuthException.forbidden(ErrorCode.TENANT_SWITCH_FORBIDDEN);
        }
        // 租户必须仍存在且 ACTIVE（逻辑删除/停用的租户不可切换，防"已删仍可切换"）
        String tenantId = membership.getTenantId().trim();
        TenantPO tenant = tenantRepository.findById(tenantId).orElse(null);
        if (tenant == null) {
            log.warn("tenant switch rejected | reason=TENANT_NOT_FOUND（租户已逻辑删除） | userId={} | membershipId={} | tenantId={}",
                    uid, mid, tenantId);
            throw AuthException.forbidden(ErrorCode.TENANT_UNAVAILABLE);
        }
        if (!"ACTIVE".equals(tenant.getTenantStatus())) {
            log.warn("tenant switch rejected | reason=TENANT_NOT_ACTIVE（租户状态={}） | userId={} | membershipId={} | tenantId={}",
                    tenant.getTenantStatus(), uid, mid, tenantId);
            throw AuthException.forbidden(ErrorCode.TENANT_UNAVAILABLE);
        }
        UserPO user = userRepository.findByUserId(claims.userId())
                .orElseThrow(() -> AuthException.unauthorized(ErrorCode.USER_NOT_FOUND));
        return tokenService.issueWithRefresh(
                        new UserPrincipal(user.getUserId(), user.getUsername(), null), membership)
                .withMustChangePassword((user.getMustChangePassword() != null && user.getMustChangePassword() == 1));
    }

    /** 当前用户的成员列表，携带真实租户名称/编码；仅需 Bearer，不授予全局租户读取权限。 */
    @GetMapping("/memberships")
    public Map<String, Object> memberships(@RequestHeader(value = "Authorization", required = false) String authorization) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        // G9：菜单增强字段（tenant_type/roles/is_owner/is_current/last_opened_at/created_at）
        List<Map<String, Object>> list = membershipMenuService.listForMenu(claims.userId(), claims.membershipId());
        return Map.of("memberships", list, "count", list.size());
    }
}

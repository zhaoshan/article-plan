package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MvcResult;

/**
 * 多 audience（docs/user-manual 03 §2）：aud = 租户启用应用 ∩ 配置白名单；无应用记录存量租户回落配置全量。
 * 覆盖：单应用租户（字符串）、双应用租户（数组）、无应用记录租户（回落）。
 */
class MultiAudienceIntegrationTest extends IamIntegrationTestBase {

    @DynamicPropertySource
    static void audienceProps(DynamicPropertyRegistry registry) {
        // 与基类 datasourceProps 合并：接入第二个业务应用 ai-chat-insight
        registry.add("iam.jwt.audiences", () -> "parlant-agent-server,ai-chat-insight");
    }

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private List<String> audOf(String token) throws Exception {
        return SignedJWT.parse(token).getJWTClaimsSet().getAudience();
    }

    private String adminPost(String url, Object body) throws Exception {
        String token = login("admin", "admin123");
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    @Test
    void audReflectsTenantEnabledAppsAndFallsBack() throws Exception {
        // ① seed 租户 tenant-org-a 仅启用 parlant → aud 单元素
        assertThat(audOf(login("admin", "admin123")))
                .containsExactly("parlant-agent-server");

        // ② 双应用租户（先注册 ai-chat-insight 应用）→ aud 含两者
        jdbcTemplate.update("""
                INSERT IGNORE INTO iam_application
                  (app_id, app_code, app_name, app_status, description, delete_flag, create_by, update_by)
                VALUES ('app-aud-ai', 'ai-chat-insight', 'AI Chat Insight', 'ACTIVE', '多 audience 测试应用', 0, 'system', 'system')
                """);
        String user2 = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                Map.of("username", "aud_user2", "email", "aud2@unify.local", "password", "Passw0rd!")),
                Map.class).get("user_id").toString();
        adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "aud-t2", "tenant_name", "Aud T2", "tenant_type", "ORGANIZATION",
                        "app_codes", List.of("parlant-agent-server", "ai-chat-insight"),
                        "owner_user_id", user2));
        assertThat(audOf(login("aud_user2", "Passw0rd!")))
                .containsExactlyInAnyOrder("parlant-agent-server", "ai-chat-insight");

        // ③ 存量无应用记录租户（建后删 iam_tenant_application 行模拟）→ 回落配置全量
        String user3 = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                Map.of("username", "aud_user3", "email", "aud3@unify.local", "password", "Passw0rd!")),
                Map.class).get("user_id").toString();
        String tenantId = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "aud-t3", "tenant_name", "Aud T3", "tenant_type", "ORGANIZATION",
                        "app_codes", List.of("parlant-agent-server"), "owner_user_id", user3)),
                Map.class).get("tenant_id").toString();
        jdbcTemplate.update("DELETE FROM iam_tenant_application WHERE tenant_id = ?", tenantId);
        assertThat(audOf(login("aud_user3", "Passw0rd!")))
                .containsExactlyInAnyOrder("parlant-agent-server", "ai-chat-insight");
    }
}

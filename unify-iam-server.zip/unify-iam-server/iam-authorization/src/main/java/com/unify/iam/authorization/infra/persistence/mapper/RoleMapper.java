package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/** gateway_role Mapper。 */
@Mapper
public interface RoleMapper extends BaseMapper<RolePO> {

    /**
     * 某成员关系持有的平台级角色数（docs/06 §3.3 作用域判定）。
     * join gateway_membership_role → gateway_role，scope_type=PLATFORM 即平台管理员。
     */
    @Select("SELECT COUNT(*) FROM gateway_membership_role mr "
            + "JOIN gateway_role r ON mr.role_id = r.role_id "
            + "WHERE mr.membership_id = #{membershipId} "
            + "AND r.scope_type = 'PLATFORM' AND mr.delete_flag = 0 AND r.delete_flag = 0")
    int countPlatformRolesByMembership(@Param("membershipId") String membershipId);
}

package com.unify.iam.app.app.service;

import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.MembershipVersionLogRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 令牌版本管理（方案 c 即时吊销，docs/07 §8.3；parlant doc11 附录 B）。
 *
 * <p>任何影响成员权限的变更（角色/权限/移除）都 bump 该成员 {@code token_version}：
 * JWT 签发时带当前版本（ver），parlant 缓存 IAM 版本 feed 后，旧 token 的 ver 落后即被拒——
 * 把「权限变更生效延迟」从 TTL 级降到 feed 刷新间隔级。每次 bump 记入
 * {@link MembershipVersionLogRepository} 支撑增量 feed。
 */
@Service
public class TokenVersionService {

    private final MembershipRepository membershipRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final MembershipVersionLogRepository versionLogRepository;

    public TokenVersionService(MembershipRepository membershipRepository,
                               MembershipRoleRepository membershipRoleRepository,
                               MembershipVersionLogRepository versionLogRepository) {
        this.membershipRepository = membershipRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.versionLogRepository = versionLogRepository;
    }

    /** 单个成员版本 +1 并记日志（角色/权限变更）。 */
    @Transactional
    public void bump(String membershipId, String changeType) {
        MembershipPO before = membershipRepository.findById(membershipId)
                .orElseThrow(() -> AuthException.notFound("成员关系不存在"));
        if (membershipRepository.bumpTokenVersion(membershipId) == 0) {
            return; // 成员已删/不存在：无 token 可吊销，仅靠 tombstone
        }
        MembershipPO after = membershipRepository.findById(membershipId).orElseThrow();
        int version = after.getTokenVersion() == null ? 0 : after.getTokenVersion();
        versionLogRepository.record(membershipId, before.getTenantId(), version, changeType);
    }

    /** 某角色所有持有者批量 +1（角色权限变更影响全体，PERM_CHANGE）。 */
    @Transactional
    public void bumpForRoleHolders(String roleId, String changeType) {
        List<String> membershipIds = membershipRoleRepository.findMembershipIdsByRole(roleId);
        for (String membershipId : membershipIds) {
            bump(membershipId, changeType);
        }
    }

    /** 成员移除 → 记 tombstone（parlant 缓存清除该成员，旧 token 立即拒绝；不 bump 版本号）。 */
    @Transactional
    public void recordRemoval(String membershipId, String tenantId) {
        versionLogRepository.record(membershipId, tenantId, 0, "MEMBERSHIP_REMOVE");
    }

    /** 租户停用/删除 → 该租户全部 ACTIVE 成员批量 bump（G1：租户停用时已登录 token 即时失效）。 */
    @Transactional
    public void bumpForTenant(String tenantId, String changeType) {
        for (MembershipPO m : membershipRepository.listByTenant(tenantId)) {
            if ("ACTIVE".equals(m.getMembershipStatus())) {
                bump(m.getMembershipId(), changeType);
            }
        }
    }
}

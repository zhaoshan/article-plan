package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.JoinRequestService;
import com.unify.iam.app.infra.persistence.po.JoinRequestPO;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：加入申请审批（iam:member:write / read）。 */
@RestController
@RequestMapping("/api/v1/admin/join-requests")
public class AdminJoinRequestController {

    private final JoinRequestService joinRequestService;
    private final AuditService auditService;

    public AdminJoinRequestController(JoinRequestService joinRequestService, AuditService auditService) {
        this.joinRequestService = joinRequestService;
        this.auditService = auditService;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_MEMBER_READ)
    public Map<String, Object> list(@RequestParam(name = "tenant_id") String tenantId,
                                    @RequestParam(name = "status", required = false) String status) {
        List<Map<String, String>> list = joinRequestService.listByTenant(CurrentAuth.claims(), tenantId.trim(), status)
                .stream().map(this::toBrief).toList();
        return Map.of("join_requests", list, "count", list.size());
    }

    @PostMapping("/{id}/approve")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> approve(@PathVariable String id,
                                       @RequestBody(required = false) Map<String, String> body) {
        String roleId = body == null ? null : body.get("role_id");
        joinRequestService.approve(CurrentAuth.claims(), id, roleId);
        auditService.audit().event("ADMIN_APPROVE_JOIN").actor(CurrentAuth.claims().userId())
                .target("JOIN_REQUEST", id).result("SUCCESS").write(null);
        return Map.of("join_request_id", id, "status", "APPROVED");
    }

    @PostMapping("/{id}/reject")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> reject(@PathVariable String id,
                                      @RequestBody(required = false) Map<String, String> body) {
        String note = body == null ? null : body.get("review_note");
        joinRequestService.reject(CurrentAuth.claims(), id, note);
        auditService.audit().event("ADMIN_REJECT_JOIN").actor(CurrentAuth.claims().userId())
                .target("JOIN_REQUEST", id).write(note == null ? Map.of() : Map.of("review_note", note));
        return Map.of("join_request_id", id, "status", "REJECTED");
    }

    private Map<String, String> toBrief(JoinRequestPO po) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("join_request_id", po.getJoinRequestId());
        m.put("tenant_id", po.getTenantId());
        m.put("user_id", po.getUserId());
        m.put("email", po.getEmail());
        m.put("request_status", po.getRequestStatus());
        m.put("request_source", po.getRequestSource());
        return m;
    }
}

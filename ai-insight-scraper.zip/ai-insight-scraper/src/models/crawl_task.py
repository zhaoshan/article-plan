"""爬取任务模型（Pydantic V2）

定义任务进度和任务实体的数据结构。
与 src/database/models.py 中的 ORM 模型对应，通过 TaskRepository 进行转换。
"""

import uuid
from datetime import datetime

from pydantic import BaseModel, Field


class TaskProgress(BaseModel):
    """任务进度值对象"""

    pages_crawled: int = Field(default=0, ge=0, description="已爬取页面数")
    links_found: int = Field(default=0, ge=0, description="已发现链接数")


class CrawlTask(BaseModel):
    """爬取任务实体

    包含任务标识、分类、状态、请求参数、输出路径、进度和时间戳。
    """

    model_config = {"extra": "forbid"}

    # ── 标识与分类 ────────────────────────────────────
    task_id: str = Field(
        default_factory=lambda: str(uuid.uuid4()),
        description="任务 UUID",
    )
    task_type: str = Field(
        default="tree",
        description="任务类型: tree（静态全量链接爬取）/ dynamic（动态页面增量爬取）",
    )
    site: str = Field(
        default="",
        description="站点域名（如 tokyostarbank.co.jp）",
    )

    # ── 任务状态 ──────────────────────────────────────
    status: str = Field(
        default="pending",
        description="任务状态: pending / running / completed / failed",
    )

    # ── 请求参数 ──────────────────────────────────────
    target_url: str = Field(
        default="",
        description="爬取入口 URL",
    )
    max_depth: int | None = Field(
        default=None,
        ge=0,
        description="最大爬取深度（None=使用配置默认值）",
    )
    headless: bool = Field(
        default=True,
        description="是否无头模式运行浏览器",
    )
    output_type: str = Field(
        default="local",
        description="输出方式: local（本地文件）/ s3（S3 存储）",
    )
    schedule_id: str | None = Field(
        default=None,
        description="关联 crawl_schedules.schedule_id，周期性调度任务时填写",
    )

    # ── 输出文件路径 ──────────────────────────────────
    links_path: str | None = Field(
        default=None,
        description="all_unique_links_{ts}.json 文件路径",
    )
    tree_path: str | None = Field(
        default=None,
        description="tree_structure_{ts}.json 文件路径",
    )

    # ── 执行进度 ──────────────────────────────────────
    progress: TaskProgress = Field(
        default_factory=TaskProgress,
        description="任务进度",
    )

    # ── 错误信息 ──────────────────────────────────────
    error_message: str | None = Field(
        default=None,
        description="错误信息（失败时记录）",
    )

    # ── 时间戳 ────────────────────────────────────────
    create_time: datetime = Field(
        default_factory=datetime.now,
        description="添加时间",
    )
    update_time: datetime | None = Field(
        default=None,
        description="更新时间",
    )
    finished_at: datetime | None = Field(
        default=None,
        description="完成/失败时间",
    )

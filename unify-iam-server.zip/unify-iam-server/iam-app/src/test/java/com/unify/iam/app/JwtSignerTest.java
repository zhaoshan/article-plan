package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.RsaKeyManager;
import com.unify.iam.common.exception.AuthException;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class JwtSignerTest {

    @TempDir
    Path tempDir;

    private JwtSigner signer;
    private RsaKeyManager keyManager;

    @BeforeEach
    void setUp() throws Exception {
        IamProperties props = new IamProperties();
        props.getJwt().setPrivateKeyPath(tempDir.resolve("key.pem").toString());
        keyManager = new RsaKeyManager(props);
        keyManager.afterPropertiesSet();
        signer = new JwtSigner(keyManager);
    }

    private JwtClaims claims(long exp, long iat) {
        return new JwtClaims(
                "https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1001",
                "tenant-org-a", "ms-2001",
                List.of("AgentOperator"),
                List.of("agent:read", "agent:publish"),
                Map.of(),
                exp, iat, "jti-1", 0L);
    }

    @Test
    void signVerifyRoundTrip() {
        long now = Instant.now().getEpochSecond();
        String token = signer.sign(claims(now + 7200, now));

        assertThat(token).contains(".");
        JwtClaims parsed = signer.verify(token);
        assertThat(parsed.userId()).isEqualTo("u-1001");
        assertThat(parsed.tenantId()).isEqualTo("tenant-org-a");
        assertThat(parsed.membershipId()).isEqualTo("ms-2001");
        assertThat(parsed.roles()).containsExactly("AgentOperator");
        assertThat(parsed.permissions()).containsExactly("agent:read", "agent:publish");
        assertThat(parsed.attrs()).isEmpty();
        assertThat(parsed.aud()).isEqualTo(List.of("parlant-agent-server"));
        assertThat(parsed.jti()).isEqualTo("jti-1");
    }

    @Test
    void signedHeaderCarriesKid() throws Exception {
        long now = Instant.now().getEpochSecond();
        String token = signer.sign(claims(now + 7200, now));
        SignedJWT parsed = SignedJWT.parse(token);
        assertThat(parsed.getHeader().getAlgorithm().getName()).isEqualTo("RS256");
        assertThat(parsed.getHeader().getKeyID()).isEqualTo("iam-key-1");
    }

    @Test
    void singleAudienceSerializesAsStringForParllantCompat() throws Exception {
        // Nimbus 单元素 audience 序列化为字符串（非数组）——parlant PyJWT 字符串 audience 校验兼容（多应用时才为数组）
        long now = Instant.now().getEpochSecond();
        String token = signer.sign(claims(now + 7200, now));
        // Nimbus 内部把 aud 存为 List（getClaim("aud") 返回 List），序列化单元素仍收拢为字符串——断言看 JSON payload
        String payloadJson = SignedJWT.parse(token).getPayload().toString();
        assertThat(payloadJson).contains("\"aud\":\"parlant-agent-server\"");
        assertThat(payloadJson).doesNotContain("\"aud\":[\"parlant-agent-server\"]");
    }

    @Test
    void expiredTokenRejected() {
        long now = Instant.now().getEpochSecond();
        String token = signer.sign(claims(now - 10, now - 7300));

        assertThatThrownBy(() -> signer.verify(token))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessageContaining("过期");
    }

    @Test
    void missingExpRejected() {
        // 构造无 exp 的 token（自定义 claims 手动签名）
        long now = Instant.now().getEpochSecond();
        JwtClaims noExp = new JwtClaims("iss", List.of("aud"), "u", "t", "m",
                List.of(), List.of(), Map.of(), 0L, now, "jti", 0L);
        String token = signer.sign(noExp);
        assertThatThrownBy(() -> signer.verify(token))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
    }

    @Test
    void tamperedTokenRejected() {
        long now = Instant.now().getEpochSecond();
        String token = signer.sign(claims(now + 7200, now));
        String tampered = token.substring(0, token.length() - 2) + (token.endsWith("aa") ? "bb" : "zz");

        assertThatThrownBy(() -> signer.verify(tampered))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
    }

    @Test
    void malformedTokenRejected() {
        assertThatThrownBy(() -> signer.verify("not-a-jwt"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401));
    }
}

> Closed on 2026-11-04 before implementation. The user explicitly narrowed the request to frontend-only work: no backend logic or seed changes. All backend proposals below are withdrawn historical planning, not an approved or implemented API contract. No implementation approval is requested.

# Execution plan

## Entry gate
- [x] Read AGENTS.md, workflow and backend specs; inspect current source.
- [x] Confirm exact user identity codes and priority.
- [x] Prepare PRD, design, research and frontend contract.
- [ ] Obtain subsequent user approval of the final planning summary.
- [ ] Run task.py start only after approval; load trellis-before-dev.

## Ordered work
1. Introduce exact-role identity classifier and tests; wire persisted active membership/role verification for management access.
2. Add explicit handler identity policy, default-deny enforcement and classification coverage; preserve Bearer 401 and permission 403 envelopes.
3. Apply platform/B-side boundaries to all management handlers, including no-permission Owner transfer. Add the two reference endpoints described in design.md by reusing existing catalog/role projections.
4. Add B-side-only current-tenant guards and reject PLATFORM member queries. Validate member grant role IDs before binding, including foreign/PLATFORM roles.
5. Align repeatable templates and compensation with the identity matrix; document deployment replay and old-token behavior.
6. Update intentionally conflicting old tests. Add focused identity/policy/scope/grant regressions and full MySQL endpoint coverage for three identities and mixed roles.
7. Run trellis-check, applicable specs, test commands and git diff --check. Fix failures and update specs with the approved identity contract (including previous member/role contract changes).
8. Record final validation and session outcome under this task/current project's journal. Leave task code uncommitted and unarchived pending the user's workflow decision. Never commit/push/create worktrees or change branch.

## Verification commands
Use project JDK 21 where available; the shell currently resolves JDK 26 and `/usr/libexec/java_home` does not discover a runtime.
- `mvn -pl iam-app -am -DskipTests test-compile`
- Focused non-Docker tests: new identity/policy/grant contract tests plus impacted controller/service unit tests, with `-Dsurefire.failIfNoSpecifiedTests=false`.
- `mvn -pl iam-app -am test` with Docker/MySQL available; classify Testcontainers setup failure as blocked, never passed.
- `git diff --check` and `task.py validate .trellis/tasks/11-04-console-identity-isolation`.
- Recheck branch and all dirty paths. Tests requiring all previous platform member administration must be rewritten only where they contradict the approved requirements.

## Evidence at planning time
No product code changed and no product test suite run. Docker CLI exists but the sandbox cannot connect to `/Users/ramiro.li/.docker/run/docker.sock` (permission denied). Request only the necessary approval if an authorized integration run requires access after the planning gate. No automatic approval rejection has occurred.

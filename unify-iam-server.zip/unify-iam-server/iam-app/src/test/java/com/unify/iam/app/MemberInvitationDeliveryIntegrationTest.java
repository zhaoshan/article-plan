package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.mail.JavaMailEmailTool;
import com.unify.iam.app.support.MemberInvitationMailTestConfiguration;
import com.unify.iam.app.support.MemberInvitationTestMailSender;
import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.common.util.SecureToken;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MvcResult;

/**
 * 成员邀请「严格投递模式」集成测试（docs/08 §7，{@code iam.mail.delivery-enabled=true}）：
 * 四道闸前置 + 投递失败整事务回滚。用进程内测试 Sender 捕获邮件，绝不触达外部 SMTP。
 */
@Import(MemberInvitationDeliveryIntegrationTest.StrictMailConfiguration.class)
class MemberInvitationDeliveryIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private MemberInvitationTestMailSender mailSender;

    /**
     * 严格模式：运行时翻转开关（基类把 spring.mail.host 与 delivery-enabled 都钉死，
     * 同 key 动态属性子类覆盖不生效，故用 @BeforeEach 改 IamProperties）；
     * 投递器用 @Primary 的真实 {@link JavaMailEmailTool} 显式装配 host/from（口径与生产一致），
     * 测试 Sender（{@link MemberInvitationMailTestConfiguration}）顶替真实投递。
     */
    @org.springframework.beans.factory.annotation.Autowired
    private com.unify.iam.app.config.IamProperties iamProperties;

    @org.junit.jupiter.api.BeforeEach
    void enableStrictDelivery() {
        iamProperties.getMail().setDeliveryEnabled(true);
    }

    @org.junit.jupiter.api.AfterEach
    void resetStrictDelivery() {
        iamProperties.getMail().setDeliveryEnabled(false);
    }

    @TestConfiguration(proxyBeanMethods = false)
    @Import(MemberInvitationMailTestConfiguration.class)
    static class StrictMailConfiguration {
        @Bean
        @Primary
        JavaMailEmailTool strictJavaMailEmailTool(ObjectProvider<org.springframework.mail.javamail.JavaMailSender> senderProvider) {
            return new JavaMailEmailTool(senderProvider, "smtp.test.local", "iam-test@example.com");
        }
    }

    @AfterEach
    void resetMailSender() {
        mailSender.reset();
    }

    @Test
    void strictModeDeliversMailReturnsTokenAndPersistsInvitation() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String email = "member-delivery-" + suffix + "@example.test";
        String tenantName = jdbcTemplate.queryForObject(
                "SELECT tenant_name FROM gateway_tenant WHERE tenant_id='tenant-org-a'", String.class);

        MvcResult result = mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email, "tenant_id", "tenant-org-a"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.token").isNotEmpty())
                .andReturn();

        // 单形态契约：严格模式与 dev 模式响应一致（{token}），前端零分叉
        String token = unwrapData(result.getResponse().getContentAsString()).get("token").toString();
        // 邮件真投递（测试 Sender 捕获）：正文含接受链接与 token
        assertThat(mailSender.sentCount()).isEqualTo(1);
        assertThat(mailSender.latestHtmlFor(email)).contains(tenantName).contains(token);
        // 邀请落库：hash 与明文 token 对应
        assertThat(jdbcTemplate.queryForObject(
                "SELECT invite_token_hash FROM gateway_invitation WHERE email=?", String.class, email))
                .isEqualTo(SecureToken.hash(token));
        // JIT 新账号已建（严格模式沿用「邀请即建号 + 初始密码」语义）
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE username=?", Integer.class, email)).isEqualTo(1);
    }

    @Test
    void strictModeSenderFailureReturns503AndRollsBackEverything() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String email = "member-delivery-fail-" + suffix + "@example.test";
        mailSender.failNextSend();

        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email, "tenant_id", "tenant-org-a"))))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("Member invitation email delivery failed"));

        // 整事务回滚：邀请 / JIT 账号 / 受邀成员 全部不留
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email=?", Integer.class, email)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE username=?", Integer.class, email)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.username=? AND m.tenant_id='tenant-org-a'", Integer.class, email)).isZero();
        assertThat(mailSender.sentCount()).isZero();
    }

    @Test
    void strictModeTenantCreateOwnerEmailSenderFailureRollsBackTenantAndJitAccount() throws Exception {
        // 场景①表单模式（带 tenant_code/app_codes + owner_email）：SMTP 失败 → 503 且
        // 租户 / JIT 账号 / 受邀成员 / 邀请 全部回滚（AdminTenantService.create 统一闸门 + 事务回滚）
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String email = "tenant-owner-fail-" + suffix + "@example.test";
        mailSender.failNextSend();

        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_code", "tfail-" + suffix,
                                "tenant_name", "TFail " + suffix,
                                "app_codes", java.util.List.of("imorph"),
                                "owner_email", email))))
                .andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.message").value("Owner invitation email delivery failed"));

        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_tenant WHERE tenant_code=?", Integer.class, "tfail-" + suffix)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE username=?", Integer.class, email)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email=?", Integer.class, email)).isZero();
        assertThat(mailSender.sentCount()).isZero();
    }

    private String adminToken() throws Exception {
        MvcResult result = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(result.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }
}

package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.TenantApplicationMapper;
import com.unify.iam.authorization.infra.persistence.po.TenantApplicationPO;
import com.unify.iam.common.util.IdGenerator;
import java.util.List;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Repository;

/**
 * 租户启用应用仓储（docs/06 §2.3，m:n：一个租户可启用多个应用）。
 *
 * <p>{@code record} 采用「存在即恢复」：先原生 UPDATE 恢复（含逻辑删除的行），
 * 不存在才 insert——避免「软删后唯一键 uk(tenant_id, app_code) 占位导致重新启用失败」。
 */
@Repository
public class TenantApplicationRepository {

    private final TenantApplicationMapper tenantApplicationMapper;

    public TenantApplicationRepository(TenantApplicationMapper tenantApplicationMapper) {
        this.tenantApplicationMapper = tenantApplicationMapper;
    }

    /** 登记/恢复租户启用某应用（幂等：已存在则恢复启用，不存在则插入）。 */
    public void record(String tenantId, String appCode) {
        String tenantIdT = tenantId.trim();
        String appCodeT = appCode.trim();
        if (tenantApplicationMapper.restore(tenantIdT, appCodeT) > 0) {
            return;
        }
        TenantApplicationPO po = new TenantApplicationPO();
        po.setTenantAppId(IdGenerator.newBizId());
        po.setTenantId(tenantIdT);
        po.setAppCode(appCodeT);
        try {
            tenantApplicationMapper.insert(po);
        } catch (DuplicateKeyException ignored) {
            // 并发兜底：另一事务已插入
        }
    }

    public List<TenantApplicationPO> listByTenant(String tenantId) {
        return tenantApplicationMapper.selectList(new LambdaQueryWrapper<TenantApplicationPO>()
                .eq(TenantApplicationPO::getTenantId, tenantId.trim()));
    }

    /** 启用了某应用的租户 ID 集（登录页按应用管控「企业组织」下拉，docs/05 §7.1）。 */
    public List<String> findTenantIdsByAppCode(String appCode) {
        return tenantApplicationMapper.selectList(new LambdaQueryWrapper<TenantApplicationPO>()
                        .eq(TenantApplicationPO::getAppCode, appCode.trim()))
                .stream().map(TenantApplicationPO::getTenantId).map(String::trim).toList();
    }

    /** 某租户启用的应用 code 集（角色配置按应用隔离，V8 权限隔离）。 */
    public List<String> findAppCodesByTenant(String tenantId) {
        return tenantApplicationMapper.selectList(new LambdaQueryWrapper<TenantApplicationPO>()
                        .eq(TenantApplicationPO::getTenantId, tenantId.trim()))
                .stream().map(TenantApplicationPO::getAppCode).map(String::trim).toList();
    }
}

package com.unify.iam.app.app.service;

import com.unify.iam.api.dto.admin.CreateInvitationRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.app.service.JitLocalAccountService.ProvisionResult;
import com.unify.iam.app.app.service.QuotaService;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.infra.persistence.po.InvitationPO;
import com.unify.iam.app.infra.persistence.repository.InvitationRepository;
import com.unify.iam.app.mail.InvitationMailService;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.SecureToken;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 邀请（docs/04 §3.5 + G2 docs/08 §2.5）：管理员发邀请 → 受邀用户接受后建成员 + 默认角色。
 * 管理端发邀请限本租户（docs/06 §3.3）。
 *
 * <p>G2/G2 增强：按邮箱分支 JIT 建号 + 初始密码（首登强制改密）；发邀请邮件（§3 通道）；
 * 邀请盖隐含应用参数 {@code app_code}（默认 {@code iam.mail.invitation-default-app}）；
 * {@code role_id} 可选——**不传默认取当前租户 is_owner 模板角色**（产品口径）；
 * accept 返回 {@code redirect_url}（解析序：invitation.app_code → iam_application.homepage_url →
 * yml {@code iam.app-homepages.<code>} → 邀请链接基址兜底）。
 */
@Service
public class InvitationService {

    /** 邀请有效期（天）——产品口径待最终确认，现状 7 天（差距文档 §5 建议天级）。 */
    private static final int TTL_DAYS = 7;

    private final InvitationRepository invitationRepository;
    private final TenantRepository tenantRepository;
    private final UserRepository userRepository;
    private final MembershipRepository membershipRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final RoleRepository roleRepository;
    private final TenantScopeGuard tenantScopeGuard;
    private final JitLocalAccountService jitLocalAccountService;
    private final InvitationMailService invitationMailService;
    private final IamProperties props;
    private final QuotaService quotaService;
    private final ApplicationRepository applicationRepository;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final ApplicationRoleTemplateRepository applicationRoleTemplateRepository;

    public InvitationService(InvitationRepository invitationRepository,
                             TenantRepository tenantRepository,
                             UserRepository userRepository,
                             MembershipRepository membershipRepository,
                             MembershipRoleRepository membershipRoleRepository,
                             RoleRepository roleRepository,
                             TenantScopeGuard tenantScopeGuard,
                             JitLocalAccountService jitLocalAccountService,
                             InvitationMailService invitationMailService,
                             IamProperties props,
                             QuotaService quotaService,
                             ApplicationRepository applicationRepository,
                             TenantApplicationRepository tenantApplicationRepository,
                             ApplicationRoleTemplateRepository applicationRoleTemplateRepository) {
        this.invitationRepository = invitationRepository;
        this.tenantRepository = tenantRepository;
        this.userRepository = userRepository;
        this.membershipRepository = membershipRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.roleRepository = roleRepository;
        this.tenantScopeGuard = tenantScopeGuard;
        this.jitLocalAccountService = jitLocalAccountService;
        this.invitationMailService = invitationMailService;
        this.props = props;
        this.quotaService = quotaService;
        this.applicationRepository = applicationRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.applicationRoleTemplateRepository = applicationRoleTemplateRepository;
    }

    /** 邀请签发结果（Owner 邮箱开通流程复用）；roleId = 生效角色（含 is_owner 默认值）。 */
    public record Issued(String token, LocalDateTime expiresAt, String roleId) {
    }

    /**
     * 管理员发邀请（管理面）：租户级作用域校验 + 开通分支 + 发信。dev 返回令牌；生产走邮件。
     *
     * <p>语义（产品口径 2026-10-26）：**新 JIT 账号**（邮箱不存在）→ 建号 + 直接建受邀租户成员
     * （is_default=1，无个人租户）+ 按生效角色绑定——否则新账号无任何成员关系，登录 401 死锁；
     * accept 幂等（标记 ACCEPTED + redirect_url）。**已有账号** → 不动成员，accept 时才建成员+绑角色。
     */
    @Transactional
    public Map<String, String> create(JwtClaims claims, CreateInvitationRequest request) {
        tenantScopeGuard.assertTenantScope(claims, request.tenantId());
        quotaService.assertMemberSeat(request.tenantId()); // G1：席位强制（限额 − 在册 − 待接受 < 1 → 400）
        String email = request.email().trim().toLowerCase();
        Issued issued = issueForTenant(request.tenantId().trim(), email,
                request.roleId() == null ? null : request.roleId().trim());
        ProvisionResult provisioned = jitLocalAccountService.provisionIfAbsent(email);
        if (provisioned.created()) {
            createInvitedMembership(request.tenantId().trim(), provisioned.userId(), issued.roleId());
        }
        String tenantName = tenantRepository.findById(request.tenantId().trim())
                .orElseThrow(() -> AuthException.notFound("租户不存在")).getTenantName();
        // 模板按生效角色分派：is_owner 角色（含不传走默认）→ Owner 模板；其余 → Member/Admin 模板
        if (issued.roleId() != null && isOwnerRole(request.tenantId().trim(), issued.roleId())) {
            invitationMailService.sendOwnerInvitation(email, tenantName,
                    provisioned.initialPassword(), issued.expiresAt(), issued.token());
        } else {
            invitationMailService.sendMemberInvitation(email, tenantName, roleName(issued.roleId()),
                    provisioned.initialPassword(), issued.expiresAt(), issued.token());
        }
        return Map.of("token", issued.token()); // dev：直接返回（生产走邮件，不暴露）
    }

    /** 生效角色是否 is_owner 模板角色（角色 code 命中租户启用应用的 is_owner 模板，G3 方式 B 同口径）。 */
    private boolean isOwnerRole(String tenantId, String roleId) {
        return roleRepository.findById(roleId.trim())
                .map(r -> r.getRoleCode() == null ? false
                        : applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                                tenantApplicationRepository.findAppCodesByTenant(tenantId))
                        .contains(r.getRoleCode().trim()))
                .orElse(false);
    }

    /** 新 JIT 账号的受邀租户成员（join_source=INVITE，is_default=1）+ 生效角色绑定。 */
    private void createInvitedMembership(String tenantId, String userId, String roleId) {
        if (membershipRepository.findByTenantAndUser(tenantId, userId).isPresent()) {
            return;
        }
        membershipRepository.clearDefault(userId); // 防御：保证恰一个默认
        MembershipPO m = new MembershipPO();
        m.setMembershipId(IdGenerator.newBizId());
        m.setTenantId(tenantId);
        m.setUserId(userId);
        m.setMembershipStatus("ACTIVE");
        m.setJoinSource("INVITE");
        m.setIsDefault(1);
        membershipRepository.create(m);
        if (roleId != null) {
            membershipRoleRepository.replaceDirectRoles(m.getMembershipId(), List.of(roleId));
        }
    }

    /**
     * 签发邀请（G2 供 Owner 邮箱开通复用；调用方已做权限/作用域校验）。
     * 校验租户与角色归属，生成一次性令牌（哈希落库，7 天）。
     * {@code roleId} 为空 → 默认取当前租户 is_owner 模板角色；{@code appCode} 缺省默认应用。
     */
    @Transactional
    public Issued issueForTenant(String tenantId, String email, String roleId) {
        String tid = tenantId.trim();
        tenantRepository.findById(tid).orElseThrow(() -> AuthException.notFound("租户不存在"));
        String effectiveRoleId = (roleId == null || roleId.isBlank()) ? defaultOwnerRoleId(tid) : roleId.trim();
        if (effectiveRoleId != null) {
            assertRoleInTenant(tid, effectiveRoleId);
        }
        String plain = SecureToken.random();
        InvitationPO po = new InvitationPO();
        po.setInvitationId(IdGenerator.newBizId());
        po.setTenantId(tid);
        po.setEmail(email.trim().toLowerCase());
        po.setInviteType("EMAIL");
        po.setInvitationStatus("PENDING");
        po.setInviteTokenHash(SecureToken.hash(plain));
        po.setDefaultRoleId(effectiveRoleId);
        po.setAppCode(props.getMail().getInvitationDefaultApp());
        po.setExpiresAt(LocalDateTime.now().plusDays(TTL_DAYS));
        invitationRepository.insert(po);
        return new Issued(plain, po.getExpiresAt(), effectiveRoleId);
    }

    /** 当前租户 is_owner 模板角色 id（产品口径：role_id 不传时的默认值；无 is_owner 模板 → null）。 */
    private String defaultOwnerRoleId(String tenantId) {
        Set<String> ownerCodes = new HashSet<>(applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                tenantApplicationRepository.findAppCodesByTenant(tenantId)));
        if (ownerCodes.isEmpty()) {
            return null;
        }
        return roleRepository.listByScope("TENANT", tenantId).stream()
                .filter(r -> r.getRoleCode() != null && ownerCodes.contains(r.getRoleCode().trim()))
                .map(r -> r.getRoleId().trim())
                .findFirst()
                .orElse(null);
    }

    /** 默认角色必须属于目标租户（TENANT 作用域 + 该租户），防存无效/他租户角色 id。 */
    private void assertRoleInTenant(String tenantId, String roleId) {
        RolePO role = roleRepository.findById(roleId)
                .orElseThrow(() -> AuthException.badRequest("默认角色不存在"));
        if (!"TENANT".equals(role.getScopeType()) || !tenantId.equals(role.getScopeId())) {
            throw AuthException.badRequest("默认角色必须属于该租户");
        }
    }

    /** 邀请预设角色名（邮件 {{role}} 展示；空 → Member）。 */
    private String roleName(String roleId) {
        if (roleId == null || roleId.isBlank()) {
            return "Member";
        }
        return roleRepository.findById(roleId.trim())
                .map(r -> r.getRoleName() == null || r.getRoleName().isBlank() ? r.getRoleCode() : r.getRoleName())
                .orElse("Member");
    }

    /**
     * 受邀用户（已登录、邮箱匹配）接受邀请 → 无成员则建成员 + 默认角色（幂等：已有成员不动）。
     *
     * @return accept 后跳转地址（G2 增强 redirect_url；解析序见类注释）
     */
    @Transactional
    public String accept(String token, String userId) {
        InvitationPO invitation = invitationRepository.findByHashPending(SecureToken.hash(token))
                .orElseThrow(() -> AuthException.unauthorized("邀请无效或已过期"));
        UserPO user = userRepository.findByUserId(userId)
                .orElseThrow(() -> AuthException.unauthorized("用户不存在"));
        if (invitation.getEmail() == null
                || !invitation.getEmail().equalsIgnoreCase(user.getPrimaryEmail() == null ? "" : user.getPrimaryEmail())) {
            throw AuthException.forbidden("邀请邮箱与当前账号不符");
        }
        String tenantId = invitation.getTenantId();
        if (membershipRepository.findByTenantAndUser(tenantId, userId).isEmpty()) {
            MembershipPO m = new MembershipPO();
            m.setMembershipId(IdGenerator.newBizId());
            m.setTenantId(tenantId);
            m.setUserId(userId);
            m.setMembershipStatus("ACTIVE");
            m.setJoinSource("INVITE");
            m.setIsDefault(0);
            membershipRepository.create(m);
            if (invitation.getDefaultRoleId() != null) {
                membershipRoleRepository.replaceDirectRoles(m.getMembershipId(), List.of(invitation.getDefaultRoleId()));
            }
        }
        invitation.setInvitationStatus("ACCEPTED");
        invitation.setAcceptedByUserId(userId);
        invitation.setAcceptedAt(LocalDateTime.now());
        invitationRepository.update(invitation);
        return resolveHomepage(invitation.getAppCode());
    }

    /** redirect_url 解析：invitation.app_code → iam_application.homepage_url → yml iam.app-homepages → 链接基址兜底。 */
    private String resolveHomepage(String appCode) {
        if (appCode != null && !appCode.isBlank()) {
            String code = appCode.trim();
            String db = applicationRepository.findActiveByCodes(List.of(code)).stream()
                    .findFirst()
                    .map(ApplicationPO::getHomepageUrl)
                    .filter(h -> h != null && !h.isBlank())
                    .map(String::trim)
                    .orElse(null);
            if (db != null) {
                return db;
            }
            String yml = props.getAppHomepages().get(code);
            if (yml != null && !yml.isBlank()) {
                return yml.trim();
            }
        }
        return props.getMail().getInvitationLinkBaseUrl();
    }
}

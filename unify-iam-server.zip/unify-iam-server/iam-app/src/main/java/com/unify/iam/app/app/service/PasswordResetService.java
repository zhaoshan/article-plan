package com.unify.iam.app.app.service;

import com.unify.iam.app.infra.persistence.po.PasswordResetTokenPO;
import com.unify.iam.app.infra.persistence.repository.PasswordResetTokenRepository;
import com.unify.iam.app.infra.persistence.repository.RefreshTokenRepository;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.mail.InvitationMailService;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.SecureToken;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 密码找回（docs/04 §3.5）：forgot 生成一次性重置令牌（同邮箱仅最新有效）；reset 改密 + 撤销旧 refresh。
 *
 * <p>dev 无邮件网关：forgot 直接在响应返回 token（生产改为邮件发送，不在响应暴露）。
 */
@Service
public class PasswordResetService {

    private static final int TTL_MINUTES = 15;

    private final UserRepository userRepository;
    private final PasswordResetTokenRepository tokenRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final UserIdentityRepository userIdentityRepository;
    private final InvitationMailService invitationMailService;
    private final IamProperties props;

    public PasswordResetService(UserRepository userRepository,
                                PasswordResetTokenRepository tokenRepository,
                                RefreshTokenRepository refreshTokenRepository,
                                UserIdentityRepository userIdentityRepository,
                                InvitationMailService invitationMailService,
                                IamProperties props) {
        this.userRepository = userRepository;
        this.tokenRepository = tokenRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.userIdentityRepository = userIdentityRepository;
        this.invitationMailService = invitationMailService;
        this.props = props;
    }

    /** 发起找回：邮箱存在则生成 token（dev 返回 token；防枚举：不存在也返回通用提示）。 */
    @Transactional
    public Map<String, String> forgot(String email) {
        String em = email.trim().toLowerCase();
        Optional<UserPO> user = userRepository.findByPrimaryEmail(em);
        if (user.isEmpty()) {
            return Map.of("detail", "如邮箱存在，已发送重置链接"); // 防枚举
        }
        tokenRepository.invalidateByEmail(em); // 旧 token 全部失效
        String plain = SecureToken.random();
        PasswordResetTokenPO po = new PasswordResetTokenPO();
        po.setPasswordResetTokenId(IdGenerator.newBizId());
        po.setUserId(user.get().getUserId());
        po.setEmail(em);
        po.setTokenHash(SecureToken.hash(plain));
        po.setExpiresAt(LocalDateTime.now().plusMinutes(TTL_MINUTES));
        po.setIsLatest(1);
        tokenRepository.insert(po);
        // docs/08 §2.1②：发送重置邮件（模板 templates/reset-password-email.html，链接指前端 /reset-password?token=）；
        // SSO-only 账号（无 LOCAL 身份）不发——无密码可重置，统一防枚举文案不暴露账号类型
        boolean hasLocal = userIdentityRepository.findLocalActive(user.get().getUserId().trim()).isPresent();
        if (hasLocal) {
            String base = props.getMail().getInvitationLinkBaseUrl().replaceAll("/+$", "");
            invitationMailService.sendPasswordReset(em, base + "/reset-password?token=" + plain);
        }
        return Map.of("token", plain); // dev：直接返回（生产走邮件，不暴露）
    }

    /** 重置密码：校验令牌 → 改密 → 标记使用 → 撤销该用户所有 refresh。 */
    @Transactional
    public void reset(String token, String newPassword) {
        PasswordResetTokenPO po = tokenRepository.findByHashLatestActive(SecureToken.hash(token))
                .orElseThrow(() -> AuthException.unauthorized("重置链接无效或已过期"));
        UserPO user = userRepository.findByUserId(po.getUserId())
                .orElseThrow(() -> AuthException.unauthorized("用户不存在"));
        user.setPasswordHash(BCryptUtils.hash(newPassword));
        userRepository.update(user);
        tokenRepository.markUsed(po.getId());
        refreshTokenRepository.revokeByUser(po.getUserId()); // 改密后旧会话失效
    }
}

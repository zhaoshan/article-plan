package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.unify.iam.app.app.service.admin.AdminAuditService;
import com.unify.iam.app.infra.persistence.repository.AuditLogFilter;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;

/** Focused parameter parsing checks without a database. SQL/permissions have existing integration coverage. */
class AdminAuditTimeContractTest {
    private final AuditLogRepository audits = mock(AuditLogRepository.class);
    private final AdminAuditService service = new AdminAuditService(audits, mock(UserRepository.class),
            mock(TenantRepository.class), mock(MembershipRepository.class), mock(RoleRepository.class));

    @ParameterizedTest
    @CsvSource({
            "2026-11-03T16:00:00Z, 2026-11-04T16:00:00Z, 2026-11-03T16:00, 2026-11-04T16:00",
            "2026-11-04T00:00:00+08:00, 2026-11-05T00:00:00+08:00, 2026-11-03T16:00, 2026-11-04T16:00",
            "2026-11-04, 2026-11-04, 2026-11-03T16:00, 2026-11-04T16:00",
            "2026-11-04T00:00:00, 2026-11-05T00:00:00, 2026-11-03T16:00, 2026-11-04T16:00",
            "2026-11-03T16:00:00Z, '', 2026-11-03T16:00,",
            ", 2026-11-04T16:00:00Z,, 2026-11-04T16:00",
            "'', '',,"
    })
    void normalizesUtcOffsetsAndLegacyValuesWithOptionalBounds(String start, String end,
                                                               String expectedStart, String expectedEnd) {
        search(start, end);
        var filter = ArgumentCaptor.forClass(AuditLogFilter.class);
        verify(audits).count(filter.capture());
        verify(audits).list(filter.getValue());
        assertThat(filter.getValue().getStartTime()).isEqualTo(time(expectedStart));
        assertThat(filter.getValue().getEndTime()).isEqualTo(time(expectedEnd));
    }

    @ParameterizedTest
    @CsvSource({"not-a-time,", ",2026-02-30", "2026-11-04T00:00:00+25:00,", ",+999999999-12-31"})
    void malformedBoundsReturnExistingClientError(String start, String end) {
        assertThatThrownBy(() -> search(start, end)).isInstanceOfSatisfying(AuthException.class, error -> {
            assertThat(error.getHttpStatus()).isEqualTo(400);
            assertThat(error.getCode()).isEqualTo("IAM-VALID-010");
        });
        verifyNoInteractions(audits);
    }

    @Test
    void comparesOrderingAfterOffsetNormalization() {
        for (String end : List.of("2026-11-04T08:00:00+08:00", "2026-11-04T07:59:59+08:00")) {
            assertThatThrownBy(() -> search("2026-11-04T00:00:00Z", end))
                    .isInstanceOfSatisfying(AuthException.class, error -> {
                        assertThat(error.getHttpStatus()).isEqualTo(400);
                        assertThat(error.getCode()).isEqualTo("IAM-VALID-002");
                    });
        }
        verifyNoInteractions(audits);
    }

    private LocalDateTime time(String value) {
        return value == null ? null : LocalDateTime.parse(value);
    }

    private void search(String start, String end) {
        service.search(null, List.of(), null, null, null, start, end, 1, 20);
    }
}

"""页面内容爬取配置解析

从 config/content_crawl_config.json 按域名查找配置，未找到时返回默认值。
结构镜像 traversal_config.py。
"""

from pathlib import Path

from src.config.provider import FileConfigProvider
from src.models.content_crawl_config import ContentCrawlConfig


def load_content_crawl_config(
    domain: str,
    config_dir: str | Path | None = None,
) -> ContentCrawlConfig:
    """
    按域名查找页面内容爬取配置。

    从 config_dir/content_crawl_config.json 中查找 domain 对应的配置，
    未找到时返回默认的 ContentCrawlConfig（空 exclude_tags）。

    Args:
        domain: 域名（如 'tokyostarbank.co.jp'）
        config_dir: 配置文件目录，默认为项目根目录下的 config/

    Returns:
        ContentCrawlConfig: 该站点的页面内容爬取配置
    """
    if config_dir is None:
        # 默认使用项目根目录下的 config/ 目录
        config_dir = Path(__file__).resolve().parent.parent.parent / "config"

    provider = FileConfigProvider(Path(config_dir))
    all_configs = provider.load_json("content_crawl_config.json")

    # 按域名精确匹配，未找到返回默认空配置
    domain_config = all_configs.get(domain, {})

    return ContentCrawlConfig.model_validate(domain_config)

package com.unify.iam.app.config;

import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.BizException;
import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.common.result.CommonResponse;
import com.unify.iam.common.result.ResultCode;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/**
 * 全局异常处理（信封，docs/user-manual/05）：
 *
 * <ul>
 *   <li>{@link EnvelopePaths} 作用域内路径 → 真实 HTTP 状态 + {@code CommonResponse} 信封
 *       （{@code {success:false, code, message, data:null}}）；</li>
 *   <li>作用域外（OIDC 重定向流程 / 非 API）→ 真实 HTTP 状态 + {@code {"detail": msg}}；</li>
 *   <li>未捕获异常 → 500 + 相应形态的失败体。</li>
 * </ul>
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(AuthException.class)
    public ResponseEntity<?> handleAuth(AuthException e) {
        // 2026-11-03 错误目录契约：细粒度码优先，未带码的旧式异常回落类目码
        // 2026-11-05 失败日志（分层②）：4xx 业务拒绝 WARN（预期内，无需堆栈）——requestId 由 MDC 自动带入
        String code = e.getCode() != null ? e.getCode() : ResultCode.AUTH_ERROR;
        if (e.getHttpStatus() < 500) {
            log.warn("request rejected | status={} | code={} | msg={}", e.getHttpStatus(), code, e.getMessage());
        } else {
            log.error("dependency failure | status={} | code={} | msg={}", e.getHttpStatus(), code, e.getMessage(), e);
        }
        return error(e.getHttpStatus(), code, e.getMessage());
    }

    /** 参数校验失败：取首个字段错误明细（bean validation 文案，英文），错误码走目录。 */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidation(MethodArgumentNotValidException e) {
        String detail = e.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(fe -> fe.getDefaultMessage() != null ? fe.getDefaultMessage() : "invalid value")
                .orElse("invalid value");
        return error(HttpStatus.BAD_REQUEST.value(), ErrorCode.REQUEST_VALIDATION_FAILED.code(),
                ErrorCode.REQUEST_VALIDATION_FAILED.format(detail));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<?> handleUnreadable(HttpMessageNotReadableException e) {
        return error(HttpStatus.BAD_REQUEST.value(), ErrorCode.REQUEST_BODY_UNREADABLE.code(),
                ErrorCode.REQUEST_BODY_UNREADABLE.message());
    }

    /** 查询参数缺失或类型不符属于客户端输入错误，不能落入 500 兜底。 */
    @ExceptionHandler({MissingServletRequestParameterException.class, MethodArgumentTypeMismatchException.class})
    public ResponseEntity<?> handleQueryParameter(Exception e) {
        return error(HttpStatus.BAD_REQUEST.value(), ErrorCode.INVALID_QUERY_PARAMETER.code(),
                ErrorCode.INVALID_QUERY_PARAMETER.message());
    }

    /** 缺失的静态资源（如不存在的路由、Chrome DevTools 探测 /.well-known/...）→ 404，而非 500。 */
    @ExceptionHandler(org.springframework.web.servlet.resource.NoResourceFoundException.class)
    public ResponseEntity<?> handleNoResource(org.springframework.web.servlet.resource.NoResourceFoundException e) {
        return error(HttpStatus.NOT_FOUND.value(), ErrorCode.RESOURCE_NOT_FOUND.code(),
                ErrorCode.RESOURCE_NOT_FOUND.message());
    }

    @ExceptionHandler(BizException.class)
    public ResponseEntity<CommonResponse<Void>> handleBiz(BizException e) {
        HttpStatus status = e.getHttpStatus() == 200 ? HttpStatus.OK : HttpStatus.valueOf(e.getHttpStatus());
        return ResponseEntity.status(status).body(CommonResponse.fail(e.getCode(), e.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleOther(Exception e) {
        log.error("未捕获异常", e);
        return error(HttpStatus.INTERNAL_SERVER_ERROR.value(), ErrorCode.INTERNAL_ERROR.code(),
                ErrorCode.INTERNAL_ERROR.message());
    }

    /** 按请求路径输出信封或 detail 失败体。 */
    private ResponseEntity<?> error(int status, String code, String message) {
        String path = currentPath();
        if (EnvelopePaths.inScope(path)) {
            return ResponseEntity.status(status).body(CommonResponse.fail(code, message));
        }
        return ResponseEntity.status(status).body(Map.of("detail", message));
    }

    private String currentPath() {
        if (RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes a) {
            return a.getRequest().getRequestURI();
        }
        return null;
    }
}

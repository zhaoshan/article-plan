# Role backend correction: review proposal

Date: 2026-11-06 (Asia/Shanghai)
Project: `/Users/ramiro.li/root/apps/work/platform-iam-service`
Branch: `dev/261026_v0.2` at `76e6580`
State: user approved this proposal and subsequent iMorph-Admin role-write repair; implementation and independent review complete. See ../../tasks/11-06-tenant-role-api-cleanup/validation.md for actual changes, tests and uncommitted delivery.

## Goal and scope

Remove the obsolete combined role catalog and use the existing tenant-scoped administrative role list for role management and member dialogs. Verify tenant authorization and document the permission-tree contract. Frontend identity, menu, button and table changes belong to the independent frontend task. No schema, seed, identity-policy, member-write-policy or Git changes are proposed.

## Repository evidence

- `TenantRoleController` exposes `GET /api/v1/admin/tenant/roles?tenant_id=<id>` with `iam:member:read`.
- `TenantRoleQueryService` checks target scope and tenant existence, then queries global custom roles plus target-tenant roles and excludes template-defined tenant Owner codes. This is precisely the obsolete union described in requirement 7.
- `RoleRepository.listForTenantMemberPicker` is referenced only by that service and its tests. `TenantRoleOption` and `TenantRoleOptions` are likewise dedicated to that endpoint.
- `AdminRoleController` exposes `GET /api/v1/admin/roles` with `iam:role:read`; response is the normal API envelope with `data.roles` and `data.count`, without the old `data.tenant_id` field.
- `AdminRoleService.listByScope` calls `TenantScopeGuard` before querying. The guard checks database-backed PLATFORM role bindings, rather than trusting a JWT role name. A non-platform caller can target only its token tenant.
- `RoleRepository.listForAdmin` already constrains tenant requests to `scope_type=TENANT AND scope_id=<id>`. Platform requests intentionally return all non-deleted roles across scopes. Both include DISABLED roles, retain `id ASC` order, and are unpaginated. Additional filters are ANDed into the authorized query.
- `AdminPermissionController` currently returns all ACTIVE permissions, with string fields `permission_id`, `permission_code`, `permission_name`, `resource_type`, `app_code`, `tenant_grantable` (`"1"`/`"0"`), and `category`. It does not accept a tenant-grantable filter.
- `AdminRoleService.assertTenantGrantable` already rejects a tenant-role permission write unless the permission has `tenant_grantable=1` and belongs to IAM or an application enabled for the target tenant. Invalid IDs are also rejected.
- Existing `AdminRoleListIntegrationTest` covers tenant-only rows, platform aggregation, disabled visibility, logical deletion, forged JWT role claims and cross-tenant denial. These tests must remain valid after removal.

## Proposed design and changed files

1. Delete the obsolete controller, service and DTOs:
   - `iam-app/src/main/java/com/unify/iam/app/adapter/controller/TenantRoleController.java`
   - `iam-app/src/main/java/com/unify/iam/app/app/service/admin/TenantRoleQueryService.java`
   - `iam-api/src/main/java/com/unify/iam/api/dto/admin/TenantRoleOption.java`
   - `iam-api/src/main/java/com/unify/iam/api/dto/admin/TenantRoleOptions.java`
2. Remove only `RoleRepository.listForTenantMemberPicker`; retain both management and runtime query semantics.
3. Remove endpoint-specific controller/service tests. Replace the old union integration test with a removal regression using a valid authenticated caller, plus canonical tenant-list contract coverage where existing tests do not already cover it. Verify the obsolete path has no registered handler, rather than assuming an authentication failure proves removal.
4. Retain the permission catalog's existing API contract. Add focused response-contract coverage for the string grantability flag if needed; the frontend filters the tenant role tree to `tenant_grantable === "1"` and target-enabled applications. No blanket removal of platform permissions from the shared directory is proposed, because platform role authorization uses that directory too.
5. Update `.trellis/spec/backend/tenant-role-candidates.md` and its index to replace the obsolete union contract with the canonical TENANT query, required permission and separate grant-policy boundary. Record task and validation artifacts only under this project's `.trellis/`.

## Frontend handoff contract and compatibility

| Use | Query / contract |
| --- | --- |
| Platform Roles list | `GET /api/v1/admin/roles?scope_type=PLATFORM&scope_id=PLATFORM` |
| Platform tenant filter | Add `filter_scope_id=<tenant_id>` to the platform query; `filter_scope_type` and `keyword` remain supported |
| Tenant Roles list and both member dialogs | `GET /api/v1/admin/roles?scope_type=TENANT&scope_id=<target_tenant_id>` |
| List response | `data.roles`, `data.count`; existing `role_id`, `role_code`, `role_name`, `role_description`, `scope_type`, `scope_id`, `tenant_name`, `role_status`, `is_builtin`, `is_owner`, `permissionCounts` |
| Role read authorization | `iam:role:read`; a caller with only `iam:member:read` will receive 403 after migrating from the obsolete endpoint |
| Role creation / edit authorization | `iam:role:write` and target-scope guard |
| Permission directory | `GET /api/v1/admin/permissions`, requires `iam:role:read`; filter string `tenant_grantable` to `"1"` for tenant-role trees |

The backend's actual route prefix is `/api/v1`; deployments may expose `/v1` through a proxy. This workspace contains no evidence verifying the frontend's proxy configuration. The independent frontend task must migrate every old endpoint caller together with the backend rollout and use the target tenant context. No other project has been accessed. Removing the old API is intentionally incompatible; rollback restores only the task-owned deletions and spec/test edits. There is no database migration.

The canonical list includes all target-tenant roles, including Owner/builtin/DISABLED entries, as requested. Catalog visibility remains distinct from assignment authority; this change does not widen member-write eligibility. Existing seeds contain role-read permissions for iMorph Admin/Member and role-write for Owner; no new grants will be inferred from frontend identity labels.

## Acceptance and validation plan

- No obsolete endpoint handler, union repository method or dedicated DTO/service caller remains in product code.
- Canonical tenant lists never include PLATFORM or foreign tenant roles; PLATFORM management aggregation remains intact.
- Cross-tenant and forged PLATFORM requests remain forbidden; `iam:role:read` is still required.
- Permission catalog response preserves string `tenant_grantable` and existing permission-write enforcement.
- Compile the reactor with JDK 21; run relevant role controller/service, role-list, tenant permission and endpoint-removal regressions. MySQL integration tests require Docker; report environment failures separately from application failures.
- Run `git diff --check`, review the complete task diff and document the exact test counts and limits.
- Keep changes uncommitted on the current branch. Do not push, merge, switch/reset branches or create/delete worktrees.

## Explicit gate

`.trellis/workflow.md`, Request Triage: "Complex task: ask whether you may create a Trellis task and enter planning."

`.trellis/workflow.md`, Phase 1 planning block: "Complex: finish prd.md, design.md, and implement.md; ask for review before task.py start."

`.agents/skills/trellis-brainstorm/SKILL.md`, Non-Negotiable Planning Contract: "For every non-trivial task, the user must respond at least once after the initial request before implementation begins."

The user's request explicitly preserves mandatory confirmation gates. Approval is therefore requested for creating the backend task and implementing this reviewed proposal. The proposal will be materialized into PRD/design/implementation artifacts before activation; any material scope change requires a new review.

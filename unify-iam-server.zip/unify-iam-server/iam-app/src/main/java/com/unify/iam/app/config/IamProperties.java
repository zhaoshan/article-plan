package com.unify.iam.app.config;

import com.unify.iam.api.constant.ClaimConstants;
import java.util.List;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * IAM 应用配置（前缀 {@code iam}）。
 */
@Data
@ConfigurationProperties(prefix = "iam")
public class IamProperties {

    /** JWT 签发配置 */
    private Jwt jwt = new Jwt();

    /** 是否启用 dev-token 端点（local/test 开，prod 关） */
    private boolean devTokenEnabled = true;

    /** E2E-2 OIDC SSO 配置 */
    private Oidc oidc = new Oidc();

    /** 版本 feed 配置（方案 c 即时吊销，docs/07 §8.3；parlant doc11 附录 B） */
    private Versions versions = new Versions();

    /** G2 邀请邮件配置（docs/08 §3；SMTP 未配置 → 日志模式） */
    private Mail mail = new Mail();

    /** G2 增强：app_code → 应用主页地址（环境级兜底；iam_application.homepage_url 优先） */
    private java.util.Map<String, String> appHomepages = new java.util.LinkedHashMap<>();

    @Data
    public static class Mail {
        /** 邀请链接 hub 基址（{{invitation_link}} = base + /invitations/accept?token=..&app=..） */
        private String invitationLinkBaseUrl = "http://localhost:5173";
        /** 邀请链接隐含应用参数（默认 imorph，db/seed/R__app_imorph.sql 注册） */
        private String invitationDefaultApp = "imorph";
        /** Owner 邀请邮件主题模板（{{变量}} 同正文） */
        private String ownerInvitationSubject = "You're invited to manage {{tenant_name}} on iMorph";
        /** Member/Admin 邀请邮件主题模板 */
        private String memberInvitationSubject = "You've been invited to join {{tenant_name}} on iMorph";
        /** Owner 邀请邮件正文模板（classpath HTML，含 {{#initial_password}} 条件块） */
        private String ownerInvitationTemplate = "templates/tenant-owner-invitation-email.html";
        /** Member/Admin 邀请邮件正文模板（classpath HTML） */
        private String memberInvitationTemplate = "templates/tenant-member-admin-invitation-email.html";
        /** 密码重置邮件主题模板（docs/08 §2.1③ 流程） */
        private String passwordResetSubject = "Reset your password for iMorph";
        /** 密码重置邮件正文模板（classpath HTML，变量 {{Full_Name}}/{{reset_url}}） */
        private String passwordResetTemplate = "templates/reset-password-email.html";
    }

    @Data
    public static class Jwt {
        /** kid（E2E-1 固定，不轮换） */
        private String kid = ClaimConstants.DEFAULT_KID;
        /** issuer */
        private String issuer = ClaimConstants.DEFAULT_ISSUER;
        /** audiences 白名单（多应用接入，docs/user-manual 03）：签发 aud = 租户启用应用 ∩ 该列表；无应用记录租户回落全量 */
        private List<String> audiences = List.of(ClaimConstants.DEFAULT_AUDIENCE);
        /** 令牌有效期（秒），默认 2h */
        private long ttlSeconds = ClaimConstants.DEFAULT_TTL_SECONDS;
        /** refresh token 有效期（天），默认 30 */
        private long refreshTtlDays = 30;
        /** RSA 私钥持久化路径（PKCS#8 PEM；首启生成，重启不换钥） */
        private String privateKeyPath = "./keys/rsa-private.pem";
    }

    @Data
    public static class Versions {
        /** 版本 feed 服务间鉴权共享令牌（parlant 侧 IAM_VERSIONS_TOKEN 对齐；空 → 端点 403 禁用） */
        private String serviceToken = "";
        /** 增量 feed 单次最大返回条数（游标分页） */
        private int feedLimit = 1000;
    }

    @Data
    public static class Oidc {
        /** OIDC 回调地址（在本服务上的 redirect_uri；浏览器跳转 IdP 后回跳本端点） */
        private String redirectUri = "http://localhost:8090/api/v1/auth/oidc/callback";
        /** 登录成功回跳前端的地址（dev：携带 ?access_token=） */
        private String frontendRedirect = "http://localhost:5173/login";
        /** 允许的 ID Token 签名算法（白名单） */
        private String allowedAlgorithms = "RS256,ES256";
        /** hub 回跳 return_to 白名单（hop-2 防 open redirect + token 外泄；新业务源在此加，hub 前端零改动） */
        private List<String> allowedReturnOrigins = List.of("http://localhost:5173");
    }
}

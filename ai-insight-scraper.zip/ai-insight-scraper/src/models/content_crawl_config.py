"""页面内容爬取配置模型

页面内容爬取的配置，按站点区分。当前包含 exclude_tags（标签过滤），
未来可扩展其它字段（通过 extra="allow" 兼容）。
"""

from pydantic import BaseModel, Field, ConfigDict


class ExcludeTag(BaseModel):
    """排除标签规则

    匹配 HTML DOM 标签，符合规则的标签在爬取时将被移除。
    """

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    tag: str = Field(..., min_length=1, description="标签名（必填）")
    id: str | None = Field(default=None, description="匹配 id 属性（精确匹配）")
    class_: str | None = Field(
        default=None,
        alias="class",
        description="匹配 class 属性（标签含多个 class 时包含即匹配）",
    )


class ContentCrawlConfig(BaseModel):
    """页面内容爬取配置（单站点）"""

    model_config = ConfigDict(extra="allow")

    exclude_tags: list[ExcludeTag] = Field(
        default_factory=list,
        description="需要排除的 DOM 标签规则列表",
    )

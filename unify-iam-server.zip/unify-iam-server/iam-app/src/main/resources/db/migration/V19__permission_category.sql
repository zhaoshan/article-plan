-- Permission category (一级功能模块): grouping column for permission catalog browsing.
-- Existing migrations are immutable; this file is additive only.
-- Data init: db/seed/R__app_imorph.sql (imorph 126 权限，取自 docs/requirements/iMorph正式版权限码与角色矩阵.xlsx 一级模块列)。

ALTER TABLE `gateway_permission`
  ADD COLUMN `category` VARCHAR(64) DEFAULT NULL
    COMMENT '一级功能模块（如 Agent Management / KnowledgeHub / Build / Preview / Test / Deploy / Monitor / Suggestions / Insights）'
    AFTER `permission_description`;

-- 索引说明：列表按 app_code 过滤走现有索引即可，category 仅作目录分组展示，不单建索引。

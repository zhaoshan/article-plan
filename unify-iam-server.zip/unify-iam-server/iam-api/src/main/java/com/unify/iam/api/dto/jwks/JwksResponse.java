package com.unify.iam.api.dto.jwks;

import java.util.List;

/**
 * JWKS 文档：{@code {"keys": [...]}}。
 */
public record JwksResponse(List<Jwk> keys) {
}

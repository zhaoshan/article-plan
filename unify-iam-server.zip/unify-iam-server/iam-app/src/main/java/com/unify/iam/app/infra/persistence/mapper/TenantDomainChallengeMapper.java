package com.unify.iam.app.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.app.infra.persistence.po.TenantDomainChallengePO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_tenant_domain_challenge Mapper。 */
@Mapper
public interface TenantDomainChallengeMapper extends BaseMapper<TenantDomainChallengePO> {
}

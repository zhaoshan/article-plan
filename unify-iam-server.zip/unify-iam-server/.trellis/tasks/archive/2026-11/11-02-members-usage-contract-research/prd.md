# Research admin tenant usage contracts for member management

## Goal

Trace GET /api/v1/admin/tenants/{tenantId}/usage and /usage/{dimensionId} through the backend and document response shape, dimension IDs, member count/quota semantics, aggregation, permissions, unlimited quotas, error behavior, and frontend integration recommendation. Read-only research; no business-code changes.

## Requirements

- Inspect the backend route/controller, service, DTO/serializer, repository/configuration, permission guard, and tests for both tenant usage endpoints.
- Record the exact successful response envelopes and field types, including nested objects and null/empty behavior.
- Identify the supported `dimensionId` values and how member usage is represented (current usage, quota, unlimited state, and aggregation).
- Compare the aggregate endpoint with the single-dimension endpoint and state which one a member-management page should call and why.
- Document authorization requirements, tenant scope checks, not-found behavior, invalid-dimension behavior, unlimited quota semantics, and other observable error cases.
- Persist code-backed evidence paths and a concrete frontend integration contract under this task's `research/` directory.
- Do not modify business code, tests, generated clients, branches, remotes, or worktrees.

## Acceptance Criteria

- [x] Research artifact cites the route/controller and service implementation for both endpoints.
- [x] Research artifact gives exact response shapes and representative examples derived from backend code/tests.
- [x] Research artifact states dimension IDs, member count/quota semantics, aggregation behavior, permissions, unlimited quota handling, and error semantics.
- [x] Research artifact gives a concrete recommendation for the member-management page, including request sequence and fallback handling.
- [x] `git diff` contains only Trellis task/research bookkeeping; no business-code files are changed.
- [x] Validation records repository status and any checks run.

## Notes

- Keep `prd.md` focused on requirements, constraints, and acceptance criteria.
- Lightweight tasks can remain PRD-only.
- For complex tasks, add `design.md` for technical design and `implement.md` for execution planning before `task.py start`.

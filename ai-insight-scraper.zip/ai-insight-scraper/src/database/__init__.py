"""数据库包

提供 SQLAlchemy 异步连接管理、ORM 模型和仓储层。

使用方式：
  1. 启动时调用 init_engine(db_config) 传入 DatabaseConfig
  2. 之后通过 get_session() 获取 Session
  3. 关闭时调用 close_db()
"""

from src.database.connection import (
    Base,
    init_engine,
    is_initialized,
    ensure_initialized,
    get_session,
    init_db,
    close_db,
)
from src.database.models import (
    CrawlTaskModel,
    CrawlLinkTreeModel,
    CrawlScheduleModel,
    CrawlScheduleLogModel,
)
from src.database.repository import (
    TaskRepository,
    LinkTreeRepository,
    ScheduleRepository,
    ScheduleLogRepository,
)
from src.database.seed import seed_crawl_link_tree_if_empty

__all__ = [
    "Base",
    "init_engine",
    "is_initialized",
    "ensure_initialized",
    "get_session",
    "init_db",
    "close_db",
    "CrawlTaskModel",
    "CrawlLinkTreeModel",
    "CrawlScheduleModel",
    "CrawlScheduleLogModel",
    "TaskRepository",
    "LinkTreeRepository",
    "ScheduleRepository",
    "ScheduleLogRepository",
    "seed_crawl_link_tree_if_empty",
]

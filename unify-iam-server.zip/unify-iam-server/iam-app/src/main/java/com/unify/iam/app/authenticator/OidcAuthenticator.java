package com.unify.iam.app.authenticator;

import com.unify.iam.app.oidc.JitProvisioner;
import com.unify.iam.app.oidc.OidcProviderConfig;
import com.unify.iam.app.oidc.VerifiedClaims;
import org.springframework.stereotype.Component;

/**
 * OIDC 认证：已验证的 ID Token 声明 → JIT 入租户 → UserPrincipal。
 *
 * <p>只做"认证 + 定位身份/成员"，授权（RBAC）由后续管线消化。
 */
@Component
public class OidcAuthenticator implements Authenticator {

    private final JitProvisioner jitProvisioner;

    public OidcAuthenticator(JitProvisioner jitProvisioner) {
        this.jitProvisioner = jitProvisioner;
    }

    @Override
    public String mechanism() {
        return "oidc";
    }

    public JitProvisioner.JitResult authenticate(OidcProviderConfig config, VerifiedClaims claims) {
        return jitProvisioner.provision(config, claims);
    }
}
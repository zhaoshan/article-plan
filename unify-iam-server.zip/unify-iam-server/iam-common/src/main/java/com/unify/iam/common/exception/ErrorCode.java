package com.unify.iam.common.exception;

/** 错误码契约：code + 人类可读 message。 */
public interface ErrorCode {

    /** 错误码（如 IAM-AUTH-001） */
    String getCode();

    /** 默认错误信息 */
    String getMessage();
}

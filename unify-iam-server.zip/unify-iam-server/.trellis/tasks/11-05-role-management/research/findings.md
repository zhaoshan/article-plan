# Repository findings

- AdminRoleController maps /api/v1/admin/roles (the deployed client may use /v1 behind a proxy).
- Existing PLATFORM management queries intentionally aggregate every scope and do not paginate. Reusing scope_type for row-type filtering would break that behavior; independent filter_scope_type/filter_scope_id preserve it.
- TenantScopeGuard checks real membership role bindings rather than trusting JWT role names. Filters must be applied only after this guard and ANDed into the authorized query.
- RoleRepository.listByScope is runtime ACTIVE-only. listForAdmin includes disabled roles and must remain separate.
- Existing TenantRepository.findByIds batches IDs, removes soft-deleted tenants through TableLogic, and trims CHAR business keys.
- TenantMemberQueryService and TenantMemberQueryMapper establish keyword + explicit ! LIKE escape as the local literal-substring convention.
- CreateRoleRequest originally required role_code and AdminRoleService directly trimmed it. No generation existed. AdminRoleController also read request.roleCode into Map.of for auditing; that would fail if code became optional without updating audit ownership.
- IdGenerator.newBizId returns a 32-character hex UUID. role_ prefix keeps generated codes under gateway_role.role_code VARCHAR(64).
- application.yml has NON_NULL serialization; missing tenant names may be omitted, consistent with existing nullable list descriptions.
- Maven targets Java 21. Default shell Java is 26; Homebrew JDK21 is available at /opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home.
- Docker socket is denied under the default sandbox; an escalated read-only docker info succeeds and reports server 29.8.0. Integration checks can use escalated Maven.

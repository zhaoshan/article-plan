"""动态页面爬取配置模型"""

from pydantic import BaseModel, Field, ConfigDict


class DynamicPageEntry(BaseModel):
    """单个站点的单个动态页面类型配置"""

    model_config = ConfigDict(extra="forbid")

    script_name: str = Field(
        ..., min_length=1, description="脚本注册表中的 key，如 'faq_crawler'"
    )
    parent_link: str = Field(
        ..., min_length=1, description="动态链接在静态树中的挂载位置"
    )
    entry_url: str = Field(
        ..., min_length=1, description="脚本实际打开并执行的入口 URL"
    )
    description: str | None = Field(default=None, description="可读描述")

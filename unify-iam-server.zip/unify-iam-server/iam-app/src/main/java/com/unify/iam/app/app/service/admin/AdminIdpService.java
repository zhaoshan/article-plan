package com.unify.iam.app.app.service.admin;

import com.fasterxml.jackson.core.type.TypeReference;
import com.unify.iam.api.dto.admin.GroupMappingRequest;
import com.unify.iam.api.dto.admin.IdpConfigRequest;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.identity.infra.persistence.po.IdpConfigPO;
import com.unify.iam.identity.infra.persistence.po.IdpGroupMappingPO;
import com.unify.iam.identity.infra.persistence.repository.IdpConfigRepository;
import com.unify.iam.identity.infra.persistence.repository.IdpGroupMappingRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/**
 * 管理面 IdP 配置与组→角色映射服务（docs/07 §3，iam:idp:*，仅平台管理员）。
 *
 * <p>平台管理员管理任意租户（tenant_id 参数）或平台级（PLATFORM）IdP；
 * {@code client_secret} 落库 client_secret_cipher——当前 DEV 明文直存（加密为待办，docs/07 §7）。
 */
@Service
public class AdminIdpService {

    private static final String PLATFORM = "PLATFORM";

    private final IdpConfigRepository idpConfigRepository;
    private final IdpGroupMappingRepository idpGroupMappingRepository;
    private final TenantRepository tenantRepository;
    private final RoleRepository roleRepository;

    public AdminIdpService(IdpConfigRepository idpConfigRepository,
                           IdpGroupMappingRepository idpGroupMappingRepository,
                           TenantRepository tenantRepository,
                           RoleRepository roleRepository) {
        this.idpConfigRepository = idpConfigRepository;
        this.idpGroupMappingRepository = idpGroupMappingRepository;
        this.tenantRepository = tenantRepository;
        this.roleRepository = roleRepository;
    }

    // ---------- IdP 配置 ----------

    public List<Map<String, Object>> listConfigs(String tenantId) {
        String tenantIdT = tenantId == null || tenantId.isBlank() ? PLATFORM : tenantId.trim();
        assertTenantExists(tenantIdT);
        return idpConfigRepository.listByTenant(tenantIdT).stream().map(this::toConfigBrief).toList();
    }

    public Map<String, Object> createConfig(IdpConfigRequest req) {
        String tenantId = req.tenantId() == null || req.tenantId().isBlank() ? PLATFORM : req.tenantId().trim();
        assertTenantExists(tenantId);
        IdpConfigPO po = new IdpConfigPO();
        po.setTenantIdpConfigId(IdGenerator.newBizId());
        po.setTenantId(tenantId);
        applyConfigFields(po, req, true);
        try {
            idpConfigRepository.insert(po);
        } catch (org.springframework.dao.DuplicateKeyException e) {
            // uk(tenant_id, protocol, provider_key, issuer)：重复配置是用户错误 → 400 而非 500
            throw AuthException.badRequest("该租户已存在相同 provider + issuer 的 IdP 配置");
        }
        return toConfigBrief(po);
    }

    public Map<String, Object> updateConfig(String configId, IdpConfigRequest req) {
        IdpConfigPO po = idpConfigRepository.findById(configId)
                .orElseThrow(() -> AuthException.notFound("IdP 配置不存在"));
        applyConfigFields(po, req, false);
        idpConfigRepository.update(po);
        return toConfigBrief(po);
    }

    public void deleteConfig(String configId) {
        idpConfigRepository.findById(configId).orElseThrow(() -> AuthException.notFound("IdP 配置不存在"));
        idpConfigRepository.logicalDelete(configId);
    }

    // ---------- 组→角色映射 ----------

    public List<Map<String, String>> listMappings(String configId) {
        idpConfigRepository.findById(configId).orElseThrow(() -> AuthException.notFound("IdP 配置不存在"));
        return idpGroupMappingRepository.listByConfig(configId.trim())
                .stream().map(this::toMappingBrief).toList();
    }

    public Map<String, String> createMapping(String configId, GroupMappingRequest req) {
        IdpConfigPO config = idpConfigRepository.findById(configId)
                .orElseThrow(() -> AuthException.notFound("IdP 配置不存在"));
        assertTargetRoleInTenant(config.getTenantId(), req.targetRoleId());
        IdpGroupMappingPO po = new IdpGroupMappingPO();
        po.setIdpGroupMappingId(IdGenerator.newBizId());
        po.setTenantIdpConfigId(configId.trim());
        applyMappingFields(po, req);
        try {
            idpGroupMappingRepository.create(po);
        } catch (org.springframework.dao.DuplicateKeyException e) {
            // uk(config, match_mode, match_value, target_role)：重复映射 → 400
            throw AuthException.badRequest("该 IdP 已存在相同匹配规则与目标角色的映射");
        }
        return toMappingBrief(po);
    }

    public Map<String, String> updateMapping(String configId, String mappingId, GroupMappingRequest req) {
        IdpConfigPO config = idpConfigRepository.findById(configId)
                .orElseThrow(() -> AuthException.notFound("IdP 配置不存在"));
        IdpGroupMappingPO po = idpGroupMappingRepository.findById(mappingId)
                .orElseThrow(() -> AuthException.notFound("组映射不存在"));
        if (!configId.trim().equals(po.getTenantIdpConfigId())) {
            throw AuthException.badRequest("组映射不属于该 IdP 配置");
        }
        if (req.targetRoleId() != null) {
            assertTargetRoleInTenant(config.getTenantId(), req.targetRoleId());
        }
        applyMappingFields(po, req);
        idpGroupMappingRepository.update(po);
        return toMappingBrief(po);
    }

    public void deleteMapping(String configId, String mappingId) {
        IdpGroupMappingPO po = idpGroupMappingRepository.findById(mappingId)
                .orElseThrow(() -> AuthException.notFound("组映射不存在"));
        if (!configId.trim().equals(po.getTenantIdpConfigId())) {
            throw AuthException.badRequest("组映射不属于该 IdP 配置");
        }
        idpGroupMappingRepository.logicalDelete(mappingId);
    }

    // ---------- 内部 ----------

    private void assertTenantExists(String tenantId) {
        if (!PLATFORM.equals(tenantId)) {
            tenantRepository.findById(tenantId).orElseThrow(() -> AuthException.notFound("租户不存在"));
        }
    }

    /** target_role_id 必须属于该 IdP 目标租户（租户级 = TENANT/该租户；平台级 = PLATFORM 角色）。 */
    private void assertTargetRoleInTenant(String tenantId, String roleId) {
        RolePO role = roleRepository.findById(roleId).orElseThrow(() -> AuthException.badRequest("目标角色不存在"));
        boolean ok = PLATFORM.equals(tenantId)
                ? "PLATFORM".equals(role.getScopeType())
                : "TENANT".equals(role.getScopeType()) && tenantId.equals(role.getScopeId());
        if (!ok) {
            throw AuthException.badRequest("目标角色必须属于该 IdP 所属租户");
        }
    }

    private void applyConfigFields(IdpConfigPO po, IdpConfigRequest req, boolean create) {
        if (req.protocol() != null) po.setProtocol(req.protocol());
        if (req.providerKey() != null) po.setProviderKey(req.providerKey());
        if (req.displayName() != null) po.setDisplayName(req.displayName());
        po.setConfigStatus(req.configStatus() == null ? "ACTIVE" : req.configStatus());
        if (req.issuer() != null) po.setIssuer(req.issuer());
        if (req.discoveryUri() != null) po.setDiscoveryUri(req.discoveryUri());
        if (req.jwkSetUri() != null) po.setJwkSetUri(req.jwkSetUri());
        if (req.authorizationEndpoint() != null) po.setAuthorizationEndpoint(req.authorizationEndpoint());
        if (req.tokenEndpoint() != null) po.setTokenEndpoint(req.tokenEndpoint());
        if (req.userinfoEndpoint() != null) po.setUserinfoEndpoint(req.userinfoEndpoint());
        if (req.clientId() != null) po.setClientId(req.clientId());
        // secret 只写不读：仅当请求带了才更新（明文直存 DEV，加密为待办 docs/07 §7）
        if (req.clientSecret() != null && !req.clientSecret().isBlank()) {
            po.setClientSecretCipher(req.clientSecret());
        }
        if (req.scopes() != null) po.setScopesJson(JsonUtils.toJson(req.scopes()));
        if (req.claimMapping() != null) po.setClaimMappingJson(JsonUtils.toJson(req.claimMapping()));
        if (req.allowedDomains() != null) po.setAllowedDomainsJson(JsonUtils.toJson(req.allowedDomains()));
        if (req.pkceRequired() != null) po.setPkceRequired(req.pkceRequired() ? 1 : 0);
        if (req.emailVerifiedRequired() != null) po.setEmailVerifiedRequired(req.emailVerifiedRequired() ? 1 : 0);
        if (req.jitProvisioningEnabled() != null) po.setJitProvisioningEnabled(req.jitProvisioningEnabled() ? 1 : 0);
        if (req.defaultJoinPolicy() != null) po.setDefaultJoinPolicy(req.defaultJoinPolicy());
        if (create && po.getProtocol() == null) po.setProtocol("OIDC");
        if (create && po.getDefaultJoinPolicy() == null) po.setDefaultJoinPolicy("INVITE_ONLY");
    }

    private void applyMappingFields(IdpGroupMappingPO po, GroupMappingRequest req) {
        if (req.matchMode() != null) po.setMatchMode(req.matchMode());
        if (req.matchValue() != null) po.setMatchValue(req.matchValue());
        if (req.targetRoleId() != null) po.setTargetRoleId(req.targetRoleId());
        if (req.priority() != null) po.setPriority(req.priority());
        po.setMappingStatus(req.mappingStatus() == null ? "ACTIVE" : req.mappingStatus());
    }

    /** 配置简要：secret 只暴露"是否有值"（不读回明文）。 */
    private Map<String, Object> toConfigBrief(IdpConfigPO po) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("idp_config_id", po.getTenantIdpConfigId());
        m.put("tenant_id", po.getTenantId());
        m.put("protocol", po.getProtocol());
        m.put("provider_key", po.getProviderKey());
        m.put("display_name", po.getDisplayName());
        m.put("config_status", po.getConfigStatus());
        m.put("issuer", po.getIssuer());
        m.put("discovery_uri", po.getDiscoveryUri());
        m.put("jwk_set_uri", po.getJwkSetUri());
        m.put("authorization_endpoint", po.getAuthorizationEndpoint());
        m.put("token_endpoint", po.getTokenEndpoint());
        m.put("userinfo_endpoint", po.getUserinfoEndpoint());
        m.put("client_id", po.getClientId());
        m.put("has_secret", po.getClientSecretCipher() != null && !po.getClientSecretCipher().isBlank());
        m.put("scopes", parseJsonList(po.getScopesJson()));
        m.put("claim_mapping", parseJsonMap(po.getClaimMappingJson()));
        m.put("allowed_domains", parseJsonList(po.getAllowedDomainsJson()));
        m.put("pkce_required", po.getPkceRequired());
        m.put("email_verified_required", po.getEmailVerifiedRequired());
        m.put("jit_provisioning_enabled", po.getJitProvisioningEnabled());
        m.put("default_join_policy", po.getDefaultJoinPolicy());
        return m;
    }

    private Map<String, String> toMappingBrief(IdpGroupMappingPO po) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("mapping_id", po.getIdpGroupMappingId());
        m.put("idp_config_id", po.getTenantIdpConfigId());
        m.put("match_mode", po.getMatchMode());
        m.put("match_value", po.getMatchValue());
        m.put("target_role_id", po.getTargetRoleId());
        m.put("priority", String.valueOf(po.getPriority()));
        m.put("mapping_status", po.getMappingStatus());
        return m;
    }

    private List<String> parseJsonList(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }
        try {
            return JsonUtils.fromJson(json, new TypeReference<List<String>>() {
            });
        } catch (Exception e) {
            return List.of();
        }
    }

    private Map<String, String> parseJsonMap(String json) {
        if (json == null || json.isBlank()) {
            return Map.of();
        }
        try {
            return JsonUtils.fromJson(json, new TypeReference<Map<String, String>>() {
            });
        } catch (Exception e) {
            return Map.of();
        }
    }
}

package com.unify.iam.app.mail;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.junit.jupiter.api.Test;

/** MailTemplateRenderer 单测：{{变量}} 替换、null→空串、{{#block}} 条件块（G2 密码区块）。 */
class MailTemplateRendererTest {

    @Test
    void replacesVariables() {
        assertThat(MailTemplateRenderer.render("Hi {{Full_Name}}, join {{tenant_name}}!",
                Map.of("Full_Name", "Alice", "tenant_name", "Org A")))
                .isEqualTo("Hi Alice, join Org A!");
    }

    @Test
    void nullValueBecomesEmptyString() {
        java.util.Map<String, String> vars = new java.util.HashMap<>();
        vars.put("initial_password", null);
        assertThat(MailTemplateRenderer.render("[{{initial_password}}]", vars)).isEqualTo("[]");
    }

    @Test
    void blockKeptAndRenderedWhenVariablePresent() {
        String tpl = "A<!-- {{#initial_password}} --> pw={{initial_password}} <!-- {{/initial_password}} -->B";
        assertThat(MailTemplateRenderer.render(tpl, Map.of("initial_password", "Xy9#")))
                .isEqualTo("A pw=Xy9# B");
    }

    @Test
    void blockStrippedWhenVariableAbsentOrNull() {
        String tpl = "A<!-- {{#initial_password}} --> pw={{initial_password}} <!-- {{/initial_password}} -->B";
        assertThat(MailTemplateRenderer.render(tpl, Map.of())).isEqualTo("AB");
        java.util.Map<String, String> withNull = new java.util.HashMap<>();
        withNull.put("initial_password", null);
        assertThat(MailTemplateRenderer.render(tpl, withNull)).isEqualTo("AB");
    }

    @Test
    void templateWithoutVariablesUnchanged() {
        assertThat(MailTemplateRenderer.render("plain <b>html</b>", Map.of())).isEqualTo("plain <b>html</b>");
    }

    @Test
    void emailVerificationTemplateSubstitutesAllVariables() throws Exception {
        String tpl = new String(new org.springframework.core.io.ClassPathResource(
                "templates/email-verification-email.html").getInputStream().readAllBytes(),
                java.nio.charset.StandardCharsets.UTF_8);
        String out = MailTemplateRenderer.render(tpl, java.util.Map.of(
                "Full_Name", "alice", "verification_code", "436165"));
        org.assertj.core.api.Assertions.assertThat(out)
                .contains("Hi alice,")
                .contains("436165")
                .doesNotContain("{{")
                .doesNotContain("}}");
    }
}
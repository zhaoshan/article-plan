# 租户详情成员数据与无分页契约

1. 核对当前仓库说明、未提交状态、真实成员/用户/角色表以及 CHAR ID 规范。
2. 详情成员查询固定 LIMIT 1000、无 OFFSET，移除分页参数与 page/size 响应，保留 members.items；返回真实 total、limit、truncated。
3. 保留批量用户和角色关联、真实 user_available、权威 owner_user_id，不伪造身份，不从首成员推断 Owner。
4. 新增 MySQL 关联/缺失/删除/CHAR/权限/上限边界回归，执行定向 Maven 测试、build、diff 检查。
5. 更新当前项目接口文档、契约与会话记录；不访问前端，不操作分支/worktree，不暂存或提交。

## 完成

以上五步已完成。6 个新增真实 MySQL 集成测试、5 个既有详情/Owner/Quota 测试、2 个作用域测试共 13 个通过，0失败/错误/跳过；Maven多模块打包与 git diff --check 通过。所有改动保持未提交。

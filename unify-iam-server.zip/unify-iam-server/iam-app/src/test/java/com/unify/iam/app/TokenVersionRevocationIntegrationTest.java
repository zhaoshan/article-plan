package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

/**
 * 方案 c 即时吊销（docs/07 §8.3；parlant doc11 附录 B）IAM 侧集成测试：
 * 角色/权限变更 bump token_version、JWT 携带 ver、版本 feed（快照/增量/tombstone/鉴权）。
 */
class TokenVersionRevocationIntegrationTest extends IamIntegrationTestBase {

    private static final String SERVICE_TOKEN = "it-service-token";

    private String adminToken() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"admin123\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private long verOf(String token) throws Exception {
        return SignedJWT.parse(token).getJWTClaimsSet().getLongClaim("ver");
    }

    /** 建用户 + 加入 tenant-org-a（parlant 应用已启用，feed 可命中）并置默认成员，返回 membership_id。 */
    private String createMember(String username, String roleId) throws Exception {
        String token = adminToken();
        String createdUser = mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + username + "@unify.local\",\"password\":\"Passw0rd!\"}"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        String userId = unwrapData(createdUser).get("user_id").toString();
        String createdMember = mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"user_id\":\"" + userId + "\",\"role_ids\":[\"" + roleId + "\"]}"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        String membershipId = unwrapData(createdMember).get("membership_id").toString();
        // 本地登录需默认成员（add() 置 is_default=0）
        jdbcTemplate.update("UPDATE gateway_membership SET is_default = 1 WHERE membership_id = ?", membershipId);
        return membershipId;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> feed(Map<String, String> params) throws Exception {
        MockHttpServletRequestBuilder req = get("/api/v1/auth/versions").header("X-IAM-Service-Token", SERVICE_TOKEN);
        for (Map.Entry<String, String> e : params.entrySet()) {
            req = req.param(e.getKey(), e.getValue());
        }
        MvcResult res = mockMvc.perform(req).andExpect(status().isOk()).andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), Map.class);
    }

    /** 角色变更 → bump 版本 + JWT 新旧 ver 递增 + feed 快照可见。 */
    @Test
    void setRolesBumpsVersionFeedAndJwtVer() throws Exception {
        String membershipId = createMember("ver_user1", "r-1003");

        // 首次登录 token ver = 0
        assertThat(verOf(login("ver_user1", "Passw0rd!"))).isZero();

        // 管理端覆盖式改角色 → bump（0 → 1）
        mockMvc.perform(put("/api/v1/admin/members/" + membershipId + "/roles")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[\"r-1001\"]}"))
                .andExpect(status().isOk());
        Integer dbVer = jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId);
        assertThat(dbVer).isEqualTo(1);

        // 再次登录 → 新 token ver=1（> 旧 token 的 0）
        assertThat(verOf(login("ver_user1", "Passw0rd!"))).isEqualTo(1L);

        // feed 快照：app 作用域内该成员 version=1
        Map<String, Object> snap = feed(Map.of("app_code", "parlant-agent-server"));
        List<Map<String, Object>> items = (List<Map<String, Object>>) snap.get("items");
        Map<String, Object> mine = items.stream()
                .filter(i -> membershipId.equals(i.get("membership_id")))
                .findFirst()
                .orElseThrow(() -> new AssertionError("feed 快照未包含成员 " + membershipId));
        assertThat(mine.get("version")).isEqualTo(1);
        assertThat(((Number) snap.get("cursor")).longValue()).isGreaterThanOrEqualTo(0);
    }

    /** 角色权限变更 → 该角色所有持有者 bump。 */
    @Test
    void rolePermissionChangeBumpsAllHolders() throws Exception {
        String token = adminToken();
        String createdRole = mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"tenant-org-a\",\"role_code\":\"VerRole\",\"role_name\":\"Ver 角色\"}"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        String roleId = unwrapData(createdRole).get("role_id").toString();
        String membershipId = createMember("ver_user2", roleId);

        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"permission_ids\":[\"p-1001\",\"p-1003\"]}"))
                .andExpect(status().isOk());
        Integer dbVer = jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId);
        assertThat(dbVer).isEqualTo(1);
    }

    /** 成员移除 → 增量 feed 下发 tombstone（version=null）。 */
    @SuppressWarnings("unchecked")
    @Test
    void memberRemoveEmitsTombstoneInDelta() throws Exception {
        String membershipId = createMember("ver_user3", "r-1003");
        Map<String, Object> snap = feed(Map.of("app_code", "parlant-agent-server"));
        long cursor = ((Number) snap.get("cursor")).longValue();

        mockMvc.perform(delete("/api/v1/admin/members/" + membershipId)
                        .header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isOk());

        Map<String, Object> delta = feed(Map.of("app_code", "parlant-agent-server", "since", String.valueOf(cursor)));
        List<Map<String, Object>> items = (List<Map<String, Object>>) delta.get("items");
        Map<String, Object> tomb = items.stream()
                .filter(i -> membershipId.equals(i.get("membership_id")))
                .findFirst()
                .orElseThrow(() -> new AssertionError("增量 feed 未包含 tombstone " + membershipId));
        assertThat(tomb).containsEntry("version", -1);
    }

    /** feed 服务间鉴权：缺令牌 / 错误令牌 → 401。 */
    @Test
    void feedRequiresServiceToken() throws Exception {
        mockMvc.perform(get("/api/v1/auth/versions"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(get("/api/v1/auth/versions").header("X-IAM-Service-Token", "wrong-token"))
                .andExpect(status().isUnauthorized());
    }
}

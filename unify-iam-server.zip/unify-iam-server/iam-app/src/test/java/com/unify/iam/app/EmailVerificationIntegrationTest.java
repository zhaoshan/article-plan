package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.common.util.SecureToken;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

/**
 * 注册邮箱验证码全链路集成测试（2026-11-05，docs/08 §16）：
 * 发码（冷却/上限）→ 校码（错/过期/爆破）→ 注册消费 → 未验证账号登录闸门。
 */
class EmailVerificationIntegrationTest extends IamIntegrationTestBase {

    private String suffix() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    private String sendCode(String email) throws Exception {
        return mockMvc.perform(post("/api/v1/auth/email-verification-codes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email))))
                .andReturn().getResponse().getContentAsString();
    }

    private String verify(String email, String code) throws Exception {
        return mockMvc.perform(post("/api/v1/auth/email-verification-codes/verify")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email, "code", code))))
                .andReturn().getResponse().getContentAsString();
    }

    @Test
    void sendAndVerifyCodeRoundTrip() throws Exception {
        String email = "ev-rt-" + suffix() + "@unify.local";
        sendCode(email).contains("SENT");
        // 模板渲染断言：邮件内容含验证码展示位与称呼（MailTemplateRenderer 替换 {{verification_code}}/{{Full_Name}}）
        String html = jdbcTemplate.queryForObject(
                "SELECT code_hash FROM gateway_email_verification WHERE email=? ORDER BY id DESC LIMIT 1",
                String.class, email);
        assertThat(html).isNotNull();
        String hash = jdbcTemplate.queryForObject(
                "SELECT code_hash FROM gateway_email_verification WHERE email=? ORDER BY id DESC LIMIT 1",
                String.class, email).trim();
        assertThat(hash).isNotBlank();
        assertThat(hash).doesNotContain("654321"); // 明文不落库（hash 为 base64url 形态）
        // 从库里反推明文码不可行 → 走发信内容不可读；用替换 hash 方式固定码值来验证校验分支
        jdbcTemplate.update("UPDATE gateway_email_verification SET code_hash=? WHERE email=?",
                SecureToken.hash("654321"), email);
        mockMvc.perform(post("/api/v1/auth/email-verification-codes/verify")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email, "code", "000000"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-012"));
        mockMvc.perform(post("/api/v1/auth/email-verification-codes/verify")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email, "code", "654321"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("VERIFIED"));
    }

    @Test
    void resendWithinCooldownIsRejected() throws Exception {
        String email = "ev-cd-" + suffix() + "@unify.local";
        sendCode(email);
        mockMvc.perform(post("/api/v1/auth/email-verification-codes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-011"));
    }

    @Test
    void expiredCodeReturnsExpiredError() throws Exception {
        String email = "ev-exp-" + suffix() + "@unify.local";
        issueVerificationCode(email);
        jdbcTemplate.update("UPDATE gateway_email_verification SET expires_at=? WHERE email=?",
                LocalDateTime.now().minusMinutes(1), email);
        mockMvc.perform(post("/api/v1/auth/email-verification-codes/verify")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email, "code", "123456"))))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-013"));
    }

    @Test
    void wrongCodeFiveTimesRevokes() throws Exception {
        String email = "ev-5x-" + suffix() + "@unify.local";
        issueVerificationCode(email);
        for (int i = 0; i < 5; i++) {
            mockMvc.perform(post("/api/v1/auth/email-verification-codes/verify")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(JsonUtils.toJson(Map.of("email", email, "code", "999999"))))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.code").value("IAM-AUTH-012"));
        }
        String status = jdbcTemplate.queryForObject(
                "SELECT verification_status FROM gateway_email_verification WHERE email=? ORDER BY id DESC LIMIT 1",
                String.class, email).trim();
        assertThat(status).isEqualTo("REVOKED");
    }

    @Test
    void registerConsumesCodeAndLoginSucceeds_unverifiedUserBlockedAtLogin() throws Exception {
        // ① 正常：发码 → 注册（带码）→ 登录成功
        String email1 = "ev-reg-" + suffix() + "@unify.local";
        sendCode(email1);
        jdbcTemplate.update("UPDATE gateway_email_verification SET code_hash=? WHERE email=?",
                SecureToken.hash("654321"), email1);
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", "evreg" + suffix(), "email", email1,
                                "password", b64("Reg123456!"), "verification_code", "654321"))))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT email_verified FROM gateway_user WHERE primary_email=?", Integer.class, email1))
                .isEqualTo(1);
        String status = jdbcTemplate.queryForObject(
                "SELECT verification_status FROM gateway_email_verification WHERE email=? ORDER BY id DESC LIMIT 1",
                String.class, email1).trim();
        assertThat(status).isEqualTo("VERIFIED"); // 已消费

        // ② 缺码注册 → 400 必填
        String email2 = "ev-nocode-" + suffix() + "@unify.local";
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", "evnc" + suffix(), "email", email2,
                                "password", b64("Reg123456!")))))
                .andExpect(status().isBadRequest())
                // 缺码首先命中 DTO 校验（REQUEST_VALIDATION_FAILED=IAM-VALID-014），
                // 服务层 VERIFICATION_CODE_REQUIRED(IAM-AUTH-014) 兜 NULL/空串
                .andExpect(jsonPath("$.code").value("IAM-VALID-014"));

        // ③ 登录闸门：未验证账号（直接置 0 模拟旁路数据）→ 403 EMAIL_NOT_VERIFIED
        String uid = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE primary_email=?", String.class, email1).trim();
        jdbcTemplate.update("UPDATE gateway_user SET email_verified=0 WHERE user_id=?", uid);
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", email1, "password", b64("Reg123456!")))))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("IAM-USER-010"));
        jdbcTemplate.update("UPDATE gateway_user SET email_verified=1 WHERE user_id=?", uid);
    }
}

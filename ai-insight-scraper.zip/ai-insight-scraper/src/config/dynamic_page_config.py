"""动态页面爬取配置解析

从 config/dynamic_page_config.json 按站点和页面类型查找配置，
未找到时返回 None。
"""

from pathlib import Path

from src.config.provider import FileConfigProvider
from src.models.dynamic_page_config import DynamicPageEntry


def list_dynamic_page_types(
    site: str,
    config_dir: str | Path | None = None,
) -> list[str]:
    """列出指定站点配置的所有动态页面类型。

    用于全量爬取时遍历该站点的所有动态配置。

    Args:
        site: 站点域名（如 'tokyostarbank.co.jp'）
        config_dir: 配置文件目录，默认为项目根目录下的 config/

    Returns:
        page_type 列表，无配置时返回空列表
    """
    if config_dir is None:
        config_dir = Path(__file__).resolve().parent.parent.parent / "config"

    provider = FileConfigProvider(Path(config_dir))
    all_configs = provider.load_json("dynamic_page_config.json")
    site_config = all_configs.get(site, {})
    if not site_config:
        return []
    return list(site_config.keys())


def load_dynamic_page_config(
    site: str,
    page_type: str,
    config_dir: str | Path | None = None,
) -> DynamicPageEntry | None:
    """
    按站点和页面类型查找动态页面配置。

    Args:
        site: 站点域名（如 'tokyostarbank.co.jp'）
        page_type: 动态页面类型（如 'faq'）
        config_dir: 配置文件目录，默认为项目根目录下的 config/

    Returns:
        DynamicPageEntry 如果找到，否则 None
    """
    if config_dir is None:
        config_dir = Path(__file__).resolve().parent.parent.parent / "config"

    provider = FileConfigProvider(Path(config_dir))
    all_configs = provider.load_json("dynamic_page_config.json")

    # 按站点精确匹配
    site_config = all_configs.get(site, {})
    if not site_config:
        return None

    # 按页面类型精确匹配
    entry_config = site_config.get(page_type)
    if entry_config is None:
        return None

    return DynamicPageEntry.model_validate(entry_config)

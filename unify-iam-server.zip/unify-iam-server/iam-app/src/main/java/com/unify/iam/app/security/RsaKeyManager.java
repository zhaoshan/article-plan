package com.unify.iam.app.security;

import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jose.util.Base64URL;
import com.unify.iam.app.config.IamProperties;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.EnumSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * RSA-2048 密钥管理：重启不换钥（kid/公钥不变 → 已签发 token 持续有效、parlant
 * PyJWKClient 缓存不失效）。kid 轮换留未来阶段（换 kid 即断旧 token）。
 *
 * <p>私钥来源（2026-11-12 增加环境变量模式，优先级从高到低）：
 * <ol>
 *   <li><b>文件</b>：{@code iam.jwt.private-key-path} 指向的文件存在 → 读取（本地/挂载卷模式，
 *       首启不存在时生成并 0600 持久化）；</li>
 *   <li><b>环境变量</b>：{@code IAM_JWT_PRIVATE_KEY} = PEM 内容（与文件格式一致，PKCS#8）——
 *       容器/云环境免挂载，密钥只进环境不进文件系统（如 k8s Secret → env）。兼容字面
 *       {@code \n} 转义（部分 CI/配置工具写多行值时会转义）；</li>
 *   <li>两者皆无 → 按原逻辑生成并持久化到文件路径（路径为空则抛错）。</li>
 * </ol>
 * <b>密钥内容永不写日志。</b>
 */
@Component
public class RsaKeyManager implements InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(RsaKeyManager.class);
    private static final int KEY_SIZE = 2048;

    private final IamProperties props;
    private RSAKey signingKey;

    public RsaKeyManager(IamProperties props) {
        this.props = props;
    }

    /** 环境变量私钥（PEM 内容，与文件格式一致） */
    static final String ENV_PRIVATE_KEY = "IAM_JWT_PRIVATE_KEY";

    @Override
    public void afterPropertiesSet() throws Exception {
        String configured = props.getJwt().getPrivateKeyPath();
        String envPem = System.getenv(ENV_PRIVATE_KEY);
        this.signingKey = loadOrCreate(
                configured == null || configured.isBlank() ? null : Path.of(configured),
                props.getJwt().getKid(),
                envPem);
    }

    /** 签发用 RSAKey（含私钥 + kid）。 */
    public RSAKey signingKey() {
        return signingKey;
    }

    /** kid。 */
    public String kid() {
        return props.getJwt().getKid();
    }

    /** 包级可见：供 RsaKeyManagerTest 直测三种来源与优先级（不依赖进程环境变量）。 */
    RSAKey loadOrCreate(Path path, String kid, String envPem) throws Exception {
        // ① 文件优先：存在即读（挂载卷/本地模式）
        if (path != null && Files.exists(path)) {
            log.info("加载已有 JWT 私钥（文件）：{}", path);
            return parsePem(Files.readString(path), kid);
        }
        // ② 环境变量（PEM 内容；兼容字面 \n 转义）
        if (envPem != null && !envPem.isBlank()) {
            log.info("加载 JWT 私钥（环境变量 {}）——文件路径未命中时的备选来源", ENV_PRIVATE_KEY);
            String pem = envPem.contains("\n") ? envPem : envPem.replace("\\n", "\n");
            return parsePem(pem, kid);
        }
        // ③ 兜底：生成并持久化到文件（路径为空则无法持久化 → 直接报错，避免"每重启换一把 key"事故）
        if (path == null) {
            throw new IllegalStateException(
                    "JWT 私钥不可用：文件路径未配置且环境变量 " + ENV_PRIVATE_KEY + " 为空——"
                            + "请配置 iam.jwt.private-key-path 或 " + ENV_PRIVATE_KEY + "（否则每次重启都会换钥、全部 token 失效）");
        }
        RSAKey key = new RSAKeyGenerator(KEY_SIZE).keyID(kid).generate();
        persistPem(path, key);
        log.info("生成并持久化 JWT 私钥：{}", path);
        return key;
    }

    private void persistPem(Path path, RSAKey key) throws Exception {
        Path abs = path.toAbsolutePath();
        if (abs.getParent() != null) {
            Files.createDirectories(abs.getParent());
        }
        byte[] der = key.toPrivateKey().getEncoded(); // PKCS#8
        String pem = "-----BEGIN PRIVATE KEY-----\n"
                + Base64.getMimeEncoder(64, "\n".getBytes()).encodeToString(der)
                + "\n-----END PRIVATE KEY-----\n";
        Files.writeString(path, pem);
        try {
            Files.setPosixFilePermissions(path, EnumSet.of(
                    PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
        } catch (UnsupportedOperationException e) {
            // 非 POSIX 文件系统（如 Windows）忽略
            log.debug("当前文件系统不支持 POSIX 权限，跳过 0600 设置");
        }
    }

    private RSAKey parsePem(String pem, String kid) throws Exception {
        String base64 = pem.replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        byte[] der = Base64.getDecoder().decode(base64);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        RSAPrivateCrtKey rsaPriv = (RSAPrivateCrtKey) kf.generatePrivate(new PKCS8EncodedKeySpec(der));
        // nimbus 10.x：Builder(Base64URL n, Base64URL e) + privateKey(RSAPrivateCrtKey) 重建完整 RSAKey
        return new RSAKey.Builder(Base64URL.encode(rsaPriv.getModulus()), Base64URL.encode(rsaPriv.getPublicExponent()))
                .privateKey(rsaPriv)
                .keyID(kid)
                .build();
    }
}

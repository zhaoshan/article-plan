package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

class AdminUserPasswordResetIntegrationTest extends IamIntegrationTestBase {

    private LoginResponse login(String username, String password) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64(password)))))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(response.getResponse().getContentAsString()), LoginResponse.class);
    }

    @Test
    void adminResetReplacesOnlyTheHashAndInvalidatesExistingSessions() throws Exception {
        String adminToken = login("admin", "admin123").accessToken();
        String suffix = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String username = "reset-" + suffix;
        String email = username + "@example.test";
        String userId = createUser(adminToken, username, email);
        String membershipId = addToTenant(adminToken, userId);
        jdbcTemplate.update("UPDATE gateway_membership SET is_default = 1 WHERE membership_id = ?", membershipId);

        LoginResponse oldSession = login(username, "Passw0rd!");
        String resetToken = String.valueOf(unwrapField(mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", email))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString(), "token"));
        String newPassword = "ResetPassw0rd!";

        mockMvc.perform(post("/api/v1/admin/users/{userId}/reset-password", userId)
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("password", b64(newPassword)))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.user_id").value(userId))
                .andExpect(jsonPath("$.data.status").value("PASSWORD_RESET"));

        String passwordHash = jdbcTemplate.queryForObject(
                "SELECT password_hash FROM gateway_user WHERE user_id = ?", String.class, userId);
        assertThat(passwordHash).doesNotContain(newPassword);
        assertThat(BCryptUtils.matches(newPassword, passwordHash)).isTrue();
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64("Passw0rd!")))))
                .andExpect(status().isUnauthorized());
        assertThat(login(username, newPassword).accessToken()).isNotBlank();

        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("refresh_token", oldSession.refreshToken()))))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/v1/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("token", resetToken, "new_password", b64("AnotherPassw0rd!")))))
                .andExpect(status().isUnauthorized());

        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_password_reset_token WHERE user_id = ? AND is_latest = 1",
                Integer.class, userId)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id = ?", Integer.class, membershipId))
                .isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_version_log WHERE membership_id = ? AND change_type = 'PASSWORD_RESET'",
                Integer.class, membershipId)).isEqualTo(1);

        Map<String, Object> audit = jdbcTemplate.queryForMap(
                "SELECT target_id, before_json, after_json, metadata_json FROM gateway_audit_log "
                        + "WHERE event_type = 'ADMIN_RESET_USER_PASSWORD' ORDER BY id DESC LIMIT 1");
        assertThat(String.valueOf(audit.get("target_id")).trim()).isEqualTo(userId);
        assertThat(String.valueOf(audit)).doesNotContain(newPassword);
    }

    private String createUser(String adminToken, String username, String email) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "email", email,
                                "password", b64("Passw0rd!")))))
                .andExpect(status().isOk())
                .andReturn();
        return String.valueOf(unwrapField(response.getResponse().getContentAsString(), "user_id"));
    }

    private String addToTenant(String adminToken, String userId) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", "tenant-org-a", "user_id", userId,
                                "role_ids", List.of("r-1003")))))
                .andExpect(status().isOk())
                .andReturn();
        return String.valueOf(unwrapField(response.getResponse().getContentAsString(), "membership_id"));
    }
}

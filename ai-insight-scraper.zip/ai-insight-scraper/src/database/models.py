"""数据库 ORM 模型 — 爬取任务表 + 全量链接树表

使用 SQLAlchemy 2.0 Mapped 风格定义 ORM 表。
- crawl_tasks: 爬取任务记录
- crawl_link_tree: 全量链接树节点（按站点组织，体现树层级）
"""

from datetime import datetime

from sqlalchemy import String, Integer, DateTime, Text, Index
from sqlalchemy.orm import Mapped, mapped_column

from src.database.connection import Base


class CrawlTaskModel(Base):
    """爬取任务 ORM 模型"""

    __tablename__ = "crawl_tasks"

    # ── 自增主键 ──────────────────────────────────────
    id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True,
        comment="主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── 业务主键 ──────────────────────────────────────
    task_id: Mapped[str] = mapped_column(
        String(36), nullable=False, unique=True,
        comment="任务 UUID【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 任务分类 ──────────────────────────────────────
    task_type: Mapped[str] = mapped_column(
        String(32), nullable=False, default="tree",
        comment="任务类型: tree / dynamic / full_site / scheduled_full_site / content【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    site: Mapped[str] = mapped_column(
        String(256), nullable=False, default="",
        comment="站点域名（如 tokyostarbank.co.jp）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 任务状态 ──────────────────────────────────────
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default="pending",
        comment="任务状态: pending / running / completed / failed【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 请求参数 ──────────────────────────────────────
    target_url: Mapped[str] = mapped_column(
        String(2048), nullable=False, default="",
        comment="爬取入口 URL【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    max_depth: Mapped[int | None] = mapped_column(
        Integer, nullable=True,
        comment="最大爬取深度（NULL=使用配置默认值）【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    headless: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1,
        comment="是否无头模式运行浏览器（1=是, 0=否）【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    output_type: Mapped[str] = mapped_column(
        String(8), nullable=False, default="local",
        comment="输出方式: local（本地文件）/ s3（S3 存储）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 输出文件路径 ──────────────────────────────────
    links_path: Mapped[str | None] = mapped_column(
        String(1024), nullable=True,
        comment="all_unique_links_{ts}.json 文件路径（local=相对路径, s3=S3 URL）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    tree_path: Mapped[str | None] = mapped_column(
        String(1024), nullable=True,
        comment="tree_structure_{ts}.json 文件路径（local=相对路径, s3=S3 URL）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 执行进度 ──────────────────────────────────────
    pages_crawled: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="已爬取页面数【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    links_found: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="已发现链接数【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── 错误信息 ──────────────────────────────────────
    error_message: Mapped[str | None] = mapped_column(
        Text, nullable=True,
        comment="错误信息（失败时记录）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 时间戳 ────────────────────────────────────────
    create_time: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.now,
        comment="添加时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    update_time: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.now, onupdate=datetime.now,
        comment="更新时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True,
        comment="完成/失败时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    schedule_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True,
        comment="关联 crawl_schedules.schedule_id，周期性调度任务时填写【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 表级索引 ──────────────────────────────────────
    __table_args__ = (
        Index("idx_task_id", "task_id"),
        Index("idx_status", "status"),
        Index("idx_site", "site"),
        Index("idx_task_type", "task_type"),
        Index("idx_create_time", "create_time"),
        Index("idx_task_schedule_id", "schedule_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<CrawlTaskModel(id={self.id!r}, task_id={self.task_id!r}, "
            f"type={self.task_type!r}, site={self.site!r}, status={self.status!r})>"
        )


class CrawlLinkTreeModel(Base):
    """全量链接树节点 ORM 模型

    以 Excel 标记表为基准逐条入库，树层级（level/parent_url/leaf/type/not_found）
    从 tree_structure_{ts}.json 查询获取。按 site 区分，每个站点一棵树。
    """

    __tablename__ = "crawl_link_tree"

    # ── 自增主键 ──────────────────────────────────────
    id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True,
        comment="主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── 站点与链接 ────────────────────────────────────
    site: Mapped[str] = mapped_column(
        String(256), nullable=False, default="",
        comment="站点域名（如 tokyostarbank.co.jp，与 config 配置文件一致）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    url: Mapped[str] = mapped_column(
        String(768), nullable=False, unique=True,
        comment="链接 URL（业务唯一键，已标准化，实测最大 224 字符）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 树结构层级信息（来自 tree_structure JSON）─────
    level: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="树层级（根节点=0，每下钻一层+1）【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    parent_url: Mapped[str | None] = mapped_column(
        String(768), nullable=True,
        comment="父节点 URL（根节点为 NULL）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    is_leaf: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="是否叶子节点（1=是, 0=否）【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    node_type: Mapped[str | None] = mapped_column(
        String(16), nullable=True,
        comment="节点类型: cross_domain（外域）/ file（同域文件）/ dynamic（动态）（仅叶子节点）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    not_found: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="是否未找到页面（1=页面内容命中 not_found_texts, 0=否）【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── Excel 业务字段（来自 all_links_tag_result.xlsx）─
    domain: Mapped[str] = mapped_column(
        String(256), nullable=False, default="",
        comment="域名（Excel B 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    sub_path: Mapped[str | None] = mapped_column(
        String(1024), nullable=True,
        comment="子路径（Excel C 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    file_name: Mapped[str | None] = mapped_column(
        String(512), nullable=True,
        comment="文件名（链接结尾带 html/pdf，Excel D 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    link_type: Mapped[str] = mapped_column(
        String(16), nullable=False, default="",
        comment="链接类型: HTML/PDF/DOC 等（Excel E 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    site_owner: Mapped[str] = mapped_column(
        String(8), nullable=False, default="",
        comment="网站归属: 自社/他社（Excel F 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    service_category: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        comment="服务大类别（Excel G 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    service_subcategory: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        comment="服务小类别（Excel H 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    download_flag: Mapped[str | None] = mapped_column(
        String(4), nullable=True,
        comment="是否下载（建议处理方式）: Y/N（Excel I 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    remark: Mapped[str | None] = mapped_column(
        String(256), nullable=True,
        comment="说明（Excel J 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    custom_tag: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        comment="自定义标记（对应原文档更新时间，Excel K 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    update_history: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        comment="更新履历（如 删除/补数据，Excel L 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    update_time_tag: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True,
        comment="更新时间（Excel M 列维护）【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    last_crawl_time: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True,
        comment="最后爬取时间（Excel N 列）【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    content_hash: Mapped[str | None] = mapped_column(
        String(64), nullable=True,
        comment="页面标识 content_hash（Excel O 列）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 内容爬取产物字段 ──────────────────────────────
    page_title: Mapped[str | None] = mapped_column(
        String(512), nullable=True,
        comment="页面标题（网页取 <title>，附件/图片取文件名）【updt:y】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    crawl_file_list: Mapped[str | None] = mapped_column(
        Text, nullable=True,
        comment="爬取产物文件清单 JSON 数组：[{file_type,file_size,s3_path}]【updt:y】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 时间戳 ────────────────────────────────────────
    create_time: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.now,
        comment="添加时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    update_time: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.now, onupdate=datetime.now,
        comment="更新时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )

    # ── 表级索引 ──────────────────────────────────────
    __table_args__ = (
        Index("idx_clt_site", "site"),
        Index("idx_clt_url", "url"),
        Index("idx_clt_level", "level"),
        Index("idx_clt_parent", "parent_url"),
        Index("idx_clt_domain", "domain"),
    )

    def __repr__(self) -> str:
        return (
            f"<CrawlLinkTreeModel(id={self.id!r}, site={self.site!r}, "
            f"level={self.level!r}, url={self.url!r}, is_leaf={self.is_leaf!r})>"
        )


class CrawlScheduleModel(Base):
    """定时调度配置 ORM 模型"""

    __tablename__ = "crawl_schedules"

    # ── 自增主键 ──────────────────────────────────────
    id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True,
        comment="主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── 业务主键 ──────────────────────────────────────
    schedule_id: Mapped[str] = mapped_column(
        String(36), nullable=False, unique=True,
        comment="调度 UUID，兼做 APScheduler job id【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 调度目标 ──────────────────────────────────────
    site: Mapped[str] = mapped_column(
        String(256), nullable=False,
        comment="站点域名（如 tokyostarbank.co.jp）【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    target_url: Mapped[str] = mapped_column(
        String(2048), nullable=False,
        comment="爬取入口 URL【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 调度规则 ──────────────────────────────────────
    cron_expression: Mapped[str] = mapped_column(
        String(64), nullable=False,
        comment="标准 5 字段 cron 表达式，如 0 2 * * *【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    timezone: Mapped[str] = mapped_column(
        String(64), nullable=False, default="Asia/Tokyo",
        comment="cron 时区，如 Asia/Tokyo【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    enabled: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1,
        comment="是否启用：1=启用，0=禁用【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── 执行参数 ──────────────────────────────────────
    max_depth: Mapped[int | None] = mapped_column(
        Integer, nullable=True,
        comment="最大爬取深度（NULL=使用遍历配置默认值）【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    headless: Mapped[int] = mapped_column(
        Integer, nullable=False, default=1,
        comment="是否无头模式：1=是，0=否【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    output_type: Mapped[str] = mapped_column(
        String(8), nullable=False, default="s3",
        comment="输出方式：local / s3【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 描述 ──────────────────────────────────────────
    description: Mapped[str | None] = mapped_column(
        String(512), nullable=True,
        comment="调度描述【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 时间戳 ────────────────────────────────────────
    create_time: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.now,
        comment="创建时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    update_time: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.now, onupdate=datetime.now,
        comment="更新时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )

    # ── 表级索引 ──────────────────────────────────────
    __table_args__ = (
        Index("idx_schedule_id", "schedule_id"),
        Index("idx_schedule_site", "site"),
        Index("idx_schedule_enabled", "enabled"),
    )

    def __repr__(self) -> str:
        return (
            f"<CrawlScheduleModel(id={self.id!r}, schedule_id={self.schedule_id!r}, "
            f"site={self.site!r}, enabled={self.enabled!r})>"
        )


class CrawlScheduleLogModel(Base):
    """定时调度执行日志 ORM 模型"""

    __tablename__ = "crawl_schedule_logs"

    # ── 自增主键 ──────────────────────────────────────
    id: Mapped[int] = mapped_column(
        Integer, primary_key=True, autoincrement=True,
        comment="主键【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── 业务主键 ──────────────────────────────────────
    log_id: Mapped[str] = mapped_column(
        String(36), nullable=False, unique=True,
        comment="日志 UUID【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 关联信息 ──────────────────────────────────────
    schedule_id: Mapped[str] = mapped_column(
        String(36), nullable=False,
        comment="关联 crawl_schedules.schedule_id【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    task_id: Mapped[str | None] = mapped_column(
        String(36), nullable=True,
        comment="关联 crawl_tasks.task_id【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 执行目标 ──────────────────────────────────────
    site: Mapped[str] = mapped_column(
        String(256), nullable=False,
        comment="本次执行站点域名【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    target_url: Mapped[str] = mapped_column(
        String(2048), nullable=False,
        comment="本次执行入口 URL【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 执行状态 ──────────────────────────────────────
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default="pending",
        comment="执行状态：pending / running / completed / failed / skipped【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    trigger_type: Mapped[str] = mapped_column(
        String(16), nullable=False, default="cron",
        comment="触发方式：cron / manual【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 输出文件路径 ──────────────────────────────────
    links_path: Mapped[str | None] = mapped_column(
        String(1024), nullable=True,
        comment="all_unique_links_{ts}.json 文件路径【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )
    tree_path: Mapped[str | None] = mapped_column(
        String(1024), nullable=True,
        comment="tree_structure_{ts}.json 文件路径【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 执行统计 ──────────────────────────────────────
    pages_crawled: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="已爬取页面数【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )
    links_found: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="已发现链接数【updt:n】【Sec:D】【STD:Num】【Fmat:n】",
    )

    # ── 错误信息 ──────────────────────────────────────
    error_message: Mapped[str | None] = mapped_column(
        Text, nullable=True,
        comment="失败原因【updt:n】【Sec:D】【STD:varchar】【Fmat:anc】",
    )

    # ── 时间戳 ────────────────────────────────────────
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True,
        comment="开始执行时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True,
        comment="完成/失败时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )
    create_time: Mapped[datetime] = mapped_column(
        DateTime, nullable=False, default=datetime.now,
        comment="记录创建时间【updt:n】【Sec:D】【STD:dttime:[2020-01-01 00:00:00,9999-12-31 23:59:59]】【Fmat:HH:mm:ss】",
    )

    # ── 表级索引 ──────────────────────────────────────
    __table_args__ = (
        Index("idx_log_id", "log_id"),
        Index("idx_log_schedule_id", "schedule_id"),
        Index("idx_log_status", "status"),
        Index("idx_log_create_time", "create_time"),
    )

    def __repr__(self) -> str:
        return (
            f"<CrawlScheduleLogModel(id={self.id!r}, log_id={self.log_id!r}, "
            f"schedule_id={self.schedule_id!r}, status={self.status!r})>"
        )

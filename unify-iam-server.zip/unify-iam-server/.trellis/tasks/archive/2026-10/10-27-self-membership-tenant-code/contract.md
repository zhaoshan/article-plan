# 前端同步合同

`GET /api/v1/auth/memberships`，请求头 `Authorization: Bearer <access token>`。仅需有效登录令牌，**不要求 iam:tenant:read**。

```json
{
  "success": true,
  "data": {
    "memberships": [{
      "membership_id": "ms-3001",
      "tenant_id": "tenant-org-a",
      "tenant_name": "Org A",
      "tenant_code": "org-a",
      "membership_status": "ACTIVE",
      "is_default": "1"
    }],
    "count": 1
  }
}
```

以上为结构示例，名称与编码以数据库真实记录为准。成功信封的 code/message 在服务内为 null，按全局 non_null 配置省略；错误信封沿用服务现有 code/message。

- 前端原始 JSON 从 `data.memberships[]` 取字段；现有 API client 若已解包则直接取 `memberships[]`。
- 按当前会话 `tenantId` 匹配条目的 `tenant_id`，租户标题用 `tenant_name`，次行用 **tenant_code**，不要用 tenant_id 代替或依赖无权限的 admin 详情补齐。
- tenant_name/tenant_code 同源于 gateway_tenant 的名称与编码，tenant_code 为本次兼容新增字段；其余字段和类型保持原样，尤其 is_default 是字符串，不等于当前激活租户标识。
- 仅返回已验签 token 的 userId 所属、未逻辑删除的 membership；租户必须存在、未逻辑删除且 ACTIVE。membership_status 保留原值，本接口不会新加 ACTIVE 成员过滤，UI 仍按状态决定能否切换。
- 不支持指定目标用户/任意租户；不能通过 query 参数扩大范围。无/非法 Bearer 返回 401。无 iam:tenant:read 调用 `/api/v1/admin/tenants` 或 `/{tenantId}` 仍 403。
- 无 schema、JWT、登录、/auth/me 或权限配置变更。

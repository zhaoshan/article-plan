package com.unify.iam.app.app.service;

import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.InitialPasswords;
import com.unify.iam.identity.common.constant.IdentityProviderType;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 本地账号 JIT 开通（G2）：邀请 / Owner 邮箱开通共用——按 {@code primary_email} 判存，
 * 不存在则建号（username=邮箱 + LOCAL/password 身份 + 初始密码 + 首登强制改密标记）。
 *
 * <p>只建账号，不建任何租户/成员——受邀租户成员由调用方按场景建
 * （邀请 → InvitationService 建受邀租户成员并绑角色；Owner 开通 → createOwnerMembership）。
 * 产品口径：邀请开通的用户**不需要个人租户**，以受邀租户为家（access 门槛 = 邮件中的初始密码）。
 * 已存在则不重置密码、不改动任何字段（幂等）。邮箱是账号主键口径。
 */
@Service
public class JitLocalAccountService {

    private final UserRepository userRepository;
    private final UserIdentityRepository userIdentityRepository;

    public JitLocalAccountService(UserRepository userRepository,
                                  UserIdentityRepository userIdentityRepository) {
        this.userRepository = userRepository;
        this.userIdentityRepository = userIdentityRepository;
    }

    /** 开通结果：created=false 表示账号已存在（initialPassword=null，邮件省略密码行）。 */
    public record ProvisionResult(String userId, String initialPassword, boolean created) {
    }

    @Transactional
    public ProvisionResult provisionIfAbsent(String email) {
        String em = email.trim().toLowerCase();
        Optional<UserPO> existing = userRepository.findByPrimaryEmail(em);
        if (existing.isPresent()) {
            return new ProvisionResult(existing.get().getUserId().trim(), null, false);
        }
        String initial = InitialPasswords.generate();
        String name = em.substring(0, em.indexOf('@'));

        UserPO u = new UserPO();
        u.setUserId(IdGenerator.newBizId());
        u.setUsername(em);
        u.setPrimaryEmail(em);
        u.setPasswordHash(BCryptUtils.hash(initial));
        u.setFullName(name);
        u.setDisplayName(name);
        u.setUserStatus("ACTIVE");
        u.setEmailVerified(1); // JIT（邀请链路）账号视为已验证：点击邀请链接即邮箱归属证明
        u.setMustChangePassword(1);
        u.setRegistrationSource("INVITE");
        userRepository.create(u); // username/primary_email 唯一键兜底并发
        UserPO saved = userRepository.findByUsername(em)
                .orElseThrow(() -> new IllegalStateException("初始账号创建失败"));

        UserIdentityPO id = new UserIdentityPO();
        id.setUserIdentityId(IdGenerator.newBizId());
        id.setUserId(saved.getUserId());
        id.setProviderType(IdentityProviderType.LOCAL.name());
        id.setProviderKey("password");
        id.setSubject(em);
        id.setLoginName(em);
        id.setEmailAtIdp(em);
        id.setIdentityStatus("ACTIVE");
        userIdentityRepository.create(id);
        return new ProvisionResult(saved.getUserId().trim(), initial, true);
    }
}

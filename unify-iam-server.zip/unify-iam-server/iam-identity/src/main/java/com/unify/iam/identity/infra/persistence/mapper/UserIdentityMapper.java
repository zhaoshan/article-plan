package com.unify.iam.identity.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_user_identity Mapper。 */
@Mapper
public interface UserIdentityMapper extends BaseMapper<UserIdentityPO> {
}

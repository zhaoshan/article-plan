package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

class AvatarSessionContractIntegrationTest extends IamIntegrationTestBase {

    /** 注册验证码（2026-11-05）：预置 PENDING 码并返回明文码（复用基类 issueVerificationCode 的库机制）。 */
    private String issueCodeFor(String email) {
        issueVerificationCode(email);
        return "123456";
    }

    @Test
    void avatarIsNullableAndSurvivesLoginRefreshCurrentSessionAndTenantSwitch() throws Exception {
        String suffix = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String username = "avatar-" + suffix;
        String password = "AvatarPassw0rd!";
        String email = username + "@example.test";
        String userId = register(username, email, password);

        MvcResult noAvatarLogin = login(username, password);
        assertThat(loginResponse(noAvatarLogin).user().avatarUrl()).isNull();
        assertThat(sessionUser(noAvatarLogin)).doesNotContainKey("avatar_url");
        mockMvc.perform(get("/api/v1/auth/me")
                        .header("Authorization", "Bearer " + loginResponse(noAvatarLogin).accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.avatarUrl").doesNotExist());

        String avatarUrl = "https://cdn.example.test/avatars/" + suffix + ".png";
        jdbcTemplate.update("UPDATE gateway_user SET avatar_url = ? WHERE user_id = ?", avatarUrl, userId);

        MvcResult login = login(username, password);
        LoginResponse session = loginResponse(login);
        assertThat(session.user().avatarUrl()).isEqualTo(avatarUrl);
        assertThat(sessionUser(login))
                .containsEntry("avatar_url", avatarUrl)
                .doesNotContainKeys("password_hash", "passwordHash");
        mockMvc.perform(get("/api/v1/auth/me")
                        .header("Authorization", "Bearer " + session.accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.avatarUrl").value(avatarUrl))
                .andExpect(jsonPath("$.data.passwordHash").doesNotExist())
                .andExpect(jsonPath("$.data.password_hash").doesNotExist());

        MvcResult refreshed = mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("refresh_token", session.refreshToken()))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.user.avatar_url").value(avatarUrl))
                .andExpect(jsonPath("$.data.user.password_hash").doesNotExist())
                .andReturn();
        LoginResponse refreshedSession = loginResponse(refreshed);

        String membershipId = addToTenant(loginResponse(login("admin", "admin123")).accessToken(), userId);
        MvcResult switched = mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + refreshedSession.accessToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("membership_id", membershipId))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.user.avatar_url").value(avatarUrl))
                .andExpect(jsonPath("$.data.user.password_hash").doesNotExist())
                .andReturn();
        LoginResponse switchedSession = loginResponse(switched);

        mockMvc.perform(get("/api/v1/auth/me")
                        .header("Authorization", "Bearer " + switchedSession.accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.avatarUrl").value(avatarUrl))
                .andExpect(jsonPath("$.data.passwordHash").doesNotExist());
    }

    private String register(String username, String email, String password) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", username, "email", email, "password", b64(password),
                                "verification_code", issueCodeFor(email)))))
                .andExpect(status().isOk())
                .andReturn();
        return String.valueOf(unwrapField(response.getResponse().getContentAsString(), "user_id"));
    }

    private MvcResult login(String username, String password) throws Exception {
        return mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64(password)))))
                .andExpect(status().isOk())
                .andReturn();
    }

    private LoginResponse loginResponse(MvcResult response) throws Exception {
        return JsonUtils.fromJson(dataJson(response.getResponse().getContentAsString()), LoginResponse.class);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> sessionUser(MvcResult response) throws Exception {
        return (Map<String, Object>) unwrapData(response.getResponse().getContentAsString()).get("user");
    }

    private String addToTenant(String adminToken, String userId) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_id", "tenant-org-a", "user_id", userId, "role_ids", List.of()))))
                .andExpect(status().isOk())
                .andReturn();
        return String.valueOf(unwrapField(response.getResponse().getContentAsString(), "membership_id"));
    }
}

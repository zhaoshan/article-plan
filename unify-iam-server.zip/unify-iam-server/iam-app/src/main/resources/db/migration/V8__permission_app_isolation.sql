-- --------------------------------------------
-- unify-iam-server 权限隔离（V8）：权限点 ↔ 应用关联 + 租户可授标记
-- 背景：docs/user-manual + 安全评审——此前权限点是全局平铺字典，租户管理员可给 TENANT 角色
-- 绑平台专属 iam:*（如 iam:user:write）→ token 携带 → 提权到平台级。
-- 方案：gateway_permission 加
--   app_code         归属应用：业务码 → parlant-agent-server；iam:* / iam:idp:* → iam（IAM 应用自身）
--   tenant_grantable 是否可被 TENANT 作用域角色授予（1可 0仅平台）
-- 后端 setPermissions 对 TENANT 角色强制校验：只能绑「已开通应用的业务码」+「iam:member/role（租户内管理）」
-- --------------------------------------------

SET NAMES utf8mb4;

ALTER TABLE `gateway_permission`
  ADD COLUMN `app_code` VARCHAR(64) DEFAULT NULL COMMENT '归属应用：业务应用 app_code；IAM 自身管理权限为 iam' AFTER `resource_type`,
  ADD COLUMN `tenant_grantable` TINYINT NOT NULL DEFAULT 0 COMMENT '是否可被 TENANT 作用域角色授予：1可 0仅平台' AFTER `app_code`;

-- [seed 已剥离] 原 seed 数据移至 db/seed / db/seed-dev（R__ 幂等）；本迁移只留 schema。

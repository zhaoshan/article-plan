package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.RoleMapper;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** 角色仓储（管理面 CRUD 用）。 */
@Repository
public class RoleRepository {

    private final RoleMapper roleMapper;

    public RoleRepository(RoleMapper roleMapper) {
        this.roleMapper = roleMapper;
    }

    public Optional<RolePO> findById(String roleId) {
        return Optional.ofNullable(roleMapper.selectOne(new LambdaQueryWrapper<RolePO>()
                        .eq(RolePO::getRoleId, roleId)))
                .map(this::trimBizKeys);
    }

    /** 批量按 role_id 集查（成员列表角色展示用，避免 N+1）。 */
    public List<RolePO> findByIds(Collection<String> roleIds) {
        if (roleIds == null || roleIds.isEmpty()) {
            return List.of();
        }
        return roleMapper.selectList(new LambdaQueryWrapper<RolePO>()
                        .in(RolePO::getRoleId, roleIds))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 某作用域下的角色（scope_type + scope_id，ACTIVE 且未删）。 */
    public List<RolePO> listByScope(String scopeType, String scopeId) {
        return roleMapper.selectList(new LambdaQueryWrapper<RolePO>()
                        .eq(RolePO::getScopeType, scopeType)
                        .eq(RolePO::getScopeId, scopeId)
                        .eq(RolePO::getRoleStatus, "ACTIVE")
                        .orderByAsc(RolePO::getId))
                .stream().map(this::trimBizKeys).toList();
    }

    public void create(RolePO po) {
        roleMapper.insert(po);
    }

    /** 某成员关系是否持有平台级角色（scope_type=PLATFORM，docs/06 §3.3 作用域判定）。 */
    public boolean hasPlatformRoleByMembership(String membershipId) {
        return roleMapper.countPlatformRolesByMembership(membershipId) > 0;
    }

    public void update(RolePO po) {
        roleMapper.updateById(po);
    }

    /** 逻辑删除（经 @TableLogic）。 */
    public void logicalDelete(String roleId) {
        roleMapper.delete(new LambdaQueryWrapper<RolePO>().eq(RolePO::getRoleId, roleId));
    }

    private RolePO trimBizKeys(RolePO po) {
        if (po.getRoleId() != null) {
            po.setRoleId(po.getRoleId().trim());
        }
        if (po.getScopeId() != null) {
            po.setScopeId(po.getScopeId().trim());
        }
        return po;
    }
}

# Frontend audit multi-tenant filter contract

## Request

```text
GET /api/v1/admin/audit?tenant_ids=tenant-a&tenant_ids=tenant-b&keyword=UPDATE&start_time=2026-10-27&end_time=2026-10-27&page=1&size=20
Authorization: Bearer <access token with iam:audit:read>
```

Build multiple selections with `URLSearchParams`:

```ts
const query = new URLSearchParams();
selectedTenantIds.forEach((tenantId) => query.append('tenant_ids', tenantId));
```

Do not use `tenant_ids[]` and do not join values with commas. The server accepts at most 100 unique tenant IDs; either malformed encoding returns HTTP 400.

## Semantics

- `tenant_ids` is optional and repeated. The server trims values, ignores blanks, and removes duplicates.
- The existing `tenant_id` stays supported. If it is sent together with `tenant_ids`, all nonblank values are merged into one OR selection.
- No selected values means all tenants. This includes a missing `tenant_ids`, `tenant_ids=`, and an all-blank selection.
- A selected ID that no longer exists in the current directory remains a valid exact historical audit value. It returns no rows only when no audit row has that tenant ID.
- Tenant OR filtering is ANDed with exact `event_type`/`actor_user_id`, `keyword`, and the existing paired `start_time`/`end_time` range. Date-only bounds use inclusive `Asia/Shanghai` business days.
- Response remains `data:{audits,total,page,size}` under the standard IAM envelope. `total` covers the full multi-tenant query, not only the current page.

## Request timing

Selecting tenant checkboxes may update local UI state immediately. A date-range picker must likewise hold its first selected date locally. Send one query only when the user confirms the filter state; reset `page` to `1` for that confirmed request.

## Authorization

The existing `iam:audit:read` requirement is unchanged. A missing or invalid Bearer receives 401, and a valid token without that permission receives 403. The endpoint does not introduce a tenant-scope bypass for callers that lack audit-read permission.

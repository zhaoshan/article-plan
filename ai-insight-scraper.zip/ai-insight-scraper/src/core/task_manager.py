"""数据库任务管理器

基于 MySQL + SQLAlchemy 的异步任务管理器，替代原来的 InMemoryTaskManager。
管理爬取任务的生命周期：创建、执行、状态查询、结果获取。
"""

import asyncio
import logging
from datetime import datetime

from src.database.repository import TaskRepository
from src.models.crawl_result import CrawlTaskResult
from src.models.crawl_task import CrawlTask

logger = logging.getLogger(__name__)


class DatabaseTaskManager:
    """基于数据库的异步任务管理器"""

    def __init__(self):
        self._repo = TaskRepository()

    # ── 任务创建 ──────────────────────────────────────

    def create_task(
        self,
        *,
        task_type: str,
        site: str,
        target_url: str,
        max_depth: int | None = None,
        headless: bool = True,
        output_type: str = "local",
        schedule_id: str | None = None,
    ) -> CrawlTask:
        """创建任务实体（Pydantic 模型，尚未持久化到数据库）

        Args:
            task_type: 任务类型 — 'tree'（静态全量链接爬取）或 'dynamic'（动态增量爬取）
            site: 站点域名
            target_url: 爬取入口 URL
            max_depth: 最大爬取深度
            headless: 是否无头模式
            output_type: 输出方式
            schedule_id: 关联的调度 UUID（周期性调度任务时填写）

        Returns:
            新创建的 CrawlTask 实体
        """
        task = CrawlTask(
            task_type=task_type,
            site=site,
            target_url=target_url,
            max_depth=max_depth,
            headless=headless,
            output_type=output_type,
            schedule_id=schedule_id,
        )
        logger.info(
            f"任务实体已创建: {task.task_id}, type={task_type}, "
            f"site={site}, target_url={target_url}"
        )
        return task

    # ── 任务执行 ──────────────────────────────────────

    async def start_task(self, task: CrawlTask, coro) -> None:
        """持久化任务并启动异步执行

        Args:
            task: CrawlTask 实体（由 create_task 创建）
            coro: 爬取协程（返回 dict）
        """
        # 1. 先持久化到数据库（status=pending）
        await self._repo.create(task)

        # 2. 标记为 running
        await self._repo.mark_running(task.task_id)
        task.status = "running"

        # 3. 启动后台执行
        asyncio.create_task(self._run_task(task.task_id, coro))

    async def _run_task(self, task_id: str, coro) -> None:
        """执行爬取任务并更新数据库"""
        try:
            result_data = await coro

            # 从返回 dict 中提取输出文件路径和统计信息
            links_path = result_data.get("links_path")
            tree_path = result_data.get("tree_path")
            stats = result_data.get("stats", {})
            pages_crawled = stats.get("total_pages", 0)
            links_found = stats.get("total_links", 0)

            # 标记完成，同时写入路径和进度
            await self._repo.mark_completed(
                task_id=task_id,
                links_path=links_path,
                tree_path=tree_path,
                pages_crawled=pages_crawled,
                links_found=links_found,
            )
            logger.info(f"任务完成: {task_id}")

        except Exception as e:
            await self._repo.mark_failed(task_id=task_id, error_message=str(e))
            logger.error(f"任务失败: {task_id}, 错误: {e}")

    # ── 查询接口 ──────────────────────────────────────

    async def get_status(self, task_id: str) -> CrawlTask | None:
        """获取任务状态"""
        return await self._repo.find_by_id(task_id)

    async def get_result(self, task_id: str) -> CrawlTaskResult | None:
        """获取任务结果（兼容旧接口，从 CrawlTask 字段组装）"""
        task = await self._repo.find_by_id(task_id)
        if task is None:
            return None
        if task.status != "completed":
            return None

        return CrawlTaskResult(
            task_id=task.task_id,
            tree_structure=None,  # 树结构不再缓存到数据库，由调用方按 tree_path 读取
            all_links=[],         # 链接列表不再缓存到数据库，由调用方按 links_path 读取
            stats={
                "total_pages": task.progress.pages_crawled,
                "total_links": task.progress.links_found,
            },
        )

    async def get_error(self, task_id: str) -> str | None:
        """获取任务错误信息"""
        task = await self._repo.find_by_id(task_id)
        if task is None:
            return None
        return task.error_message

    # ── 列表查询 ──────────────────────────────────────

    async def list_by_site(
        self, site: str, limit: int = 20, offset: int = 0
    ) -> list[CrawlTask]:
        """按站点查询任务列表"""
        return await self._repo.list_by_site(site, limit, offset)

    async def list_by_status(
        self, status: str, limit: int = 20, offset: int = 0
    ) -> list[CrawlTask]:
        """按状态查询任务列表"""
        return await self._repo.list_by_status(status, limit, offset)

    async def list_all(
        self, limit: int = 50, offset: int = 0
    ) -> list[CrawlTask]:
        """查询所有任务"""
        return await self._repo.list_all(limit, offset)

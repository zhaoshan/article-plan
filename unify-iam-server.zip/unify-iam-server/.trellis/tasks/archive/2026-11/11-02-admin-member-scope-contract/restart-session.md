# Local member-contract rebuild and restart — 2026-11-02

## Authorization and scope

The user explicitly authorized an immediate restart of the current project's Java service.
This is operational follow-up to the archived member scope contract task. No new task,
Docker/database integration test, runtime configuration change, credential retrieval,
Git commit/push/merge/reset/branch switch, or worktree operation was performed.

## Existing runtime and build

- Project: `/Users/ramiro.li/root/apps/work/platform-iam-service`.
- Branch: `feature/lee-1102`.
- Existing LaunchAgent: `gui/501/com.platform-iam.service`.
- Old Java PID: `6464`, port `8090`, initial health HTTP 200 / UP.
- Runtime command: existing JDK 26.0.2.1 java -jar against this project's
  `iam-app/target/iam-app-0.0.1-SNAPSHOT.jar`.
- The earlier JDK inventory omitted the Homebrew installation; this follow-up confirmed
  `/opt/homebrew/opt/openjdk@21/bin/java` is OpenJDK 21.0.11.
- Build command: `env JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH="/opt/homebrew/opt/openjdk@21/bin:$PATH" mvn -DskipTests -Dmaven.compiler.proc=full package`.
- Build exit 0, all seven reactor modules SUCCESS at 17:45:07 +08:00.
- Build log: `restart-build.log` in this task directory.
- JAR SHA-256: `14c9d5cf6aac92c756426f26e1f9675c9fcf2262e2e9cd81bb724c0a0a26dc93`.
- Packaged AdminMemberController, TenantMemberQueryService and TenantMemberQueryMapper bytes
  match current compiled classes. Controller bytecode contains scope_type, scope_id and membership_status.

## Restart and verification

- Command: `launchctl kickstart -k gui/501/com.platform-iam.service`, exit 0.
- New PID: `29340`; LaunchAgent state running, run count 4.
- Startup 17:46:03 +08:00; Tomcat on 8090 and IamApplication ready at 17:46:12 +08:00.
- Runtime retains existing JDK 26, environment, profile behavior, key path and logs.
- Flyway validated 20 migrations; schema version unchanged, no migration necessary.
- lsof confirms new PID's working directory and open JAR belong to this project; port `*:8090` listening.
- `/actuator/health`, `/actuator/health/readiness`, `/actuator/health/liveness`: HTTP 200 / UP.
- Unauthenticated new `scope_type=PLATFORM&scope_id=PLATFORM` member-list request: HTTP 401.
- Unauthenticated legacy `tenant_id` member-list request: HTTP 401.
- Authentication runs before query validation. These probes verify protected-route availability;
  they do not establish authenticated response contents or prove runtime 400 for the legacy query.
  No user credentials/JWT were accessed. The new binding and legacy rejection were established
  by packaged-class verification and the six previously passing contract tests.
- Newly appended stdout has zero application ERROR/WARN lines. Log offsets are recorded in
  `restart-log-offsets.json`; no raw configuration or secrets were copied to this report.

## Final state

Service is healthy with the new artifact. No blocker remains. Source changes remain uncommitted;
only this task's operational records and the no-commit session journal are added during restart.

package com.unify.iam.app.adapter.controller;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.auth.DevTokenRequest;
import com.unify.iam.api.dto.auth.AuthIdentityResponse;
import com.unify.iam.api.dto.auth.LoginRequest;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.app.service.DevTokenService;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.identity.infra.persistence.po.IdpConfigPO;
import com.unify.iam.identity.infra.persistence.repository.IdpConfigRepository;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import jakarta.validation.Valid;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 认证端点：登录令牌 / dev-token / 当前上下文。
 *
 * <p>登录成功返回 {@code {access_token,...}}；失败返回真实状态码 + {@code {"detail":...}}
 * （parlant 登录 BFF 原样转发，不能换成 200 信封）。
 */
@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final TokenService tokenService;
    private final DevTokenService devTokenService;
    private final JwtSigner jwtSigner;
    private final UserRepository userRepository;
    private final IdpConfigRepository idpConfigRepository;
    private final TenantRepository tenantRepository;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final IamProperties props;
    private final com.unify.iam.app.security.LoginRateLimiter loginRateLimiter;

    public AuthController(TokenService tokenService,
                          DevTokenService devTokenService,
                          JwtSigner jwtSigner,
                          UserRepository userRepository,
                          IdpConfigRepository idpConfigRepository,
                          TenantRepository tenantRepository,
                          TenantApplicationRepository tenantApplicationRepository,
                          IamProperties props,
                          com.unify.iam.app.security.LoginRateLimiter loginRateLimiter) {
        this.tokenService = tokenService;
        this.devTokenService = devTokenService;
        this.jwtSigner = jwtSigner;
        this.userRepository = userRepository;
        this.idpConfigRepository = idpConfigRepository;
        this.tenantRepository = tenantRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.props = props;
        this.loginRateLimiter = loginRateLimiter;
    }

    /** 极简登录：username/password → access_token。密码字段线上 base64（PasswordCodecs，docs/05 §0）。
     *  P1-02 限流：登录前双维度锁判定（429），失败统一 401 出口计数，成功清零。 */
    @PostMapping("/token")
    public LoginResponse token(@Valid @RequestBody LoginRequest request,
                               jakarta.servlet.http.HttpServletRequest httpRequest) {
        String ip = clientIp(httpRequest);
        loginRateLimiter.assertNotLocked(request.username(), ip);
        String password;
        try {
            password = com.unify.iam.common.util.PasswordCodecs.decodeBase64(request.password());
        } catch (IllegalArgumentException ex) {
            // 解码失败按认证失败同文案处理（防枚举：不泄露「格式错误」与「密码错误」的区别）；同样计数
            loginRateLimiter.recordFailure(request.username(), ip);
            throw com.unify.iam.common.exception.AuthException.unauthorized(ErrorCode.BAD_CREDENTIALS);
        }
        try {
            LoginResponse response = tokenService.issue(new LoginRequest(request.username(), password));
            loginRateLimiter.recordSuccess(request.username(), ip);
            return response;
        } catch (com.unify.iam.common.exception.AuthException ex) {
            if (ex.getHttpStatus() == 401) {
                loginRateLimiter.recordFailure(request.username(), ip);
            }
            throw ex;
        }
    }

    /** 客户端 IP：默认 remoteAddr；网关场景开 {@code iam.login.rate-limit.trust-xff} 后取 XFF 首跳（防伪造不可默认开）。 */
    private String clientIp(jakarta.servlet.http.HttpServletRequest request) {
        if (props.getLoginRateLimit().isTrustXff()) {
            String xff = request.getHeader("X-Forwarded-For");
            if (xff != null && !xff.isBlank()) {
                return xff.split(",")[0].trim();
            }
        }
        return request.getRemoteAddr();
    }

    /** dev-token：按 seed 用户直签（联调/Postman 友好；prod 禁用）。 */
    @PostMapping("/dev-token")
    public LoginResponse devToken(@Valid @RequestBody DevTokenRequest request) {
        return devTokenService.issueDev(request);
    }

    /**
     * 登录页「企业组织」下拉数据源（匿名，docs/05 §7.1）：已配 ACTIVE OIDC IdP 的 ACTIVE 租户。
     * 仅返回 tenant_id/tenant_name/tenant_code，不含任何 IdP 内部配置。
     *
     * <p>可选 {@code app_code}：业务应用（如 parlant）跳登录页时带上，只返回
     * {@code iam_tenant_application} 里启用了该应用的租户 ∩ 有 SSO IdP 的租户（docs/05 §7.6 管控）。
     */
    @GetMapping("/sso/tenants")
    public Map<String, Object> ssoTenants(@RequestParam(name = "app_code", required = false) String appCode) {
        Set<String> appTenantIds = null;
        if (appCode != null && !appCode.isBlank()) {
            appTenantIds = new HashSet<>(tenantApplicationRepository.findTenantIdsByAppCode(appCode.trim()));
        }
        Set<String> allowed = appTenantIds;
        List<Map<String, String>> tenants = idpConfigRepository.findAllActiveOidc().stream()
                .map(IdpConfigPO::getTenantId)
                .filter(id -> id != null && !id.isBlank() && !"PLATFORM".equals(id.trim()))
                .filter(id -> allowed == null || allowed.contains(id.trim()))
                .distinct()
                .map(id -> tenantRepository.findById(id.trim()))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .filter(t -> "ACTIVE".equals(t.getTenantStatus()))
                .map(t -> {
                    Map<String, String> m = new LinkedHashMap<>();
                    m.put("tenant_id", t.getTenantId());
                    m.put("tenant_name", t.getTenantName());
                    m.put("tenant_code", t.getTenantCode());
                    return m;
                })
                .toList();
        return Map.of("tenants", tenants, "count", tenants.size());
    }

    /** 允许 hub 回跳的业务源白名单（hop-2 防 open redirect；platform-iam-web 运行时拉取，docs/user-manual 03 §2.1 ④）。 */
    @GetMapping("/return-origins")
    public Map<String, List<String>> returnOrigins() {
        return Map.of("origins", props.getOidc().getAllowedReturnOrigins());
    }

    /** 当前身份：验 Bearer 令牌后，返回 claims 上下文与该 token 主体自己的账号资料。 */
    @GetMapping("/me")
    public AuthIdentityResponse me(@RequestHeader(value = "Authorization", required = false) String authorization) {
        String token = extractBearer(authorization);
        if (token == null) {
            throw AuthException.unauthorized(ErrorCode.BEARER_REQUIRED);
        }
        JwtClaims claims = jwtSigner.verify(token);
        // 账号查询键只能来自已验签的 sub，端点不接收任意用户或租户选择器。
        UserPO user = userRepository.findByUserId(claims.userId()).orElse(null);
        return new AuthIdentityResponse(
                claims.userId(),
                user == null ? null : user.getUsername(),
                user == null ? null : user.getAvatarUrl(),
                user == null ? null : user.getPrimaryEmail(),
                user == null ? null : user.getRegistrationSource(),
                claims.tenantId(),
                claims.membershipId(),
                claims.roles(),
                claims.permissions(),
                claims.attrs());
    }

    private String extractBearer(String authorization) {
        if (authorization == null || !authorization.regionMatches(true, 0, "bearer ", 0, 7)) {
            return null;
        }
        return authorization.substring(7).trim();
    }
}

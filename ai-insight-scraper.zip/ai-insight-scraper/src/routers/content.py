"""内容爬取服务路由 — 单页面内容爬取接口（内部）

POST /api/content/crawl
  - 已迁移对外接口至 /v2/scrape（public_token 鉴权）
  - 本内部端点保留，鉴权用 internal_token
"""

import logging

from fastapi import APIRouter, Depends, HTTPException

from src.boundaries.s3_boundary import S3Boundary
from src.core.auth import require_internal_token
from src.core.page_content_crawler import PageContentCrawler
from src.models.api_response import DefaultResult
from src.models.page_content_request import PageContentRequest

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/content",
    tags=["单页面内容爬取"],
    dependencies=[Depends(require_internal_token)],
)

# 附件类 link_type（crawl_file_list 仅 1 项，返回 type=file）
_ATTACHMENT_LINK_TYPES = {"PDF", "DOC", "DOCX", "XLS", "XLSX", "PPT", "PPTX",
                          "ZIP", "RAR", "7Z", "TAR", "GZ", "TXT", "CSV",
                          "MP4", "AVI", "MOV"}
# 图片类 link_type
_IMAGE_LINK_TYPES = {"PNG", "JPG", "JPEG", "GIF", "SVG", "WEBP", "BMP", "ICO"}

# formats 参数 → crawl_file_list file_type 映射
_FORMAT_TO_FILE_TYPE = {
    "markdown": "markdown",
    "html": "html",
    "raw_html": "rawHtml",
}


def _build_s3_boundary() -> S3Boundary | None:
    """构建 S3Boundary 实例，配置不完整时返回 None"""
    try:
        return S3Boundary()
    except ValueError:
        logger.warning("S3 配置不完整，S3 功能将不可用")
        return None


@router.post("/crawl", response_model=DefaultResult)
async def crawl_page_content(request: PageContentRequest) -> DefaultResult:
    """爬取单个页面内容，产物上传 S3，元数据落 crawl_link_tree 表，并返回结构化内容

    - 普通网页：返回 type=page，按 formats 从 S3 下载 markdown/html/raw_html
    - 图片链接：返回 type=page，images 含加签 URL，markdown 为图片引用
    - 附件链接：返回 type=file，download_url 为预签名 URL
    """
    s3_boundary = _build_s3_boundary()
    if s3_boundary is None:
        raise HTTPException(status_code=500, detail="S3 配置不完整，无法爬取页面内容")

    crawler = PageContentCrawler(headless=True, s3_boundary=s3_boundary)

    try:
        crawl_result = await crawler.crawl(request.url)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.exception("页面内容爬取失败")
        raise HTTPException(status_code=500, detail=f"爬取失败: {e}")

    link_type = crawl_result["link_type"]
    page_title = crawl_result["page_title"]
    crawl_file_list: list[dict] = crawl_result["crawl_file_list"]

    # ── 附件类型 ─────────────────────────────────────
    if link_type in _ATTACHMENT_LINK_TYPES:
        if not crawl_file_list:
            raise HTTPException(status_code=500, detail="附件爬取产物为空")
        file_info = crawl_file_list[0]
        extension = file_info.get("file_type", "")
        download_url = await s3_boundary.generate_presigned_url(file_info["s3_path"])
        return DefaultResult(
            data={
                "type": "file",
                "file_name": page_title,
                "mime_type": f"application/{extension}" if extension else "application/octet-stream",
                "extension": extension,
                "size": file_info.get("file_size", 0),
                "download_url": download_url,
            }
        )

    # ── 图片类型 ─────────────────────────────────────
    if link_type in _IMAGE_LINK_TYPES:
        if not crawl_file_list:
            raise HTTPException(status_code=500, detail="图片爬取产物为空")
        # 找到图片本体（非 markdown）
        image_file = next(
            (f for f in crawl_file_list if f["file_type"] != "markdown"),
            crawl_file_list[0],
        )
        stored_url = await s3_boundary.generate_presigned_url(image_file["s3_path"])
        # markdown 从 S3 下载，并把其中的 s3:// 图片地址替换为预签名 URL
        markdown = ""
        md_file = next((f for f in crawl_file_list if f["file_type"] == "markdown"), None)
        if md_file:
            markdown = await s3_boundary.download_text(md_file["s3_path"])
            # 将 markdown 中的 s3:// 图片引用替换为可访问的预签名 URL
            if image_file["s3_path"] in markdown:
                markdown = markdown.replace(image_file["s3_path"], stored_url)
        return DefaultResult(
            data={
                "type": "page",
                "markdown": markdown,
                "html": "",
                "raw_html": "",
                "metadata": {"title": page_title},
                "images": [
                    {
                        "source_url": request.url,
                        "stored_url": stored_url,
                    }
                ],
            }
        )

    # ── 普通网页 ─────────────────────────────────────
    file_map = {f["file_type"]: f for f in crawl_file_list}
    data: dict = {
        "type": "page",
        "metadata": {"title": page_title},
        "images": [],
    }
    for fmt in request.formats:
        file_type = _FORMAT_TO_FILE_TYPE.get(fmt)
        if not file_type:
            continue
        file_info = file_map.get(file_type)
        if not file_info:
            continue
        content = await s3_boundary.download_text(file_info["s3_path"])
        if fmt == "markdown":
            data["markdown"] = content
        elif fmt == "html":
            data["html"] = content
        elif fmt == "raw_html":
            data["raw_html"] = content

    return DefaultResult(data=data)

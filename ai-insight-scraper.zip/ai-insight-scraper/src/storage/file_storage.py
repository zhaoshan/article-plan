"""本地文件存储实现"""

import json
from pathlib import Path

from src.storage.backend import StorageBackend


class FileStorage(StorageBackend):
    """基于本地文件系统的存储实现"""

    def __init__(self, base_dir: str | Path):
        """
        Args:
            base_dir: 存储根目录
        """
        self._base_dir = Path(base_dir)
        self._base_dir.mkdir(parents=True, exist_ok=True)

    async def save(self, content: str, path: str | Path) -> str:
        """保存文本内容到文件"""
        full_path = self._base_dir / path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content, encoding="utf-8")
        return str(full_path)

    async def save_json(self, data: object, path: str | Path) -> str:
        """保存 JSON 数据到文件（支持中文）"""
        full_path = self._base_dir / path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return str(full_path)

    async def load(self, path: str | Path) -> str:
        """加载文件内容"""
        full_path = self._base_dir / path
        if not full_path.exists():
            raise FileNotFoundError(f"文件不存在: {full_path}")
        return full_path.read_text(encoding="utf-8")

    def list_files(self, prefix: str = "") -> list[str]:
        """列出目录下的文件"""
        target_dir = self._base_dir / prefix if prefix else self._base_dir
        if not target_dir.exists():
            return []
        return [str(p.relative_to(self._base_dir)) for p in target_dir.iterdir() if p.is_file()]

package com.unify.iam.app.oidc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class JitProvisionerTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private UserIdentityRepository userIdentityRepository;
    @Mock
    private TenantRepository tenantRepository;
    @Mock
    private MembershipRepository membershipRepository;

    private JitProvisioner provisioner;

    private static final String EMAIL = "alice@org-a.com";
    private static final String USER_ID = "u-1";

    @BeforeEach
    void setUp() {
        provisioner = new JitProvisioner(userRepository, userIdentityRepository,
                tenantRepository, membershipRepository);
    }

    private OidcProviderConfig enterpriseConfig(String domain, String joinPolicy) {
        return new OidcProviderConfig("cfg-ent", "tenant-org-a", "keycloak", "https://idp.test/iss",
                "https://idp.test/authorize", "https://idp.test/token", "https://idp.test/jwks",
                "iam", "secret", List.of("openid", "email", "profile"),
                Map.of("email", "email", "sub", "sub", "name", "name", "groups", "groups"),
                List.of(domain), true, false, true, joinPolicy);
    }

    private OidcProviderConfig consumerConfig() {
        return new OidcProviderConfig("cfg-consumer", "PLATFORM", "google", "https://accounts.test",
                "https://accounts.test/authorize", "https://accounts.test/token", "https://accounts.test/jwks",
                "iam", "secret", List.of("openid", "email", "profile"),
                Map.of("email", "email", "sub", "sub", "name", "name", "groups", "groups"),
                List.of(), true, false, true, "AUTO_JOIN");
    }

    private VerifiedClaims claims(String email) {
        return new VerifiedClaims("sub-1", email, "Alice", List.of(), Map.of());
    }

    private void stubExistingIdentity() {
        UserIdentityPO id = new UserIdentityPO();
        id.setUserIdentityId("id-1");
        id.setUserId(USER_ID);
        when(userIdentityRepository.findByProvider(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Optional.of(id));
        UserPO u = new UserPO();
        u.setUserId(USER_ID);
        u.setUsername(EMAIL);
        when(userRepository.findByUserId(USER_ID)).thenReturn(Optional.of(u));
    }

    private TenantPO tenant(String id, String domain) {
        TenantPO t = new TenantPO();
        t.setTenantId(id);
        t.setPrimaryDomain(domain);
        return t;
    }

    private MembershipPO membership(String tenantId) {
        MembershipPO m = new MembershipPO();
        m.setMembershipId("ms-1");
        m.setTenantId(tenantId);
        m.setUserId(USER_ID);
        return m;
    }

    @Test
    void existingTenantAutoJoinCreatesMembership() {
        stubExistingIdentity();
        when(tenantRepository.findActiveByPrimaryDomain("org-a.com")).thenReturn(Optional.of(tenant("t-1", "org-a.com")));
        // 首次查无成员（尚未加入），ensureMembership 后再查返回新成员
        when(membershipRepository.findByTenantAndUser("t-1", USER_ID))
                .thenReturn(Optional.empty()).thenReturn(Optional.of(membership("t-1")));
        when(membershipRepository.create(any(MembershipPO.class))).thenReturn(true);

        JitProvisioner.JitResult result =
                provisioner.provision(enterpriseConfig("org-a.com", "AUTO_JOIN"), claims(EMAIL));

        assertThat(result.membership().getTenantId()).isEqualTo("t-1");
        assertThat(result.principal().userId()).isEqualTo(USER_ID);
        verify(userRepository).updateDefaultTenant(USER_ID, "t-1");
    }

    @Test
    void unprovisionedDomainRejected() {
        stubExistingIdentity();
        // S1：企业 SSO 域名未命中 → 403，不再 JIT 自建 ORGANIZATION 租户
        when(tenantRepository.findActiveByPrimaryDomain("newco.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> provisioner.provision(enterpriseConfig("newco.com", "AUTO_JOIN"), claims("alice@newco.com")))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(403));
        verify(tenantRepository, never()).create(any(TenantPO.class));
        verify(membershipRepository, never()).create(any(MembershipPO.class));
    }

    @Test
    void inviteOnlyWithoutMembershipDenied() {
        stubExistingIdentity();
        when(tenantRepository.findActiveByPrimaryDomain("org-a.com")).thenReturn(Optional.of(tenant("t-1", "org-a.com")));
        when(membershipRepository.findByTenantAndUser("t-1", USER_ID)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> provisioner.provision(enterpriseConfig("org-a.com", "INVITE_ONLY"), claims(EMAIL)))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(403));
    }

    @Test
    void domainNotAllowedDenied() {
        // 域名白名单在触达任何仓储前抛出 → 无需桩
        assertThatThrownBy(() -> provisioner.provision(enterpriseConfig("org-a.com", "AUTO_JOIN"), claims("alice@evil.com")))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(403));
    }

    @Test
    void consumerCreatesPersonalTenant() {
        stubExistingIdentity();
        when(tenantRepository.findActiveByOwnerAndType(USER_ID, "PERSONAL")).thenReturn(Optional.empty());
        when(tenantRepository.create(any(TenantPO.class))).thenReturn(true);
        when(membershipRepository.findByTenantAndUser(anyString(), eq(USER_ID))).thenReturn(Optional.of(membership("t-personal")));
        when(membershipRepository.create(any(MembershipPO.class))).thenReturn(true);

        JitProvisioner.JitResult result = provisioner.provision(consumerConfig(), claims("alice@gmail.com"));

        assertThat(result.membership().getTenantId()).isEqualTo("t-personal");
        verify(tenantRepository).create(any(TenantPO.class));
    }

    @Test
    void existingMembershipReused() {
        stubExistingIdentity();
        when(tenantRepository.findActiveByPrimaryDomain("org-a.com")).thenReturn(Optional.of(tenant("t-1", "org-a.com")));
        when(membershipRepository.findByTenantAndUser("t-1", USER_ID)).thenReturn(Optional.of(membership("t-1")));

        JitProvisioner.JitResult result =
                provisioner.provision(enterpriseConfig("org-a.com", "AUTO_JOIN"), claims(EMAIL));

        assertThat(result.membership().getTenantId()).isEqualTo("t-1");
        verify(membershipRepository, never()).create(any(MembershipPO.class));
    }

    @Test
    void provisionProducesUserPrincipal() {
        stubExistingIdentity();
        when(tenantRepository.findActiveByPrimaryDomain("org-a.com")).thenReturn(Optional.of(tenant("t-1", "org-a.com")));
        when(membershipRepository.findByTenantAndUser("t-1", USER_ID)).thenReturn(Optional.of(membership("t-1")));

        UserPrincipal principal = provisioner.provision(enterpriseConfig("org-a.com", "AUTO_JOIN"), claims(EMAIL)).principal();

        assertThat(principal.userId()).isEqualTo(USER_ID);
        assertThat(principal.username()).isEqualTo(EMAIL);
        assertThat(principal.userIdentityId()).isEqualTo("id-1");
    }
}
package com.unify.iam.tenant.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_tenant Mapper。 */
@Mapper
public interface TenantMapper extends BaseMapper<TenantPO> {
}

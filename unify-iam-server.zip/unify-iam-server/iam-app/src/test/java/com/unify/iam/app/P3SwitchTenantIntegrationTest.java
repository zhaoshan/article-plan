package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * P3 多租户切换集成测试：建第二个成员 → 切换租户 → 令牌 tenantId 改变；越权切换 403。
 */
class P3SwitchTenantIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminPost(String url, Object body, String token) throws Exception {
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    @Test
    void switchTenantReissuesTokenScopedToTargetMembership() throws Exception {
        String admin = login("admin", "admin123");

        // ① 建第二个租户 T
        String tenantId = JsonUtils.fromJson(
                adminPost("/api/v1/admin/tenants", Map.of(
                        "tenant_code", "sw-tenant", "tenant_name", "Switch Tenant",
                        "tenant_type", "ORGANIZATION", "app_codes", java.util.List.of("parlant-agent-server")), admin),
                Map.class).get("tenant_id").toString();

        // ② admin 加入 T（第二成员）
        String membershipId = JsonUtils.fromJson(
                adminPost("/api/v1/admin/members", Map.of(
                        "tenant_id", tenantId, "user_id", "u-1000"), admin),
                Map.class).get("membership_id").toString();

        // ③ admin 的可切换成员列表应含 T
        mockMvc.perform(get("/api/v1/auth/memberships").header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.memberships[?(@.membership_id == '" + membershipId + "')]").exists());

        // ④ 切换到 T → 新 token 的 tenantId 是 T
        MvcResult sw = mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("membership_id", membershipId))))
                .andExpect(status().isOk())
                .andReturn();
        LoginResponse switched = JsonUtils.fromJson(dataJson(sw.getResponse().getContentAsString()), LoginResponse.class);
        assertThat(switched.accessToken()).isNotBlank();

        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + switched.accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenantId").value(tenantId));
    }

    @Test
    void switchingToForeignMembershipForbidden() throws Exception {
        String viewer = login("viewer", "view123");

        mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + viewer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("membership_id", "ms-1001"))))
                .andExpect(status().isForbidden());
    }
}

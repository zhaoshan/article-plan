package com.unify.iam.app.oidc;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class OidcAuthSessionStoreTest {

    @Test
    void putAndTakeRoundTrip() {
        OidcAuthSessionStore store = new OidcAuthSessionStore();
        OidcAuthSession s = session("state-1", System.currentTimeMillis());

        store.put("state-1", s);
        assertThat(store.take("state-1")).isEqualTo(s);
    }

    @Test
    void unknownStateReturnsNull() {
        OidcAuthSessionStore store = new OidcAuthSessionStore();
        assertThat(store.take("missing")).isNull();
    }

    @Test
    void takeIsOneTime() {
        OidcAuthSessionStore store = new OidcAuthSessionStore();
        store.put("state-1", session("state-1", System.currentTimeMillis()));

        assertThat(store.take("state-1")).isNotNull();
        assertThat(store.take("state-1")).isNull();
    }

    @Test
    void expiredSessionEvicted() {
        OidcAuthSessionStore store = new OidcAuthSessionStore();
        store.put("state-old", session("state-old", System.currentTimeMillis() - 700_000L)); // 11 分钟前

        assertThat(store.take("state-old")).isNull();
    }

    private OidcAuthSession session(String state, long createdAt) {
        return new OidcAuthSession(state, "nonce", "challenge", "verifier", "cfg-1", "tenant-org-a", createdAt);
    }
}
package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * 兼容「字符串（逗号分隔）」或「字符串数组」两种 JSON 形态 → List&lt;String&gt;。
 *
 * <p>用于 allowed_domains / scopes 等字段：前端表单常以逗号文本提交，API 也接受数组。
 */
public class StringListDeserializer extends JsonDeserializer<List<String>> {

    @Override
    public List<String> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        if (p.currentToken() == JsonToken.VALUE_STRING) {
            String s = p.getValueAsString();
            if (s == null || s.isBlank()) {
                return List.of();
            }
            return Arrays.stream(s.split(","))
                    .map(String::trim)
                    .filter(x -> !x.isEmpty())
                    .toList();
        }
        if (p.currentToken() == JsonToken.START_ARRAY) {
            return p.readValueAs(new TypeReference<List<String>>() {
            });
        }
        throw new IOException("该字段需为字符串（逗号分隔）或字符串数组");
    }
}

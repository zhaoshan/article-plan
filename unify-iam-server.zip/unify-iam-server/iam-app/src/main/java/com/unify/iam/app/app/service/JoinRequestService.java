package com.unify.iam.app.app.service;

import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.infra.persistence.po.JoinRequestPO;
import com.unify.iam.app.infra.persistence.repository.JoinRequestRepository;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 加入申请（docs/04 §3.4，docs/03 §6.1）：用户申请加入租户 → 按 join_policy 自动加入 / 待审批；
 * 管理员审批通过建成员、拒绝置状态。审批限本租户（docs/06 §3.3）。
 */
@Service
public class JoinRequestService {

    private final JoinRequestRepository joinRequestRepository;
    private final TenantRepository tenantRepository;
    private final MembershipRepository membershipRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final TenantScopeGuard tenantScopeGuard;
    private final TokenVersionService tokenVersionService;

    public JoinRequestService(JoinRequestRepository joinRequestRepository,
                              TenantRepository tenantRepository,
                              MembershipRepository membershipRepository,
                              MembershipRoleRepository membershipRoleRepository,
                              TenantScopeGuard tenantScopeGuard,
                              TokenVersionService tokenVersionService) {
        this.joinRequestRepository = joinRequestRepository;
        this.tenantRepository = tenantRepository;
        this.membershipRepository = membershipRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.tenantScopeGuard = tenantScopeGuard;
        this.tokenVersionService = tokenVersionService;
    }

    /**
     * 用户发起加入申请。返回：AUTO_JOINED（直接建成员）/ PENDING（待审批）。
     */
    @Transactional
    public String request(String userId, String email, String tenantId) {
        TenantPO tenant = tenantRepository.findById(tenantId.trim())
                .orElseThrow(() -> AuthException.notFound("租户不存在"));
        if (membershipRepository.findByTenantAndUser(tenant.getTenantId(), userId).isPresent()) {
            throw AuthException.badRequest("已是该租户成员");
        }
        String joinPolicy = tenant.getJoinPolicy() == null ? "INVITE_ONLY" : tenant.getJoinPolicy();
        return switch (joinPolicy) {
            case "AUTO_JOIN" -> {
                createMembership(userId, tenant, "AUTO_JOIN", null);
                yield "AUTO_JOINED";
            }
            case "DOMAIN_AUTO_JOIN", "REQUEST", "DOMAIN_REQUEST" -> {
                JoinRequestPO po = new JoinRequestPO();
                po.setJoinRequestId(IdGenerator.newBizId());
                po.setTenantId(tenant.getTenantId());
                po.setUserId(userId);
                po.setEmail(email);
                po.setRequestSource("JOIN_PAGE");
                po.setRequestStatus("PENDING");
                joinRequestRepository.insert(po);
                yield "PENDING";
            }
            default -> throw AuthException.forbidden("该租户仅限邀请加入"); // INVITE_ONLY
        };
    }

    /** 审批通过：建成员 + 可选默认角色。限该申请所在租户。 */
    @Transactional
    public void approve(JwtClaims claims, String joinRequestId, String roleId) {
        JoinRequestPO po = findPending(joinRequestId);
        tenantScopeGuard.assertTenantScope(claims, po.getTenantId());
        po.setRequestStatus("APPROVED");
        po.setReviewedByUserId(claims.userId());
        po.setReviewedAt(LocalDateTime.now());
        joinRequestRepository.update(po);

        String tenantId = po.getTenantId();
        String userId = po.getUserId();
        if (!membershipRepository.findByTenantAndUser(tenantId, userId).isPresent()) {
            createMembership(userId, tenantRepository.findById(tenantId)
                    .orElseThrow(() -> AuthException.badRequest("租户不存在")), "REQUEST", roleId);
        } else if (roleId != null) {
            String existingMembershipId = membershipRepository.findByTenantAndUser(tenantId, userId).get().getMembershipId();
            membershipRoleRepository.replaceDirectRoles(existingMembershipId, List.of(roleId));
            tokenVersionService.bump(existingMembershipId, "ROLE_CHANGE");
        }
    }

    /** 审批拒绝。限该申请所在租户。 */
    public void reject(JwtClaims claims, String joinRequestId, String reviewNote) {
        JoinRequestPO po = findPending(joinRequestId);
        tenantScopeGuard.assertTenantScope(claims, po.getTenantId());
        po.setRequestStatus("REJECTED");
        po.setReviewNote(reviewNote);
        po.setReviewedByUserId(claims.userId());
        po.setReviewedAt(LocalDateTime.now());
        joinRequestRepository.update(po);
    }

    public List<JoinRequestPO> listByTenant(JwtClaims claims, String tenantId, String status) {
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        return joinRequestRepository.listByTenant(tenantId, status);
    }

    private JoinRequestPO findPending(String joinRequestId) {
        JoinRequestPO po = joinRequestRepository.findById(joinRequestId)
                .orElseThrow(() -> AuthException.notFound("加入申请不存在"));
        if (!"PENDING".equals(po.getRequestStatus())) {
            throw AuthException.badRequest("该申请已处理");
        }
        return po;
    }

    private void createMembership(String userId, TenantPO tenant, String joinSource, String roleId) {
        MembershipPO membership = new MembershipPO();
        membership.setMembershipId(IdGenerator.newBizId());
        membership.setTenantId(tenant.getTenantId());
        membership.setUserId(userId);
        membership.setMembershipStatus("ACTIVE");
        membership.setJoinSource(joinSource);
        membership.setIsDefault(0);
        membershipRepository.create(membership);
        if (roleId != null) {
            membershipRoleRepository.replaceDirectRoles(membership.getMembershipId(), List.of(roleId));
        }
    }
}

# CLAUDE.md

本文件为 Claude Code (claude.ai/code) 在此仓库中工作时提供指导。

## 项目概览

一个通用的 Web 数据爬取服务，基于 FastAPI 构建。提供可配置的站点链接树遍历、多策略内容解析、定时爬取调度以及可扩展的数据存储能力。

**核心技术栈：** Python 3.11+, FastAPI, Pydantic V2, Playwright, BeautifulSoup, Crawl4AI

**语言约定：** 代码注释和文档使用中文，变量/函数/类名使用英文。

## 项目规则（.claude/rules/）

以下规则文件在每次对话中自动附带（`alwaysApply: true`），Claude Code 会严格遵守：

| 规则文件 | 说明 |
|----------|------|
| `architecture-and-modules.md` | 9 模块依赖图、抽象接口、脚本迁移映射 |
| `python-conventions.md` | 类型标注、Pydantic V2、导入顺序、异步规范、命名约定 |
| `team-conventions.md` | 语言规范、代码审查要点、常见陷阱、文件编码 |
| `testing-requirements.md` | 强制覆盖率、测试模式、fixtures、提交前验证 |
| `workflow-and-process.md` | 实施顺序、提交前检查清单、配置约定、Git 工作流 |
| `fastapi-exception-handling.md` | FastAPI 全局异常处理 → DefaultResult 统一格式 |

## 架构（9 模块结构）

```
web-scraper-service/
├── config/                        # 运行时配置文件目录
│   ├── content_crawl_config.json  #   页面内容爬取配置（多站点）
│   └── traversal_rule_config.json #   站点遍历规则
├── scripts/                       # 独立脚本（原型代码，待迁移至 src/）
│   ├── common_response.py         #   通用 Pydantic 响应模型
│   ├── crawl_page_content.py      #   页面内容爬取（Playwright）
│   ├── crawl_tokyostarbank_faq.py #   动态 FAQ 站点爬取
│   ├── deep_crawl_nested_links.py #   深层嵌套链接遍历（BFS/DFS/Tree）
│   └── html_converter.py          #   HTML → Markdown 转换
├── src/
│   ├── boundaries/                # 边界服务对接（S3、业务通知）
│   ├── config/                    # 配置解析模块
│   ├── core/                      # 核心能力（链接遍历、增量爬取、内容抓取）
│   ├── models/                    # Pydantic V2 模型定义（共享层）
│   ├── parsers/                   # 多策略解析适配器
│   ├── routers/                   # FastAPI 路由接口
│   ├── schedulers/                # 定时任务调度管理
│   ├── storage/                   # 数据存储（文件/S3）
│   └── utils/                     # 公共工具抽象
│       └── static_checker.py      #   静态/动态页面判定
├── tests/                         # 测试目录
├── main.py                        # 入口（待重构为 FastAPI 应用）
└── requirements.txt
```

### 模块职责

| 模块 | 职责 | 状态 |
|------|------|------|
| **config** | 解析 `config/` 目录下的 JSON 配置，为 core 提供配置读取 | 空壳 |
| **core** | 站点链接树遍历、动态页面增量爬取、站点内容获取 | 空壳 |
| **models** | 跨模块共享的 Pydantic V2 模型定义（请求/响应/配置） | 空壳 |
| **parsers** | 多策略适配器模式，从 HTML 中提取结构化内容 | 空壳 |
| **routers** | FastAPI 路由定义，对外暴露爬取接口 | 空壳 |
| **storage** | 抽象存储接口，默认文件存储，后续接入 S3 | 空壳 |
| **boundaries** | 外部系统集成（S3 上传下载、爬取结果通知） | 空壳 |
| **schedulers** | 定时爬取任务管理 | 空壳 |
| **utils** | 公共工具类（静态页面判定、HTML 转换等） | 部分实现 |

## 构建 / 测试 / 格式化

### 常用命令

```bash
# 运行所有测试
python -m pytest tests/ -v --cov=src

# 运行特定模块测试
python -m pytest tests/test_utils/ -v --cov=src/utils

# 异步测试
python -m pytest tests/ -v --cov=src --asyncio-mode=auto

# 代码风格检查（待引入 ruff）
# ruff check src/ tests/

# 类型检查（待引入 mypy）
# python -m mypy src/ --strict

# 启动开发服务器
python -m uvicorn src.main:app --reload --host 0.0.0.0 --port 8000

# 安装依赖
python -m pip install -r requirements.txt
```

### 测试要求

1. **强制测试覆盖：**
   - `src/utils/` — 所有工具函数必须有单元测试
   - `src/core/` — 核心服务接口必须有集成测试
2. **测试框架：** pytest + pytest-asyncio
3. **覆盖率目标：** utils 和 core 模块 ≥ 80%
4. **测试命名：** `test_<module>.py`，目录结构镜像 `src/`

## 代码风格

### 通用规范
- **Python 3.11+** 类型标注，所有函数签名必须带类型
- 使用 PEP 585 泛型：`list[str]` 而非 `typing.List[str]`
- 使用 PEP 604 联合类型：`str | None` 而非 `Optional[str]`
- 注释：中文；代码标识符：英文
- 最大行宽：120 字符

### Pydantic V2
- 直接继承 `pydantic.BaseModel`
- 使用 `Field(description=..., default=...)` 定义字段
- 使用 `model_config = ConfigDict(...)` 配置模型
- 使用 `field_validator` 装饰器进行字段级验证
- 使用 `model_validator(mode="after")` 进行跨字段验证
- 禁止使用 V1 的 `@validator` 或内部 `Config` 类

### 导入顺序
1. 标准库
2. 第三方包

3. 本地应用模块

### 异步规范
- 所有 I/O 操作使用 `async def`
- Playwright 使用 `async_playwright()` 上下文管理器
- 长时间操作必须包含超时、重试和日志

## 模块依赖规则

```
routers → schedulers → core → {config, parsers, storage, boundaries}
                                 ↓
                              models（共享层，不依赖任何 src/ 模块）
                                 ↓
                              utils（叶子模块，不依赖任何 src/ 模块）
```

- `models` 禁止 import 任何其他 `src/` 模块
- `utils` 禁止 import 任何其他 `src/` 模块
- `core` 可以 import `config`、`models`、`utils`、`parsers`、`storage`、`boundaries`
- `routers` 是最上层模块，编排调度所有下层模块
- **严格禁止循环导入**，使用依赖注入解耦模块

## 脚本迁移路径

`scripts/` 中的独立脚本是原型代码，逐步迁移至 `src/`：

| 脚本 | 迁移目标 |
|------|----------|
| `scripts/common_response.py` | → `src/models/api_response.py`（通用响应模型） |
| `scripts/html_converter.py` | → `src/utils/html_converter.py`（HTML 转换工具） |
| `scripts/deep_crawl_nested_links.py` | → `src/core/link_traverser.py`（遍历逻辑）+ `src/models/`（数据模型） |
| `scripts/crawl_page_content.py` | → `src/core/content_fetcher.py`（抓取逻辑）+ `src/storage/`（存储逻辑） |
| `scripts/crawl_tokyostarbank_faq.py` | → `src/core/incremental_crawler.py`（动态页面增量爬取模式） |

## 实施顺序（推荐）

- **Phase 1（基础层）：** git init → models → utils → config
- **Phase 2（核心层）：** storage → parsers → core
- **Phase 3（服务层）：** boundaries → schedulers → routers → main.py

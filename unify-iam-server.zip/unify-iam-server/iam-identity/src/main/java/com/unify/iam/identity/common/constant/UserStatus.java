package com.unify.iam.identity.common.constant;

/** 账号状态（对应 gateway_user.user_status）。 */
public enum UserStatus {

    PENDING,
    ACTIVE,
    SUSPENDED,
    DELETED;

    /** 是否 ACTIVE。 */
    public static boolean isActive(String status) {
        return ACTIVE.name().equals(status);
    }
}

-- --------------------------------------------
-- unify-iam-server docs/06 §5.3：应用角色模板 + 租户启用应用（V6）
-- 目标：租户按「启用的应用」初始化灌入预置角色，新增应用 = 插数据不改代码
-- 关联：gateway_permission（权限点全局字典，code 与模板 permission_codes 同套）
-- 说明：seed 为权威目录（非环境占位），同 V2/V5 惯例放迁移；INSERT IGNORE 幂等
-- --------------------------------------------

SET NAMES utf8mb4;

-- ============================================================
-- 1. 应用注册表
-- ============================================================
CREATE TABLE IF NOT EXISTS `iam_application` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `app_id` CHAR(32) NOT NULL COMMENT '应用业务唯一标识',
  `app_code` VARCHAR(64) NOT NULL COMMENT '应用编码，如 parlant-agent-server',
  `app_name` VARCHAR(128) NOT NULL COMMENT '应用名称',
  `app_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '状态：ACTIVE/DISABLED',
  `description` VARCHAR(512) DEFAULT NULL COMMENT '应用描述',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL,
  `update_by` VARCHAR(64) DEFAULT NULL,
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_iam_app_id` (`app_id`),
  UNIQUE KEY `uk_iam_app_code` (`app_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='应用注册表（应用→角色/权限模板权威目录）';

-- ============================================================
-- 2. 应用预置角色模板表
-- ============================================================
CREATE TABLE IF NOT EXISTS `iam_application_role_template` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `template_id` CHAR(32) NOT NULL COMMENT '模板业务唯一标识',
  `app_code` VARCHAR(64) NOT NULL COMMENT '所属应用编码',
  `role_code` VARCHAR(64) NOT NULL COMMENT '角色编码，如 TenantAdmin',
  `role_name` VARCHAR(128) NOT NULL COMMENT '角色名称',
  `role_description` VARCHAR(256) DEFAULT NULL COMMENT '角色描述',
  `permission_codes_json` JSON NOT NULL COMMENT '权限点 code 数组（与 gateway_permission 同套 code）',
  `is_owner` TINYINT NOT NULL DEFAULT 0 COMMENT '首人 owner 角色（docs/06 §3.1，0否 1是）',
  `priority` INT NOT NULL DEFAULT 0 COMMENT '初始化/展示顺序，小者优先',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL,
  `update_by` VARCHAR(64) DEFAULT NULL,
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_iam_template_id` (`template_id`),
  UNIQUE KEY `uk_iam_app_role` (`app_code`, `role_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='应用预置角色模板表（租户初始化灌入来源）';

-- ============================================================
-- 3. 租户启用应用表
-- ============================================================
CREATE TABLE IF NOT EXISTS `iam_tenant_application` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `tenant_app_id` CHAR(32) NOT NULL COMMENT '租户应用业务唯一标识',
  `tenant_id` CHAR(32) NOT NULL COMMENT '所属租户ID；逻辑关联 gateway_tenant.tenant_id',
  `app_code` VARCHAR(64) NOT NULL COMMENT '启用的应用编码',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除（停用 = 逻辑删除该启用关系）',
  `create_by` VARCHAR(64) DEFAULT NULL,
  `update_by` VARCHAR(64) DEFAULT NULL,
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_iam_tenant_app_id` (`tenant_app_id`),
  UNIQUE KEY `uk_iam_tenant_app` (`tenant_id`, `app_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户启用应用表（m:n 关联，一个租户可启用多个应用）';

-- ============================================================

-- [seed 已剥离] 原 seed 数据移至 db/seed / db/seed-dev（R__ 幂等）；本迁移只留 schema。

package com.unify.iam.app;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * docs/06 增量 2 集成测试：租户级管理面。
 *
 * <p>租户 TenantAdmin（租户内 iam:member:* / iam:role:*）只能管理本租户（token.tenantId）；
 * 平台管理员（PlatformAdmin）跨租户放行；PLATFORM 作用域目标仅平台管理员可操作。
 */
class P3TenantScopeIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminPost(String url, Object body, String token) throws Exception {
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    private String createUser(String token, String username, String email) throws Exception {
        String body = adminPost("/api/v1/admin/users",
                Map.of("username", username, "email", email, "password", "Passw0rd!"), token);
        return JsonUtils.fromJson(body, Map.class).get("user_id").toString();
    }

    private String createTenant(String token, String code, String name, String ownerUserId) throws Exception {
        Map<String, Object> req = new java.util.LinkedHashMap<>();
        req.put("tenant_code", code);
        req.put("tenant_name", name);
        req.put("tenant_type", "ORGANIZATION");
        req.put("app_codes", List.of("parlant-agent-server"));
        if (ownerUserId != null) {
            req.put("owner_user_id", ownerUserId);
        }
        String body = adminPost("/api/v1/admin/tenants", req, token);
        return JsonUtils.fromJson(body, Map.class).get("tenant_id").toString();
    }

    @Test
    void tenantAdminSelfServesOwnTenant() throws Exception {
        String admin = login("admin", "admin123");
        String ownerUserId = createUser(admin, "tsc_owner1", "tsc-owner1@unify.local");
        String memberUserId = createUser(admin, "tsc_member1", "tsc-member1@unify.local");
        String tenantId = createTenant(admin, "tsc-tenant-1", "TSC Tenant 1", ownerUserId);

        // ① 首人 owner 登录 → token.tenantId = 本租户，roles 含 TenantAdmin，permissions 含租户内 iam:member:write
        String owner = login("tsc_owner1", "Passw0rd!");
        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + owner))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenantId").value(tenantId))
                .andExpect(jsonPath("$.data.roles[?(@ == 'TenantAdmin')]").exists())
                .andExpect(jsonPath("$.data.permissions[?(@ == 'iam:member:write')]").exists());

        // ② 本租户自助：列角色 / 加成员 / 列成员 / 授角色
        String rolesBody = mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantId)
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(3))
                .andReturn().getResponse().getContentAsString();
        String tenantAdminRoleId = firstId(rolesBody, "roles", "role_id");

        String membershipId = JsonUtils.fromJson(
                adminPost("/api/v1/admin/members", Map.of(
                        "tenant_id", tenantId, "user_id", memberUserId), owner),
                Map.class).get("membership_id").toString();
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", tenantId)
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.members[?(@.membership_id == '" + membershipId + "')]").exists());
        mockMvc.perform(put("/api/v1/admin/members/" + membershipId + "/roles")
                        .header("Authorization", "Bearer " + owner)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("role_ids", List.of(tenantAdminRoleId)))))
                .andExpect(status().isOk());

        // ③ 本租户自助：建租户内角色 / 发邀请
        adminPost("/api/v1/admin/roles", Map.of(
                "scope_type", "TENANT", "scope_id", tenantId,
                "role_code", "TscRole", "role_name", "TSC 角色"), owner);
        adminPost("/api/v1/admin/invitations", Map.of(
                "email", "invitee1@unify.local", "tenant_id", tenantId), owner);

        // ④ 本租户自助：加入申请审批（申请人用已登录的 viewer，与 P3JoinRequest 同模式）
        jdbcTemplate.update("UPDATE gateway_tenant SET join_policy='DOMAIN_REQUEST' WHERE tenant_id=?", tenantId);
        String applicant = login("viewer", "view123");
        mockMvc.perform(post("/api/v1/memberships/join-request")
                        .header("Authorization", "Bearer " + applicant)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", tenantId))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("PENDING"));
        String joinList = mockMvc.perform(get("/api/v1/admin/join-requests")
                        .param("tenant_id", tenantId)
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(1))
                .andReturn().getResponse().getContentAsString();
        String joinRequestId = firstId(joinList, "join_requests", "join_request_id");
        mockMvc.perform(post("/api/v1/admin/join-requests/" + joinRequestId + "/approve")
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isOk());

        // ⑤ 平台管理员仍可跨租户操作（回归）
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", tenantId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
    }

    @Test
    void tenantAdminCannotTouchOtherTenantsOrPlatform() throws Exception {
        String admin = login("admin", "admin123");
        String ownerUserId = createUser(admin, "tsc_owner2", "tsc-owner2@unify.local");
        String tenantId = createTenant(admin, "tsc-tenant-2", "TSC Tenant 2", ownerUserId);
        String owner = login("tsc_owner2", "Passw0rd!");

        // ① 越权：成员（读/写）指向 tenant-org-a → 403
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + owner)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", "tenant-org-a", "user_id", "u-1001"))))
                .andExpect(status().isForbidden());

        // ② 越权：角色（列/建）指向 tenant-org-a → 403
        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + owner)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "scope_type", "TENANT", "scope_id", "tenant-org-a",
                                "role_code", "BadRole", "role_name", "Bad"))))
                .andExpect(status().isForbidden());

        // ③ 越权：邀请指向 tenant-org-a → 403
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + owner)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", "x@unify.local", "tenant_id", "tenant-org-a"))))
                .andExpect(status().isForbidden());

        // ④ 越权：加入申请列表指向 tenant-org-a → 403
        mockMvc.perform(get("/api/v1/admin/join-requests").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isForbidden());

        // ⑤ PLATFORM 作用域目标：租户管理员不可列/建平台角色 → 403
        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + owner)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "scope_type", "PLATFORM", "scope_id", "PLATFORM",
                                "role_code", "PlatRole", "role_name", "Plat"))))
                .andExpect(status().isForbidden());

        // ⑥ 平台专属权限点：租户管理员未授权 → 403（iam:user:* / iam:tenant:*）
        mockMvc.perform(get("/api/v1/admin/users").header("Authorization", "Bearer " + owner))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + owner)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_code", "x", "tenant_name", "X"))))
                .andExpect(status().isForbidden());

        // ⑦ 本租户内操作不受影响（自证仍有租户内权限）
        mockMvc.perform(get("/api/v1/admin/members").param("tenant_id", tenantId)
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isOk());
    }

    private String firstId(String jsonBody, String listKey, String itemKey) {
        Map<String, Object> parsed = unwrapData(jsonBody);
        Object list = parsed.get(listKey);
        if (list instanceof java.util.List<?> rows && !rows.isEmpty()) {
            return String.valueOf(((Map<?, ?>) rows.get(0)).get(itemKey));
        }
        return "";
    }
}

package com.unify.iam.app.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.app.infra.persistence.mapper.TenantDomainMapper;
import com.unify.iam.app.infra.persistence.po.TenantDomainPO;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** 租户域名仓储（P3 域名验证）。 */
@Repository
public class TenantDomainRepository {

    private final TenantDomainMapper mapper;

    public TenantDomainRepository(TenantDomainMapper mapper) {
        this.mapper = mapper;
    }

    public void insert(TenantDomainPO po) {
        mapper.insert(po);
    }

    public void update(TenantDomainPO po) {
        mapper.updateById(po);
    }

    public Optional<TenantDomainPO> findById(String tenantDomainId) {
        return Optional.ofNullable(mapper.selectOne(new LambdaQueryWrapper<TenantDomainPO>()
                .eq(TenantDomainPO::getTenantDomainId, tenantDomainId)));
    }

    public List<TenantDomainPO> listByTenant(String tenantId) {
        return mapper.selectList(new LambdaQueryWrapper<TenantDomainPO>()
                .eq(TenantDomainPO::getTenantId, tenantId));
    }
}

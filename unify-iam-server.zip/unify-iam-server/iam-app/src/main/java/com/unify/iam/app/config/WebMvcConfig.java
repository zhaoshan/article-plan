package com.unify.iam.app.config;

import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web MVC 配置：注册管理面鉴权拦截器（仅保护 `/api/v1/admin/**`，不动公开端点）。
 *
 * <p>用 {@code ObjectProvider} 容错：全量上下文有拦截器 bean 则注册；{@code @WebMvcTest} 切片不扫描
 * 该 @Component（无 bean）时跳过，避免上下文加载失败。
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final ObjectProvider<ManagementAuthorizationInterceptor> interceptorProvider;

    public WebMvcConfig(ObjectProvider<ManagementAuthorizationInterceptor> interceptorProvider) {
        this.interceptorProvider = interceptorProvider;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        ManagementAuthorizationInterceptor interceptor = interceptorProvider.getIfAvailable();
        if (interceptor != null) {
            // /api/v1/mgmt/** 是 /api/v1/admin/** 的别名（WAF 拦截路径含 admin 的应对措施，
            // 双跑过渡：消费方迁完后从 controller 注解删旧值）——两个前缀都必须被鉴权拦截器覆盖
            registry.addInterceptor(interceptor).addPathPatterns("/api/v1/admin/**", "/api/v1/mgmt/**");
        }
    }
}
"""共享测试 fixtures"""

import json
import pytest
import pytest_asyncio
from pathlib import Path

from src.config.system_config import DatabaseConfig
from src.database.connection import init_engine, close_db, init_db


@pytest.fixture
def temp_dir(tmp_path: Path) -> Path:
    """临时目录 fixture"""
    return tmp_path


@pytest.fixture
def sample_config_dir(tmp_path: Path) -> Path:
    """创建临时配置目录，包含示例 traversal_rule_config.json 与 content_crawl_config.json"""
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    config_data = {
        "example.com": {
            "need_outer_site": "True",
            "outer_site_whitelist": ["partner.com"],
            "drill_down_levels": 2,
        },
        "no-outer.com": {
            "need_outer_site": "False",
            "outer_site_whitelist": [],
            "drill_down_levels": 1,
        },
    }
    (config_dir / "traversal_rule_config.json").write_text(
        json.dumps(config_data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 页面内容爬取配置（多站点，域名作 key）
    content_crawl_data = {
        "tokyostarbank.co.jp": {
            "exclude_tags": [
                {"tag": "header", "id": "header"},
                {"tag": "div", "class": "footer-copyright"},
            ]
        },
        "example.com": {
            "exclude_tags": [
                {"tag": "nav", "class": "main-nav"}
            ]
        },
    }
    (config_dir / "content_crawl_config.json").write_text(
        json.dumps(content_crawl_data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # 动态页面爬取配置
    dynamic_page_data = {
        "tokyostarbank.co.jp": {
            "faq": {
                "script_name": "faq_crawler",
                "parent_link": "https://support.tokyostarbank.co.jp/",
                "entry_url": "https://support.tokyostarbank.co.jp/category/test/",
                "description": "测试 FAQ 配置",
            }
        }
    }
    (config_dir / "dynamic_page_config.json").write_text(
        json.dumps(dynamic_page_data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return config_dir


@pytest_asyncio.fixture(scope="function")
async def db_session():
    """初始化内存 SQLite 数据库并创建表，返回可用状态。

    测试结束后关闭引擎与连接池。
    """
    db_config = DatabaseConfig(
        url="sqlite+aiosqlite:///:memory:",
        driver="sqlite+aiosqlite",
    )
    init_engine(db_config)
    await init_db()
    yield
    await close_db()

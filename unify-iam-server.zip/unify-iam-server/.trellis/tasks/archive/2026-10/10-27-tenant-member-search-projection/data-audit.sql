START TRANSACTION READ ONLY;
SELECT JSON_OBJECT(
  'membership_id', TRIM(m.membership_id), 'user_id', TRIM(m.user_id),
  'membership_status', m.membership_status, 'membership_deleted', m.delete_flag,
  'tenant_id', TRIM(t.tenant_id), 'tenant_code', t.tenant_code,
  'tenant_deleted', t.delete_flag, 'owner_user_id', TRIM(t.owner_user_id),
  'user_exists', u.id IS NOT NULL, 'user_deleted', u.delete_flag, 'user_status', u.user_status,
  'has_username', NULLIF(TRIM(u.username), '') IS NOT NULL,
  'has_full_name', NULLIF(TRIM(u.full_name), '') IS NOT NULL,
  'has_display_name', NULLIF(TRIM(u.display_name), '') IS NOT NULL,
  'has_email', NULLIF(TRIM(u.primary_email), '') IS NOT NULL
)
FROM gateway_membership m
LEFT JOIN gateway_tenant t ON t.tenant_id=m.tenant_id
LEFT JOIN gateway_user u ON u.user_id=m.user_id
WHERE m.user_id='47a0408e815c4c7487d27d1992ae6db1'
   OR m.membership_id='47a0408e815c4c7487d27d1992ae6db1';
COMMIT;

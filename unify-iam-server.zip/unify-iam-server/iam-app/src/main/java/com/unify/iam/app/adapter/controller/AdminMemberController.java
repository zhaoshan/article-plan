package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateMemberRequest;
import com.unify.iam.api.dto.admin.SetRolesRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminMemberService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.authorization.infra.persistence.po.MembershipRolePO;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：成员 CRUD（iam:member:*）。 */
@RestController
@RequestMapping("/api/v1/admin/members")
public class AdminMemberController {

    private final AdminMemberService adminMemberService;
    private final AuditService auditService;
    private final UserRepository userRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final RoleRepository roleRepository;
    private final com.unify.iam.tenant.infra.persistence.repository.TenantRepository tenantRepository;

    public AdminMemberController(AdminMemberService adminMemberService,
                                 AuditService auditService,
                                 UserRepository userRepository,
                                 MembershipRoleRepository membershipRoleRepository,
                                 RoleRepository roleRepository,
                                 com.unify.iam.tenant.infra.persistence.repository.TenantRepository tenantRepository) {
        this.adminMemberService = adminMemberService;
        this.auditService = auditService;
        this.userRepository = userRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.roleRepository = roleRepository;
        this.tenantRepository = tenantRepository;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_MEMBER_READ)
    public Map<String, Object> list(@RequestParam(name = "tenant_id") String tenantId) {
        List<MembershipPO> members = adminMemberService.listByTenant(CurrentAuth.claims(), tenantId.trim());
        // 批量补 username（租户管理员无 iam:user:read，靠这里展示成员名）
        Map<String, String> usernameByUserId = userRepository.findByIds(
                        members.stream().map(MembershipPO::getUserId).toList()).stream()
                .collect(Collectors.toMap(u -> u.getUserId(), u -> u.getUsername(), (a, b) -> a));
        // 批量补当前租户下的角色（避免 N+1，docs/user-manual 02 §1）
        List<MembershipRolePO> memberRoles = membershipRoleRepository.listByMemberships(
                members.stream().map(MembershipPO::getMembershipId).toList());
        Map<String, RolePO> roleById = roleRepository.findByIds(
                        memberRoles.stream().map(MembershipRolePO::getRoleId).toList()).stream()
                .collect(Collectors.toMap(RolePO::getRoleId, Function.identity(), (a, b) -> a));
        Map<String, List<Map<String, String>>> rolesByMembership = memberRoles.stream()
                .filter(mr -> roleById.containsKey(mr.getRoleId()))
                .collect(Collectors.groupingBy(MembershipRolePO::getMembershipId,
                        Collectors.mapping(mr -> roleBrief(roleById.get(mr.getRoleId())), Collectors.toList())));
        List<Map<String, Object>> briefs = members.stream()
                .map(m -> toBrief(m,
                        usernameByUserId.getOrDefault(m.getUserId(), m.getUserId()),
                        rolesByMembership.getOrDefault(m.getMembershipId(), List.of())))
                .toList();
        String tenantType = tenantRepository.findById(tenantId.trim())
                .map(com.unify.iam.tenant.infra.persistence.po.TenantPO::getTenantType).orElse("");
        return Map.of("members", briefs, "count", briefs.size(), "tenant_type", tenantType);
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> add(@Valid @RequestBody CreateMemberRequest request) {
        String membershipId = adminMemberService.add(CurrentAuth.claims(), request);
        auditService.audit().event("ADMIN_ADD_MEMBER").actor(CurrentAuth.claims().userId())
                .target("MEMBERSHIP", membershipId).result("SUCCESS").tenant(request.tenantId())
                .write(Map.of("user_id", request.userId()));
        return Map.of("membership_id", membershipId);
    }

    @PutMapping("/{membershipId}/roles")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> setRoles(@PathVariable String membershipId,
                                        @Valid @RequestBody SetRolesRequest request) {
        adminMemberService.setRoles(CurrentAuth.claims(), membershipId, request);
        return Map.of("membership_id", membershipId);
    }

    @GetMapping("/{membershipId}/roles")
    @RequirePermission(PermissionCodes.IAM_MEMBER_READ)
    public Map<String, Object> getRoles(@PathVariable String membershipId) {
        List<Map<String, String>> roles = adminMemberService.getRoles(CurrentAuth.claims(), membershipId).stream()
                .map(r -> {
                    Map<String, String> m = new LinkedHashMap<>();
                    m.put("role_id", r.getRoleId());
                    m.put("role_code", r.getRoleCode());
                    m.put("role_name", r.getRoleName());
                    return m;
                })
                .toList();
        return Map.of("roles", roles, "count", roles.size());
    }

    @PostMapping("/{membershipId}/suspend")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> suspend(@PathVariable String membershipId) {
        adminMemberService.suspend(CurrentAuth.claims(), membershipId);
        return Map.of("membership_id", membershipId);
    }

    @PostMapping("/{membershipId}/restore")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> restore(@PathVariable String membershipId) {
        adminMemberService.restore(CurrentAuth.claims(), membershipId);
        return Map.of("membership_id", membershipId);
    }

    @DeleteMapping("/{membershipId}")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> remove(@PathVariable String membershipId) {
        adminMemberService.remove(CurrentAuth.claims(), membershipId);
        auditService.audit().event("ADMIN_REMOVE_MEMBER").actor(CurrentAuth.claims().userId())
                .target("MEMBERSHIP", membershipId).result("SUCCESS").write(null);
        return Map.of("membership_id", membershipId);
    }

    private Map<String, Object> toBrief(MembershipPO m, String username, List<Map<String, String>> roles) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("membership_id", m.getMembershipId());
        map.put("tenant_id", m.getTenantId());
        map.put("user_id", m.getUserId());
        map.put("username", username);
        map.put("membership_status", m.getMembershipStatus());
        map.put("is_default", String.valueOf(m.getIsDefault()));
        map.put("roles", roles);
        return map;
    }

    private Map<String, String> roleBrief(RolePO r) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("role_id", r.getRoleId());
        m.put("role_code", r.getRoleCode());
        m.put("role_name", r.getRoleName());
        return m;
    }
}

-- --------------------------------------------
-- unify-iam-server E2E-2：认证接入域（SSO）建表（V3）
-- 数据库：MySQL 8.x；schema：unify_iam（由 datasource 指定，本脚本不写 USE）
-- 来源：20260825-Gateway-Tenant-IAM-schema-mysql.sql（gateway_tenant_idp_config / gateway_idp_group_mapping）
-- 说明：企业 SSO（OIDC 先行）的 IdP 配置与 IdP 组→内部角色白名单映射
-- --------------------------------------------

SET NAMES utf8mb4;

-- ============================================================
-- 租户级 IdP / SSO 配置
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_tenant_idp_config` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `tenant_idp_config_id` CHAR(32) NOT NULL COMMENT '租户 IdP 配置业务唯一标识',
  `tenant_id` CHAR(32) NOT NULL COMMENT '所属租户ID；平台级 consumer IdP 预留 PLATFORM 作用域',
  `protocol` VARCHAR(16) NOT NULL COMMENT '协议：OIDC/SAML',
  `provider_key` VARCHAR(64) NOT NULL COMMENT '提供方标识：google/microsoft/okta/keycloak/auth0/custom',
  `display_name` VARCHAR(128) NOT NULL COMMENT '前端展示名称，如 Company SSO',
  `config_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '配置状态：DRAFT/ACTIVE/DISABLED',
  `issuer` VARCHAR(255) DEFAULT NULL COMMENT 'OIDC issuer 或 SAML entityId',
  `discovery_uri` VARCHAR(512) DEFAULT NULL COMMENT 'OIDC discovery 地址',
  `jwk_set_uri` VARCHAR(512) DEFAULT NULL COMMENT 'OIDC JWKS 地址',
  `authorization_endpoint` VARCHAR(512) DEFAULT NULL COMMENT '授权地址；支持 Auth Code + PKCE',
  `token_endpoint` VARCHAR(512) DEFAULT NULL COMMENT '换 token 地址',
  `userinfo_endpoint` VARCHAR(512) DEFAULT NULL COMMENT 'userinfo 地址；可选',
  `client_id` VARCHAR(255) DEFAULT NULL COMMENT '客户端 ID',
  `client_secret_cipher` TEXT DEFAULT NULL COMMENT '加密后的客户端密钥或 SAML 私钥材料',
  `scopes_json` JSON DEFAULT NULL COMMENT 'OIDC scopes 数组 JSON；如 ["openid","email","profile"]',
  `claim_mapping_json` JSON DEFAULT NULL COMMENT 'claim 映射配置 JSON；内部字段->外部claim 名',
  `allowed_domains_json` JSON DEFAULT NULL COMMENT '允许使用该 IdP 的邮箱域名 JSON 数组',
  `pkce_required` TINYINT NOT NULL DEFAULT 1 COMMENT '是否要求 PKCE：0否 1是',
  `email_verified_required` TINYINT NOT NULL DEFAULT 0 COMMENT '是否要求 claim.email_verified=true：0否 1是',
  `jit_provisioning_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '是否启用首次登录自动建号/建成员关系：0否 1是',
  `default_join_policy` VARCHAR(16) NOT NULL DEFAULT 'INVITE_ONLY' COMMENT '首次登录时的默认加入策略：REQUEST/AUTO_JOIN/INVITE_ONLY',
  `metadata_xml` LONGTEXT DEFAULT NULL COMMENT 'SAML 元数据 XML；仅 protocol=SAML 时使用',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_tenant_idp_config_id` (`tenant_idp_config_id`),
  UNIQUE KEY `uk_gateway_tenant_protocol_provider_issuer` (`tenant_id`, `protocol`, `provider_key`, `issuer`),
  KEY `idx_config_status` (`config_status`),
  KEY `idx_tenant_protocol` (`tenant_id`, `protocol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户级身份提供方配置表；支持 OIDC / SAML';

-- ============================================================
-- IdP Group 到内部角色映射（纯 RBAC 版本：白名单）
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_idp_group_mapping` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `idp_group_mapping_id` CHAR(32) NOT NULL COMMENT 'IdP 组映射业务唯一标识',
  `tenant_idp_config_id` CHAR(32) NOT NULL COMMENT '租户 IdP 配置ID；逻辑关联 gateway_tenant_idp_config.tenant_idp_config_id',
  `match_mode` VARCHAR(16) NOT NULL DEFAULT 'EXACT' COMMENT '匹配模式：EXACT/REGEX',
  `match_value` VARCHAR(255) NOT NULL COMMENT '外部 group 值或正则表达式',
  `target_role_id` CHAR(32) NOT NULL COMMENT '目标角色ID；逻辑关联 gateway_role.role_id',
  `priority` INT NOT NULL DEFAULT 100 COMMENT '匹配优先级；数值越小优先级越高',
  `mapping_status` VARCHAR(16) NOT NULL DEFAULT 'ACTIVE' COMMENT '映射状态：ACTIVE/DISABLED',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_idp_group_mapping_id` (`idp_group_mapping_id`),
  UNIQUE KEY `uk_gateway_idp_group_mapping_rule` (`tenant_idp_config_id`, `match_mode`, `match_value`, `target_role_id`),
  KEY `idx_target_role_id` (`target_role_id`),
  KEY `idx_mapping_status_priority` (`mapping_status`, `priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='IdP group/role 到内部角色的映射规则表（纯 RBAC 版本）';
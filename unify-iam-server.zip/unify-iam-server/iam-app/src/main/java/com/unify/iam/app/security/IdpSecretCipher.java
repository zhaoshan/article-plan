package com.unify.iam.app.security;

import org.jasypt.encryption.StringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * IdP client_secret 落库加解密（P1-06，docs/07 §7 待办闭环）。
 *
 * <p>复用 jasypt-spring-boot 的 {@link StringEncryptor}（主密钥 = JASYPT_ENCRYPTOR_PASSWORD，
 * 与配置 ENC() 密文同一密钥体系，不新增密钥管理面）：
 * <ul>
 *   <li><b>写入</b>（管理端 create/update）：{@link #encrypt} 密文落 {@code client_secret_cipher}；</li>
 *   <li><b>读取</b>（OIDC 换 token）：{@link #decrypt} 还原明文；解密失败按<b>存量明文</b>宽容处理——
 *       2026-11-11 前的历史行是明文直存，原样返回并用一次 WARN 提示管理员「保存一次即完成迁移」，
 *       无需停机迁移脚本。</li>
 * </ul>
 *
 * <p>安全口径：DB/备份泄露后 client_secret 不可直接利用；管理端查询响应本就只回
 * {@code has_secret} 布尔（不回显任何形态的秘密）。生产必须设置 JASYPT_ENCRYPTOR_PASSWORD
 * 强密钥（与 spring.mail.password ENC 密文同套）。
 */
@Component
public class IdpSecretCipher {

    private static final Logger log = LoggerFactory.getLogger(IdpSecretCipher.class);

    private final StringEncryptor encryptor;

    /** 存量明文告警去重（每进程一次即可，不刷屏） */
    private volatile boolean legacyWarned = false;

    public IdpSecretCipher(StringEncryptor encryptor) {
        this.encryptor = encryptor;
    }

    /** 明文 → 密文（写入侧唯一入口）。 */
    public String encrypt(String plain) {
        return encryptor.encrypt(plain);
    }

    /**
     * 密文 → 明文（读取侧唯一入口）。解密失败按存量明文宽容返回——历史明文行在下次
     * update 时经 encrypt 自动迁移为密文。
     */
    public String decrypt(String stored) {
        if (stored == null || stored.isBlank()) {
            return stored;
        }
        try {
            return encryptor.decrypt(stored);
        } catch (RuntimeException legacyPlaintext) {
            if (!legacyWarned) {
                legacyWarned = true;
                log.warn("IdP client_secret 为存量明文直存——重新保存该配置即自动迁移为密文（P1-06）");
            }
            return stored;
        }
    }
}

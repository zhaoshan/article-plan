# Validation and delivery record

Date: 2026-11-06 (Asia/Shanghai)
Project: /Users/ramiro.li/root/apps/work/platform-iam-service
Branch: dev/261026_v0.2
Base/current HEAD: 76e6580
Delivery: implemented and independently reviewed; all task changes uncommitted.

## Actual changes
- Deleted TenantRoleController, TenantRoleQueryService, TenantRoleOption and TenantRoleOptions.
- Removed RoleRepository.listForTenantMemberPicker; generic management/runtime query implementations unchanged.
- Added a single iam:role:write grant to tpl-3002 and idempotent existing non-deleted TENANT iMorph-Admin role binding repair in R__app_imorph.sql. Tombstoned bindings are revived. Member and PLATFORM grants are unchanged.
- Replaced obsolete endpoint tests with TenantRoleApiRemovalIntegrationTest, AdminPermissionControllerTest and ImorphAdminRoleCreationIntegrationTest.
- Updated .trellis/spec/backend/tenant-role-candidates.md and index; planning and session records remain in this project.

## Results
Latest seven Surefire reports represent 33 unique passing tests, 0 failures/errors/skips:
- AdminRoleControllerTest: 11
- AdminRoleServiceTest: 9
- AdminRoleListIntegrationTest: 7
- TenantRoleApiRemovalIntegrationTest: 1
- AdminPermissionControllerTest: 2
- ImorphAdminRoleCreationIntegrationTest: 2
- P3AdminCrudIntegrationTest#tenantRoleCannotGrantPlatformOnlyPermissions: 1

The independent trellis-check agent reviewed the full diff/spec/task scope and found no actionable defect; no reviewer code edits were needed. Reactor compilation with JDK 21 passed, git diff --check passed, task context validation passed. No dedicated lint plugin is configured. Production source search found no remaining obsolete endpoint/controller/service/DTO/union-method references.

Real provisioned iMorph-Admin HTTP login produced DB-derived role-write permission; own-tenant role creation returned 200 and persisted correct scope. Foreign TENANT and PLATFORM creation returned 403. Real Member login lacked role-write and creation returned 403. Seed replay twice repaired missing/tombstoned bindings without duplicates, preserved original revived binding ID, and excluded Member/PLATFORM/deleted roles. Existing tenant-list, forged-platform, cross-tenant and grant-write regressions passed.

## Execution history and commands
The initial default-sandbox clean test compiled successfully and removed stale classes for deleted sources, but tests could not initialize Mockito attach or access Docker. Authorized escalated execution resolved environment access and used real MySQL Testcontainers.

The first escalated command below exited 1: 32 tests passed and one new real-login fixture failed 401 because AdminMemberService creates is_default=0 memberships. The fixture was corrected to mark its new account's sole membership default; product code was not changed for this failure. The second command exited 0 with both affected tests passing. The final 33-pass result combines the unchanged passing classes and this corrected-fixture rerun; it is not a claim that the first command passed.

```sh
JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin:$PATH mvn -q -pl iam-app -am '-Dtest=AdminRoleControllerTest,AdminRoleServiceTest,AdminRoleListIntegrationTest,TenantRoleApiRemovalIntegrationTest,AdminPermissionControllerTest,ImorphAdminRoleCreationIntegrationTest,P3AdminCrudIntegrationTest#tenantRoleCannotGrantPlatformOnlyPermissions' -Dsurefire.failIfNoSpecifiedTests=false test
JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin:$PATH mvn -q -pl iam-app -am '-Dtest=ImorphAdminRoleCreationIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false test
```

## Contracts and rollout limits
- Tenant lists/dialogs: GET /api/v1/admin/roles?scope_type=TENANT&scope_id=<tenant_id>. Platform aggregate: scope_type=PLATFORM&scope_id=PLATFORM; optional filter_scope_id narrows tenant selection. Requires iam:role:read; data.roles/data.count envelope.
- Permission catalog: GET /api/v1/admin/permissions exposes string tenant_grantable ("1"/"0"), app_code/category and permission metadata. Frontend filters tenant trees; tenant permission writes still independently enforce grantability and enabled apps.
- Role creation requires iam:role:write. That existing permission also authorizes role edit/delete/permission writes within the same scope guard; no new create-only capability was introduced.
- Backend prefix is /api/v1. External /v1 depends on proxy configuration. Independent frontend work is reported migrated by the user; this task did not access another project or run frontend tests.
- Deploy/restart the updated application with its configured Flyway repeatable seeds and issue fresh/refreshed tokens for existing Admin users. Current source has seed locations enabled in application.yml. No running service, live database, deployment or user token was modified in this session.
- Full repository suite was not run. No implementation blockers remain.

## Git / Trellis state
User explicitly requires uncommitted delivery. No commit/stage/push/merge/branch change/reset/worktree operation occurred. Task remains in_progress with delivery_state=validated_uncommitted; automatic commit/archive finish paths were not invoked. Session is recorded with add_session.py --no-commit. Existing unrelated active tasks were left unchanged.

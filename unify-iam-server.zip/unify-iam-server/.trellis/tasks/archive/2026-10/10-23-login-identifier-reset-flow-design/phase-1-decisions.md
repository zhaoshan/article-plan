# Phase 1 decision log

Date: 2026-10-23

## Confirmed product decisions

| Decision | Confirmed behavior | Consequence |
|---|---|---|
| Email-first branch | Browser submits email directly to an IAM API. | The endpoint is public and must be designed as a minimal browser-safe use case, not as a browser copy of the service-only user-exists API. |
| Existing account | Existing account immediately routes to password entry. | The public response needs only the approved existence decision; frontend maps true to password. |
| Absent account | Absent account immediately routes to account creation. | The public response needs only the approved existence decision; frontend maps false to account creation. |
| No additional user journey | No email-verification, magic-link, or added user-facing preflight. | Privacy-first alternatives are out of scope. Rate limiting and observability must be transparent technical controls. |

## Recommended contract, pending final approval

    POST /api/v1/auth/login/identifier
    { "email": "person@example.com" }
    -> data:{ "exists": true | false }

Reasons:

- POST avoids placing email in a URL.
- The existing API convention wraps normal /api/v1 JSON bodies in success/code/message/data.
- A boolean is the smallest payload that serves the confirmed immediate branch.
- It does not leak the existing service endpoint's auth_mode, user ID, tenancy, or IdP configuration.
- Existing POST /api/v1/auth/user-exists remains service-token-only and backward compatible.

## Remaining decisions that cannot be inferred

| Item | Why it blocks implementation | Required decision |
|---|---|---|
| OIDC-only account | exists=true would route to password entry, but no LOCAL credential exists; revealing tenant/IdP is not acceptable. | Confirm that the email-first flow applies only to the current local-account entry and enterprise SSO remains the existing separate entry, or explicitly authorize a third public outcome. |
| Suspended/pending account | Treating it as absent causes later unique-email failure; treating it as existing leads to generic password failure. | Confirm the intended generic browser behavior without disclosing lifecycle status. |
| Username/email compatibility | Existing password login only finds username; email-first routing can target a historical username-not-equal-email user. | Confirm email alias support in local password verification and collision-remediation policy, or retain a username field on the password page. |
| Registration shape | Existing RegisterRequest requires username and lets email be null. | Confirm whether create-account continues collecting username or derives a compatible username from the now-required email while preserving existing clients. |
| Reset mail release model | Current endpoint returns a development token and no mail is sent. | Confirm transport/secret management and whether queue/outbox delivery is available. |
| Abuse controls | A direct public exists endpoint is an accepted but sensitive enumeration oracle. | Confirm shared limiter storage, trusted proxy source-of-IP, ingress limits, audit retention, and alert ownership. |
| Post-reset access tokens | Current reset only revokes refresh tokens. | Confirm bounded expiry at current access-token TTL or immediate invalidation across all token consumers. |

No business implementation starts until every row above has a resolved owner and approved direction.

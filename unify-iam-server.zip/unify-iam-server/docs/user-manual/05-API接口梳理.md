# IAM API 接口梳理（docs/user-manual/05）

> 定位：按**使用方/调用方**分类梳理 IAM 全部接口——① 业务系统对接（后端调用：服务间 / 用户 Bearer / 公开）、② IAM 前端（hub：登录/注册/我的身份/切换）、③ **前端管理台接口**（`/api/v1/admin/**`，给 `platform-iam-web` 的 `/admin` 管理页面用）。
> 契约：**全部 `/api/v1/**` JSON 接口统一返回信封 `{success, code, message, data}`**——成功 `data` 为业务体（数组或对象），失败真实状态码 + 信封（`message` 为文案）。唯一例外：`/api/v1/auth/oidc/**`（OIDC 重定向流程，见下）与 `/.well-known/jwks.json`（裸 JWK Set）。
> 版本基线：2026-10-20。

---

## 使用方与鉴权模型（先读）

**「前端」和「前端管理台」是同一个前端应用（`platform-iam-web`）的两块页面，不是两套系统**——它们调不同的后端路由族、用不同的鉴权门槛。

| 使用方 | 是什么 | 典型页面/调用 | 后端路由族 | 鉴权模型 |
|---|---|---|---|---|
| **业务系统后端** | parlant / ai-chat-insight / iMorph 等**其他业务系统的后端** | 登录转发、验签、后台任务状态校验 | `/api/v1/auth/**`（部分） | `Service` 服务令牌 / 透传用户 `Bearer` / `公开` |
| **IAM 前端（hub）** | `platform-iam-web` 的**身份入口区** | `/login`、`/register`、`/forgot-password`、`/admin/me`（我的身份）、租户切换 | `/api/v1/auth/**`、`/api/v1/memberships/**` | `公开` 或 `Bearer`（只要求登录态） |
| **IAM 前端管理台** | `platform-iam-web` 的 `/admin` **管理页面** | 用户/租户/成员/角色/权限/SSO 配置/审计 | `/api/v1/admin/**` | `Bearer` + `iam:*` 权限点 + 作用域（`TenantScopeGuard`，默认拒绝） |

**鉴权机制记号**：

| 记号 | 含义 |
|---|---|
| `公开` | 无需鉴权（登录/注册/找回/JWKS/SSO 发起等） |
| `Bearer` | 用户 JWT（`Authorization: Bearer <token>`）；只校验登录态 |
| `iam:*` | 管理面权限点（`@RequirePermission`）+ 作用域；未认证 401、缺权限 403（`/api/v1/admin/**` 全局拦截、默认拒绝） |
| `Service` | 服务间令牌 `X-IAM-Service-Token`（=`iam.versions.service-token`），无用户 token |

> 说明：IAM 没有独立的前端专用代理进程；「前端管理台接口」指专为前端管理台（`platform-iam-web` 的 `/admin` 页面）提供的后端接口（`/api/v1/admin/**`），与面向业务系统的外部契约端点（`/api/v1/auth/**`）相对。

### 统一返回信封（{success, code, message, data}）

**全部 `/api/v1/**` JSON 接口**（管理台、hub、业务系统端点）的成功与失败都套信封：成功 `data` 为业务体（数组或对象），失败真实状态码 + `data=null` + `message` 为文案。判定集中在 IAM `EnvelopePaths.inScope`（`ApiEnvelopeAdvice` 套成功、`GlobalExceptionHandler` 套失败）。

前端 `client.ts` 按响应是否带 `success` 判别（无需路径白名单）：成功透出 `data`，失败抛 `ApiError`（`message`/`detail` 二选一）。业务系统消费端（parlant-agent `app/routers/auth.py` 登录/刷新、`app/authz/versions.py` 版本 feed）已同步按 `data` 解包。

**例外（保持非信封形态）**：

| 端点 | 形态 |
|---|---|
| `/api/v1/auth/oidc/**`（authorize/callback） | 标准 OIDC 重定向流程：成功 302（callback 带 `?access_token=` 回跳），错误真实状态码 + `{"detail":...}` |
| `/.well-known/jwks.json` | 裸 JWK Set（标准 JOSE 客户端直接消费，不可套） |

---

## 1. 业务系统对接（后端调用）

> 供 parlant、ai-chat-insight、iMorph 等业务系统后端调用。业务系统可经自己的**业务后端转发**（同源）或直连 IAM。

### 1.1 服务间（`X-IAM-Service-Token`，无用户 token）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/v1/auth/versions?app_code=&since=&membership_id=` | 权限版本 feed：增量游标 / 全量快照 / 点查；tombstone=`version:-1`（方案 c 即时吊销） |
| POST | `/api/v1/auth/status-check` | 后台任务执行前校验：按任务提交时存的 `{tenant_id,membership_id}` 返回 `valid`（租户/成员停用即 false，不再执行任务） |
| POST | `/api/v1/auth/user-exists` | 邮箱存在性判定（G8 登录/注册两段式）：body `{email}` → `data:{exists, auth_mode}`——有 LOCAL 身份→`password`、仅 OIDC→`sso`（两者都有→`password`，依据 identity 而非 registration_source）；防枚举：仅服务间可调、响应只回 exists+auth_mode、调用方限流 |

### 1.2 用户 Bearer（带用户 token，业务系统透传）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/v1/auth/me` | 当前用户上下文（claims 快照） |
| GET | `/api/v1/auth/session-status` | 当前上下文**权威状态**（读库：tenant_status/membership_status/valid） |
| GET | `/api/v1/auth/tenant-status?tenant_id=` | 查询某租户状态（限调用者自己成员关系，防枚举） |
| GET | `/api/v1/auth/app-access?app_code=` | 登录后能力检查（可选租户 / 跳 IAM 控制台 / 阻断） |
| POST | `/api/v1/auth/switch-tenant` | 切换租户 → 重签 access+refresh |
| GET | `/api/v1/auth/memberships` | 当前用户可切换成员列表（G9 增强：`tenant_type`/`roles`/`is_owner`/`is_current`/`last_opened_at`/`tenant_created_at`/`joined_at`，供租户切换菜单的类型/角色徽标与 Last opened/Created time 排序） |
| POST | `/api/v1/auth/refresh` | 静默刷新（refresh 轮换：旧作废+新返回） |
| POST | `/api/v1/auth/logout` | 登出（撤销 refresh token） |

### 1.3 公开（无需鉴权）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/.well-known/jwks.json` | 公钥（RS256，kid=iam-key-1）——业务系统验签用 |
| POST | `/api/v1/auth/token` | 本地密码登录（业务后端转发）→ `{access_token, refresh_token, ...}` |
| GET | `/api/v1/auth/oidc/authorize?tenant_id=` | 企业 SSO 发起（302 跳 IdP） |
| GET | `/api/v1/auth/oidc/callback` | SSO 回调（302 回前端，携带 access/refresh token） |
| POST | `/api/v1/auth/dev-token` | ⚠️ dev 免密发 token（**生产必须 `IAM_DEVTOKEN_ENABLED=false`**） |

> 业务系统验签链路：`/.well-known/jwks.json` 取公钥 → RS256 验签 + `aud` 含本应用 app_code + `iss` 逐字 + `exp`；权限新鲜度用 §1.1 versions feed（`ver` 比对）。

## 2. IAM 前端接口（hub：platform-iam-web，浏览器同源）

> hub 前端（登录/注册/我的身份/租户切换）直接调用；业务系统前端不经 IAM（跳 hub 登录，见 `03-业务系统接入指南`）。

| 方法 | 路径 | 鉴权 | 说明 |
|---|---|---|---|
| GET | `/api/v1/auth/sso/tenants?app_code=` | 公开 | 登录页「企业组织」下拉（`?app=` 只列启用该应用的租户） |
| GET | `/api/v1/auth/return-origins` | 公开 | 回跳 `return_to` 白名单（server 下发，防 open redirect） |
| POST | `/api/v1/auth/register` | 公开 | 注册（建 LOCAL 身份 + 个人租户 owner） |
| POST | `/api/v1/auth/forgot-password` | 公开 | 找回密码 |
| POST | `/api/v1/auth/reset-password` | 公开 | 重置密码 |
| POST | `/api/v1/auth/change-password` | Bearer | 登录态改密（G2 首登强制改密）：`{old_password,new_password}` → 校验旧密码、清零 `must_change_password`、不吊销当前会话（与「忘记密码重置吊销全部 refresh」区分） |
| POST | `/api/v1/auth/token` | 公开 | 本地登录 |
| POST | `/api/v1/auth/refresh` | Bearer | 401 静默刷新（client.ts trySilentRefresh） |
| GET | `/api/v1/auth/me` | Bearer | 我的身份 |
| GET | `/api/v1/auth/memberships` | Bearer | 多租户列表（G9 增强字段见 §1.2） |
| POST | `/api/v1/auth/switch-tenant` | Bearer | 切换租户 |
| GET | `/api/v1/auth/app-access?app_code=` | Bearer | 登录后选租户/跳控制台/阻断分流 |
| GET | `/api/v1/auth/session-status` | Bearer | 当前上下文权威状态 |
| GET | `/api/v1/auth/tenant-status?tenant_id=` | Bearer | 租户状态（限自己成员） |
| GET | `/api/v1/auth/oidc/authorize?tenant_id=` | 公开 | 企业 SSO 发起 |
| GET | `/api/v1/auth/oidc/callback` | 公开 | SSO 回调收 token |
| POST | `/api/v1/memberships/join-request` | Bearer | 发起加入申请 |
| POST | `/api/v1/auth/invitations/{token}/accept` | Bearer | 接受邀请（**必须登录**+邀请邮箱==当前账号，不符 403；无成员则建成员+按邀请角色绑定，幂等）；响应 `data:{status, redirect_url}`——redirect_url 由后端解析（invitation.app_code → iam_application.homepage_url → yml iam.app-homepages.<code> → 邀请链接基址兜底），前端只认它跳转 |

## 3. 前端管理台接口（`/api/v1/admin/**`）

> 供 `platform-iam-web` 的前端管理台各页面（用户/租户/成员/角色/权限/应用/SSO配置/审计）调用；鉴权 = Bearer + `iam:*` 权限点（`@RequirePermission`，未授权 403）。

### 3.1 用户（iam:user:*，仅平台）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/users` |
| GET/PUT/DELETE | `/api/v1/admin/users/{userId}` |

### 3.2 租户（iam:tenant:*，平台；更新/删除限作用域）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/tenants`（POST 支持 `owner_email`——G2 A-02「Create and send invite」：任意 Owner 邮箱，不存在则 JIT 建号+初始密码并发送 Owner 邀请邮件；与 `owner_user_id` 并存） |
| GET | `/api/v1/admin/tenants/{tenantId}/usage`（G1 Usage 视图：全局 iam 维度+已启用应用维度，行含 limit/used/pending/remaining） |
| PUT | `/api/v1/admin/tenants/{tenantId}/usage/{dimensionId}`（G1 租户调额 `{limit_value}`；null=清除覆盖回落模板默认） |
| GET/PUT/DELETE | `/api/v1/admin/tenants/{tenantId}` |
| GET | `/api/v1/admin/tenants/{tenantId}/applications`（iam:role:read，角色配置用） |
| POST | `/api/v1/admin/tenants/{tenantId}/domains`（域名验证） |
| POST | `/api/v1/admin/domains/{domainId}/verify` |

### 3.3 成员（iam:member:*，租户）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/members` |
| GET/PUT | `/api/v1/admin/members/{membershipId}/roles` |
| POST | `/api/v1/admin/members/{membershipId}/suspend`（停用，G2） |
| POST | `/api/v1/admin/members/{membershipId}/restore`（恢复） |
| DELETE | `/api/v1/admin/members/{membershipId}`（移除） |

### 3.4 角色与权限（iam:role:*）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/roles` |
| GET/PUT | `/api/v1/admin/roles/{roleId}/permissions`（TENANT 角色受 `tenant_grantable` 约束） |
| DELETE | `/api/v1/admin/roles/{roleId}` |
| GET | `/api/v1/admin/permissions`（权限点目录，含 app_code/tenant_grantable） |

### 3.5 应用与目录（iam:role:*）
| 方法 | 路径 |
|---|---|
| GET | `/api/v1/admin/applications`（应用注册表） |
| GET | `/api/v1/admin/user-directory`（用户目录检索） |

### 3.6 SSO 配置（iam:idp:*，仅平台）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/idp-configs` |
| PUT/DELETE | `/api/v1/admin/idp-configs/{configId}` |
| GET/POST/PUT/DELETE | `/api/v1/admin/idp-configs/{configId}/group-mappings[/{mappingId}]`（组→角色映射） |

### 3.7 审计（iam:audit:read，仅平台）
| 方法 | 路径 |
|---|---|
| GET | `/api/v1/admin/audit` |

### 3.8 邀请与加入申请（iam:member:*，租户）
| 方法 | 路径 |
|---|---|
| POST | `/api/v1/admin/invitations`（创建邀请——G2：按邮箱分支 JIT 建号+初始密码（不存在）/省略密码行（已存在）并发送邀请邮件；`role_id` 可选，不传默认当前租户 is_owner 模板角色；`app_code` 盖默认应用（邮件链接 `?token=..&app=imorph`）；dev 仍返回 token） |
| GET | `/api/v1/admin/join-requests` |
| POST | `/api/v1/admin/join-requests/{id}/approve` / `{id}/reject` |

---

## 4. 相关文档

- 接入方：`03-业务系统接入指南`（登录/验签/鉴权/权限变更即时生效）
- 业务逻辑：`04-业务逻辑流程`（角色/权限展示与校验）
- 需求与差距：`../requirements/M10W3-能力盘点与IAM差距分析.md`
- 管理台：`01-平台管理员手册` / `02-租户管理员手册`

package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.auth.DevTokenRequest;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import org.springframework.stereotype.Service;

/**
 * dev-token 签发：按 seed 用户/角色直签，联调/Postman 友好（不校验密码）。
 * prod 通过 {@code iam.dev-token-enabled=false} 禁用。
 */
@Service
public class DevTokenService {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(DevTokenService.class);

    private final UserRepository userRepository;
    private final MembershipResolver membershipResolver;
    private final TokenService tokenService;
    private final IamProperties props;

    public DevTokenService(UserRepository userRepository,
                           MembershipResolver membershipResolver,
                           TokenService tokenService,
                           IamProperties props) {
        this.userRepository = userRepository;
        this.membershipResolver = membershipResolver;
        this.tokenService = tokenService;
        this.props = props;
    }

    /** P0-07：dev-token 开启时启动告警——生产误配置兜底（warn 醒目，拒绝忽略）。 */
    @jakarta.annotation.PostConstruct
    void warnIfEnabled() {
        if (props.isDevTokenEnabled()) {
            log.warn("SECURITY: dev-token endpoint ENABLED (passwordless token issuance) —— "
                    + "仅本地/测试允许，生产必须关闭（P0-07）");
        }
    }

    public LoginResponse issueDev(DevTokenRequest request) {
        if (!props.isDevTokenEnabled()) {
            throw AuthException.forbidden(ErrorCode.DEV_TOKEN_DISABLED);
        }
        if (!request.hasUserRef()) {
            throw AuthException.badRequest(ErrorCode.USERID_OR_USERNAME_REQUIRED);
        }
        UserPO user = resolveUser(request);
        MembershipPO membership = resolveMembership(request, user);
        UserPrincipal principal = new UserPrincipal(user.getUserId().trim(), user.getUsername(), null);
        return tokenService.issueWithRefresh(principal, membership);
    }

    private UserPO resolveUser(DevTokenRequest request) {
        if (request.userId() != null && !request.userId().isBlank()) {
            return userRepository.findByUserId(request.userId().trim())
                    .orElseThrow(() -> AuthException.notFound(ErrorCode.USER_NOT_FOUND));
        }
        return userRepository.findByUsername(request.username().trim())
                .orElseThrow(() -> AuthException.notFound(ErrorCode.USER_NOT_FOUND));
    }

    private MembershipPO resolveMembership(DevTokenRequest request, UserPO user) {
        if (request.membershipId() != null && !request.membershipId().isBlank()) {
            return membershipResolver.findById(request.membershipId().trim())
                    .filter(m -> m.getUserId().equals(user.getUserId().trim()))
                    .orElseThrow(() -> AuthException.notFound(ErrorCode.MEMBERSHIP_NOT_FOUND));
        }
        return membershipResolver.findDefaultActiveMembership(user.getUserId().trim())
                .orElseThrow(() -> AuthException.notFound(ErrorCode.NO_AVAILABLE_MEMBERSHIP));
    }
}

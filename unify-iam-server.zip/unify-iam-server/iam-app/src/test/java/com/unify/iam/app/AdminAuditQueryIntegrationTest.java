package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/** Covers the database-backed audit keyword and date-range contract. */
class AdminAuditQueryIntegrationTest extends IamIntegrationTestBase {

    private static final ZoneId AUDIT_TIME_ZONE = ZoneId.of("Asia/Shanghai");

    private String adminToken() throws Exception {
        return token("admin", "admin123");
    }

    private String token(String username, String password) throws Exception {
        MvcResult response = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(response.getResponse().getContentAsString()), LoginResponse.class)
                .accessToken();
    }

    @Test
    void listOmitsStoredRequestContextAndSnapshotsWhileRetainingOtherFields() throws Exception {
        String auditId = "audit-projection-20310405";
        LocalDateTime time = LocalDate.of(2031, 4, 5).atTime(9, 0);
        insertAudit(auditId, "ADMIN_UPDATE_TENANT", "u-1000", time);
        jdbcTemplate.update("""
                        UPDATE gateway_audit_log
                        SET actor_membership_id = 'ms-1001', request_id = 'audit-projection-request',
                            ip_address = '192.0.2.42', user_agent = 'AuditProjectionTest/1.0',
                            before_json = '{"tenant_status":"ACTIVE"}',
                            after_json = '{"tenant_status":"DISABLED"}',
                            metadata_json = '{"source":"projection-test"}', trace_id = 'projection-trace'
                        WHERE audit_log_id = ?
                        """, auditId);

        MvcResult result = mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("tenant_ids", "tenant-org-a", "tenant-history-missing")
                        .param("keyword", "UPDATE_TENANT")
                        .param("start_time", "2031-04-05")
                        .param("end_time", "2031-04-05"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(1))
                .andExpect(jsonPath("$.data.page").value(1))
                .andExpect(jsonPath("$.data.size").value(20))
                .andExpect(jsonPath("$.data.audits.length()").value(1))
                .andExpect(jsonPath("$.data.audits[0].request_id").doesNotHaveJsonPath())
                .andExpect(jsonPath("$.data.audits[0].ip_address").doesNotHaveJsonPath())
                .andExpect(jsonPath("$.data.audits[0].user_agent").doesNotHaveJsonPath())
                .andExpect(jsonPath("$.data.audits[0].before_json").doesNotHaveJsonPath())
                .andExpect(jsonPath("$.data.audits[0].after_json").doesNotHaveJsonPath())
                .andReturn();

        List<?> audits = (List<?>) unwrapField(result.getResponse().getContentAsString(), "audits");
        Map<?, ?> row = (Map<?, ?>) audits.getFirst();
        assertThat(row.keySet().stream().map(Object::toString).toList()).containsExactlyInAnyOrderElementsOf(List.of(
                "audit_log_id", "tenant_id", "tenant_name", "actor_user_id", "actor_username",
                "actor_membership_id", "event_type", "event_name", "target_type", "target_id",
                "target_display", "result_status", "metadata_json", "trace_id", "create_time"));
        assertThat(row.get("audit_log_id")).isEqualTo(auditId);
        assertThat(row.get("tenant_id")).isEqualTo("tenant-org-a");
        assertThat(row.get("tenant_name")).isEqualTo("Org A");
        assertThat(row.get("actor_user_id")).isEqualTo("u-1000");
        assertThat(row.get("actor_username")).isEqualTo("admin");
        assertThat(row.get("actor_membership_id")).isEqualTo("ms-1001");
        assertThat(row.get("event_type")).isEqualTo("ADMIN_UPDATE_TENANT");
        assertThat(row.get("event_name")).isEqualTo("更新租户（启停/改名/域名）");
        assertThat(row.get("target_type")).isEqualTo("TENANT");
        assertThat(row.get("target_id")).isEqualTo("tenant-org-a");
        assertThat(row.get("target_display")).isEqualTo("Org A");
        assertThat(row.get("result_status")).isEqualTo("SUCCESS");
        assertThat(JsonUtils.fromJson(row.get("metadata_json").toString(), Map.class))
                .containsEntry("source", "projection-test");
        assertThat(row.get("trace_id")).isEqualTo("projection-trace");
        assertThat(row.get("create_time")).isEqualTo("2031-04-05T09:00:00Z"); // 2026-11-03 起 LocalDateTime 统一输出带 Z 的 UTC ISO

        // A missing JSON path must result from the response contract, not NULL storage/serialization.
        Map<String, Object> stored = jdbcTemplate.queryForMap("""
                        SELECT request_id, ip_address, user_agent, before_json, after_json
                        FROM gateway_audit_log WHERE audit_log_id = ?
                        """, auditId);
        assertThat(stored).hasSize(5);
        assertThat(stored.values()).allSatisfy(value -> assertThat(value).isNotNull());
    }

    @Test
    void keywordFiltersEventTypeEventNameAndActorUserInsteadOfBeingIgnored() throws Exception {
        LocalDate date = LocalDate.of(2031, 2, 3);
        LocalDateTime start = date.atStartOfDay();
        String auditId = "audit-keyword-20310203";
        String otherAuditId = "audit-keyword-other-20310203";
        insertAudit(auditId, "ADMIN_UPDATE_TENANT", "u-1000", start.plusHours(9));
        insertAudit(otherAuditId, "ADMIN_CREATE_TENANT", "u-1001", start.plusHours(10));
        String token = adminToken();

        assertSingleAuditMatch(token, "UPDATE_TENANT", date, auditId);
        assertSingleAuditMatch(token, "更新租户", date, auditId);
        assertSingleAuditMatch(token, "u-1000", date, auditId);
        assertSingleAuditMatch(token, "operator", date, otherAuditId);
        assertNoAuditMatch(token, "%", date);
    }

    @Test
    void dateRangeIncludesBothShanghaiCalendarDaysAndExcludesTheFollowingDay() throws Exception {
        LocalDate startDate = LocalDate.of(2031, 2, 20);
        LocalDate endDate = startDate.plusDays(1);
        LocalDateTime start = startDate.atStartOfDay();
        LocalDateTime afterEnd = endDate.plusDays(1).atStartOfDay();
        String atStart = "audit-range-start-20310220";
        String beforeEnd = "audit-range-before-end-20310221";
        String atEnd = "audit-range-end-20310222";
        // 2026-11-04：库存 UTC 化（connectionTimeZone=UTC）——测试数据须写 UTC 瞬时值：
        // 「上海日历日 00:00」的墙钟先按上海时区解释为 instant 再转 UTC 落库
        java.time.ZoneId shanghai = java.time.ZoneId.of("Asia/Shanghai");
        insertAudit(atStart, "ADMIN_CREATE_TENANT", "u-1000",
                start.atZone(shanghai).withZoneSameInstant(java.time.ZoneOffset.UTC).toLocalDateTime());
        insertAudit(beforeEnd, "ADMIN_CREATE_TENANT", "u-1000",
                afterEnd.minusSeconds(1).atZone(shanghai).withZoneSameInstant(java.time.ZoneOffset.UTC).toLocalDateTime());
        insertAudit(atEnd, "ADMIN_CREATE_TENANT", "u-1000",
                afterEnd.atZone(shanghai).withZoneSameInstant(java.time.ZoneOffset.UTC).toLocalDateTime());

        MvcResult result = mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("start_time", startDate.toString())
                        .param("end_time", endDate.toString())
                        .param("page", "1")
                        .param("size", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(2))
                .andExpect(jsonPath("$.data.audits[?(@.audit_log_id == '" + atStart + "')]").exists())
                .andExpect(jsonPath("$.data.audits[?(@.audit_log_id == '" + beforeEnd + "')]").exists())
                .andExpect(jsonPath("$.data.audits[?(@.audit_log_id == '" + atEnd + "')]").doesNotExist())
                .andReturn();

        assertThat(result.getResponse().getContentAsString()).contains(atStart).contains(beforeEnd).doesNotContain(atEnd);
    }

    @Test
    void timeRangeAcceptsFrontendOffsetDateTimes() throws Exception {
        LocalDateTime start = LocalDateTime.of(2031, 2, 6, 0, 0);
        LocalDateTime end = start.plusDays(1);
        String auditId = "audit-offset-20310206";
        insertAudit(auditId, "ADMIN_CREATE_TENANT", "u-1000", start.plusHours(8));

        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("start_time", formatOffset(start))
                        .param("end_time", formatOffset(end)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(1))
                .andExpect(jsonPath("$.data.audits[0].audit_log_id").value(auditId));

        // The same Shanghai interval expressed as UTC proves the server compares normalized instants.
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("start_time", formatUtcOffset(start))
                        .param("end_time", formatUtcOffset(end)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(1))
                .andExpect(jsonPath("$.data.audits[0].audit_log_id").value(auditId));
    }

    @Test
    void timeRangeAllowsOneBoundAndRequiresAPositiveWindow() throws Exception {
        String token = adminToken();
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("start_time", "2031-02-06"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("start_time", "2031-02-07")
                        .param("end_time", "2031-02-06"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("end_time must be later than start_time"));

        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("start_time", "not-a-time")
                        .param("end_time", "2031-02-07"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.code").value("IAM-VALID-010"))
                .andExpect(jsonPath("$.message").value(
                        "start_time must be an ISO-8601 timestamp with Z or an explicit offset, e.g. 2026-10-26T00:00:00Z; legacy YYYY-MM-DD and local timestamps use Asia/Shanghai"));
    }

    @Test
    void utcRangeIncludesStartAndExcludesEnd() throws Exception {
        String tenant = "tenant-utc-boundary";
        LocalDateTime start = LocalDateTime.of(2032, 6, 1, 16, 0);
        insertAudit("utc-before", tenant, "ADMIN_CREATE_TENANT", "u-1000", start.minusSeconds(1));
        insertAudit("utc-start", tenant, "ADMIN_CREATE_TENANT", "u-1000", start);
        insertAudit("utc-last", tenant, "ADMIN_CREATE_TENANT", "u-1000", start.plusDays(1).minusSeconds(1));
        insertAudit("utc-end", tenant, "ADMIN_CREATE_TENANT", "u-1000", start.plusDays(1));
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken()).param("tenant_id", tenant)
                        .param("start_time", "2032-06-01T16:00:00Z")
                        .param("end_time", "2032-06-02T16:00:00Z"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(2))
                .andExpect(jsonPath("$.data.audits[0].audit_log_id").value("utc-last"))
                .andExpect(jsonPath("$.data.audits[1].audit_log_id").value("utc-start"));
    }

    @Test
    void timeRangeIndexesAreAppliedByFlyway() {
        List<String> indexes = jdbcTemplate.queryForList("""
                        SELECT DISTINCT index_name
                        FROM information_schema.statistics
                        WHERE table_schema = DATABASE()
                          AND table_name = 'gateway_audit_log'
                        """, String.class);

        assertThat(indexes).contains("idx_audit_time_id", "idx_audit_tenant_time_id");
    }

    @Test
    void tenantIdsOrTogetherAndWithKeywordDateOnlyRangeAndPaginationTotal() throws Exception {
        LocalDate date = LocalDate.of(2031, 3, 4);
        LocalDateTime start = date.atStartOfDay();
        String tenantA = "tenant-multi-a";
        String tenantB = "tenant-multi-b";
        String tenantOther = "tenant-multi-other";
        String auditA = "audit-multi-a-20310304";
        String auditB = "audit-multi-b-20310304";
        String auditOther = "audit-multi-other-20310304";
        insertAudit(auditA, tenantA, "ADMIN_UPDATE_TENANT", "u-1000", start.plusHours(9));
        insertAudit(auditB, tenantB, "ADMIN_UPDATE_TENANT", "u-1000", start.plusHours(10));
        insertAudit(auditOther, tenantOther, "ADMIN_UPDATE_TENANT", "u-1000", start.plusHours(11));
        insertAudit("audit-mkwd-20310304", tenantB,
                "ADMIN_CREATE_TENANT", "u-1000", start.plusHours(12));
        insertAudit("audit-mdate-20310305", tenantA,
                "ADMIN_UPDATE_TENANT", "u-1000", start.plusDays(1).plusHours(1));
        String token = adminToken();

        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("tenant_ids", " " + tenantA + " ", tenantB, tenantA, "tenant-history-missing")
                        .param("keyword", "UPDATE_TENANT")
                        .param("start_time", date.toString())
                        .param("end_time", date.toString())
                        .param("page", "1")
                        .param("size", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(2))
                .andExpect(jsonPath("$.data.audits.length()").value(1))
                .andExpect(jsonPath("$.data.audits[0].audit_log_id").value(auditB));

        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("tenant_ids", tenantA, tenantB)
                        .param("keyword", "UPDATE_TENANT")
                        .param("start_time", date.toString())
                        .param("end_time", date.toString())
                        .param("page", "2")
                        .param("size", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(2))
                .andExpect(jsonPath("$.data.audits[0].audit_log_id").value(auditA));

        // Legacy singleton callers preserve exact filtering when the new parameter is absent.
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("tenant_id", tenantA)
                        .param("keyword", "UPDATE_TENANT")
                        .param("start_time", date.toString())
                        .param("end_time", date.toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(1))
                .andExpect(jsonPath("$.data.audits[0].audit_log_id").value(auditA));

        // Supplying both forms creates one OR set instead of silently preferring one parameter.
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("tenant_id", tenantA)
                        .param("tenant_ids", tenantB)
                        .param("keyword", "UPDATE_TENANT")
                        .param("start_time", date.toString())
                        .param("end_time", date.toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(2));

        // A blank/empty multiple-selection is deliberately the all-tenants state.
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("tenant_ids", "")
                        .param("keyword", "UPDATE_TENANT")
                        .param("start_time", date.toString())
                        .param("end_time", date.toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(3));
    }

    @Test
    void tenantIdsRequireRepeatedEncodingAndPreserveAuditAuthorizationBoundary() throws Exception {
        mockMvc.perform(get("/api/v1/admin/audit")
                        .param("tenant_ids", "tenant-a,tenant-b"))
                .andExpect(status().isUnauthorized());

        String viewer = token("viewer", "view123");
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + viewer)
                        .param("tenant_ids", "tenant-a", "tenant-b"))
                .andExpect(status().isForbidden());

        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("tenant_ids", "tenant-a,tenant-b"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value(
                        "tenant_ids must be passed as repeated query parameters, not tenant_ids[] or comma-separated"));

        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("tenant_ids[]", "tenant-a"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(
                        "tenant_ids must be passed as repeated query parameters, not tenant_ids[] or comma-separated"));

        String[] tooManyTenantIds = new String[101];
        for (int index = 0; index < tooManyTenantIds.length; index++) {
            tooManyTenantIds[index] = "tenant-limit-" + index;
        }
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("tenant_ids", tooManyTenantIds))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("tenant_ids supports at most 100 entries"));
    }

    private void assertSingleAuditMatch(String token,
                                        String keyword,
                                        LocalDate date,
                                        String auditId) throws Exception {
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("keyword", keyword)
                        .param("start_time", date.toString())
                        .param("end_time", date.toString())
                        .param("page", "1")
                        .param("size", "20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(1))
                .andExpect(jsonPath("$.data.audits.length()").value(1))
                .andExpect(jsonPath("$.data.audits[0].audit_log_id").value(auditId));
    }

    private void assertNoAuditMatch(String token, String keyword, LocalDate date) throws Exception {
        mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("keyword", keyword)
                        .param("start_time", date.toString())
                        .param("end_time", date.toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").value(0));
    }

    private void insertAudit(String auditLogId, String eventType, String actorUserId, LocalDateTime createTime) {
        insertAudit(auditLogId, "tenant-org-a", eventType, actorUserId, createTime);
    }

    private void insertAudit(String auditLogId,
                             String tenantId,
                             String eventType,
                             String actorUserId,
                             LocalDateTime createTime) {
        jdbcTemplate.update("""
                        INSERT INTO gateway_audit_log
                            (audit_log_id, tenant_id, actor_user_id, event_type, target_type, target_id,
                             result_status, delete_flag, create_time, update_time)
                        VALUES (?, ?, ?, ?, 'TENANT', ?, 'SUCCESS', 0, ?, ?)
                        """,
                auditLogId, tenantId, actorUserId, eventType, tenantId, createTime, createTime);
    }

    private String formatOffset(LocalDateTime time) {
        return time.atZone(AUDIT_TIME_ZONE).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    private String formatUtcOffset(LocalDateTime time) {
        return time.atZone(AUDIT_TIME_ZONE)
                .withZoneSameInstant(ZoneOffset.UTC)
                .format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }
}

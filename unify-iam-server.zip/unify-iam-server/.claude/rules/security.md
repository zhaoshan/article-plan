---
path: iam-*/src/main/java/** , docs/**
description: IAM 安全约束（改动前必读，源自 OWASP JWT / OIDC 最佳实践）
---

- **JWT 校验**：算法白名单 `RS256/ES256`，**显式禁用 `none` 与 HS 系**（防伪造 + 密钥/算法混淆）；校验 `iss`/`aud`/`exp`/`nonce`；JWKS 按 `kid` 选钥 + 缓存 + 未知 kid 回源。
- **iss/aud 双向校验**：`aud` 含本服务标识、`iss` 与预期 issuer 逐字相等，缺一不可（防 issuer/audience 混淆）。
- **JWT 非机密**：签名不加密，claims 可读——token 不承载密钥/密码等敏感值。
- **吊销/重放**：无状态 JWT 需 denylist/短 TTL 才可即时吊销；用短 TTL + nonce 防重放、refresh token 轮换；**方案 c 即时吊销（V10）**：角色/权限/成员变更 bump `membership.token_version` + 版本 feed（`X-IAM-Service-Token` 鉴权、app 作用域、增量游标、tombstone 哨兵 `version:-1`），parlant 缓存后感知延迟 = feed 刷新间隔；生产 TTL 可调短（15–60min）。
- **OIDC 回调 redirect 白名单**：`iam.oidc.frontend-redirect` 用配置值、不回显用户输入（防 open redirect）。
- **统一信封**：全部 `/api/v1/**` JSON 接口成功与失败套 `{success,code,message,data}`（失败真实状态码，`message` 为文案；防枚举 401 语义不变）；**仅 `/api/v1/auth/oidc/**` 排除**（重定向流程，错误体 `{"detail":...}`）；`/.well-known/jwks.json` 保持裸 JWK Set（标准 JOSE 客户端消费）。消费端（parlant `auth.py`/`versions.py`、web `client.ts`）按 `data` 解包。
- **默认最小权限**：无权限点即 403；P3 管理面 `/api/v1/admin/**` 默认拒绝 + 显式白名单，用 `iam:*` 权限点（与业务 9 码分离）。
- **签名私钥**：`keys/*.pem` 永不提交、不落日志；路径由 `IAM_JWT_PRIVATE_KEY_PATH` 固定；换钥靠 kid 并存窗口；公钥只经 `/.well-known/jwks.json` 发布。
- **敏感数据**：`client_secret_cipher` 需加密存储；token/密钥不写日志。
- **契约锁死**：JWT `aud`（租户启用应用 ∩ `iam.jwt.audiences` 白名单，单值字符串/多值数组）、单租户语义、`PermissionCodes` 9 码与 parlant 同套；改一处同步另一处。

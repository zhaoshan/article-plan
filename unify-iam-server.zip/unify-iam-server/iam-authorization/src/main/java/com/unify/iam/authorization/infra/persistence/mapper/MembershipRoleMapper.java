package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.MembershipRolePO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/** gateway_membership_role Mapper。 */
@Mapper
public interface MembershipRoleMapper extends BaseMapper<MembershipRolePO> {

    /**
     * 复活逻辑删除的成员-角色绑定（原生 UPDATE，绕过 @TableLogic 的 delete_flag=0 过滤——
     * 软删后唯一键 (membership_id, role_id) 仍占位，重新授予需复活而非重插；参照 TenantApplicationMapper.restore）。
     *
     * @return 命中的行数（0 表示无墓碑，调用方改走 insert）
     */
    @Update("UPDATE gateway_membership_role SET delete_flag = 0, grant_source = #{grantSource}, update_time = NOW() "
            + "WHERE membership_id = #{membershipId} AND role_id = #{roleId} AND delete_flag = 1")
    int revive(@Param("membershipId") String membershipId,
               @Param("roleId") String roleId,
               @Param("grantSource") String grantSource);

    // ── G3 最后管理员保护：租户管理能力 = 持有 iam:member:write / iam:role:write（租户可授管理权限） ──

    /** 某成员持有的「租户管理能力」角色数（>0 即视为租户管理员，G3）。 */
    @Select("SELECT COUNT(DISTINCT mr.role_id) FROM gateway_membership_role mr "
            + "JOIN gateway_role r ON r.role_id = mr.role_id AND r.delete_flag = 0 AND r.role_status = 'ACTIVE' "
            + "JOIN gateway_role_permission rp ON rp.role_id = r.role_id AND rp.delete_flag = 0 "
            + "JOIN gateway_permission p ON p.permission_id = rp.permission_id AND p.delete_flag = 0 "
            + "WHERE mr.membership_id = #{membershipId} AND mr.delete_flag = 0 "
            + "AND p.permission_code IN ('iam:member:write', 'iam:role:write')")
    int countAdminCapableRolesByMembership(@Param("membershipId") String membershipId);

    /** 某租户内、除指定成员外，仍持「租户管理能力」的 ACTIVE 成员数（G3 触底判定）。 */
    @Select("SELECT COUNT(DISTINCT m.membership_id) FROM gateway_membership m "
            + "JOIN gateway_membership_role mr ON mr.membership_id = m.membership_id AND mr.delete_flag = 0 "
            + "JOIN gateway_role r ON r.role_id = mr.role_id AND r.delete_flag = 0 AND r.role_status = 'ACTIVE' "
            + "JOIN gateway_role_permission rp ON rp.role_id = r.role_id AND rp.delete_flag = 0 "
            + "JOIN gateway_permission p ON p.permission_id = rp.permission_id AND p.delete_flag = 0 "
            + "WHERE m.tenant_id = #{tenantId} AND m.membership_status = 'ACTIVE' AND m.delete_flag = 0 "
            + "AND m.membership_id != #{excludeMembershipId} "
            + "AND p.permission_code IN ('iam:member:write', 'iam:role:write')")
    int countAdminCapableMembersExcluding(@Param("tenantId") String tenantId,
                                          @Param("excludeMembershipId") String excludeMembershipId);

    /** 某角色是否具备「租户管理能力」（降权校验：新角色集若含管理能力则不算降权，G3）。 */
    @Select("SELECT COUNT(*) FROM gateway_role_permission rp "
            + "JOIN gateway_permission p ON p.permission_id = rp.permission_id AND p.delete_flag = 0 "
            + "WHERE rp.role_id = #{roleId} AND rp.delete_flag = 0 "
            + "AND p.permission_code IN ('iam:member:write', 'iam:role:write')")
    int countAdminCapableByRole(@Param("roleId") String roleId);

    /** 某角色（租户内唯一）除指定成员外的 ACTIVE 持有者数（G3 方式 B：is_owner 角色是否还有其他人）。 */
    @Select("SELECT COUNT(DISTINCT m.membership_id) FROM gateway_membership m "
            + "JOIN gateway_membership_role mr ON mr.membership_id = m.membership_id AND mr.delete_flag = 0 "
            + "WHERE mr.role_id = #{roleId} AND m.membership_status = 'ACTIVE' AND m.delete_flag = 0 "
            + "AND m.membership_id != #{excludeMembershipId}")
    int countActiveMembersByRoleExcluding(@Param("roleId") String roleId,
                                          @Param("excludeMembershipId") String excludeMembershipId);
}

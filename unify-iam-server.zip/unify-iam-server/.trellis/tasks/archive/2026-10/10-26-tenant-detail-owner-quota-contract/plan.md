# Tenant detail, owner, and quota backend plan

Date: 2026-10-26

Status: Complete.

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, plan, session, and validation records under this repository's `.trellis/` directory.
- Do not inspect or modify a separate frontend project or the supplied `.pen` design file.
- Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- Hidden-path searches confirm that `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree. The applicable instructions are `CLAUDE.md` and `.claude/rules/security.md`; no undocumented Trellis confirmation gate can be inferred.

## Confirmed baseline

1. Management creation defaults `tenant_type` to `ORGANIZATION`, but currently accepts an explicit `PERSONAL` value. Personal tenants are authoritative only for self-registration and platform consumer SSO flows.
2. Existing `GET /api/v1/admin/tenants/{tenantId}` has only the base tenant fields. Existing member, application, and owner information is spread across `gateway_membership`, `gateway_user`, `gateway_membership_role`, `iam_tenant_application`, and `gateway_tenant.owner_user_id`.
3. `gateway_quota_dimension` and `gateway_tenant_quota` do not exist. The approved requirements model calls for template dimensions plus tenant overrides; design screenshots' numeric limits are examples, not an existing authoritative source.
4. Existing membership and application relations are authoritative for IAM-owned usage. Pending invitations are authoritative rows in `gateway_invitation`; no member row exists until acceptance.
5. Existing tenant status updates revoke member token versions on a transition away from `ACTIVE`, but the update map currently permits arbitrary status text.
6. Existing invitation handling stores only a token hash and returns a development token. The repository has no SMTP/transactional email dependency or configured invitation URL. It must not represent an email as delivered when no transport exists.

## Chosen contract

- Platform `POST /api/v1/admin/tenants` accepts an omitted or explicit `ORGANIZATION` type and rejects any other type. Self-service registration remains the sole personal-tenant path.
- `GET /api/v1/admin/tenants/{tenantId}/details` is a read aggregation for the drawer. It returns base tenant data, the resolved owner projection when available, enabled applications, true IAM usage/quota dimensions, and a paged member projection. It requires both tenant and member read authority plus the target-tenant scope guard.
- Quota dimensions are persisted in `gateway_quota_dimension`; tenant overrides are persisted in `gateway_tenant_quota`. The initial IAM dimensions are `members` and `apps`, both with no effective numeric default limit. This represents "unlimited until configured" rather than inventing design-sample limits.
- Member usage is `ACTIVE memberships + PENDING memberships + unexpired PENDING invitations`; app usage is active `iam_tenant_application` relations. The response exposes the breakdown, effective limit, remaining capacity when bounded, and over-limit state.
- `PUT /api/v1/admin/tenants/{tenantId}/quotas/{dimensionKey}` persists a non-negative tenant override after rejecting values below current reserved usage. Member addition and invitation creation enforce the effective members limit. Platform tenant creation validates default members/apps limits should an operator later configure them.
- `POST /api/v1/admin/tenants/{tenantId}/owner` supports `EXISTING_MEMBER` and `INVITE_BY_EMAIL`. A completed transfer updates `owner_user_id`, preserves the former owner's membership/roles, ensures the new owner holds current owner-template roles, bumps the promoted member's token version, and audits the transition. The non-destructive former-owner behavior is deliberate because the existing product decision does not authorize an implicit demotion or removal.
- Email transfer invitations use the existing hashed-token acceptance flow with an `OWNER_TRANSFER` purpose. A configured SMTP sender and a tokenized acceptance URL are mandatory before an invitation is created; missing configuration returns `503` and creates no invitation. This prevents an undeliverable invitation or leaked raw token from being mistaken for a sent email.
- Tenant status keeps the established `PUT /api/v1/admin/tenants/{tenantId}` route, now restricted to `ACTIVE` and `DISABLED` for the management toggle. Its existing token-version revocation behavior remains intact.

## Implementation checklist

- [x] Read actual project/security instructions and record the missing requested AGENTS/Trellis workflow files.
- [x] Trace tenant, owner, member, invitation, application, quota, authorization, audit, and status sources.
- [x] Add schema, seed, DTO, repository, and service contracts for true quota/usage data.
- [x] Add the aggregate drawer detail endpoint and enterprise-only management creation validation.
- [x] Add owner transfer and purpose-aware acceptance handling, including conditional SMTP delivery.
- [x] Enforce quota and safe tenant-state behavior in existing write paths.
- [x] Add focused integration/unit coverage, documentation, static checks, and Maven validation.

## Validation result

The sandboxed integration-test attempt could compile but could not access Docker. The same focused
command was rerun with the local Docker socket available; the disposable Testcontainers MySQL
database applied V12 and all assertions passed.

```text
mvn -pl iam-app -am test -Dtest='TenantDetailOwnerQuotaIntegrationTest,OwnerInvitationMailServiceTest' \
  -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 6 passed, 0 failures, 0 errors

mvn -pl iam-app -am test -Dtest='P3TenantInitIntegrationTest,P3AdminCrudIntegrationTest,AdminProtectionIntegrationTest,TenantDetailOwnerQuotaIntegrationTest' \
  -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full
# 33 passed, 0 failures, 0 errors
```

`git diff --check` produced no output. No branch/worktree operation, commit, merge, push,
checkout, or reset was performed.

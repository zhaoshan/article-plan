# IAM API 接口梳理（docs/user-manual/05）

> 定位：按**使用方/调用方**分类梳理 IAM 全部接口——① 业务系统对接（后端调用：服务间 / 用户 Bearer / 公开）、② IAM 前端（hub：登录/注册/我的身份/切换）、③ **前端管理台接口**（`/api/v1/admin/**`，给 `platform-iam-web` 的 `/admin` 管理页面用）。
> 契约：**全部 `/api/v1/**` JSON 接口统一返回信封 `{success, code, message, data}`**——成功 `data` 为业务体（数组或对象），失败真实状态码 + 信封（`message` 为文案）。唯一例外：`/api/v1/auth/oidc/**`（OIDC 重定向流程，见下）与 `/.well-known/jwks.json`（裸 JWK Set）。
> **TOKEN_STALE 即时吊销**（2026-11-09）：`/api/v1/admin/**` 请求比对 token `ver` 与成员当前
> `token_version`——角色/权限/成员变更后旧 token 首次请求返回 401 `IAM-AUTH-015`（成员已删同样）；
> 客户端按「401 → refresh → 重试」处理即追平。不回调 IAM 的业务系统仍靠 versions feed。
> **未验证账号禁止登录**（2026-11-05）：注册必经验证码；若账号 `email_verified=0`（如换绑邮箱后），登录返回 403 `IAM-USER-010`。
> **密码字段线上 base64（2026-10-29 起）**：`password` / `old_password` / `new_password` 一律 base64 编码传输
> （UTF-8 字节；严格解码，无兼容明文期）——对接方审计「不得明文传输」的形式要求；base64 是编码非加密，
> 机密性仍由 TLS 承担。涉及端点：`/api/v1/auth/token`、`/api/v1/auth/register`、
> `/api/v1/auth/reset-password`、`/api/v1/auth/change-password`、`/api/v1/admin/users`（建用户）、
> `/api/v1/admin/users/{id}/reset-password`。编码失败/解出空白按 400（登录入口统一 401 防枚举）。
> 版本基线：2026-10-29。

---

## 使用方与鉴权模型（先读）

**「前端」和「前端管理台」是同一个前端应用（`platform-iam-web`）的两块页面，不是两套系统**——它们调不同的后端路由族、用不同的鉴权门槛。

| 使用方 | 是什么 | 典型页面/调用 | 后端路由族 | 鉴权模型 |
|---|---|---|---|---|
| **业务系统后端** | parlant / ai-chat-insight / iMorph 等**其他业务系统的后端** | 登录转发、验签、后台任务状态校验 | `/api/v1/auth/**`（部分） | `Service` 服务令牌 / 透传用户 `Bearer` / `公开` |
| **IAM 前端（hub）** | `platform-iam-web` 的**身份入口区** | `/login`、`/register`、`/forgot-password`、`/admin/me`（我的身份）、租户切换 | `/api/v1/auth/**`、`/api/v1/memberships/**` | `公开` 或 `Bearer`（只要求登录态） |
| **IAM 前端管理台** | `platform-iam-web` 的 `/admin` **管理页面** | 用户/租户/成员/角色/权限/SSO 配置/审计 | `/api/v1/admin/**` | `Bearer` + `iam:*` 权限点 + 作用域（`TenantScopeGuard`，默认拒绝） |

**鉴权机制记号**：

| 记号 | 含义 |
|---|---|
| `公开` | 无需鉴权（登录/注册/找回/JWKS/SSO 发起等） |
| `Bearer` | 用户 JWT（`Authorization: Bearer <token>`）；只校验登录态 |
| `iam:*` | 管理面权限点（`@RequirePermission`）+ 作用域；未认证 401、缺权限 403（`/api/v1/admin/**` 全局拦截、默认拒绝） |
| `Service` | 服务间令牌 `X-IAM-Service-Token`（=`iam.versions.service-token`），无用户 token |

> 说明：IAM 没有独立的前端专用代理进程；「前端管理台接口」指专为前端管理台（`platform-iam-web` 的 `/admin` 页面）提供的后端接口（`/api/v1/admin/**`），与面向业务系统的外部契约端点（`/api/v1/auth/**`）相对。

### 统一返回信封（{success, code, message, data}）

**全部 `/api/v1/**` JSON 接口**（管理台、hub、业务系统端点）的成功与失败都套信封：成功 `data` 为业务体（数组或对象），失败真实状态码 + `data=null` + `message` 为文案。判定集中在 IAM `EnvelopePaths.inScope`（`ApiEnvelopeAdvice` 套成功、`GlobalExceptionHandler` 套失败）。

前端 `client.ts` 按响应是否带 `success` 判别（无需路径白名单）：成功透出 `data`，失败抛 `ApiError`（`message`/`detail` 二选一）。业务系统消费端（parlant-agent `app/routers/auth.py` 登录/刷新、`app/authz/versions.py` 版本 feed）已同步按 `data` 解包。

**例外（保持非信封形态）**：

| 端点 | 形态 |
|---|---|
| `/api/v1/auth/oidc/**`（authorize/callback） | 标准 OIDC 重定向流程：成功 302（callback 带 `?access_token=` 回跳），错误真实状态码 + `{"detail":...}` |
| `/.well-known/jwks.json` | 裸 JWK Set（标准 JOSE 客户端直接消费，不可套） |

---

## 1. 业务系统对接（后端调用）

> 供 parlant、ai-chat-insight、iMorph 等业务系统后端调用。业务系统可经自己的**业务后端转发**（同源）或直连 IAM。

### 1.1 服务间（`X-IAM-Service-Token`，无用户 token）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/v1/auth/versions?app_code=&since=&membership_id=` | 权限版本 feed：增量游标 / 全量快照 / 点查；tombstone=`version:-1`（方案 c 即时吊销） |
| POST | `/api/v1/auth/status-check` | 后台任务执行前校验：按任务提交时存的 `{tenant_id,membership_id}` 返回 `valid`（租户/成员停用即 false，不再执行任务） |
| POST | `/api/v1/auth/user-exists` | 账号存在性判定（G8 登录/注册两段式，用户名优先、邮箱兜底）：body `{email}`（兼容用户名） → `data:{exists, auth_mode}`——有 LOCAL 身份→`password`、仅 OIDC→`sso`（两者都有→`password`，依据 identity 而非 registration_source）；防枚举：仅服务间可调、响应只回 exists+auth_mode、调用方限流 |

### 1.2 用户 Bearer（带用户 token，业务系统透传）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/v1/auth/me` | 当前用户上下文（claims 快照）+ 当前账号的 My identity 资料 |
| GET | `/api/v1/auth/session-status` | 当前上下文**权威状态**（读库：tenant_status/membership_status/valid） |
| GET | `/api/v1/auth/tenant-status?tenant_id=` | 查询某租户状态（限调用者自己成员关系，防枚举） |
| GET | `/api/v1/auth/app-access?app_code=` | 登录后能力检查（可选租户 / 跳 IAM 控制台 / 阻断） |
| POST | `/api/v1/auth/switch-tenant` | 切换租户 → 重签 access+refresh |
| GET | `/api/v1/auth/memberships` | 当前用户可切换成员列表（G9 增强：`tenant_type`/`roles`/`is_owner`/`is_current`/`last_opened_at`/`tenant_created_at`/`joined_at`，供租户切换菜单的类型/角色徽标与 Last opened/Created time 排序） |
| POST | `/api/v1/auth/refresh` | 静默刷新（refresh 轮换：旧作废+新返回） |
| POST | `/api/v1/auth/logout` | 登出（撤销 refresh token） |

### 1.3 公开（无需鉴权）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/.well-known/jwks.json` | 公钥（RS256，kid=iam-key-1）——业务系统验签用 |
| POST | `/api/v1/auth/token` | 本地密码登录（业务后端转发，`username` 兼容用户名或邮箱）→ `{access_token, refresh_token, ...}` |
| GET | `/api/v1/auth/oidc/authorize?tenant_id=` | 企业 SSO 发起（302 跳 IdP） |
| GET | `/api/v1/auth/oidc/callback` | SSO 回调（302 回前端，携带 access/refresh token） |
| POST | `/api/v1/auth/dev-token` | ⚠️ dev 免密发 token（**生产必须 `IAM_DEVTOKEN_ENABLED=false`**） |

> 业务系统验签链路：`/.well-known/jwks.json` 取公钥 → RS256 验签 + `aud` 含本应用 app_code + `iss` 逐字 + `exp`；权限新鲜度用 §1.1 versions feed（`ver` 比对）。

### 1.4 登录标识兼容合同（2026-10-29）

#### 1. 范围

账号存在性分流与本地密码登录必须使用同一账号解析规则，兼容 `platform_admin` 等历史用户名与邮箱登录。

#### 2. 签名

- `POST /api/v1/auth/user-exists`：保留 `{ "email": "<用户名或邮箱>" }` 与服务间鉴权。
- `POST /api/v1/auth/token`：保留 `{ "username": "<用户名或邮箱>", "password": "<原始密码>" }`。

#### 3. 合同

两条路径共用 `UserRepository.findByLoginIdentifier`：去除标识首尾空白，先按 `username` 查，未命中再按 `primary_email` 查。用户名不主动转小写；邮箱使用 `Locale.ROOT` 转小写，匹配仍遵循数据库排序规则。密码不 trim 或转换。登录响应 `user.user_name` 始终返回账号存储的用户名。

用户名命中后，不因账号停用、本地身份缺失或密码错误而尝试另一个邮箱账号。存在性响应仍只有 `exists` 与 `auth_mode`，不额外暴露用户资料。

#### 4. 错误矩阵

| 条件 | 分流 | 密码登录 |
|---|---|---|
| `platform_admin` / `platform_admin@unify.local` | 命中同一账号，`password` | 正确密码登录同一账号 |
| 未知标识 | `exists:false` | 401「用户名或密码错误」 |
| 命中仅 OIDC 身份 | `exists:true, auth_mode:sso` | 401「用户名或密码错误」 |
| 命中账号停用或密码错误 | 不改变账号查找结果 | 401「用户名或密码错误」，不再尝试其他账号 |
| 用户名与另一账号邮箱相同 | 用户名对应账号优先 | 只验证用户名对应账号 |
| 空白标识 | 400 | 400 |

#### 5. 示例场景

正常：历史用户名能进入密码页，邮箱也能登录该账号。基线：现有字段名与服务令牌合同保持兼容。错误：把用户名作为主邮箱查找，或邮箱登录后把邮箱当作 `user_name` 返回。

#### 6. 回归测试

`UserExistsIntegrationTest` 覆盖历史用户名、空白处理、混合大小写邮箱、同账号登录和规范用户名、冲突优先级及错误密码；`IdentityVerificationServiceTest` 保留本地身份、账号状态与通用失败文案的校验。

#### 7. 实现对照

错误：分流使用 `findByPrimaryEmail`，登录使用 `findByUsername`。正确：两者都使用 `findByLoginIdentifier` 选定同一账号，然后分别计算登录模式或验证本地凭据。

## 2. IAM 前端接口（hub：platform-iam-web，浏览器同源）

> hub 前端（登录/注册/我的身份/租户切换）直接调用；业务系统前端不经 IAM（跳 hub 登录，见 `03-业务系统接入指南`）。

| 方法 | 路径 | 鉴权 | 说明 |
|---|---|---|---|
| GET | `/api/v1/auth/sso/tenants?app_code=` | 公开 | 登录页「企业组织」下拉（`?app=` 只列启用该应用的租户） |
| GET | `/api/v1/auth/return-origins` | 公开 | 回跳 `return_to` 白名单（server 下发，防 open redirect） |
| POST | `/api/v1/auth/register` | 公开 | 注册（建 LOCAL 身份 + 个人租户 owner）；**`verification_code` 必填**（先调下方验证码接口，事务内消费，10 分钟有效） |
| POST | `/api/v1/auth/email-verification-codes` | 公开 | 发注册验证码（60s 冷却 + 24h 10 次上限；SMTP 未配置时码值走服务日志；`IAM-AUTH-011` 频繁） |
| POST | `/api/v1/auth/email-verification-codes/verify` | 公开 | 校码：`IAM-AUTH-012` 错误 / `IAM-AUTH-013` 过期；5 次错误作废 |
| POST | `/api/v1/auth/forgot-password` | 公开 | 找回密码 |
| POST | `/api/v1/auth/reset-password` | 公开 | 重置密码 |
| POST | `/api/v1/auth/change-password` | Bearer | 登录态改密（G2 首登强制改密）：`{old_password,new_password}` → 校验旧密码、清零 `must_change_password`、不吊销当前会话（与「忘记密码重置吊销全部 refresh」区分） |
| POST | `/api/v1/auth/token` | 公开 | 本地登录 |
| POST | `/api/v1/auth/refresh` | Bearer | 401 静默刷新（client.ts trySilentRefresh） |
| GET | `/api/v1/auth/me` | Bearer | 我的身份（当前 claims 上下文 + 当前账号资料） |
| GET | `/api/v1/auth/memberships` | Bearer | 多租户列表（G9 增强字段见 §1.2） |
| POST | `/api/v1/auth/switch-tenant` | Bearer | 切换租户 |
| GET | `/api/v1/auth/app-access?app_code=` | Bearer | 登录后选租户/跳控制台/阻断分流 |
| GET | `/api/v1/auth/session-status` | Bearer | 当前上下文权威状态 |
| GET | `/api/v1/auth/tenant-status?tenant_id=` | Bearer | 租户状态（限自己成员） |
| GET | `/api/v1/auth/oidc/authorize?tenant_id=` | 公开 | 企业 SSO 发起 |
| GET | `/api/v1/auth/oidc/callback` | 公开 | SSO 回调收 token |
| POST | `/api/v1/memberships/join-request` | Bearer | 发起加入申请 |
| POST | `/api/v1/auth/invitations/{token}/accept` | Bearer | 接受邀请（**必须登录**+邀请邮箱==当前账号，不符 403；无成员则建成员+按邀请角色绑定，幂等）；响应 `data:{status, redirect_url}`——redirect_url 由后端解析（invitation.app_code → iam_application.homepage_url → yml iam.app-homepages.<code> → 邀请链接基址兜底），前端只认它跳转 |

### 2.1 My identity：`GET /api/v1/auth/me`

请求只接受当前会话的 `Authorization: Bearer <access token>`，成功体保持统一信封；实际内容是 `data` 下的平铺对象，不额外嵌套 profile：

| JSON 字段 | 类型/格式 | 数据来源 | 缺失语义 |
|---|---|---|---|
| `userId` | string | 已验签 JWT `sub` | JWT context 字段 |
| `userName` | string | `gateway_user.username` | 用户行不存在时省略 |
| `email` | string | `gateway_user.primary_email` | 可为空；为空时按全局 `non_null` 配置省略 |
| `registrationSource` | string | `gateway_user.registration_source` | 正常账号必有；用户行不存在时省略 |
| `tenantId` / `membershipId` / `roles` / `permissions` / `attrs` | 与现有 `AuthorizationContext` 相同 | 已验签 JWT claims | 当前单租户 token 上下文 |

账号资料查询只能以已验签 JWT 的 `sub` 为键；接口没有目标用户、租户或成员关系参数，因此不会用 My identity 查询跨租户账号资料。

### 2.2 当前用户所属租户：`GET /api/v1/auth/memberships`

仅需 `Authorization: Bearer <access token>`，不要求 `iam:tenant:read`。标准信封的
`data` 为 `{memberships:[...], count}`；每条成员关系包含字段
`membership_id`、`tenant_id`、`tenant_name`、`tenant_code`、`membership_status`、`is_default`。
名称与编码同源于该成员关系关联的 `gateway_tenant` 真实数据，`tenant_code` 为兼容新增字段。

查询仅按已验签 token 的 `userId` 返回本人的未逻辑删除成员关系，并排除不存在、已逻辑删除及非 ACTIVE 的租户；
成员关系自身的 `membership_status` 保留原值，前端仍须按状态决定能否切换。`is_default` 保留当前分支的整数类型（0/1），并保留 `is_current`、`tenant_type`、`roles`、`is_owner` 与时间字段；
当前租户应按会话 `tenantId` 匹配 `tenant_id`，不以默认标记代替当前上下文。
前端可直接用匹配条目的 `tenant_name` / `tenant_code` 展示租户名称和次行编码，无需调用管理端租户详情补齐。
本接口没有目标用户/任意租户查询参数；无/非法 Bearer 返回 401；管理端租户读取仍要求 `iam:tenant:read`。

## 3. 前端管理台接口（`/api/v1/admin/**`）

> 供 `platform-iam-web` 的前端管理台各页面（用户/租户/成员/角色/权限/应用/SSO配置/审计）调用；鉴权 = Bearer + `iam:*` 权限点（`@RequirePermission`，未授权 403）。

### 3.1 用户（iam:user:*，仅平台）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/users` |
| GET/PUT/DELETE | `/api/v1/admin/users/{userId}` |
| POST | `/api/v1/admin/users/{userId}/reset-password` |

#### 管理员重置本地密码

用户编辑表单的重置密码输入框在非空时调用：

```http
POST /api/v1/admin/users/{userId}/reset-password
Authorization: Bearer <access token with iam:user:write>
Content-Type: application/json

{"password":"NewPassword123!"}
```

成功为 `200` 标准信封，`data` 为 `{"user_id":"...","status":"PASSWORD_RESET"}`；密码、哈希和令牌均不会出现在响应中。该操作仅适用于具有 ACTIVE `LOCAL/password` 身份的用户，不会为 OIDC-only 用户创建本地凭据。

`password` 必填且不能全为空白，保留原样（不 trim），最大为 72 个 UTF-8 字节以避免 BCrypt 截断；当前项目尚无额外的统一复杂度/强度规则。请求缺少或无效 Bearer 返回 `401`，缺少 `iam:user:write` 返回 `403`，空白/超限密码或 OIDC-only 用户返回 `400`，用户不存在返回 `404`；失败体同样使用标准错误信封。请求中的 `new_password` 不属于此管理端点的契约，不能作为别名使用。

该输入框用于管理员设置替换密码，不包含一次性凭据或首次登录强制改密语义；当前账号模型没有该状态字段。

成功后服务只持久化 BCrypt 哈希，撤销目标用户的全部 refresh token 和仍有效的密码重置令牌，并将其所有 ACTIVE 成员关系的令牌版本递增（`PASSWORD_RESET`，供 `/api/v1/auth/versions` 下游同步）。已签发 access token 不会在 IAM 签名校验层被同步拉黑：消费端执行下一次版本-feed 刷新后会拒绝旧版本；未执行该校验的消费端最多仍可使用到配置的 access-token TTL（默认 1800 秒）。管理面不会记录或返回明文密码。成功操作会写入 `ADMIN_RESET_USER_PASSWORD` 审计事件，审计内容不含密码、哈希或令牌。

### 3.2 租户（iam:tenant:*，平台；更新/删除限作用域）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/tenants`（POST 支持 `owner_email`——G2 A-02「Create and send invite」：任意 Owner 邮箱，不存在则 JIT 建号+初始密码并发送 Owner 邀请邮件；与 `owner_user_id` 并存） |
| GET | `/api/v1/admin/tenants/{tenantId}/usage`（G1 Usage 视图：全局 iam 维度+已启用应用维度，行含 limit/used/pending/remaining；**iam:apps:read**，2026-11-02 自 iam:tenant:read 切换——apps 系权限可租户授权，租户 Owner/Admin 可查本租户配额；写端点不在此列） |
| PUT | `/api/v1/admin/tenants/{tenantId}/usage/{dimensionId}`（G1 租户调额 `{limit_value}`；null=清除覆盖回落模板默认；**iam:tenant:write**——写操作仅平台管理员，2026-11-02 曾试开放 iam:apps:write 后收回） |
| POST | `/api/v1/admin/tenants/{tenantId}/owner`（G3 更换 Owner；**双轨鉴权**：iam:tenant:write 或 该租户 is_owner 角色持有者）：body `{mode, membership_id?, email?}`——`EXISTING_MEMBER` 选现有成员 / `INVITE_EMAIL` 邮箱邀请（JIT 建号+Owner 邀请邮件）；单 Owner（每应用每租户至多 1 个 ACTIVE 持有者），swap 事务内先降后授：旧 Owner 同应用 is_owner→is_admin 降级、新 Owner 追加 is_owner，更新 tenant.owner_user_id + 审计 + bump |
| GET/PUT/DELETE | `/api/v1/admin/tenants/{tenantId}` |
| GET | `/api/v1/admin/tenants/{tenantId}/details`（详情抽屉聚合） |
| PUT/DELETE | `/api/v1/admin/tenants/{tenantId}/quotas/{dimensionKey}`（**iam:tenant:write**——写操作仅平台管理员；2026-11-02 与 /usage 调额端点同日曾试切换 iam:apps:write，随后按「读开放写收回」决策回退） |
| POST | `/api/v1/admin/tenants/{tenantId}/owner` |
| GET | `/api/v1/admin/tenants/{tenantId}/applications`（iam:role:read，角色配置用） |
| POST | `/api/v1/admin/tenants/{tenantId}/domains`（域名验证） |
| POST | `/api/v1/admin/domains/{domainId}/verify` |

`GET /api/v1/admin/tenants` 的每个 `tenants[]` 行包含 `applications` 数组；数组元素为
`{app_code, app_name, description?, app_status}`。`app_code` 与 `app_name` 是稳定的列表展示字段，
`description`（可为空）和 `app_status` 可供编辑弹框展示应用元数据。租户列表应直接使用该字段，
不要再为每个列表行请求 `/{tenantId}/applications`，以避免 N+1 HTTP 请求；后者保留给单租户上下文。

应用目录后来变为 `DISABLED` 时，既有 `iam_tenant_application` 关系仍会携带真实名称、描述和状态
返回，不能被静默过滤成空数组。若历史关系已没有对应目录记录，服务仍返回该 `app_code`，并以它作为
`app_name` 回退标签，便于管理台显示和排查数据问题。

#### 创建企业租户与状态开关

租户表单使用 `POST /api/v1/admin/tenants` 的 Owner 邮箱开通契约（平台管理员且拥有
`iam:tenant:write`）：

```json
{"tenant_name":"Example Enterprise","owner_email":"owner@example.com"}
```

当 `tenant_code` 与 `app_codes` 都省略且携带 `owner_email` 时，进入该两字段开通分支，拒绝其他旧字段。
兼容当前分支：显式提供 `tenant_code`、`app_codes` 时，仍走原有即时开通流程；`owner_email` 可触发 JIT 建号、初始密码和 Owner 邀请邮件。
以下两字段分支由服务端生成
不可由调用方控制的 `org-<uuid>` 内部 code，固定写入 `tenant_type="ORGANIZATION"`，并依据
`iam.enterprise-tenant-provisioning.default-app-codes` 开通平台默认业务应用（默认 `imorph`）。该策略拒绝
`iam` 或任何 PLATFORM 作用域模板，避免把 `PlatformAdmin` 授予企业 Owner。

邮件投递成功后，响应为下列真实的可恢复状态，而不是宣称 Owner 已完成转移：

```json
{
  "tenant_id":"...",
  "tenant_type":"ORGANIZATION",
  "tenant_status":"PENDING",
  "owner_email":"owner@example.com",
  "owner_assigned":false,
  "invitation_id":"...",
  "invitation_status":"PENDING",
  "delivery_status":"DELIVERED",
  "expires_at":"2026-10-31T12:00:00"
}
```

受邀邮箱对应的已登录账号调用 `POST /api/v1/auth/invitations/{token}/accept` 后，服务才创建成员（如需要）、
授予默认应用的 Owner 模板角色、写入 `owner_user_id` 并将租户激活为 `ACTIVE`。缺少 SMTP 配置或实际投递失败
返回 `503`；创建、应用关系和邀请处于同一事务，失败时不会留下无 Owner 的 PENDING 租户，也不会给前端返回成功。
若邀请过期，平台管理员可继续通过下述 Owner 邮箱动作重新发送；该动作会保留 `TENANT_OWNER_SETUP` 语义并在
接受后完成激活。

兼容期内，旧内部管理调用仍可使用显式 `tenant_code`、`app_codes` 和可选
`owner_user_id` 创建企业租户；该兼容路径不是租户表单契约。个人租户仍只由公开注册和平台 consumer SSO 的专用
流程创建，管理台不能借该接口创建个人空间。

详情抽屉的启用/禁用继续调用既有 `PUT /api/v1/admin/tenants/{tenantId}`：

```json
{"tenant_status":"DISABLED"}
```

仅 `ACTIVE` 与 `DISABLED` 是管理台允许的值；其他状态返回 `400`。从 `ACTIVE` 切到 `DISABLED` 会递增该租户
所有有效成员的令牌版本，现有会话和下游版本校验随之失效；切回 `ACTIVE` 后成员可按其原有状态重新登录。

#### 详情抽屉聚合

`GET /api/v1/admin/tenants/{tenantId}/details` 需要
`iam:tenant:read` 与 `iam:member:read`，并执行目标租户作用域校验。它一次返回：

```json
{
  "tenant": {"tenant_id":"...","tenant_name":"...","tenant_type":"ORGANIZATION","tenant_status":"ACTIVE"},
  "owner_assigned": true,
  "owner": {"membership_id":"...","user_id":"...","username":"...","email":"...","roles":[...]},
  "usage": {"dimensions":[...]},
  "applications": [{"app_code":"...","app_name":"...","app_status":"ACTIVE"}],
  "members": {"items":[...],"total":1,"limit":1000,"truncated":false}
}
```

`owner` 仅在 `owner_user_id` 可解析为未删除用户和成员关系时返回；`owner_assigned` 和
`tenant.owner_user_id` 保留真实主表状态，管理台不能以虚构用户替代缺失数据。成员项目包含真实
`membership_status`、用户资料（若目录记录存在）、`is_owner`、`is_default`、`join_source` 与当前角色摘要。

成员不分页，数据库按 `gateway_membership.id ASC` 一次查询 `LIMIT 1000`，不使用 OFFSET。
`member_page/member_size` 已移除；旧客户端发送它们会被忽略，不影响返回集合。
`members.items` 保留为数组；`total` 是该租户未逻辑删除成员关系的真实总数（包含所有成员状态），
`limit` 固定 `1000`，`truncated` 表示真实总数大于实际返回条数。`total>1000` 时只返回最早 1000 条，
不能宣称已返回全部，也没有下一页接口。成员块不再返回 `page/size`。

单项 shape（可空资料按全局 `non_null` 规则省略）：

```json
{
  "membership_id":"...",
  "user_id":"...",
  "user_available":true,
  "username":"actual-login",
  "full_name":"实际全名",
  "display_name":"实际昵称",
  "email":"actual@example.com",
  "membership_status":"ACTIVE",
  "is_default":false,
  "is_owner":false,
  "join_source":"ADMIN",
  "roles":[{"role_id":"...","role_code":"TenantAdmin","role_name":"Tenant Admin"}]
}
```

成员集合以 `gateway_membership.tenant_id` 为准，不能用 `gateway_user.tenant_id/default_tenant_id`
或全局用户列表代替。身份字段按 `membership.user_id -> gateway_user.user_id` 批量关联；不存在或已逻辑删除
的用户保留成员关系及真实状态、角色，返回 `user_available=false`，省略 username/full_name/display_name/email。
未删除用户的可选名称/邮箱本来为空时仍为 `user_available=true`，不生成替代资料。
角色按 `membership_id -> gateway_membership_role -> gateway_role` 批量关联，过滤逻辑删除绑定/角色和缺失角色，
没有绑定则为 `[]`。CHAR(32) 业务键读取归一化后再关联。
`is_owner` 仅比较租户主表的 `owner_user_id`；Owner 超出返回上限时单独解析，绝不取第一个成员代替。
`owner_assigned=true` 仅表示已记录 Owner ID；若用户或成员不可用，`owner` 仍省略。

租户列表 `GET /api/v1/admin/tenants?limit=1000` 也不分页：保留 `{tenants:[...],count:N}`，
默认 limit=20，上限1000；count 是本次返回数量，不是全库 total，没有 page/size/下一页语义。
列表可选作用域参数必须使用 snake_case：`scope_type=PLATFORM&scope_id=PLATFORM` 表示平台全局视图，
`scope_type=TENANT&scope_id=<tenant_id>` 只返回指定租户。两个参数必须同时提供，作用域值必须使用大写；
缺参、错误大小写或不匹配的作用域组合返回 400。未传作用域参数保持平台列表兼容行为。

Usage 仅返回 IAM 可以权威计算的维度。`members.used_count` 为 ACTIVE 成员、PENDING 成员和未过期 PENDING
邀请的总和，`active_count`/`pending_count` 给出真实拆分；`apps.used_count` 为
`iam_tenant_application` 的现有关系数。`limited=false` 表示尚未配置实际额度；在全局 `non_null` 序列化下，
此时 `limit_value` 和 `remaining` 省略，不能把页面样例的 `10` 或 `20` 当作后端值。

`PUT /api/v1/admin/tenants/{tenantId}/quotas/members` 或 `/apps` 接受
`{"limit_value":10}`。仅允许非负数，且不能低于当前真实已使用数量；成功返回更新后的单个 Usage 维度。
`DELETE` 同一路径清除租户覆盖并回退维度默认值。成员直加和新成员邀请都会在有限 Members 配额达到上限时返回
`400`；并发写操作锁定目标租户行，避免超卖席位。

#### 更换 Owner

`POST /api/v1/admin/tenants/{tenantId}/owner` 需要 `iam:tenant:write`、`iam:member:write` 和目标租户作用域。

```json
{"mode":"EXISTING_MEMBER","membership_id":"..."}
```

会重新校验真实未删除且 ACTIVE 的用户、ACTIVE 目标成员及非当前 Owner，再立即把目标设为 `owner_user_id`，补齐当前启用应用的 Owner 模板角色，递增该成员令牌版本，并写审计。
旧 Owner 的成员关系和既有角色会保留，不会在没有明确产品策略时被隐式降权或移除。

```json
{"mode":"INVITE_BY_EMAIL","email":"new-owner@example.com"}
```

只在同时配置 `iam.owner-invitation.delivery-enabled=true`、Spring Mail、发件人和含 `{token}` 的
`iam.owner-invitation.accept-url-template` 后可执行。配置缺失或投递器不可用时返回 `503`，且不会创建待接受邀请，
不会返回或审计明文 token。成功后返回 `{tenant_id,status:"OWNER_INVITATION_SENT",invitation_id,
invitation_status:"PENDING",delivery_status:"DELIVERED",expires_at}`；收件人以匹配邮箱的已登录账号调用
`POST /api/v1/auth/invitations/{token}/accept` 后，服务才创建成员（如需要）并完成 Owner 转移。SMTP 调用与邀请
写入处于同一事务；实际投递异常同样回滚邀请。对于上述 PENDING 企业租户，此动作会创建或重发首个 Owner 邀请，
接受后写 Owner 并激活租户，而不会把前端本地输入当作已完成的 Owner 变更。

### 3.3 成员（iam:member:*，租户）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/members` |
| GET/PUT | `/api/v1/admin/members/{membershipId}/roles` |
| POST | `/api/v1/admin/members/{membershipId}/suspend`（停用，G2） |
| POST | `/api/v1/admin/members/{membershipId}/restore`（恢复） |
| DELETE | `/api/v1/admin/members/{membershipId}`（移除） |

#### 成员作用域、搜索与 New Owner 候选（2026-11-02）

复用 `GET /api/v1/admin/members`，不新增用户目录或候选 endpoint。需要 Bearer、
`iam:member:read` 和目标租户作用域；不需要 `iam:user:read`。仅持租户级权限的调用者不能查询其他租户，
平台管理员可选目标租户或 PLATFORM 全局范围。`scope_type` 与 `scope_id` 必须成对提供，值区分大小写；PLATFORM 必须配 `scope_id=PLATFORM`。缺参、非法组合或出现旧 `tenant_id`（含混用）均为 `400`，不再提供兼容映射。TENANT 下有权限但目标不存在/已删除仍为 `404`。

| query | 类型/默认 | 语义 |
|---|---|---|
| `scope_type` | string，必填 | `PLATFORM` 查询跨租户成员，`TENANT` 查询单租户 |
| `scope_id` | string，必填 | PLATFORM 时必须为 `PLATFORM`；TENANT 时为真实目标租户 ID，去首尾空白 |
| `membership_status` | string，可选 | 逗号分隔 `ACTIVE,PENDING,SUSPENDED` 多值，如 `ACTIVE,PENDING`；精确大写，先过滤再 count/limit；不支持 `status` 别名 |
| `keyword` | string，可选 | 去首尾空白；空串不筛选；在真实 `display_name/full_name/username/primary_email` 任一字段中做包含匹配，大小写按数据库排序规则；`%`、`_`、`!` 作为字面字符，不支持通配符或按 ID 搜索 |
| `owner_candidates` | boolean，默认 false | true 时仅返回可转移 Owner 的目标成员 |
| `limit` | integer，默认1000 | 1..1000，越界或非整数 `400`；不是 page size |

```http
GET /api/v1/admin/members?scope_type=TENANT&scope_id=<tenantId>&keyword=<encodedText>&owner_candidates=true&limit=1000
GET /api/v1/admin/members?scope_type=PLATFORM&scope_id=PLATFORM&membership_status=ACTIVE,PENDING
```

成功仍套 `{success,code,message,data}`，data 示例：

```json
{
  "members": [{
    "membership_id":"member-business-id", "tenant_id":"tenant-business-id", "user_id":"user-business-id",
    "user_available":true, "username":"real-login", "full_name":"真实全名", "display_name":"真实昵称",
    "email":"member@example.com", "user_status":"ACTIVE", "owner_eligible":true,
    "membership_status":"ACTIVE", "is_default":"0", "is_owner":false, "join_source":"ADMIN",
    "roles":[{"role_id":"role-id","role_code":"Member","role_name":"成员"}]
  }],
  "count":1, "tenant_type":"ORGANIZATION", "total":1, "limit":1000, "truncated":false
}
```

每行同时返回真实 `tenant_id`、`tenant_name`、`tenant_type`；行操作必须使用该行所属租户。PLATFORM 聚合不返回顶层单租户 `tenant_type/tenant_name`，同一用户在不同租户的成员关系各占一行。TENANT 仍返回顶层 `tenant_type`，并附 `tenant_name`。

成员邮箱字段位于 `data.members[].email`，值来自关联真实用户的 `gateway_user.primary_email`，
与租户详情共用批量资料投影，不逐成员查询。邮箱是可选字段：用户存在但主邮箱为数据库 `NULL` 时，
按全局 `non_null` 序列化规则省略 `email`（不是空字符串或显式 `null`），`user_available` 仍为 `true`；
用户不存在或已逻辑删除时也省略邮箱，且 `user_available=false`。不会用用户名或 ID 生成邮箱。

`count` 是本次返回条数；`total` 是应用 keyword/候选条件后、截断前的真实关系数；
`truncated=(total>count)`。先在授权范围中完成 keyword、membership_status 和候选过滤，再按 `gateway_membership.id ASC` 稳定排序、限制条数，
无 OFFSET、无分页参数/下一页。空集合为 `members:[],count:0,total:0,limit:1000,truncated:false`。

成员来源始终是所属租户未删除的未删除 `gateway_membership`，不是用户默认租户或全局用户目录。
`owner_candidates=false` 且无 keyword 时保留所有状态的未删除成员关系，包括缺失/已删除用户；
这些关系 `user_available=false`、`owner_eligible=false`，username/full_name/display_name/email/user_status
全部省略，**不再用 user_id 冒充 username**。非空 keyword 只匹配可用真实资料，因此不会命中 unavailable 用户。
用户存在但状态非 ACTIVE 时仍可展示真实资料（`user_available=true`），但不是 Owner 候选。

`owner_candidates=true` 同时要求：关系未删除且 `membership_status=ACTIVE`、关联用户真实存在且未逻辑删除、
`user_status=ACTIVE`、目标用户不是 `gateway_tenant.owner_user_id`。PLATFORM 范围按每条成员所属租户的 Owner 分别判断。未设置 Owner 时不排除任意首成员。
用户删除或停用后，即使关系仍 ACTIVE 也不能入选；返回 `membership_id` 是提交值，不能提交 user_id。

列表和 `GET /api/v1/admin/tenants/{tenantId}/details` 的 `data.members.items[]` 共用同一资料/角色投影，
详情额外新增相同的 `user_status`（可省略）、`owner_eligible`（boolean）。详情的 `is_default` 仍为 boolean，
列表为兼容旧契约仍为字符串 `"0"/"1"`，列表另含 `tenant_id/tenant_name/tenant_type`；其他同名字段一致。
展示标签建议按非空 `display_name → full_name → username → email` 回退；unavailable 显示“用户不可用”并可附 ID，
ID 不应被显示成姓名。Owner 标识仅看 `is_owner`，不从角色或首成员猜测。

New Owner 可以在详情 `truncated=false` 时本地过滤 `owner_eligible===true`；有截断或需远程模糊搜索时使用
上述候选查询，避免先截断再筛选漏掉第1001条之后的有效成员。不应把详情所有关系直接当作可选项。

确认后仍调用 `POST /api/v1/admin/tenants/{tenantId}/owner`，JSON
`{"mode":"EXISTING_MEMBER","membership_id":"<candidate.membership_id>"}`；
需要 `iam:tenant:write`、`iam:member:write` 和目标租户作用域。提交端重新验证租户归属、ACTIVE 成员、
真实未删除且 ACTIVE 用户及非当前 Owner，不相信客户端候选缓存；无效目标 `400`，不存在成员 `404`。
不合法请求不会变更 Owner、授予角色、递增令牌版本或写入成功审计。

### 3.4 角色与权限（iam:role:*）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/roles` |
| PUT | `/api/v1/admin/roles/{roleId}`（更新角色基本信息） |
| GET/PUT | `/api/v1/admin/roles/{roleId}/permissions`（TENANT 角色受 `tenant_grantable` 约束） |
| DELETE | `/api/v1/admin/roles/{roleId}` |
| GET | `/api/v1/admin/permissions`（权限点目录，含 app_code/tenant_grantable/category） |

`GET /api/v1/admin/roles?scope_type=PLATFORM` 返回所有未逻辑删除角色（包括各租户角色和停用角色），
必须通过 `iam:role:read` 和平台管理员作用域校验；`scope_id=PLATFORM` 可继续传入，但不限制平台查询。
非 `PLATFORM` 请求只返回 `scope_id` 指定租户的角色（含停用、排除软删除），租户管理员仅可查本租户，
平台管理员可指定其他租户。列表按 id 升序，无默认分页，`count` 是本次返回数量。
运行时授权等调用的 `RoleRepository.listByScope` 仍只取 ACTIVE 角色。

`GET /api/v1/admin/roles` 的每个角色项包含 `role_id`、`role_code`、`role_name`、
`scope_type`、`scope_id`、`role_status`、`is_builtin`（是否内建：模板灌入/预置角色，禁删）、
`is_owner`（是否 Owner 角色：角色 code 命中该租户已启用应用的 is_owner 模板标记，单 Owner 语义的
角色切换入口据此展示；PLATFORM 作用域恒为 `false`），以及有值时的 `role_description`。
全局 `non_null` 序列化会省略空描述字段，管理台应将缺失字段视为没有描述。

每个角色项还包含 `permissionCounts`（JSON 数字，无权限为 `0`），供 Permissions 列直接展示。
统计口径与 `GET /api/v1/admin/roles/{roleId}/permissions` 的 `permission_ids` 一致：
统计当前未逻辑删除的角色—权限直接绑定，不额外按权限状态或应用筛选。后端对本次返回的角色一次批量聚合，避免列表 N+1 查询。

#### Role list filters and generated role codes

The authorization tuple `scope_type` / `scope_id` keeps its existing behavior.
Optional independent filters are:

| Query parameter | Contract |
| --- | --- |
| `filter_scope_type` | Comma-separated uppercase `PLATFORM,TENANT`; OR within the list; trim/deduplicate; empty or unknown entries return 400 |
| `filter_scope_id` | Exact tenant ID (the role's `scope_id`); trim; blank means no filter |
| `keyword` | Trimmed literal substring in `role_name` OR `role_description`; blank means no search |

Filters combine with AND and can only narrow the authorized rows. `%` and `_`
in keyword are literal characters. Example:

```http
GET /api/v1/admin/roles?scope_type=PLATFORM&scope_id=PLATFORM&filter_scope_type=TENANT&filter_scope_id=tenant-org-a&keyword=Support
```

The response preserves `{roles,count}`, ordering and existing non-pagination
behavior. Each TENANT role includes `tenant_name` resolved in a batch by scope ID.
Missing/deleted tenants and PLATFORM roles have no tenant name; an unavailable
`tenant_name` may be omitted by the existing NON_NULL serialization policy.

Creation no longer requires a manually entered role code:

```http
POST /api/v1/admin/roles
Content-Type: application/json

{"scope_type":"TENANT","scope_id":"tenant-org-a","role_name":"Support","role_description":"Handles tickets"}
```

Omitted, null or blank `role_code` generates `role_<32-hex UUID>` on the backend.
Existing clients may still supply a nonblank code, which is trimmed and retained.
The response remains `data: {"role_id":"..."}`; the list exposes the saved code.
Creation audit records that saved code. Updates still cannot change role codes.

#### 更新角色基本信息

角色详情编辑页保存名称/描述时调用：

```http
PUT /api/v1/admin/roles/{roleId}
Authorization: Bearer <access token with iam:role:write>
Content-Type: application/json

{"role_name":"Support operator","role_description":"Handles customer support workflows"}
```

成功为 `200` 标准信封，`data` 为 `{"role_id":"..."}`。`role_name` 必填、非空白、最多 128 个字符，服务会
trim 后持久化；`role_description` 可为空、最多 512 个字符。该接口是可编辑基本信息的 PUT 表达：省略或传
`null` 的 `role_description` 会清空已有描述，非空字符串按现有创建语义原样保存。

`role_code` 不是可编辑字段：它在作用域内唯一、会进入 JWT 的 `roles`，并参与应用模板和 Owner 角色匹配。
因此管理台应只读展示它；向此接口传入非空 `role_code` 会得到 `400`（`role_code 不支持更新`），不会被静默忽略。
`scope_type`、`scope_id`、`is_builtin` 与 `role_status` 同样不能通过此接口修改。名称/描述不是令牌声明，成功更新
不会递增成员 token version；权限变更仍必须使用既有的 `PUT /roles/{roleId}/permissions`，并保持该接口已有的
租户权限隔离与持有者 token-version 递增语义。两次保存是独立请求，不是一个组合事务。

该写操作需要有效 Bearer 和 `iam:role:write`，随后执行现有角色作用域校验：租户管理员只能更新当前租户角色，
平台角色仅平台管理员可更新。无令牌为 `401`，权限/作用域不足为 `403`，角色不存在为 `404`，字段不合法或尝试
修改编码为 `400`；失败同样使用标准错误信封。成功更新会记录 `ADMIN_UPDATE_ROLE` 审计事件，含名称/描述前后快照。

### 3.5 应用与目录（iam:role:*）
| 方法 | 路径 |
|---|---|
| GET | `/api/v1/admin/applications`（应用注册表） |
| GET | `/api/v1/admin/user-directory`（用户目录检索） |

### 3.6 SSO 配置（iam:idp:*，仅平台）
| 方法 | 路径 |
|---|---|
| GET/POST | `/api/v1/admin/idp-configs` |
| PUT/DELETE | `/api/v1/admin/idp-configs/{configId}` |
| GET/POST/PUT/DELETE | `/api/v1/admin/idp-configs/{configId}/group-mappings[/{mappingId}]`（组→角色映射） |

### 3.7 审计（iam:audit:read，仅平台）
| 方法 | 路径 |
|---|---|
| GET | `/api/v1/admin/audit` |

`GET /api/v1/admin/audit` 保持原有 `data.{audits,total,page,size}` 响应和
`tenant_id`、`event_type`、`actor_user_id` 精确筛选。

每条 `audits` 项仅投影以下字段：`audit_log_id`、`tenant_id`、`tenant_name`、`actor_user_id`、
`actor_username`、`actor_membership_id`、`event_type`、`event_name`、`target_type`、`target_id`、
`target_display`、`result_status`、`metadata_json`、`trace_id`、`create_time`。空值仍按全局
`non_null` 规则省略；`tenant_name` 为关联租户的当前名称，关联记录缺失时可省略。
列表不再返回 `user_agent`、`ip_address`、`request_id`、`before_json`、`after_json`，即使数据库中
有值也不会出现这些键；采集、数据库列和历史记录继续保留。`metadata_json` 仍为 JSON 文本字符串。
列表 SQL 同样采用明确的列投影，不读取上述五项；排序保持 `create_time DESC, id DESC`。

可选筛选参数如下，多个条件之间为 AND：

| 参数 | 语义 |
|---|---|
| `tenant_ids` | 多选租户筛选。使用重复 query key 编码，例如 `tenant_ids=t-a&tenant_ids=t-b`；管理台应通过 `URLSearchParams.append('tenant_ids', tenantId)` 对每个已选租户追加，不能发送 `tenant_ids[]` 或逗号拼接（两种错误编码均返回 400）。服务将其与旧 `tenant_id` 去空白、去重后合并为 OR 集合，再与其他筛选条件按 AND 组合。缺省、`tenant_ids=` 或全为空表示全部租户；最多 100 个不同租户。未知或已删除的租户 ID 仍按精确历史值查询，未命中时仅返回空结果，不返回 400。 |
| `keyword` | 最多 100 个字符的模糊匹配，命中 `event_type`、事件目录中的 `event_name`、`actor_user_id` 或 `actor_username`。 |
| `start_time` / `end_time` | Each bound is independently optional; absent or blank means unbounded. Send ISO-8601 UTC timestamps with `Z` (preferred), or an equivalent explicit offset. Filtering uses `create_time >= start_time` and `create_time < end_time` after normalization to UTC. Example: `2026-11-03T16:00:00Z` through `2026-11-04T16:00:00Z` covers the November 4 Shanghai calendar day. |

The browser converts the selected first day's local midnight and the day after the selected last
day's local midnight to UTC, advancing by local calendar day before conversion (including 23/25-hour
DST days). Use URL encoding for offsets: a literal `+08:00` must be encoded as `%2B08%3A00`.
For example:

```text
GET /api/v1/admin/audit?start_time=2026-11-03T16%3A00%3A00Z&end_time=2026-11-04T16%3A00%3A00Z&page=1&size=20
```

Compatibility: existing `YYYY-MM-DD` values retain `Asia/Shanghai` calendar-day semantics;
start is that day's midnight, end is the following day's midnight. Thus equal date-only values
still select one day. Existing ISO local timestamps without an offset retain Shanghai wall-time
semantics and exact half-open bounds. New clients should always send UTC timestamps. MySQL
`DATETIME` query values are UTC wall clocks; offset timestamps are normalized once, with no extra
Shanghai offset. Historical rows stored before the UTC convention are not migrated here.

Malformed values return HTTP `400` with `success=false`, `code=IAM-VALID-010`, and a message naming
`start_time` or `end_time`. If both normalized bounds exist and `end_time <= start_time`, the response
is HTTP `400`, `code=IAM-VALID-002`, `message="end_time must be later than start_time"`.
Neither bound requires the other. The standard response envelope and pagination are unchanged.
Reset `page` to `1` when tenant, keyword, or confirmed date range changes; keep the date picker's
first selection local until the user confirms the range.

### 3.8 邀请与加入申请（iam:member:*，租户）
| 方法 | 路径 |
|---|---|
| POST | `/api/v1/admin/invitations`（创建邀请——G2：按邮箱分支 JIT 建号+初始密码（不存在）/省略密码行（已存在）并发送邀请邮件；`role_id` 可选，不传默认当前租户 is_owner 模板角色；`app_code` 盖默认应用（邮件链接 `?token=..&app=imorph`）；dev 仍返回 token） |
| GET | `/api/v1/admin/join-requests` |
| POST | `/api/v1/admin/join-requests/{id}/approve` / `{id}/reject` |

成员邀请使用 `POST /api/v1/admin/invitations`，需要 Bearer token 中的 `iam:member:write`，并对请求中的
`tenant_id` 执行目标租户作用域校验（租户管理员只能邀请到自己当前租户；平台管理员可以处理任意租户）。请求为：

```json
{"email":"invitee@example.com","tenant_id":"...","role_id":"..."}
```

默认沿用当前分支：`iam.member-invitation.delivery-enabled=false` 时，执行 JIT 建号/初始密码、默认 Owner 角色及原有邮件模板，响应 `data:{token}`。

显式设置 `iam.member-invitation.delivery-enabled=true` 后，启用以下严格投递模式。`role_id` 可选；提供时必须是目标租户的 TENANT 作用域角色。此模式成功响应的 `data` 仅包含：

```json
{"invitation_id":"...","invitation_status":"PENDING","delivery_status":"SUBMITTED"}
```

服务在同一事务中写入 token 哈希并调用配置的 `JavaMailSender`。`SUBMITTED` 只表示已成功提交给配置的投递器，
不表示邮件已进入收件箱，也不表示受邀人已接受。明文 token 不会进入 API 响应、审计或数据库。邮件链接由
`iam.member-invitation.accept-url-template` 的 `{token}` 占位符生成；对应账号登录后调用
`POST /api/v1/auth/invitations/{token}/accept` 才会创建成员关系并授予可选默认角色。

严格投递模式默认关闭，默认模式仍使用原有邀请邮件通道。启用严格投递模式时必须同时配置 Spring Mail、`iam.member-invitation.delivery-enabled=true`、
`from` 以及含 `{token}` 的 `accept-url-template`。配置缺失、投递器不可用或其发送调用失败都会返回 `503`，
并回滚新邀请，不会把失败的请求伪装成已发送。

---

## 4. 相关文档

- 接入方：`03-业务系统接入指南`（登录/验签/鉴权/权限变更即时生效）
- 业务逻辑：`04-业务逻辑流程`（角色/权限展示与校验）
- 需求与差距：`../requirements/M10W3-能力盘点与IAM差距分析.md`
- 管理台：`01-平台管理员手册` / `02-租户管理员手册`

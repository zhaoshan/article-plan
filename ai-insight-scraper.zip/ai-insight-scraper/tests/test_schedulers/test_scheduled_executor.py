"""ScheduledExecutor 单元测试"""

import uuid
from datetime import datetime
from unittest.mock import AsyncMock, Mock

import pytest

from src.database.models import CrawlScheduleModel
from src.models.crawl_task import CrawlTask
from src.schedulers.scheduled_executor import execute_scheduled_crawl


@pytest.fixture
def sample_schedule():
    """返回一个启用的 CrawlScheduleModel"""
    return CrawlScheduleModel(
        schedule_id=str(uuid.uuid4()),
        site="example.com",
        target_url="https://example.com/",
        cron_expression="0 2 * * *",
        timezone="Asia/Tokyo",
        enabled=1,
        max_depth=0,
        headless=1,
        output_type="local",
        description="test schedule",
        create_time=datetime.now(),
        update_time=datetime.now(),
    )


@pytest.mark.asyncio
async def test_execute_scheduled_crawl_success(monkeypatch, sample_schedule):
    """定时调度成功执行，日志与任务状态均更新为 completed"""
    # Mock repositories
    schedule_repo_mock = AsyncMock()
    schedule_repo_mock.find_by_id.return_value = sample_schedule

    log_repo_mock = AsyncMock()
    created_log = AsyncMock()
    created_log.log_id = "log-001"
    log_repo_mock.create.return_value = created_log

    task_repo_mock = AsyncMock()
    created_task = CrawlTask(
        task_id="task-001",
        task_type="scheduled_full_site",
        site="example.com",
        target_url="https://example.com/",
        output_type="local",
        schedule_id=sample_schedule.schedule_id,
    )
    task_repo_mock.create.return_value = created_task

    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.ScheduleRepository",
        lambda: schedule_repo_mock,
    )
    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.ScheduleLogRepository",
        lambda: log_repo_mock,
    )
    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.TaskRepository",
        lambda: task_repo_mock,
    )

    # Mock CrawlSemaphoreGuard
    class FakeGuard:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.CrawlSemaphoreGuard",
        lambda task_id: FakeGuard(),
    )

    # Mock FullSiteCrawler
    fake_crawler = AsyncMock()
    fake_crawler.run.return_value = {
        "links_path": "/tmp/links.json",
        "tree_path": "/tmp/tree.json",
        "stats": {"total_pages": 10, "total_links": 100},
    }

    def fake_full_site_crawler(*args, **kwargs):
        return fake_crawler

    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.FullSiteCrawler",
        fake_full_site_crawler,
    )

    await execute_scheduled_crawl(sample_schedule.schedule_id)

    # 验证任务创建与状态
    assert task_repo_mock.create.called
    assert task_repo_mock.mark_running.called
    assert task_repo_mock.mark_completed.called
    _, kwargs = task_repo_mock.mark_completed.call_args
    assert kwargs["pages_crawled"] == 10
    assert kwargs["links_found"] == 100

    # 验证日志状态
    assert log_repo_mock.create.called
    assert log_repo_mock.update_status.called
    assert log_repo_mock.mark_completed.called


@pytest.mark.asyncio
async def test_execute_disabled_schedule_skipped(monkeypatch, sample_schedule):
    """禁用调度直接跳过，不创建日志"""
    sample_schedule.enabled = 0

    schedule_repo_mock = AsyncMock()
    schedule_repo_mock.find_by_id.return_value = sample_schedule

    log_repo_mock = AsyncMock()

    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.ScheduleRepository",
        lambda: schedule_repo_mock,
    )
    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.ScheduleLogRepository",
        lambda: log_repo_mock,
    )

    await execute_scheduled_crawl(sample_schedule.schedule_id)

    schedule_repo_mock.find_by_id.assert_awaited_once_with(sample_schedule.schedule_id)
    log_repo_mock.create.assert_not_called()


@pytest.mark.asyncio
async def test_execute_missing_schedule_skipped(monkeypatch):
    """调度不存在直接跳过"""
    schedule_repo_mock = AsyncMock()
    schedule_repo_mock.find_by_id.return_value = None

    log_repo_mock = AsyncMock()

    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.ScheduleRepository",
        lambda: schedule_repo_mock,
    )
    monkeypatch.setattr(
        "src.schedulers.scheduled_executor.ScheduleLogRepository",
        lambda: log_repo_mock,
    )

    await execute_scheduled_crawl("non-existent-id")

    log_repo_mock.create.assert_not_called()

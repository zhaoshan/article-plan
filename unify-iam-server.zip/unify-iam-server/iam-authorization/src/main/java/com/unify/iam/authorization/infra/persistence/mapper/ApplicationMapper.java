package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import org.apache.ibatis.annotations.Mapper;

/** iam_application Mapper。 */
@Mapper
public interface ApplicationMapper extends BaseMapper<ApplicationPO> {
}

package com.unify.iam.app.app.service.admin;

import com.unify.iam.api.dto.admin.CreateUserRequest;
import com.unify.iam.api.dto.admin.UpdateUserRequest;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.identity.common.constant.IdentityProviderType;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 管理面用户服务（docs/04 §3.2，iam:user:*）。
 */
@Service
public class AdminUserService {

    private final UserRepository userRepository;
    private final UserIdentityRepository userIdentityRepository;

    public AdminUserService(UserRepository userRepository,
                            UserIdentityRepository userIdentityRepository) {
        this.userRepository = userRepository;
        this.userIdentityRepository = userIdentityRepository;
    }

    /** 管理员建用户：gateway_user + 本地密码身份。 */
    @Transactional
    public String create(CreateUserRequest request) {
        String username = request.username().trim();
        if (userRepository.findByUsername(username).isPresent()) {
            throw AuthException.badRequest("用户名已存在");
        }
        String userId = IdGenerator.newBizId();
        UserPO user = new UserPO();
        user.setUserId(userId);
        user.setUsername(username);
        user.setPrimaryEmail(request.email() == null ? null : request.email().trim().toLowerCase());
        user.setPasswordHash(BCryptUtils.hash(request.password()));
        user.setFullName(request.fullName());
        user.setUserStatus("ACTIVE");
        user.setRegistrationSource("ADMIN");
        userRepository.create(user);

        UserIdentityPO identity = new UserIdentityPO();
        identity.setUserIdentityId(IdGenerator.newBizId());
        identity.setUserId(userId);
        identity.setProviderType(IdentityProviderType.LOCAL.name());
        identity.setProviderKey("password");
        identity.setSubject(username);
        identity.setLoginName(username);
        identity.setEmailAtIdp(user.getPrimaryEmail());
        identity.setIdentityStatus("ACTIVE");
        userIdentityRepository.create(identity);
        return userId;
    }

    /** 更新资料/状态（不含密码）。 */
    public void update(String userId, UpdateUserRequest request) {
        UserPO user = userRepository.findByUserId(userId)
                .orElseThrow(() -> AuthException.notFound("用户不存在"));
        if (request.email() != null) {
            user.setPrimaryEmail(request.email().trim().toLowerCase());
        }
        if (request.fullName() != null) {
            user.setFullName(request.fullName());
        }
        if (request.displayName() != null) {
            user.setDisplayName(request.displayName());
        }
        if (request.userStatus() != null) {
            user.setUserStatus(request.userStatus());
        }
        userRepository.update(user);
    }

    /** 逻辑删除用户（禁用）。 */
    public void delete(String userId) {
        userRepository.findByUserId(userId).orElseThrow(() -> AuthException.notFound("用户不存在"));
        userRepository.logicalDelete(userId);
    }
}

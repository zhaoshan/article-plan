package com.unify.iam.app.security;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 管理接口权限点注解：controller 方法级标注所需 {@code iam:*} 权限码。
 *
 * <p>由 {@link ManagementAuthorizationInterceptor} 在请求进入时校验：未满足 → 403。未认证 → 401。
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface RequirePermission {

    /** 所需权限点 code（如 {@code iam:user:read}）。 */
    String value();
}
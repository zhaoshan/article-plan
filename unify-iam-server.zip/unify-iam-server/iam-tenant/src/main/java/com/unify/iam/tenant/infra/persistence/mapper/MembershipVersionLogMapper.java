package com.unify.iam.tenant.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.tenant.infra.persistence.po.MembershipVersionLogPO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/** gateway_membership_version_log Mapper。 */
@Mapper
public interface MembershipVersionLogMapper extends BaseMapper<MembershipVersionLogPO> {

    /** 当前最大日志 id（版本 feed 游标；无记录 → 0）。 */
    @Select("SELECT COALESCE(MAX(id), 0) FROM gateway_membership_version_log")
    long maxId();
}

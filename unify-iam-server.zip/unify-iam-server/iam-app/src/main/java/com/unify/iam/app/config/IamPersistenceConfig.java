package com.unify.iam.app.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis-Plus Mapper 扫描配置。
 *
 * <p>独立于 {@code IamApplication}：完整上下文启动时被组件扫描装配；
 * {@code @WebMvcTest} 切片会排除本 {@code @Configuration}，避免无 DataSource 的上下文加载失败。
 */
@Configuration
@MapperScan({
        "com.unify.iam.app.infra.persistence.mapper",
        "com.unify.iam.identity.infra.persistence.mapper",
        "com.unify.iam.tenant.infra.persistence.mapper",
        "com.unify.iam.authorization.infra.persistence.mapper"
})
public class IamPersistenceConfig {
}

package com.unify.iam.app.config;

import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import com.unify.iam.app.security.RequestMeta;
import com.unify.iam.common.log.LogPayload;
import com.unify.iam.common.util.LogMasks;
import com.unify.iam.api.model.JwtClaims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerMapping;

/**
 * 访问日志过滤器（2026-11-05 日志分层①）：每个 API 请求一行——method/path/status/耗时/
 * requestId/actor/tenantId；{@code @LogPayload} 白名单端点额外输出<b>脱敏后</b>请求体（③）。
 *
 * <p>body 捕获：仅包装 {@code ContentCachingRequestWrapper}（Spring 读取 body 时自动缓存，无侵入）；
 * 仅当 handler 方法带 {@code @LogPayload} 且 Content-Type 为 JSON 时输出，强制过 {@link LogMasks}。
 * 凭据类端点永不允许声明 {@code @LogPayload}（注解 javadoc + CLAUDE.md 双保险）。
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class AccessLogFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger("ACCESS");

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String path = request.getRequestURI();
        if (!path.startsWith("/api/v1/")) {
            chain.doFilter(request, response);
            return;
        }
        ContentCachingRequestWrapper cached = new ContentCachingRequestWrapper(request);
        long start = System.currentTimeMillis();
        try {
            chain.doFilter(cached, response);
        } finally {
            long duration = System.currentTimeMillis() - start;
            String requestId = String.valueOf(request.getAttribute(RequestMeta.REQUEST_ID_ATTR));
            JwtClaims claims = (JwtClaims) request.getAttribute(ManagementAuthorizationInterceptor.AUTH_CLAIMS_ATTR);
            String actor = claims == null ? "-" : claims.userId();
            String tenant = claims == null ? "-" : claims.tenantId();
            log.info("{} {} | status={} | {}ms | rid={} | actor={} | tenant={}",
                    request.getMethod(), pathWithQuery(request), response.getStatus(),
                    duration, requestId, actor, tenant);
            logPayloadIfAllowed(cached, request, path);
        }
    }

    private void logPayloadIfAllowed(ContentCachingRequestWrapper cached, HttpServletRequest request, String path) {
        Object handler = request.getAttribute(HandlerMapping.BEST_MATCHING_HANDLER_ATTRIBUTE);
        if (!(handler instanceof HandlerMethod hm) || !hm.hasMethodAnnotation(LogPayload.class)) {
            return;
        }
        String contentType = cached.getContentType();
        if (contentType == null || !contentType.toLowerCase().startsWith(MediaType.APPLICATION_JSON_VALUE)) {
            return;
        }
        byte[] body = cached.getContentAsByteArray();
        if (body.length == 0) {
            return;
        }
        String raw = new String(body, StandardCharsets.UTF_8);
        log.info("PAYLOAD {} {} | {}", request.getMethod(), path, LogMasks.maskJson(raw));
    }

    private String pathWithQuery(HttpServletRequest request) {
        String query = request.getQueryString();
        // query 只记参数名不记值（防 code/state/token 类敏感值进日志）
        if (query == null || query.isBlank()) {
            return request.getRequestURI();
        }
        StringBuilder names = new StringBuilder();
        for (String pair : query.split("&")) {
            int eq = pair.indexOf('=');
            names.append(names.length() > 0 ? "&" : "?")
                    .append(eq > 0 ? pair.substring(0, eq) : pair)
                    .append("=…");
        }
        return request.getRequestURI() + names;
    }
}

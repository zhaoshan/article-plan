package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

/**
 * 邀请 app_code 解析集成测试（2026-11-11 修复「链接恒 imorph」）：
 * 租户启用应用（iam_tenant_application 首个）→ 回落 iam.mail.invitation-default-app；
 * 存量邀请（app_code NULL）accept 时按租户应用兜底。
 * 断言邀请记录 app_code、邮件链接 &app= 参数与 accept 后 redirect_url 命中层级一致。
 */
class InvitationAppCodeResolutionIntegrationTest extends IamIntegrationTestBase {

    @MockitoBean
    private com.unify.iam.app.mail.EmailTool emailTool;

    @org.springframework.beans.factory.annotation.Autowired
    private com.unify.iam.app.config.IamProperties iamProperties;

    /** 层级区分：把 parlant 主页指向专用地址（区别于基址 5173），验证走「租户应用」层而非基址兜底 */
    @org.junit.jupiter.api.BeforeEach
    void pinParlantHomepage() {
        iamProperties.getAppHomepages().put("parlant-agent-server", "http://localhost:9199/app/");
    }

    @org.junit.jupiter.api.AfterEach
    void unpinParlantHomepage() {
        iamProperties.getAppHomepages().remove("parlant-agent-server");
    }

    private String sfx() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    private String adminToken() throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("access_token").toString();
    }

    @Test
    void ownerInvitationUsesTenantAppCodeInRecordAndMailLink() throws Exception {
        String admin = adminToken();
        String email = "aic_" + sfx() + "@unify.local";
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"aic_" + sfx() + "\",\"tenant_name\":\"AIC " + sfx() + "\","
                                + "\"app_codes\":[\"parlant-agent-server\"],\"owner_email\":\"" + email + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();

        // 邀请记录 app_code = 租户启用应用
        String appCode = jdbcTemplate.queryForObject(
                "SELECT app_code FROM gateway_invitation WHERE tenant_id=? ORDER BY id DESC LIMIT 1",
                String.class, tenantId.trim());
        assertThat(appCode.trim()).isEqualTo("parlant-agent-server");
        // 邮件链接 &app= 与之一致
        ArgumentCaptor<String> html = ArgumentCaptor.forClass(String.class);
        Mockito.verify(emailTool).send(eq(email), org.mockito.ArgumentMatchers.anyString(), html.capture());
        assertThat(html.getValue())
                .contains("/invitations/accept?token=")
                .contains("&app=parlant-agent-server");
    }

    @Test
    void memberInvitationFallsBackToDefaultAppWhenTenantHasNoAppRecord() throws Exception {
        String admin = adminToken();
        // 建租户（app_codes 必填）后删应用登记，模拟存量无应用租户 → 回落 invitation-default-app
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"aicf_" + sfx() + "\",\"tenant_name\":\"AICF\","
                                + "\"app_codes\":[\"parlant-agent-server\"],\"owner_user_id\":\"u-1000\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        jdbcTemplate.update("DELETE FROM iam_tenant_application WHERE tenant_id=?", tenantId.trim());

        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"aicf_" + sfx() + "@unify.local\",\"tenant_id\":\"" + tenantId + "\"}"))
                .andExpect(status().isOk());

        String appCode = jdbcTemplate.queryForObject(
                "SELECT app_code FROM gateway_invitation WHERE tenant_id=? ORDER BY id DESC LIMIT 1",
                String.class, tenantId.trim());
        assertThat(appCode.trim()).isEqualTo("imorph");
        Mockito.verify(emailTool).send(org.mockito.ArgumentMatchers.anyString(),
                org.mockito.ArgumentMatchers.anyString(), contains("&app=imorph"));
    }

    /** 存量邀请（app_code NULL，旧 Owner 转移/企业开通等流程产生）accept 时按租户启用应用兜底。 */
    @Test
    void legacyNullAppCodeInvitationResolvesTenantAppAtAccept() throws Exception {
        String admin = adminToken();
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"aicl_" + sfx() + "\",\"tenant_name\":\"AIC Legacy\","
                                + "\"app_codes\":[\"parlant-agent-server\"],\"owner_user_id\":\"u-1000\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        // 邀请 viewer（seed 只读用户，可直接登录 accept）；日志模式响应带明文 token
        String plain = unwrapData(mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"viewer@unify.local\",\"tenant_id\":\"" + tenantId + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("token").toString();
        // 模拟存量：清掉 app_code（旧 persistOwnerInvitation 不写该列）
        jdbcTemplate.update("UPDATE gateway_invitation SET app_code=NULL WHERE tenant_id=?", tenantId.trim());

        String viewer = unwrapData(mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"viewer\",\"password\":\"" + b64("view123") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("access_token").toString();

        // accept → redirect_url 命中租户应用层（归一去尾斜杠），而非基址兜底
        String redirect = unwrapData(mockMvc.perform(post("/api/v1/auth/invitations/" + plain + "/accept")
                        .header("Authorization", "Bearer " + viewer))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("redirect_url").toString();
        assertThat(redirect).isEqualTo("http://localhost:9199/app");
    }
}

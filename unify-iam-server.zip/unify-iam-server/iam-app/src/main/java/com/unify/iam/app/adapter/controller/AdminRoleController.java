package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateRoleRequest;
import com.unify.iam.api.dto.admin.SetPermissionsRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminRoleService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：角色 CRUD（iam:role:*）。 */
@RestController
@RequestMapping("/api/v1/admin/roles")
public class AdminRoleController {

    private final AdminRoleService adminRoleService;
    private final AuditService auditService;

    public AdminRoleController(AdminRoleService adminRoleService, AuditService auditService) {
        this.adminRoleService = adminRoleService;
        this.auditService = auditService;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_ROLE_READ)
    public Map<String, Object> list(@RequestParam(name = "scope_type", required = false) String scopeType,
                                    @RequestParam(name = "scope_id", required = false) String scopeId) {
        List<Map<String, String>> roles = adminRoleService.listByScope(CurrentAuth.claims(), scopeType, scopeId)
                .stream().map(this::toBrief).toList();
        return Map.of("roles", roles, "count", roles.size());
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_ROLE_WRITE)
    public Map<String, String> create(@Valid @RequestBody CreateRoleRequest request) {
        String roleId = adminRoleService.create(CurrentAuth.claims(), request);
        String tenantId = "TENANT".equals(request.scopeType()) ? request.scopeId() : null;
        auditService.audit().event("ADMIN_CREATE_ROLE").actor(CurrentAuth.claims().userId())
                .target("ROLE", roleId).result("SUCCESS").tenant(tenantId)
                .write(Map.of("role_code", request.roleCode()));
        return Map.of("role_id", roleId);
    }

    @PutMapping("/{roleId}/permissions")
    @RequirePermission(PermissionCodes.IAM_ROLE_WRITE)
    public Map<String, String> setPermissions(@PathVariable String roleId,
                                              @Valid @RequestBody SetPermissionsRequest request) {
        adminRoleService.setPermissions(CurrentAuth.claims(), roleId, request);
        auditService.audit().event("ADMIN_SET_ROLE_PERMISSIONS").actor(CurrentAuth.claims().userId())
                .target("ROLE", roleId).result("SUCCESS").write(null);
        return Map.of("role_id", roleId);
    }

    @GetMapping("/{roleId}/permissions")
    @RequirePermission(PermissionCodes.IAM_ROLE_READ)
    public Map<String, Object> getPermissions(@PathVariable String roleId) {
        return Map.of("permission_ids", adminRoleService.getPermissionIds(roleId));
    }

    @DeleteMapping("/{roleId}")
    @RequirePermission(PermissionCodes.IAM_ROLE_WRITE)
    public Map<String, String> delete(@PathVariable String roleId) {
        adminRoleService.delete(CurrentAuth.claims(), roleId);
        return Map.of("role_id", roleId);
    }

    private Map<String, String> toBrief(RolePO r) {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("role_id", r.getRoleId());
        m.put("role_code", r.getRoleCode());
        m.put("role_name", r.getRoleName());
        m.put("scope_type", r.getScopeType());
        m.put("scope_id", r.getScopeId());
        m.put("role_status", r.getRoleStatus());
        return m;
    }
}

---
description: 检查 SSO / Keycloak / JWKS 联调链路状态
---

核对企业 SSO 全链路，按序输出：
1. IAM 是否在 8090：`curl -s localhost:8090/.well-known/jwks.json`（应 200、kid=iam-key-1）。
2. DB IdP 配置：`gateway_tenant_idp_config`（应有 `kc-org-a` 指向 Keycloak 8099 realm org-a，client_id=iam）。
3. 组映射：`gateway_idp_group_mapping`（agent-operators→r-1001，match_value 用 `/agent-operators` 带斜杠形态）。
4. 用户 claims 快照：`gateway_user_identity.claims_json` 的 `groups` 应含 `/agent-operators`（每次登录刷新）。
5. Keycloak 侧提示：client 需 Group Membership mapper（Token Claim Name=groups、Add to ID token=ON），且用户已入组。
查询用：`docker exec spring-ai-alibaba-mysql sh -c 'mysql -uroot -proot123456 -e "..."'`。
如某步失败给出修复指引（参考 CLAUDE.md 开发注意 + docs/03 附录 A）。

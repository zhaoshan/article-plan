"""定时调度管理路由

提供定时全站爬取调度配置的 CRUD、手动触发与执行日志查询。
鉴权：内部接口，请求头 Authorization: Bearer <internal_token>
"""

import logging
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query

from src.core.auth import require_internal_token
from src.database import (
    ScheduleRepository,
    ScheduleLogRepository,
    CrawlScheduleModel,
    CrawlScheduleLogModel,
)
from src.models.api_response import DefaultResult
from src.models.crawl_schedule import (
    CrawlScheduleCreate,
    CrawlScheduleUpdate,
    CrawlScheduleResponse,
    CrawlScheduleLogResponse,
)
from src.schedulers import scheduler_service

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/schedules",
    tags=["定时调度管理"],
    dependencies=[Depends(require_internal_token)],
)


def _schedule_model_from_create(data: CrawlScheduleCreate) -> CrawlScheduleModel:
    """CrawlScheduleCreate → CrawlScheduleModel"""
    return CrawlScheduleModel(
        schedule_id=str(uuid.uuid4()),
        site=data.site,
        target_url=data.target_url,
        cron_expression=data.cron_expression,
        timezone=data.timezone,
        enabled=1 if data.enabled else 0,
        max_depth=data.max_depth,
        headless=1 if data.headless else 0,
        output_type=data.output_type,
        description=data.description,
        create_time=datetime.now(),
        update_time=datetime.now(),
    )


def _apply_update(model: CrawlScheduleModel, data: CrawlScheduleUpdate) -> CrawlScheduleModel:
    """将更新请求中的非空字段应用到 ORM 模型"""
    if data.site is not None:
        model.site = data.site
    if data.target_url is not None:
        model.target_url = data.target_url
    if data.cron_expression is not None:
        model.cron_expression = data.cron_expression
    if data.timezone is not None:
        model.timezone = data.timezone
    if data.enabled is not None:
        model.enabled = 1 if data.enabled else 0
    if data.max_depth is not None:
        model.max_depth = data.max_depth
    if data.headless is not None:
        model.headless = 1 if data.headless else 0
    if data.output_type is not None:
        model.output_type = data.output_type
    if data.description is not None:
        model.description = data.description
    model.update_time = datetime.now()
    return model


@router.post("", response_model=DefaultResult)
async def create_schedule(request: CrawlScheduleCreate) -> DefaultResult:
    """创建定时调度配置"""
    repo = ScheduleRepository()
    model = _schedule_model_from_create(request)
    await repo.create(model)

    # 如果启用，立即注册 APScheduler job
    if model.enabled:
        scheduler_service.add_schedule_job(model)

    logger.info(f"创建调度配置: schedule_id={model.schedule_id}, site={model.site}")
    return DefaultResult(
        data=CrawlScheduleResponse.model_validate(model).model_dump(),
    )


@router.get("", response_model=DefaultResult)
async def list_schedules(
    site: str | None = None,
    enabled: bool | None = None,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> DefaultResult:
    """查询定时调度配置列表"""
    repo = ScheduleRepository()
    models = await repo.list_all(site=site, enabled=enabled, limit=limit, offset=offset)
    return DefaultResult(
        data=[CrawlScheduleResponse.model_validate(m).model_dump() for m in models],
    )


@router.get("/{schedule_id}", response_model=DefaultResult)
async def get_schedule(schedule_id: str) -> DefaultResult:
    """查询单个调度配置"""
    repo = ScheduleRepository()
    model = await repo.find_by_id(schedule_id)
    if model is None:
        raise HTTPException(status_code=404, detail="调度配置不存在")

    data = CrawlScheduleResponse.model_validate(model).model_dump()
    job_info = scheduler_service.get_job_info(schedule_id)
    if job_info is not None:
        data["job_info"] = job_info
    return DefaultResult(data=data)


@router.put("/{schedule_id}", response_model=DefaultResult)
async def update_schedule(schedule_id: str, request: CrawlScheduleUpdate) -> DefaultResult:
    """更新定时调度配置"""
    repo = ScheduleRepository()
    model = await repo.find_by_id(schedule_id)
    if model is None:
        raise HTTPException(status_code=404, detail="调度配置不存在")

    model = _apply_update(model, request)
    await repo.update(model)

    # 同步更新 APScheduler job
    if model.enabled:
        scheduler_service.reschedule_job(model)
    else:
        scheduler_service.remove_schedule_job(schedule_id)

    logger.info(f"更新调度配置: schedule_id={schedule_id}")
    return DefaultResult(
        data=CrawlScheduleResponse.model_validate(model).model_dump(),
    )


@router.delete("/{schedule_id}", response_model=DefaultResult)
async def delete_schedule(
    schedule_id: str,
    delete_logs: bool = Query(default=False, description="是否级联删除执行日志"),
) -> DefaultResult:
    """删除定时调度配置"""
    repo = ScheduleRepository()
    model = await repo.find_by_id(schedule_id)
    if model is None:
        raise HTTPException(status_code=404, detail="调度配置不存在")

    # 移除 APScheduler job
    scheduler_service.remove_schedule_job(schedule_id)

    # 级联删除日志
    if delete_logs:
        log_repo = ScheduleLogRepository()
        logs = await log_repo.list_by_schedule(schedule_id, limit=10000)
        for log in logs:
            await log_repo.delete(log.log_id)

    await repo.delete(schedule_id)
    logger.info(f"删除调度配置: schedule_id={schedule_id}")
    return DefaultResult(data={"deleted": True})


@router.post("/{schedule_id}/trigger", response_model=DefaultResult)
async def trigger_schedule(schedule_id: str) -> DefaultResult:
    """立即手动触发一次调度执行"""
    repo = ScheduleRepository()
    model = await repo.find_by_id(schedule_id)
    if model is None:
        raise HTTPException(status_code=404, detail="调度配置不存在")

    scheduler_service.trigger_job_now(schedule_id, trigger_type="manual")
    logger.info(f"手动触发调度: schedule_id={schedule_id}")
    return DefaultResult(data={"schedule_id": schedule_id, "triggered": True})


@router.get("/{schedule_id}/logs", response_model=DefaultResult)
async def list_schedule_logs(
    schedule_id: str,
    limit: int = Query(default=20, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> DefaultResult:
    """查询指定调度的执行日志"""
    repo = ScheduleLogRepository()
    logs = await repo.list_by_schedule(schedule_id, limit=limit, offset=offset)
    return DefaultResult(
        data=[CrawlScheduleLogResponse.model_validate(log).model_dump() for log in logs],
    )

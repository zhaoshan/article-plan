package com.unify.iam.app.oidc;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.common.exception.AuthException;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import java.util.Map;

/**
 * OIDC provider 的 HTTP 客户端（拉 discovery/JWKS、换 token）。
 */
@Component
public class OidcProviderClient {

    private final RestClient restClient;

    public OidcProviderClient(RestClient.Builder builder) {
        this.restClient = builder.build();
    }

    /** GET 原始字符串（JWKS 解析用）。 */
    public String getString(String url) {
        try {
            return restClient.get().uri(url).retrieve().body(String.class);
        } catch (RestClientException e) {
            throw AuthException.serviceUnavailable(ErrorCode.IDP_UNREACHABLE, typeHint(e));
        }
    }

    /** GET JSON。 */
    public Map<String, Object> getJson(String url) {
        try {
            return restClient.get()
                    .uri(url)
                    .retrieve()
                    .body(new ParameterizedTypeReference<Map<String, Object>>() {
                    });
        } catch (RestClientException e) {
            throw AuthException.serviceUnavailable(ErrorCode.IDP_UNREACHABLE, typeHint(e));
        }
    }

    /** POST form 表单（OAuth token 端点）。 */
    public Map<String, Object> postForm(String url, MultiValueMap<String, String> form) {
        try {
            return restClient.post()
                    .uri(url)
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(form)
                    .retrieve()
                    .body(new ParameterizedTypeReference<Map<String, Object>>() {
                    });
        } catch (RestClientException e) {
            throw AuthException.serviceUnavailable(ErrorCode.IDP_TOKEN_EXCHANGE_FAILED, typeHint(e));
        }
    }

    private String typeHint(Throwable e) {
        String msg = e.getMessage();
        return (msg == null || msg.isBlank()) ? e.getClass().getSimpleName() : msg;
    }
}
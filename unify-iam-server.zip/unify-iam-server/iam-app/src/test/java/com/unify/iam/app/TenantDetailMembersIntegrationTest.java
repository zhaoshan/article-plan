package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

/** 详情成员的真实关联、缺失资料、CHAR 业务键与无分页上限契约。 */
@Transactional
class TenantDetailMembersIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private SqlSessionTemplate sqlSession;

    private String token(String username, String password) throws Exception {
        String json = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64(password)))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return JsonUtils.fromJson(dataJson(json), LoginResponse.class).accessToken();
    }

    private void tenant(String id, String ownerId) {
        jdbcTemplate.update("""
                INSERT INTO gateway_tenant (tenant_id, tenant_code, tenant_name, tenant_type, owner_user_id)
                VALUES (?, ?, ?, 'ORGANIZATION', ?)
                """, id, id, "真实租户", ownerId);
    }

    private void user(String id, String fullName, String displayName, String email, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_user (user_id, username, full_name, display_name, primary_email,
                  default_tenant_id, delete_flag)
                VALUES (?, ?, ?, ?, ?, 'unrelated-default-tenant', ?)
                """, id, "login-" + id, fullName, displayName, email, deleted);
    }

    private void membership(String id, String tenantId, String userId, String state, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_membership (membership_id, tenant_id, user_id, membership_status,
                  join_source, is_default, delete_flag)
                VALUES (?, ?, ?, ?, 'ADMIN', 0, ?)
                """, id, tenantId, userId, state, deleted);
    }

    private void role(String id, String tenantId, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_role (role_id, scope_type, scope_id, role_code, role_name, delete_flag)
                VALUES (?, 'TENANT', ?, ?, ?, ?)
                """, id, tenantId, id, "角色-" + id, deleted);
    }

    private void grant(String id, String memberId, String roleId, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_membership_role (membership_role_id, membership_id, role_id, delete_flag)
                VALUES (?, ?, ?, ?)
                """, id, memberId, roleId, deleted);
    }

    private Map<String, Object> details(String tenantId, String bearer) throws Exception {
        // 测试在同一回滚事务里用 JDBC 改 fixture；清理 MyBatis 缓存，模拟下次独立请求的新会话。
        sqlSession.clearCache();
        String json = mockMvc.perform(get("/api/v1/admin/tenants/" + tenantId + "/details")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return unwrapData(json);
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> items(Map<String, Object> data) {
        return (List<Map<String, Object>>) ((Map<String, Object>) data.get("members")).get("items");
    }

    @Test
    void preservesRealProfilesAndRolesWhileReportingUnavailableUsersAndNeverGuessingOwner() throws Exception {
        tenant("detail-relations", null);
        user("detail-real", "真实全名", "真实昵称", "real@example.test", 0);
        user("detail-minimal", null, null, null, 0);
        user("detail-deleted", "不应泄露", "不应泄露", "deleted@example.test", 1);
        membership("detail-ms-real", "detail-relations", "detail-real", "ACTIVE", 0);
        membership("detail-ms-minimal", "detail-relations", "detail-minimal", "PENDING", 0);
        membership("detail-ms-missing", "detail-relations", "detail-missing", "SUSPENDED", 0);
        membership("detail-ms-deleted-user", "detail-relations", "detail-deleted", "REMOVED", 0);
        membership("detail-ms-deleted", "detail-relations", "detail-hidden", "ACTIVE", 1);
        tenant("detail-other", null);
        membership("detail-ms-other", "detail-other", "detail-real", "ACTIVE", 0);
        role("detail-role-live", "detail-relations", 0);
        role("detail-role-deleted", "detail-relations", 1);
        role("detail-role-unbound", "detail-relations", 0);
        grant("detail-grant-live", "detail-ms-real", "detail-role-live", 0);
        grant("detail-grant-deleted-role", "detail-ms-real", "detail-role-deleted", 0);
        grant("detail-grant-missing-role", "detail-ms-real", "detail-role-missing", 0);
        grant("detail-grant-deleted", "detail-ms-real", "detail-role-unbound", 1);

        Map<String, Object> data = details("detail-relations", token("admin", "admin123"));
        assertThat(data).containsEntry("owner_assigned", false).doesNotContainKey("owner");
        List<Map<String, Object>> members = items(data);
        assertThat(members).hasSize(4);
        assertThat(members.getFirst()).containsAllEntriesOf(Map.of(
                "membership_id", "detail-ms-real", "user_id", "detail-real", "user_available", true,
                "username", "login-detail-real", "full_name", "真实全名", "display_name", "真实昵称",
                "email", "real@example.test", "membership_status", "ACTIVE", "is_owner", false));
        assertThat(members.getFirst().get("roles")).isEqualTo(List.of(Map.of(
                "role_id", "detail-role-live", "role_code", "detail-role-live", "role_name", "角色-detail-role-live")));
        assertThat(members.get(1)).containsEntry("user_available", true)
                .containsEntry("username", "login-detail-minimal").containsEntry("membership_status", "PENDING")
                .doesNotContainKeys("full_name", "display_name", "email");
        for (int i : List.of(2, 3)) {
            assertThat(members.get(i)).containsEntry("user_available", false).containsEntry("is_owner", false)
                    .doesNotContainKeys("username", "full_name", "display_name", "email");
        }
        assertThat(members.get(2)).containsEntry("membership_status", "SUSPENDED");
        assertThat(members.get(3)).containsEntry("membership_status", "REMOVED");
    }

    @Test
    void charPaddingDoesNotBreakUserRoleOrAuthoritativeOwnerAssociation() throws Exception {
        // 只修改当前事务连接的 session sql_mode，回归 CHAR(32) 返回补齐空格的情况。
        String original = jdbcTemplate.queryForObject("SELECT @@session.sql_mode", String.class);
        jdbcTemplate.execute("SET SESSION sql_mode = CONCAT(@@session.sql_mode, ',PAD_CHAR_TO_FULL_LENGTH')");
        try {
            tenant("detail-char", "char-owner");
            user("char-first", null, null, "first@example.test", 0);
            user("char-owner", "全名", "昵称", "owner@example.test", 0);
            membership("char-ms-first", "detail-char", "char-first", "ACTIVE", 0);
            membership("char-ms-owner", "detail-char", "char-owner", "ACTIVE", 0);
            role("char-role", "detail-char", 0);
            grant("char-grant", "char-ms-owner", "char-role", 0);
            assertThat(jdbcTemplate.queryForObject(
                    "SELECT LENGTH(user_id) FROM gateway_user WHERE user_id='char-owner'", Integer.class)).isEqualTo(32);
            Map<String, Object> data = details("detail-char", token("admin", "admin123"));
            assertThat(data.get("owner")).isInstanceOf(Map.class);
            assertThat((Map<?, ?>) data.get("owner")).isEqualTo(Map.of(
                    "membership_id", "char-ms-owner", "user_id", "char-owner", "username", "login-char-owner",
                    "full_name", "全名", "display_name", "昵称", "email", "owner@example.test",
                    "membership_status", "ACTIVE", "roles", List.of(Map.of(
                            "role_id", "char-role", "role_code", "char-role", "role_name", "角色-char-role"))));
            assertThat(items(data).getFirst()).containsEntry("is_owner", false);
            assertThat(items(data).get(1)).containsEntry("is_owner", true).containsEntry("user_available", true);
        } finally {
            jdbcTemplate.update("SET SESSION sql_mode = ?", original);
        }
    }

    @Test
    void returnsMoreThanTwentyAndIgnoresObsoletePaginationParameters() throws Exception {
        tenant("detail-many", null);
        members("detail-many", 25);
        mockMvc.perform(get("/api/v1/admin/tenants/detail-many/details")
                        .header("Authorization", "Bearer " + token("admin", "admin123"))
                        .param("member_page", "99").param("member_size", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.members.items.length()").value(25))
                .andExpect(jsonPath("$.data.members.total").value(25))
                .andExpect(jsonPath("$.data.members.limit").value(1000))
                .andExpect(jsonPath("$.data.members.truncated").value(false))
                .andExpect(jsonPath("$.data.members.page").doesNotExist())
                .andExpect(jsonPath("$.data.members.size").doesNotExist());
    }

    private void members(String tenantId, int count) {
        List<Object[]> rows = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            rows.add(new Object[]{tenantId + "-m-" + i, tenantId, tenantId + "-u-" + i});
        }
        jdbcTemplate.batchUpdate("""
                INSERT INTO gateway_membership (membership_id, tenant_id, user_id, membership_status)
                VALUES (?, ?, ?, 'ACTIVE')
                """, rows);
    }

    @Test
    void capsAt1000ReportsTrueTotalAndResolvesOwnerOutsideReturnedMembers() throws Exception {
        String bearer = token("admin", "admin123");
        tenant("detail-cap", null);
        members("detail-cap", 1000);
        Map<String, Object> boundary = details("detail-cap", bearer);
        assertThat(boundary.get("members")).isEqualTo(Map.of(
                "items", items(boundary), "total", 1000, "limit", 1000, "truncated", false));
        user("detail-cap-owner", "真正 Owner", null, "cap-owner@example.test", 0);
        membership("detail-cap-owner-ms", "detail-cap", "detail-cap-owner", "ACTIVE", 0);
        jdbcTemplate.update("UPDATE gateway_tenant SET owner_user_id='detail-cap-owner' WHERE tenant_id='detail-cap'");
        Map<String, Object> overflow = details("detail-cap", bearer);
        assertThat(items(overflow)).hasSize(1000).noneMatch(item -> Boolean.TRUE.equals(item.get("is_owner")));
        assertThat(overflow.get("members")).isEqualTo(Map.of(
                "items", items(overflow), "total", 1001, "limit", 1000, "truncated", true));
        assertThat(overflow).containsEntry("owner_assigned", true);
        assertThat(((Map<?, ?>) overflow.get("owner")).get("user_id")).isEqualTo("detail-cap-owner");
    }

    @Test
    void emptyAndUnavailableOwnerStatesRemainTruthful() throws Exception {
        String bearer = token("admin", "admin123");
        tenant("detail-empty", null);
        Map<String, Object> empty = details("detail-empty", bearer);
        assertThat(empty.get("members")).isEqualTo(Map.of("items", List.of(), "total", 0, "limit", 1000, "truncated", false));
        assertThat(empty).containsEntry("owner_assigned", false).doesNotContainKey("owner");
        jdbcTemplate.update("UPDATE gateway_tenant SET owner_user_id='unavailable-owner' WHERE tenant_id='detail-empty'");
        membership("unavailable-owner-ms", "detail-empty", "unavailable-owner", "ACTIVE", 0);
        Map<String, Object> unavailable = details("detail-empty", bearer);
        assertThat(unavailable).containsEntry("owner_assigned", true).doesNotContainKey("owner");
        assertThat(items(unavailable).getFirst()).containsEntry("is_owner", true).containsEntry("user_available", false);
    }

    @Test
    void requiresBothPermissionsAndTenantScopeAndKeepsTenantListUnpaged() throws Exception {
        String admin = token("admin", "admin123");
        mockMvc.perform(get("/api/v1/admin/tenants/tenant-org-a/details"))
                .andExpect(status().isUnauthorized());
        String viewer = token("viewer", "view123");
        mockMvc.perform(get("/api/v1/admin/tenants/tenant-org-a/details")
                        .header("Authorization", "Bearer " + viewer))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.data.members").doesNotExist());
        // 使用真实租户角色/授权，分别验证两项权限及跨租户作用域，而不改变平台管理员。
        role("detail-reader", "tenant-org-a", 0);
        grant("detail-reader-grant", "ms-3001", "detail-reader", 0);
        assertThat(jdbcTemplate.update("""
                INSERT INTO gateway_role_permission (role_permission_id, role_id, permission_id)
                SELECT CONCAT('detail-', permission_id), 'detail-reader', permission_id FROM gateway_permission
                WHERE permission_code IN ('iam:tenant:read', 'iam:member:read') AND delete_flag=0
                """)).isEqualTo(2);
        String scopedReader = token("viewer", "view123");
        details("tenant-org-a", scopedReader);
        tenant("detail-scope-foreign", null);
        mockMvc.perform(get("/api/v1/admin/tenants/detail-scope-foreign/details")
                        .header("Authorization", "Bearer " + scopedReader))
                .andExpect(status().isForbidden());
        jdbcTemplate.update("""
                UPDATE gateway_role_permission SET delete_flag=1
                WHERE role_id='detail-reader' AND permission_id='p-2005'
                """);
        String tenantReadOnly = token("viewer", "view123");
        mockMvc.perform(get("/api/v1/admin/tenants/tenant-org-a/details")
                        .header("Authorization", "Bearer " + tenantReadOnly))
                .andExpect(status().isForbidden());
        jdbcTemplate.update("""
                UPDATE gateway_role_permission SET delete_flag=CASE WHEN permission_id='p-2005' THEN 0 ELSE 1 END
                WHERE role_id='detail-reader'
                """);
        mockMvc.perform(get("/api/v1/admin/tenants/tenant-org-a/details")
                        .header("Authorization", "Bearer " + token("viewer", "view123")))
                .andExpect(status().isForbidden());
        mockMvc.perform(get("/api/v1/admin/tenants").param("limit", "1000")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.tenants").isArray())
                .andExpect(jsonPath("$.data.count").isNumber())
                .andExpect(jsonPath("$.data.page").doesNotExist()).andExpect(jsonPath("$.data.total").doesNotExist());
    }
}

package com.unify.iam.app.security;

import com.unify.iam.common.exception.ErrorCode;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import java.text.ParseException;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 * JWT 签发与验签（RS256 + kid header）。
 *
 * <p>{@code sign} 用于登录/dev-token 签发；{@code verify} 供 IAM 自身受保护端点（如 /me）
 * 就地验签。parlant 侧由 GatewayProvider 独立验签，不依赖本类。
 *
 * <p>P1-05（2026-11-11）：verify 除签名 + exp 外补 claims 校验——iss 与配置逐字相等、aud
 * 非空、nbf/iat 未来时间（60s 时钟容忍）拒绝、kid 格式白名单。iss/aud 由签发管线写入，
 * 存量 token 天然通过——零兼容期。纵深防御点：密钥复用/多签发者场景下防跨系统 token 混淆。
 */
@Component
public class JwtSigner {

    /** nbf/iat 未来时间容忍（秒）：防验证方/签发方时钟微偏误杀 */
    private static final long CLOCK_SKEW_SECONDS = 60;

    /** kid 格式白名单（P1-05：防路径样式 kid，如 ../../ 之类被接受） */
    private static final java.util.regex.Pattern KID_PATTERN = java.util.regex.Pattern.compile("^[A-Za-z0-9_-]{1,64}$");

    private final RsaKeyManager keyManager;
    private final IamProperties props;

    public JwtSigner(RsaKeyManager keyManager, IamProperties props) {
        this.keyManager = keyManager;
        this.props = props;
    }

    /**
     * 签发 RS256 JWT（紧凑序列化，header 带 kid）。
     */
    public String sign(JwtClaims claims) {
        try {
            JWTClaimsSet.Builder builder = new JWTClaimsSet.Builder()
                    .issuer(claims.iss())
                    .subject(claims.sub())
                    .claim("tenantId", claims.tenantId())
                    .claim("membershipId", claims.membershipId())
                    .claim("roles", claims.roles())
                    .claim("permissions", claims.permissions())
                    .claim("attrs", claims.attrs())
                    .claim("ver", claims.ver())
                    .expirationTime(Date.from(Instant.ofEpochSecond(claims.exp())))
                    .issueTime(Date.from(Instant.ofEpochSecond(claims.iat())))
                    .jwtID(claims.jti());
            // aud：单值收拢为字符串（parlant 等按字符串校验的消费端精确向后兼容），多值才序列化为数组
            if (claims.aud().size() == 1) {
                builder.audience(claims.aud().get(0));
            } else {
                builder.audience(claims.aud());
            }
            JWTClaimsSet claimsSet = builder.build();
            JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256)
                    .keyID(keyManager.kid())
                    .build();
            SignedJWT signedJwt = new SignedJWT(header, claimsSet);
            signedJwt.sign(new RSASSASigner(keyManager.signingKey()));
            return signedJwt.serialize();
        } catch (JOSEException e) {
            throw new IllegalStateException("JWT 签名失败", e);
        }
    }

    /**
     * 验签（RS256 公钥）+ claims 校验：exp（缺失/过期拒绝）、iss（逐字相等）、aud（非空）、
     * nbf/iat（未来时间拒绝，60s 容忍）、kid 格式白名单。负向均 401 且错误码与签名错误区分。
     *
     * @throws AuthException 401（签名无效 / 缺 exp / 已过期 / 格式错误）
     */
    public JwtClaims verify(String token) {
        try {
            SignedJWT signedJwt = SignedJWT.parse(token);
            // P1-05：kid 格式白名单（在验签前——header 无需验签即可读，尽早拒绝畸形 header）
            String kid = signedJwt.getHeader().getKeyID();
            if (kid == null || !KID_PATTERN.matcher(kid).matches()) {
                throw AuthException.unauthorized(ErrorCode.TOKEN_MALFORMED);
            }
            RSAKey publicKey = keyManager.signingKey().toPublicJWK();
            JWSVerifier verifier = new RSASSAVerifier(publicKey);
            if (!signedJwt.verify(verifier)) {
                throw AuthException.unauthorized(ErrorCode.TOKEN_BAD_SIGNATURE);
            }
            JWTClaimsSet claimsSet = signedJwt.getJWTClaimsSet();
            Date exp = claimsSet.getExpirationTime();
            if (exp == null) {
                throw AuthException.unauthorized(ErrorCode.TOKEN_MISSING_EXP);
            }
            if (exp.before(new Date())) {
                throw AuthException.unauthorized(ErrorCode.TOKEN_EXPIRED);
            }
            // P1-05 claims 校验（签发管线本就以这些值签发，存量 token 天然通过）
            String expectedIss = props.getJwt().getIssuer();
            if (claimsSet.getIssuer() == null || !claimsSet.getIssuer().equals(expectedIss)) {
                throw AuthException.unauthorized(ErrorCode.ISSUER_MISMATCH);
            }
            if (claimsSet.getAudience() == null || claimsSet.getAudience().isEmpty()) {
                throw AuthException.unauthorized(ErrorCode.AUD_MISMATCH);
            }
            long nowPlusSkew = Instant.now().plusSeconds(CLOCK_SKEW_SECONDS).getEpochSecond() * 1000L;
            if (claimsSet.getNotBeforeTime() != null
                    && claimsSet.getNotBeforeTime().after(new Date(nowPlusSkew))) {
                throw AuthException.unauthorized(ErrorCode.TOKEN_NOT_YET_VALID);
            }
            if (claimsSet.getIssueTime() != null
                    && claimsSet.getIssueTime().after(new Date(nowPlusSkew))) {
                throw AuthException.unauthorized(ErrorCode.TOKEN_NOT_YET_VALID);
            }
            return toJwtClaims(claimsSet);
        } catch (ParseException e) {
            throw AuthException.unauthorized(ErrorCode.TOKEN_MALFORMED);
        } catch (JOSEException e) {
            throw AuthException.unauthorized(ErrorCode.TOKEN_VERIFY_FAILED);
        }
    }

    @SuppressWarnings("unchecked")
    private JwtClaims toJwtClaims(JWTClaimsSet cs) {
        Object rolesObj = cs.getClaim("roles");
        Object permsObj = cs.getClaim("permissions");
        long ver = 0L; // ver 缺省/非法 → 0（旧 token 无 ver，方案 c 前签发；parlant 按 0 保守判定）
        try {
            Long v = cs.getLongClaim("ver");
            ver = v == null ? 0L : v;
        } catch (java.text.ParseException ignored) {
            // 非法 ver 值 → 0
        }
        return new JwtClaims(
                cs.getIssuer(),
                cs.getAudience() == null ? List.of() : cs.getAudience(),
                cs.getSubject(),
                String.valueOf(cs.getClaim("tenantId")),
                cs.getClaim("membershipId") == null ? null : String.valueOf(cs.getClaim("membershipId")),
                rolesObj instanceof List<?> ? ((List<String>) rolesObj) : List.of(),
                permsObj instanceof List<?> ? ((List<String>) permsObj) : List.of(),
                cs.getClaim("attrs") instanceof java.util.Map<?, ?> attrs
                        ? (java.util.Map<String, List<String>>) attrs : java.util.Map.of(),
                cs.getExpirationTime() == null ? 0L : cs.getExpirationTime().toInstant().getEpochSecond(),
                cs.getIssueTime() == null ? 0L : cs.getIssueTime().toInstant().getEpochSecond(),
                cs.getJWTID(),
                ver);
    }
}

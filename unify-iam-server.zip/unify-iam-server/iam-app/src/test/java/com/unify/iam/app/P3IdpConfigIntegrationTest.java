package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * docs/07（P3.5）集成测试：管理面 SSO 配置——IdP 配置 + 组→角色映射 CRUD。
 * iam:idp:* 仅平台管理员（租户 TenantAdmin 无此权限 → 403）。
 */
class P3IdpConfigIntegrationTest extends IamIntegrationTestBase {

    @BeforeEach
    void cleanIdpTables() {
        // 测试隔离：清空 IdP 配置/组映射（与 OidcSsoIntegrationTest 同模式，避免共享库唯一键碰撞）
        jdbcTemplate.update("DELETE FROM gateway_idp_group_mapping");
        jdbcTemplate.update("DELETE FROM gateway_tenant_idp_config");
    }

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminPost(String url, Object body, String token) throws Exception {
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    private Map<String, Object> idpBody(String tenantId) {
        Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("tenant_id", tenantId);
        m.put("provider_key", "keycloak");
        m.put("display_name", "Org A SSO");
        m.put("issuer", "http://localhost:8099/realms/org-a");
        m.put("authorization_endpoint", "http://localhost:8099/realms/org-a/protocol/openid-connect/auth");
        m.put("token_endpoint", "http://localhost:8099/realms/org-a/protocol/openid-connect/token");
        m.put("jwk_set_uri", "http://localhost:8099/realms/org-a/protocol/openid-connect/certs");
        m.put("client_id", "iam");
        m.put("client_secret", "DEV_ONLY:secret");
        m.put("scopes", List.of("openid", "email", "profile", "groups"));
        m.put("claim_mapping", Map.of("email", "email", "sub", "sub", "groups", "groups"));
        m.put("allowed_domains", List.of("org-a.com"));
        m.put("pkce_required", true);
        m.put("email_verified_required", true);
        m.put("jit_provisioning_enabled", true);
        m.put("default_join_policy", "AUTO_JOIN");
        return m;
    }

    @Test
    void platformAdminManagesIdpConfigAndGroupMappings() throws Exception {
        String admin = login("admin", "admin123");

        // ① 建 IdP 配置（tenant-org-a）
        String configId = JsonUtils.fromJson(
                adminPost("/api/v1/admin/idp-configs", idpBody("tenant-org-a"), admin),
                Map.class).get("idp_config_id").toString();

        // ①b 重复（同 provider+issuer）→ 400（uk 冲突，非 500）
        mockMvc.perform(post("/api/v1/admin/idp-configs")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(idpBody("tenant-org-a"))))
                .andExpect(status().isBadRequest());

        // ② 列表：secret 只暴露 has_secret、不回明文
        String listBody = mockMvc.perform(get("/api/v1/admin/idp-configs")
                        .param("tenant_id", "tenant-org-a").header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.idp_configs[?(@.idp_config_id == '" + configId + "')].has_secret")
                        .value(org.hamcrest.Matchers.hasItem(true)))
                .andReturn().getResponse().getContentAsString();
        assertThat(listBody).doesNotContain("client_secret");

        // ③ 组映射 CRUD（target_role = tenant-org-a 的 AgentOperator r-1001）
        String mappingId = JsonUtils.fromJson(adminPost("/api/v1/admin/idp-configs/" + configId + "/group-mappings",
                Map.of("match_mode", "EXACT", "match_value", "/agent-operators", "target_role_id", "r-1001", "priority", 100), admin),
                Map.class).get("mapping_id").toString();
        mockMvc.perform(get("/api/v1/admin/idp-configs/" + configId + "/group-mappings")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.group_mappings[?(@.mapping_id == '" + mappingId + "')].match_value")
                        .value(org.hamcrest.Matchers.hasItem("/agent-operators")));

        // ④ 更新配置（display_name）
        mockMvc.perform(put("/api/v1/admin/idp-configs/" + configId)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("display_name", "Org A SSO 更新"))))
                .andExpect(status().isOk());

        // ⑤ 删除映射 + 删除配置
        mockMvc.perform(delete("/api/v1/admin/idp-configs/" + configId + "/group-mappings/" + mappingId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
        mockMvc.perform(delete("/api/v1/admin/idp-configs/" + configId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
    }

    @Test
    void createConfigAcceptsCommaSeparatedDomains() throws Exception {
        String admin = login("admin", "admin123");
        // allowed_domains 传逗号字符串（前端表单/手动 curl 形态）→ 应接受并解析为数组
        Map<String, Object> body = idpBody("tenant-org-a");
        body.put("allowed_domains", "org-a.com, org-b.com");
        String configId = JsonUtils.fromJson(adminPost("/api/v1/admin/idp-configs", body, admin),
                Map.class).get("idp_config_id").toString();
        String listBody = mockMvc.perform(get("/api/v1/admin/idp-configs").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        // 逗号字符串被解析为数组：allowed_domains = ["org-a.com","org-b.com"]
        assertThat(listBody).contains("\"org-a.com\"").contains("\"org-b.com\"");
    }

    @Test
    void groupMappingRejectsRoleOutsideConfigTenant() throws Exception {
        String admin = login("admin", "admin123");
        String configId = JsonUtils.fromJson(
                adminPost("/api/v1/admin/idp-configs", idpBody("tenant-org-a"), admin),
                Map.class).get("idp_config_id").toString();

        // 建第二个租户，取其 TenantAdmin 角色（不属于 tenant-org-a）
        String tenantB = JsonUtils.fromJson(adminPost("/api/v1/admin/tenants",
                Map.of("tenant_code", "idp-tenant-b", "tenant_name", "Idp Tenant B",
                        "app_codes", List.of("parlant-agent-server")), admin),
                Map.class).get("tenant_id").toString();
        String roleB = mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", tenantB)
                        .header("Authorization", "Bearer " + admin))
                .andReturn().getResponse().getContentAsString();
        String roleBId = ((List<Map<String, Object>>) unwrapData(roleB).get("roles"))
                .stream().filter(r -> "TenantAdmin".equals(r.get("role_code")))
                .map(r -> r.get("role_id").toString()).findFirst().orElseThrow();

        // target_role 属于别的租户 → 400
        mockMvc.perform(post("/api/v1/admin/idp-configs/" + configId + "/group-mappings")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "match_mode", "EXACT", "match_value", "/x", "target_role_id", roleBId))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void nonPlatformUsersGet403OnIdpAdmin() throws Exception {
        String admin = login("admin", "admin123");
        // 平台建租户 + 首人（TenantAdmin），以及 seed viewer
        String ownerUserId = JsonUtils.fromJson(adminPost("/api/v1/admin/users",
                Map.of("username", "idp_owner", "email", "idp-owner@unify.local", "password", b64("Passw0rd!")), admin),
                Map.class).get("user_id").toString();
        adminPost("/api/v1/admin/tenants", Map.of(
                "tenant_code", "idp-tenant-c", "tenant_name", "Idp Tenant C",
                "owner_user_id", ownerUserId, "app_codes", List.of("parlant-agent-server")), admin);

        // 租户管理员（TenantAdmin）无 iam:idp:* → 403
        String owner = login("idp_owner", "Passw0rd!");
        mockMvc.perform(get("/api/v1/admin/idp-configs").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isForbidden());

        // seed viewer（无任何 iam:*）→ 403
        String viewer = login("viewer", "view123");
        mockMvc.perform(get("/api/v1/admin/idp-configs").param("tenant_id", "tenant-org-a")
                        .header("Authorization", "Bearer " + viewer))
                .andExpect(status().isForbidden());
    }
}

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

/**
 * P1-15 自助改密撤销会话集成测试：改密后旧 refresh 全部撤销、旧 access 因版本 bump 立即
 * stale（管理面 ver 检查 401 IAM-AUTH-015）、响应携带重签的新会话（纯增量契约）、
 * 审计事件 USER_CHANGE_PASSWORD / USER_RESET_PASSWORD 落库（metadata 不含密码）。
 */
class ChangePasswordRevocationIntegrationTest extends IamIntegrationTestBase {

    private Map<String, Object> login(String username, String password) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
    }

    /** 共享库恢复：断言中途失败也必须把 seed 账号密码还原（直改哈希，不依赖任何会话）。 */
    @AfterEach
    void restoreSeedPasswords() {
        jdbcTemplate.update("UPDATE gateway_user SET password_hash=? WHERE user_id='u-1000'",
                com.unify.iam.common.util.BCryptUtils.hash("admin123"));
    }

    @Test
    void changePasswordRevokesOldSessionAndReturnsNewOne() throws Exception {
        Map<String, Object> before = login("admin", "admin123");
        String oldAccess = before.get("access_token").toString();
        String oldRefresh = before.get("refresh_token").toString();

        // 改密 → 200 + 新会话字段（纯增量：status=CHANGED 保留）
        Map<String, Object> data = unwrapData(mockMvc.perform(post("/api/v1/auth/change-password")
                        .header("Authorization", "Bearer " + oldAccess)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"old_password\":\"" + b64("admin123") + "\",\"new_password\":\""
                                + b64("NewAdm1n!x") + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("CHANGED"))
                .andExpect(jsonPath("$.data.access_token").isNotEmpty())
                .andReturn().getResponse().getContentAsString());
        String newAccess = data.get("access_token").toString();
        String newRefresh = data.get("refresh_token").toString();
        assertThat(newAccess).isNotEqualTo(oldAccess);

        // 新会话可用：/auth/me 200
        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + newAccess))
                .andExpect(status().isOk());
        // 新 refresh 可续签
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"" + newRefresh + "\"}"))
                .andExpect(status().isOk());

        // 旧 refresh 已撤销 → 401
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"" + oldRefresh + "\"}"))
                .andExpect(status().isUnauthorized());
        // 旧 access 因版本 bump 立即 stale → 管理面 ver 检查 401 IAM-AUTH-015
        mockMvc.perform(get("/api/v1/admin/users").param("limit", "1")
                        .header("Authorization", "Bearer " + oldAccess))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-015"));

        // 审计落库：USER_CHANGE_PASSWORD，metadata 记事实标记、绝不记密码
        Map<String, Object> row = jdbcTemplate.queryForMap(
                "SELECT result_status, metadata_json FROM gateway_audit_log WHERE event_type='USER_CHANGE_PASSWORD' "
                        + "ORDER BY id DESC LIMIT 1");
        assertThat(row.get("result_status").toString()).isEqualTo("SUCCESS");
        assertThat(row.get("metadata_json").toString())
                .contains("sessions_revoked").doesNotContain("NewAdm1n");
    }

    @Test
    void forgotResetWritesAuditEvent() throws Exception {
        // 专用用户（避免撞共享库其它用例的 viewer 邮箱 forgot 60s 冷却窗口）
        String username = "cpv_" + java.util.UUID.randomUUID().toString().substring(0, 8);
        String email = username + "@unify.local";
        String admin = login("admin", "admin123").get("access_token").toString();
        Map<String, Object> created = unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + email + "\",\"password\":\""
                                + b64("Init#12345") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        String uid = created.get("user_id").toString();

        // 忘记密码（日志模式返 token）→ 重置 → USER_RESET_PASSWORD 审计落库
        Map<String, Object> forgot = unwrapData(mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        String token = forgot.get("token").toString();
        mockMvc.perform(post("/api/v1/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"token\":\"" + token + "\",\"new_password\":\"" + b64("Viewer#999") + "\"}"))
                .andExpect(status().isOk());
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_audit_log WHERE event_type='USER_RESET_PASSWORD' "
                        + "AND target_id=?", Integer.class, uid.trim());
        assertThat(count).isGreaterThanOrEqualTo(1);
    }
}

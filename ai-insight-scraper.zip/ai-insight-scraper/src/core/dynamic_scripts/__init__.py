"""动态脚本注册表"""

from src.core.dynamic_scripts.base import DynamicScript
from src.core.dynamic_scripts.faq_crawler import FaqCrawler

# 脚本注册表：script_name → 实现类
_SCRIPT_REGISTRY: dict[str, type[DynamicScript]] = {
    "faq_crawler": FaqCrawler,
}


def get_script(script_name: str) -> type[DynamicScript]:
    """按名称查找动态脚本实现类。

    Args:
        script_name: 脚本注册名（如 'faq_crawler'）

    Returns:
        对应的 DynamicScript 子类

    Raises:
        KeyError: 脚本名未注册
    """
    if script_name not in _SCRIPT_REGISTRY:
        available = list(_SCRIPT_REGISTRY.keys())
        raise KeyError(
            f"未知动态脚本: '{script_name}'，可用: {available}"
        )
    return _SCRIPT_REGISTRY[script_name]


def register_script(name: str, script_cls: type[DynamicScript]) -> None:
    """注册新的动态脚本实现类（用于扩展）。

    Args:
        name: 脚本注册名
        script_cls: DynamicScript 子类
    """
    _SCRIPT_REGISTRY[name] = script_cls


__all__ = [
    "DynamicScript",
    "get_script",
    "register_script",
]

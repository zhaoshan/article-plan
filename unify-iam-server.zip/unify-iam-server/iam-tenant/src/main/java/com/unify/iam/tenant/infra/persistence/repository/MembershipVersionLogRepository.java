package com.unify.iam.tenant.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.tenant.infra.persistence.mapper.MembershipVersionLogMapper;
import com.unify.iam.tenant.infra.persistence.po.MembershipVersionLogPO;
import java.util.Collection;
import java.util.List;
import org.springframework.stereotype.Repository;

/**
 * 成员令牌版本变更日志仓储（方案 c 即时吊销，docs/07 §8.3；parlant doc11 附录 B）。
 * 每次 bump 记一行，自增 id 作 feed 游标：首次全量快照 + 之后增量；删除记 tombstone。
 */
@Repository
public class MembershipVersionLogRepository {

    private final MembershipVersionLogMapper mapper;

    public MembershipVersionLogRepository(MembershipVersionLogMapper mapper) {
        this.mapper = mapper;
    }

    /** 记录一次版本变更（bump 后调用，tokenVersion = 变更后的值）。 */
    public void record(String membershipId, String tenantId, int tokenVersion, String changeType) {
        MembershipVersionLogPO po = new MembershipVersionLogPO();
        po.setLogId(IdGenerator.newBizId());
        po.setMembershipId(membershipId);
        po.setTenantId(tenantId);
        po.setTokenVersion(tokenVersion);
        po.setChangeType(changeType);
        mapper.insert(po);
    }

    /** 增量：id > sinceId 且租户在 app 作用域内，按 id 升序限量（空作用域 → 空）。 */
    public List<MembershipVersionLogPO> listAfter(Long sinceId, Collection<String> tenantIds, int limit) {
        if (tenantIds == null || tenantIds.isEmpty()) {
            return List.of();
        }
        return mapper.selectList(new LambdaQueryWrapper<MembershipVersionLogPO>()
                        .gt(MembershipVersionLogPO::getId, sinceId)
                        .in(MembershipVersionLogPO::getTenantId, tenantIds)
                        .orderByAsc(MembershipVersionLogPO::getId)
                        .last("LIMIT " + limit))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 某成员的最近一条日志（feed 点查 tombstone 判断用）。 */
    public List<MembershipVersionLogPO> listByMembership(String membershipId) {
        return mapper.selectList(new LambdaQueryWrapper<MembershipVersionLogPO>()
                        .eq(MembershipVersionLogPO::getMembershipId, membershipId)
                        .orderByDesc(MembershipVersionLogPO::getId))
                .stream().map(this::trimBizKeys).toList();
    }

    /** feed 游标：当前最大日志 id。 */
    public long maxId() {
        return mapper.maxId();
    }

    private MembershipVersionLogPO trimBizKeys(MembershipVersionLogPO po) {
        if (po.getMembershipId() != null) {
            po.setMembershipId(po.getMembershipId().trim());
        }
        if (po.getTenantId() != null) {
            po.setTenantId(po.getTenantId().trim());
        }
        return po;
    }
}

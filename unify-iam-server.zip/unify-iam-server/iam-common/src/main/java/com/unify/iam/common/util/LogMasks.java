package com.unify.iam.common.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 日志脱敏工具（2026-11-05 日志分层方案③）：body 日志的白名单安全前提。
 *
 * <p>两条铁律：
 * <ol>
 *   <li><b>字段名黑名单无条件打码</b>（不看值、不可关闭）——password、token、secret 类字段命中即 {@code *** }。
 *       base64 密码可逆 ≈ 明文，即使误把 {@code @LogPayload} 打在凭据端点上也不可能泄进日志；</li>
 *   <li><b>email 掩码</b>——保留首尾可排查性（{@code a***@example.com}）。</li>
 * </ol>
 *
 * <p>配套边界（CLAUDE.md）：凭据类端点（/auth/token、register、refresh、reset/change-password、
 * SSO callback query）永不声明 {@code @LogPayload}；白名单仅限管理面写操作与服务间端点。
 */
public final class LogMasks {

    private LogMasks() {
    }

    /** 字段名黑名单（小写匹配，含下划线/中划线变体）。 */
    private static final Set<String> SENSITIVE_FIELDS = Set.of(
            "password", "old_password", "new_password", "oldpassword", "newpassword",
            "refresh_token", "refreshtoken", "access_token", "accesstoken",
            "token", "id_token", "idtoken", "client_secret", "clientsecret",
            "secret", "authorization", "auth", "code", "state", "initial_password");

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Pattern EMAIL = Pattern.compile("(^.|^..)(.*)(@.*$)");
    private static final Pattern EMAIL_LIKE =
            Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");

    /** 单条日志里的 email 掩码。 */
    public static String maskEmail(String email) {
        if (email == null) {
            return null;
        }
        String trimmed = email.trim();
        int at = trimmed.indexOf('@');
        if (at <= 0) {
            return trimmed;
        }
        String local = trimmed.substring(0, at);
        String head = local.length() <= 1 ? local : local.substring(0, Math.min(2, local.length() - 1));
        return head + "***" + trimmed.substring(at);
    }

    /** 任意字符串值中的 email 形态掩码（用于非 JSON 场景）。 */
    public static String maskText(String text) {
        if (text == null) {
            return null;
        }
        return EMAIL_LIKE.matcher(text).replaceAll(mr -> maskEmail(mr.group()));
    }

    /** JSON body 脱敏：递归遍历，黑名单字段打码、字符串值中的 email 形态掩码。非法 JSON 原样截断返回。 */
    public static String maskJson(String json) {
        if (json == null) {
            return null;
        }
        try {
            JsonNode node = MAPPER.readTree(json);
            JsonNode masked = maskNode(node);
            return MAPPER.writeValueAsString(masked);
        } catch (Exception e) {
            return truncate(json.trim(), 512);
        }
    }

    /** Map 载荷脱敏（结构化日志参数用）。 */
    public static Map<String, Object> maskMap(Map<String, Object> payload) {
        if (payload == null) {
            return null;
        }
        java.util.LinkedHashMap<String, Object> out = new java.util.LinkedHashMap<>();
        payload.forEach((k, v) -> out.put(k, isSensitive(k) ? "***" : maskValue(v)));
        return out;
    }

    private static JsonNode maskNode(JsonNode node) {
        if (node instanceof ObjectNode obj) {
            Iterator<Map.Entry<String, JsonNode>> it = obj.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                if (isSensitive(e.getKey())) {
                    e.setValue(com.fasterxml.jackson.databind.node.TextNode.valueOf("***"));
                } else {
                    e.setValue(maskNode(e.getValue()));
                }
            }
            return obj;
        }
        if (node instanceof ArrayNode arr) {
            for (int i = 0; i < arr.size(); i++) {
                arr.set(i, maskNode(arr.get(i)));
            }
            return arr;
        }
        if (node.isTextual()) {
            return com.fasterxml.jackson.databind.node.TextNode.valueOf(maskText(node.asText()));
        }
        return node;
    }

    private static Object maskValue(Object v) {
        if (v instanceof Map<?, ?> m) {
            java.util.LinkedHashMap<String, Object> out = new java.util.LinkedHashMap<>();
            m.forEach((k, val) -> out.put(String.valueOf(k), isSensitive(String.valueOf(k)) ? "***" : maskValue(val)));
            return out;
        }
        if (v instanceof List<?> l) {
            return l.stream().map(LogMasks::maskValue).toList();
        }
        if (v instanceof String s) {
            return maskText(s);
        }
        return v;
    }

    static boolean isSensitive(String fieldName) {
        return SENSITIVE_FIELDS.contains(fieldName.trim().toLowerCase(Locale.ROOT));
    }

    private static String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max) + "...(truncated)";
    }
}

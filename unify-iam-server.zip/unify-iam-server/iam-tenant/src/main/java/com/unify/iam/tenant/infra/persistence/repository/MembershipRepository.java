package com.unify.iam.tenant.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.unify.iam.tenant.infra.persistence.mapper.MembershipMapper;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/**
 * 成员关系仓储。读取时对 CHAR(32) 业务键 trim。
 */
@Repository
public class MembershipRepository {

    private final MembershipMapper membershipMapper;

    public MembershipRepository(MembershipMapper membershipMapper) {
        this.membershipMapper = membershipMapper;
    }

    /** 查询用户默认且 ACTIVE 的成员关系（is_default=1 + ACTIVE + 未逻辑删除）。 */
    public Optional<MembershipPO> findDefaultActive(String userId) {
        // LIMIT 1：is_default 语义上每用户至多 1，但数据可能不一致（如历史/并发建多租户 owner），
        // selectOne 多行会抛 TooManyResultsException → 取最早一条，登录不再 500（CLAUDE.md 非唯一列 LIMIT 1）
        return Optional.ofNullable(membershipMapper.selectOne(new LambdaQueryWrapper<MembershipPO>()
                        .eq(MembershipPO::getUserId, userId)
                        .eq(MembershipPO::getIsDefault, 1)
                        .eq(MembershipPO::getMembershipStatus, "ACTIVE")
                        .orderByAsc(MembershipPO::getId)
                        .last("LIMIT 1")))
                .map(this::trimBizKeys);
    }

    /** 批量按成员关系 ID 查（审计富化等）。 */
    public List<MembershipPO> findByIds(Collection<String> membershipIds) {
        if (membershipIds == null || membershipIds.isEmpty()) {
            return List.of();
        }
        return membershipMapper.selectList(new LambdaQueryWrapper<MembershipPO>()
                        .in(MembershipPO::getMembershipId, membershipIds))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 按成员关系 ID 查（dev-token 指定 membership 用）。 */
    public Optional<MembershipPO> findById(String membershipId) {
        return Optional.ofNullable(membershipMapper.selectOne(new LambdaQueryWrapper<MembershipPO>()
                        .eq(MembershipPO::getMembershipId, membershipId)))
                .map(this::trimBizKeys);
    }

    /** 按 租户+用户 查成员关系（JIT 判断是否已加入）。 */
    public Optional<MembershipPO> findByTenantAndUser(String tenantId, String userId) {
        return Optional.ofNullable(membershipMapper.selectOne(new LambdaQueryWrapper<MembershipPO>()
                        .eq(MembershipPO::getTenantId, tenantId)
                        .eq(MembershipPO::getUserId, userId)))
                .map(this::trimBizKeys);
    }

    /** 管理端成员列表（某租户），按 id 升序。 */
    public List<MembershipPO> listByTenant(String tenantId) {
        return membershipMapper.selectList(new LambdaQueryWrapper<MembershipPO>()
                        .eq(MembershipPO::getTenantId, tenantId)
                        .orderByAsc(MembershipPO::getId))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 某用户的全部成员关系（多租户切换用），按 id 升序。 */
    public List<MembershipPO> listByUser(String userId) {
        return membershipMapper.selectList(new LambdaQueryWrapper<MembershipPO>()
                        .eq(MembershipPO::getUserId, userId)
                        .orderByAsc(MembershipPO::getId))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 更新成员（状态变更：停用/恢复等；@TableLogic 字段不参与 updateById，勿用它改 delete_flag）。 */
    public void update(MembershipPO po) {
        membershipMapper.updateById(po);
    }

    /** 逻辑删除成员（delete_flag=1，经 @TableLogic）。 */
    public void logicalDelete(String membershipId) {
        membershipMapper.delete(new LambdaQueryWrapper<MembershipPO>()
                .eq(MembershipPO::getMembershipId, membershipId));
    }

    /** 新建成员关系（JIT 用）；唯一键 (tenant_id, user_id) 冲突视为已存在（幂等）。 */
    public boolean create(MembershipPO po) {
        try {
            return membershipMapper.insert(po) > 0;
        } catch (org.springframework.dao.DuplicateKeyException e) {
            return false;
        }
    }

    /** 清除某用户所有成员关系的默认标记（新默认接管前调用，保证一用户至多一个 is_default=1）。 */
    public void clearDefault(String userId) {
        membershipMapper.update(null, new LambdaUpdateWrapper<MembershipPO>()
                .eq(MembershipPO::getUserId, userId)
                .set(MembershipPO::getIsDefault, 0));
    }

    /** 令牌版本 +1（方案 c 即时吊销 bump；@TableLogic 字段被 updateById 剔除，必须原生 UPDATE）。 */
    /** G9：刷新成员级最近打开时间（issueWithRefresh 调用：初始登录/SSO/切换；refresh 直调 issueFor 不经过，天然不刷）。 */
    public void updateLastOpenedAt(String membershipId) {
        membershipMapper.update(null, new LambdaUpdateWrapper<MembershipPO>()
                .eq(MembershipPO::getMembershipId, membershipId.trim())
                .set(MembershipPO::getLastOpenedAt, java.time.LocalDateTime.now()));
    }

    public int bumpTokenVersion(String membershipId) {
        return membershipMapper.bumpTokenVersion(membershipId.trim());
    }

    /** 某批租户下的 ACTIVE 成员（版本 feed 快照用：app 作用域 = 启用了该应用的租户）。 */
    /** G1：租户 ACTIVE 成员数（配额已用席位）。 */
    public long countActiveByTenant(String tenantId) {
        return membershipMapper.selectCount(new LambdaQueryWrapper<MembershipPO>()
                .eq(MembershipPO::getTenantId, tenantId)
                .eq(MembershipPO::getMembershipStatus, "ACTIVE"));
    }

    public List<MembershipPO> listActiveByTenants(Collection<String> tenantIds) {
        if (tenantIds == null || tenantIds.isEmpty()) {
            return List.of();
        }
        return membershipMapper.selectList(new LambdaQueryWrapper<MembershipPO>()
                        .in(MembershipPO::getTenantId, tenantIds)
                        .eq(MembershipPO::getMembershipStatus, "ACTIVE")
                        .orderByAsc(MembershipPO::getId))
                .stream().map(this::trimBizKeys).toList();
    }

    private MembershipPO trimBizKeys(MembershipPO po) {
        if (po.getMembershipId() != null) {
            po.setMembershipId(po.getMembershipId().trim());
        }
        if (po.getTenantId() != null) {
            po.setTenantId(po.getTenantId().trim());
        }
        if (po.getUserId() != null) {
            po.setUserId(po.getUserId().trim());
        }
        return po;
    }
}

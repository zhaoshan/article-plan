package com.unify.iam.authorization.app.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.authorization.infra.persistence.mapper.MembershipRoleMapper;
import com.unify.iam.authorization.infra.persistence.po.MembershipRolePO;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

/**
 * IdP 组 → 角色覆盖式同步（docs/03 §7）。
 *
 * <p>以登录时的 IdP 组映射为准重算某个成员的 {@code IDP_SYNC} 角色：
 * 本次命中的角色 upsert 授予；未命中且先前由 {@code IDP_SYNC} 授予的角色逻辑删除
 * （防僵尸角色）；{@code DIRECT} 手工授予不回收。
 */
@Service
public class RoleSyncService {

    private final MembershipRoleMapper membershipRoleMapper;

    public RoleSyncService(MembershipRoleMapper membershipRoleMapper) {
        this.membershipRoleMapper = membershipRoleMapper;
    }

    /**
     * 按期望角色集合同步该成员的 IDP_SYNC 角色。
     *
     * @param desiredRoleIds 本次由 IdP 组命中的内部角色 ID 集合（去重后）
     * @return 角色绑定是否发生变化（补授或回收任一生效）——供调用方决定是否 bump 令牌版本（方案 c）
     */
    public boolean syncIdpRoles(String membershipId, Collection<String> desiredRoleIds) {
        boolean changed = false;
        Set<String> desired = new HashSet<>(desiredRoleIds);
        List<MembershipRolePO> existing = membershipRoleMapper.selectList(
                new LambdaQueryWrapper<MembershipRolePO>()
                        .eq(MembershipRolePO::getMembershipId, membershipId));
        Set<String> existingRoleIds = existing.stream()
                .map(MembershipRolePO::getRoleId)
                .collect(Collectors.toSet());

        // 本次命中但尚未授予 → 补授（grant_source=IDP_SYNC；软删墓碑先复活，唯一键 (membership_id, role_id) 占位）
        for (String roleId : desired) {
            if (existingRoleIds.contains(roleId)) {
                continue;
            }
            String roleIdT = roleId.trim();
            if (membershipRoleMapper.revive(membershipId.trim(), roleIdT, "IDP_SYNC") == 0) {
                MembershipRolePO po = new MembershipRolePO();
                po.setMembershipRoleId(IdGenerator.newBizId());
                po.setMembershipId(membershipId.trim());
                po.setRoleId(roleIdT);
                po.setGrantSource("IDP_SYNC");
                try {
                    membershipRoleMapper.insert(po);
                    changed = true;
                } catch (DuplicateKeyException ignored) {
                    // 并发登录下唯一键 (membership_id, role_id) 兜底
                }
            }
        }

        // 移除未命中的僵尸 IDP_SYNC 角色（DIRECT 保留）——逻辑删除走 deleteById（@TableLogic，updateById 不写 delete_flag）
        for (MembershipRolePO po : existing) {
            if ("IDP_SYNC".equals(po.getGrantSource()) && !desired.contains(po.getRoleId())) {
                membershipRoleMapper.deleteById(po.getId());
                changed = true;
            }
        }
        return changed;
    }
}
# Rebuild and start attempt — 2026-11-04 (Asia/Shanghai)

The user explicitly requested rebuilding and restarting this backend. This is operational
follow-up to the active audit task, with no new implementation or Git/worktree changes.

## Runtime inspection
- Current workspace: /Users/ramiro.li/root/apps/work/platform-iam-service.
- Branch: feature/lee-1102; all source edits remain uncommitted.
- No Java backend process or listener on 8090 existed before the attempt.
- The historical gui/501/com.platform-iam.service LaunchAgent was no longer registered,
  and its saved LaunchAgents file was absent. No existing process was terminated.
- No project startup script was present. Recent runtime logs and archived restart notes
  identify this workspace JAR, Java 26.0.2.1, Spring default profile, and port 8090.

## Build
Command (JDK21, from project root):
`JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/bin:$PATH mvn -B -pl iam-app -am -DskipTests -Dmaven.compiler.proc=full package`

All seven reactor modules SUCCESS; exit 0; BUILD SUCCESS. Tests intentionally skipped for
this rebuild; prior focused test results remain in validation.md. Artifact:
`iam-app/target/iam-app-0.0.1-SNAPSHOT.jar`.

SHA-256: 12ebc4814abb98b3d4284fe4f49838ca3ff4eec3306ddb885f4748c650e71a50.
Packaged AdminAuditService bytes match the newly compiled class.
Build log: restart-build.log.

## Start and outcome
Started in a detached process with stdin closed and stdout/stderr redirected to
restart-runtime.log, using the existing project keys/rsa-private.pem through
IAM_JWT_PRIVATE_KEY_PATH (key contents not accessed):
`/Users/ramiro.li/.local/jdks/jdk-26.0.2.1.jdk/Contents/Home/bin/java -jar /Users/ramiro.li/root/apps/work/platform-iam-service/iam-app/target/iam-app-0.0.1-SNAPSHOT.jar`

PID 71419 started the correct project with the default profile, then exited. The configured
MySQL endpoint 127.0.0.1:3306 refuses connections (confirmed outside sandbox). Flyway failed
with Communications link failure -> java.net.ConnectException: Connection refused.
No database settings were changed and no unrelated infrastructure/service was started/stopped.

Final checks: PID no longer running; no 8090 listener; /actuator/health,
/actuator/health/readiness and /actuator/health/liveness all unreachable. Rebuild succeeded;
backend startup is blocked by unavailable MySQL. Restore the existing database before
retrying the same start command. No restart success is claimed.

## Dependency recovery and successful retry

User explicitly authorized starting local MySQL. Docker Desktop was started with
`open -a Docker`. Read-only container inspection identified the existing stopped
`platform-iam-service-mysql` (mysql:8.0), bound to 127.0.0.1:3306 with its existing data
volume. Executed `docker start platform-iam-service-mysql`; container is running and
MySQL reports ready for connections. No database recreation, initialization, password,
configuration or volume change was performed. Other stopped containers were not started.

Retried the same built JAR and runtime configuration in a detached process. New PID:
71905 (parent PID 1); Java26 runtime, Spring default profile, current project JAR.
Port *:8090 LISTEN verified for that exact PID. /actuator/health,
/actuator/health/readiness and /actuator/health/liveness all returned HTTP200/UP.
Previous MySQL startup blocker is resolved. Current runtime state is healthy.

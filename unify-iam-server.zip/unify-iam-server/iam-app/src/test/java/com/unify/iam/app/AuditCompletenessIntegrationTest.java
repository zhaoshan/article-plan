package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G5-a/G5-b 审计完整性与覆盖：关键变更记录含 租户/操作者/前后值/请求编号/IP，且新增写点已覆盖。
 */
class AuditCompletenessIntegrationTest extends IamIntegrationTestBase {

    private String adminToken() throws Exception {
        return login("admin", "admin123");
    }

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String createTenant(String code) throws Exception {
        Map<?, ?> t = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_code", code, "tenant_name", "Audit " + code,
                                "tenant_type", "ORGANIZATION", "app_codes", List.of("parlant-agent-server")))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        return t.get("tenant_id").toString();
    }

    private String createMember(String tenantId, String username) throws Exception {
        String token = adminToken();
        String userId = unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"email\":\"" + username + "@unify.local\",\"password\":\"" + b64("Passw0rd!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString()).get("user_id").toString();
        return unwrapData(mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"" + tenantId + "\",\"user_id\":\"" + userId + "\",\"role_ids\":[]}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString()).get("membership_id").toString();
    }

    private Map<String, Object> latestAudit(String eventType) {
        return jdbcTemplate.queryForMap(
                "SELECT tenant_id, actor_user_id, actor_membership_id, result_status, request_id, ip_address, before_json, after_json "
                        + "FROM gateway_audit_log WHERE event_type = ? ORDER BY id DESC LIMIT 1", eventType);
    }

    @Test
    void tenantUpdateAuditCarriesTenantActorBeforeAfterRequestId() throws Exception {
        String tenantId = createTenant("audit-t1");
        String reqId = "audit-req-" + tenantId;
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId)
                        .header("Authorization", "Bearer " + adminToken())
                        .header("X-Request-Id", reqId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_status\":\"DISABLED\"}"))
                .andExpect(status().isOk());

        Map<String, Object> a = latestAudit("ADMIN_UPDATE_TENANT");
        assertThat(a.get("tenant_id").toString().trim()).isEqualTo(tenantId);
        assertThat(a.get("actor_user_id")).isNotNull();
        assertThat(a.get("actor_membership_id")).isNotNull(); // 自动从请求上下文补
        assertThat(a.get("result_status")).isEqualTo("SUCCESS");
        assertThat(a.get("request_id")).isEqualTo(reqId);      // 透传 X-Request-Id
        assertThat(a.get("ip_address")).isNotNull();
        assertThat(String.valueOf(a.get("before_json"))).contains("ACTIVE");
        assertThat(String.valueOf(a.get("after_json"))).contains("DISABLED");
    }

    @Test
    void memberStatusAndRoleChangeAudited() throws Exception {
        String tenantId = createTenant("audit-t2");
        String mid = createMember(tenantId, "audit_user2");
        String token = adminToken();

        mockMvc.perform(post("/api/v1/admin/members/" + mid + "/suspend")
                        .header("Authorization", "Bearer " + token)).andExpect(status().isOk());
        Map<String, Object> suspend = latestAudit("ADMIN_SUSPEND_MEMBER");
        assertThat(suspend.get("tenant_id").toString().trim()).isEqualTo(tenantId);
        assertThat(String.valueOf(suspend.get("before_json"))).contains("ACTIVE");
        assertThat(String.valueOf(suspend.get("after_json"))).contains("SUSPENDED");

        mockMvc.perform(put("/api/v1/admin/members/" + mid + "/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"role_ids\":[]}")).andExpect(status().isOk());
        assertThat(latestAudit("ADMIN_SET_MEMBER_ROLES").get("tenant_id").toString().trim()).isEqualTo(tenantId);
    }

    @Test
    void roleDeleteIsAuditedWithTenant() throws Exception {
        String tenantId = createTenant("audit-t3");
        String token = adminToken();
        String roleId = unwrapData(mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"" + tenantId + "\",\"role_code\":\"AuditRole\",\"role_name\":\"AuditRole\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString()).get("role_id").toString();
        mockMvc.perform(delete("/api/v1/admin/roles/" + roleId)
                        .header("Authorization", "Bearer " + token)).andExpect(status().isOk());

        Map<String, Object> a = latestAudit("ADMIN_DELETE_ROLE");
        assertThat(a.get("tenant_id").toString().trim()).isEqualTo(tenantId);
        assertThat(a.get("actor_user_id")).isNotNull();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> auditRow(String eventType, String tenantId) throws Exception {
        MvcResult res = mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("event_type", eventType).param("page", "1").param("size", "20"))
                .andExpect(status().isOk()).andReturn();
        Map<String, Object> body = unwrapData(res.getResponse().getContentAsString());
        List<Map<String, Object>> audits = (List<Map<String, Object>>) body.get("audits");
        return audits.stream().filter(a -> tenantId.equals(a.get("tenant_id"))).findFirst()
                .orElseThrow(() -> new AssertionError("未找到审计行 " + eventType));
    }

    /** G5 可用性：事件目录 + 租户/操作人名称富化。 */
    @Test
    void eventsCatalogAndTenantEnrichment() throws Exception {
        mockMvc.perform(get("/api/v1/admin/audit/events").header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.events[?(@.code == 'ADMIN_UPDATE_TENANT')].name").exists());

        String tenantId = createTenant("audit-enrich");
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId)
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_status\":\"DISABLED\"}"))
                .andExpect(status().isOk());
        Map<String, Object> row = auditRow("ADMIN_UPDATE_TENANT", tenantId);
        assertThat(row.get("event_name")).isEqualTo("更新租户（启停/改名/域名）");
        assertThat(row.get("actor_username")).isEqualTo("admin");
        assertThat(row.get("tenant_name")).isEqualTo("Audit audit-enrich");
        assertThat(row.get("target_display")).isEqualTo("Audit audit-enrich"); // 目标为租户 → 租户名
    }

    /** G5 可用性：目标展示名解析（用户→用户名、成员→用户名、角色→code（名称））。 */
    @Test
    void targetDisplayResolvesUserMembershipRole() throws Exception {
        String token = adminToken();
        String tenantId = createTenant("audit-enrich2");
        String mid = createMember(tenantId, "enrich_user");
        String roleId = unwrapData(mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"" + tenantId
                                + "\",\"role_code\":\"EnrichRole\",\"role_name\":\"富化角色\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString()).get("role_id").toString();

        // 用户目标 → 用户名（ADMIN_CREATE_USER 为平台级，tenant_id 为空，不按租户过滤）
        Map<String, Object> anyUserRow = latestAuditEnriched("ADMIN_CREATE_USER");
        assertThat(String.valueOf(anyUserRow.get("target_display"))).isEqualTo("enrich_user");

        // 成员目标 → 成员用户名
        Map<String, Object> memberRow = auditRow("ADMIN_ADD_MEMBER", tenantId);
        assertThat(memberRow.get("target_display")).isEqualTo("enrich_user");

        // 角色目标 → code（名称）
        Map<String, Object> roleRow = auditRow("ADMIN_CREATE_ROLE", tenantId);
        assertThat(String.valueOf(roleRow.get("target_display"))).contains("EnrichRole").contains("富化角色");
        assertThat(roleId).isNotBlank();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> getAuditPage(String eventType, int page, int size, String token) throws Exception {
        MvcResult res = mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token)
                        .param("event_type", eventType)
                        .param("page", String.valueOf(page))
                        .param("size", String.valueOf(size)))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString());
    }

    /** 分页：不同页记录不同 + total 一致（真实分页，不再只取前 50）。 */
    @SuppressWarnings("unchecked")
    @Test
    void auditPaginationPageAndTotal() throws Exception {
        createTenant("pg-a");
        createTenant("pg-b");
        createTenant("pg-c");
        String token = adminToken();

        Map<String, Object> p1 = getAuditPage("ADMIN_CREATE_TENANT", 1, 2, token);
        Map<String, Object> p2 = getAuditPage("ADMIN_CREATE_TENANT", 2, 2, token);
        List<Map<String, Object>> a1 = (List<Map<String, Object>>) p1.get("audits");
        List<Map<String, Object>> a2 = (List<Map<String, Object>>) p2.get("audits");

        assertThat(a1).hasSize(2);
        assertThat(a2).hasSizeGreaterThanOrEqualTo(1);
        assertThat(a1.get(0).get("audit_log_id")).isNotEqualTo(a2.get(0).get("audit_log_id")); // 不同页记录
        long total1 = ((Number) p1.get("total")).longValue();
        long total2 = ((Number) p2.get("total")).longValue();
        assertThat(total1).isGreaterThanOrEqualTo(3);
        assertThat(total1).isEqualTo(total2);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> latestAuditEnriched(String eventType) throws Exception {
        MvcResult res = mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + adminToken())
                        .param("event_type", eventType).param("page", "1").param("size", "20"))
                .andExpect(status().isOk()).andReturn();
        Map<String, Object> body = unwrapData(res.getResponse().getContentAsString());
        List<Map<String, Object>> audits = (List<Map<String, Object>>) body.get("audits");
        return audits.get(0);
    }
}

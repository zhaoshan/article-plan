# Database Guidelines

> Database patterns and conventions for this project.

---

## Overview

<!--
Document your project's database conventions here.

Questions to answer:
- What ORM/query library do you use?
- How are migrations managed?
- What are the naming conventions for tables/columns?
- How do you handle transactions?
-->

(To be filled by the team)

---

## Query Patterns

<!-- How should queries be written? Batch operations? -->

(To be filled by the team)

---

## Migrations

<!-- How to create and run migrations -->

(To be filled by the team)

---

## Naming Conventions

<!-- Table names, column names, index names -->

(To be filled by the team)

---

## Common Mistakes

<!-- Database-related mistakes your team has made -->

(To be filled by the team)

## Admin role listing

### 1. Scope / Trigger

Management role visibility differs from runtime authorization. The user-defined
platform management view includes tenant roles as well as platform roles.

### 2. Signatures

- API: `GET /api/v1/admin/roles?scope_type=PLATFORM&scope_id=PLATFORM`
- Service: `AdminRoleService.listByScope(JwtClaims, String, String)`
- Management query: `RoleRepository.listForAdmin(String, String)`
- Runtime query: `RoleRepository.listByScope(String, String)` remains ACTIVE-only.

### 3. Contracts

Exact `scope_type=PLATFORM` returns every `gateway_role` row with
`delete_flag=0`, regardless of scope or role status. The platform `scope_id` does
not constrain this query. Other requests use `scope_type='TENANT'` plus the target
`scope_id`. Management lists include DISABLED roles, order by `id ASC`, and do
not paginate. The response keeps `{roles, count}` inside the existing envelope;
`count` is the returned length. Owner flags use each role's tenant/application
templates, loaded in batches; PLATFORM role rows retain `is_owner=false`.

### 4. Validation & Error Matrix

| Condition | Result |
| --- | --- |
| Missing/invalid Bearer | 401 |
| Missing `iam:role:read` | 403 |
| PLATFORM query without real platform membership role | 403 |
| Non-platform caller targets another tenant | 403 |
| Unknown authorized target tenant | Empty list |
| Deleted role | Excluded through BaseEntity `@TableLogic` |

The service must authorize through `TenantScopeGuard` before invoking the
management query. JWT role names alone are insufficient for platform access.

### 5. Good/Base/Bad Cases

- Good: platform admin lists active and disabled roles from multiple tenants.
- Base: tenant admin lists active and disabled roles only from their own tenant.
- Bad: tenant admin sets PLATFORM in the request or role claims to bypass scope.

### 6. Tests Required

`AdminRoleListIntegrationTest` verifies global listing beyond 20 records,
DISABLED visibility, soft-delete exclusion, Owner fields, tenant isolation,
forged PLATFORM/foreign-tenant rejection, and the permission gate. It also
asserts that the original runtime query continues to exclude disabled roles.
Use JDK 21 with Docker available for the MySQL Testcontainers tests.

### 7. Wrong vs Correct

Wrong: remove ACTIVE filtering from the shared runtime `listByScope`, or treat
PLATFORM management as `.eq(scope_type, 'PLATFORM').eq(scope_id, 'PLATFORM')`.

Correct: after platform/tenant authorization, use the separate management query;
retain ACTIVE filtering in existing runtime queries and soft-delete filtering
in both paths.

## Admin member listing

### 1. Scope / Trigger

Member management uses explicit scope queries; a platform view aggregates membership
relationships across tenants, rather than interpreting the platform management tenant as all tenants.

### 2. Signatures

- API: `GET /api/v1/admin/members?scope_type=PLATFORM&scope_id=PLATFORM`
- Canonical tenant query: `scope_type=TENANT&scope_id=<tenant_id>`.
- Service: `TenantMemberQueryService.search` validates scope and filtering before data access.
- SQL: `TenantMemberQueryMapper.search/count` share the same filter fragment.

### 3. Contracts

Require both exact-case scope fields. Reject `tenant_id` (alone or mixed), rather than mapping old
requests or inferring a global default. Preserve `keyword`, `owner_candidates`, `limit` (1..1000,
default 1000), and stable `gateway_membership.id ASC` ordering. Status uses one comma-separated
parameter: `membership_status=ACTIVE,PENDING`; supported values are ACTIVE, PENDING, SUSPENDED.
Blank/malformed lists are invalid; `status` is rejected as an unsupported alias.

Apply scope, literal keyword search, status and owner-candidate filtering before COUNT and LIMIT.
Join only non-deleted tenants; retain all membership/user statuses by default and soft-delete
filtering. Rows represent memberships (a user may appear in multiple tenants), each with real
`tenant_id`, `tenant_name`, `tenant_type`. Project user/roles in batches. Owner identity/eligibility
must use each row's tenant owner. PLATFORM omits singleton top-level tenant metadata; TENANT retains
`tenant_type` and adds `tenant_name`. `count` is returned length, `total` is pre-limit matched length,
and `truncated = total > count`. There is no OFFSET/page/size pagination.

### 4. Validation & Error Matrix

| Condition | Result |
| --- | --- |
| Missing/invalid Bearer | 401 |
| Missing `iam:member:read` | 403 |
| PLATFORM without real platform membership role | 403, before queries |
| Non-platform member targets foreign TENANT | 403, before tenant existence lookup |
| Authorized missing/deleted TENANT | 404 (existing member-list behavior) |
| Missing/invalid tuple, legacy tenant_id, status alias, invalid status/limit | 400 |

### 5. Good/Base/Bad Cases

- Good: PLATFORM search returns members from multiple tenants with per-row tenant and Owner attribution.
- Base: TENANT read keeps unavailable users as relationships, with optional user fields omitted.
- Bad: claims named PlatformAdmin alone bypass the real membership role check.

### 6. Tests Required

`AdminMemberScopeContractTest` covers actual controller binding, service/guard authorization order,
legacy/malformed requests, status handoff to COUNT/search, multi-tenant projection and generated mapper SQL.
`TenantMemberSearchIntegrationTest` covers MySQL filtering-before-limit, literal keyword matching,
per-tenant owner candidates, status filtering and aggregation; it requires Docker/Testcontainers.
Other endpoint contracts (`join-requests`, `tenant-status`, write members) keep their existing `tenant_id`.

### 7. Wrong vs Correct

Wrong: filter candidates/status after LIMIT, use one tenant's Owner globally, or infer global scope from
missing parameters. Correct: validate/authorize first, use shared SQL predicates for count/search,
and project owners using each membership's tenant.

## Admin audit time filtering

1. **Scope**: only `GET /api/v1/admin/audit` time parameters change.
2. **Signatures**: optional string `start_time` / `end_time` are parsed by
   `AdminAuditService.AuditSearchCriteria` into UTC `LocalDateTime` in `AuditLogFilter`.
3. **Contract**: prefer ISO-8601 `Z` timestamps; explicit offsets represent equivalent
   instants. Normalize once to UTC for `gateway_audit_log.create_time` (`DATETIME`, UTC
   wall-clock convention). SQL remains `>= start` and `< end`, with either bound absent
   or blank independently. Legacy `YYYY-MM-DD` is Shanghai midnight, advancing only the
   date-only end by one calendar day; unzoned ISO timestamps remain Shanghai wall time.
   The browser converts local calendar midnights to UTC; encode offset `+` as `%2B`.
4. **Errors**: malformed/conversion-overflow values return HTTP 400 `IAM-VALID-010`;
   equal/reversed normalized bounds return HTTP 400 `IAM-VALID-002`. Keep the standard
   failure envelope and existing permission, tenant/filter, pagination and ordering behavior.
5. **Cases**: `2026-11-03T16:00:00Z` to `2026-11-04T16:00:00Z` selects Shanghai November 4;
   legacy `2026-11-04` to `2026-11-04` selects the same day. Equivalent start/end instants
   with different offsets form an invalid zero-length window.
6. **Tests**: focused `AdminAuditTimeContractTest` verifies parsing, offsets, compatibility,
   optional/blank bounds and errors without Docker. `AdminAuditQueryIntegrationTest`
   verifies actual start-included/end-excluded rows and existing query regressions with
   MySQL Testcontainers. A blocked Docker run is not a passed integration check.
7. **Wrong vs correct**: never strip `Z`, reinterpret UTC as Shanghai, add an offset twice
   or advance timestamp ends by a day. Normalize offset-bearing inputs directly to UTC;
   only legacy date-only ends advance locally. Global timezone setup and historical-row
   migration remain outside this endpoint change.

## Role management enrichment, filters and generated codes

### 1. Scope / Trigger
Role management list filters are independent from the authorization scope tuple.
Creation supports clients that omit role_code.

### 2. Signatures
GET /api/v1/admin/roles retains scope_type/scope_id and adds filter_scope_type,
filter_scope_id and keyword. POST on the same path accepts optional role_code.

### 3. Contracts
Retain PLATFORM authorization as a global management view; never reinterpret it
as a PLATFORM-only row filter. filter_scope_type is one comma-separated uppercase
PLATFORM/TENANT list, trimmed and deduplicated with OR semantics. filter_scope_id
is a tenant ID; blank means no filter. keyword is trimmed literal substring search
on role_name OR role_description; escape LIKE metacharacters using bound parameters
and an explicit escape character. Dimensions AND with the authorized query.
Preserve unpaginated id ASC ordering, DISABLED visibility, logical-delete exclusion
and {roles,count}. Do not change the ACTIVE-only runtime role query.
Resolve tenant_name only for nonblank TENANT scope IDs, deduplicated into a batch
TenantRepository.findByIds query. Missing/deleted tenants and non-tenant roles have
no name; global NON_NULL serialization can omit unavailable tenant_name.
POST omitted/null/blank role_code generates role_<32-hex UUID> with existing
IdGenerator. Explicit codes remain accepted and trimmed. Keep {role_id} response
and PUT role_code immutability. Creation audit must use actual persisted code
and normalized scope, never the nullable request code.

### 4. Validation & Error Matrix
- Missing Bearer: 401; missing role permission or unauthorized scope: 403.
- Supplied empty/unknown/malformed filter_scope_type: 400.
- Empty keyword/tenant filter: no additional constraint.
- Contradictory type/tenant filter or foreign filter inside a tenant scope: empty
  result; filters never grant access to foreign rows.
- Missing role_name remains 400; update role_code remains 400.

### 5. Good/Base/Bad Cases
Good: platform authorization plus TENANT filter and a tenant ID returns that
tenant's matching roles. Base: old PLATFORM requests retain global visibility.
Bad: applying keyword OR outside the scope predicate leaks foreign role rows.

### 6. Tests Required
Controller binding/envelopes, CSV validation, scope-before-data-access, filter
intersection, literal wildcard search, batch tenant lookup, missing-name behavior,
generated/explicit codes and persisted-code audit. MySQL integration regressions
must retain management/runtime separation and global lists beyond 20 records.

### 7. Wrong vs Correct
Wrong: use incoming role_code in Map.of during audit after allowing it to be null;
replace authorization scope with selected filter types; query tenants per role.
Correct: generate before persistence/audit, AND filters with authorization and
batch-enrich only the authorized result list.

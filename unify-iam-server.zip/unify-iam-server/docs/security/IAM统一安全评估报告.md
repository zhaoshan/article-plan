
> 整改进展跟踪：见同目录 `IAM安全问题整改台账.md`（状态以台账为准；本报告问题定义/证据保持原样）。

### IAM 后端

#### 开发登录与账号恢复

##### P0-07　IAM 默认启用开发 Token，并存在默认基础设施凭据

- **应用／功能**：IAM 后端；开发辅助登录／基础设施凭据。
- **优先级／验证状态**：P0；本地行为已复现。
- **接口／入口**：`POST /api/v1/auth/dev-token；默认数据库/版本服务配置为非 HTTP 配置面`。
- **静态定位**：`platform-iam-service`，`iam-app/src/main/resources/application.yml`、`DevTokenService.java`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/DevTokenService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/DevTokenService.java>)。
- **原因**：默认配置开启开发 Token；默认配置还包含数据库、版本服务等可预测凭据。
- **动态证据**：D3 匿名提交 username=platform_admin 得到 access_token 与 refresh_token，返回 PlatformAdmin 权限；D2 对应 F-03。未验证任何生产环境，也未使用报告中的默认基础设施凭据连接外部服务。
- **评审判断**：无密码签发在本地已确认；开发端点显式开关属于生产误配置风险。不能推断生产已开启；默认基础设施凭据是本项中仅由静态报告支持的子问题。
- **整改状态（2026-11-09 已整改）**：① `IamProperties.devTokenEnabled` 代码默认值 `true→false`，`application.yml` 同步 `dev-token-enabled: false`——生产未显式开启即拒绝（403 DEV_TOKEN_DISABLED）；② 开启时启动日志输出醒目 WARN（`DevTokenService.warnIfEnabled`），运维误配置可即时发现；③ 数据库密码默认值 `root123456` 移除（`${SPRING_DATASOURCE_PASSWORD:}` 空默认）——缺凭据即连库失败拒绝启动，强制环境注入；④ versions `service-token` 可预测默认值 `ae72...` 移除，强制 `IAM_VERSIONS_SERVICE_TOKEN` 注入。本地/测试通过 `IamIntegrationTestBase` 显式开启/注入保持可用。
- **潜在或已验证影响**：部署时若未覆盖配置，可能绕过密码直接取得用户 Token，或访问内部服务。
- **修复建议**：生产环境禁用并最好移除端点；所有数据库、服务 Token、JWT 密钥改为强制环境注入；启动时拒绝开发配置。
- **验收要点**：生产端点不存在或明确拒绝；开发 profile 不可部署到生产；缺少正式基础设施凭据拒绝启动；已暴露凭据完成轮换并留记录，不能只删除源码默认值。
- **来源对应**：S1 P0-07；D2 F-03。

##### P0-08　忘记密码接口直接返回重置 Token

- **应用／功能**：IAM 后端；账号恢复／忘记密码。
- **优先级／验证状态**：P0；本地行为已复现。
- **接口／入口**：`POST /api/v1/auth/forgot-password → POST /api/v1/auth/reset-password → POST /api/v1/auth/token`。
- **静态定位**：`platform-iam-service`，`PasswordResetService.java`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/PasswordResetService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/PasswordResetService.java>)。
- **原因**：代码注释说明生产不返回 Token，但方法当前始终返回生成的 Token。
- **动态证据**：D4：forgot-existing-b 返回 data.token；anonymous-reset-own-b=200；old-password-after-reset=401；new-password-after-reset=200；reset-token-reuse=401。只改动本轮创建的 b 测试账号，后续恢复原密码。
- **评审判断**：已有匿名获取恢复凭据并完成测试账号接管的证据。静态报告指出 return Map.of("token", plain) 无环境判断，不能只归类为 local 配置问题。未知邮箱返回 data.detail，与已知邮箱结构不同；相同 200 状态并不构成有效防枚举。
- **整改状态（2026-11-09 已整改）**：① forgot 响应改为 `{"status":"SENT"}` 统一形态，已知/未知邮箱完全同构（原 detail 差异消除）；② token 仅在 SMTP 未配置（日志模式，`EmailTool.isMailConfigured()=false`，dev 闭环便利）时附加返回——生产配置 SMTP 后 token 只经邮件交付，响应绝不暴露（`PasswordResetService.forgot`）；③ 新增同邮箱 60s 冷却限流（重复提交 400 `IAM-AUTH-011`）；④ 旧 token 即时失效（`invalidateByEmail`，原有）与重置后撤销全部 refresh（原有）保持不变。回归测试：`PasswordResetMailIntegrationTest` 新增 3 用例（配置模式不返 token / 未知邮箱同形态 / 冷却限流）。
- **潜在或已验证影响**：知道具有本地密码身份的邮箱即可申请并直接读取重置 Token，完成密码重设；响应结构差异还可辅助邮箱枚举。生产是否对外可达须另核实，但代码本身未证明存在生产保护分支。
- **修复建议**：生产只返回统一提示；Token 只通过邮件/短信发送；增加邮箱、IP 和设备维度限流；旧 Token 必须立即失效。
- **验收要点**：已知/未知邮箱返回等价公共提示且不含 Token；仅通过受验证渠道交付；单次使用、过期、旧 Token 作废保持有效；恢复后按策略撤销旧会话，限流和日志脱敏可验证。
- **来源对应**：S1 P0-08；D2 F-01。

#### 登录策略与密码生命周期

##### P1-01　密码传输与日志保护需要核实（Base64 不提供保密性）

- **应用／功能**：IAM 后端；密码登录／前后端传输与日志。
- **优先级／验证状态**：P1；静态待验证。
- **接口／入口**：`POST /api/v1/auth/token；关联 platform-iam-web/packages/auth-kit`。
- **静态定位**：`platform-iam-service` 的 `PasswordCodecs.java`；`platform-iam-web/packages/auth-kit/src/index.ts`。
- **文件定位链接**：[platform-iam-service/iam-common/src/main/java/com/unify/iam/common/util/PasswordCodecs.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-common/src/main/java/com/unify/iam/common/util/PasswordCodecs.java>)；[platform-iam-web/packages/auth-kit/src/index.ts](</Users/orechou/Workspace/project/iMorpy/platform-iam-web/packages/auth-kit/src/index.ts>)。
- **原因**：密码在请求体中仅做 Base64 编码，Base64 可以直接还原原文。
- **动态证据**：没有针对本项的专项动态证据；仅凭基础路由矩阵不能确认完整利用。
- **评审判断**：这是 HTTPS、HSTS 和日志保护的条件性核查项。Base64 编码本身不等于独立漏洞，不能要求无依据的前端自制加密。动态测试使用本地 HTTP，不能推断生产未加密传输。
- **潜在或已验证影响**：Base64 本身不是独立漏洞；若传输未强制 HTTPS，或代理/链路追踪记录请求体，密码可被直接还原。
- **修复建议**：强制 HTTPS 和 HSTS；禁止网关、日志、链路追踪记录密码字段；不要把 Base64 当作安全措施。
- **验收要点**：生产全链路 HTTPS，适用域名 HSTS；网关/应用/链路追踪不记录密码或可还原编码；敏感字段脱敏失败时不输出原文。
- **来源对应**：S1 P1-01。

##### P1-02　登录接口未发现暴力破解防护

- **应用／功能**：IAM 后端；登录安全／限流和撞库防护。
- **优先级／验证状态**：P1；静态待验证。
- **接口／入口**：`POST /api/v1/auth/token`。
- **静态定位**：`platform-iam-service`，`IdentityVerificationService.java`。
- **文件定位链接**：[platform-iam-service/iam-identity/src/main/java/com/unify/iam/identity/app/service/IdentityVerificationService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-identity/src/main/java/com/unify/iam/identity/app/service/IdentityVerificationService.java>)。
- **原因**：静态代码中未发现账号/IP 级失败次数限制、冷却、验证码或风险控制。
- **动态证据**：D4 仅有 3 次受限的错误密码请求，均 401。该数量不足以认定不存在限流，本轮未爆破/压测，也未核验生产网关防护。
- **评审判断**：静态未见应用防护，需要同时核查网关配置、账号/IP 组合策略及告警。保留 P1 排查优先级，不写成已完成暴力破解。
- **潜在或已验证影响**：可进行密码爆破和撞库。
- **修复建议**：增加账号 + IP 组合限流、失败冷却、风险验证码、异常登录告警和撞库密码检测。
- **验收要点**：隔离环境按约定阈值出现 429/冷却且不会误封正常用户；覆盖分布式计数、账号/IP 组合和恢复窗口；异常事件可查审计/告警。
- **来源对应**：S1 P1-02。

##### P1-03　注册、重置与改密缺少统一后端密码策略

- **应用／功能**：IAM 后端；密码设置／注册、重置、自助改密。
- **优先级／验证状态**：P1；静态待验证。
- **接口／入口**：`POST /api/v1/auth/register；POST /api/v1/auth/reset-password；POST /api/v1/auth/change-password；对照 POST /api/v1/admin/users/{userId}/reset-password`。
- **静态定位**：`platform-iam-service`，`RegisterRequest.java`、`ResetPasswordRequest.java`、`ChangePasswordRequest.java`、`RegisterService.java`、`PasswordResetService.java`、`ChangePasswordService.java`。
- **文件定位链接**：[platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/auth/RegisterRequest.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/auth/RegisterRequest.java>)；[platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/auth/ResetPasswordRequest.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/auth/ResetPasswordRequest.java>)；[platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/auth/ChangePasswordRequest.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/auth/ChangePasswordRequest.java>)；[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/RegisterService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/RegisterService.java>)；[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/PasswordResetService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/PasswordResetService.java>)；[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/ChangePasswordService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/ChangePasswordService.java>)。
- **原因**：前三个设置新密码的链路未发现统一最短长度及 BCrypt 字节上限校验；管理员重置密码已有 72 字节上限，策略不一致。
- **动态证据**：没有针对本项的专项动态证据；仅凭基础路由矩阵不能确认完整利用。
- **评审判断**：静态指出后端策略不一致。测试账号使用强密码，没有验证短密码或超长密码是否被接受。具体策略需评审明确，并与当前 BCrypt 实现的 UTF-8 字节边界一致。
- **潜在或已验证影响**：攻击者可以直接调用 API 提交弱密码；超长密码还可能受到 BCrypt 72 字节限制。
- **修复建议**：后端统一限制 UTF-8 字节长度，例如 8 至 72 字节；统一注册、重置、改密和管理员改密策略。
- **验收要点**：四条设置密码链路执行同一服务端策略；边界长度、中文/多字节、超长输入和弱密码测试有明确结果；不依赖前端校验，不静默截断。
- **来源对应**：S1 P1-03。

##### P1-15　IAM 自助改密未撤销其他会话

- **应用／功能**：IAM 后端；账号安全／改密后会话撤销。
- **优先级／验证状态**：P1；本地行为已复现。
- **接口／入口**：`POST /api/v1/auth/change-password；关联 POST /api/v1/auth/refresh 与 GET /api/v1/auth/me`。
- **静态定位**：`platform-iam-service`，`ChangePasswordService.java:25-35`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/ChangePasswordService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/ChangePasswordService.java>)。
- **原因**：改密后只更新 BCrypt 哈希，没有撤销现有 refresh token，也没有提高成员 Token 版本；与管理员重置密码和忘记密码重置的行为不一致。
- **动态证据**：D4：change-password-own-a=200 后，改密前 refresh 在 refresh-after-password-change 仍 200，旧 access 在 access-after-password-change 仍 200。D2 原 O-01 与静态 P1-15 合并，不重复计数。
- **评审判断**：静态实现明确选择“自助改密不吊销会话”。这是已复现的会话策略风险，需评审决定是否保留当前会话、是否撤销其他会话。旧 access 退出后暂时有效也不单独判成绕过，须结合承诺的失效时限。
- **潜在或已验证影响**：密码泄露后用户改密，已被窃取的 refresh token 仍可能续签会话。
- **修复建议**：改密后撤销该用户其他 refresh token 并 bump 全部成员版本；当前会话可重新签发保留。
- **验收要点**：确定并文档化改密失效策略；至少模拟另一设备被盗 refresh，改密后不得续签；当前合法设备按批准方案重新签发；access/成员版本与管理面校验策略一致。
- **来源对应**：S1 P1-15；D2 O-01。

#### Token 验证、轮换和管理授权

##### P1-05　JWT 验证缺少 issuer/audience 等校验

- **应用／功能**：IAM 后端；JWT 验证／IAM 自身 Bearer 认证。
- **优先级／验证状态**：P1；本地行为已复现。
- **接口／入口**：`GET /api/v1/auth/me（动态验证入口）；复用 JwtSigner.verify 的其他受保护入口`。
- **静态定位**：`platform-iam-service`，`JwtSigner.java`。 `iam-app/src/main/java/com/unify/iam/app/security/JwtSigner.java:76-92`，供 IAM 自身 Bearer 验证复用。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/JwtSigner.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/JwtSigner.java>)。
- **原因**：当前主要验证签名和 `exp`，未严格校验 `iss`、`aud`、`nbf`、`iat`。
- **动态证据**：D4：用隔离实例自己的测试私钥重新签名后，错误 iss、错误 aud、未来 nbf/iat、未知/路径样式 kid 均 200。正确签名的过期/无 exp、错误签名、alg=none、RSA/HMAC 混淆均 401。
- **评审判断**：确认 claims 验证缺口，利用需具有可信签名条件，如密钥复用或其他签发链。未证明无私钥伪造 JWT、算法绕过、文件读取或路径穿越；路径样式 kid 被接受只说明 kid 约束不足。
- **潜在或已验证影响**：密钥复用或配置错误时，可能接受面向其他系统签发的 Token。
- **修复建议**：严格校验 `alg`、`kid`、issuer、audience 和完整时间窗口；对旧 Token 兼容逻辑设置明确期限。
- **验收要点**：保留合法 Token 正向对照；错误 iss/aud、未生效/异常未来时间、非允许算法和未知 kid 被拒绝；所有负向用例与签名错误区分，按业务定义允许时钟偏差及兼容期限。
- **来源对应**：S1 P1-05；D2 F-04。

##### P1-D01　refresh Token 并发轮换可同时成功多次

- **应用／功能**：IAM 后端；登录会话／refresh 轮换与重放。
- **优先级／验证状态**：P1；本地行为已复现。
- **接口／入口**：`POST /api/v1/auth/refresh`。
- **静态定位**：`platform-iam-service`，`iam-app/src/main/java/com/unify/iam/app/app/service/RefreshTokenService.java:55-66`；`iam-app/src/main/java/com/unify/iam/app/infra/persistence/repository/RefreshTokenRepository.java`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/RefreshTokenService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/RefreshTokenService.java>)；[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/infra/persistence/repository/RefreshTokenRepository.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/infra/persistence/repository/RefreshTokenRepository.java>)。
- **原因**：先查询 active refresh，再撤销旧值并签发新值，旧值的单次消费未由原子条件更新保障。
- **动态证据**：D4 的 concurrent-refresh-0/1/2 对同一 refresh 同步发出，3 个请求均 200、success=true；串行 refresh-replay-old=401，refresh-after-logout=401。D2 对应 F-05。仅 3 路隔离账号验证，不是压力测试。
- **评审判断**：新增动态发现，与 JWT claims 缺失、改密未吊销分别计数。串行重放防护有效，问题是轮换的并发原子性。
- **潜在或已验证影响**：持有同一有效 refresh Token 的并发请求可能换出多个有效新会话，削弱单次轮换与重放检测。
- **修复建议**：复用现有持久化层，以条件更新/必要事务保证同一 Token 只有一个消费者成功；只有确认撤销旧值成功才签发新值；明确 token family 与重放处置策略。
- **验收要点**：同一有效 refresh 并发消费最多一次成功，其余拒绝；并发、串行重放、注销后重放和异常事务回滚均验证；合法单次刷新完整返回新会话。
- **来源对应**：D4 并发 refresh 用例；D2 F-05。

##### P1-16　IAM 管理面依赖 JWT 内的旧权限快照

- **应用／功能**：IAM 后端；平台管理／权限撤销和成员状态。
- **优先级／验证状态**：P1；静态待验证。
- **接口／入口**：`/api/v1/admin/**`。
- **静态定位**：`platform-iam-service`，`ManagementAuthorizationInterceptor.java:36-42`、`JwtSigner.java:76-92`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/ManagementAuthorizationInterceptor.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/ManagementAuthorizationInterceptor.java>)；[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/JwtSigner.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/security/JwtSigner.java>)。
- **原因**：拦截器只比对已签名 JWT 内的 `permissions`，没有检查当前成员状态和 `token_version`。角色撤销、成员停用或密码重置后，旧 JWT 在有效期内可能仍被 IAM 自身接受。
- **动态证据**：D4 中普通账号访问 admin users/tenants/roles 得到 403，证明基础权限拒绝有效；没有在撤权/停用后重放旧高权限 JWT 的专项用例。不能据此确认或排除此项。
- **评审判断**：静态发现管理面只依赖旧权限快照的风险。与 P1-05 的 Token 校验、P1-15 的版本/撤销联动，但三个根因分别保留。
- **潜在或已验证影响**：权限变更和账号停用无法在 IAM 管理面即时生效，最长受 access token 有效期影响；下游版本 feed 不能代替 IAM 自身校验。
- **修复建议**：管理面每次验证当前成员状态和版本，或使用短 TTL、可失效缓存；对高危写操作实时查验。
- **验收要点**：撤销角色、停用成员/租户、重置密码后，在约定失效窗口内旧 JWT 管理读写均拒绝；高危写实时核验；合法新 Token 仍可访问。
- **来源对应**：S1 P1-16。

##### P2-10　角色权限读取缺少租户归属校验

- **应用／功能**：IAM 后端；租户角色／权限读取的对象授权。
- **优先级／验证状态**：P2；静态待验证。
- **接口／入口**：`GET /api/v1/admin/roles/{roleId}/permissions`。
- **静态定位**：`platform-iam-service`，`AdminRoleController.java:98-103`、`AdminRoleService.java:156-159`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminRoleController.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminRoleController.java>)；[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminRoleService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminRoleService.java>)。
- **原因**：只要求 `IAM_ROLE_READ`，服务层按角色 ID 直接查询权限，没有执行同类角色接口使用的租户作用域校验。
- **动态证据**：没有针对本项的专项动态证据；仅凭基础路由矩阵不能确认完整利用。
- **评审判断**：静态指向缺少 assertRoleScope 的对象权限读取链。动态未创建两租户角色专项替换 roleId；普通用户 admin 403 不能替代具有 IAM_ROLE_READ 的租户用户跨域验证。保留来源 P2，实际敏感度和暴露范围可在评审时重新定级。
- **潜在或已验证影响**：持有任一租户角色读取权限的用户，若知道其他租户角色 ID，可读取其权限配置。
- **修复建议**：在查询前加载角色并调用统一 `assertRoleScope`；补充跨租户拒绝测试。
- **验收要点**：有 IAM_ROLE_READ 的租户 A 用户可读 A 角色，读 B 角色返回 403/404 且无权限数据；平台管理员访问按批准范围工作。
- **来源对应**：S1 P2-10。

#### SSO、身份源密钥与登录发现

##### P1-04　OIDC 回调通过 URL 传递 access/refresh Token

- **应用／功能**：IAM 后端；企业 SSO／OIDC 回调与前端登录落地。
- **优先级／验证状态**：P1；静态待验证。
- **接口／入口**：`GET /api/v1/auth/oidc/callback；影响两个前端的回跳和 Token 接收逻辑`。
- **静态定位**：`platform-iam-service`，`OidcController.java`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/OidcController.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/OidcController.java>)。
- **原因**：重定向 Query 参数包含 access token 和 refresh token。
- **动态证据**：D4：无效 state=401、缺失 state=400、未配置 IdP 的 authorize=404；没有本地 IdP，未完成成功回调。resolve-target 的正常和异常 return_to 均因主页地址缺失返回 503。
- **评审判断**：Token 进入回跳 Query 的结论来自静态代码；动态未验证成功回跳泄露，也不能用配置错误响应认定不存在开放重定向。改造需同步两个前端接收方式。
- **潜在或已验证影响**：Token 可能进入浏览器历史、代理日志、Referer、监控和 Web 服务器日志。
- **修复建议**：使用一次性授权码交换；或改用 HttpOnly、Secure、SameSite Cookie；禁止 refresh token 出现在 URL。
- **验收要点**：成功登录的 URL、Location、历史和日志均不含 access/refresh Token；一次性码或会话交付防重放并绑定回跳地址/客户端；state/nonce/回跳白名单正反例通过。
- **来源对应**：S1 P1-04。

##### P1-06　IdP `client_secret` 明文落库

- **应用／功能**：IAM 后端；企业身份源管理／IdP Secret 存储。
- **优先级／验证状态**：P1；静态待验证。
- **接口／入口**：`POST /api/v1/admin/idp-configs；PUT /api/v1/admin/idp-configs/{configId}`。
- **静态定位**：`platform-iam-service`，`IdpConfigRequest.java` 及 IdP 配置服务。
- **文件定位链接**：[platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/admin/IdpConfigRequest.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-api/src/main/java/com/unify/iam/api/dto/admin/IdpConfigRequest.java>)。
- **原因**：`AdminIdpService.applyConfigFields()` 直接将请求的明文 `client_secret` 写入名为 `client_secret_cipher` 的字段，没有加密步骤。
- **动态证据**：没有针对本项的专项动态证据；仅凭基础路由矩阵不能确认完整利用。
- **评审判断**：静态字段赋值显示明文写入名为 cipher 的字段；本次未读取生产数据库/备份或验证数据库透明加密。需区分应用未加密与底层存储保护，审查 Secret 读取接口。
- **潜在或已验证影响**：数据库、备份或管理接口泄露后可接管企业 SSO。
- **修复建议**：使用 KMS/Secret Manager 加密；查询接口只返回脱敏状态；迁移并轮换历史密钥。
- **验收要点**：数据库/备份中只有密文或 Secret 引用；只有受授权组件可解密；管理响应不返回原 Secret；历史记录迁移并轮换后，SSO 联调成功。
- **来源对应**：S1 P1-06。

##### P2-05　匿名 SSO 租户目录可能披露组织信息

- **应用／功能**：IAM 后端；登录发现／SSO 租户选择。
- **优先级／验证状态**：P2；部分动态验证。
- **接口／入口**：`GET /api/v1/auth/sso/tenants`。
- **静态定位**：`platform-iam-service`，`AuthController.java` 的 `/sso/tenants`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AuthController.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/AuthController.java>)。
- **原因**：接口允许匿名列出已配置 SSO 的租户名称、编码和数量。
- **动态证据**：D5 和 D6 匿名请求返回 200、success=true、count=0、tenants=[]；本地没有可展示的 SSO 租户，未观察到真实组织名称/编码泄露。
- **评审判断**：确认匿名入口存在，数据披露风险来自静态返回字段。是否匿名展示组织目录是产品策略，需以存在 IdP 的隔离样本评审最小字段。
- **潜在或已验证影响**：暴露租户名称、编码和数量，可辅助组织枚举和定向攻击。
- **修复建议**：确认是否必须匿名返回；必要时改为模糊提示或仅返回经过业务授权的租户。
- **验收要点**：确定匿名发现契约；匿名返回字段最小化；有 SSO 测试租户时验证名称/编码展示符合策略，禁止由错误响应扩大组织枚举。
- **来源对应**：S1 P2-05。

##### P2-09　OIDC 临时登录状态只存内存且缺少创建限额

- **应用／功能**：IAM 后端；企业 SSO／OIDC 临时授权状态。
- **优先级／验证状态**：P2；静态待验证。
- **接口／入口**：`GET /api/v1/auth/oidc/authorize；GET /api/v1/auth/oidc/callback`。
- **静态定位**：`platform-iam-service`，`OidcAuthSessionStore.java:16-30`、`OidcController.java:35-39`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/oidc/OidcAuthSessionStore.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/oidc/OidcAuthSessionStore.java>)；[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/OidcController.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/OidcController.java>)。
- **原因**：匿名请求每次创建一条内存状态；过期清理只在回调 `take()` 时执行，没有定时清理或创建限流。
- **动态证据**：无本地 IdP，authorize 未进入完整授权创建链；本轮没有请求洪泛、内存耗尽或多副本回调测试。
- **评审判断**：内存状态缺少上限、清理触发和跨实例一致性来自静态分析；未量化可耗尽规模。
- **潜在或已验证影响**：大量未完成的授权请求可能持续占用内存；多实例部署时回调落到另一实例还会失败。
- **修复建议**：改用带 TTL 和容量上限的 Redis/缓存，增加 IP/租户级限流。
- **验收要点**：状态有硬 TTL 和容量/创建速率上限；未完成登录也会回收；状态单次消费且跨副本可读；缺少依赖时安全失败，不无限堆积。
- **来源对应**：S1 P2-09。

#### 邀请和身份日志保护

##### P1-14　IAM 访问日志记录路径中的邀请 Token

- **应用／功能**：IAM 后端；成员邀请／访问日志。
- **优先级／验证状态**：P1；静态待验证。
- **接口／入口**：`POST /api/v1/auth/invitations/{token}/accept`。
- **静态定位**：`platform-iam-service`，`LoginUiController.java:90-96`、`AccessLogFilter.java:57-59,81-94`。
- **文件定位链接**：[platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/LoginUiController.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-app/src/main/java/com/unify/iam/app/adapter/controller/LoginUiController.java>)。
- **原因**：访问日志只隐藏 Query 参数值，直接记录完整 URI 路径；邀请 Token 位于路径参数中。
- **动态证据**：没有针对本项的专项动态证据；仅凭基础路由矩阵不能确认完整利用。
- **评审判断**：邀请 Token 落日志由静态代码支持；接受邀请仍需要与受邀邮箱匹配的登录态，不把单独日志泄露描述成无需身份接受邀请。
- **潜在或已验证影响**：邀请凭据会进入应用日志和日志平台；接受邀请仍要求与受邀邮箱匹配的登录态，但日志泄露扩大了凭据暴露面。
- **修复建议**：记录路由模板而非原始路径；对 Token、重置码等路径参数统一打码；缩短日志保留时间并清理历史敏感日志。
- **验收要点**：应用/网关/追踪日志记录路由模板或打码路径；含邀请 Token 的请求各状态均不留原值；既有敏感日志按访问和保留策略处置。
- **来源对应**：S1 P1-14。

##### P2-07　登录失败日志记录完整用户名

- **应用／功能**：IAM 后端；登录失败／用户名日志。
- **优先级／验证状态**：P2；静态待验证。
- **接口／入口**：`非独立入口；POST /api/v1/auth/token 触发 IdentityVerificationService 失败日志`。
- **静态定位**：`platform-iam-service`，`IdentityVerificationService.java`。 `iam-identity/src/main/java/com/unify/iam/identity/app/service/IdentityVerificationService.java:29-32`，由登录接口调用。
- **文件定位链接**：[platform-iam-service/iam-identity/src/main/java/com/unify/iam/identity/app/service/IdentityVerificationService.java](</Users/orechou/Workspace/project/iMorpy/platform-iam-service/iam-identity/src/main/java/com/unify/iam/identity/app/service/IdentityVerificationService.java>)。
- **原因**：认证失败日志直接输出未经脱敏的用户名或邮箱。
- **动态证据**：没有针对本项的专项动态证据；仅凭基础路由矩阵不能确认完整利用。
- **评审判断**：失败登录日志中个人标识暴露由静态报告支持；没有将真实用户登录失败日志纳入本次动态证据。
- **潜在或已验证影响**：日志泄露邮箱或用户名，可辅助账号枚举。
- **修复建议**：邮箱脱敏；限制认证日志访问范围；禁止记录密码和请求体。
- **验收要点**：使用合成邮箱失败登录，日志只留脱敏标识或不可逆关联值；密码与请求体不输出，保留可用审计信息。
- **来源对应**：S1 P2-07。

##### P2-11　IAM 脱敏日志在 JSON 解析失败时回退输出原文

- **应用／功能**：IAM 后端；邮箱验证／畸形 JSON 日志脱敏。
- **优先级／验证状态**：P2；静态待验证。
- **接口／入口**：`POST /api/v1/auth/email-verification-codes；POST /api/v1/auth/email-verification-codes/verify；当前 @LogPayload 路径`。
- **静态定位**：`platform-iam-service`，`LogMasks.java:67-78`、`AccessLogFilter.java:64-78`。
- **原因**：JSON 解析失败时返回原始请求体前 512 字符；恶意或畸形请求可在其中夹带密码/令牌样式内容，绕过按字段名脱敏。
- **动态证据**：没有针对本项的专项动态证据；仅凭基础路由矩阵不能确认完整利用。
- **评审判断**：JSON 解析失败回退输出前 512 字符由静态代码支持；本次未主动向日志投放畸形敏感文本。字段级脱敏不能覆盖原文回退。
- **潜在或已验证影响**：敏感文本可能写入访问日志；当前只有少数白名单接口受影响，但未来复用会扩大范围。
- **修复建议**：解析失败时只记录固定错误标记和长度，绝不回退记录原文；增加畸形 JSON 的脱敏测试。
- **验收要点**：合成密码/Token 标记放入畸形 JSON，应用/网关日志不出现原文；仅记录固定解析失败信息、长度和请求标识；正常 JSON 仍正确脱敏。
- **来源对应**：S1 P2-11。

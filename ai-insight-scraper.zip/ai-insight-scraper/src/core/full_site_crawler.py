"""FullSiteCrawler — 全量链接树爬取编排器

负责将一个站点的全量爬取流程编排为有序步骤：

  1. 创建主任务（task_type="full_site"），状态贯穿整个流程
  2. 解析域名，加载该站点的遍历规则和动态页面配置
  3. 调度 TreeCrawler（S3 模式）执行全量静态链接爬取
  4. 如果 dynamic_page_config.json 中有该站点的动态配置，
     遍历每个 page_type 调度 DynamicCrawler
  5. 调用 LinkTreeSyncer 将最终树结构同步到 crawl_link_tree 表
  6. 更新主任务状态为 completed 或 failed

子任务直接 await 协程（不通过 asyncio.create_task 后台跑），
从而同步获得子任务的输出文件路径。
"""

import asyncio
import logging
from datetime import datetime
from pathlib import Path

from src.boundaries.s3_boundary import S3Boundary
from src.config.dynamic_page_config import (
    load_dynamic_page_config,
    list_dynamic_page_types,
)
from src.config.traversal_config import load_traversal_config
from src.core.crawl_semaphore import CrawlSemaphoreGuard
from src.core.dynamic_crawler import DynamicCrawler
from src.core.link_tree_syncer import LinkTreeSyncer
from src.core.task_manager import DatabaseTaskManager
from src.core.tree_crawler import TreeCrawler
from src.database.repository import TaskRepository
from src.models.crawl_task import CrawlTask
from src.utils.url_utils import get_domain

logger = logging.getLogger(__name__)


class FullSiteCrawler:
    """全量链接树爬取编排器"""

    def __init__(
        self,
        headless: bool = True,
        max_depth: int | None = None,
        output_type: str = "s3",
    ):
        """
        Args:
            headless: 是否无头模式运行浏览器
            max_depth: 爬取深度，None=使用配置文件默认值
            output_type: 输出方式，"local" 或 "s3"；s3 模式需要完整 S3 配置
        """
        self.headless = headless
        self.max_depth = max_depth
        self.output_type = output_type
        self._task_manager = DatabaseTaskManager()
        self._repo = TaskRepository()
        self._s3_boundary: S3Boundary | None = None

        # S3 模式时要求配置必须完整
        if self.output_type == "s3":
            try:
                self._s3_boundary = S3Boundary()
            except ValueError as e:
                logger.error(f"S3 配置不完整: {e}")
                raise

    async def run(self, target_url: str, master_task: CrawlTask | None = None) -> dict:
        """执行全量爬取编排。

        Args:
            target_url: 站点首页 URL
            master_task: 已在路由层创建好的主任务；为 None 时在内部自动创建

        Returns:
            dict: 包含主任务 task_id、links_path、tree_path、stats
        """
        # ── 1. 解析域名 ───────────────────────────────────
        domain = get_domain(target_url)
        if not domain:
            raise ValueError(f"无法从 URL 解析域名: {target_url}")

        logger.info(f"开始全量爬取: target_url={target_url}, domain={domain}")

        # ── 2. 创建主任务（或使用路由层已创建的）────────────
        if master_task is not None:
            master = master_task
            logger.info(f"使用路由层已创建的主任务: {master.task_id}")
        else:
            master = self._task_manager.create_task(
                task_type="full_site",
                site=domain,
                target_url=target_url,
                max_depth=self.max_depth,
                headless=self.headless,
                output_type=self.output_type,
            )
            await self._repo.create(master)
            await self._repo.mark_running(master.task_id)

        links_path: str | None = None
        tree_path: str | None = None

        # 全局信号量限流：避免多任务同时启动 Chrome 进程耗尽性能
        async with CrawlSemaphoreGuard(master.task_id):
            try:
                # ── 3. 加载配置 ───────────────────────────────
                traversal_config = load_traversal_config(domain)
                dynamic_page_types = list_dynamic_page_types(domain)
                effective_depth = (
                    self.max_depth
                    if self.max_depth is not None
                    else traversal_config.drill_down_levels
                )
                logger.info(
                    f"配置加载完成: domain={domain}, "
                    f"drill_down_levels={traversal_config.drill_down_levels}, "
                    f"dynamic_page_types={dynamic_page_types}"
                )

                # ── 4. 调度 TreeCrawler ─────────────────────────
                logger.info("=== 步骤1: Tree 全量爬取 ===")
                tree_task = self._task_manager.create_task(
                    task_type="tree",
                    site=domain,
                    target_url=target_url,
                    max_depth=self.max_depth,
                    headless=self.headless,
                    output_type=self.output_type,
                    schedule_id=master.schedule_id,
                )
                await self._repo.create(tree_task)
                await self._repo.mark_running(tree_task.task_id)

                try:
                    crawler = TreeCrawler(
                        headless=self.headless,
                        output_dir="output",
                        log_dir="logs",
                        traversal_config=traversal_config,
                        s3_boundary=self._s3_boundary,
                        output_type=self.output_type,
                    )
                    tree_result = await crawler.crawl(
                        target_url, max_depth=self.max_depth
                    )
                    links_path = tree_result["links_path"]
                    tree_path = tree_result["tree_path"]
                    tree_stats = tree_result.get("stats", {})

                    # Tree 阶段未获取到任何页面数据，视为失败，不再执行后续阶段
                    if tree_stats.get("total_pages", 0) == 0:
                        raise RuntimeError(
                            "Tree 阶段未爬取到任何页面（首页可能无法打开或返回空内容）"
                        )

                    # Tree 阶段成功页面数不足，视为失败
                    min_pages = traversal_config.min_tree_pages_threshold
                    if tree_stats.get("total_pages", 0) < min_pages:
                        raise RuntimeError(
                            f"Tree 阶段成功页面数不足: "
                            f"{tree_stats.get('total_pages', 0)}，阈值 {min_pages}"
                        )

                    # Tree 阶段成功率过低，视为失败
                    min_success_rate = traversal_config.min_tree_success_rate
                    success_rate = tree_stats.get("success_rate", 0.0)
                    if success_rate < min_success_rate:
                        raise RuntimeError(
                            f"Tree 阶段成功率过低: {success_rate:.2%}，阈值 {min_success_rate:.2%}"
                        )

                    await self._repo.mark_completed(
                        task_id=tree_task.task_id,
                        links_path=links_path,
                        tree_path=tree_path,
                        pages_crawled=tree_stats.get("total_pages", 0),
                        links_found=tree_stats.get("total_links", 0),
                    )
                    logger.info(f"Tree 爬取完成: links={links_path}, tree={tree_path}")
                except Exception as e:
                    await self._repo.mark_failed(
                        tree_task.task_id, error_message=str(e)
                    )
                    raise

                # ── 5. 调度 DynamicCrawler（如有配置）─────────
                if dynamic_page_types:
                    logger.info(
                        f"=== 步骤2: Dynamic 增量爬取（{len(dynamic_page_types)} 种类型） ==="
                    )
                    for page_type in dynamic_page_types:
                        await self._run_dynamic_crawl(
                            domain, page_type, links_path, tree_path,
                            schedule_id=master.schedule_id,
                        )
                else:
                    logger.info("=== 步骤2: 无动态页面配置，跳过 ===")

                # ── 6. LinkTreeSyncer 同步到链接树表 ─────────
                logger.info("=== 步骤3: 同步到链接树表 ===")
                syncer = LinkTreeSyncer(
                    headless=self.headless,
                    s3_boundary=self._s3_boundary,
                )
                sync_stats = await syncer.sync(
                    tree_file=tree_path, site=domain
                )
                logger.info(f"链接树同步完成: {sync_stats}")

                # ── 7. 更新主任务为 completed ─────────────────
                await self._repo.mark_completed(
                    task_id=master.task_id,
                    links_path=links_path,
                    tree_path=tree_path,
                    pages_crawled=tree_stats.get("total_pages", 0),
                    links_found=tree_stats.get("total_links", 0),
                )

                logger.info(
                    f"全量爬取完成: task_id={master.task_id}, "
                    f"site={domain}, links={links_path}, tree={tree_path}"
                )

                return {
                    "task_id": master.task_id,
                    "site": domain,
                    "links_path": links_path,
                    "tree_path": tree_path,
                    "stats": {
                        "total_pages": tree_stats.get("total_pages", 0),
                        "total_links": tree_stats.get("total_links", 0),
                        "sync_inserted": sync_stats.get("inserted", 0),
                        "sync_skipped": sync_stats.get("skipped", 0),
                    },
                }

            except Exception as e:
                logger.exception(f"全量爬取失败: {master.task_id}")
                await self._repo.mark_failed(
                    master.task_id, error_message=str(e)
                )
                raise

    async def _run_dynamic_crawl(
        self,
        site: str,
        page_type: str,
        links_path: str,
        tree_path: str,
        schedule_id: str | None = None,
    ) -> None:
        """执行单个动态页面爬取。

        Args:
            site: 站点域名
            page_type: 动态页面类型
            links_path: 当前链接列表 S3 路径
            tree_path: 当前树结构 S3 路径
            schedule_id: 关联的调度 ID（周期性调度任务时填写）
        """
        entry = load_dynamic_page_config(site, page_type)
        if entry is None:
            logger.warning(f"未找到动态页面配置: site={site}, page_type={page_type}，跳过")
            return

        logger.info(f"--- Dynamic 爬取: site={site}, page_type={page_type} ---")
        dynamic_task = self._task_manager.create_task(
            task_type="dynamic",
            site=site,
            target_url=f"{site}/{page_type}",
            headless=self.headless,
            output_type=self.output_type,
            schedule_id=schedule_id,
        )
        await self._repo.create(dynamic_task)
        await self._repo.mark_running(dynamic_task.task_id)

        try:
            crawler = DynamicCrawler(
                headless=self.headless,
                s3_boundary=self._s3_boundary,
            )
            dynamic_result = await crawler.crawl_dynamic(
                site=site,
                page_type=page_type,
                static_links_file=links_path,
                static_tree_file=tree_path,
            )
            await self._repo.mark_completed(
                task_id=dynamic_task.task_id,
                links_path=links_path,
                tree_path=tree_path,
                pages_crawled=0,
                links_found=dynamic_result.get("merged_links_count", 0),
            )
            logger.info(
                f"Dynamic 爬取完成: site={site}, page_type={page_type}, "
                f"merged={dynamic_result.get('merged_links_count', 0)}"
            )
        except Exception as e:
            await self._repo.mark_failed(
                dynamic_task.task_id, error_message=str(e)
            )
            logger.error(
                f"Dynamic 爬取失败: site={site}, page_type={page_type}, error={e}"
            )
            # 不抛出异常：单个 dynamic 失败不应阻塞整个全量流程
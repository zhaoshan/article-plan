package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 登录态自助改密（G2 首登强制改密，docs/08 §2）：校验旧密码（或初始密码）→ 更新 BCrypt →
 * 清零 {@code must_change_password}。不吊销当前会话（强制改密场景保持登录态，体验优先；
 * 会话吊销语义与「忘记密码重置」区分——重置吊销全部 refresh，改密不吊销）。
 */
@Service
public class ChangePasswordService {

    private final UserRepository userRepository;

    public ChangePasswordService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Transactional
    public void change(String userId, String oldPassword, String newPassword) {
        UserPO user = userRepository.findByUserId(userId)
                .orElseThrow(() -> AuthException.unauthorized("用户不存在"));
        if (user.getPasswordHash() == null || !BCryptUtils.matches(oldPassword, user.getPasswordHash())) {
            throw AuthException.unauthorized("原密码不正确");
        }
        user.setPasswordHash(BCryptUtils.hash(newPassword));
        user.setMustChangePassword(0);
        userRepository.update(user);
    }
}

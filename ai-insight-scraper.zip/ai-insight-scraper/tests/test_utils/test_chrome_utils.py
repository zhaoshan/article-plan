"""chrome_utils 工具函数测试"""

import pytest
from unittest.mock import patch
from src.utils.chrome_utils import find_chrome_path


class TestFindChromePath:
    """find_chrome_path 测试"""

    def test_returns_path_when_exists(self):
        """当 Chrome 路径存在时返回路径"""
        with patch("src.utils.chrome_utils.platform.system", return_value="Windows"):
            with patch("os.path.exists", side_effect=lambda p: "Program Files" in p):
                result = find_chrome_path()
                assert "chrome.exe" in result.lower()

    def test_returns_empty_when_not_found(self):
        """当 Chrome 未找到时返回空字符串"""
        with patch("os.path.exists", return_value=False):
            result = find_chrome_path()
            assert result == ""

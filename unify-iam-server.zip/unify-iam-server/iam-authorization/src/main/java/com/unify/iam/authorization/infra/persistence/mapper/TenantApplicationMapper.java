package com.unify.iam.authorization.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.authorization.infra.persistence.po.TenantApplicationPO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/** iam_tenant_application Mapper。 */
@Mapper
public interface TenantApplicationMapper extends BaseMapper<TenantApplicationPO> {

    /**
     * 恢复/启用租户应用关系（原生 UPDATE，绕过 @TableLogic 的 delete_flag=0 过滤，
     * 可恢复逻辑删除的行——避免「软删后唯一键占位导致重新启用失败」）。
     *
     * @return 命中的行数（0 表示不存在，调用方改走 insert）
     */
    @Update("UPDATE iam_tenant_application SET delete_flag = 0, update_time = NOW() "
            + "WHERE tenant_id = #{tenantId} AND app_code = #{appCode}")
    int restore(@Param("tenantId") String tenantId, @Param("appCode") String appCode);
}

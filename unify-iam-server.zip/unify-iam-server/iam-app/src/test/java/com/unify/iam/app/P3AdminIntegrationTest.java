package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * E2E-3（P3）管理面集成测试：自身鉴权（401/403/200）+ 审计落库。
 */
class P3AdminIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    @Test
    void adminCanListUsersWithIamPermission() throws Exception {
        String token = login("admin", "admin123");

        MvcResult res = mockMvc.perform(get("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + token)
                        .param("limit", "10"))
                .andExpect(status().isOk())
                .andReturn();
        String body = res.getResponse().getContentAsString();
        // 3 个 seed 用户 + 不含密码哈希
        assertThat(body).contains("admin").contains("operator").contains("viewer");
        assertThat(body).doesNotContain("passwordHash");

        // 审计落库
        Integer audits = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_audit_log WHERE event_type='ADMIN_LIST_USERS'", Integer.class);
        assertThat(audits).isGreaterThanOrEqualTo(1);
    }

    @Test
    void nonAdminUserGets403OnAdminEndpoint() throws Exception {
        String token = login("viewer", "view123"); // Viewer：无任何 iam:*

        mockMvc.perform(get("/api/v1/admin/users").header("Authorization", "Bearer " + token))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("Missing permission point")));
    }

    @Test
    void adminTokenCarriesIamPermissions() throws Exception {
        String token = login("admin", "admin123");
        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.roles").value(org.hamcrest.Matchers.hasItem("PlatformAdmin")))
                .andExpect(jsonPath("$.data.permissions").value(org.hamcrest.Matchers.hasItem("iam:user:read")))
                .andExpect(jsonPath("$.data.permissions").value(org.hamcrest.Matchers.hasItem("iam:audit:read")));
    }

    @Test
    void adminUsersWithoutTokenReturns401() throws Exception {
        mockMvc.perform(get("/api/v1/admin/users"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void adminCanQueryAuditWithFilters() throws Exception {
        String token = login("admin", "admin123");
        // 触发一条审计（列用户会落 ADMIN_LIST_USERS）
        mockMvc.perform(get("/api/v1/admin/users").param("limit", "10")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk());

        // ① 无过滤列表 → 200 且含审计条目
        String body = mockMvc.perform(get("/api/v1/admin/audit")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.total").isNumber())
                .andReturn().getResponse().getContentAsString();
        assertThat(body).contains("ADMIN_LIST_USERS");

        // ② 按事件类型过滤 → 只返回匹配项
        mockMvc.perform(get("/api/v1/admin/audit")
                        .param("event_type", "ADMIN_LIST_USERS")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.audits[0].event_type").value("ADMIN_LIST_USERS"));

        // ③ 非平台管理员（无 iam:audit:read）→ 403
        String viewer = login("viewer", "view123");
        mockMvc.perform(get("/api/v1/admin/audit").header("Authorization", "Bearer " + viewer))
                .andExpect(status().isForbidden());
    }
}
package com.unify.iam.identity.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.identity.infra.persistence.mapper.IdpConfigMapper;
import com.unify.iam.identity.infra.persistence.po.IdpConfigPO;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/**
 * 租户 IdP 配置仓储（读取时 trim 业务键）。
 */
@Repository
public class IdpConfigRepository {

    private final IdpConfigMapper idpConfigMapper;

    public IdpConfigRepository(IdpConfigMapper idpConfigMapper) {
        this.idpConfigMapper = idpConfigMapper;
    }

    /** 查某租户的 ACTIVE OIDC 配置（企业 SSO；平台级 consumer 用 tenantId=PLATFORM）。 */
    public Optional<IdpConfigPO> findActiveOidcByTenant(String tenantId) {
        return Optional.ofNullable(idpConfigMapper.selectOne(new LambdaQueryWrapper<IdpConfigPO>()
                        .eq(IdpConfigPO::getTenantId, tenantId)
                        .eq(IdpConfigPO::getProtocol, "OIDC")
                        .eq(IdpConfigPO::getConfigStatus, "ACTIVE")))
                .map(this::trimBizKeys);
    }

    /** 按配置 ID 查（回调阶段用）。 */
    public Optional<IdpConfigPO> findActiveById(String configId) {
        return Optional.ofNullable(idpConfigMapper.selectOne(new LambdaQueryWrapper<IdpConfigPO>()
                        .eq(IdpConfigPO::getTenantIdpConfigId, configId)
                        .eq(IdpConfigPO::getConfigStatus, "ACTIVE")))
                .map(this::trimBizKeys);
    }

    /** 全部 ACTIVE OIDC 配置（登录页「企业组织」下拉数据源，docs/05 §7.1）。 */
    public List<IdpConfigPO> findAllActiveOidc() {
        return idpConfigMapper.selectList(new LambdaQueryWrapper<IdpConfigPO>()
                        .eq(IdpConfigPO::getProtocol, "OIDC")
                        .eq(IdpConfigPO::getConfigStatus, "ACTIVE"))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 某租户的全部配置（含 DISABLED，管理面列表用，docs/07 §3.1）。 */
    public List<IdpConfigPO> listByTenant(String tenantId) {
        return idpConfigMapper.selectList(new LambdaQueryWrapper<IdpConfigPO>()
                        .eq(IdpConfigPO::getTenantId, tenantId.trim())
                        .orderByAsc(IdpConfigPO::getId))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 按配置 ID 查（任意状态，管理面编辑用）。 */
    public Optional<IdpConfigPO> findById(String configId) {
        return Optional.ofNullable(idpConfigMapper.selectOne(new LambdaQueryWrapper<IdpConfigPO>()
                        .eq(IdpConfigPO::getTenantIdpConfigId, configId)))
                .map(this::trimBizKeys);
    }

    /** 更新（管理面编辑）。 */
    public void update(IdpConfigPO po) {
        idpConfigMapper.updateById(po);
    }

    /** 逻辑删除（管理面停用）。 */
    public void logicalDelete(String configId) {
        idpConfigMapper.delete(new LambdaQueryWrapper<IdpConfigPO>()
                .eq(IdpConfigPO::getTenantIdpConfigId, configId));
    }

    /** 插入（测试/联调运行时写入 IdP 配置）。 */
    public void insert(IdpConfigPO po) {
        idpConfigMapper.insert(po);
    }

    private IdpConfigPO trimBizKeys(IdpConfigPO po) {
        if (po.getTenantIdpConfigId() != null) {
            po.setTenantIdpConfigId(po.getTenantIdpConfigId().trim());
        }
        if (po.getTenantId() != null) {
            po.setTenantId(po.getTenantId().trim());
        }
        return po;
    }
}
package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateDomainRequest;
import com.unify.iam.app.app.service.DomainVerificationService;
import com.unify.iam.app.security.RequirePermission;
import jakarta.validation.Valid;
import java.util.Map;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：企业域名登记与验证（iam:tenant:write）。 */
@RestController
public class AdminDomainController {

    private final DomainVerificationService domainVerificationService;

    public AdminDomainController(DomainVerificationService domainVerificationService) {
        this.domainVerificationService = domainVerificationService;
    }

    /** 为租户登记域名，返回验证挑战（DNS TXT / HTTP 文件值）。 */
    @PostMapping("/api/v1/admin/tenants/{tenantId}/domains")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, String> createDomain(@PathVariable String tenantId,
                                            @Valid @RequestBody CreateDomainRequest request) {
        return domainVerificationService.createDomain(tenantId, request);
    }

    /** 验证通过（dev 自动验证；生产应在校验 DNS/HTTP 挑战后调用）。 */
    @PostMapping("/api/v1/admin/domains/{domainId}/verify")
    @RequirePermission(PermissionCodes.IAM_TENANT_WRITE)
    public Map<String, String> verify(@PathVariable String domainId) {
        return domainVerificationService.verify(domainId);
    }
}

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;

import com.unify.iam.app.app.service.TokenVersionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * bump 宽容化回归测试（2026-11-12）：成员已删（孤儿绑定——membership_role 活着但 membership
 * 软删）时 bump/bumpForRoleHolders 跳过 + WARN，不再 404 中断批量流程
 * （role-templates/permissions 同步曾因孤儿持有者全事务回滚）。
 */
class TokenVersionBumpToleranceIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private TokenVersionService tokenVersionService;

    @Test
    void bumpSkipsMissingMembershipInsteadOfThrowing() throws Exception {
        // 随机不存在的 membershipId：旧行为 404，新行为跳过返回 false
        boolean bumped = tokenVersionService.bump("ms-nonexistent-00000000000000000", "PERM_CHANGE");
        assertThat(bumped).isFalse();
    }

    @Test
    void bumpForRoleHoldersSkipsOrphansAndCountsActualBumps() throws Exception {
        String admin = unwrapData(mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .post("/api/v1/auth/token")
                        .contentType(org.springframework.http.MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.status().isOk())
                .andReturn().getResponse().getContentAsString())
                .get("access_token").toString();
        // tenant-org-a 建角色 + 绑给 admin（活持有者）
        String roleId = unwrapData(mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(org.springframework.http.MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"tenant-org-a\","
                                + "\"role_code\":\"BumpTol_" + java.util.UUID.randomUUID().toString().substring(0, 6)
                                + "\",\"role_name\":\"Bump Tolerance\"}"))
                .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.status().isOk())
                .andReturn().getResponse().getContentAsString())
                .get("role_id").toString();
        String msId = jdbcTemplate.queryForObject(
                "SELECT membership_id FROM gateway_membership WHERE tenant_id='tenant-org-a' "
                        + "AND user_id='u-1000' AND delete_flag=0", String.class).trim();
        jdbcTemplate.update("INSERT INTO gateway_membership_role (membership_role_id, membership_id, role_id, "
                        + "grant_source, delete_flag, create_by, update_by) VALUES (?,?,?,'DIRECT',0,'system','system')",
                "mrt-probe-" + java.util.UUID.randomUUID().toString().substring(0, 8), msId, roleId.trim());
        // 造孤儿绑定：membership_role 指向不存在的 membership
        jdbcTemplate.update("INSERT INTO gateway_membership_role (membership_role_id, membership_id, role_id, "
                        + "grant_source, delete_flag, create_by, update_by) VALUES (?,?,?,'DIRECT',0,'system','system')",
                "mrt-orphan-" + java.util.UUID.randomUUID().toString().substring(0, 8),
                "ms-orphan-0000000000000000000", roleId.trim());

        int bumped = tokenVersionService.bumpForRoleHolders(roleId.trim(), "PERM_CHANGE");

        // 旧行为：orphan 处抛 MEMBERSHIP_NOT_FOUND；新行为：跳过孤儿，只计活持有者 1 个
        assertThat(bumped).isEqualTo(1);
    }
}

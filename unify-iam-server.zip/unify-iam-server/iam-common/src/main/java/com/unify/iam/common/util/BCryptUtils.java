package com.unify.iam.common.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * BCrypt 密码哈希封装（仅依赖 spring-security-crypto，不引全量 Spring Security）。
 *
 * <p>{@code BCryptPasswordEncoder.matches} 兼容 {@code $2a/$2b/$2y} 前缀的哈希；
 * E2E-1 seed 使用 cost=10 的 {@code $2y$} 哈希。
 */
public final class BCryptUtils {

    private static final BCryptPasswordEncoder ENCODER = new BCryptPasswordEncoder();

    private BCryptUtils() {
    }

    /** 生成 BCrypt 哈希。 */
    public static String hash(String rawPassword) {
        return ENCODER.encode(rawPassword);
    }

    /** 校验明文与哈希是否匹配。 */
    public static boolean matches(String rawPassword, String encodedPassword) {
        if (encodedPassword == null || encodedPassword.isEmpty()) {
            return false;
        }
        return ENCODER.matches(rawPassword, encodedPassword);
    }
}

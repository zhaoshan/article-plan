package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.app.support.MemberInvitationTestMailSender;
import com.unify.iam.common.util.JsonUtils;
import com.unify.iam.common.util.SecureToken;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.http.MediaType;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MvcResult;

/**
 * The form contract must never report a sent Owner invitation if tenant persistence or SMTP delivery failed.
 */
@Import(EnterpriseTenantOwnerInvitationIntegrationTest.MailConfiguration.class)
class EnterpriseTenantOwnerInvitationIntegrationTest extends IamIntegrationTestBase {

    /** 邮件密码块：模板 "Temporary password" 标签后的值单元格（{{initial_password}} 渲染处）。 */
    private static final Pattern INITIAL_PASSWORD_PATTERN =
            Pattern.compile("Temporary password\\s*</td>\\s*<td[^>]*>\\s*([^<]+?)\\s*</td>");

    @Autowired
    private MemberInvitationTestMailSender mailSender;

    @Autowired
    private com.unify.iam.app.config.IamProperties iamProperties;

    @org.junit.jupiter.api.BeforeEach
    void enableStrictDelivery() {
        iamProperties.getMail().setDeliveryEnabled(true);
    }

    @org.junit.jupiter.api.AfterEach
    void resetStrictDelivery() {
        iamProperties.getMail().setDeliveryEnabled(false);
    }


    @AfterEach
    void resetMailSender() {
        mailSender.reset();
    }

    @Test
    void formProvisioningGeneratesCodeUsesOnlyDefaultBusinessAppAndActivatesOnAcceptance() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String tenantName = "Owner invite " + suffix;
        String admin = adminToken();

        Map<String, Object> created = adminPost("/api/v1/admin/tenants",
                Map.of("tenant_name", tenantName, "owner_email", "operator@unify.local"), admin);
        String tenantId = created.get("tenant_id").toString();
        String invitationId = created.get("invitation_id").toString();

        assertThat(created)
                .containsEntry("tenant_type", "ORGANIZATION")
                .containsEntry("tenant_status", "PENDING")
                .containsEntry("owner_email", "operator@unify.local")
                .containsEntry("owner_assigned", false)
                .containsEntry("invitation_status", "PENDING")
                .containsEntry("delivery_status", "DELIVERED");
        assertThat(mailSender.sentCount()).isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT tenant_code FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .matches("org-[0-9a-f]{16}");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT tenant_type FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo("ORGANIZATION");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT tenant_status FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo("PENDING");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isNull();
        assertThat(jdbcTemplate.queryForList(
                "SELECT app_code FROM iam_tenant_application WHERE tenant_id=? ORDER BY app_code", String.class,
                tenantId)).containsExactly("imorph");

        // The raw token is deliberately never a response value. Replace the test row's hash only to exercise
        // the same authoritative acceptance transition that the emailed token reaches in production.
        String rawToken = "tenant-owner-accept-" + suffix;
        jdbcTemplate.update("UPDATE gateway_invitation SET invite_token_hash=? WHERE invitation_id=?",
                SecureToken.hash(rawToken), invitationId);
        String operator = login("operator", "op123");
        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken + "/accept")
                        .header("Authorization", "Bearer " + operator))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"));

        String operatorId = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE username='operator'", String.class);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT tenant_status FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo("ACTIVE");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo(operatorId);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT invitation_status FROM gateway_invitation WHERE invitation_id=?", String.class, invitationId))
                .isEqualTo("ACCEPTED");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_audit_log WHERE tenant_id=? "
                        + "AND event_type='TENANT_OWNER_INVITATION_ACCEPTED'", Integer.class, tenantId))
                .isEqualTo(1);
    }

    @Test
    void formProvisioningJitsNewOwnerWithInitialPasswordPersonalTenantAndAccepts() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String admin = adminToken();
        String email = "owner-jit-" + suffix + "@example.com";
        // 登录目录按 jwt audiences 白名单过滤应用：测试环境默认仅 parlant-agent-server，放开 imorph
        iamProperties.getJwt().setAudiences(List.of("parlant-agent-server", "imorph"));

        Map<String, Object> created = adminPost("/api/v1/admin/tenants",
                Map.of("tenant_name", "Owner JIT " + suffix, "owner_email", email), admin);
        String tenantId = created.get("tenant_id").toString();

        // JIT 建号：username=邮箱、INVITE 来源、首登强制改密
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE username=? AND registration_source='INVITE'"
                        + " AND must_change_password=1", Integer.class, email)).isEqualTo(1);
        String userId = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE username=?", String.class, email);
        // PENDING 企业租户激活前不可登录（TokenService 要求默认 ACTIVE 成员、登录目录跳过非 ACTIVE 租户）
        // ——新 JIT 账号补个人租户（自助注册同口径），保证初始密码可登录
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_tenant WHERE owner_user_id=? AND tenant_type='PERSONAL'"
                        + " AND tenant_status='ACTIVE'", Integer.class, userId)).isEqualTo(1);
        String personalTenantId = jdbcTemplate.queryForObject(
                "SELECT tenant_id FROM gateway_tenant WHERE owner_user_id=? AND tenant_type='PERSONAL'",
                String.class, userId);
        // 与注册同口径：个人租户灌入默认应用（imorph）+ owner 授 is_owner 模板角色——
        // 否则个人租户无应用记录，登录目录（/available-apps）为空 → DENIED，进不了 hub accept
        assertThat(jdbcTemplate.queryForList(
                "SELECT app_code FROM iam_tenant_application WHERE tenant_id=?", String.class, personalTenantId))
                .containsExactly("imorph");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_role r ON mr.role_id=r.role_id"
                        + " JOIN gateway_membership m ON mr.membership_id=m.membership_id"
                        + " WHERE m.tenant_id=? AND r.role_code='iMorph-Owner'", Integer.class, personalTenantId))
                .isEqualTo(1);

        // 邮件含初始密码块 → 提取后即可登录（username=邮箱）
        String html = mailSender.latestHtmlFor(email);
        Matcher matcher = INITIAL_PASSWORD_PATTERN.matcher(html);
        assertThat(matcher.find()).as("owner invitation mail should contain the initial password block").isTrue();
        String ownerBearer = login(email, matcher.group(1));

        // 登录目录可见 imorph（个人租户已灌应用；全局 Jackson 为 snake_case）
        mockMvc.perform(get("/api/v1/auth/available-apps")
                        .header("Authorization", "Bearer " + ownerBearer))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.applications[0].app_code").value("imorph"));

        // 凭邮件 token accept → 租户激活 + 绑定 owner
        mockMvc.perform(post("/api/v1/auth/invitations/" + mailSender.latestTokenFor(email) + "/accept")
                        .header("Authorization", "Bearer " + ownerBearer))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"));
        assertThat(jdbcTemplate.queryForObject(
                "SELECT tenant_status FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo("ACTIVE");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT owner_user_id FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId))
                .isEqualTo(userId);
    }

    @Test
    void formProvisioningExistingOwnerEmailOmitsPasswordBlockAndKeepsPassword() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String admin = adminToken();
        String username = "owner-existing-" + suffix;
        String email = username + "@example.com";
        createUser(username, email, admin); // 已有账号（密码 Passw0rd!，无强制改密）
        String passwordHashBefore = jdbcTemplate.queryForObject(
                "SELECT password_hash FROM gateway_user WHERE username=?", String.class, username);

        Map<String, Object> created = adminPost("/api/v1/admin/tenants",
                Map.of("tenant_name", "Owner existing " + suffix, "owner_email", email), admin);
        assertThat(created.get("tenant_status")).isEqualTo("PENDING");

        // 已有账号：邮件无初始密码块；不重置密码（比对哈希）、不建个人租户
        assertThat(mailSender.latestHtmlFor(email)).doesNotContain("Temporary password");
        Object mustChange = jdbcTemplate.queryForObject(
                "SELECT must_change_password FROM gateway_user WHERE username=?", Object.class, username);
        assertThat(String.valueOf(mustChange)).isNotEqualTo("1");
        String userId = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE username=?", String.class, username);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_tenant WHERE owner_user_id=? AND tenant_type='PERSONAL'",
                Integer.class, userId)).isZero();
        // JIT 幂等：密码哈希保持不变
        assertThat(jdbcTemplate.queryForObject(
                "SELECT password_hash FROM gateway_user WHERE username=?", String.class, username))
                .isEqualTo(passwordHashBefore);
    }

    @Test
    void formBranchRejectsLegacyFieldsAndInvalidOwnerEmail() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String admin = adminToken();
        String legacyFieldName = "Reject legacy " + suffix;
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_name", legacyFieldName,
                                "owner_email", "owner@example.com",
                                "app_codes", List.of("iam")))))
                .andExpect(status().isBadRequest());
        assertThat(countTenantsNamed(legacyFieldName)).isZero();

        String invalidEmailName = "Reject email " + suffix;
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_name", invalidEmailName,
                                "owner_email", "not-an-email"))))
                .andExpect(status().isBadRequest());
        assertThat(countTenantsNamed(invalidEmailName)).isZero();
    }

    @Test
    void smtpFailureRollsBackNewTenantAndExistingOwnerTransferInvitation() throws Exception {
        String suffix = UUID.randomUUID().toString().substring(0, 8);
        String admin = adminToken();
        String failedTenantName = "SMTP rollback " + suffix;

        mailSender.failNextSend();
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "tenant_name", failedTenantName,
                                "owner_email", "mail-failure-" + suffix + "@example.com"))))
                .andExpect(status().isServiceUnavailable());
        assertThat(countTenantsNamed(failedTenantName)).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email=? AND invitation_purpose='TENANT_OWNER_SETUP'",
                Integer.class, "mail-failure-" + suffix + "@example.com")).isZero();
        // JIT 账号 + 个人租户随整事务一并回滚（邀请即建号语义）
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE username=?", Integer.class,
                "mail-failure-" + suffix + "@example.com")).isZero();
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_tenant t JOIN gateway_user u ON t.owner_user_id=u.user_id"
                        + " WHERE u.username=? AND t.tenant_type='PERSONAL'", Integer.class,
                "mail-failure-" + suffix + "@example.com")).isZero();

        String currentOwnerId = createUser("smtp-owner-" + suffix, "smtp-owner-" + suffix + "@example.com", admin);
        String existingTenantId = createLegacyTenant("smtp-existing-" + suffix, "Existing " + suffix,
                currentOwnerId, admin);
        mailSender.failNextSend();
        mockMvc.perform(post("/api/v1/admin/tenants/" + existingTenantId + "/owner")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "mode", "INVITE_BY_EMAIL",
                                "email", "owner-transfer-failure-" + suffix + "@example.com"))))
                .andExpect(status().isServiceUnavailable());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE tenant_id=? AND invitation_purpose='OWNER_TRANSFER'",
                Integer.class, existingTenantId)).isZero();
    }

    private int countTenantsNamed(String tenantName) {
        return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM gateway_tenant WHERE tenant_name=?", Integer.class,
                tenantName);
    }

    private String login(String username, String password) throws Exception {
        MvcResult result = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", username, "password", b64(password)))))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(result.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminToken() throws Exception {
        return login("admin", "admin123");
    }

    private Map<String, Object> adminPost(String path, Object body, String token) throws Exception {
        MvcResult result = mockMvc.perform(post(path)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return unwrapData(result.getResponse().getContentAsString());
    }

    private String createUser(String username, String email, String token) throws Exception {
        return adminPost("/api/v1/admin/users", Map.of(
                "username", username, "email", email, "password", b64("Passw0rd!")), token)
                .get("user_id").toString();
    }

    private String createLegacyTenant(String code, String name, String ownerUserId, String token) throws Exception {
        return adminPost("/api/v1/admin/tenants", Map.of(
                "tenant_code", code,
                "tenant_name", name,
                "owner_user_id", ownerUserId,
                "app_codes", List.of("parlant-agent-server")), token)
                .get("tenant_id").toString();
    }

    @TestConfiguration(proxyBeanMethods = false)
    static class MailConfiguration {

        @Bean
        @Primary
        MemberInvitationTestMailSender ownerInvitationTestMailSender() {
            return new MemberInvitationTestMailSender();
        }

        /** 统一闸门校验 isMailConfigured（host/from + Sender）：基类把 spring.mail.host 注册为空串，此处显式补齐。 */
        @Bean
        @Primary
        com.unify.iam.app.mail.JavaMailEmailTool strictJavaMailEmailTool(
                org.springframework.beans.factory.ObjectProvider<org.springframework.mail.javamail.JavaMailSender> senderProvider) {
            return new com.unify.iam.app.mail.JavaMailEmailTool(
                    senderProvider, "smtp.test.local", "iam-test@example.com");
        }
    }
}

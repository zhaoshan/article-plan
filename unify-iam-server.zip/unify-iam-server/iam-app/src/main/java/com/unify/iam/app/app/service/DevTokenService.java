package com.unify.iam.app.app.service;

import com.unify.iam.api.dto.auth.DevTokenRequest;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import org.springframework.stereotype.Service;

/**
 * dev-token 签发：按 seed 用户/角色直签，联调/Postman 友好（不校验密码）。
 * prod 通过 {@code iam.dev-token-enabled=false} 禁用。
 */
@Service
public class DevTokenService {

    private final UserRepository userRepository;
    private final MembershipResolver membershipResolver;
    private final TokenService tokenService;
    private final IamProperties props;

    public DevTokenService(UserRepository userRepository,
                           MembershipResolver membershipResolver,
                           TokenService tokenService,
                           IamProperties props) {
        this.userRepository = userRepository;
        this.membershipResolver = membershipResolver;
        this.tokenService = tokenService;
        this.props = props;
    }

    public LoginResponse issueDev(DevTokenRequest request) {
        if (!props.isDevTokenEnabled()) {
            throw AuthException.forbidden("dev-token 已禁用");
        }
        if (!request.hasUserRef()) {
            throw AuthException.badRequest("userId 与 username 至少提供一个");
        }
        UserPO user = resolveUser(request);
        MembershipPO membership = resolveMembership(request, user);
        UserPrincipal principal = new UserPrincipal(user.getUserId().trim(), user.getUsername(), null);
        return tokenService.issueWithRefresh(principal, membership);
    }

    private UserPO resolveUser(DevTokenRequest request) {
        if (request.userId() != null && !request.userId().isBlank()) {
            return userRepository.findByUserId(request.userId().trim())
                    .orElseThrow(() -> AuthException.notFound("用户不存在"));
        }
        return userRepository.findByUsername(request.username().trim())
                .orElseThrow(() -> AuthException.notFound("用户不存在"));
    }

    private MembershipPO resolveMembership(DevTokenRequest request, UserPO user) {
        if (request.membershipId() != null && !request.membershipId().isBlank()) {
            return membershipResolver.findById(request.membershipId().trim())
                    .filter(m -> m.getUserId().equals(user.getUserId().trim()))
                    .orElseThrow(() -> AuthException.notFound("成员关系不存在"));
        }
        return membershipResolver.findDefaultActiveMembership(user.getUserId().trim())
                .orElseThrow(() -> AuthException.notFound("用户没有可用成员关系"));
    }
}

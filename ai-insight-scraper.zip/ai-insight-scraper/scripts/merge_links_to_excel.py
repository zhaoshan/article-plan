# -*- coding: utf-8 -*-
"""
将链接 JSON 文件增量合并到 all_links_tag_result.xlsx

规则：
- A列(原始链接): 写入URL，与已有数据去重，不重复写入
- B列(域名)/C列(子路径)/D列(文件名): 参考 json_to_excel.py 的 parse_url 计算规则
- E列(链接类型): 如果不是附件类链接，取 HTML，附件的话取附件类型，比如：PDF/DOC/EXCEL
- F列(网站归属): 如果原始链接域名与爬取站点域名一致，取：自社，否则取：他社
- G列(服务大类别): 空值
- H列(服务小类别): 空值
- I列(是否下载): 空值
- J列(说明): 空值
- K列(最后更新日期): 空值
- L列(更新履历): 固定值 补数据
- M列(更新时间): 当前时间
- N列(最后爬取时间): 空值
- O列(content_hash): 空值

用法：
    python scripts/merge_links_to_excel.py <json_file> --site <站点域名>

示例：
    python scripts/merge_links_to_excel.py output/all_tsb_unique_links.json --site tokyostarbank.co.jp
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import openpyxl

# 解决 Windows 控制台 UTF-8 编码问题
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ==================== 附件类型检测 ====================

# 常见附件扩展名 → 类型标签
ATTACHMENT_EXTENSIONS: dict[str, str] = {
    # PDF
    ".pdf": "PDF",
    # Word
    ".doc": "DOC",
    ".docx": "DOC",
    # Excel
    ".xls": "EXCEL",
    ".xlsx": "EXCEL",
    ".csv": "EXCEL",
    # PowerPoint
    ".ppt": "PPT",
    ".pptx": "PPT",
    # 压缩包
    ".zip": "ZIP",
    ".rar": "ZIP",
    ".7z": "ZIP",
    ".tar": "ZIP",
    ".gz": "ZIP",
    # 图片
    ".png": "IMAGE",
    ".jpg": "IMAGE",
    ".jpeg": "IMAGE",
    ".gif": "IMAGE",
    ".bmp": "IMAGE",
    ".svg": "IMAGE",
    ".webp": "IMAGE",
    # 文本
    ".txt": "TEXT",
    # 视频
    ".mp4": "VIDEO",
    ".avi": "VIDEO",
    ".mov": "VIDEO",
    ".wmv": "VIDEO",
}


def detect_attachment_type(url: str) -> str:
    """
    从 URL 路径中检测附件类型。

    如果 URL 路径的扩展名匹配已知附件类型，返回对应标签；
    否则返回 "HTML"。
    """
    path = urlparse(url).path.lower()
    if not path:
        return "HTML"

    # 取最后一个 . 之后的扩展名
    if "." in path:
        ext = "." + path.rsplit(".", 1)[-1]
        # 排除常见的非附件扩展名（.html, .htm, .php, .asp, .aspx, .jsp 等）
        if ext in ATTACHMENT_EXTENSIONS:
            return ATTACHMENT_EXTENSIONS[ext]

    return "HTML"


# ==================== URL 解析（与 json_to_excel.py 一致） ====================


def parse_url(url: str) -> dict:
    """
    解析 URL，提取域名、子路径、文件名

    规则与 json_to_excel.py 的 parse_url 保持一致
    """
    parsed = urlparse(url)

    # 域名（去除 www. 前缀）
    domain = parsed.netloc.replace("www.", "")

    # 路径部分
    path = parsed.path

    # 子路径和文件名
    if path and path != "/":
        path_parts = path.strip("/").split("/")
        if len(path_parts) > 1:
            # 有多级路径，子路径是除最后一段外的所有部分
            sub_path = "/" + "/".join(path_parts[:-1])
        else:
            # 只有一级路径
            sub_path = ""
        # 如果最后一段包含.，认为是文件名
        if "." in path_parts[-1]:
            file_name = path_parts[-1]
        else:
            file_name = ""
            # 如果没有文件名，最后一段属于子路径
            sub_path = "/" + "/".join(path_parts) if path_parts else ""
    elif path == "/":
        sub_path = ""
        file_name = ""
    else:
        sub_path = ""
        file_name = ""

    return {
        "domain": domain,
        "sub_path": sub_path if sub_path else None,
        "file_name": file_name if file_name else None,
    }


def get_domain_from_url(url: str) -> str:
    """从 URL 中提取域名（去除 www. 前缀）"""
    domain = urlparse(url).netloc.replace("www.", "")
    return domain


def is_same_site(url: str, site: str) -> bool:
    """
    判断 URL 的域名是否与站点一致。

    匹配规则：
    - 精确匹配：url 域名 == site（如 tokyostarbank.co.jp）
    - 子域名匹配：url 域名以 .site 结尾（如 sub.tokyostarbank.co.jp）
    """
    url_domain = get_domain_from_url(url)
    if not url_domain:
        return False
    return url_domain == site or url_domain.endswith("." + site)


# ==================== 主流程 ====================


def merge_links_to_excel(json_file: Path, site: str, excel_file: Path | None = None):
    """将 JSON 链接增量合并到 Excel

    Args:
        json_file: 链接 JSON 文件路径（如 all_tsb_unique_links.json）
        site: 站点域名（如 tokyostarbank.co.jp），用于判定 F列 网站归属
        excel_file: 目标 Excel 文件路径（默认与 json_file 同目录的 all_links_tag_result.xlsx）
    """
    # 1. 读取 JSON 链接
    if not json_file.exists():
        print(f"错误：JSON 文件不存在 - {json_file}")
        sys.exit(1)

    with open(json_file, "r", encoding="utf-8") as f:
        links = json.load(f)

    print(f"JSON 中共 {len(links)} 条链接")

    # 2. 确定 Excel 文件路径
    if excel_file is None:
        excel_file = json_file.parent / "all_links_tag_result.xlsx"

    if not excel_file.exists():
        print(f"错误：Excel 文件不存在 - {excel_file}")
        sys.exit(1)

    wb = openpyxl.load_workbook(excel_file)
    ws = wb.worksheets[0]

    # 读取 A 列已有的所有 URL（从第2行开始，第1行是表头）
    existing_urls = set()
    for row in range(2, ws.max_row + 1):
        url = ws.cell(row=row, column=1).value
        if url:
            existing_urls.add(url.strip())

    print(f"Excel 中已有 {len(existing_urls)} 条链接")

    # 3. 筛选出需要新增的链接
    new_links = []
    for link in links:
        url = link.strip()
        if url not in existing_urls:
            new_links.append(url)

    print(f"需要新增 {len(new_links)} 条链接")

    if not new_links:
        print("无新增链接，无需更新")
        wb.close()
        return

    # 4. 逐行写入新增链接
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    start_row = ws.max_row + 1

    for i, url in enumerate(new_links):
        row = start_row + i
        parsed = parse_url(url)

        # A列: 原始链接
        ws.cell(row=row, column=1, value=url)
        # B列: 域名
        ws.cell(row=row, column=2, value=parsed["domain"])
        # C列: 子路径
        ws.cell(row=row, column=3, value=parsed["sub_path"])
        # D列: 文件名
        ws.cell(row=row, column=4, value=parsed["file_name"])
        # E列: 链接类型 — 附件类取附件类型，否则 HTML
        ws.cell(row=row, column=5, value=detect_attachment_type(url))
        # F列: 网站归属 — 同域名取自社，否则他社
        ws.cell(row=row, column=6, value="自社" if is_same_site(url, site) else "他社")
        # G列: 服务大类别 — 空值
        ws.cell(row=row, column=7, value=None)
        # H列: 服务小类别 — 空值
        ws.cell(row=row, column=8, value=None)
        # I列: 是否下载 — 空值
        ws.cell(row=row, column=9, value=None)
        # J列: 说明 — 空值
        ws.cell(row=row, column=10, value=None)
        # K列: 最后更新日期 — 空值
        ws.cell(row=row, column=11, value=None)
        # L列: 更新履历 — 补数据
        ws.cell(row=row, column=12, value="补数据")
        # M列: 更新时间 — 当前时间
        ws.cell(row=row, column=13, value=now_str)
        # N列: 最后爬取时间 — 空值
        ws.cell(row=row, column=14, value=None)
        # O列: content_hash — 空值
        ws.cell(row=row, column=15, value=None)

    # 5. 保存
    wb.save(excel_file)
    wb.close()

    print(f"已新增 {len(new_links)} 条链接到 {excel_file.name}")
    print(f"Excel 总行数: {start_row + len(new_links) - 1} (含表头)")


# ==================== CLI 入口 ====================

def main():
    parser = argparse.ArgumentParser(
        description="将链接 JSON 文件增量合并到 all_links_tag_result.xlsx",
    )
    parser.add_argument(
        "json_file",
        type=Path,
        help="链接 JSON 文件路径（如 all_tsb_unique_links.json）",
    )
    parser.add_argument(
        "--site",
        required=True,
        type=str,
        help="站点域名，与 dynamic_page_config.json 的 key 一致（如 tokyostarbank.co.jp）",
    )
    parser.add_argument(
        "--excel",
        type=Path,
        default=None,
        help="目标 Excel 文件路径（默认与 json_file 同目录的 all_links_tag_result.xlsx）",
    )

    args = parser.parse_args()
    merge_links_to_excel(args.json_file, args.site, args.excel)


if __name__ == "__main__":
    main()

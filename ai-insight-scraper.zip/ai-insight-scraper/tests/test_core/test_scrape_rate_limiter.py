"""ScrapeRateLimiter 单元测试"""

import asyncio
from unittest.mock import MagicMock

import pytest

from src.config.system_config import CrawlConfig, SystemConfig
from src.core.scrape_rate_limiter import ScrapeRateLimiter, ScrapeRateLimitError


class FakePsutil:
    """可配置可用内存的 psutil stub"""

    def __init__(self, available_mb: int):
        self._available_bytes = available_mb * 1024 * 1024

    class _VirtualMemory:
        def __init__(self, available: int):
            self.available = available

    def virtual_memory(self):
        return self._VirtualMemory(self._available_bytes)


def _make_config(max_concurrent_scrapes: int = 2, scrape_min_available_memory_mb: int = 300) -> SystemConfig:
    """构造测试用 SystemConfig"""
    return SystemConfig(
        crawl=CrawlConfig(
            max_concurrent_crawlers=1,
            max_concurrent_scrapes=max_concurrent_scrapes,
            scrape_min_available_memory_mb=scrape_min_available_memory_mb,
        )
    )


@pytest.mark.asyncio
async def test_rate_limiter_allows_when_healthy():
    """内存充足且并发槽空闲时，允许通过"""
    limiter = ScrapeRateLimiter(
        config=_make_config(),
        psutil_module=FakePsutil(available_mb=500),
    )
    async with limiter:
        pass


@pytest.mark.asyncio
async def test_rate_limiter_rejects_low_memory():
    """可用内存低于阈值时，抛出 ScrapeRateLimitError"""
    limiter = ScrapeRateLimiter(
        config=_make_config(scrape_min_available_memory_mb=300),
        psutil_module=FakePsutil(available_mb=299),
    )
    with pytest.raises(ScrapeRateLimitError) as exc_info:
        async with limiter:
            pass
    assert "可用内存不足" in exc_info.value.error
    assert exc_info.value.status_code == 429


@pytest.mark.asyncio
async def test_rate_limiter_rejects_when_concurrent_full():
    """并发槽满时，抛出 ScrapeRateLimitError"""
    limiter = ScrapeRateLimiter(
        config=_make_config(max_concurrent_scrapes=1),
        psutil_module=FakePsutil(available_mb=500),
    )

    async with limiter:
        with pytest.raises(ScrapeRateLimitError) as exc_info:
            async with limiter:
                pass
    assert "任务数已达上限" in exc_info.value.error
    assert exc_info.value.status_code == 429


@pytest.mark.asyncio
async def test_rate_limiter_releases_slot_after_exit():
    """退出上下文后，并发槽被释放"""
    limiter = ScrapeRateLimiter(
        config=_make_config(max_concurrent_scrapes=1),
        psutil_module=FakePsutil(available_mb=500),
    )

    async with limiter:
        pass

    # 释放后再次获取应成功
    async with limiter:
        pass


@pytest.mark.asyncio
async def test_rate_limiter_defaults_are_safe():
    """默认配置至少允许 1 个并发，内存阈值非负"""
    limiter = ScrapeRateLimiter(
        config=SystemConfig(),
        psutil_module=FakePsutil(available_mb=9999),
    )
    assert limiter._max_concurrent >= 1
    assert limiter._min_memory_mb >= 0


@pytest.mark.asyncio
async def test_rate_limiter_invalid_config_clamped():
    """非法配置值会被钳位到安全范围"""
    limiter = ScrapeRateLimiter(
        config=_make_config(
            max_concurrent_scrapes=0,
            scrape_min_available_memory_mb=-100,
        ),
        psutil_module=FakePsutil(available_mb=500),
    )
    assert limiter._max_concurrent == 1
    assert limiter._min_memory_mb == 0

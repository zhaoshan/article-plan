package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.ApplicationRoleTemplateMapper;
import com.unify.iam.authorization.infra.persistence.po.ApplicationRoleTemplatePO;
import java.util.Collection;
import java.util.List;
import org.springframework.stereotype.Repository;

/** 应用预置角色模板仓储（docs/06 §2.2）。 */
@Repository
public class ApplicationRoleTemplateRepository {

    private final ApplicationRoleTemplateMapper applicationRoleTemplateMapper;

    public ApplicationRoleTemplateRepository(ApplicationRoleTemplateMapper applicationRoleTemplateMapper) {
        this.applicationRoleTemplateMapper = applicationRoleTemplateMapper;
    }

    /** 指定应用集内 is_owner=1 的模板角色 code（租户 Admin 保护，docs/requirements CommonCapabilities 方式 B）。 */
    public List<String> listIsOwnerRoleCodes(Collection<String> codes) {
        if (codes == null || codes.isEmpty()) {
            return List.of();
        }
        return applicationRoleTemplateMapper.selectList(new LambdaQueryWrapper<ApplicationRoleTemplatePO>()
                        .in(ApplicationRoleTemplatePO::getAppCode, codes)
                        .eq(ApplicationRoleTemplatePO::getIsOwner, 1))
                .stream().map(ApplicationRoleTemplatePO::getRoleCode).map(String::trim).distinct().toList();
    }

    /** 按 app_code 集查模板（按 priority 升序；未逻辑删除）。 */
    public List<ApplicationRoleTemplatePO> listByAppCodes(Collection<String> codes) {
        if (codes == null || codes.isEmpty()) {
            return List.of();
        }
        return applicationRoleTemplateMapper.selectList(new LambdaQueryWrapper<ApplicationRoleTemplatePO>()
                .in(ApplicationRoleTemplatePO::getAppCode, codes)
                .orderByAsc(ApplicationRoleTemplatePO::getPriority)
                .orderByAsc(ApplicationRoleTemplatePO::getId));
    }
}

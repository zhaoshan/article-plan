"""src.parsers — 多策略解析适配器"""

from src.parsers.link_extractor import extract_links_from_page, extract_page_text

__all__ = [
    "extract_links_from_page",
    "extract_page_text",
]

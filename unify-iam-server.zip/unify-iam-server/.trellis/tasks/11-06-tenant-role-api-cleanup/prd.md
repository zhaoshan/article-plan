# Canonical tenant role catalog

## Goal
Use the existing authorized TENANT role list for role management and member dialogs, removing the obsolete combined global/tenant catalog.

## Requirements
- Remove GET /api/v1/admin/tenant/roles and its dedicated implementation and DTOs.
- Preserve GET /api/v1/admin/roles?scope_type=TENANT&scope_id=<tenant_id>: all non-deleted target-tenant roles, including builtin/Owner/DISABLED roles, no global or foreign tenant roles.
- Preserve platform aggregation, scope guards and iam:role:read authorization.
- Preserve permission directory string tenant_grantable and tenant-role write enforcement.
- Update executable contracts and record verification locally.
- Requirement 3: iMorph-Admin must actually create roles. Add iam:role:write to its template and existing non-deleted TENANT roles; keep Member read-only and retain own-tenant scope guards.

## Acceptance criteria
- Obsolete endpoint has no registered handler, and dedicated union query/DTOs have no product callers.
- Canonical list and cross-tenant/forged-platform permission regressions pass.
- Permission response includes string grantability flags and existing grant validation remains effective.
- Reactor compilation and relevant checks pass or environment limits are reported explicitly.
- Actual provisioned Admin login can create own-tenant roles but cannot create foreign-tenant/PLATFORM roles. Member cannot create roles. Existing-role grant repair is idempotent.

## Constraints and out of scope
Only current project/main checkout, current branch, uncommitted delivery. No commit, push, merge, branch switch/reset or worktrees. Frontend implementation and deployment belong to independent work. No schema changes, identity-policy or member-write-policy expansion. Seed changes are limited to the explicitly authorized iMorph-Admin role-write gap.

## Approval
The user approved the final review proposal in .trellis/workspace/xiaoshuang.li/2026-11-06-role-backend-review.md: “批准，继续后端实施”. Task creation and implementation are authorized. The proposal is authoritative except the subsequent explicit requirement-3 steering: user authorized necessary iMorph-Admin create-role permission repair.

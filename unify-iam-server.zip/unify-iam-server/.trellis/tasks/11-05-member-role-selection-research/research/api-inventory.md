# Existing API and query inventory

Research date: 2026-11-05. Evidence is from the current `feature/lee-1102` working tree, including pre-existing uncommitted role changes. No frontend source or live API was inspected.

## Endpoints
| Endpoint | Permission / purpose | Suitability |
| --- | --- | --- |
| GET `/api/v1/admin/roles` | `iam:role:read`; role administration | Closest data source, but current semantics and permissions differ from member assignment. |
| GET `/api/v1/admin/members/{membershipId}/roles` | `iam:member:read`; existing bindings | Needed for Edit role selection, not a candidate list. Returns role_id/code/name only. |
| GET `/api/v1/admin/applications` | `iam:tenant:read`; application template catalog | Templates lack persisted role IDs/custom roles and do not represent a target tenant's assignments. |
| GET `/api/v1/admin/tenants/{tenantId}/details` | `iam:tenant:read` plus `iam:member:read` | Aggregated member/current-role projection, not all eligible roles. |
| GET `/api/v1/auth/memberships` | current-user membership menu | Current user's assigned roles only, not target-tenant candidates. |
| GET `/api/v1/admin/roles/{roleId}/permissions` | `iam:role:read`; permission bindings | No candidate discovery. |
| POST `/api/v1/admin/invitations` | `iam:member:write` | `{email,tenant_id,role_id?}`; a single optional role, not role_ids. |
| PUT `/api/v1/admin/members/{membershipId}/roles` | `iam:member:write` | `{role_ids:[...]}` replacement of DIRECT bindings; null becomes empty. |

Controller evidence: `AdminRoleController.java:49-67,96-99`; `AdminMemberController.java:65-85`; `AdminApplicationController.java:22-56`; `AdminTenantController.java:148-154`; `SwitchTenantController.java:81-84`; `AdminInvitationController.java:22-42` (all under `iam-app/src/main/java/com/unify/iam/app/adapter/controller/`). DTOs: `iam-api/src/main/java/com/unify/iam/api/dto/admin/CreateInvitationRequest.java`, `SetRolesRequest.java`.

## Existing role listing semantics
`AdminRoleService.listByScope` normalizes exact PLATFORM to platform scope; every other value becomes TENANT; missing scope_id becomes PLATFORM. It calls the scope guard before querying. Do not copy this permissive normalization into a new strict contract.

`RoleRepository.listForAdmin` (lines 59-83) returns all non-deleted roles for authorized PLATFORM requests, including foreign tenant roles and DISABLED rows; platform scope_id is not a row filter. TENANT requests constrain scope_type=TENANT and scope_id=target. Ordering is id ASC, unpaginated.

Current optional `filter_scope_type` is uppercase CSV PLATFORM/TENANT, trimmed/deduplicated OR, with empty/unknown tokens rejected. `filter_scope_id` means a TENANT ID and adds scope_type=TENANT, not an arbitrary scope ID. Keyword is a trimmed literal substring over role_name OR role_description, with escaped LIKE characters. Filter dimensions AND with the authorized base set. Therefore a target-tenant filter cannot express `(PLATFORM custom) OR (target TENANT non-Owner)`; tenant callers cannot broaden their own scope through filters.

Response data is `{roles,count}` with `count=roles.length`. Each role has role_id, role_code, role_name, optional role_description, scope_type, scope_id, optional tenant_name, role_status, boolean is_builtin/is_owner, and the existing mixed-case `permissionCounts`. Tenant names and Owner flags are batched. See `AdminRoleController.java:112-160`. Envelope is `{success:true,data:...}`; nullable envelope fields/maps may be omitted through NON_NULL (`config/ApiEnvelopeAdvice.java:23-35`, `application.yml:5`). Do not infer exact serialization from older CommonResponse comments.

## Scope, builtin and Owner rules
- `RolePO` stores scope_type, scope_id, is_builtin and role_status. Global PLATFORM convention is scope_id=PLATFORM. Creation is authorized through AdminRoleService and sets is_builtin=0, ACTIVE; there is no dedicated creator-category field. Interpret 'created by platform administrators' as scope_type=PLATFORM + canonical scope_id + is_builtin=0, not a create_by join against the creator's current privileges.
- Runtime `RoleRepository.listByScope` (lines 38-46) requires ACTIVE. Management list intentionally does not. Logical deletion comes from `BaseEntity.java:29-32` via MyBatis-Plus TableLogic.
- Tenant provisioning copies tenant templates and reuses global platform templates (`TenantAppProvisionService.java:74-118`); builtin tenant non-owner roles must not be excluded merely because is_builtin=1.
- Owner is not a literal role name/code and is not a gateway_role column. Role list resolves enabled tenant application templates with is_owner=1 and matches trimmed role_code (`AdminRoleController.java:123-159`). PLATFORM rows currently get is_owner=false. Template owner role differs from tenant.owner_user_id (person identity).
- Preserve existing Owner transfer/invitation workflows. Excluding Owner candidates does not authorize removing an existing Owner binding via replacement.

## Authorization warning
`TenantScopeGuard.java:27-45` uses a DB-backed PLATFORM-role predicate, not a JWT role name. `RoleMapper.java:17-21` counts any non-deleted PLATFORM binding; it does not check builtin flag, role code or role_status. A new custom PLATFORM grant changes scope access wherever endpoint permissions are also present. Global reuse and platform administration are currently coupled.

## Existing specifications and validation evidence
`.trellis/spec/backend/database-guidelines.md` documents management/runtime separation and recently added filters. `.trellis/tasks/11-05-role-management/{prd,design}.md` is related existing work, read only. `AdminRoleListIntegrationTest.java:58-110,145-205` covers current filtering/global/disabled/Owner behavior. These tests were inspected, not run; no runtime correctness claim is made.

package com.unify.iam.app.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.app.infra.persistence.po.AuditLogPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_audit_log Mapper。 */
@Mapper
public interface AuditLogMapper extends BaseMapper<AuditLogPO> {
}
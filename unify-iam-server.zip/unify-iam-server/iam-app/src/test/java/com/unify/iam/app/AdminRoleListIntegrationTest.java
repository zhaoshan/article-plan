package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

/** Management visibility must not broaden runtime authorization or bypass tenant guards. */
@Transactional
class AdminRoleListIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private JwtSigner signer;
    @Autowired
    private RoleRepository roles;

    private String token(boolean platform, boolean readPermission) {
        long now = Instant.now().getEpochSecond();
        // Real seeded memberships exercise the database-backed scope guard, even if role claims are forged.
        return signer.sign(new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"),
                platform ? "u-1000" : "u-1001", "tenant-org-a", platform ? "ms-1001" : "ms-2001",
                List.of("PlatformAdmin"), readPermission ? List.of("iam:role:read") : List.of(), Map.of(),
                now + 3600, now, "role-list-test", currentVer(platform ? "ms-1001" : "ms-2001")));
    }

    private void role(String id, String type, String scopeId, String state, int deleted) {
        jdbcTemplate.update("""
                INSERT INTO gateway_role (role_id, scope_type, scope_id, role_code, role_name, role_status, delete_flag)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """, id, type, scopeId, id, id, state, deleted);
    }

    /** 2026-11-09 ver 校验（方案 c 闭环）：合成 token 须携带库内当前 token_version，否则 401 TOKEN_STALE。 */
    private long currentVer(String membershipId) {
        Integer v = jdbcTemplate.queryForObject(
                "SELECT token_version FROM gateway_membership WHERE membership_id=?", Integer.class, membershipId);
        return v == null ? 0L : v;
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> list(String token, String type, String scopeId) throws Exception {
        var request = get("/api/v1/admin/roles").param("scope_type", type)
                .header("Authorization", "Bearer " + token);
        if (scopeId != null) {
            request.param("scope_id", scopeId);
        }
        String json = mockMvc.perform(request).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        Map<String, Object> data = unwrapData(json);
        List<Map<String, Object>> result = (List<Map<String, Object>>) data.get("roles");
        assertThat(((Number) data.get("count")).intValue()).isEqualTo(result.size());
        return result;
    }

    @Test
    void independentFiltersCombineWithinAuthorizedScopeAndSearchLiteralText() throws Exception {
        role("filter-a", "TENANT", "tenant-org-a", "DISABLED", 0);
        role("filter-b", "TENANT", "tenant-org-a", "ACTIVE", 0);
        role("filter-foreign", "TENANT", "filter-tenant-b", "ACTIVE", 0);
        role("filter-platform", "PLATFORM", "PLATFORM", "ACTIVE", 0);
        role("filter-deleted", "TENANT", "tenant-org-a", "ACTIVE", 1);
        jdbcTemplate.update("UPDATE gateway_role SET role_name='filter needle' WHERE role_id IN ('filter-a','filter-foreign','filter-platform','filter-deleted')");
        jdbcTemplate.update("UPDATE gateway_role SET role_name='different', role_description='has filter needle here' WHERE role_id='filter-b'");
        var request = get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(true, true))
                .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                .param("filter_scope_type", "TENANT,PLATFORM,TENANT")
                .param("filter_scope_id", "tenant-org-a").param("keyword", "filter needle");
        String json = mockMvc.perform(request).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(roleIds(json)).containsExactly("filter-a", "filter-b");
        json = mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(true, true))
                        .param("scope_type", "PLATFORM").param("filter_scope_type", "TENANT,PLATFORM")
                        .param("keyword", "filter needle"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(roleIds(json)).containsExactly("filter-a", "filter-b", "filter-foreign", "filter-platform");
        json = mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(true, true))
                        .param("scope_type", "PLATFORM").param("filter_scope_type", "PLATFORM")
                        .param("keyword", "filter needle"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(roleIds(json)).containsExactly("filter-platform");
        json = mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(false, true))
                        .param("scope_type", "TENANT").param("scope_id", "tenant-org-a")
                        .param("keyword", "filter needle"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(roleIds(json)).containsExactly("filter-a", "filter-b");
        String tenantName = jdbcTemplate.queryForObject("SELECT tenant_name FROM gateway_tenant WHERE tenant_id='tenant-org-a' AND delete_flag=0", String.class);
        assertThat(json).contains(tenantName);
        // A tenant filter cannot escape the already authorized tenant scope.
        json = mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(false, true))
                        .param("scope_type", "TENANT").param("scope_id", "tenant-org-a")
                        .param("filter_scope_id", "filter-tenant-b").param("keyword", "filter needle"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(roleIds(json)).isEmpty();
        json = mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(true, true))
                        .param("scope_type", "PLATFORM").param("filter_scope_type", "PLATFORM")
                        .param("filter_scope_id", "tenant-org-a"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(roleIds(json)).isEmpty();
        jdbcTemplate.update("UPDATE gateway_role SET role_description='literal %_! value' WHERE role_id='filter-b'");
        json = mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(true, true))
                        .param("scope_type", "PLATFORM").param("keyword", " %_! "))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        assertThat(roleIds(json)).containsExactly("filter-b");
        for (String invalid : List.of("", "tenant", "TENANT,", "PLATFORM,INVALID")) {
            mockMvc.perform(get("/api/v1/admin/roles").header("Authorization", "Bearer " + token(true, true))
                            .param("scope_type", "PLATFORM").param("filter_scope_type", invalid))
                    .andExpect(status().isBadRequest());
        }
    }

    @Test
    void deletedTenantHasNoNameWhileRoleRemainsVisibleInGlobalList() throws Exception {
        jdbcTemplate.update("UPDATE gateway_tenant SET delete_flag=1 WHERE tenant_id='tenant-org-a'");
        List<Map<String, Object>> result = list(token(true, true), "PLATFORM", "PLATFORM");
        assertThat(result).filteredOn(row -> "TENANT".equals(row.get("scope_type"))
                        && "tenant-org-a".equals(row.get("scope_id")))
                .isNotEmpty().allSatisfy(row -> assertThat(row.get("tenant_name")).isNull());
    }

    @Test
    void generatedCodeIsPersistedAndAuditedWhenHttpRequestOmitsCode() throws Exception {
        long now = Instant.now().getEpochSecond();
        String writer = signer.sign(new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"),
                "u-1000", "tenant-org-a", "ms-1001", List.of("PlatformAdmin"),
                List.of("iam:role:write"), Map.of(), now + 3600, now, "role-create-test", currentVer("ms-1001")));
        String json = mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + writer).contentType(org.springframework.http.MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"tenant-org-a\",\"role_name\":\"Generated role\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String id = unwrapData(json).get("role_id").toString();
        String code = jdbcTemplate.queryForObject("SELECT role_code FROM gateway_role WHERE role_id=?", String.class, id);
        assertThat(code).matches("role_[a-f0-9]{32}");
        String metadata = jdbcTemplate.queryForObject("SELECT metadata_json FROM gateway_audit_log WHERE event_type='ADMIN_CREATE_ROLE' AND target_id=?", String.class, id);
        assertThat(metadata).contains(code);
    }

    @SuppressWarnings("unchecked")
    private List<String> roleIds(String json) {
        List<Map<String, Object>> rows = (List<Map<String, Object>>) unwrapData(json).get("roles");
        assertThat(((Number) unwrapData(json).get("count")).intValue()).isEqualTo(rows.size());
        return rows.stream().map(r -> r.get("role_id").toString()).toList();
    }

    @Test
    void platformListsEveryNonDeletedRoleAcrossScopesIncludingDisabledWithoutPagination() throws Exception {
        role("list-platform-disabled", "PLATFORM", "PLATFORM", "DISABLED", 0);
        role("list-tenant-disabled", "TENANT", "tenant-org-a", "DISABLED", 0);
        role("list-other-tenant", "TENANT", "list-tenant-b", "ACTIVE", 0);
        role("list-deleted", "TENANT", "tenant-org-a", "ACTIVE", 1);
        for (int i = 0; i < 25; i++) {
            role("list-extra-" + i, "TENANT", "list-tenant-b", "ACTIVE", 0);
        }
        Integer expected = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_role WHERE delete_flag=0", Integer.class);
        List<Map<String, Object>> result = list(token(true, true), "PLATFORM", "PLATFORM");
        assertThat(result).hasSize(expected);
        assertThat(result).filteredOn(row -> "r-1002".equals(row.get("role_id")))
                .allSatisfy(row -> assertThat(row).containsEntry("is_owner", true));
        assertThat(result).filteredOn(row -> "r-2001".equals(row.get("role_id")))
                .allSatisfy(row -> assertThat(row).containsEntry("is_owner", false));
        assertThat(result).extracting(row -> row.get("role_id"))
                .contains("r-2001", "r-1001", "list-platform-disabled", "list-tenant-disabled", "list-other-tenant")
                .doesNotContain("list-deleted");
        assertThat(result).filteredOn(row -> "list-tenant-disabled".equals(row.get("role_id")))
                .allSatisfy(row -> assertThat(row).containsEntry("role_status", "DISABLED")
                        .containsEntry("permissionCounts", 0));
        assertThat(list(token(true, true), "PLATFORM", null)).isEqualTo(result);
        // Authorization/template callers keep the ACTIVE-only query.
        assertThat(roles.listByScope("TENANT", "tenant-org-a")).extracting(r -> r.getRoleId())
                .doesNotContain("list-tenant-disabled", "list-deleted", "list-other-tenant");
    }

    @Test
    void tenantManagementIncludesDisabledButOnlyWithinAuthorizedTenant() throws Exception {
        role("list-own-disabled", "TENANT", "tenant-org-a", "DISABLED", 0);
        role("list-own-deleted", "TENANT", "tenant-org-a", "ACTIVE", 1);
        role("list-foreign", "TENANT", "list-tenant-b", "ACTIVE", 0);
        for (boolean platform : List.of(false, true)) {
            List<Map<String, Object>> result = list(token(platform, true), "TENANT", "tenant-org-a");
            assertThat(result).allSatisfy(row -> assertThat(row)
                    .containsEntry("scope_type", "TENANT").containsEntry("scope_id", "tenant-org-a"));
            assertThat(result).extracting(row -> row.get("role_id"))
                    .contains("r-1001", "list-own-disabled")
                    .doesNotContain("r-2001", "list-own-deleted", "list-foreign");
        }
    }

    @Test
    void tenantMemberCannotForgePlatformScopeOrCrossTenantScopeEvenWithRoleReadPermission() throws Exception {
        for (String[] scope : List.of(new String[]{"PLATFORM", "PLATFORM"},
                new String[]{"PLATFORM", "tenant-org-a"}, new String[]{"TENANT", "list-tenant-b"})) {
            mockMvc.perform(get("/api/v1/admin/roles")
                            .param("scope_type", scope[0]).param("scope_id", scope[1])
                            .header("Authorization", "Bearer " + token(false, true)))
                    .andExpect(status().isForbidden());
        }
    }

    @Test
    void platformMembershipStillRequiresRoleReadPermission() throws Exception {
        mockMvc.perform(get("/api/v1/admin/roles").param("scope_type", "PLATFORM")
                        .header("Authorization", "Bearer " + token(true, false)))
                .andExpect(status().isForbidden());
    }
}

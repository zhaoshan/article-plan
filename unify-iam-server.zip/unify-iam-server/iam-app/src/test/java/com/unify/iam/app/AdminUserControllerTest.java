package com.unify.iam.app;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.adapter.controller.AdminUserController;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminUserService;
import com.unify.iam.app.config.GlobalExceptionHandler;
import com.unify.iam.app.config.WebMvcConfig;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.ManagementAuthorizationInterceptor;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(AdminUserController.class)
@Import({GlobalExceptionHandler.class, WebMvcConfig.class, ManagementAuthorizationInterceptor.class})
class AdminUserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private JwtSigner jwtSigner;
    @MockitoBean
    private UserRepository userRepository;
    @MockitoBean
    private AdminUserService adminUserService;
    @MockitoBean
    private AuditService auditService;
    @MockitoBean
    private AuditLogRepository auditLogRepository;

    private JwtClaims claims(String... permissions) {
        long now = Instant.now().getEpochSecond();
        return new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1",
                "tenant-org-a", "ms-1", List.of("PlatformAdmin"), List.of(permissions), Map.of(),
                now + 3600, now, "jti", 0L);
    }

    @Test
    void adminUsersWithoutTokenReturns401() throws Exception {
        mockMvc.perform(get("/api/v1/admin/users"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("缺少令牌")));
    }

    @Test
    void adminUsersWithoutIamPermissionReturns403() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims("agent:read")); // 无 iam:user:read

        mockMvc.perform(get("/api/v1/admin/users").header("Authorization", "Bearer t"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("缺少权限点")));
    }

    @Test
    void adminUsersWithIamPermissionReturns200() throws Exception {
        when(jwtSigner.verify("t")).thenReturn(claims(PermissionCodes.IAM_USER_READ));
        UserPO u = new UserPO();
        u.setUserId("u-1000");
        u.setUsername("admin");
        u.setPrimaryEmail("admin@unify.local");
        u.setUserStatus("ACTIVE");
        when(userRepository.search(anyInt())).thenReturn(List.of(u));
        when(auditService.audit())
                .thenReturn(new AuditService.AuditEntry(auditLogRepository)); // 真实 entry，repo mock 落库无副作用

        mockMvc.perform(get("/api/v1/admin/users").header("Authorization", "Bearer t"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(1))
                .andExpect(jsonPath("$.data.users[0].username").value("admin"))
                .andExpect(jsonPath("$.data.users[0].user_id").value("u-1000"));
    }
}
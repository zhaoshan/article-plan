# 前端交接：真实会话租户与管理路由目标

## 现有服务端契约

| 端点 | 凭据与请求 | 成功信封 data 内容 |
|---|---|---|
| POST /api/v1/auth/token | JSON username/password | access_token、refresh_token、token_type、expires_in、refresh_expires_in、user |
| GET /api/v1/auth/memberships | Authorization: Bearer access | memberships[]、count；条目 membership_id、tenant_id、tenant_name、tenant_code、membership_status、is_default |
| POST /api/v1/auth/switch-tenant | Bearer 当前 access；JSON `{"membership_id":"目标成员关系ID"}` | 与 token 相同的新 access/refresh 响应，不直接返回 tenantId/membershipId |
| GET /api/v1/auth/me | Bearer 当前 access | **平铺** camelCase userId、tenantId、membershipId、roles、permissions、attrs 与可选账号资料，不嵌套 user/profile |
| POST /api/v1/auth/refresh | JSON `{"refresh_token":"当前保存的refresh"}`；不依赖 Bearer | 与 token 相同；旧 refresh 轮换失效，新的 access/refresh 继续绑定该 refresh 原 membership |
| GET /api/v1/auth/session-status | Bearer 当前 access | snake_case tenant_id、membership_id、tenant_status、membership_status、valid（另有可用时的 tenant_code） |

- 所有成功响应统一 `{success,code,message,data}`。若 API client 已解包，消费返回值本身；不要重复取 data。
- switch 请求只支持 snake_case membership_id。camelCase membershipId 或 tenant_id 代替字段得到 400；把 tenant ID 填入 membership_id 得到 403（若不存在同 ID 的本人有效成员关系）。
- 目标必须是当前用户自己的 ACTIVE membership，且租户存在、未删除、ACTIVE；平台管理员权限不豁免 membership 归属检查。没有自己的 membership 时，管理路由导航不是会话切换。
- access JWT claims 与 /me 均使用 camelCase tenantId、membershipId。token 响应 user 只有 user_id、user_name、可选 avatar_url、roles、permissions，**没有**租户上下文字段或 tenants 列表。应以新 access 调 me 验证目标，而非在 switch 响应 user 中猜字段。
- `is_default` 返回字符串 `"1"`/`"0"`，只表示下次交互式登录的默认入口，switch 不更新它。当前选中必须关联 me.membershipId/tenantId，不能以 is_default 为当前会话判断。

## 旧凭据行为与客户端替换顺序

1. 登录 A 取得 accessA/refreshA，switch 到 B 返回 accessB/refreshB。**必须一起替换两种凭据**，再使用 accessB 请求 me。
2. accessA 仍表示 A；switch 不修改已签发 JWT，不会把旧 Bearer 隐式改为 B。
3. switch 不撤销原 refreshA。携带 refreshA 刷新会取得 A，即使同时带 Bearer accessB 也一样；携带 refreshB 则稳定得到 B。旧 refresh 的这种行为不代表 cookie/服务器缓存恢复旧租户。
4. refreshB 一次轮换后失效；后续必须保存并使用返回的下一代 refresh。异步刷新和切换应按同一会话更新顺序处理，避免旧请求完成后覆盖新凭据。此条为消费端根据现有契约应采取的处理，不是服务端已观测到的前端代码事实。
5. 服务端这组端点没有通过 Cookie/HttpSession 存放当前租户；新凭据响应不设置会话 cookie。仅 cookie 不足以调用 me。
6. 管理员打开无本人 membership 的租户管理页时，路由目标 tenant ID 与认证 me.tenantId 可以不同。侧栏管理目标展示应反映管理路由，成员会话切换仍严格使用 membership_id；不能伪造 token 租户或新建 membership 来使它们相等。

## 来源索引

- SwitchTenantController.switchTenant / memberships / toBrief
- RefreshController.refresh、RefreshTokenService.issue / rotate
- TokenService.issue / issueFor / issueWithRefresh
- AuthController.me、AuthIdentityResponse、LoginResponse、TokenUser、SwitchTenantRequest、RefreshRequest
- SessionStatusController.sessionStatus

API 手册当前第 2 节端点表将 refresh 鉴权列写为 Bearer，与 RefreshController 实际请求体鉴权不一致；以上以实际源码和运行探测为准。未编辑共享文档，避免干扰并行任务。

## 验证范围

- 8090 已运行服务：健康/认证缺失/请求字段格式/无效 refresh 的 7 项 HTTP 探测，结果记录 runtime-probes.json；这些探测不会创建业务数据。
- 全链路成功与旧凭据行为：当前源码、真实 Testcontainers MySQL/Flyway、MockMvc，与本地业务库和签名密钥隔离；使用本测试新建的事务内用户/LOCAL identity/三个租户及 membership，回滚，不修改真实用户或权限。
- 未访问前端目录，未对用户当前浏览器或真实账号进行端到端复现。前端路由根因来自主会话提供的信息；本任务独立证据限于服务端。

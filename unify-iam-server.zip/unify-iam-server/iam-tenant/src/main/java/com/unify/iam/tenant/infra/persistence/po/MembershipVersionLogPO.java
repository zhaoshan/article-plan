package com.unify.iam.tenant.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_membership_version_log 成员令牌版本变更日志 PO（方案 c 即时吊销 feed 数据源）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_membership_version_log")
public class MembershipVersionLogPO extends BaseEntity {

    /** 日志业务唯一标识 */
    private String logId;
    /** 成员关系 ID */
    private String membershipId;
    /** 租户 ID（feed app 作用域过滤） */
    private String tenantId;
    /** 变更后的 token_version（tombstone 行恒 0） */
    private Integer tokenVersion;
    /** 变更类型：ROLE_CHANGE/PERM_CHANGE/MEMBERSHIP_REMOVE */
    private String changeType;
}

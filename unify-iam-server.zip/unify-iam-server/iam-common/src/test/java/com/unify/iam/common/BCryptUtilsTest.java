package com.unify.iam.common;

import static org.assertj.core.api.Assertions.assertThat;

import com.unify.iam.common.util.BCryptUtils;
import org.junit.jupiter.api.Test;

class BCryptUtilsTest {

    @Test
    void knownHashMatches() {
        // $2y$ cost10（与 V2 seed 同规格）
        String hash = "$2y$10$rKYNH6UsTYNgjfLz2khy5O/yoazBt.R/Ak03v8o9dQ0fc9cvpwDmi";
        assertThat(BCryptUtils.matches("admin123", hash)).isTrue();
    }

    @Test
    void wrongPasswordRejected() {
        String hash = "$2y$10$rKYNH6UsTYNgjfLz2khy5O/yoazBt.R/Ak03v8o9dQ0fc9cvpwDmi";
        assertThat(BCryptUtils.matches("wrong-password", hash)).isFalse();
    }

    @Test
    void hashAndVerifyRoundTrip() {
        String hash = BCryptUtils.hash("some-secret");
        assertThat(hash).startsWith("$2");
        assertThat(BCryptUtils.matches("some-secret", hash)).isTrue();
        assertThat(BCryptUtils.matches("other", hash)).isFalse();
    }

    @Test
    void nullOrEmptyHashRejected() {
        assertThat(BCryptUtils.matches("x", null)).isFalse();
        assertThat(BCryptUtils.matches("x", "")).isFalse();
    }
}

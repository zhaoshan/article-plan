package com.unify.iam.common.util;

import java.security.SecureRandom;

/**
 * 初始密码生成（G2 邀请 JIT 建号 / Owner 邮箱开通）：16 位、含大小写字母+数字+符号，
 * 去除易混淆字符（0/O/1/l/I），邮件明文展示一次、落库 BCrypt。
 */
public final class InitialPasswords {

    private static final String LOWER = "abcdefghjkmnpqrstuvwxyz";
    private static final String UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    private static final String DIGITS = "23456789";
    private static final String SPECIAL = "@#%";
    private static final String ALL = LOWER + UPPER + DIGITS + SPECIAL;

    private InitialPasswords() {
    }

    /** 生成初始密码：保证 ≥1 小写/大写/数字/符号 + 补足随机，长度 16。 */
    public static String generate() {
        SecureRandom rng = new SecureRandom();
        StringBuilder sb = new StringBuilder(16);
        sb.append(pick(rng, LOWER)).append(pick(rng, UPPER))
                .append(pick(rng, DIGITS)).append(pick(rng, SPECIAL));
        for (int i = 4; i < 16; i++) {
            sb.append(pick(rng, ALL));
        }
        // Fisher–Yates 打散前 16 位
        char[] chars = sb.toString().toCharArray();
        for (int i = chars.length - 1; i > 0; i--) {
            int j = rng.nextInt(i + 1);
            char t = chars[i];
            chars[i] = chars[j];
            chars[j] = t;
        }
        return new String(chars);
    }

    private static char pick(SecureRandom rng, String alphabet) {
        return alphabet.charAt(rng.nextInt(alphabet.length()));
    }
}

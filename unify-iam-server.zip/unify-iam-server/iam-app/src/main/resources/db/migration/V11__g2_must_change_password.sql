-- G2：初始密码账号（邀请 JIT 建号 / Owner 邮箱开通）首登强制改密标记
ALTER TABLE `gateway_user`
  ADD COLUMN `must_change_password` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '首登必须改密（初始密码账号，G2）：登录响应透出，改密后清零' AFTER `user_status`;

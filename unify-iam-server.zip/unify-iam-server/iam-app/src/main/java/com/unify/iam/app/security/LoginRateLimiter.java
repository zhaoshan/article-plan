package com.unify.iam.app.security;

/**
 * 登录限流器（P1-02 暴力破解防护）：账号/IP 双维度失败计数 + 冷却锁定。
 *
 * <p>实现按 {@code iam.redis.enabled} 二选一：false（默认，本地/单实例）= 进程内
 * {@link InMemoryLoginRateLimiter}；true = {@link RedisLoginRateLimiter}（多副本共享计数）。
 * 判定与计数分离：控制器先 {@link #assertNotLocked}（命中锁即 429，不计数），
 * 认证结果出来后 {@link #recordFailure}/{@link #recordSuccess}。
 *
 * <p>所有实现必须 fail-safe：限流组件故障（含 Redis 宕机）不得阻断登录主链路——
 * 判定降级为放行、计数静默丢弃，并 WARN 留痕。
 */
public interface LoginRateLimiter {

    /** 登录前判定：账号或 IP 命中锁 → 429（不区分账号是否存在，防枚举）。 */
    void assertNotLocked(String username, String ip);

    /** 认证失败计数（含用户不存在——统一出口处调用，调用方无需关心账号真实性）。 */
    void recordFailure(String username, String ip);

    /** 认证成功：清零两维计数。 */
    void recordSuccess(String username, String ip);
}

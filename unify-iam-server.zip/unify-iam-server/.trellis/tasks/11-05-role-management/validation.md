# Validation and session record

Project: /Users/ramiro.li/root/apps/work/platform-iam-service
Branch: feature/lee-1102
Date: 2026-11-05 (Asia/Shanghai)

## Results
31 unique targeted tests passed with zero failures/errors/skips, including real MySQL Testcontainers. Reactor compile passed as part of Maven test. git diff --check and Trellis context validation passed. No dedicated Maven lint plugin is configured. Independent trellis-check review found no production defect; audit matrix source was synchronized, and requested stronger integration coverage was added and passed.

- AdminRoleServiceTest: 9 passed
- AdminRoleControllerTest: 11 passed
- AdminRoleListIntegrationTest: 7 passed
- AdminRolePermissionCountsIntegrationTest: 1 passed
- AdminRoleUpdateIntegrationTest: 1 passed
- RoleDeleteProtectionIntegrationTest: 2 passed

## Commands (exit 0)

```sh
JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin:$PATH mvn -q -pl iam-app -am -Dtest=AdminRoleServiceTest,AdminRoleControllerTest,AdminRoleListIntegrationTest,AdminRolePermissionCountsIntegrationTest,AdminRoleUpdateIntegrationTest -Dsurefire.failIfNoSpecifiedTests=false test
JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin:$PATH mvn -q -pl iam-app -am -Dtest=AdminRoleServiceTest,AdminRoleControllerTest,RoleDeleteProtectionIntegrationTest -Dsurefire.failIfNoSpecifiedTests=false test
JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home/bin:$PATH mvn -q -pl iam-app -am -Dtest=AdminRoleListIntegrationTest -Dsurefire.failIfNoSpecifiedTests=false test
```

## Environment and limits
Default sandbox Mockito attach and Docker socket access failed; authorized escalated execution resolved both. Tests use JDK 21 rather than the shell default JDK 26. Full repository suite and frontend checks were not run.

## Delivery state
All backend requirements implemented and documented. Work remains uncommitted at the user's explicit instruction. No push, merge, branch change/reset or worktree operation. The pre-existing untracked .trellis/tasks/archive/2026-11/11-04-console-identity-isolation directory was preserved. Task remains in_progress pending user-directed Git/archival workflow; finish-work auto-commit paths intentionally not invoked.

## Follow-up: server-side tenant_name verification

Rechecked after the user's correction about a frontend tenants-list request.
No backend product-code correction was needed: AdminRoleController.list first
loads authorized/filtered roles, calls tenantNamesForRoles, then writes each
resolved name directly into data.roles[].tenant_name via toBrief. The repository
lookup is TenantRepository.findByIds with only distinct nonblank TENANT scope IDs;
it is not an HTTP call to /admin/tenants and does not load all tenants.
PLATFORM rows never receive a tenant name even when their scope_id coincides with
a tenant ID. Missing/blank scope and missing/deleted tenant rows have no name;
the existing NON_NULL serialization omits those values.

Evidence: AdminRoleController.java lines 57-67, 112-119, 147-156;
TenantRepository.java lines 40-46. The existing
listBindsIndependentFiltersAndBatchesTenantNames HTTP test asserts two TENANT
rows receive Organization A, PLATFORM/missing/null/blank rows do not receive a
name, and exactly one findByIds call occurs without per-row findById calls.
The deletedTenantHasNoNameWhileRoleRemainsVisibleInGlobalList MySQL test covers
logical deletion. Re-inspected existing Surefire reports (controller 11/list 7,
zero failures/errors/skips); did not rerun the unchanged test suite. Other parallel
member-role-selection changes visible in git status were left untouched.

## Follow-up: running instance still uses old packaged code

Read-only process/artifact diagnosis on 2026-11-05 (Asia/Shanghai):
- Local TCP 8090 listener is Java PID 17677, started 09:23:02.
- Its cwd is this project and open application artifact is this project's
  iam-app/target/iam-app-0.0.1-SNAPSHOT.jar (mtime 09:22:38).
- Inspected the packaged BOOT-INF/classes/.../AdminRoleController.class:
  neither tenant_name nor tenantNamesForRoles exists in its bytecode constants.
- Current source includes response enrichment; target/classes controller also
  contains tenant_name and tenantNamesForRoles (class mtime 11:56:08).
- Conclusion: the local listener is using an old packaged application, while
  Maven test/compile refreshed classes but did not repackage the running JAR.
  Repackage then restart using the existing service configuration/launch method;
  restarting the same old JAR alone is insufficient.
- No service was stopped/restarted, no database query or write was performed,
  no token/password/environment secret was printed. Screenshot target host was
  not provided, so matching the browser's endpoint to local 8090 remains unverified.
  Specific scope_id tenant existence was not queried; it remains a secondary
  check only if names are absent after the correct application is deployed.

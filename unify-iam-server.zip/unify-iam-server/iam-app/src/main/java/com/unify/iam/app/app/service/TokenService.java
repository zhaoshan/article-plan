package com.unify.iam.app.app.service;

import com.unify.iam.api.dto.auth.LoginRequest;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.dto.auth.TokenUser;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.authenticator.LocalPasswordAuthenticator;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.authorization.app.model.RbacResult;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.authorization.app.service.RbacResolver;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

/**
 * 令牌签发编排（组合层）：登录 → 校验身份 → 定位成员 → 解析 RBAC → 组装 claims → 签名。
 *
 * <p>放 iam-app 而非任一域模块，避免击穿 identity/tenant/authorization 域边界；
 * 未来 SSO 换认证来源时只替换认证步骤，管线不重写。
 */
@Service
public class TokenService {

    private final LocalPasswordAuthenticator localPasswordAuthenticator;
    private final MembershipResolver membershipResolver;
    private final RbacResolver rbacResolver;
    private final JwtSigner jwtSigner;
    private final RefreshTokenService refreshTokenService;
    private final IamProperties props;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final com.unify.iam.identity.infra.persistence.repository.UserRepository userRepository;
    private final com.unify.iam.tenant.infra.persistence.repository.MembershipRepository membershipRepository;

    public TokenService(LocalPasswordAuthenticator localPasswordAuthenticator,
                        MembershipResolver membershipResolver,
                        RbacResolver rbacResolver,
                        JwtSigner jwtSigner,
                        RefreshTokenService refreshTokenService,
                        IamProperties props,
                        TenantApplicationRepository tenantApplicationRepository,
                             com.unify.iam.identity.infra.persistence.repository.UserRepository userRepository,
                             com.unify.iam.tenant.infra.persistence.repository.MembershipRepository membershipRepository) {
        this.localPasswordAuthenticator = localPasswordAuthenticator;
        this.membershipResolver = membershipResolver;
        this.rbacResolver = rbacResolver;
        this.jwtSigner = jwtSigner;
        this.refreshTokenService = refreshTokenService;
        this.props = props;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.userRepository = userRepository;
        this.membershipRepository = membershipRepository;
    }

    /**
     * 本地密码登录签发（access + refresh）。
     *
     * @throws AuthException 401（凭据无效 / 无可用成员关系）
     */
    public LoginResponse issue(LoginRequest request) {
        UserPrincipal principal = localPasswordAuthenticator.authenticate(request.username(), request.password());
        MembershipPO membership = membershipResolver.findDefaultActiveMembership(principal.userId())
                .orElseThrow(() -> AuthException.unauthorized("用户没有可用成员关系"));
        LoginResponse issued = issueWithRefresh(principal, membership);
        // G2：初始密码账号首登强制改密（透出标记，前端拦截跳改密页）
        com.unify.iam.identity.infra.persistence.po.UserPO user = userRepository.findByUserId(principal.userId())
                .orElseThrow(() -> AuthException.unauthorized("用户不存在"));
        return issued.withMustChangePassword((user.getMustChangePassword() != null && user.getMustChangePassword() == 1));
    }

    /**
     * 按已解析的用户主体与成员关系签发（dev-token / SSO / refresh 重签共用装配管线）。
     * 仅产出 access token（不含 refresh）。
     */
    public LoginResponse issueFor(UserPrincipal principal, MembershipPO membership) {
        RbacResult rbac = rbacResolver.resolve(membership.getMembershipId());
        long now = Instant.now().getEpochSecond();
        long ttl = props.getJwt().getTtlSeconds();
        // aud = 租户启用应用 ∩ 配置白名单；无应用记录的存量租户回落配置全量（docs/user-manual 03）
        List<String> aud = tenantApplicationRepository
                .findAppCodesByTenant(membership.getTenantId().trim()).stream()
                .filter(props.getJwt().getAudiences()::contains)
                .distinct()
                .toList();
        if (aud.isEmpty()) {
            aud = props.getJwt().getAudiences();
        }
        JwtClaims claims = new JwtClaims(
                props.getJwt().getIssuer(),
                aud,
                principal.userId(),
                membership.getTenantId().trim(),
                membership.getMembershipId().trim(),
                rbac.roles(),
                rbac.permissions(),
                Map.of(), // attrs 恒空（数据策略预留，E2E-1 不落库）
                now + ttl,
                now,
                IdGenerator.newBizId(),
                membership.getTokenVersion() == null ? 0 : membership.getTokenVersion());
        String token = jwtSigner.sign(claims);
        return LoginResponse.of(token, "bearer", ttl,
                new TokenUser(principal.userId(), principal.username(), claims.roles(), claims.permissions()));
    }

    /**
     * 签发 access + refresh（登录 / dev-token / SSO 入口）。
     */
    public LoginResponse issueWithRefresh(UserPrincipal principal, MembershipPO membership) {
        LoginResponse access = issueFor(principal, membership);
        String refresh = refreshTokenService.issue(principal.userId(), membership);
        // G9：登录/SSO/切换打开租户 → 刷成员级 last_opened_at（refresh 续签走 issueFor 不经过此处，天然不刷）
        membershipRepository.updateLastOpenedAt(membership.getMembershipId());
        // must_change_password 由登录/刷新/切换等入口按需 withMustChangePassword 透出（此处默认 null）
        return new LoginResponse(access.accessToken(), access.tokenType(), access.expiresIn(), access.user(),
                refresh, refreshTokenService.refreshTtlSeconds(), null);
    }
}

package com.unify.iam.app.security;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.common.exception.AuthException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 当前已认证上下文访问器：读取管理面拦截器写入 request attribute 的 claims。
 *
 * <p>仅应在受保护端点（/api/v1/admin/**）内调用；未认证/无请求上下文 → 401。
 */
public final class CurrentAuth {

    private CurrentAuth() {
    }

    public static JwtClaims claims() {
        if (!(RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs)) {
            throw AuthException.unauthorized(ErrorCode.NO_REQUEST_CONTEXT);
        }
        Object value = attrs.getRequest().getAttribute(ManagementAuthorizationInterceptor.AUTH_CLAIMS_ATTR);
        if (!(value instanceof JwtClaims claims)) {
            throw AuthException.unauthorized(ErrorCode.UNAUTHENTICATED);
        }
        return claims;
    }
}
package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.ChangePasswordRequest;
import com.unify.iam.api.dto.auth.ForgotPasswordRequest;
import com.unify.iam.api.dto.auth.RegisterRequest;
import com.unify.iam.api.dto.auth.ResetPasswordRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.app.service.ChangePasswordService;
import com.unify.iam.app.app.service.InvitationService;
import com.unify.iam.app.app.service.PasswordResetService;
import com.unify.iam.app.app.service.RegisterService;
import com.unify.iam.app.security.JwtAuth;
import com.unify.iam.app.security.JwtSigner;
import jakarta.validation.Valid;
import java.util.Map;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 登录 UI 后端（docs/04 §3.5）：注册 / 忘记密码 / 重置密码 / 接受邀请。位于 /api/v1/auth/**（公开或凭 Bearer）。
 */
@RestController
@RequestMapping("/api/v1/auth")
public class LoginUiController {

    private final RegisterService registerService;
    private final PasswordResetService passwordResetService;
    private final InvitationService invitationService;
    private final ChangePasswordService changePasswordService;
    private final JwtSigner jwtSigner;

    public LoginUiController(RegisterService registerService,
                             PasswordResetService passwordResetService,
                             InvitationService invitationService,
                             ChangePasswordService changePasswordService,
                             JwtSigner jwtSigner) {
        this.registerService = registerService;
        this.passwordResetService = passwordResetService;
        this.invitationService = invitationService;
        this.changePasswordService = changePasswordService;
        this.jwtSigner = jwtSigner;
    }

    /** 注册：建用户 + 本地身份 + 个人租户（Owner）。 */
    @PostMapping("/register")
    public Map<String, String> register(@Valid @RequestBody RegisterRequest request) {
        String userId = registerService.register(request);
        return Map.of("user_id", userId);
    }

    /** 忘记密码：生成重置令牌（dev 直接返回 token，生产走邮件）。 */
    @PostMapping("/forgot-password")
    public Map<String, String> forgotPassword(@Valid @RequestBody ForgotPasswordRequest request) {
        return passwordResetService.forgot(request.email());
    }

    /** 重置密码：校验令牌 → 改密 → 撤销旧 refresh。 */
    @PostMapping("/reset-password")
    public Map<String, String> resetPassword(@Valid @RequestBody ResetPasswordRequest request) {
        passwordResetService.reset(request.token(), request.newPassword());
        return Map.of("status", "RESET");
    }

    /** 接受邀请：凭 Bearer（受邀用户已登录），邮箱匹配则建成员 + 默认角色。 */
    @PostMapping("/invitations/{token}/accept")
    public Map<String, String> acceptInvitation(@PathVariable String token,
                                                @RequestHeader(value = "Authorization", required = false) String authorization) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        // G2 增强：redirect_url 由后端解析（app_code → homepage_url → yml → 基址兜底），前端只认它跳转
        String redirectUrl = invitationService.accept(token, claims.userId());
        return Map.of("status", "ACCEPTED", "redirect_url", redirectUrl);
    }

    /** 登录态改密（G2 首登强制改密）：校验旧密码 → 更新 → 清零 must_change_password。 */
    @PostMapping("/change-password")
    public Map<String, String> changePassword(
            @RequestHeader(value = "Authorization", required = false) String authorization,
            @Valid @RequestBody ChangePasswordRequest request) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        changePasswordService.change(claims.userId(), request.oldPassword(), request.newPassword());
        return Map.of("status", "CHANGED");
    }
}

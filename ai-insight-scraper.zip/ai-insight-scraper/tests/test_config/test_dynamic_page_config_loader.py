"""load_dynamic_page_config 配置加载测试"""

import pytest
from src.config.dynamic_page_config import load_dynamic_page_config


class TestLoadDynamicPageConfig:
    """动态页面配置加载测试"""

    def test_found_by_site_and_page_type(self, sample_config_dir):
        """按 site + page_type 找到配置"""
        entry = load_dynamic_page_config(
            "tokyostarbank.co.jp", "faq", config_dir=sample_config_dir
        )
        assert entry is not None
        assert entry.script_name == "faq_crawler"
        assert entry.parent_link == "https://support.tokyostarbank.co.jp/"
        assert "support.tokyostarbank.co.jp" in entry.entry_url

    def test_unknown_site_returns_none(self, sample_config_dir):
        """未知站点返回 None"""
        entry = load_dynamic_page_config(
            "unknown.com", "faq", config_dir=sample_config_dir
        )
        assert entry is None

    def test_unknown_page_type_returns_none(self, sample_config_dir):
        """未知页面类型返回 None"""
        entry = load_dynamic_page_config(
            "tokyostarbank.co.jp", "unknown_type", config_dir=sample_config_dir
        )
        assert entry is None

package com.unify.iam.app.app.service;

import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.infra.persistence.repository.InvitationRepository;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.infra.persistence.po.QuotaDimensionPO;
import com.unify.iam.authorization.infra.persistence.po.TenantQuotaPO;
import com.unify.iam.authorization.infra.persistence.repository.QuotaDimensionRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantQuotaRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * G1 Usage 配额模型（docs/requirements/M10W4-W5 §G1）：模板驱动——
 * {@code gateway_quota_dimension}（维度注册/默认上限）+ {@code gateway_tenant_quota}（租户调额覆盖，无行=默认）。
 *
 * <p>用量：{@code source=IAM} 维度由 IAM 实时计数（members=ACTIVE 成员数、apps=启用应用数）并强制；
 * {@code source=BUSINESS} 维度 IAM 只存上限（上限展示/下发，用量业务上报）。剩余席位 = limit − used − pending。
 */
@Service
public class QuotaService {

    public static final String KEY_MEMBERS = "members";
    public static final String KEY_APPS = "apps";

    private final QuotaDimensionRepository dimensionRepository;
    private final TenantQuotaRepository tenantQuotaRepository;
    private final MembershipRepository membershipRepository;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final InvitationRepository invitationRepository;
    private final TenantScopeGuard tenantScopeGuard;
    private final AuditService auditService;

    public QuotaService(QuotaDimensionRepository dimensionRepository,
                        TenantQuotaRepository tenantQuotaRepository,
                        MembershipRepository membershipRepository,
                        TenantApplicationRepository tenantApplicationRepository,
                        InvitationRepository invitationRepository,
                        TenantScopeGuard tenantScopeGuard,
                        AuditService auditService) {
        this.dimensionRepository = dimensionRepository;
        this.tenantQuotaRepository = tenantQuotaRepository;
        this.membershipRepository = membershipRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.invitationRepository = invitationRepository;
        this.tenantScopeGuard = tenantScopeGuard;
        this.auditService = auditService;
    }

    /** 租户 Usage 视图：全局 iam 维度 + 该租户已启用应用的专属维度（A-03 抽屉 / 06 成员管理配额条）。 */
    public Map<String, Object> usage(JwtClaims claims, String tenantId) {
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        String tid = tenantId.trim();
        // 配额跟随开通的应用：仅取该租户已启用应用的维度（iam 维度仅对显式启用 iam 应用的租户生效，如平台管理租户）
        Set<String> appCodes = new HashSet<>(tenantApplicationRepository.findAppCodesByTenant(tid));
        List<Map<String, Object>> rows = new ArrayList<>();
        for (QuotaDimensionPO dim : dimensionRepository.listByAppCodes(appCodes)) {
            rows.add(row(tid, dim));
        }
        return Map.of("tenant_id", tid, "usage", rows);
    }

    /** 设置/清除租户级调额（limitValue=null → 删覆盖回落默认）。返回该维度最新行。 */
    @Transactional
    public Map<String, Object> setLimit(JwtClaims claims, String tenantId, String dimensionId, Integer limitValue) {
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        if (limitValue != null && limitValue < 0) {
            throw AuthException.badRequest("limit_value 不能为负数");
        }
        QuotaDimensionPO dim = dimensionRepository.findById(dimensionId.trim())
                .orElseThrow(() -> AuthException.notFound("配额维度不存在"));
        String tid = tenantId.trim();
        if (limitValue == null) {
            tenantQuotaRepository.deleteByTenantAndDimension(tid, dim.getDimensionId());
        } else {
            TenantQuotaPO po = tenantQuotaRepository
                    .findByTenantAndDimension(tid, dim.getDimensionId())
                    .orElse(null);
            if (po == null) {
                po = new TenantQuotaPO();
                po.setTenantQuotaId(IdGenerator.newBizId());
                po.setTenantId(tid);
                po.setDimensionId(dim.getDimensionId().trim());
                po.setLimitValue(limitValue);
                tenantQuotaRepository.insert(po);
            } else {
                po.setLimitValue(limitValue);
                tenantQuotaRepository.update(po);
            }
        }
        auditService.audit().event("ADMIN_SET_TENANT_QUOTA").actor(claims.userId())
                .tenant(tid).target("TENANT", tid)
                .write(Map.of("dimension_id", dim.getDimensionId().trim(), "limit_value", String.valueOf(limitValue)));
        return row(tid, dim);
    }

    /** 成员席位强制（邀请/加成员前）：所有适用 members 维度（iam 全局 + 已启用应用专属）逐一校验，最严者生效。 */
    public void assertMemberSeat(String tenantId) {
        String tid = tenantId.trim();
        long used = membershipRepository.countActiveByTenant(tid);
        long pending = invitationRepository.countPendingWithoutMembership(tid);
        for (QuotaDimensionPO dim : applicableDimensions(tid, KEY_MEMBERS)) {
            int limit = effectiveLimit(tid, dim);
            if (used + pending >= limit) {
                throw AuthException.badRequest("成员席位不足：" + dim.getDimensionName() + "（" + dim.getAppCode()
                        + "）已达配额上限 " + limit + "（含 " + pending + " 个待接受邀请）");
            }
        }
    }

    /** 应用数强制（建租户选 app_codes 时）：所有适用 apps 维度逐一校验。 */
    public void assertAppCount(String tenantId, int appCount) {
        String tid = tenantId.trim();
        for (QuotaDimensionPO dim : applicableDimensions(tid, KEY_APPS)) {
            int limit = effectiveLimit(tid, dim);
            if (appCount > limit) {
                throw AuthException.badRequest("应用数超限：" + dim.getDimensionName() + "（" + dim.getAppCode()
                        + "）上限 " + limit + "，本次选择 " + appCount + " 个");
            }
        }
    }

    /** 适用维度：dimension_key 匹配且 app_code ∈ 租户已启用应用（与 Usage 视图同口径；iam 维度仅在租户启用 iam 应用时适用）。 */
    private List<QuotaDimensionPO> applicableDimensions(String tenantId, String dimensionKey) {
        Set<String> appCodes = new HashSet<>(tenantApplicationRepository.findAppCodesByTenant(tenantId));
        return dimensionRepository.listByAppCodes(appCodes).stream()
                .filter(d -> dimensionKey.equals(d.getDimensionKey()))
                .filter(d -> d.getDefaultLimit() != null)
                .toList();
    }

    private int effectiveLimit(String tenantId, QuotaDimensionPO dim) {
        return tenantQuotaRepository
                .findByTenantAndDimension(tenantId, dim.getDimensionId().trim())
                .map(TenantQuotaPO::getLimitValue)
                .orElse(dim.getDefaultLimit());
    }

    /** 单行视图：limit（生效上限）/default_limit/override/used/pending/remaining。 */
    private Map<String, Object> row(String tenantId, QuotaDimensionPO dim) {
        String did = dim.getDimensionId().trim();
        Integer override = tenantQuotaRepository
                .findByTenantAndDimension(tenantId, did)
                .map(TenantQuotaPO::getLimitValue)
                .orElse(null);
        Integer limit = override != null ? override : dim.getDefaultLimit();

        long used = 0;
        long pending = 0;
        if ("IAM".equals(dim.getSource())) {
            if (KEY_MEMBERS.equals(dim.getDimensionKey())) {
                used = membershipRepository.countActiveByTenant(tenantId);
                pending = invitationRepository.countPendingWithoutMembership(tenantId);
            } else if (KEY_APPS.equals(dim.getDimensionKey())) {
                used = tenantApplicationRepository.findAppCodesByTenant(tenantId).size();
            }
        }

        Map<String, Object> r = new LinkedHashMap<>();
        r.put("dimension_id", did);
        r.put("app_code", dim.getAppCode());
        r.put("dimension_key", dim.getDimensionKey());
        r.put("dimension_name", dim.getDimensionName());
        r.put("unit", dim.getUnit());
        r.put("source", dim.getSource());
        r.put("default_limit", dim.getDefaultLimit());
        r.put("limit", limit);
        r.put("override", override != null);
        r.put("used", "IAM".equals(dim.getSource()) ? used : null);
        r.put("pending", "IAM".equals(dim.getSource()) && KEY_MEMBERS.equals(dim.getDimensionKey()) ? pending : null);
        r.put("remaining", limit == null ? null : Math.max(0, limit - used - pending));
        return r;
    }
}

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.security.RedisLoginRateLimiter;
import com.unify.iam.common.exception.AuthException;
import java.time.Duration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

/** Redis 版登录限流器单元测试（mock StringRedisTemplate）：锁判定、阈值置锁、故障降级放行。 */
class RedisLoginRateLimiterTest {

    private StringRedisTemplate redis;
    private ValueOperations<String, String> ops;
    private RedisLoginRateLimiter limiter;

    @BeforeEach
    void setup() {
        redis = mock(StringRedisTemplate.class);
        ops = mock(ValueOperations.class);
        when(redis.opsForValue()).thenReturn(ops);
        IamProperties props = new IamProperties();
        props.getRedis().setEnv("test");
        props.getLoginRateLimit().setMaxFailures(3);
        props.getLoginRateLimit().setLockSeconds(600);
        props.getLoginRateLimit().setIpMaxFailures(20);
        props.getLoginRateLimit().setIpLockSeconds(900);
        limiter = new RedisLoginRateLimiter(props, redis);
    }

    @Test
    void lockedAccountRejectedWith429() {
        when(redis.hasKey("test:iam:login:rl:acct:alice")).thenReturn(true);
        assertThatThrownBy(() -> limiter.assertNotLocked("alice", "1.2.3.4"))
                .isInstanceOf(AuthException.class)
                .extracting("httpStatus").isEqualTo(429);
    }

    @Test
    void unlockedWhenNoKeys() {
        when(redis.hasKey(anyString())).thenReturn(false);
        limiter.assertNotLocked("alice", "1.2.3.4"); // 不抛异常
    }

    @Test
    void thresholdSetsLockWithTtlAndClearsCounter() {
        when(ops.increment(anyString())).thenReturn(1L); // 默认：IP 维度未达阈值
        when(ops.increment("test:iam:login:rl:acct:alice:fail")).thenReturn(3L); // 账号维度第 3 次
        limiter.recordFailure("alice", "1.2.3.4");
        verify(ops).set(eq("test:iam:login:rl:acct:alice"), eq("1"), eq(Duration.ofSeconds(600)));
        verify(redis).delete("test:iam:login:rl:acct:alice:fail");
    }

    @Test
    void redisFailureDegradesToPassOnCheckAndSkipsRecord() {
        when(redis.hasKey(anyString())).thenThrow(new RuntimeException("connection refused"));
        limiter.assertNotLocked("alice", "1.2.3.4"); // 降级放行，不阻断登录
        when(ops.increment(anyString())).thenThrow(new RuntimeException("connection refused"));
        limiter.recordFailure("alice", "1.2.3.4");   // 静默丢弃
        verify(ops, never()).set(anyString(), any(), any(Duration.class));
    }

    @Test
    void successDeletesAllFourKeys() {
        limiter.recordSuccess("alice", "1.2.3.4");
        verify(redis).delete(java.util.List.of(
                "test:iam:login:rl:acct:alice:fail", "test:iam:login:rl:acct:alice",
                "test:iam:login:rl:ip:1.2.3.4:fail", "test:iam:login:rl:ip:1.2.3.4"));
    }
}

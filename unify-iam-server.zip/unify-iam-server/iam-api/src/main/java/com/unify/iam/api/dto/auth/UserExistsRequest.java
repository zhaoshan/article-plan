package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 邮箱存在性判定请求（G8 服务间）：{@code POST /api/v1/auth/user-exists}。 */
public record UserExistsRequest(
        @NotBlank(message = "email 不能为空") @JsonProperty("email") String email) {
}

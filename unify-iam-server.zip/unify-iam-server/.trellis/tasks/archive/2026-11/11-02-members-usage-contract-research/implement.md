# Research execution plan

1. Locate both endpoint declarations and all references to `/usage` and usage DTOs.
2. Trace controller/service authorization, tenant scoping, aggregation, and error paths.
3. Inspect dimension definitions, quota storage, unlimited markers, and tests/fixtures.
4. Write `research/backend-tenant-usage-contract.md` with exact evidence and frontend recommendation.
5. Run read-only validation (`git diff --check`, repository status, and targeted searches) and record results.

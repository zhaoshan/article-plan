package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_membership_role 成员与角色关联表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_membership_role")
public class MembershipRolePO extends BaseEntity {

    /** 成员角色关系业务唯一标识 */
    private String membershipRoleId;
    /** 成员关系 ID */
    private String membershipId;
    /** 角色 ID */
    private String roleId;
    /** 授予来源：DIRECT/GROUP/IDP_SYNC */
    private String grantSource;
}

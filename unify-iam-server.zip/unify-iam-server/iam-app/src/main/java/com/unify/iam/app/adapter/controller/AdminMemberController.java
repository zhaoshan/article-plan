package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateMemberRequest;
import com.unify.iam.api.dto.admin.SetRolesRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.admin.AdminMemberService;
import com.unify.iam.app.app.service.admin.TenantMemberQueryService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：成员 CRUD（iam:member:*）。 */
@RestController
@RequestMapping("/api/v1/admin/members")
public class AdminMemberController {

    private final AdminMemberService adminMemberService;
    private final AuditService auditService;
    private final TenantMemberQueryService memberQuery;

    public AdminMemberController(AdminMemberService adminMemberService, AuditService auditService,
                                 TenantMemberQueryService memberQuery) {
        this.adminMemberService = adminMemberService;
        this.auditService = auditService;
        this.memberQuery = memberQuery;
    }

    @GetMapping
    @RequirePermission(PermissionCodes.IAM_MEMBER_READ)
    public Map<String, Object> list(@RequestParam(name = "scope_type", required = false) String scopeType,
                                    @RequestParam(name = "scope_id", required = false) String scopeId,
                                    @RequestParam(name = "tenant_id", required = false) String legacyTenantId,
                                    @RequestParam(name = "keyword", required = false) String keyword,
                                    @RequestParam(name = "owner_candidates", defaultValue = "false") boolean ownerCandidates,
                                    @RequestParam(name = "membership_status", required = false) String membershipStatus,
                                    @RequestParam(name = "status", required = false) String unsupportedStatus,
                                    @RequestParam(name = "limit", defaultValue = "1000") int limit) {
        return memberQuery.search(CurrentAuth.claims(), scopeType, scopeId, legacyTenantId,
                keyword, ownerCandidates, membershipStatus, unsupportedStatus, limit);
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> add(@Valid @RequestBody CreateMemberRequest request) {
        String membershipId = adminMemberService.add(CurrentAuth.claims(), request);
        auditService.audit().event("ADMIN_ADD_MEMBER").actor(CurrentAuth.claims().userId())
                .target("MEMBERSHIP", membershipId).result("SUCCESS").tenant(request.tenantId())
                .write(Map.of("user_id", request.userId()));
        return Map.of("membership_id", membershipId);
    }

    @PutMapping("/{membershipId}/roles")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> setRoles(@PathVariable String membershipId,
                                        @Valid @RequestBody SetRolesRequest request) {
        adminMemberService.setRoles(CurrentAuth.claims(), membershipId, request);
        return Map.of("membership_id", membershipId);
    }

    @GetMapping("/{membershipId}/roles")
    @RequirePermission(PermissionCodes.IAM_MEMBER_READ)
    public Map<String, Object> getRoles(@PathVariable String membershipId) {
        List<Map<String, String>> roles = adminMemberService.getRoles(CurrentAuth.claims(), membershipId).stream()
                .map(r -> {
                    Map<String, String> m = new LinkedHashMap<>();
                    m.put("role_id", r.getRoleId());
                    m.put("role_code", r.getRoleCode());
                    m.put("role_name", r.getRoleName());
                    return m;
                })
                .toList();
        return Map.of("roles", roles, "count", roles.size());
    }

    @PostMapping("/{membershipId}/suspend")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> suspend(@PathVariable String membershipId) {
        adminMemberService.suspend(CurrentAuth.claims(), membershipId);
        return Map.of("membership_id", membershipId);
    }

    @PostMapping("/{membershipId}/restore")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> restore(@PathVariable String membershipId) {
        adminMemberService.restore(CurrentAuth.claims(), membershipId);
        return Map.of("membership_id", membershipId);
    }

    @DeleteMapping("/{membershipId}")
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    public Map<String, String> remove(@PathVariable String membershipId) {
        adminMemberService.remove(CurrentAuth.claims(), membershipId); // 审计在 service 层（含 tenant_id）
        return Map.of("membership_id", membershipId);
    }

}

package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;

/** 更新用户资料/状态（不含密码；改密走找回流程）。 */
public record UpdateUserRequest(
        String email,
        @JsonProperty("full_name") String fullName,
        @JsonProperty("display_name") String displayName,
        @JsonProperty("user_status") String userStatus) {
}

"""链接查询请求/响应模型"""

from pydantic import BaseModel, Field, field_validator


class LinkQueryRequest(BaseModel):
    """已爬取数据链接查询请求参数"""

    model_config = {"extra": "forbid", "str_strip_whitespace": True}

    url: str = Field(
        ...,
        description="站点 URL（用于解析站点域名）",
        min_length=1,
        max_length=2048,
    )
    search: str = Field(
        default="",
        description="模糊匹配关键词，对 url/page_title 做 LIKE 匹配，空则不过滤",
        max_length=256,
    )
    limit: int = Field(
        default=5000,
        ge=1,
        le=50000,
        description="返回链接条数上限",
    )

    @field_validator("url")
    @classmethod
    def validate_url_scheme(cls, v: str) -> str:
        """校验 URL 必须以 http:// 或 https:// 开头"""
        if not v.startswith(("http://", "https://")):
            raise ValueError("url 必须以 http:// 或 https:// 开头")
        return v

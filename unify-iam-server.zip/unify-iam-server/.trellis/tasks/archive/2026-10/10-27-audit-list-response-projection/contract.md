# GET /api/v1/admin/audit 响应契约

标准信封及 `data:{audits,total,page,size}` 不变。`audits[]` 显式投影：

`audit_log_id, tenant_id, tenant_name, actor_user_id, actor_username, actor_membership_id,
event_type, event_name, target_type, target_id, target_display, result_status,
metadata_json, trace_id, create_time`。

`user_agent, ip_address, request_id, before_json, after_json` 无论存储是否有值，均不作为列表项键返回。
采集、写库、列和历史值继续保留；列表 SELECT 同样排除这五列。`metadata_json` 仍返回 JSON 文本字符串。
其余可空字段按全局 non_null 省略，tenant_name/事件名/操作者/目标富化保留。

授权仍为 `iam:audit:read`，无令牌 401、无权限 403。重复 `tenant_ids` 的 OR 集合与其他过滤 AND，
旧 tenant_id 兼容、Asia/Shanghai 日期自然日、keyword、排序 create_time/id 倒序、分页和 total 不变。
localhost:5174 代理消费同一后端响应，本任务不访问或修改前端项目。

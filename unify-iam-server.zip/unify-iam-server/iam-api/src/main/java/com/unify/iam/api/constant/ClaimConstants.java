package com.unify.iam.api.constant;

/** JWT 契约常量（E2E-1 范围文档 §4.1/§4.3）。 */
public final class ClaimConstants {

    private ClaimConstants() {
    }

    /** 默认签发 issuer（parlant 配置 JWT_ISSUER 指向它时启用 iss 校验） */
    public static final String DEFAULT_ISSUER = "https://www.identityfabric.com";

    /** 默认 audience：parlant-agent-server（parlant GatewayProvider 默认按此校验 aud） */
    public static final String DEFAULT_AUDIENCE = "parlant-agent-server";

    /** 固定 kid（E2E-1 不轮换） */
    public static final String DEFAULT_KID = "iam-key-1";

    /** 默认令牌有效期（秒）= 2h */
    public static final long DEFAULT_TTL_SECONDS = 7200L;

    /** JWT 算法 */
    public static final String ALG_RS256 = "RS256";
}

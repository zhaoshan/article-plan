package com.unify.iam.app.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_audit_log 审计日志表 PO（P3 起步，粗粒度）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_audit_log")
public class AuditLogPO extends BaseEntity {

    private String auditLogId;
    private String tenantId;
    private String actorUserId;
    private String actorMembershipId;
    private String eventType;
    private String targetType;
    private String targetId;
    private String resultStatus;
    private String traceId;
    private String requestId;
    private String ipAddress;
    private String userAgent;
    private String beforeJson;
    private String afterJson;
    private String metadataJson;
}
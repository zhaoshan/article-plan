# Trellis 批量归档记录

项目：`/Users/ramiro.li/root/apps/work/platform-iam-service`
分支：`feature/v0.10.5-m10w5`

成功归档 24 个目录；无法归档 4 个。未归档列表不为空，剩余 4 个。

使用项目官方 `task.py archive <name> --no-commit`；未绕过分支门禁，未暂存、提交、切换、重置、合并、推送或操作 worktree。

归档目录：`.trellis/tasks/archive/2026-10/`。原始 task.json、原始状态及逐文件 SHA-256 见 before.json；命令及完整拒绝原因见 results.json。

24 个归档目录含 21 个原 completed、1 个原 awaiting_confirmation、2 个缺少 task.json 的记录目录。后两者由官方脚本原样移动，没有编造 task.json。待确认任务根据用户清理全部任务的指令结束跟进并归档；脚本 completed 仅表示生命周期关闭，不代表未完成设计或验收已通过。

## 原始未归档清单

| 任务目录 | 原始状态 | 本次结果 |
| --- | --- | --- |
| 10-20-local-java-service-startup | in_progress | 门禁阻止，原地保留 |
| 10-23-iam-real-page-api-corrigendum | completed | 门禁阻止，原地保留 |
| 10-23-login-identifier-reset-flow-design | awaiting_confirmation | 门禁阻止，原地保留 |
| 10-23-restart-local-mysql | completed | 门禁阻止，原地保留 |
| 10-24-my-identity-fields | completed | 归档 |
| 10-26-admin-user-password-reset-contract | completed | 归档 |
| 10-26-audit-query-filters | completed | 归档 |
| 10-26-session-avatar-contract | completed | 归档 |
| 10-26-tenant-detail-owner-quota-contract | completed | 归档 |
| 10-26-tenant-list-api-and-ui-remediation | awaiting_confirmation | 归档 |
| 10-26-users-email-update-api-audit | completed | 归档 |
| 10-27-admin-user-update-pending | completed | 归档 |
| 10-27-audit-list-response-projection | completed | 归档 |
| 10-27-audit-multi-tenant-filter-contract | completed | 归档 |
| 10-27-audit-response-field-investigation | completed | 归档 |
| 10-27-member-invitation-mail-contract | completed | 归档 |
| 10-27-member-list-email-verification | completed | 归档 |
| 10-27-role-basic-info-update-contract | completed | 归档 |
| 10-27-self-membership-tenant-code | completed | 归档 |
| 10-27-switch-tenant-session-verification | completed | 归档 |
| 10-27-tenant-detail-members-contract | completed | 归档 |
| 10-27-tenant-member-search-projection | completed | 归档 |
| 10-27-tenant-owner-invite-provisioning-contract | completed | 归档 |
| 10-28-members-page-contract-investigation | completed | 归档 |
| 10-29-local-db-rebuild | completed | 归档 |
| 10-29-login-service-token | missing task.json | 归档 |
| 10-29-role-permission-counts | completed | 归档 |
| 10-29-roles-restart | missing task.json | 归档 |

## 无法归档的任务

- `10-20-local-java-service-startup`：in_progress，branch 为空、base_branch=main，仓库存在 remote，归档门禁拒绝缺失工作分支。
- `10-23-iam-real-page-api-corrigendum`：completed，branch 与 base_branch 都为 main，归档门禁拒绝。
- `10-23-login-identifier-reset-flow-design`：awaiting_confirmation，branch 与 base_branch 都为 main，归档门禁拒绝；原设计确认项继续保留。
- `10-23-restart-local-mysql`：completed，branch 与 base_branch 都为 main，归档门禁拒绝。

## 核对

核对 152 个任务文件；除归档脚本更新 status/completedAt 外，文件内容与文件集合一致。全部原始元数据已保留。
归档范围以外的已有文件内容变化：0；HEAD 与分支未变。
工作区仍有未提交变化：127 个已跟踪修改、45 个未跟踪条目（git status 默认目录折叠统计）。
现有业务配置 `iam-app/src/main/resources/application.yml` 和其他既有未提交变更均保留。归档移动与本报告均未提交。

校验异常：0。

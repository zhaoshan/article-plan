package com.unify.iam.app.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_join_request 加入租户申请表 PO（P3）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_join_request")
public class JoinRequestPO extends BaseEntity {

    private String joinRequestId;
    private String tenantId;
    private String userId;
    private String email;
    private String requestSource;
    private String requestStatus;
    private String requestReason;
    private String reviewedByUserId;
    private String reviewNote;
    private LocalDateTime reviewedAt;
}

package com.unify.iam.app.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.app.infra.persistence.mapper.InvitationMapper;
import com.unify.iam.app.infra.persistence.po.InvitationPO;
import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** 租户邀请仓储。 */
@Repository
public class InvitationRepository {

    private final InvitationMapper mapper;

    public InvitationRepository(InvitationMapper mapper) {
        this.mapper = mapper;
    }

    public void insert(InvitationPO po) {
        mapper.insert(po);
    }

    public void update(InvitationPO po) {
        mapper.updateById(po);
    }

    /** G1：待接受邀请数——排除「邮箱对应账号已在该租户有 ACTIVE 成员」的邀请（JIT 邀请即建成员，避免重复计席位）。 */
    public long countPendingWithoutMembership(String tenantId) {
        return mapper.selectCount(new LambdaQueryWrapper<InvitationPO>()
                .eq(InvitationPO::getTenantId, tenantId)
                .eq(InvitationPO::getInvitationStatus, "PENDING")
                .apply("NOT EXISTS (SELECT 1 FROM gateway_user u JOIN gateway_membership m ON m.user_id = u.user_id "
                        + "WHERE m.tenant_id = {0} AND m.membership_status = 'ACTIVE' "
                        + "AND LOWER(TRIM(u.primary_email)) = LOWER(email))", tenantId));
    }

    /** 按令牌哈希查待接受、未过期的邀请。 */
    public Optional<InvitationPO> findByHashPending(String hash) {
        return Optional.ofNullable(mapper.selectOne(new LambdaQueryWrapper<InvitationPO>()
                        .eq(InvitationPO::getInviteTokenHash, hash)
                        .eq(InvitationPO::getInvitationStatus, "PENDING")
                        .gt(InvitationPO::getExpiresAt, LocalDateTime.now())));
    }
}

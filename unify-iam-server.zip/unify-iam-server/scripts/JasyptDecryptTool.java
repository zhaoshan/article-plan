import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.iv.RandomIvGenerator;
import org.jasypt.salt.RandomSaltGenerator;

/**
 * jasypt 解密工具（P1-06 排障用）——与 IAM 应用内 IdpSecretCipher 同一加密体系：
 * StandardPBEStringEncryptor 参数与 jasypt-spring-boot 4.x 的 StringEncryptor Bean
 * 完全一致（PBEWithMD5AndDES / 1000 迭代 / RandomSaltGenerator / RandomIvGenerator / base64 输出）。
 * 注意 4.x 默认 IV 生成器已从 3.x 的 NoIvGenerator 改为 RandomIvGenerator——我们 yml 未显式
 * 覆盖 iv-generator-classname，故跟随 4.x 默认（带 IV，密文比 3.x 长 8 字节）；这是与 jasypt
 * 官方 CLI 及 3.x 习惯配置解不通的根因。
 *
 * 不要直接用 jasypt 官方 CLI（org.jasypt.intf.cli.JasyptPBEStringDecryptionCLI）——
 * 其默认装配与 jasypt-spring-boot 4.x 的 Bean 参数存在差异，同密钥会解出乱码（2026-11-11 实测）。
 *
 * 用法： java -cp <classpath> JasyptDecryptTool <密文> <JASYPT_ENCRYPTOR_PASSWORD>
 * 包装脚本：scripts/jasypt-decrypt.sh <密文>   （密码从环境变量 JASYPT_ENCRYPTOR_PASSWORD 读，勿贴命令行历史）
 */
public class JasyptDecryptTool {

    public static void main(String[] args) {
        if (args.length < 2 || args[0].isBlank() || args[1].isBlank()) {
            System.err.println("usage: JasyptDecryptTool <ciphertext> <jasypt-password>");
            System.exit(1);
        }
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(args[1]);
        encryptor.setAlgorithm("PBEWithMD5AndDES");
        encryptor.setKeyObtentionIterations(1000);
        encryptor.setSaltGenerator(new RandomSaltGenerator());
        encryptor.setIvGenerator(new RandomIvGenerator());
        encryptor.setStringOutputType("base64");
        System.out.println(encryptor.decrypt(args[0]));
    }
}

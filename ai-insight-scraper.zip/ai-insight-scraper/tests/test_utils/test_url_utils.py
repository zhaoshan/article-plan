"""url_utils 工具函数测试"""

import pytest
from src.utils.url_utils import (
    normalize_url,
    get_domain,
    is_same_domain,
    is_crawlable_url,
    is_valid_url_for_collection,
    is_valid_url,
    resolve_url,
    NON_CRAWLABLE_EXTENSIONS,
    KEEP_WWW_DOMAINS,
)


class TestNormalizeUrl:
    """normalize_url 测试"""

    def test_removes_query_params(self):
        """移除查询参数"""
        result = normalize_url("https://example.com/page?a=1&b=2")
        assert result == "https://example.com/page"

    def test_removes_hash(self):
        """移除哈希"""
        result = normalize_url("https://example.com/page#section")
        assert result == "https://example.com/page"

    def test_removes_trailing_slash(self):
        """移除末尾斜杠"""
        result = normalize_url("https://example.com/page/")
        assert result == "https://example.com/page"

    def test_removes_www_prefix(self):
        """移除 www 前缀"""
        result = normalize_url("https://www.example.com/page")
        assert result == "https://example.com/page"

    def test_lowercase(self):
        """统一为小写"""
        result = normalize_url("https://EXAMPLE.COM/Page")
        assert result == "https://example.com/page"

    def test_keeps_www_for_special_domains(self):
        """保留特定域名的 www 前缀"""
        result = normalize_url("https://www.tokyostarbank.co.jp/page")
        assert result == "https://www.tokyostarbank.co.jp/page"

    def test_non_http_unchanged(self):
        """非 http 协议不做标准化"""
        result = normalize_url("ftp://example.com/file")
        assert result == "ftp://example.com/file"

    @pytest.mark.parametrize("url_a,url_b", [
        ("https://example.com/page?a=1", "https://example.com/page?b=2"),
        ("https://example.com/page/", "https://example.com/page"),
        ("https://www.example.com/page", "https://example.com/page"),
        ("https://EXAMPLE.com/page", "https://example.com/page"),
    ])
    def test_equivalent_urls_normalize_to_same(self, url_a: str, url_b: str):
        """等价 URL 标准化后应相同"""
        assert normalize_url(url_a) == normalize_url(url_b)


class TestGetDomain:
    """get_domain 测试"""

    def test_extracts_domain(self):
        """提取域名"""
        assert get_domain("https://example.com/page") == "example.com"

    def test_removes_www(self):
        """移除 www"""
        assert get_domain("https://www.example.com/page") == "example.com"

    def test_non_http_returns_none(self):
        """非 http 协议返回 None"""
        assert get_domain("ftp://example.com/file") is None

    def test_subdomain_preserved(self):
        """子域名保留"""
        assert get_domain("https://sub.example.com/page") == "sub.example.com"


class TestIsSameDomain:
    """is_same_domain 测试"""

    def test_exact_match(self):
        """精确匹配"""
        assert is_same_domain("https://example.com/page", "example.com") is True

    def test_subdomain_match(self):
        """子域名匹配"""
        assert is_same_domain("https://sub.example.com/page", "example.com") is True

    def test_different_domain(self):
        """不同域名"""
        assert is_same_domain("https://other.com/page", "example.com") is False

    def test_none_target_domain(self):
        """目标域名为 None 时全部通过"""
        assert is_same_domain("https://example.com/page", None) is True

    def test_www_variant_match(self):
        """www 变体匹配"""
        assert is_same_domain("https://www.example.com/page", "example.com") is True


class TestIsCrawlableUrl:
    """is_crawlable_url 测试"""

    def test_html_is_crawlable(self):
        """HTML 页面可爬取"""
        assert is_crawlable_url("https://example.com/page.html") is True

    def test_pdf_is_not_crawlable(self):
        """PDF 文件不可爬取"""
        assert is_crawlable_url("https://example.com/doc.pdf") is False

    def test_non_http_not_crawlable(self):
        """非 http 协议不可爬取"""
        assert is_crawlable_url("ftp://example.com/file.html") is False

    def test_images_not_crawlable(self):
        """图片不可爬取"""
        assert is_crawlable_url("https://example.com/photo.jpg") is False
        assert is_crawlable_url("https://example.com/icon.png") is False

    def test_archives_not_crawlable(self):
        """压缩包不可爬取"""
        assert is_crawlable_url("https://example.com/data.zip") is False


class TestIsValidUrlForCollection:
    """is_valid_url_for_collection 测试"""

    def test_html_valid(self):
        """HTML 链接可收集"""
        assert is_valid_url_for_collection("https://example.com/page") is True

    def test_pdf_valid_for_collection(self):
        """PDF 链接可收集"""
        assert is_valid_url_for_collection("https://example.com/doc.pdf") is True

    def test_non_http_invalid(self):
        """非 http 协议不可收集"""
        assert is_valid_url_for_collection("ftp://example.com/file") is False


class TestIsValidUrl:
    """is_valid_url 测试"""

    def test_http_valid(self):
        assert is_valid_url("https://example.com") is True

    def test_javascript_invalid(self):
        assert is_valid_url("javascript:void(0)") is False

    def test_empty_invalid(self):
        assert is_valid_url("") is False


class TestResolveUrl:
    """resolve_url 测试"""

    def test_absolute_url_unchanged(self):
        """绝对 URL 不变"""
        result = resolve_url("https://example.com", "https://other.com/page")
        assert result == "https://other.com/page"

    def test_relative_url_resolved(self):
        """相对 URL 解析"""
        result = resolve_url("https://example.com/dir/", "sub/page.html")
        assert result == "https://example.com/dir/sub/page.html"

    def test_root_relative_url_resolved(self):
        """根相对 URL 解析"""
        result = resolve_url("https://example.com/dir/", "/root/page.html")
        assert result == "https://example.com/root/page.html"


class TestConstants:
    """常量测试"""

    def test_pdf_in_non_crawlable(self):
        assert '.pdf' in NON_CRAWLABLE_EXTENSIONS

    def test_tokyostarbank_in_keep_www(self):
        assert 'www.tokyostarbank.co.jp' in KEEP_WWW_DOMAINS

package com.unify.iam.app.security;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.common.exception.AuthException;
import java.text.ParseException;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 * JWT 签发与验签（RS256 + kid header）。
 *
 * <p>{@code sign} 用于登录/dev-token 签发；{@code verify} 供 IAM 自身受保护端点（如 /me）
 * 就地验签（签名 + exp）。parlant 侧由 GatewayProvider 独立验签，不依赖本类。
 */
@Component
public class JwtSigner {

    private final RsaKeyManager keyManager;

    public JwtSigner(RsaKeyManager keyManager) {
        this.keyManager = keyManager;
    }

    /**
     * 签发 RS256 JWT（紧凑序列化，header 带 kid）。
     */
    public String sign(JwtClaims claims) {
        try {
            JWTClaimsSet.Builder builder = new JWTClaimsSet.Builder()
                    .issuer(claims.iss())
                    .subject(claims.sub())
                    .claim("tenantId", claims.tenantId())
                    .claim("membershipId", claims.membershipId())
                    .claim("roles", claims.roles())
                    .claim("permissions", claims.permissions())
                    .claim("attrs", claims.attrs())
                    .claim("ver", claims.ver())
                    .expirationTime(Date.from(Instant.ofEpochSecond(claims.exp())))
                    .issueTime(Date.from(Instant.ofEpochSecond(claims.iat())))
                    .jwtID(claims.jti());
            // aud：单值收拢为字符串（parlant 等按字符串校验的消费端精确向后兼容），多值才序列化为数组
            if (claims.aud().size() == 1) {
                builder.audience(claims.aud().get(0));
            } else {
                builder.audience(claims.aud());
            }
            JWTClaimsSet claimsSet = builder.build();
            JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256)
                    .keyID(keyManager.kid())
                    .build();
            SignedJWT signedJwt = new SignedJWT(header, claimsSet);
            signedJwt.sign(new RSASSASigner(keyManager.signingKey()));
            return signedJwt.serialize();
        } catch (JOSEException e) {
            throw new IllegalStateException("JWT 签名失败", e);
        }
    }

    /**
     * 验签（RS256 公钥）+ 校验 exp（缺失或已过期拒绝）。
     *
     * @throws AuthException 401（签名无效 / 缺 exp / 已过期 / 格式错误）
     */
    public JwtClaims verify(String token) {
        try {
            SignedJWT signedJwt = SignedJWT.parse(token);
            RSAKey publicKey = keyManager.signingKey().toPublicJWK();
            JWSVerifier verifier = new RSASSAVerifier(publicKey);
            if (!signedJwt.verify(verifier)) {
                throw AuthException.unauthorized("令牌签名无效");
            }
            JWTClaimsSet claimsSet = signedJwt.getJWTClaimsSet();
            Date exp = claimsSet.getExpirationTime();
            if (exp == null) {
                throw AuthException.unauthorized("令牌缺少 exp");
            }
            if (exp.before(new Date())) {
                throw AuthException.unauthorized("令牌已过期");
            }
            return toJwtClaims(claimsSet);
        } catch (ParseException e) {
            throw AuthException.unauthorized("令牌格式错误");
        } catch (JOSEException e) {
            throw AuthException.unauthorized("令牌验签失败");
        }
    }

    @SuppressWarnings("unchecked")
    private JwtClaims toJwtClaims(JWTClaimsSet cs) {
        Object rolesObj = cs.getClaim("roles");
        Object permsObj = cs.getClaim("permissions");
        long ver = 0L; // ver 缺省/非法 → 0（旧 token 无 ver，方案 c 前签发；parlant 按 0 保守判定）
        try {
            Long v = cs.getLongClaim("ver");
            ver = v == null ? 0L : v;
        } catch (java.text.ParseException ignored) {
            // 非法 ver 值 → 0
        }
        return new JwtClaims(
                cs.getIssuer(),
                cs.getAudience() == null ? List.of() : cs.getAudience(),
                cs.getSubject(),
                String.valueOf(cs.getClaim("tenantId")),
                cs.getClaim("membershipId") == null ? null : String.valueOf(cs.getClaim("membershipId")),
                rolesObj instanceof List<?> ? ((List<String>) rolesObj) : List.of(),
                permsObj instanceof List<?> ? ((List<String>) permsObj) : List.of(),
                cs.getClaim("attrs") instanceof java.util.Map<?, ?> attrs
                        ? (java.util.Map<String, List<String>>) attrs : java.util.Map.of(),
                cs.getExpirationTime() == null ? 0L : cs.getExpirationTime().toInstant().getEpochSecond(),
                cs.getIssueTime() == null ? 0L : cs.getIssueTime().toInstant().getEpochSecond(),
                cs.getJWTID(),
                ver);
    }
}

package com.unify.iam.authorization.app.model;

import java.util.List;

/**
 * 应用目录条目（docs/05 §7.3 建租户表单用）：一个 ACTIVE 应用 + 其预置角色模板。
 */
public record AppCatalog(
        String appCode,
        String appName,
        String description,
        List<AppRoleTemplate> roles) {
}

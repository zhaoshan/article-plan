# IAM Web 接口矩阵勘误计划

**日期：** 2026-10-23  
**范围：** 当前 `platform-iam-service` 主工作区；仅 `.trellis/` 文档和任务记录。

## 目标

保留既有接口审计的源码事实，同时将当前 IAM Web 的接口结论收敛到真实页面范围：顶层
`/admin/agents` 与 `/admin/agent-studio` 不再被记录为 IAM Web 的接口缺口；
`/admin/tenant-settings/:tenantId/agents` 仍作为租户已启用应用与 RBAC 治理视图核对。

## 已确认的边界

- 不修改业务源码、API 契约、测试、配置、分支或 worktree。
- 不访问其他 Platform IAM 项目；任务、计划、会话和历史审计均保留在本仓库 `.trellis/`。
- 仓库内未找到 `AGENTS.md` 或 `.trellis/workflow.md`。已读取实际存在的 `CLAUDE.md`，并遵守其不自动提交规则。
- 以当前 `main` 的静态 controller、DTO、service、seed 和已交付设计文档为证据；不把未检出的前端页面假设成后端契约。

## 执行项

- [x] 定位历史接口审计与其面向后续开发的结论。
- [x] 核对 IAM Web 的既定页面范围、控制器路径、方法、请求字段和响应字段。
- [x] 核对 `tenant-settings/:tenantId/agents` 对应的租户应用、角色/权限和成员治理边界。
- [x] 给历史审计增加勘误说明，保留原始事实而撤销其作为活跃 IAM backlog 的含义。
- [x] 新增当前 IAM Web 的替代接口矩阵，分别列出可直接调用、部分匹配和真实 IAM 缺口。
- [x] 对新增文档运行路径/方法/字段的静态复核、Markdown/Git 健康检查，并记录结果。

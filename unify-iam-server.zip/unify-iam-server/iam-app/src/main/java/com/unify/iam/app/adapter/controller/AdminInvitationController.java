package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.constant.PermissionCodes;
import com.unify.iam.api.dto.admin.CreateInvitationRequest;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.InvitationService;
import com.unify.iam.app.security.CurrentAuth;
import com.unify.iam.app.security.RequirePermission;
import jakarta.validation.Valid;
import java.util.Map;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** IAM 管理面：邀请（iam:member:write）。 */
@RestController
@RequestMapping({"/api/v1/admin/invitations", "/api/v1/mgmt/invitations"})
public class AdminInvitationController {

    private final InvitationService invitationService;
    private final AuditService auditService;

    public AdminInvitationController(InvitationService invitationService, AuditService auditService) {
        this.invitationService = invitationService;
        this.auditService = auditService;
    }

    @PostMapping
    @RequirePermission(PermissionCodes.IAM_MEMBER_WRITE)
    @com.unify.iam.common.log.LogPayload // body 无凭据（email/tenant_id/role_id），白名单样例
    public Map<String, String> create(@Valid @RequestBody CreateInvitationRequest request) {
        Map<String, String> result = invitationService.create(CurrentAuth.claims(), request);
        auditService.audit().event("ADMIN_INVITE").actor(CurrentAuth.claims().userId())
                .target("INVITATION", com.unify.iam.common.util.SecureToken.hash(result.get("token")))
                .result("SUCCESS").tenant(request.tenantId())
                .write(Map.of("email", request.email()));
        return result;
    }
}

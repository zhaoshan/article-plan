package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * dev-token 请求：{@code POST /api/v1/auth/dev-token}（联调/Postman 友好）。
 *
 * <p>{@code user_id} 与 {@code username} 至少给一个；{@code membership_id} 可选（默认取默认成员关系）。
 * 字段名与 E2E-1 范围文档 §5.2 的 snake_case 契约一致。
 */
public record DevTokenRequest(
        @JsonProperty("user_id") String userId,
        String username,
        @JsonProperty("membership_id") String membershipId) {

    /** 是否携带了可识别用户的标识。 */
    public boolean hasUserRef() {
        return (userId != null && !userId.isBlank()) || (username != null && !username.isBlank());
    }
}

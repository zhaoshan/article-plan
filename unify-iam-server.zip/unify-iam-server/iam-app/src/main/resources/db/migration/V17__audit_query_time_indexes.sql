-- Audit query range filters: preserve the original V5 schema and add only additive indexes.
-- create_time + id supports deterministic time-descending pagination; tenant_id first keeps
-- tenant-scoped range queries selective. The existing idx_tenant_event_time remains for exact
-- tenant + event_type filtering.

CREATE INDEX `idx_audit_time_id` ON `gateway_audit_log` (`create_time`, `id`);

CREATE INDEX `idx_audit_tenant_time_id` ON `gateway_audit_log` (`tenant_id`, `create_time`, `id`);

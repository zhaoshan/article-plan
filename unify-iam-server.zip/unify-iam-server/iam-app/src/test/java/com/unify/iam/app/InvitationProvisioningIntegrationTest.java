package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.app.mail.EmailTool;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G2 集成测试：邀请 JIT 建号 + 初始密码 + Owner 邮箱开通 + 首登强制改密。
 * EmailTool 用 @MockitoBean 捕获渲染结果（测试环境无 SMTP，生产真实发送）。
 */
class InvitationProvisioningIntegrationTest extends IamIntegrationTestBase {

    private static final Pattern PW_PATTERN = Pattern.compile(
            "(?s)Temporary password.*?word-break: break-all;\\\">\\s*(\\S+)\\s*</td>");
    private static final Pattern TOKEN_PATTERN = Pattern.compile("(?:\\?|&)token=([A-Za-z0-9_\\-]+)");

    @MockitoBean
    private EmailTool emailTool;

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("access_token").toString();
    }

    private String adminToken() throws Exception {
        return login("admin", "admin123");
    }

    /** 捕获最近一封发给 to 的邮件正文。 */
    private String capturedHtml(String to) {
        ArgumentCaptor<String> html = ArgumentCaptor.forClass(String.class);
        verify(emailTool).send(eq(to), anyString(), html.capture());
        return html.getValue();
    }

    @Test
    void inviteNewEmailProvisionsAccountWithInitialPassword() throws Exception {
        MvcResult inviteRes = mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"g2new@unify.local\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.token").exists())
                .andReturn();
        String inviteToken = unwrapData(inviteRes.getResponse().getContentAsString()).get("token").toString();

        // 账号 JIT 创建：ACTIVE + 首登强制改密
        Integer mustChange = jdbcTemplate.queryForObject(
                "SELECT must_change_password FROM gateway_user WHERE primary_email='g2new@unify.local'",
                Integer.class);
        assertThat(mustChange).isEqualTo(1);

        // 新 JIT 账号（产品口径）：受邀租户成员即时创建（is_default=1）+ 生效角色绑定（未传 role → is_owner 默认 r-1002）；
        // 且不建个人租户
        Map<String, Object> m = jdbcTemplate.queryForMap(
                "SELECT m.membership_status, m.is_default FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND m.tenant_id='tenant-org-a'");
        assertThat(m.get("membership_status")).isEqualTo("ACTIVE");
        assertThat(((Number) m.get("is_default")).intValue()).isEqualTo(1);
        Integer roleCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND m.tenant_id='tenant-org-a' AND mr.delete_flag=0",
                Integer.class);
        assertThat(roleCount).isEqualTo(1);
        Integer personalTenants = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_tenant WHERE tenant_type='PERSONAL' AND owner_user_id="
                        + "(SELECT user_id FROM gateway_user WHERE primary_email='g2new@unify.local')",
                Integer.class);
        assertThat(personalTenants).isZero();
        Integer localIdentities = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user_identity ui JOIN gateway_user u ON ui.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND ui.provider_type='LOCAL'",
                Integer.class);
        assertThat(localIdentities).isEqualTo(1);

        // 邮件含初始密码区块 + 链接
        String html = capturedHtml("g2new@unify.local");
        Matcher pw = PW_PATTERN.matcher(html);
        assertThat(pw.find()).as("邮件应含初始密码").isTrue();
        assertThat(html).contains("token=").contains("app=imorph");

        // 初始密码可登录，登录响应透出 must_change_password=true
        String initial = pw.group(1);
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g2new@unify.local\",\"password\":\"" + initial + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.must_change_password").value(true));

        // 首登强制改密：旧密码错误 401；正确改密后标记清零
        String bearer = login("g2new@unify.local", initial);
        mockMvc.perform(post("/api/v1/auth/change-password")
                        .header("Authorization", "Bearer " + bearer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"old_password\":\"wrong\",\"new_password\":\"NewPass123!\"}"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/v1/auth/change-password")
                        .header("Authorization", "Bearer " + bearer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"old_password\":\"" + initial + "\",\"new_password\":\"NewPass123!\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("CHANGED"));
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g2new@unify.local\",\"password\":\"NewPass123!\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.must_change_password").value(false));

        // accept 幂等：受邀成员/角色邀请时已建，accept 仅标记 ACCEPTED + redirect_url（成员数不变）
        mockMvc.perform(post("/api/v1/auth/invitations/" + inviteToken + "/accept")
                        .header("Authorization", "Bearer " + login("g2new@unify.local", "NewPass123!")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"))
                .andExpect(jsonPath("$.data.redirect_url").value("http://localhost:5173"));
        Integer membershipCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND m.tenant_id='tenant-org-a'",
                Integer.class);
        assertThat(membershipCount).isEqualTo(1);
    }

    @Test
    void inviteExistingEmailOmitsPasswordBlockAndKeepsAccount() throws Exception {
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"viewer@unify.local\",\"tenant_id\":\"tenant-org-a\","
                                + "\"role_id\":\"r-1001\"}")) // 显式非 owner 角色 → member 模板
                .andExpect(status().isOk());

        // 不重复建号、不动标记
        Integer users = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE primary_email='viewer@unify.local'", Integer.class);
        assertThat(users).isEqualTo(1);
        Integer mustChange = jdbcTemplate.queryForObject(
                "SELECT must_change_password FROM gateway_user WHERE primary_email='viewer@unify.local'",
                Integer.class);
        assertThat(mustChange).isZero();

        // 显式 role_id 原样生效（r-1001 AgentOperator，非 owner → member 模板）
        String invitedRole = jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE email='viewer@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1", String.class);
        assertThat(invitedRole).isEqualTo("r-1001");
        // 邀请盖隐含应用参数（G2 增强）
        String appCode = jdbcTemplate.queryForObject(
                "SELECT app_code FROM gateway_invitation WHERE email='viewer@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1", String.class);
        assertThat(appCode).isEqualTo("imorph");

        // 已有账号：密码区块整块移除
        verify(emailTool).send(eq("viewer@unify.local"), anyString(), contains("been invited to join"));
        String html = capturedHtml("viewer@unify.local");
        assertThat(html).doesNotContain("Temporary password");
        assertThat(html).doesNotContain("{{initial_password}}");
    }

    @Test
    void inviteWithoutRoleUsesOwnerTemplate() throws Exception {
        // 不传 role_id → 生效角色 = 默认 is_owner（r-1002）→ 邮件用 Owner 模板（"as the Owner"）
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"g2ownrole@unify.local\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isOk());
        org.mockito.ArgumentCaptor<String> html = org.mockito.ArgumentCaptor.forClass(String.class);
        org.mockito.Mockito.verify(emailTool).send(
                org.mockito.ArgumentMatchers.eq("g2ownrole@unify.local"),
                org.mockito.ArgumentMatchers.anyString(), html.capture());
        assertThat(html.getValue()).contains("as the Owner");
    }

    @Test
    void ownerEmailCreatesTenantAndSendsOwnerInvitation() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"g2own\",\"tenant_name\":\"G2 Own Tenant\","
                                + "\"app_codes\":[\"imorph\"],\"owner_email\":\"g2owner@unify.local\"}"))
                .andExpect(status().isOk())
                .andReturn();
        String tenantId = unwrapData(res.getResponse().getContentAsString()).get("tenant_id").toString();

        // Owner 已建成员 + 角色绑定（is_owner 模板）
        Integer memberships = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2owner@unify.local' AND m.tenant_id=? AND m.membership_status='ACTIVE'",
                Integer.class, tenantId);
        assertThat(memberships).isEqualTo(1);
        Integer roleBindings = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2owner@unify.local' AND m.tenant_id=? AND mr.delete_flag=0",
                Integer.class, tenantId);
        assertThat(roleBindings).isGreaterThanOrEqualTo(1);

        // Owner 邀请必带 is_owner 模板角色（产品口径：邀请必传角色，Owner = is_owner=1 模板）
        String ownerRoleId = jdbcTemplate.queryForObject(
                "SELECT role_id FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND role_code='iMorph-Owner'",
                String.class, tenantId);
        String invitedRole = jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE tenant_id=? AND email='g2owner@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1",
                String.class, tenantId);
        assertThat(invitedRole).isEqualTo(ownerRoleId);

        // Owner 邀请邮件：新账号含密码 + Owner 语义
        String html = capturedHtml("g2owner@unify.local");
        assertThat(html).contains("as the Owner");
        Matcher pw = PW_PATTERN.matcher(html);
        assertThat(pw.find()).isTrue();

        // 初始密码登录 → accept（幂等：已是成员，仅标记 ACCEPTED）
        String bearer = login("g2owner@unify.local", pw.group(1));
        Matcher token = TOKEN_PATTERN.matcher(html);
        assertThat(token.find()).isTrue();
        mockMvc.perform(post("/api/v1/auth/invitations/" + token.group(1) + "/accept")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"))
                // G2 增强：redirect_url 兜底为邀请链接基址（未配 homepage_url / yml 为空）
                .andExpect(jsonPath("$.data.redirect_url").value("http://localhost:5173"));
        assertThat(memberships).isEqualTo(1); // 成员数不重复增加
    }
}

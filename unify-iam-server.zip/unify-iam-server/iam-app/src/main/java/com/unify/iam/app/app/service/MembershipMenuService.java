package com.unify.iam.app.app.service;

import com.unify.iam.authorization.infra.persistence.po.MembershipRolePO;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.springframework.stereotype.Service;

/**
 * 租户切换菜单数据（G9，docs/08 §14）：`GET /auth/memberships` 的增强数据源。
 *
 * <p>每行透出：基础字段 + {@code tenant_type}（Enterprise/Personal 徽标）+ {@code roles}/{@code is_owner}
 * （Owner/Admin/Member 徽标）+ {@code is_current} + {@code last_opened_at}（Last opened 排序）+
 * {@code tenant_created_at}/{@code joined_at}（Created time 排序，两种口径都给出）。
 * 搜索/排序/展示名归前端。
 */
@Service
public class MembershipMenuService {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final MembershipResolver membershipResolver;
    private final TenantRepository tenantRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final RoleRepository roleRepository;
    private final ApplicationRoleTemplateRepository applicationRoleTemplateRepository;
    private final TenantApplicationRepository tenantApplicationRepository;

    public MembershipMenuService(MembershipResolver membershipResolver,
                                 TenantRepository tenantRepository,
                                 MembershipRoleRepository membershipRoleRepository,
                                 RoleRepository roleRepository,
                                 ApplicationRoleTemplateRepository applicationRoleTemplateRepository,
                                 TenantApplicationRepository tenantApplicationRepository) {
        this.membershipResolver = membershipResolver;
        this.tenantRepository = tenantRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.roleRepository = roleRepository;
        this.applicationRoleTemplateRepository = applicationRoleTemplateRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
    }

    /** 当前用户可切换成员列表（租户有效过滤），带菜单所需的全部展示字段。 */
    public List<Map<String, Object>> listForMenu(String userId, String currentMembershipId) {
        String current = currentMembershipId == null ? "" : currentMembershipId.trim();
        List<Map<String, Object>> rows = new ArrayList<>();
        for (MembershipPO m : membershipResolver.listByUser(userId)) {
            String tenantId = m.getTenantId().trim();
            String mid = m.getMembershipId().trim();
            TenantPO tenant = tenantRepository.findById(tenantId).orElse(null);

            Map<String, Object> row = new LinkedHashMap<>();
            row.put("membership_id", mid);
            row.put("tenant_id", tenantId);
            row.put("tenant_name", tenant == null ? "" : tenant.getTenantName());
            row.put("tenant_code", tenant == null ? "" : tenant.getTenantCode());
            row.put("tenant_type", tenant == null ? "" : tenant.getTenantType());
            row.put("membership_status", m.getMembershipStatus());
            row.put("is_default", m.getIsDefault());
            row.put("is_current", mid.equals(current));

            // 角色 + is_owner（角色 code 命中该租户启用应用的 is_owner 模板，G3 方式 B 同口径）
            List<String> roleIds = membershipRoleRepository.listByMembership(mid).stream()
                    .map(MembershipRolePO::getRoleId).map(String::trim).toList();
            List<RolePO> roles = roleIds.stream()
                    .map(roleRepository::findById).filter(Optional::isPresent).map(Optional::get).toList();
            row.put("roles", roles.stream().map(r -> r.getRoleCode().trim()).toList());
            Set<String> ownerCodes = new HashSet<>(applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                    tenantApplicationRepository.findAppCodesByTenant(tenantId)));
            row.put("is_owner", roles.stream().anyMatch(r -> ownerCodes.contains(r.getRoleCode().trim())));

            row.put("last_opened_at", fmt(m.getLastOpenedAt()));
            row.put("joined_at", fmt(m.getCreateTime()));
            row.put("tenant_created_at", tenant == null ? null : fmt(tenant.getCreateTime()));
            rows.add(row);
        }
        return rows;
    }

    private String fmt(LocalDateTime t) {
        return t == null ? null : t.format(FMT);
    }
}

package com.unify.iam.authorization;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.unify.iam.authorization.app.model.RbacResult;
import com.unify.iam.authorization.app.service.RbacResolver;
import com.unify.iam.authorization.infra.persistence.mapper.AuthorizationQueryMapper;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class RbacResolverTest {

    @Mock
    private AuthorizationQueryMapper queryMapper;

    @Test
    void resolveReturnsRolesAndPermissionsInOrder() {
        when(queryMapper.selectRoleCodesByMembership("ms-2001")).thenReturn(List.of("AgentOperator"));
        when(queryMapper.selectPermissionCodesByMembership("ms-2001"))
                .thenReturn(List.of("agent:read", "agent:build", "agent:publish", "agent:delete",
                        "session:read", "session:send", "customer:manage", "trace:read", "settings:read"));

        RbacResolver resolver = new RbacResolver(queryMapper);
        RbacResult result = resolver.resolve("ms-2001");

        assertThat(result.roles()).containsExactly("AgentOperator");
        assertThat(result.permissions()).containsExactly(
                "agent:read", "agent:build", "agent:publish", "agent:delete",
                "session:read", "session:send", "customer:manage", "trace:read", "settings:read");
    }

    @Test
    void resolveWithNoRolesReturnsEmpty() {
        when(queryMapper.selectRoleCodesByMembership("ms-x")).thenReturn(List.of());
        when(queryMapper.selectPermissionCodesByMembership("ms-x")).thenReturn(List.of());

        RbacResult result = new RbacResolver(queryMapper).resolve("ms-x");

        assertThat(result.roles()).isEmpty();
        assertThat(result.permissions()).isEmpty();
    }

    @Test
    void resolveDedupesAndKeepsSortOrderAcrossRoles() {
        // 多角色 union 后 DISTINCT + ORDER BY（权限跨角色重复由 SQL 去重，此处模拟已去重有序结果）
        when(queryMapper.selectRoleCodesByMembership("ms-x"))
                .thenReturn(List.of("AgentOperator", "TenantAdmin"));
        when(queryMapper.selectPermissionCodesByMembership("ms-x"))
                .thenReturn(List.of("agent:read", "agent:build", "agent:publish", "session:read"));

        RbacResult result = new RbacResolver(queryMapper).resolve("ms-x");

        assertThat(result.roles()).containsExactly("AgentOperator", "TenantAdmin");
        assertThat(result.permissions()).containsExactly("agent:read", "agent:build", "agent:publish", "session:read");
    }
}

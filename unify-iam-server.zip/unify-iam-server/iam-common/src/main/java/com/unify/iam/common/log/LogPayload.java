package com.unify.iam.common.log;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 请求体日志白名单开关（2026-11-05 日志分层方案）：打在 Controller 方法上声明
 * 「该端点允许在访问日志中输出脱敏后的请求体」。
 *
 * <p><b>边界（CLAUDE.md，review 必查）</b>：
 * <ul>
 *   <li>凭据类端点<b>永不</b>声明本注解：{@code /auth/token}、register、refresh、
 *       reset/change-password、forgot-password，以及 SSO callback 的 query（code/state）；</li>
 *   <li>仅管理面写操作与服务间端点（低 QPS、无凭据）可用；</li>
 *   <li>即使声明，body 仍强制过 {@code LogMasks}（字段名黑名单无条件打码，password、token、secret
 *       类字段命中即 {@code *** }，防误声明泄露）。</li>
 * </ul>
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LogPayload {
}

---
description: 校验签名私钥与 JWKS 一致性
---

核对 IAM 签名私钥与其发布公钥是否一致：

1. 运行实例公钥：`curl -s localhost:8090/.well-known/jwks.json` 取 `keys[0].n`。
2. 私钥推导公钥：用 `iam-app/.venv`（或 parlant venv，含 cryptography）读 `$IAM_JWT_PRIVATE_KEY_PATH`（默认 `/Users/zhaoshan/workspace/unify-iam-server/keys/rsa-private.pem`），算 base64url `n`，与 JWKS 的 `n` 比较。

要点：
- 私钥路径由 `IAM_JWT_PRIVATE_KEY_PATH` 固定为单一绝对路径；检查是否存在多余 `keys/` 目录（相对路径启动会各生成一把 → token 失配）。
- `keys/*.pem` 必须 0600、gitignore、不提交。
- 换钥靠 kid 并存窗口轮换；泄露即换钥并作废旧 token。

"""ScheduleRepository / ScheduleLogRepository 单元测试"""

import uuid
from datetime import datetime

import pytest

from src.database.models import CrawlScheduleModel, CrawlScheduleLogModel
from src.database.repository import ScheduleRepository, ScheduleLogRepository


@pytest.fixture
def sample_schedule():
    """返回一个启用的 CrawlScheduleModel"""
    return CrawlScheduleModel(
        schedule_id=str(uuid.uuid4()),
        site="example.com",
        target_url="https://example.com/",
        cron_expression="0 2 * * *",
        timezone="Asia/Tokyo",
        enabled=1,
        max_depth=0,
        headless=1,
        output_type="local",
        description="test schedule",
        create_time=datetime.now(),
        update_time=datetime.now(),
    )


@pytest.fixture
def sample_log(sample_schedule):
    """返回一个 pending 状态的 CrawlScheduleLogModel"""
    return CrawlScheduleLogModel(
        log_id=str(uuid.uuid4()),
        schedule_id=sample_schedule.schedule_id,
        site=sample_schedule.site,
        target_url=sample_schedule.target_url,
        status="pending",
        trigger_type="cron",
        create_time=datetime.now(),
    )


class TestScheduleRepository:
    """ScheduleRepository CRUD 测试"""

    @pytest.mark.asyncio
    async def test_create_and_find(self, db_session, sample_schedule):
        """创建调度配置后可通过 ID 查询"""
        repo = ScheduleRepository()
        created = await repo.create(sample_schedule)
        assert created.schedule_id == sample_schedule.schedule_id

        found = await repo.find_by_id(sample_schedule.schedule_id)
        assert found is not None
        assert found.site == "example.com"
        assert found.enabled == 1

    @pytest.mark.asyncio
    async def test_find_by_id_not_exists(self, db_session):
        """查询不存在的 schedule_id 返回 None"""
        repo = ScheduleRepository()
        assert await repo.find_by_id("not-exist") is None

    @pytest.mark.asyncio
    async def test_update(self, db_session, sample_schedule):
        """更新调度配置"""
        repo = ScheduleRepository()
        await repo.create(sample_schedule)

        sample_schedule.cron_expression = "*/5 * * * *"
        sample_schedule.enabled = 0
        updated = await repo.update(sample_schedule)

        assert updated.cron_expression == "*/5 * * * *"
        assert updated.enabled == 0

    @pytest.mark.asyncio
    async def test_delete(self, db_session, sample_schedule):
        """删除调度配置"""
        repo = ScheduleRepository()
        await repo.create(sample_schedule)

        deleted = await repo.delete(sample_schedule.schedule_id)
        assert deleted is True
        assert await repo.find_by_id(sample_schedule.schedule_id) is None

    @pytest.mark.asyncio
    async def test_list_all_filter_by_site_and_enabled(self, db_session):
        """列表查询支持按 site 与 enabled 过滤"""
        repo = ScheduleRepository()
        s1 = CrawlScheduleModel(
            schedule_id=str(uuid.uuid4()),
            site="example.com",
            target_url="https://example.com/",
            cron_expression="0 2 * * *",
            enabled=1,
            create_time=datetime.now(),
            update_time=datetime.now(),
        )
        s2 = CrawlScheduleModel(
            schedule_id=str(uuid.uuid4()),
            site="example.com",
            target_url="https://example.com/v2",
            cron_expression="0 3 * * *",
            enabled=0,
            create_time=datetime.now(),
            update_time=datetime.now(),
        )
        s3 = CrawlScheduleModel(
            schedule_id=str(uuid.uuid4()),
            site="other.com",
            target_url="https://other.com/",
            cron_expression="0 4 * * *",
            enabled=1,
            create_time=datetime.now(),
            update_time=datetime.now(),
        )
        await repo.create(s1)
        await repo.create(s2)
        await repo.create(s3)

        all_enabled = await repo.list_all(enabled=True)
        assert len(all_enabled) == 2

        example_enabled = await repo.list_all(site="example.com", enabled=True)
        assert len(example_enabled) == 1
        assert example_enabled[0].schedule_id == s1.schedule_id

    @pytest.mark.asyncio
    async def test_list_enabled(self, db_session, sample_schedule):
        """list_enabled 仅返回启用配置"""
        repo = ScheduleRepository()
        sample_schedule.enabled = 1
        await repo.create(sample_schedule)

        disabled = CrawlScheduleModel(
            schedule_id=str(uuid.uuid4()),
            site="disabled.com",
            target_url="https://disabled.com/",
            cron_expression="0 2 * * *",
            enabled=0,
            create_time=datetime.now(),
            update_time=datetime.now(),
        )
        await repo.create(disabled)

        enabled = await repo.list_enabled()
        assert len(enabled) == 1
        assert enabled[0].schedule_id == sample_schedule.schedule_id


class TestScheduleLogRepository:
    """ScheduleLogRepository 测试"""

    @pytest.mark.asyncio
    async def test_create_and_find(self, db_session, sample_schedule, sample_log):
        """创建日志后可通过 ID 查询"""
        schedule_repo = ScheduleRepository()
        log_repo = ScheduleLogRepository()
        await schedule_repo.create(sample_schedule)
        created = await log_repo.create(sample_log)

        assert created.log_id == sample_log.log_id
        found = await log_repo.find_by_id(sample_log.log_id)
        assert found is not None
        assert found.status == "pending"

    @pytest.mark.asyncio
    async def test_mark_running(self, db_session, sample_schedule, sample_log):
        """标记日志为 running"""
        schedule_repo = ScheduleRepository()
        log_repo = ScheduleLogRepository()
        await schedule_repo.create(sample_schedule)
        await log_repo.create(sample_log)

        await log_repo.mark_running(sample_log.log_id)
        found = await log_repo.find_by_id(sample_log.log_id)
        assert found.status == "running"
        assert found.started_at is not None

    @pytest.mark.asyncio
    async def test_mark_completed(self, db_session, sample_schedule, sample_log):
        """标记日志为 completed"""
        schedule_repo = ScheduleRepository()
        log_repo = ScheduleLogRepository()
        await schedule_repo.create(sample_schedule)
        await log_repo.create(sample_log)

        await log_repo.mark_completed(
            sample_log.log_id,
            task_id="task-001",
            links_path="/tmp/links.json",
            tree_path="/tmp/tree.json",
            pages_crawled=10,
            links_found=100,
        )
        found = await log_repo.find_by_id(sample_log.log_id)
        assert found.status == "completed"
        assert found.task_id == "task-001"
        assert found.links_path == "/tmp/links.json"
        assert found.tree_path == "/tmp/tree.json"
        assert found.pages_crawled == 10
        assert found.links_found == 100
        assert found.finished_at is not None

    @pytest.mark.asyncio
    async def test_mark_failed(self, db_session, sample_schedule, sample_log):
        """标记日志为 failed"""
        schedule_repo = ScheduleRepository()
        log_repo = ScheduleLogRepository()
        await schedule_repo.create(sample_schedule)
        await log_repo.create(sample_log)

        await log_repo.mark_failed(sample_log.log_id, "something wrong", task_id="task-002")
        found = await log_repo.find_by_id(sample_log.log_id)
        assert found.status == "failed"
        assert found.error_message == "something wrong"
        assert found.task_id == "task-002"

    @pytest.mark.asyncio
    async def test_mark_skipped(self, db_session, sample_schedule, sample_log):
        """标记日志为 skipped"""
        schedule_repo = ScheduleRepository()
        log_repo = ScheduleLogRepository()
        await schedule_repo.create(sample_schedule)
        await log_repo.create(sample_log)

        await log_repo.mark_skipped(sample_log.log_id, "already running")
        found = await log_repo.find_by_id(sample_log.log_id)
        assert found.status == "skipped"
        assert found.error_message == "already running"

    @pytest.mark.asyncio
    async def test_list_by_schedule(self, db_session, sample_schedule, sample_log):
        """按 schedule_id 分页查询日志"""
        schedule_repo = ScheduleRepository()
        log_repo = ScheduleLogRepository()
        await schedule_repo.create(sample_schedule)
        await log_repo.create(sample_log)

        logs = await log_repo.list_by_schedule(sample_schedule.schedule_id)
        assert len(logs) == 1
        assert logs[0].log_id == sample_log.log_id

    @pytest.mark.asyncio
    async def test_delete(self, db_session, sample_schedule, sample_log):
        """删除执行日志"""
        schedule_repo = ScheduleRepository()
        log_repo = ScheduleLogRepository()
        await schedule_repo.create(sample_schedule)
        await log_repo.create(sample_log)

        deleted = await log_repo.delete(sample_log.log_id)
        assert deleted is True
        assert await log_repo.find_by_id(sample_log.log_id) is None

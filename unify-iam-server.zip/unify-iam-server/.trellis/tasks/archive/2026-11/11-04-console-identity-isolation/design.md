> Closed on 2026-11-04 before implementation. The user explicitly narrowed the request to frontend-only work: no backend logic or seed changes. All backend proposals below are withdrawn historical planning, not an approved or implemented API contract. No implementation approval is requested.

# Technical design

## Existing chain
Password/SSO/refresh/switch → TokenService.issueFor → RbacResolver → AuthorizationQueryMapper → signed JWT role and permission arrays. `/auth/me` returns the verified arrays. ManagementAuthorizationInterceptor currently checks only `@RequirePermission`; TenantScopeGuard treats any bound PLATFORM role as platform admin and bypasses tenant scope. The role count query does not filter role status. See research/server-authorization.md for anchors.

## Canonical identity
Add a small shared exact-role classifier in iam-api (enum PLATFORM_ADMIN, TENANT_ADMIN, MEMBER), consumed by the server and documented for frontend reuse. Input is current membership role codes, not all memberships for an account. Apply PlatformAdmin precedence first, then only iMorph-Owner/iMorph-Admin. Preserve JWT roles/permissions and the /me response format; no identity claim/schema change is required. Frontend computes the same three-way rule from `data.roles`.

Management requests must also validate the authenticated membership belongs to token sub/tenant, is active, and its active persisted roles support the claimed privileged identity. This prevents deleted/disabled/foreign role bindings or a stale role removal from authorizing requests. No permissions-only fallback. Reuse repository paths; do not silently promote every PLATFORM role. Keep current permission checks as additional restrictions on legacy APIs; ensure the two confirmed B-side roles receive the needed member/apps capabilities in fresh and existing seed data.

## Endpoint boundary
Explicitly annotate/classify management handlers by identity; enforce centrally in ManagementAuthorizationInterceptor after Bearer verification and before controller execution. Avoid broad URL-only matching because AdminTenantController contains both platform and tenant helper methods. Default-deny an unclassified management handler and verify classification coverage in a focused test.

| Capability / API family | Allowed identity | Target scope |
| --- | --- | --- |
| `/auth/me` | all authenticated | self |
| `/admin/tenants` CRUD, details, quotas and Owner transfer | PLATFORM_ADMIN | platform-selected tenant |
| `/admin/roles`, `/admin/permissions` | PLATFORM_ADMIN | platform / tenant roles |
| `/admin/audit`, user and IdP/domain management | PLATFORM_ADMIN | existing platform rules |
| `/admin/members`, `/admin/invitations`, `/admin/join-requests`, member directory | TENANT_ADMIN | current token tenant |
| `/admin/applications` catalog (Apps page) | TENANT_ADMIN | read-only existing catalog |
| `/admin/tenants/{tenantId}/applications` (role-reference helper) | PLATFORM_ADMIN or TENANT_ADMIN | platform target or B-side current tenant |
| `/admin/tenants/{tenantId}/usage` (Apps usage helper) | TENANT_ADMIN | current token tenant; platform usage already included in `/details` |

Preserve platform Tenants application selection by extracting a platform-only `/admin/tenants/application-catalog` helper reusing the catalog service. Provide `/admin/members/assignable-roles?tenant_id=...` for B-side role options, returning existing active TENANT role briefs with role_id/role_code/role_name from the current tenant; do not open `/admin/roles` to B-side callers. These helpers exist only to preserve workflows behind the approved menu isolation. Their final names must be communicated before frontend integration.

Use separate tenant-administrator assertions for member mutations, member queries, invitations/review and Apps helpers. Do not globally remove platform tenant scope access: Tenants and Roles legitimately manage target tenants. Reject member PLATFORM scope for every identity. Platform Tenants summaries continue through `/tenants/{id}/details`, not `/members`.

`AdminMemberService.add/setRoles` must validate every supplied role ID is an active TENANT role of the target tenant before modifying bindings. Reuse the check on any other touched member role grant path (invitation acceptance must not trust unchecked IDs). A B-side administrator cannot manufacture PlatformAdmin via role assignment. Keep transaction and Owner/last-admin invariants.

## Seed compatibility
Current seeds grant Members/Apps permissions to PlatformAdmin and member/role reads to iMorph-Member. The identity gate must reject these old tokens independently of cleanup. Adjust repeatable seeds and existing-role compensation to align identities: preserve platform Tenants/Roles/Audit/user/IdP permissions, provide member/apps read/write to iMorph-Owner and iMorph-Admin, remove inappropriate console grants from iMorph-Member and platform member/apps grants. Keep business permission grants intact. Retain template flags for lifecycle behavior; they are not the identity definition.

Production defaults to schema-only Flyway locations, so record seed replay requirements explicitly; server identity isolation must work before seed cleanup. Existing B-side roles missing write/app permissions need documented seed replay to gain full capabilities. Do not edit already-applied versioned migrations.

## Frontend contract
See research/frontend-contract.md. No frontend repository access is needed.

## Risks and rollback
This intentionally breaks historical platform Members access, tenant Roles-page access, and ordinary member reads; update those tests rather than weakening the boundary. Existing consumers of the moved platform application catalog need the new platform helper. Apps currently has no CRUD implementation; this task does not invent one. Auth tenant switching remains available for business login, while only TENANT_ADMIN renders the console selector.

Rollback is reverting this task's uncommitted code and seed changes selectively, preserving unrelated work. No database operation, real emails or live application writes will be performed during planning/verification; isolated MySQL test fixtures only.

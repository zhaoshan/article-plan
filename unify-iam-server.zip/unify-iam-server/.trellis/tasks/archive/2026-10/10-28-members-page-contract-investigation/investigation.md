# Members 页面契约调查（2026-10-28）

项目：`/Users/ramiro.li/root/apps/work/platform-iam-service`。分支：`dev/261026_v0.2`。源码基线：`ffe2bea47554477252bbd3aaea8c6957e46379c7`。

以下路径均相对当前项目根目录，行号对应本次读取的工作区源码。结论是源码契约，未声称正在运行的服务已加载这些代码。

## 1. 状态：成员关系与全局用户必须分开

| 对象/响应字段 | 契约值 | 证据 |
| --- | --- | --- |
| 成员关系 `membership_status` | `PENDING`、`ACTIVE`、`SUSPENDED`、`REMOVED` | `iam-tenant/src/main/java/com/unify/iam/tenant/infra/persistence/po/MembershipPO.java:21`；`iam-app/src/main/resources/db/migration/V1__init_schema.sql:93` |
| 全局用户 `user_status` | `PENDING`、`ACTIVE`、`SUSPENDED`、`DELETED` | `iam-identity/src/main/java/com/unify/iam/identity/common/constant/UserStatus.java:4`；同一 DDL `:29` |

Members 页按成员状态筛选时，应固定提供“全部 + PENDING + ACTIVE + SUSPENDED + REMOVED”，比较每行的 `membership_status`，不能从本次结果中动态提取唯一的 ACTIVE，也不能把全局用户的 DELETED 混入成员选项。成员状态当前没有独立 Java enum：上述集合由 PO 和 DDL 注释一致声明，数据库字段实际为 VARCHAR，不是数据库 ENUM。

实际生命周期：`AdminMemberService.java:113` 创建 ACTIVE、`:165` 停用为 SUSPENDED、`:187` 恢复 ACTIVE。删除走 `:149` 的逻辑删除，`MembershipRepository.java:110` 设置 delete_flag，而非将状态改为 REMOVED。当前主代码没有写入成员 PENDING/REMOVED 的 setter；这两种仍属于声明的契约集合，不能将“当前创建流程只产生 ACTIVE/SUSPENDED”误认为只有两个合法成员状态。删除关系被列表 SQL 的 delete_flag=0 排除，所以 REMOVED 选项可能没有结果。

`TenantMemberQueryService.java:72,74` 同时返回 `user_status` 与 `membership_status`，`TenantMemberProjectionService.java:69` 分别从 UserPO 和 MembershipPO 取值。用户缺失或被逻辑删除时，关系仍可返回，user_available=false，用户资料和 user_status 不返回；不能据此把关系状态改为 DELETED。`owner_candidates=true` 才同时要求两种状态均 ACTIVE。

补充边界：`UpdateUserRequest.java:16` 的 user_status 是未做枚举约束的 String，`AdminUserService.java:104` 原样赋值；因此 Java UserStatus 枚举不等于所有历史数据库值必然合法。DISABLED 不在该枚举内，也不属于成员状态。本次未查询真实数据库，不声明当前数据分布。

## 2. 列表无分页，状态筛选需前端执行

接口：`GET /api/v1/admin/members`，需要 `iam:member:read` 和租户作用域。

`iam-app/src/main/java/com/unify/iam/app/adapter/controller/AdminMemberController.java:41` 仅声明：

| 参数 | 当前契约 |
| --- | --- |
| tenant_id | 必填；trim 后不可为空 |
| keyword | 可选；trim 后空串不限制资料 |
| owner_candidates | boolean，默认 false；普通 Members 页面应保持 false/省略 |
| limit | 默认 1000；整数 1..1000 |

没有 page/page_size/size/offset，也没有 status/membership_status 筛选参数。传旧分页或状态参数不会触发所期待的分页/状态过滤；没有可供后端状态筛选的“合法 query 值”。上述四种值用于前端本地按 membership_status 筛选。

`TenantMemberQueryMapper.java:12` 先按租户、delete_flag、keyword、候选条件筛选，再在 `:28` 执行 `ORDER BY m.id ASC LIMIT`，无 OFFSET。普通模式不隐式只保留 ACTIVE。

`TenantMemberQueryService.java:55` 返回 data：`members`、`count`（实际返回数）、`tenant_type`、`total`（过滤后截断前总数）、`limit`、`truncated`（total > count）。因此去掉分页控件符合接口；无分页不等于无限返回。truncated=true 时，本地状态筛选仅覆盖已返回最多 1000 条，不能冒充全租户精确筛选；远程 keyword 会先搜索全部目标关系再截断。

现有测试源码：`TenantMemberSearchIntegrationTest.java:193` 覆盖 1001 条截断和真实 total，`:210` 明确验证传 page=999、size=999 仍返回第一条。这里只阅读测试，未执行。

## 3. 搜索字段不包含 ID

`TenantMemberQueryMapper.java:16` keyword 仅 OR 匹配未逻辑删除用户的 `display_name`、`full_name`、`username`、`primary_email`；不查询 user_id、membership_id、tenant_id，也不搜索全局目录。`TenantMemberQueryService.java:45` 处理 trim、参数绑定及 `%/_/!` 字面转义。

前端 placeholder 可用“搜索用户名、姓名或邮箱”；应去掉 ID 文案，并去掉前端本地对 ID 的匹配（后端不支持）。如果 ID 字符串恰好出现在真实用户名/邮箱中，仍可能命中该资料字段，不能理解为存在 ID 搜索。

`TenantMemberSearchIntegrationTest.java:148` 覆盖四个字段、中文、大小写和 trim，`:153` 覆盖字面通配符。

## 4. 编辑角色保存与错误契约

```http
PUT /api/v1/admin/members/{membershipId}/roles
Authorization: Bearer <token>
Content-Type: application/json

{"role_ids":["<role_id>"]}
```

`AdminMemberController.java:60` 路径参数必须是 membership_id，不能用 user_id；权限为 `iam:member:write`。成功响应经 ApiEnvelopeAdvice 包裹，data 为 `{membership_id: ...}`。

`iam-api/src/main/java/com/unify/iam/api/dto/admin/SetRolesRequest.java:7` 只有 role_ids；编辑角色接口不修改 user，亦无需 user_id 或 username。缺失/null role_ids 会规范化为空列表，相当于尝试清空角色，不是“不修改”；空集合受最后管理员保护。

`AdminMemberService.java:126` 顺序为查成员→租户作用域→最后管理员保护→替换角色→bump token version→写审计，在事务中执行。

| HTTP | 已明确的情形/文案 | 实现 |
| --- | --- | --- |
| 401 | 未认证/令牌无效 | `ManagementAuthorizationInterceptor.java:46` |
| 403 | 缺少 iam:member:write；或“无权操作其他租户” | 同文件 `:39`；`TenantScopeGuard.java:30` |
| 404 | “成员关系不存在” | `AdminMemberService.java:127` |
| 400 | “至少保留一名有效租户管理员” | `AdminMemberService.java:205` |
| 400 | “请求体格式错误” | `GlobalExceptionHandler.java:50` |
| 500 | “系统错误”，不把 Java 异常堆栈作为响应文案 | `GlobalExceptionHandler.java:73` |

最后管理员保护包括：IAM 管理能力不能归零；当前持有应用模板 is_owner 角色的唯一 ACTIVE 持有者不能失去该角色。不是每次保存都失败；是否命中取决于当前与目标角色集。`AdminProtectionIntegrationTest.java:172` 和 `:194` 的测试源码覆盖对应 400 拒绝。

错误在 `/api/v1/admin/**` 内由 `EnvelopePaths.java:19` + `GlobalExceptionHandler.java:36,80` 统一输出真实非 2xx HTTP 状态及 `{success:false,code,message}`；AuthException 的 code 为 `IAM-AUTH-000`，参数/JSON 错误为 `IAM-PARAM-000`，系统错误为 `IAM-SYST-000`。CommonResponse 内 data=null，但 `application.yml:5` 配置 non_null，所以线上序列化时 data 可能省略，前端不能强制要求 data:null。AuthException/CommonResponse 类中仍有旧 detail 注释，应以实际路径判定和 handler 实现为准。

后端只定义响应，不决定 UI 展示位置。按本轮用户明确要求，前端应把接口失败的 message 交给右上角统一提示框，不在页面/弹框内额外展示接口异常块，也不要重复提示。这里没有证据证明截图的具体保存错误就是最后管理员保护：本任务未查看前端请求、响应或运行服务日志，不做根因定论。

额外输入边界：SetRolesRequest 没有 role_ids 元素级 @NotBlank，也没有在 setRoles 中显式校验每个角色的存在/租户归属。MembershipRoleRepository.java:74 对每项调用 trim，null 元素可能触发 500；不能向前端承诺所有非法角色输入都有友好 400。此为代码边界说明，本次不修改。

## 5. 验证及交接边界

完成 controller→service→mapper/repository→DTO→异常处理→序列化配置与既有测试源码交叉核对。未运行 Maven 测试、未访问 API/数据库、未读取密钥、未登录、未重启服务。无需编译：无业务或测试源码修改。

AGENTS.md 与 .trellis/workflow.md 在当前工作区缺失，Trellis 脚本目录仅有既有缓存；不能声称执行了不存在的工作流命令或确认门禁。沿用实际 CLAUDE.md、.claude/rules 与 .trellis/tasks 既有调查记录格式。无需用户追加确认即可完成已授权的只读调查。

前端改动由独立任务处理；本任务没有访问、修改或创建其他 Platform IAM 项目的任务，也不主动跨会话发消息。最终结论由调度主会话接收。

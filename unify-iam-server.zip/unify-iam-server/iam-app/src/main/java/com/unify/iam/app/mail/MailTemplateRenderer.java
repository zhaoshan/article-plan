package com.unify.iam.app.mail;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 简单模板渲染（对齐 ai-chat-insight {@code MailTemplateRenderer}）：
 *
 * <ul>
 *   <li>{@code {{key}}} 替换为对应值；值为 null 时替换为空字符串；</li>
 *   <li>条件块 {@code <!-- {{#key}} -->...<!-- {{/key}} -->}：key 值为 <b>null</b> 时整块移除
 *       （G2 邀请邮件「初始密码区块」——已有账号省略密码行），非 null 时保留块内内容并渲染。</li>
 * </ul>
 */
public final class MailTemplateRenderer {

    private static final Pattern BLOCK =
            Pattern.compile("<!--\\s*\\{\\{#(\\w+)}}\\s*-->(.*?)<!--\\s*\\{\\{/\\1}}\\s*-->", Pattern.DOTALL);

    private MailTemplateRenderer() {
    }

    public static String render(String template, Map<String, String> variables) {
        if (template == null) {
            return null;
        }
        String result = stripAbsentBlocks(template, variables);
        if (variables == null || variables.isEmpty()) {
            return result;
        }
        for (Map.Entry<String, String> entry : variables.entrySet()) {
            String val = entry.getValue() == null ? "" : entry.getValue();
            result = result.replace("{{" + entry.getKey() + "}}", val);
        }
        return result;
    }

    /** 条件块处理：块 key 在 variables 中缺失或为 null → 整块移除；否则保留内层（标记注释本身始终移除）。 */
    private static String stripAbsentBlocks(String template, Map<String, String> variables) {
        Matcher m = BLOCK.matcher(template);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String key = m.group(1);
            boolean present = variables != null && variables.get(key) != null;
            m.appendReplacement(sb, Matcher.quoteReplacement(present ? m.group(2) : ""));
        }
        m.appendTail(sb);
        return sb.toString();
    }
}

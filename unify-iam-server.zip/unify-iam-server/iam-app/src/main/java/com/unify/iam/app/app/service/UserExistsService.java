package com.unify.iam.app.app.service;

import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Service;

/**
 * 邮箱存在性判定（G8，docs/requirements/M10W4-W5 §G8 + 「登录与账号关联 · 设计决策」）。
 *
 * <p>登录/注册两段式：输入邮箱 → 账号存在走密码登录 / 不存在走创建账号 / IdP 用户跳 SSO。
 * 判定口径：按 {@code primary_email} 找账号；{@code auth_mode} 由 {@code gateway_user_identity}
 * 计算（有 LOCAL 身份→{@code password}；仅 OIDC→{@code sso}；两者都有→{@code password}，前端可再跳 SSO）
 * ——**依据 identity 而非 {@code registration_source}**（后者只是创建来源描述）。
 *
 * <p>安全（防枚举）：仅服务间令牌可调；响应最小化（只回 {@code exists} + {@code auth_mode}，
 * 不回 user_id/角色/租户）；调用方限流。
 */
@Service
public class UserExistsService {

    private final UserRepository userRepository;
    private final UserIdentityRepository userIdentityRepository;

    public UserExistsService(UserRepository userRepository,
                             UserIdentityRepository userIdentityRepository) {
        this.userRepository = userRepository;
        this.userIdentityRepository = userIdentityRepository;
    }

    /** 判定邮箱账号存在性与登录模式。 */
    public Map<String, Object> check(String email) {
        String em = email.trim().toLowerCase();
        Map<String, Object> r = new LinkedHashMap<>();
        Optional<UserPO> user = userRepository.findByPrimaryEmail(em);
        if (user.isEmpty()) {
            r.put("exists", false);
            r.put("auth_mode", null);
            return r;
        }
        String userId = user.get().getUserId().trim();
        boolean hasLocal = userIdentityRepository.findLocalActive(userId).isPresent();
        boolean hasOidc = userIdentityRepository.existsOidcActive(userId);
        // LOCAL 优先：两者都有 → password（前端可再跳 SSO）；无任何身份 → null（异常数据，防御）
        String authMode = hasLocal ? "password" : (hasOidc ? "sso" : null);
        r.put("exists", true);
        r.put("auth_mode", authMode);
        return r;
    }
}

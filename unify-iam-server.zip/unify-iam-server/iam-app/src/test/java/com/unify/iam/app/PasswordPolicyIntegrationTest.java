package com.unify.iam.app;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

/**
 * P1-03 统一密码策略集成测试：UTF-8 字节 8–72，覆盖全部「设置新密码」链路——
 * 注册 / 忘记密码重置 / 自助改密 / 管理员重置 / 管理员建用户（边界 8 字节放行、73 字节拒绝）。
 */
class PasswordPolicyIntegrationTest extends IamIntegrationTestBase {

    private String sfx() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    private String login(String username, String password) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("access_token").toString();
    }

    @Test
    void registerRejectsShortPasswordAndAcceptsBoundary() throws Exception {
        String email = "pp_" + sfx() + "@unify.local";
        issueVerificationCode(email);
        // 7 字节 → 400 IAM-VALID-013
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"pp_short_" + sfx() + "\",\"email\":\"" + email + "\",\"password\":\""
                                + b64("Ab1!xyz") + "\",\"verification_code\":\"123456\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-VALID-013"));
        // 8 字节（边界）→ 200
        String email2 = "pp2_" + sfx() + "@unify.local";
        issueVerificationCode(email2);
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"pp_ok_" + sfx() + "\",\"email\":\"" + email2 + "\",\"password\":\""
                                + b64("Ab1!wxyz") + "\",\"verification_code\":\"123456\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void registerRejectsOver72Bytes() throws Exception {
        String email = "pp3_" + sfx() + "@unify.local";
        issueVerificationCode(email);
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"pp_long_" + sfx() + "\",\"email\":\"" + email + "\",\"password\":\""
                                + b64("A".repeat(73)) + "\",\"verification_code\":\"123456\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-VALID-011"));
    }

    @Test
    void forgotResetRejectsShortPassword() throws Exception {
        // 策略校验在令牌校验之前——无需有效令牌即可断言 400
        mockMvc.perform(post("/api/v1/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"token\":\"whatever\",\"new_password\":\"" + b64("Ab1!xyz") + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-VALID-013"));
    }

    @Test
    void changePasswordRejectsShortNewPassword() throws Exception {
        String token = login("admin", "admin123");
        mockMvc.perform(post("/api/v1/auth/change-password")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"old_password\":\"" + b64("admin123") + "\",\"new_password\":\""
                                + b64("Ab1!xyz") + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-VALID-013"));
    }

    @Test
    void adminCreateAndResetEnforcePolicy() throws Exception {
        String admin = login("admin", "admin123");
        // 建用户：7 字节拒绝
        mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"pp_adm_" + sfx() + "\",\"email\":\"pp_adm_" + sfx()
                                + "@unify.local\",\"password\":\"" + b64("Ab1!xyz") + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-VALID-013"));
        // 管理员重置 viewer：7 字节拒绝（viewer 是 seed 只读用户，不动其密码）
        String viewerId = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE username='viewer'", String.class).trim();
        mockMvc.perform(post("/api/v1/admin/users/" + viewerId + "/reset-password")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"password\":\"" + b64("Ab1!xyz") + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-VALID-013"));
    }
}

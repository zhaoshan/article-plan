# Frontend member invitation contract

Use this current-service route when the dialog's primary action is **Send invitation**.

```http
POST /api/v1/admin/invitations
Authorization: Bearer <access token with iam:member:write>
Content-Type: application/json

{"email":"invitee@example.com","tenant_id":"<tenant_id>","role_id":"<optional role_id>"}
```

The standard IAM JSON envelope applies. A successful body is:

```json
{
  "success": true,
  "data": {
    "invitation_id": "...",
    "invitation_status": "PENDING",
    "delivery_status": "SUBMITTED"
  }
}
```

`SUBMITTED` means the configured JavaMailSender accepted the message submission. It does not prove inbox delivery, and it does not mean the invitation has been accepted. The plaintext invitation token is deliberately absent from the response.

`tenant_id` is the request identifier. Obtain the display values from `GET /api/v1/admin/tenants` with `iam:tenant:read`: each `data.tenants[]` item includes `tenant_id`, `tenant_name`, and `tenant_code`. `GET /api/v1/admin/tenants/{tenantId}` returns the same three identity/display fields for one tenant. Display name/code however the UI needs, but submit the ID.

The server requires `iam:member:write` and enforces target-tenant scope: a tenant administrator may send only to the token's tenant, while a platform administrator may target another tenant. `role_id` is optional but must name a role in the target tenant. Invalid input/role is `400`, no valid Bearer is `401`, missing permission or scope is `403`, no tenant is `404`, and incomplete mail configuration or failed sender submission is `503`; all use the standard error envelope. A `503` leaves no new pending invitation.

# Verify local Java service startup

## Goal

Build and run the existing `platform-iam-service` locally so the web
application can call the local Java HTTP API.

## Confirmed Facts

- The repository is a Java 21 / Spring Boot 3.5.9 Maven multi-module project.
- `iam-app` is the executable Spring Boot module. Its configured HTTP port is
  `8090`.
- The default datasource is MySQL at `127.0.0.1:3306/unify_iam`, using
  `root/root123456`; Flyway applies schema migrations and platform bootstrap
  seed data on startup.
- The application expects an absolute JWT private-key path. Local startup must
  set `IAM_JWT_PRIVATE_KEY_PATH` to the current repository's ignored `keys/`
  directory rather than use the checked-in former-developer path.
- The current shell has Maven but no usable Java runtime/JDK. System Java
  discovery, standard JDK/IDE/version-manager locations, and user shell
  configuration contain no JDK path.
- Neither port `3306` nor port `8090` is listening. Docker contexts, service
  managers, local MySQL configuration, Unix sockets, and project environment
  overrides do not identify a running MySQL instance or alternate port.

## Requirements

- Install the requested OpenJDK 26 under the current user's home directory and
  persist its `JAVA_HOME` and `bin` path for login shells without changing a
  system-wide Java installation.
- Start a dedicated local MySQL 8 instance because no existing MySQL
  installation or listener is present, then start the app against it with a
  repository-local, ignored JWT private-key path.
- Verify a live health endpoint and the public JWKS endpoint after startup.
- Report the listener address/port, repeatable startup command, build and
  runtime evidence, current Git branch, and working-tree status.
- State the web-facing local API contract without editing the web project.

## Acceptance Criteria

- [x] `java -version` confirms the installed JDK 26 and a new login shell
      resolves the persisted `JAVA_HOME` and `PATH` configuration.
- [x] Maven reports a successful build using JDK 26.
- [x] MySQL is reachable on the configured local datasource before app launch.
- [x] The Spring Boot process listens on `http://127.0.0.1:8090`.
- [x] `GET /actuator/health` reports `UP` and
      `GET /.well-known/jwks.json` returns a JSON JWKS document.
- [x] The final report includes the exact connection contract for the web
      client: `http://127.0.0.1:8090`, the token endpoint
      `POST /api/v1/auth/token`, and the JWKS endpoint
      `GET /.well-known/jwks.json`.
- [x] No tracked product source or configuration files are changed.
- [x] A macOS user-level service owns the already-built `iam-app` JAR, so the
      process does not depend on an interactive terminal after `launchctl`
      loads it.
- [x] The service sets `IAM_JWT_PRIVATE_KEY_PATH` to this repository's
      absolute `keys/rsa-private.pem` path, starts at user login, and restarts
      after an abnormal process exit.
- [x] `127.0.0.1:8090` is listening and `GET /actuator/health` returns `UP`
      after the daemon is loaded.

## Out of Scope

- Editing `platform-iam-web`, its environment files, or any other Platform IAM
  project.
- Changing application source, Flyway migrations, authentication contracts, or
  committing any changes.
- Persisting credentials, keys, or container configuration in Git.

## Key Decisions and Risks

- The request is a lightweight operational verification task, so this PRD is
  the sole planning artifact.
- The user explicitly authorized JDK 26 installation, persistent current-user
  shell configuration, and local MySQL startup, superseding the prior
  prohibition on environment preparation.
- Homebrew does not package JDK 26 on this machine. The approved source is the
  official OpenJDK macOS/AArch64 archive build, installed only under the
  current user's home directory.
- Startup applies Flyway migrations and platform bootstrap seed data to the
  configured database. It must not be pointed at an unknown shared database.
- The dedicated MySQL instance will use the application's configured local
  JDBC target (`127.0.0.1:3306/unify_iam`) so no tracked configuration change
  is needed.
- JDK 26 disables automatic annotation-processor discovery. Maven commands
  for this project must include `-Dmaven.compiler.proc=full` so Lombok
  generates constructors and accessors while compiling the Java 21 target.
- A generated JWT key under this repository's ignored `keys/` directory is a
  local runtime artifact and must remain untracked.

## Execution Results

- OpenJDK 26.0.2.1 was downloaded from the official OpenJDK archive, verified
  against its published SHA-256, and installed at
  `/Users/ramiro.li/.local/jdks/jdk-26.0.2.1.jdk/Contents/Home`.
- `/Users/ramiro.li/.zprofile` now conditionally exports that path as
  `JAVA_HOME` and prepends `$JAVA_HOME/bin` to `PATH` for login shells.
- `mvn clean install -DskipTests -Dmaven.compiler.proc=full` completed and
  installed `iam-app` into the local Maven repository.
- The dedicated `platform-iam-service-mysql` container runs MySQL 8.0.46 at
  `127.0.0.1:3306`, is healthy, and contains the `unify_iam` database.
- The application is running on `127.0.0.1:8090`; health, JWKS, and seeded
  `platform_admin` token issuance were validated without exposing token values.

## Persistent Runtime Addendum

- User confirmed that the service must remain available beyond the launching
  terminal and explicitly authorized a user-scoped macOS service manager
  configuration. This remains an operational-only change: no product source,
  tracked application configuration, credentials, or keys may be changed.
- The configured database remains the dedicated local MySQL container. Its
  availability is an external dependency of the user-level IAM service.
- Logs must remain under the current user's `~/Library/Logs/` directory, and
  the launch agent must be installed under `~/Library/LaunchAgents/`, outside
  the repository and outside version control.

## Persistent Service Execution Results

- Created the user-only launch agent at
  `/Users/ramiro.li/Library/LaunchAgents/com.platform-iam.service.plist` and
  its owner-only log directory at `/Users/ramiro.li/Library/Logs/platform-iam`.
  The plist is outside the repository, runs the existing JAR with the approved
  absolute JDK path and working directory, provides the absolute JWT key path
  via `IAM_JWT_PRIVATE_KEY_PATH`, runs at login, records stdout/stderr in that
  log directory, and restarts a non-successful exit after a 10-second throttle.
- Validated the plist with `plutil -lint`, then loaded it in the current user
  GUI domain with `launchctl bootstrap gui/501` and explicitly started it with
  `launchctl kickstart -k gui/501/com.platform-iam.service`.
- `launchctl print` reports `state = running`, the intended JAR arguments and
  key-path environment variable. The Java process is parented by PID 1, so it
  is not owned by an interactive shell.
- `lsof -nP -iTCP:8090 -sTCP:LISTEN` shows the Java process listening on
  `*:8090`. `curl --noproxy '*' http://127.0.0.1:8090/actuator/health` returns
  `{"status":"UP","groups":["liveness","readiness"]}`; the JWKS endpoint
  also returns HTTP 200.
- Restart behavior was exercised: the initial Java PID `77194` was terminated
  with `SIGKILL`; `launchd` restarted it as PID `77701`, recorded
  `last terminating signal = Killed: 9`, and the health endpoint returned `UP`
  after restart.
- The current branch is `feature/v0.10.2-m10w2-lee`. At validation time, Git
  reported the pre-existing modified
  `.trellis/spec/backend/quality-guidelines.md` and this untracked task
  directory; no tracked product source or application configuration was
  modified by the persistent-service work.

## Remaining Operational Risk

- The launch agent owns only the IAM JVM. It depends on the separately managed
  local MySQL container remaining available at `127.0.0.1:3306`; if MySQL is
  unavailable, the agent will retry the JVM after abnormal exits, but the
  application cannot become healthy until the database is restored.
- The service runs the current built JAR at
  `iam-app/target/iam-app-0.0.1-SNAPSHOT.jar`. A later rebuild changes that
  artifact in place; restarting the launch agent applies it. The service file
  intentionally avoids embedding keys, credentials, or database configuration.

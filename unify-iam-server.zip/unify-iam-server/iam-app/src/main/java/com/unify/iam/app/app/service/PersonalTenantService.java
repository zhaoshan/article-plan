package com.unify.iam.app.app.service;

import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 个人租户编排（架构 §7.1 场景 A）：注册/consumer 时复用或新建 PERSONAL 租户 + Owner 成员。
 */
@Service
public class PersonalTenantService {

    private final TenantRepository tenantRepository;
    private final MembershipRepository membershipRepository;
    private final UserRepository userRepository;

    public PersonalTenantService(TenantRepository tenantRepository,
                                 MembershipRepository membershipRepository,
                                 UserRepository userRepository) {
        this.tenantRepository = tenantRepository;
        this.membershipRepository = membershipRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public MembershipPO ensurePersonalTenantAndOwner(UserPO user) {
        TenantPO personal = tenantRepository.findActiveByOwnerAndType(user.getUserId(), "PERSONAL").orElse(null);
        if (personal == null) {
            personal = new TenantPO();
            personal.setTenantId(IdGenerator.newBizId());
            personal.setTenantCode("p-" + user.getUserId().substring(0, Math.min(10, user.getUserId().length())));
            personal.setTenantName((user.getDisplayName() != null ? user.getDisplayName() : user.getUsername()) + " 的个人空间");
            personal.setTenantType("PERSONAL");
            personal.setTenantStatus("ACTIVE");
            personal.setRegistrationSource("SELF_SERVICE");
            personal.setOwnerUserId(user.getUserId());
            tenantRepository.create(personal);
        }
        String tenantId = personal.getTenantId().trim();
        MembershipPO membership = membershipRepository.findByTenantAndUser(tenantId, user.getUserId())
                .orElseGet(() -> {
                    MembershipPO po = new MembershipPO();
                    po.setMembershipId(IdGenerator.newBizId());
                    po.setTenantId(tenantId);
                    po.setUserId(user.getUserId());
                    po.setMembershipStatus("ACTIVE");
                    po.setJoinSource("SELF_REGISTER");
                    po.setIsDefault(1);
                    membershipRepository.create(po);
                    return membershipRepository.findByTenantAndUser(tenantId, user.getUserId())
                            .orElseThrow();
                });
        userRepository.updateDefaultTenant(user.getUserId(), tenantId);
        return membership;
    }
}

-- Cascade soft-delete & partial unique keys (2026-11-06).
-- Existing migrations are immutable; this file is additive/replacement-of-index only.
--
-- 背景：username / primary_email / (tenant_id,user_id) 均为硬唯一键，包含软删行——
-- 软删后邮箱/用户名/成员关系无法复用。方案：生成列部分唯一索引（delete_flag=0 才参与唯一性，
-- 软删行生成 NULL，MySQL 唯一索引允许多个 NULL），原值保留可审计，优于混淆值方案。

-- ① 存量防御：已有软删用户的 username/primary_email 若与活人撞值会导致生成列唯一索引建不起来——
--    先混淆存量软删行（幂等；当前预期无存量，纯兜底）。
UPDATE `gateway_user`
   SET `username` = CONCAT(`username`, '~del~', SUBSTRING(`user_id`, 1, 8))
 WHERE `delete_flag` = 1 AND `username` NOT LIKE '%~del~%';
UPDATE `gateway_user`
   SET `primary_email` = CONCAT(`primary_email`, '~del~', SUBSTRING(`user_id`, 1, 8))
 WHERE `delete_flag` = 1 AND `primary_email` IS NOT NULL AND `primary_email` NOT LIKE '%~del~%';

-- ② gateway_user：唯一键迁至生成列（仅存活行）
ALTER TABLE `gateway_user`
  ADD COLUMN `active_username` VARCHAR(255) GENERATED ALWAYS AS (
    CASE WHEN `delete_flag` = 0 THEN `username` END) STORED
    COMMENT '存活用户名（软删行为 NULL，参与唯一索引）',
  ADD COLUMN `active_email` VARCHAR(255) GENERATED ALWAYS AS (
    CASE WHEN `delete_flag` = 0 THEN `primary_email` END) STORED
    COMMENT '存活主邮箱（软删行为 NULL，参与唯一索引；邮箱可重新注册）';
ALTER TABLE `gateway_user`
  DROP INDEX `uk_gateway_user_username`,
  DROP INDEX `uk_gateway_user_primary_email`,
  ADD UNIQUE KEY `uk_gateway_user_active_username` (`active_username`),
  ADD UNIQUE KEY `uk_gateway_user_active_email` (`active_email`);

-- ③ gateway_membership：唯一键迁至生成列（租户级联删成员后，同用户可重新加入该租户）
ALTER TABLE `gateway_membership`
  ADD COLUMN `active_tu` VARCHAR(80) GENERATED ALWAYS AS (
    CASE WHEN `delete_flag` = 0 THEN CONCAT(`tenant_id`, '|', `user_id`) END) STORED
    COMMENT '存活成员键 tenant|user（软删行为 NULL，参与唯一索引）';
ALTER TABLE `gateway_membership`
  DROP INDEX `uk_gateway_membership_tenant_user`,
  ADD UNIQUE KEY `uk_gateway_membership_active_tu` (`active_tu`);

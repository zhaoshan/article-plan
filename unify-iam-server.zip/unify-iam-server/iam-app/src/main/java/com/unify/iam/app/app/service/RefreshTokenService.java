package com.unify.iam.app.app.service;

import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.infra.persistence.po.RefreshTokenPO;
import com.unify.iam.app.infra.persistence.repository.RefreshTokenRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import org.springframework.stereotype.Service;

/**
 * refresh token 生命周期（docs/04 §3.3）：签发 / 轮换（旧作废+新生效）/ 撤销。
 *
 * <p>安全：落库存 SHA-256 哈希（非明文）；轮换后旧 refresh 立即失效；TTL 默认 30 天（大于 access）。
 */
@Service
public class RefreshTokenService {

    private final RefreshTokenRepository refreshTokenRepository;
    private final MembershipResolver membershipResolver;
    private final IamProperties props;

    public RefreshTokenService(RefreshTokenRepository refreshTokenRepository,
                               MembershipResolver membershipResolver,
                               IamProperties props) {
        this.refreshTokenRepository = refreshTokenRepository;
        this.membershipResolver = membershipResolver;
        this.props = props;
    }

    /** 轮换结果：新 refresh + 其绑定的用户/成员上下文（controller 据此重签 access）。 */
    public record Rotated(String newRefreshToken, String userId, String membershipId, String tenantId) {
    }

    /** 签发一个新的 refresh token（绑定用户+成员上下文），返回明文一次。 */
    public String issue(String userId, MembershipPO membership) {
        String plain = randomToken();
        RefreshTokenPO po = new RefreshTokenPO();
        po.setRefreshTokenId(IdGenerator.newBizId());
        po.setUserId(userId.trim());
        po.setTenantId(membership.getTenantId().trim());
        po.setMembershipId(membership.getMembershipId().trim());
        po.setRefreshTokenHash(sha256(plain));
        po.setExpiresAt(LocalDateTime.now().plusDays(props.getJwt().getRefreshTtlDays()));
        refreshTokenRepository.insert(po);
        return plain;
    }

    /** 轮换：校验旧 token → 作废旧 → 签发新（同用户+成员）。 */
    public Rotated rotate(String refreshToken) {
        RefreshTokenPO po = refreshTokenRepository.findActiveByHash(sha256(refreshToken))
                .orElseThrow(() -> AuthException.unauthorized("refresh token 无效或已过期"));
        // 租户必须 ACTIVE（findActiveById）：漏查会让停用租户绕过续签签出新 token（防停用绕过）
        MembershipPO membership = membershipResolver.findActiveById(po.getMembershipId())
                .filter(m -> m.getUserId().equals(po.getUserId())
                        && "ACTIVE".equals(m.getMembershipStatus()))
                .orElseThrow(() -> AuthException.unauthorized("refresh token 无效或已过期"));
        refreshTokenRepository.markRevoked(po.getId()); // 轮换：旧 refresh 立即作废
        String newPlain = issue(po.getUserId(), membership);
        return new Rotated(newPlain, po.getUserId(), po.getMembershipId(), po.getTenantId());
    }

    /** 撤销（登出）：置 revoked_at，后续不可用。 */
    public void revoke(String refreshToken) {
        refreshTokenRepository.findActiveByHash(sha256(refreshToken))
                .ifPresent(po -> refreshTokenRepository.markRevoked(po.getId()));
    }

    public long refreshTtlSeconds() {
        return props.getJwt().getRefreshTtlDays() * 86400L;
    }

    private String randomToken() {
        byte[] buf = new byte[48];
        new SecureRandom().nextBytes(buf);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(buf);
    }

    private String sha256(String value) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (Exception e) {
            throw new IllegalStateException("refresh token 哈希失败", e);
        }
    }
}
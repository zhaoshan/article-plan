package com.unify.iam.app.support;

import jakarta.mail.Address;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.mail.MailSendException;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/** Captures member invitation messages in tests instead of delivering them to SMTP. */
public final class MemberInvitationTestMailSender extends JavaMailSenderImpl {

    private static final Pattern TOKEN_PATTERN = Pattern.compile("token=([^&\"<]+)");

    private final List<MimeMessage> messages = new ArrayList<>();
    private boolean failNextSend;

    @Override
    public synchronized void send(MimeMessage mimeMessage) {
        if (failNextSend) {
            failNextSend = false;
            throw new MailSendException("simulated member invitation SMTP outage");
        }
        messages.add(mimeMessage);
    }

    @Override
    public synchronized void send(MimeMessage... mimeMessages) {
        for (MimeMessage mimeMessage : mimeMessages) {
            send(mimeMessage);
        }
    }

    public synchronized void failNextSend() {
        failNextSend = true;
    }

    public synchronized int sentCount() {
        return messages.size();
    }

    public synchronized void reset() {
        messages.clear();
        failNextSend = false;
    }

    public synchronized String latestTokenFor(String recipient) {
        for (int index = messages.size() - 1; index >= 0; index--) {
            MimeMessage message = messages.get(index);
            if (!hasRecipient(message, recipient)) {
                continue;
            }
            Matcher matcher = TOKEN_PATTERN.matcher(html(message));
            if (matcher.find()) {
                return URLDecoder.decode(matcher.group(1), StandardCharsets.UTF_8);
            }
        }
        throw new IllegalStateException("no invitation token captured for recipient");
    }

    public synchronized String latestHtmlFor(String recipient) {
        for (int index = messages.size() - 1; index >= 0; index--) {
            MimeMessage message = messages.get(index);
            if (hasRecipient(message, recipient)) {
                return html(message);
            }
        }
        throw new IllegalStateException("no invitation message captured for recipient");
    }

    private boolean hasRecipient(MimeMessage message, String recipient) {
        try {
            Address[] recipients = message.getAllRecipients();
            if (recipients == null) {
                return false;
            }
            for (Address address : recipients) {
                if (recipient.equalsIgnoreCase(address.toString())) {
                    return true;
                }
            }
            return false;
        } catch (MessagingException ex) {
            throw new IllegalStateException("cannot inspect captured recipient", ex);
        }
    }

    private String html(MimeMessage message) {
        try {
            Object content = message.getContent();
            return content == null ? "" : content.toString();
        } catch (MessagingException | IOException ex) {
            throw new IllegalStateException("cannot inspect captured invitation", ex);
        }
    }
}

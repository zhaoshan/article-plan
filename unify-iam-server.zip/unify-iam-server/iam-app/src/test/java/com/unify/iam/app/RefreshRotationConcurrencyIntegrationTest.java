package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.app.app.service.RefreshTokenService;
import com.unify.iam.common.exception.AuthException;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

/**
 * P1-D01 refresh 并发轮换原子性集成测试：同一 refresh token 并发多请求轮换，
 * 必须「恰好一个成功」（原子条件消费），其余全部 401——原「先查后改」实现下
 * 并发请求可同时通过校验多次成功（安全报告 D4 动态证据）。
 */
class RefreshRotationConcurrencyIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private RefreshTokenService refreshTokenService;

    @Test
    void concurrentRotationOfSameTokenSucceedsExactlyOnce() throws Exception {
        // 取一个有效 refresh token（登录 admin）
        String body = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String plain = unwrapData(body).get("refresh_token").toString();

        // 4 线程同步并发轮换同一 token
        int threads = 4;
        CountDownLatch ready = new CountDownLatch(threads);
        CountDownLatch fire = new CountDownLatch(1);
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        AtomicInteger successes = new AtomicInteger();
        AtomicInteger failures = new AtomicInteger();
        ConcurrentLinkedQueue<RefreshTokenService.Rotated> rotated = new ConcurrentLinkedQueue<>();
        try {
            for (int i = 0; i < threads; i++) {
                pool.submit(() -> {
                    ready.countDown();
                    try {
                        fire.await();
                        RefreshTokenService.Rotated r = refreshTokenService.rotate(plain);
                        rotated.add(r);
                        successes.incrementAndGet();
                    } catch (AuthException e) {
                        if (e.getHttpStatus() == 401) {
                            failures.incrementAndGet();
                        } else {
                            throw new IllegalStateException("unexpected status " + e.getHttpStatus(), e);
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new IllegalStateException(e);
                    }
                    return null;
                });
            }
            assertThat(ready.await(30, TimeUnit.SECONDS)).isTrue();
            fire.countDown();
        } finally {
            pool.shutdown();
            assertThat(pool.awaitTermination(60, TimeUnit.SECONDS)).isTrue();
        }

        assertThat(successes.get()).as("同一 refresh 并发轮换成功次数必须为 1").isEqualTo(1);
        assertThat(failures.get()).isEqualTo(threads - 1);

        // 旧 token 已消费：再轮换 → 401
        assertThatThrownBy401(() -> refreshTokenService.rotate(plain));
        // 胜出新 token 可用（单次消费后再轮换 → 401）
        String newPlain = rotated.iterator().next().newRefreshToken();
        refreshTokenService.rotate(newPlain);
        assertThatThrownBy401(() -> refreshTokenService.rotate(newPlain));
    }

    private void assertThatThrownBy401(org.assertj.core.api.ThrowableAssert.ThrowingCallable call) {
        org.assertj.core.api.Assertions.assertThatThrownBy(call)
                .isInstanceOf(AuthException.class)
                .extracting("httpStatus").isEqualTo(401);
    }
}

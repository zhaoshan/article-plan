# Design

Add a management-only repository query. PLATFORM omits scope predicates after the service authorizes platform access. Other requests use TENANT plus scope_id after tenant authorization. Both preserve automatic logical deletion and id ordering. Existing listByScope remains ACTIVE-only for runtime consumers. Return fields and permission count enrichment stay intact.

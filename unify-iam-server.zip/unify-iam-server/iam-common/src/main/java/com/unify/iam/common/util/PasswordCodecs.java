package com.unify.iam.common.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * 密码字段线上编码约定（docs/user-manual/05 §0）：请求体中所有密码字段一律 base64 传输——
 * 对接方审计「不得明文传输」的形式要求；base64 是编码非加密，真实机密性仍由 TLS 承担。
 *
 * <p>注意：base64 字符集与常见密码字符重叠，宽容解码会把明文密码误判为 base64 解出垃圾——
 * 因此解码是<b>严格模式</b>（非法 base64 直接抛 {@link IllegalArgumentException}），
 * 所有调用方（web/parlant/测试）必须同步编码，无兼容明文期。
 */
public final class PasswordCodecs {

    private PasswordCodecs() {
    }

    /** 严格解码：非法 base64（含解出非法 UTF-8）抛 IllegalArgumentException，由调用方转业务异常。 */
    public static String decodeBase64(String encoded) {
        if (encoded == null || encoded.isBlank()) {
            throw new IllegalArgumentException("password is not base64-encoded");
        }
        byte[] decoded = Base64.getDecoder().decode(encoded.trim());
        return new String(decoded, StandardCharsets.UTF_8);
    }

    /** 编码（客户端/测试用；UTF-8 安全：非 ASCII 密码如中文/emoji 经 UTF-8 字节编码）。 */
    public static String encodeBase64(String raw) {
        return Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
    }
}

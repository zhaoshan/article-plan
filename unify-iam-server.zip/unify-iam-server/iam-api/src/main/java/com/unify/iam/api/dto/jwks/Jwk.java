package com.unify.iam.api.dto.jwks;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * JWK（RFC 7517）：{@code GET /.well-known/jwks.json} 的单个密钥。
 * 形状与 parlant {@code PyJWKClient} 消费的 JWKS 一致。
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record Jwk(
        String kty,
        String kid,
        String n,
        String e,
        String alg,
        @JsonProperty("use") String use) {

    public static Jwk of(String kty, String kid, String n, String e, String alg, String use) {
        return new Jwk(kty, kid, n, e, alg, use);
    }
}

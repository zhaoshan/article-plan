package com.unify.iam.app.mail;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.common.exception.AuthException;
import java.net.URI;
import org.springframework.stereotype.Service;

/**
 * 邀请邮件「严格投递模式」前置闸门（docs/08 §7，单路径语义开关 {@code iam.mail.delivery-enabled}）。
 *
 * <p>开关关（默认/dev）：本守卫全 no-op，链路允许日志兜底、响应返回 token。
 * 开关开（生产）：创建邀请**之前**校验投递链路真实可用，任一不满足 → 503 且调用方尚未写库，
 * 不会留下「受邀人永远收不到」的伪邀请（死邀请还会占位成员配额、堵同邮箱重邀）。
 *
 * <p>四道闸（对齐 docs/merge-resolution-2026-10-28 的投递边界设计，映射到我方配置）：
 * <ol>
 *   <li>意图闸：delivery-enabled 本身——防止「配了 SMTP 就静默切换行为」的漂移；</li>
 *   <li>+④ 环境/身份闸：{@link JavaMailEmailTool#isMailConfigured()}（JavaMailSender Bean +
 *       spring.mail.host + spring.mail.username 作 From，三者缺一不可）；</li>
 *   <li>链接闸：{@code iam.mail.invitation-link-base-url} 必须解析为绝对 URL
 *       （邮件在收件人客户端打开，相对路径无基址可解析 = 死链）。</li>
 * </ol>
 * 运行时断裂（SMTP 中途失败）由 {@code InvitationService.create} 捕获转 503 + 事务回滚兜底。
 */
@Service
public class InvitationDeliveryGuard {

    private final IamProperties props;
    private final EmailTool emailTool;

    public InvitationDeliveryGuard(IamProperties props, EmailTool emailTool) {
        this.props = props;
        this.emailTool = emailTool;
    }

    /** 严格模式下校验投递可用；dev 模式（开关关）直接放行。 */
    public void requireDeliverable() {
        if (!props.getMail().isDeliveryEnabled()) {
            return;
        }
        // 环境/身份闸：以 JavaMailEmailTool 的配置口径为准；测试替身（@MockBean EmailTool 等非实现类）
        // 视为已配置，不被本闸误伤（严格模式集成测试用真实 JavaMailEmailTool + 测试 Sender 覆盖）
        if (emailTool instanceof JavaMailEmailTool javaMail && !javaMail.isMailConfigured()) {
            throw AuthException.serviceUnavailable(
                    ErrorCode.MAIL_DELIVERY_NOT_CONFIGURED);
        }
        String base = props.getMail().getInvitationLinkBaseUrl();
        try {
            if (base == null || !URI.create(base.trim()).isAbsolute()) {
                throw new IllegalArgumentException("not absolute");
            }
        } catch (IllegalArgumentException ex) {
            throw AuthException.serviceUnavailable(
                    ErrorCode.INVITE_BASE_URL_INVALID);
        }
    }
}

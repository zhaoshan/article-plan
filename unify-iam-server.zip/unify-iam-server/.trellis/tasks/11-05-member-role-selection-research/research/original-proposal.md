# Member role selection proposal — awaiting confirmation

## Outcome and decision status
Use one member-assignment candidate API for Invite members and Edit role. **Recommend a dedicated endpoint**, reusing repository/template logic, rather than overloading management scope/filter semantics. This is a proposed contract, not shipped behavior or approval to implement. The user must confirm the authorization policy below; no Phase 2 activation is permitted yet.

## Compare the three approaches
| Approach | Concrete shape | Benefits | Costs / decision |
| --- | --- | --- | --- |
| Extend original API | GET `/admin/roles?scope_type=TENANT&scope_id=T&purpose=MEMBER_ASSIGNMENT` | Existing payload/client integration; lowest route churn. | Must introduce a distinct OR-union query, status/Owner rules and mode-dependent permission checks (`iam:role:read` vs member workflow), not just add filter_scope_type. TENANT currently never exposes PLATFORM rows. A boolean `include_platform` alone leaves Owner/grant/status unresolved. Feasible second choice if route stability is prioritized, but isolated service policy remains necessary. Default purpose must retain old behavior; reject management-only filter combinations in assignment mode. |
| Reuse another current API | member roles, application catalog, tenant details or memberships | No new route. | None provides the candidate set: assigned bindings are incomplete, templates lack concrete custom-role IDs, aggregations omit unassigned roles and carry unrelated permissions. Frontend merging/filtering two admin role calls would need platform read privileges, download excess tenant data, duplicate policy and still not fix invitation writes. Reject. |
| Dedicated candidate API | GET `/api/v1/admin/members/role-options?tenant_id=T` | Member permission boundary; explicit target; one shared contract; leaves role administration unchanged; can share eligibility policy with writes. | New DTO/controller/service/query and frontend method; cross-path validation work still required. Recommended because assignment is a separate authorization operation, not merely a role-management filter. |

No schema migration is needed for the proposed endpoint and restricted grant policy. If PLATFORM must become a reusable business-role scope without platform authority, that is a separate authorization-model design/migration, not covered by this claim.

## Requested collection
For an authorized concrete target tenant T, return the following non-deleted role rows, ordered by internal id ASC, deduplicated by role_id, unpaginated:

```
(global scope_type=PLATFORM AND scope_id=PLATFORM AND is_builtin=0)
OR
(scope_type=TENANT AND scope_id=T AND NOT owner_for_tenant(T, role_code))
```

Apply `delete_flag=0` to the entire union, not only one arm. Owner codes come from the target tenant's enabled application templates with is_owner=1, compared by trimmed code, never from a hardcoded Owner name or is_builtin. Do not exclude builtin non-owner tenant roles. Do not use actor/current-token tenant instead of the selected target tenant when a platform administrator edits a member in another tenant.

Interpret 'platform administrator created' via global scope + is_builtin=0: current fields do not reliably prove creator category after historical changes. Malformed PLATFORM scope_id rows are excluded under the canonical global scope convention and should be investigated separately. Do not inject template-only roles that have no persisted role_id.

The user's 'all tenant roles except Owner' does not specify status. **Proposed**: include DISABLED rows for transparency, with can_assign=false. ACTIVE controls new grants. Do not silently switch the collection to ACTIVE-only, and do not remove disabled rows from the management list.

## Proposed authorization policy requiring confirmation
1. Require authenticated `iam:member:write` for this picker, since both consumers prepare member mutations. Do not require role read/write or tenant read. Existing GET current bindings still requires `iam:member:read`; Edit role needs both permissions to operate safely.
2. Require a nonblank explicit tenant_id, normalize once, then authorize the target with TenantScopeGuard before tenant existence lookup. Platform administrators may target any tenant; other callers must target their token tenant. Missing/deleted authorized target returns 404.
3. Return the exact requested collection, but for tenant-level callers mark PLATFORM options `can_assign=false`, `unavailable_reason=PLATFORM_ADMIN_REQUIRED`. Platform administrators may grant ACTIVE custom PLATFORM roles, accepting their current platform scope authority. This policy and the visibility of global role metadata require user confirmation; it is not asserted as an existing product rule.
4. Mark DISABLED options unassignable for all actors, reason ROLE_DISABLED (status reason takes precedence if both constraints apply). No silent role-name or permission-subset inference.
5. If tenant admins must be able to select all custom PLATFORM roles, do not ship this restricted policy as if it satisfied that intent: first decouple global role reuse from `isPlatformAdmin` and define effective permission/app boundaries. That is a wider security change. Holding any PLATFORM role today changes scope authority even when is_builtin=0; endpoint permission checks still apply.

## Request and response contract (new; proposed)

```http
GET /api/v1/admin/members/role-options?tenant_id=tenant-org-a
Authorization: Bearer <access_token>
```

Only tenant_id is supported initially. No scope tuple, role-management filter fields, keyword, pagination or membership_id. Reject recognized incompatible scope/filter parameters with 400 rather than implying they constrain this API; document other unknown parameters as unsupported. A dedicated strict request binder should enforce the documented contract.

Success HTTP 200, sample for a platform administrator:

```json
{
  "success": true,
  "data": {
    "tenant_id": "tenant-org-a",
    "roles": [
      {
        "role_id": "global-custom-id",
        "role_code": "SupportGlobal",
        "role_name": "Global support",
        "scope_type": "PLATFORM",
        "scope_id": "PLATFORM",
        "role_status": "ACTIVE",
        "is_builtin": false,
        "is_owner": false,
        "can_assign": true
      },
      {
        "role_id": "tenant-reader-id",
        "role_code": "Reader",
        "role_name": "Reader",
        "scope_type": "TENANT",
        "scope_id": "tenant-org-a",
        "role_status": "DISABLED",
        "is_builtin": true,
        "is_owner": false,
        "can_assign": false,
        "unavailable_reason": "ROLE_DISABLED"
      }
    ],
    "count": 2
  }
}
```

Required fields: tenant_id, roles, count; each row has the fields shown other than unavailable_reason. role_description is optional. unavailable_reason is present only when can_assign=false and is an enum (`ROLE_DISABLED`, `PLATFORM_ADMIN_REQUIRED`), not an ErrorCode. count includes all returned visible rows and equals roles.length, not selectable count. All returned is_owner flags are false by construction. No permissionCounts or permission IDs are needed by these controls. Optional nulls, including success code/message, may be omitted under existing NON_NULL serialization. Empty result is success with roles=[] and count=0.

| Condition | HTTP / behavior |
| --- | --- |
| Missing/invalid authentication | 401, standard failure envelope |
| Missing member write or unauthorized target | 403; no candidate lookup for unauthorized target |
| Missing/blank tenant_id, incompatible recognized query parameters | 400 |
| Authorized target absent/deleted | 404, existing TENANT_NOT_FOUND |
| No candidates, or all unassignable | 200; explicit empty/nonselectable UI |
| Dependency/server failure | Standard 5xx failure envelope, retry UI |

Errors keep real HTTP status and `{success:false,code,message}` with nullable data omitted as currently configured. New validation conditions need centralized error-catalog entries after approval; do not invent conflicting IAM numeric codes in this research. Existing permission/target errors should reuse their current entries.

## Read/write consistency is a prerequisite to rollout
A picker endpoint is not an authorization check for submitted role IDs. Create a reusable actor + target + role policy for the candidate service and member/invitation writes. Validate role existence/non-deletion, ACTIVE for newly granted IDs, tenant scope or authorized custom PLATFORM scope, and non-Owner member assignment. Reject the entire submitted mutation atomically when any newly granted role is ineligible; never silently intersect submitted IDs.

- Invite retains singular `{email,tenant_id,role_id}` and requires the UI to select and explicitly send a valid role. Current omission triggers Owner/admin fallback; keep that legacy backend default outside this picker path unless separately approved. Do not blanket change shared issueForTenant/default resolution used by tenant creation/Owner flows. To accept PLATFORM choices from platform administrators, ordinary member invitation orchestration must adopt the new grant rule instead of the existing TENANT-only assertRoleInTenant. No invitation role_ids expansion is proposed.
- Edit retains PUT `{role_ids:[...]}` and current GET bindings for initial selection. Preserve existing last-admin, Owner uniqueness, DIRECT/IdP grant semantics, token-version bump and audit. Currently held roles missing from candidates must be shown as locked existing bindings and retained until explicitly supported removal is possible; do not automatically replace them with an empty/intersection set. Backend must distinguish retained bindings from new grants: keeping an existing disabled/Owner binding is not a new grant; ordinary edits must not introduce Owner or remove a protected Owner as a side effect. MembershipRoleRepository retains its existing source behavior; UI must not represent IdP roles as freely editable DIRECT roles. If current GET metadata is insufficient to identify source or protected grants, enrich the current-binding read contract separately after approval, or lock that editor rather than guessing.
- Member add uses the same new-grant validator if supplied role IDs, closing the existing bypass alongside setRoles; do not leave another public member-write route accepting IDs the picker rejects.
- Acceptance must revalidate the saved role against current existence/status/target rules; a role can change after invite creation. A PLATFORM grant needs persisted issuance authorization context (or a reliably linked issuer audit record) to distinguish an authorized platform invitation from an unauthorized one, and an explicit policy for issuer authority revocation. This is a follow-up design gate before implementation, not an already-supported storage field. Recommended: re-check issuing actor's current platform grant authority on accept, rejecting if it has been lost. Public acceptance has no administrator claims, so do not accidentally authorize against the invitee.
- Existing Owner setup/transfer purposes remain separate and retain their invariants. Audit historical/legacy invitations before tightening acceptance rules, especially absent issuer provenance. Scope of this work and any compatibility treatment must be reviewed before business implementation.

## Frontend loading contract
No server `loading` field or special loading endpoint is required. Both dialogs share the candidate query and normalize `data.roles` once.

| UI/request state | Edit role | Invite members role panel |
| --- | --- | --- |
| Initial pending | Skeleton role rows; retain current selection separately; do not show false empty state. Wait for candidates AND current bindings before editable initialization. | Trigger remains enabled. Opening panel shows skeleton rows while request is pending. |
| Success | Render candidates and current selection; honor can_assign. | Opening panel renders resolved options immediately. |
| Success empty | Explicit no-available-roles message; no accidental clearing of existing roles. | Explicit empty panel; block submission without a chosen role. |
| Error | Inline failure + retry; preserve selections, stop skeleton. | Trigger stays operable; panel shows failure + retry; block invite submission without valid selection. |

Only the Invite dropdown trigger's loading disablement is removed. Actual role choices and mutation submission remain unavailable until valid data/selection is ready. Do not submit omitted role_id as a workaround for pending/error. For Edit role, do not submit partial or default-empty role_ids while either read is pending.

Key caches by target tenant AND actor/membership authorization context, not just URL/tenant; sign-out/tenant/identity changes invalidate them. Fetch once on dialog open or use a valid cache; do not restart the request on every dropdown click. Ignore/abort stale results on tenant change or dialog close. Reopen may show a valid completed cache immediately; if the request is pending show skeleton. Invalidate after role changes; write validation still handles stale data. In a platform-wide member list, use the selected row's tenant_id, never a synthetic PLATFORM value. Existing frontend fetch behavior and component locations need verification in its own authorized project later; this repository contains no frontend implementation.

## Compatibility, rollout and risks
- Old GET /admin/roles calls, filter_* semantics, rich response, DISABLED visibility and runtime ACTIVE queries remain unchanged; do not filter their global list by a target tenant.
- Introduce the new API before frontend adoption. Never fall back to a broader old management query when the new endpoint fails. Roll out query and approved write policy together to avoid unsubmitable PLATFORM selections. Revert frontend adoption first if rollback is needed; retain all issued invitation provenance needed by acceptance.
- New write validation intentionally rejects inputs previously accepted by member mutations; audit consumers and treat this as a security/compatibility change, not a purely additive GET.
- No N+1 queries: query the two-arm role set, load target application Owner codes in batches, and evaluate actor authority once. Unpaginated behavior matches the current role list but can become large; measure before separately introducing pagination.
- Existing dirty role-management work may still evolve. Recheck anchors and query behavior before later implementation; do not overwrite those edits.
- This source review did not run tests or verify deployed data. The role_status omission in platform-admin detection and broader authorization-model weaknesses are documented risks, not silently repaired here.

## Decision required
Confirm the dedicated API and restricted grant policy (global options visible, only existing platform admins may newly grant PLATFORM roles, disabled rows visible/unassignable), or require tenant admins to grant global custom roles and commission the broader authority-model redesign first. Acceptance provenance/legacy invitation compatibility and current-binding source metadata must be resolved before a later implementation-ready plan. This research task remains planning and is not marked implementation-ready.

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.unify.iam.api.dto.admin.UpdateUserRequest;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.app.service.admin.AdminUserService;
import com.unify.iam.app.infra.persistence.repository.PasswordResetTokenRepository;
import com.unify.iam.app.infra.persistence.repository.RefreshTokenRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.identity.infra.persistence.po.UserIdentityPO;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DuplicateKeyException;

@ExtendWith(MockitoExtension.class)
class AdminUserServiceTest {

    @Mock
    private UserRepository userRepository;
    @Mock
    private UserIdentityRepository userIdentityRepository;
    @Mock
    private PasswordResetTokenRepository passwordResetTokenRepository;
    @Mock
    private RefreshTokenRepository refreshTokenRepository;
    @Mock
    private TokenVersionService tokenVersionService;

    private AdminUserService service;

    @BeforeEach
    void setUp() {
        service = new AdminUserService(userRepository, userIdentityRepository, passwordResetTokenRepository,
                refreshTokenRepository, tokenVersionService);
    }

    @Test
    void updateNormalizesEmailResetsVerificationAndInvalidatesResetTokens() {
        UserPO user = user("u-1", "old@example.com");
        user.setEmailVerified(1);
        when(userRepository.findByUserId("u-1")).thenReturn(Optional.of(user));
        when(userRepository.findByPrimaryEmail("new@example.com")).thenReturn(Optional.empty());

        service.update("u-1", new UpdateUserRequest(" New@Example.COM ", null, null, null));

        assertThat(user.getPrimaryEmail()).isEqualTo("new@example.com");
        assertThat(user.getEmailVerified()).isZero();
        verify(userRepository).update(user);
        verify(passwordResetTokenRepository).invalidateByUserId("u-1");
    }

    @Test
    void updateRejectsEmailOwnedByAnotherUser() {
        UserPO user = user("u-1", "old@example.com");
        UserPO owner = user("u-2", "taken@example.com");
        when(userRepository.findByUserId("u-1")).thenReturn(Optional.of(user));
        when(userRepository.findByPrimaryEmail("taken@example.com")).thenReturn(Optional.of(owner));

        assertThatThrownBy(() -> service.update("u-1", new UpdateUserRequest("taken@example.com", null, null, null)))
                .isInstanceOf(AuthException.class)
                .hasMessage("Email is already in use");

        verify(userRepository, never()).update(any());
        verifyNoInteractions(passwordResetTokenRepository);
    }

    @Test
    void updateConvertsUniqueKeyRaceIntoBadRequest() {
        UserPO user = user("u-1", "old@example.com");
        when(userRepository.findByUserId("u-1")).thenReturn(Optional.of(user));
        when(userRepository.findByPrimaryEmail("new@example.com")).thenReturn(Optional.empty());
        doThrow(new DuplicateKeyException("uk_gateway_user_primary_email"))
                .when(userRepository).update(user);

        assertThatThrownBy(() -> service.update("u-1", new UpdateUserRequest("new@example.com", null, null, null)))
                .isInstanceOf(AuthException.class)
                .hasMessage("Email is already in use");

        verifyNoInteractions(passwordResetTokenRepository);
    }

    @Test
    void updateRejectsBlankEmailDefensively() {
        UserPO user = user("u-1", "old@example.com");
        when(userRepository.findByUserId("u-1")).thenReturn(Optional.of(user));

        assertThatThrownBy(() -> service.update("u-1", new UpdateUserRequest("   ", null, null, null)))
                .isInstanceOf(AuthException.class)
                .hasMessage("email is required");

        verify(userRepository, never()).update(any());
        verifyNoInteractions(passwordResetTokenRepository);
    }

    @Test
    void resetPasswordHashesCredentialAndInvalidatesAllTargetSessions() {
        UserPO user = user("u-1", "user@example.com");
        user.setPasswordHash("old-hash");
        when(userRepository.findByUserId("u-1")).thenReturn(Optional.of(user));
        when(userIdentityRepository.findLocalActive("u-1")).thenReturn(Optional.of(new UserIdentityPO()));

        service.resetPassword("u-1", "NewPassword123!");

        assertThat(user.getPasswordHash()).isNotEqualTo("NewPassword123!");
        assertThat(BCryptUtils.matches("NewPassword123!", user.getPasswordHash())).isTrue();
        verify(userRepository).update(user);
        verify(passwordResetTokenRepository).invalidateByUserId("u-1");
        verify(refreshTokenRepository).revokeByUser("u-1");
        verify(tokenVersionService).bumpForUser("u-1", "PASSWORD_RESET");
    }

    @Test
    void resetPasswordRejectsOidcOnlyUserWithoutWritingAnOrphanHash() {
        UserPO user = user("u-1", "user@example.com");
        when(userRepository.findByUserId("u-1")).thenReturn(Optional.of(user));
        when(userIdentityRepository.findLocalActive("u-1")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.resetPassword("u-1", "NewPassword123!"))
                .isInstanceOf(AuthException.class)
                .hasMessage("User has no local password to reset");

        verify(userRepository, never()).update(any());
        verifyNoInteractions(passwordResetTokenRepository, refreshTokenRepository, tokenVersionService);
    }

    @Test
    void resetPasswordRejectsUtf8ValuesThatBcryptWouldTruncate() {
        String overLimit = "\u20AC".repeat(25); // 25 characters, 75 UTF-8 bytes

        assertThatThrownBy(() -> service.resetPassword("u-1", overLimit))
                .isInstanceOf(AuthException.class)
                .hasMessage("password must not exceed 72 bytes");

        verifyNoInteractions(userRepository, userIdentityRepository, passwordResetTokenRepository,
                refreshTokenRepository, tokenVersionService);
    }

    private UserPO user(String userId, String email) {
        UserPO user = new UserPO();
        user.setUserId(userId);
        user.setPrimaryEmail(email);
        return user;
    }
}

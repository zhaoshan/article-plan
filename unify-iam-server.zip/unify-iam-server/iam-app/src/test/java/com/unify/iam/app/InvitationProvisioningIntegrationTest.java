package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.app.mail.EmailTool;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G2 集成测试：邀请 JIT 建号 + 初始密码 + Owner 邮箱开通 + 首登强制改密。
 * EmailTool 用 @MockitoBean 捕获渲染结果（测试环境无 SMTP，生产真实发送）。
 */
class InvitationProvisioningIntegrationTest extends IamIntegrationTestBase {

    private static final Pattern PW_PATTERN = Pattern.compile(
            "(?s)Temporary password.*?word-break: break-all;\\\">\\s*(\\S+)\\s*</td>");
    private static final Pattern TOKEN_PATTERN = Pattern.compile("(?:\\?|&)token=([A-Za-z0-9_\\-]+)");

    @MockitoBean
    private EmailTool emailTool;

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("access_token").toString();
    }

    private String adminToken() throws Exception {
        return login("admin", "admin123");
    }

    /** 捕获最近一封发给 to 的邮件正文。 */
    private String capturedHtml(String to) {
        ArgumentCaptor<String> html = ArgumentCaptor.forClass(String.class);
        verify(emailTool).send(eq(to), anyString(), html.capture());
        return html.getValue();
    }

    @Test
    void inviteNewEmailProvisionsAccountWithInitialPassword() throws Exception {
        MvcResult inviteRes = mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"g2new@unify.local\",\"tenant_id\":\"tenant-org-a\","
                                + "\"role_id\":\"r-1001\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.token").exists())
                .andReturn();
        String inviteToken = unwrapData(inviteRes.getResponse().getContentAsString()).get("token").toString();

        // 账号 JIT 创建：ACTIVE + 首登强制改密
        Integer mustChange = jdbcTemplate.queryForObject(
                "SELECT must_change_password FROM gateway_user WHERE primary_email='g2new@unify.local'",
                Integer.class);
        assertThat(mustChange).isEqualTo(1);

        // 新 JIT 账号（产品口径）：受邀租户成员即时创建（is_default=1）+ 生效角色绑定（未传 role → is_owner 默认 r-1002）；
        // 且不建个人租户
        Map<String, Object> m = jdbcTemplate.queryForMap(
                "SELECT m.membership_status, m.is_default FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND m.tenant_id='tenant-org-a'");
        assertThat(m.get("membership_status")).isEqualTo("ACTIVE");
        assertThat(((Number) m.get("is_default")).intValue()).isEqualTo(1);
        // 收紧语义：新 JIT 账号的角色延期到 accept 绑定——邀请后角色数为 0（accept 后=1，见尾部断言）
        Integer roleCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND m.tenant_id='tenant-org-a' AND mr.delete_flag=0",
                Integer.class);
        assertThat(roleCount).isZero();
        Integer personalTenants = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_tenant WHERE tenant_type='PERSONAL' AND owner_user_id="
                        + "(SELECT user_id FROM gateway_user WHERE primary_email='g2new@unify.local')",
                Integer.class);
        assertThat(personalTenants).isZero();
        Integer localIdentities = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user_identity ui JOIN gateway_user u ON ui.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND ui.provider_type='LOCAL'",
                Integer.class);
        assertThat(localIdentities).isEqualTo(1);

        // 邮件含初始密码区块 + 链接
        String html = capturedHtml("g2new@unify.local");
        Matcher pw = PW_PATTERN.matcher(html);
        assertThat(pw.find()).as("邮件应含初始密码").isTrue();
        // 2026-11-11 修复：app 跟随租户启用应用（tenant-org-a = parlant），不再恒 imorph
        assertThat(html).contains("token=").contains("app=parlant-agent-server");

        // 初始密码可登录，登录响应透出 must_change_password=true
        String initial = pw.group(1);
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g2new@unify.local\",\"password\":\"" + b64(initial) + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.must_change_password").value(true));

        // 首登强制改密：旧密码错误 401；正确改密后标记清零
        String bearer = login("g2new@unify.local", initial);
        mockMvc.perform(post("/api/v1/auth/change-password")
                        .header("Authorization", "Bearer " + bearer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"old_password\":\"" + b64("wrong") + "\",\"new_password\":\"" + b64("NewPass123!") + "\"}"))
                .andExpect(status().isUnauthorized());
        mockMvc.perform(post("/api/v1/auth/change-password")
                        .header("Authorization", "Bearer " + bearer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"old_password\":\"" + b64(initial) + "\",\"new_password\":\"" + b64("NewPass123!") + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("CHANGED"));
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"g2new@unify.local\",\"password\":\"" + b64("NewPass123!") + "\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.must_change_password").value(false));

        // accept：成员已建（幂等不动），角色在此刻绑定（r-1001）+ 标记 ACCEPTED + redirect_url
        mockMvc.perform(post("/api/v1/auth/invitations/" + inviteToken + "/accept")
                        .header("Authorization", "Bearer " + login("g2new@unify.local", "NewPass123!")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"))
                .andExpect(jsonPath("$.data.redirect_url").value("http://localhost:5173"));
        Integer membershipCount = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND m.tenant_id='tenant-org-a'",
                Integer.class);
        assertThat(membershipCount).isEqualTo(1);
        Integer roleAfterAccept = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2new@unify.local' AND m.tenant_id='tenant-org-a' AND mr.delete_flag=0",
                Integer.class);
        assertThat(roleAfterAccept).isEqualTo(1);

        // 幂等重放：同一人重复 accept（StrictMode 双发/双击/刷新）→ 200 + 相同 redirect_url；
        // 换他人用同一 token → 401
        mockMvc.perform(post("/api/v1/auth/invitations/" + inviteToken + "/accept")
                        .header("Authorization", "Bearer " + login("g2new@unify.local", "NewPass123!")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.redirect_url").value("http://localhost:5173"));
        mockMvc.perform(post("/api/v1/auth/invitations/" + inviteToken + "/accept")
                        .header("Authorization", "Bearer " + adminToken()))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void inviteExistingEmailOmitsPasswordBlockAndKeepsAccount() throws Exception {
        // 造一个「already exists账号但非 tenant-org-a 成员」的用户（2026-11-03 防重：已是成员的邮箱邀请会被 400）
        unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"extinv\",\"email\":\"extinv@unify.local\",\"password\":\""
                                + b64("Ext123456!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"extinv@unify.local\",\"tenant_id\":\"tenant-org-a\","
                                + "\"role_id\":\"r-1001\"}")) // 显式非 owner 角色 → member 模板
                .andExpect(status().isOk());

        // 不重复建号、不动标记
        Integer users = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_user WHERE primary_email='extinv@unify.local'", Integer.class);
        assertThat(users).isEqualTo(1);
        Integer mustChange = jdbcTemplate.queryForObject(
                "SELECT must_change_password FROM gateway_user WHERE primary_email='extinv@unify.local'",
                Integer.class);
        assertThat(mustChange).isZero();

        // 显式 role_id 原样生效（r-1001 AgentOperator，非 owner → member 模板）
        String invitedRole = jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE email='extinv@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1", String.class);
        assertThat(invitedRole).isEqualTo("r-1001");
        // 邀请盖隐含应用参数（G2 增强）
        String appCode = jdbcTemplate.queryForObject(
                "SELECT app_code FROM gateway_invitation WHERE email='extinv@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1", String.class);
        // 2026-11-11 修复：app 跟随租户启用应用（tenant-org-a = parlant）
        assertThat(appCode.trim()).isEqualTo("parlant-agent-server");

        // 已有账号（非成员）：密码区块整块移除
        verify(emailTool).send(eq("extinv@unify.local"), anyString(), contains("been invited to join"));
        String html = capturedHtml("extinv@unify.local");
        assertThat(html).doesNotContain("Temporary password");
        assertThat(html).doesNotContain("{{initial_password}}");
    }

    @Test
    void duplicateInvitesToSameEmailAreRejectedAndPendingCountedOnce() throws Exception {
        String admin = adminToken();
        // ① 首次邀请（新邮箱）→ 200
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"dup-inv@unify.local\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isOk());
        // 同邮箱未接受邀请唯一：重复邀请 → 400，且库中 PENDING 行仍=1（pending 不重复计数）
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"dup-inv@unify.local\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("pending invitation")));
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email='dup-inv@unify.local' "
                        + "AND tenant_id='tenant-org-a' AND invitation_status='PENDING'", Integer.class))
                .isEqualTo(1);
        // ② 接受后成为真成员（有角色），再邀请 → 400「已是成员」
        String rawToken = "dup-invite-token";
        jdbcTemplate.update("UPDATE gateway_invitation SET invite_token_hash=? WHERE email='dup-inv@unify.local'",
                com.unify.iam.common.util.SecureToken.hash(rawToken));
        jdbcTemplate.update("UPDATE gateway_user SET password_hash=(SELECT password_hash FROM (SELECT password_hash FROM gateway_user WHERE username='admin') t) WHERE username='dup-inv@unify.local'");
        String bearer = login("dup-inv@unify.local", "admin123");
        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken + "/accept")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"dup-inv@unify.local\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("is already a member of this tenant")));
    }

    @Test
    void removingUnacceptedMemberCancelsPendingInviteAndAllowsReinvite() throws Exception {
        String admin = adminToken();
        String email = "del-inv@unify.local";
        // ① 发邀请（新邮箱 → JIT 账号 + 成员预建 + PENDING 邀请）
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isOk());
        String inviteToken = jdbcTemplate.queryForObject(
                "SELECT invite_token_hash FROM gateway_invitation WHERE email=? AND invitation_status='PENDING'",
                String.class, email).trim();
        String msId = jdbcTemplate.queryForObject(
                "SELECT m.membership_id FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.username=? AND m.tenant_id='tenant-org-a'", String.class, email).trim();
        // ② 管理员移除该成员 → 邀请联动撤销（CANCELLED）
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .delete("/api/v1/admin/members/" + msId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT invitation_status FROM gateway_invitation WHERE email=?", String.class, email).trim())
                .isEqualTo("CANCELLED");
        // ③ 可重邀（防重不再拦截，新 PENDING 行生成）
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isOk());
        // ④ 旧邮件 token accept → 401（CANCELLED 不可再接受）
        jdbcTemplate.update("UPDATE gateway_user SET password_hash=(SELECT password_hash FROM (SELECT password_hash FROM gateway_user WHERE username='admin') t) WHERE username=?", email);
        String bearer = login(email, "admin123");
        String rawToken = "cancelled-invite-token";
        jdbcTemplate.update("UPDATE gateway_invitation SET invite_token_hash=? WHERE email=? AND invitation_status='CANCELLED'",
                com.unify.iam.common.util.SecureToken.hash(rawToken), email);
        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken + "/accept")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void removedMembersRolesAreUnboundAndReinviteStartsFresh() throws Exception {
        String admin = adminToken();
        String email = "rebind@unify.local";
        // ① 邀请（显式角色 r-1001 AgentOperator）→ 接受
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"tenant_id\":\"tenant-org-a\",\"role_id\":\"r-1001\"}"))
                .andExpect(status().isOk());
        String rawToken1 = "rebind-token-1";
        jdbcTemplate.update("UPDATE gateway_invitation SET invite_token_hash=? WHERE email=? AND invitation_status='PENDING'",
                com.unify.iam.common.util.SecureToken.hash(rawToken1), email);
        jdbcTemplate.update("UPDATE gateway_user SET password_hash=(SELECT password_hash FROM (SELECT password_hash FROM gateway_user WHERE username='admin') t) WHERE username=?", email);
        String bearer = login(email, "admin123");
        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken1 + "/accept")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isOk());
        String msId = jdbcTemplate.queryForObject(
                "SELECT m.membership_id FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.username=? AND m.tenant_id='tenant-org-a' AND m.delete_flag=0", String.class, email).trim();
        assertThat(activeRoleCount(msId, "r-1001")).isEqualTo(1);
        // ② 移除成员 → 角色绑定一并解除（逻辑删）
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                        .delete("/api/v1/admin/members/" + msId)
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role WHERE membership_id=? AND delete_flag=0",
                Integer.class, msId)).isZero();
        // 移除动作有审计留痕（2026-11-03 补）：高危操作 + 联动动作可溯
        // 移除动作有审计留痕（service 层 ADMIN_REMOVE_MEMBER，恰好 1 条——双记防护；tenant_id 必填）
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_audit_log WHERE event_type='ADMIN_REMOVE_MEMBER' "
                        + "AND target_id=? AND result_status='SUCCESS'", Integer.class, msId)).isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT tenant_id FROM gateway_audit_log WHERE event_type='ADMIN_REMOVE_MEMBER' "
                        + "AND target_id=?", String.class, msId).trim()).isEqualTo("tenant-org-a");
        // ③ 重邀（换角色 r-1003 Viewer）→ 接受 → 只剩新角色，旧角色不残留
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"tenant_id\":\"tenant-org-a\",\"role_id\":\"r-1003\"}"))
                .andExpect(status().isOk());
        String rawToken2 = "rebind-token-2";
        jdbcTemplate.update("UPDATE gateway_invitation SET invite_token_hash=? WHERE email=? AND invitation_status='PENDING'",
                com.unify.iam.common.util.SecureToken.hash(rawToken2), email);
        // 2026-11-06 孤儿级联：② 移除后原账号已软删（旧 bearer 随 tombstone 失效）——
        // ③ 重邀 JIT 新建同邮箱账号：重置新账号密码 → 新登录 → accept
        String newUserId = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE username=? AND delete_flag=0", String.class, email).trim();
        jdbcTemplate.update("UPDATE gateway_user SET password_hash=(SELECT password_hash FROM (SELECT password_hash FROM gateway_user WHERE username='admin') t) WHERE user_id=?", newUserId);
        String newBearer = login(email, "admin123");
        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken2 + "/accept")
                        .header("Authorization", "Bearer " + newBearer))
                .andExpect(status().isOk());
        String msId2 = jdbcTemplate.queryForObject(
                "SELECT m.membership_id FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.username=? AND m.tenant_id='tenant-org-a' AND m.delete_flag=0", String.class, email).trim();
        assertThat(activeRoleCount(msId2, "r-1003")).isEqualTo(1);
        assertThat(activeRoleCount(msId2, "r-1001")).isZero();
    }

    private int activeRoleCount(String membershipId, String roleId) {
        return jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role WHERE membership_id=? AND role_id=? AND delete_flag=0",
                Integer.class, membershipId.trim(), roleId.trim());
    }

    @Test
    void expiredPendingInviteIsFlippedAndReinviteAllowed() throws Exception {
        String admin = adminToken();
        String email = "expired-inv@unify.local";
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isOk());
        // 模拟过期：过期 PENDING 行由 create() 入口主动翻转为 EXPIRED（V20 唯一索引前提），重邀放行
        jdbcTemplate.update("UPDATE gateway_invitation SET expires_at=? WHERE email=? AND invitation_status='PENDING'",
                java.time.LocalDateTime.now().minusDays(1), email);
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"tenant_id\":\"tenant-org-a\"}"))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email=? AND invitation_status='PENDING'",
                Integer.class, email)).isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email=? AND invitation_status='EXPIRED'",
                Integer.class, email)).isEqualTo(1);
    }

    @Test
    void concurrentInvitesToSameEmailYieldSinglePendingRow() throws Exception {
        String admin = adminToken();
        String email = "conc-inv@unify.local";
        String body = "{\"email\":\"" + email + "\",\"tenant_id\":\"tenant-org-a\"}";
        java.util.concurrent.CountDownLatch ready = new java.util.concurrent.CountDownLatch(2);
        java.util.concurrent.CountDownLatch fire = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.atomic.AtomicInteger ok = new java.util.concurrent.atomic.AtomicInteger();
        java.util.concurrent.atomic.AtomicInteger dup = new java.util.concurrent.atomic.AtomicInteger();
        Runnable task = () -> {
            try {
                ready.countDown();
                fire.await();
                int status = mockMvc.perform(post("/api/v1/admin/invitations")
                                .header("Authorization", "Bearer " + admin)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(body))
                        .andReturn().getResponse().getStatus();
                if (status == 200) {
                    ok.incrementAndGet();
                } else if (status == 400) {
                    dup.incrementAndGet();
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        };
        var pool = java.util.concurrent.Executors.newFixedThreadPool(2);
        var f1 = pool.submit(task);
        var f2 = pool.submit(task);
        ready.await();
        fire.countDown();
        f1.get();
        f2.get();
        pool.shutdown();
        // 一个成功一个防重 400（同一错误码 IAM-INVITE-003），库里恰一条 PENDING
        assertThat(ok.get()).isEqualTo(1);
        assertThat(dup.get()).isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_invitation WHERE email=? AND invitation_status='PENDING'",
                Integer.class, email)).isEqualTo(1);
    }

    @Test
    void multiRoleInviteBindsAllRolesAtAccept() throws Exception {
        String admin = adminToken();
        String email = "multi-role@unify.local";
        // imorph 租户建两个自定义角色，多角色邀请（iam-test 前端 role_ids 契约）
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"multirole\",\"tenant_name\":\"MultiRole\","
                                + "\"app_codes\":[\"imorph\"],\"owner_user_id\":\"u-1000\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        String roleA = createRole(admin, tenantId, "MultiA");
        String roleB = createRole(admin, tenantId, "MultiB");

        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\",\"tenant_id\":\"" + tenantId + "\","
                                + "\"role_ids\":[\"" + roleA + "\",\"" + roleB + "\"]}"))
                .andExpect(status().isOk());
        // role_ids_json 落库全量
        String json = jdbcTemplate.queryForObject(
                "SELECT role_ids_json FROM gateway_invitation WHERE email=? AND invitation_status='PENDING'",
                String.class, email).trim();
        assertThat(json).contains(roleA.trim()).contains(roleB.trim());

        // accept → 双角色绑定
        String rawToken = "multi-role-token";
        jdbcTemplate.update("UPDATE gateway_invitation SET invite_token_hash=? WHERE email=? AND invitation_status='PENDING'",
                com.unify.iam.common.util.SecureToken.hash(rawToken), email);
        jdbcTemplate.update("UPDATE gateway_user SET password_hash=(SELECT password_hash FROM (SELECT password_hash FROM gateway_user WHERE username='admin') t) WHERE username=?", email);
        String bearer = login(email, "admin123");
        mockMvc.perform(post("/api/v1/auth/invitations/" + rawToken + "/accept")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isOk());
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_user u ON m.user_id=u.user_id WHERE u.username=? AND m.tenant_id=? "
                        + "AND mr.role_id IN (?, ?) AND mr.delete_flag=0",
                Integer.class, email, tenantId, roleA.trim(), roleB.trim()))
                .isEqualTo(2);
    }

    private String createRole(String token, String tenantId, String code) throws Exception {
        return unwrapData(mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"scope_type\":\"TENANT\",\"scope_id\":\"" + tenantId + "\","
                                + "\"role_code\":\"" + code + "\",\"role_name\":\"" + code + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("role_id").toString();
    }

    @Test
    void inviteWithoutRoleUsesOwnerTemplate() throws Exception {
        // G3 默认语义：无 ACTIVE Owner 的租户 → 不传 role 补位 is_owner（Owner 模板）；
        // 已有 Owner → 回落 is_admin（Member/Admin 模板）
        String ownerless = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"g2ownless\",\"tenant_name\":\"G2 Ownerless\","
                                + "\"app_codes\":[\"imorph\"]}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"g2ownrole@unify.local\",\"tenant_id\":\"" + ownerless + "\"}"))
                .andExpect(status().isOk());
        org.mockito.ArgumentCaptor<String> html = org.mockito.ArgumentCaptor.forClass(String.class);
        org.mockito.Mockito.verify(emailTool).send(
                org.mockito.ArgumentMatchers.eq("g2ownrole@unify.local"),
                org.mockito.ArgumentMatchers.anyString(), html.capture());
        assertThat(html.getValue()).contains("as the Owner"); // 补位 Owner → Owner 模板
        String invitedRole = jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE email='g2ownrole@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1", String.class);
        assertThat(invitedRole).isEqualTo(imorphRoleId(ownerless, "iMorph-Owner"));

        // 该租户已有 Owner（JIT 即建成员）→ 第二个不传 role 的邀请回落 iMorph-Admin
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"g2adminfb@unify.local\",\"tenant_id\":\"" + ownerless + "\"}"))
                .andExpect(status().isOk());
        String fallbackRole = jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE email='g2adminfb@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1", String.class);
        assertThat(fallbackRole).isEqualTo(imorphRoleId(ownerless, "iMorph-Admin"));
    }

    private String imorphRoleId(String tenantId, String roleCode) {
        return jdbcTemplate.queryForObject(
                "SELECT role_id FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND role_code=?",
                String.class, tenantId, roleCode).trim();
    }

    @Test
    void ownerEmailCreatesTenantAndSendsOwnerInvitation() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + adminToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"g2own\",\"tenant_name\":\"G2 Own Tenant\","
                                + "\"app_codes\":[\"imorph\"],\"owner_email\":\"g2owner@unify.local\"}"))
                .andExpect(status().isOk())
                .andReturn();
        String tenantId = unwrapData(res.getResponse().getContentAsString()).get("tenant_id").toString();

        // Owner 成员已建（收紧语义：Owner 角色延期到 accept 绑定——此处角色数为 0）
        Integer memberships = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership m JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2owner@unify.local' AND m.tenant_id=? AND m.membership_status='ACTIVE'",
                Integer.class, tenantId);
        assertThat(memberships).isEqualTo(1);
        Integer roleBindings = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_user u ON m.user_id=u.user_id "
                        + "WHERE u.primary_email='g2owner@unify.local' AND m.tenant_id=? AND mr.delete_flag=0",
                Integer.class, tenantId);
        assertThat(roleBindings).isZero();

        // Owner 邀请必带 is_owner 模板角色（产品口径：邀请必传角色，Owner = is_owner=1 模板）
        String ownerRoleId = jdbcTemplate.queryForObject(
                "SELECT role_id FROM gateway_role WHERE scope_type='TENANT' AND scope_id=? AND role_code='iMorph-Owner'",
                String.class, tenantId);
        String invitedRole = jdbcTemplate.queryForObject(
                "SELECT default_role_id FROM gateway_invitation WHERE tenant_id=? AND email='g2owner@unify.local' "
                        + "ORDER BY create_time DESC LIMIT 1",
                String.class, tenantId);
        assertThat(invitedRole).isEqualTo(ownerRoleId);

        // Owner 邀请邮件：新账号含密码 + Owner 语义
        String html = capturedHtml("g2owner@unify.local");
        assertThat(html).contains("as the Owner");
        Matcher pw = PW_PATTERN.matcher(html);
        assertThat(pw.find()).isTrue();

        // 初始密码登录 → accept（幂等：已是成员，仅标记 ACCEPTED）
        String bearer = login("g2owner@unify.local", pw.group(1));
        Matcher token = TOKEN_PATTERN.matcher(html);
        assertThat(token.find()).isTrue();
        mockMvc.perform(post("/api/v1/auth/invitations/" + token.group(1) + "/accept")
                        .header("Authorization", "Bearer " + bearer))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"))
                // G2 增强：redirect_url 兜底为邀请链接基址（未配 homepage_url / yml 为空）
                .andExpect(jsonPath("$.data.redirect_url").value("http://localhost:5173"));
        assertThat(memberships).isEqualTo(1); // 成员数不重复增加
        // 收紧语义：accept 时才绑定 Owner 角色
        Integer ownerRoles = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_membership m ON mr.membership_id=m.membership_id "
                        + "JOIN gateway_user u ON m.user_id=u.user_id JOIN gateway_role r ON mr.role_id=r.role_id "
                        + "WHERE u.primary_email='g2owner@unify.local' AND m.tenant_id=? AND r.role_code='iMorph-Owner' AND mr.delete_flag=0",
                Integer.class, tenantId);
        assertThat(ownerRoles).isEqualTo(1);
    }
}

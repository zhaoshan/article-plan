package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;

import com.nimbusds.jose.jwk.RSAKey;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.security.RsaKeyManager;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class RsaKeyManagerTest {

    @TempDir
    Path tempDir;

    private IamProperties props(String keyFile) {
        IamProperties props = new IamProperties();
        props.getJwt().setPrivateKeyPath(tempDir.resolve(keyFile).toString());
        return props;
    }

    @Test
    void generatePersistReloadProduceSameKey() throws Exception {
        IamProperties props = props("k1.pem");
        RsaKeyManager first = new RsaKeyManager(props);
        first.afterPropertiesSet();
        String mod1 = first.signingKey().getModulus().toString();
        String kid1 = first.kid();

        // 重新加载（模拟重启）：公钥与 kid 必须一致（存量 token 不失效）
        RsaKeyManager second = new RsaKeyManager(props);
        second.afterPropertiesSet();

        assertThat(second.signingKey().getModulus().toString()).isEqualTo(mod1);
        assertThat(second.kid()).isEqualTo(kid1);
        assertThat(second.signingKey().getPrivateExponent()).isNotNull();
    }

    @Test
    void jwksShapeExposesPublicKeyWithFixedKid() throws Exception {
        RsaKeyManager manager = new RsaKeyManager(props("k2.pem"));
        manager.afterPropertiesSet();

        RSAKey pub = manager.signingKey().toPublicJWK();
        assertThat(pub.getKeyType().getValue()).isEqualTo("RSA");
        assertThat(pub.getKeyID()).isEqualTo("iam-key-1");
        assertThat(pub.getModulus()).isNotNull();
        assertThat(pub.getPublicExponent()).isNotNull();
        // 公开 JWK 不应包含私钥组件
        assertThat(pub.getPrivateExponent()).isNull();
    }
}

# Users email update API audit and hardening plan

Date: 2026-10-26

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, planning, session, and validation records in this repository's `.trellis/` directory.
- Do not access another Platform IAM project, create/delete a worktree, switch/reset a branch, commit, merge, or push.
- The requested `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree, including hidden-path searches. Follow the actual `CLAUDE.md` and `.claude/rules/security.md`; no undocumented Trellis confirmation gate can be inferred.

## Confirmed baseline

- `PUT /api/v1/admin/users/{userId}` already exists, is protected by a verified Bearer token plus `iam:user:write`, and accepts an optional `email` field.
- It normalizes a supplied email with trim/lowercase and writes `gateway_user.primary_email`; the schema has the `uk_gateway_user_primary_email` unique key.
- Before this task, the update request had no email format/empty/length validation, duplicate updates could escape as a generic 500 under a concurrent or pre-existing collision, and changing an email left active password-reset tokens usable because reset authorization is keyed by token/user rather than the current email.

## Intended changes

1. Preserve the existing endpoint and response shape; do not add a new endpoint or a frontend route.
2. Validate a supplied email and normalize it deterministically; reject blank, malformed, and too-long values with the normal API 400 envelope.
3. Check for an occupied email before update and translate the database unique-key race into the same client-safe 400 result.
4. Reset `email_verified` and invalidate all still-active password-reset tokens for the user when the primary email actually changes.
5. Add focused MVC/unit coverage for authorization/response shape, validation, duplicate conflict handling, normalization, and token invalidation.

## Completed validation

- `AdminUserControllerTest` verifies `iam:user:write` can call the existing `PUT` route and receives the standard success envelope; malformed, blank, and oversize email values are rejected before the service runs.
- `AdminUserServiceTest` verifies normalization, reset-token invalidation, preflight duplicate rejection, and unique-key race translation.
- `AdminUserEmailUpdateIntegrationTest` verifies the complete Spring/MySQL flow: lowercase persistence, `email_verified=0`, active reset-token invalidation, rejection of a used email, and preservation of the target's old email after rejection.
- No migration was necessary: the existing `uk_gateway_user_primary_email` index remains the database race-safe uniqueness guard.

## Out of scope

- Adding or changing the platform-iam-web Users-page editing UI.
- Changing OIDC identity snapshots (`gateway_user_identity.email_at_idp` remains IdP-provided data).
- Building an email-verification/delivery workflow, changing login identifier semantics, changing user-status lifecycle semantics, or adding migrations.

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.unify.iam.api.dto.admin.AddTemplatePermissionRequest;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.app.service.admin.TemplatePermissionAdminService;
import com.unify.iam.authorization.app.model.TemplatePermissionAddResult;
import com.unify.iam.authorization.app.model.TemplatePermissionGrant;
import com.unify.iam.authorization.app.service.ApplicationTemplateService;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RolePermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** {@link TemplatePermissionAdminService}：模板 + 存量租户同步编排。 */
@ExtendWith(MockitoExtension.class)
class TemplatePermissionAdminServiceTest {

    @Mock
    private ApplicationTemplateService applicationTemplateService;
    @Mock
    private RoleRepository roleRepository;
    @Mock
    private RolePermissionRepository rolePermissionRepository;
    @Mock
    private PermissionRepository permissionRepository;
    @Mock
    private MembershipRoleRepository membershipRoleRepository;
    @Mock
    private TokenVersionService tokenVersionService;

    private TemplatePermissionAdminService service;

    @BeforeEach
    void setUp() {
        service = new TemplatePermissionAdminService(applicationTemplateService, roleRepository,
                rolePermissionRepository, permissionRepository, membershipRoleRepository, tokenVersionService);
    }

    @Test
    void withoutSyncTouchesTemplateOnly() {
        AddTemplatePermissionRequest request =
                new AddTemplatePermissionRequest("imorph", "iMorph-Admin", "agent:deploy", "ops-zhao",
                        false, false, null, null, null, null);
        when(applicationTemplateService.addPermission(any())).thenReturn(
                new TemplatePermissionAddResult("imorph", "iMorph-Admin", "agent:deploy", true, 42, false));

        TemplatePermissionAdminService.TemplatePermissionChange change = service.add(request);

        assertThat(change.template().added()).isTrue();
        assertThat(change.syncedRoles()).isZero();
        assertThat(change.bumpedMembers()).isZero();
        verifyNoInteractions(roleRepository, rolePermissionRepository, permissionRepository,
                membershipRoleRepository, tokenVersionService);
    }

    @Test
    void passesGrantThroughWithAllFields() {
        AddTemplatePermissionRequest request =
                new AddTemplatePermissionRequest("imorph", "iMorph-Admin", "parlant-agent:deploy:read", "ops-zhao",
                        false, true, "查看部署", "Deploy", "read", "Deploy");
        when(applicationTemplateService.addPermission(any())).thenReturn(
                new TemplatePermissionAddResult("imorph", "iMorph-Admin", "parlant-agent:deploy:read", true, 43, true));

        service.add(request);

        org.mockito.ArgumentCaptor<TemplatePermissionGrant> captor =
                org.mockito.ArgumentCaptor.forClass(TemplatePermissionGrant.class);
        verify(applicationTemplateService).addPermission(captor.capture());
        TemplatePermissionGrant grant = captor.getValue();
        assertThat(grant.appCode()).isEqualTo("imorph");
        assertThat(grant.permissionCode()).isEqualTo("parlant-agent:deploy:read");
        assertThat(grant.createPermission()).isTrue();
        assertThat(grant.permissionName()).isEqualTo("查看部署");
        assertThat(grant.resourceType()).isEqualTo("Deploy");
        assertThat(grant.action()).isEqualTo("read");
        assertThat(grant.category()).isEqualTo("Deploy");
    }

    @Test
    void syncBindsMissingRolesOnlyAndBumpsTheirHolders() {
        AddTemplatePermissionRequest request =
                new AddTemplatePermissionRequest("imorph", "iMorph-Admin", "agent:deploy", "ops-zhao",
                        true, false, null, null, null, null);
        when(applicationTemplateService.addPermission(any())).thenReturn(
                new TemplatePermissionAddResult("imorph", "iMorph-Admin", "agent:deploy", true, 42, false));
        when(permissionRepository.findIdByCodes(List.of("agent:deploy"))).thenReturn(Map.of("agent:deploy", "p-1"));
        RolePO missing = role("r-1", "tenant-a");
        RolePO already = role("r-2", "tenant-b");
        when(roleRepository.listBuiltinTenantRolesByCode("iMorph-Admin")).thenReturn(List.of(missing, already));
        when(rolePermissionRepository.addIfAbsent("r-1", "p-1", "ops-zhao")).thenReturn(true);
        when(rolePermissionRepository.addIfAbsent("r-2", "p-1", "ops-zhao")).thenReturn(false);
        when(membershipRoleRepository.findMembershipIdsByRole("r-1")).thenReturn(List.of("m-1", "m-2"));

        TemplatePermissionAdminService.TemplatePermissionChange change = service.add(request);

        assertThat(change.syncedRoles()).isEqualTo(1);
        assertThat(change.bumpedMembers()).isEqualTo(2);
        verify(tokenVersionService).bumpForRoleHolders("r-1", "PERM_CHANGE");
        verify(tokenVersionService, never()).bumpForRoleHolders(eq("r-2"), eq("PERM_CHANGE"));
    }

    @Test
    void syncRunsEvenWhenTemplateAlreadyContainedPermission() {
        // added=false 不代表租户角色不缺绑（历史漏灌）——同步独立于模板是否新加
        AddTemplatePermissionRequest request =
                new AddTemplatePermissionRequest("imorph", "iMorph-Admin", "agent:deploy", "ops-zhao",
                        true, false, null, null, null, null);
        when(applicationTemplateService.addPermission(any())).thenReturn(
                new TemplatePermissionAddResult("imorph", "iMorph-Admin", "agent:deploy", false, 42, false));
        when(permissionRepository.findIdByCodes(List.of("agent:deploy"))).thenReturn(Map.of("agent:deploy", "p-1"));
        RolePO role = role("r-1", "tenant-a");
        when(roleRepository.listBuiltinTenantRolesByCode("iMorph-Admin")).thenReturn(List.of(role));
        when(rolePermissionRepository.addIfAbsent("r-1", "p-1", "ops-zhao")).thenReturn(true);
        lenient().when(membershipRoleRepository.findMembershipIdsByRole("r-1")).thenReturn(List.of());

        TemplatePermissionAdminService.TemplatePermissionChange change = service.add(request);

        assertThat(change.template().added()).isFalse();
        assertThat(change.syncedRoles()).isEqualTo(1);
        verify(tokenVersionService).bumpForRoleHolders("r-1", "PERM_CHANGE");
    }

    private RolePO role(String roleId, String tenantId) {
        // 编排只读 roleId；scopeId（租户标识）不在本路径使用
        RolePO po = mock(RolePO.class);
        when(po.getRoleId()).thenReturn(roleId);
        return po;
    }
}

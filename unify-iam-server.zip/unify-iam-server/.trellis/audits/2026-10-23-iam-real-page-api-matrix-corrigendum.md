# IAM Web 真实页面接口矩阵（勘误与替代）

**日期：** 2026-10-23  
**源码基线：** `main` / `da062d0`  
**证据范围：** 当前 `platform-iam-service` 工作区的 controller、DTO、service、repository、seed 与已交付的 IAM 设计文档；未读取其他 Platform IAM 项目，未假定未检出的前端代码。  
**变更性质：** 文档勘误。未修改业务源码、API 契约、测试、配置、分支或 worktree。

## 1. 勘误结论与范围

本文件替代以下历史审计的**活跃开发结论**，但不删除其源码调查事实：

- `2026-10-22-iam-frontend-real-api-matrix.md`
- `2026-10-23-agent-studio-tenant-settings-api-gap.md`

已确认顶层 `/admin/agents`（Agent 管理）和 `/admin/agent-studio`（Agent Studio）属于
`ai-insight-web` / Imorph，已从当前 IAM Web 移除。它们不是本 IAM Web 的页面，也不应再把
Agent 列表、定义、草稿、版本、发布、测试、运行、会话或 trace 记为本仓库必须补齐的 API。

历史审计关于“当前 IAM 没有 Agent 实体 controller、DTO、service、repository 或运行时”的静态
发现仍然正确；变化的是范围解释：这是**外部业务领域的归属事实**，不是 IAM Web 的当前接口
缺口或待开发契约。

`/admin/tenant-settings/:tenantId/agents` 是不同的 IAM Web 租户设置子视图，必须保留。其后端
归属是 IAM 的“租户已启用业务应用 + 角色/权限/成员治理”，不是 Agent 实体或 Agent 运行时。

### 当前 IAM Web 的实际范围

设计文档定义的 IAM 管理台覆盖用户、租户、成员、角色/权限、SSO/IdP 和审计
（`docs/05-IAM前端管理台与统一登录设计.md`；`docs/user-manual/05-API接口梳理.md`）。本矩阵
按下列页面能力组织：

- 租户列表、基础设置、租户已启用应用（含 `tenant-settings/:tenantId/agents`）与域名；
- 成员、邀请、加入申请、角色与权限；
- IdP 配置与组到角色映射；
- 审计；
- 当前身份、租户切换与应用可访问性，作为上述页面的上下文。

## 2. 通用调用约束

| 项目 | 已实现行为 | 前端接入结论 |
| --- | --- | --- |
| 成功/失败信封 | 除 OIDC 重定向外，所有 `/api/v1/**` JSON 成功响应为 `{success:true, code:null, message:null, data:<业务体>}`；错误保留真实 HTTP 状态并为 `{success:false, code, message, data:null}`。 | 始终读取 `data`；401 进入登录/刷新路径，403 显示无权，400 在操作附近显示 `message`。 |
| 管理面鉴权 | `/api/v1/admin/**` 要求 `Authorization: Bearer <access_token>`；控制器以 `iam:*` 权限点额外校验。 | 导航隐藏只是 UX；后端 401/403 才是权威。 |
| 租户作用域 | 具 PLATFORM 作用域角色者可跨租户；仅租户作用域角色者只能操作 `token.tenantId`。 | 不得把 URL 中任意 `tenantId` 当作授权证明；必要时先 `POST /api/v1/auth/switch-tenant`。 |
| OIDC/JWKS 例外 | `/api/v1/auth/oidc/**` 是重定向，不套信封；`/.well-known/jwks.json` 是裸 JWK Set。 | 不把这两个例外套进通用 JSON 解包器。 |

证据：`ApiEnvelopeAdvice`、`EnvelopePaths`、`GlobalExceptionHandler`、`WebMvcConfig`、
`ManagementAuthorizationInterceptor` 与 `TenantScopeGuard`。

## 3. 可直接调用的当前 IAM 页面接口

下表只列真实 IAM 页面能够直接使用的资源。字段均位于响应 `data` 内。

| 页面/能力 | 方法与路径 | 关键请求/响应字段 | 权限与边界 |
| --- | --- | --- | --- |
| 当前操作者与页面显隐 | `GET /api/v1/auth/me` | `userId`, `tenantId`, `membershipId`, `roles[]`, `permissions[]`, `attrs` | Bearer；这是当前单租户 token 上下文，不是任意目标租户授权查询。 |
| 租户选择 | `GET /api/v1/auth/memberships`；`POST /api/v1/auth/switch-tenant` | 列表项：`membership_id`, `tenant_id`, `tenant_name`, `membership_status`, `is_default`；切换体：`{membership_id}`；切换后返回新的 access/refresh token。 | Bearer；目标成员必须属于当前用户且成员、租户均为 `ACTIVE`。 |
| 应用入口可用性 | `GET /api/v1/auth/app-access?app_code={appCode}` | `memberships[]:{membership_id,tenant_id,tenant_name,tenant_code}`，`is_platform_admin` | Bearer；表示活跃成员关系与已启用应用的交集，不是 Agent 清单。 |
| 租户列表/详情 | `GET /api/v1/admin/tenants?limit={1..1000}`；`GET /api/v1/admin/tenants/{tenantId}` | `tenant_id`, `tenant_code`, `tenant_name`, `tenant_type`, `tenant_status`, `primary_domain` | `iam:tenant:read`；列表无搜索、筛选、排序、分页或总数。 |
| 建立/基础更新/删除租户 | `POST /api/v1/admin/tenants`；`PUT` / `DELETE /api/v1/admin/tenants/{tenantId}` | 创建体：`{tenant_code,tenant_name,tenant_type?,primary_domain?,owner_user_id?,app_codes:[...]}`，其中 `app_codes` 非空；更新实际只消费 `tenant_name`、`tenant_status`、`primary_domain`，返回均为 `{tenant_id}`。 | `iam:tenant:write`；更新和删除执行租户作用域校验。未知更新键不构成已支持的设置。 |
| **租户设置 / agents 子视图** | `GET /api/v1/admin/tenants/{tenantId}/applications` | `{applications:[{app_code,app_name}],count}` | `iam:role:read` + `TenantScopeGuard`。仅展示该租户已启用的业务应用。 |
| 建租户时的应用/模板选择 | `GET /api/v1/admin/applications` | `{applications:[{app_code,app_name,description,roles:[{role_code,role_name,permission_count,is_owner}]}],count}` | `iam:tenant:read`；只返回 ACTIVE 应用。它是应用模板目录，不是 Agent 资源。 |
| 成员与用户目录 | `GET /api/v1/admin/members?tenant_id={tenantId}`；`GET /api/v1/admin/user-directory?search=&limit=20`；`POST /api/v1/admin/members` | 成员项：`membership_id`, `tenant_id`, `user_id`, `username`, `membership_status`, `is_default`, `roles[]`；添加体：`{tenant_id,user_id,role_ids?}`；目录项：`user_id`, `username`, `email`。 | `iam:member:read/write`；成员 API 做租户作用域校验。目录最多 20 条且无分页。 |
| 成员角色与生命周期 | `GET/PUT /api/v1/admin/members/{membershipId}/roles`；`POST .../suspend`；`POST .../restore`；`DELETE /api/v1/admin/members/{membershipId}` | 角色项：`role_id`, `role_code`, `role_name`；PUT 体：`{role_ids:[...]}`，为替换语义；写结果 `{membership_id}`。 | `iam:member:read/write`；最后管理员/owner 防护可能返回 400。 |
| 邀请与加入申请 | `POST /api/v1/admin/invitations`；`GET /api/v1/admin/join-requests?tenant_id=&status?`；`POST .../{id}/approve` / `reject` | 邀请体：`{email,tenant_id,role_id?}`，当前返回 `{token}`；批准体可为 `{role_id?}`，拒绝体可为 `{review_note?}`。 | `iam:member:*` + 作用域；邀请没有邮件发送、列表、撤销或重发接口。 |
| 角色与权限 | `GET/POST /api/v1/admin/roles`；`GET/PUT /api/v1/admin/roles/{roleId}/permissions`；`DELETE /api/v1/admin/roles/{roleId}`；`GET /api/v1/admin/permissions` | 角色查询必须显式传 `scope_type=TENANT&scope_id={tenantId}`；角色项为 `role_id`, `role_code`, `role_name`, `scope_type`, `scope_id`, `role_status`；创建体 `{scope_type,scope_id,role_code,role_name,role_description?}`；权限写体 `{permission_ids:[...]}`，也是替换语义。 | `iam:role:*`。TENANT 角色只能绑定已启用应用的 `tenant_grantable=1` 业务权限和可租户授予的 IAM 成员/角色权限。 |
| 域名登记与验证 | `POST /api/v1/admin/tenants/{tenantId}/domains`；`POST /api/v1/admin/domains/{domainId}/verify` | 创建体是 **camelCase** `{domain,challengeType?}`，返回 `tenant_domain_id`, `challenge_type`, `challenge_token`；验证返回 `status`, `domain`。 | `iam:tenant:write`；当前验证是开发期直接标记 VERIFIED。 |
| IdP 与组映射 | `GET/POST /api/v1/admin/idp-configs?tenant_id=`；`PUT/DELETE /api/v1/admin/idp-configs/{configId}`；`GET/POST/PUT/DELETE /api/v1/admin/idp-configs/{configId}/group-mappings[/{mappingId}]` | IdP 写体使用 snake_case，例如 `tenant_id`, `provider_key`, `client_secret`（仅写）、`scopes`, `claim_mapping`, `allowed_domains`, `pkce_required`, `jit_provisioning_enabled`；映射体为 `{match_mode,match_value,target_role_id,priority,mapping_status}`。 | `iam:idp:read/write`；现有 seed 仅 PlatformAdmin 持有，读取结果仅以 `has_secret` 表示密钥存在。 |
| 审计 | `GET /api/v1/admin/audit?tenant_id=&event_type=&actor_user_id=&page=1&size=20`；`GET /api/v1/admin/audit/events` | `{audits,total,page,size}`；审计项含 `audit_log_id`, tenant/actor 富化名、`event_type`, `event_name`, target、结果、request/IP/user-agent、before/after/metadata JSON、`trace_id`, `create_time`。 | `iam:audit:read`；这是当前唯一具服务端 `page/size/total` 的管理列表，`size` 为 1..200。 |

## 4. `/admin/tenant-settings/:tenantId/agents` 的后端归属

### 4.1 IAM 能支持什么

该子视图只能表达“此租户启用了哪些业务应用，以及这些应用的 IAM 授权如何被治理”：

1. **已启用应用读取：** `GET /api/v1/admin/tenants/{tenantId}/applications` 从
   `iam_tenant_application` 关联读取应用码和名称；这是该子视图的主数据源。
2. **应用模板说明：** `GET /api/v1/admin/applications` 可在建租户流程展示 ACTIVE 应用及其
   预置角色模板。创建租户的 `app_codes` 会由 `AdminTenantService` / `TenantAppProvisionService`
   登记关联并灌入模板角色。
3. **谁可以使用已启用应用：** 成员、角色、权限目录和 IdP 组映射 API 可治理其 token 内的
   业务权限码。对 TENANT 角色，`AdminRoleService` 会拒绝未启用应用的业务权限。
4. **外部业务入口判定：** `GET /api/v1/auth/app-access?app_code=` 返回用户在该应用已启用租户
   中的活跃成员关系，可用于业务应用进入前的租户选择。

例如 `parlant-agent-server` 可作为一个 `app_code` 出现在该视图中；`agent:read`、
`agent:build`、`agent:publish`、`agent:delete` 是它的**业务权限码**。IAM 负责签发这些授权
声明，并不保有任何 Agent 记录。

### 4.2 IAM 明确不拥有的内容

以下均不是该子视图的当前 IAM 必做缺口：Agent ID、名称、定义、草稿、版本、发布状态、模型、
工具、知识库引用、测试运行、会话、trace、指标或业务运行时控制。没有 `/api/v1/admin/agents`
或 Agent Studio controller 是正确的服务边界，而非本仓库需要补出的 REST 资源。

若该子视图的产品语义后来要求展示这些业务实体，应由对应业务服务/网关提供数据；IAM 仅提供
Bearer/JWKS、当前租户、成员状态和 permissions。该情形应作为跨服务集成确认，不得反向创建
Agent 实体 API 到 IAM。

### 4.3 该子视图的真实 IAM 缺口

- 现有租户应用 API **只读**；应用只在建租户/注册初始化时写入。没有后续 `PUT/PATCH/DELETE`
  的租户应用启停/保存契约。
- 应用注册表和角色模板没有管理 CRUD 或状态管理接口；它们按现有设计由平台 SQL/脚本维护。
- 任何新增“启用/移除应用”的设计必须先定义模板角色灌入、现有成员/角色、已签发 token 和外部
  业务资源的迁移/回收规则。这是租户应用治理缺口，**不是** Agent 生命周期或运行时缺口。

## 5. 部分匹配与真实 IAM 后续项

| 区域 | 当前能用 | 不能声称已支持 | 真实 IAM 后续项 |
| --- | --- | --- | --- |
| 租户基础设置 | 读取、创建、三字段更新、删除 | owner、成员/管理员汇总、配额/用量、时区、品牌、通知、订阅/计费 | 若页面需要，提供明确 settings projection/DTO；不要继续向裸 `PUT` 发送猜测字段。 |
| 租户应用（`agents` 子视图） | 已启用应用只读、建租户时选应用、RBAC 按应用限制 | 后续启停、移除、应用模板/目录 CRUD | 设计租户应用写模型及回收语义；不新增 Agent 资源。 |
| 域名 | 创建验证挑战、开发期验证 | 列表/详情/删除、主域名切换、真实 DNS/HTTP 校验、验证状态查询 | 补资源查询/删除与生产校验；此外当前 `DomainVerificationService` 未调用 `TenantScopeGuard`，应先修复作用域一致性。 |
| 成员/邀请 | 成员 CRUD、角色替换、暂停/恢复、单次邀请、加入申请审批 | 邮件投递、邀请列表/状态/撤销/重发、批量导入、owner 转移 | 邮件 outbox 与邀请生命周期查询；显式 owner 转移事务。 |
| 角色/权限 | 角色创建/列表/删除、权限读取/替换、目录 | 角色详情/更新/启停、说明/builtin/owner/持有人数投影、服务端分页/搜索 | 增加安全的角色投影与更新契约；前端不应从 role code 推断 owner。 |
| IdP/组映射 | 列表、创建、更新、删除、组映射 CRUD、secret 脱敏 | 单项 GET、连接/发现验证、租户自助 IdP、生产级 secret 加密 | 如需产品化，增加安全验证端点；`client_secret` 当前开发期明文存储的安全待办必须在生产前完成。 |
| 审计 | 按租户/事件/操作人分页、事件目录 | 时间范围、全文/目标筛选、导出 | 在已有 audit 查询资源上追加筛选和导出契约。 |
| 非审计列表 | tenant/user-directory 有有限 `limit`；members/roles/IdP 为全量 | 统一的服务端搜索、排序、`page/size/total` | 依资源增加可选分页/查询参数，并保持旧数组字段兼容。 |

## 6. 字段与路径勘误要点

- `GET /api/v1/admin/applications` 的控制器权限是 `iam:tenant:read`，不是 `iam:role:read`。
  其用途是 ACTIVE 应用目录/建租户模板选择；租户内的已启用应用读取才是
  `GET /api/v1/admin/tenants/{tenantId}/applications` + `iam:role:read` + 作用域守卫。
- `GET /api/v1/admin/roles` 虽然 query 参数在代码中可选，但缺省值会组合为
  `TENANT` / `PLATFORM`；前端必须显式传 `scope_type` 和 `scope_id`，不能依赖缺省行为。
- 域名创建 DTO 未使用 `@JsonProperty`，因此写体是 `challengeType`，不是
  `challenge_type`；其余表内标注的请求体以 DTO 的 snake_case 注解为准。
- `GET /api/v1/admin/tenants/{tenantId}/applications` 返回的是 `{applications,count}`，不是
  分页 `items`，也不包含应用状态、角色模板或 Agent 数量。
- `GET /api/v1/admin/audit` 的过滤参数仅为 `tenant_id`、`event_type`、`actor_user_id`；
  `page` 从 1 开始，`size` 被约束在 1..200。时间和目标过滤尚未实现。

## 7. 验证与待确认

### 本次静态核对

- 对 `iam-app` 全部 controller 映射及业务源码搜索后，没有发现 `/api/v1/admin/agents`、
  Agent Studio、Agent 实体 controller/DTO/service/repository；`agent:*` 出现为业务权限码和
  `parlant-agent-server` 应用模板数据。
- 逐一核对了本文件表中租户、应用、成员、角色、域名、IdP/组映射和审计的 mapping、DTO 与
  service；字段和方法以第 3 节为准。
- 本文件发布前还应运行文档路径/方法/字段静态复核和 Git/Markdown 健康检查，结果会写入本任务
  会话记录。

### 待确认事项

1. `tenant-settings/:tenantId/agents` 的具体 UX 是否仅展示“已启用应用 + 授权治理”，还是还要
   聚合外部业务服务的 Agent 实体；后一种情况需要业务服务/网关的负责人确认数据源和鉴权协议，
   不应作为 IAM API backlog。
2. 当前仓库没有对应的前端源码可做页面字段逐列比对；本矩阵以服务端已交付的 IAM 页面设计和
   静态契约为准。
3. 本仓库与 `.trellis/` 内均未找到 `AGENTS.md` 或 `.trellis/workflow.md`。需要项目负责人确认
   这两个流程文件是否应补回当前主工作区，或说明其替代位置；在此之前无法执行其中未落盘的
   确认门禁/语言规则。

-- ============================================================
-- 平台基础引导（可重复、幂等；所有环境都执行——新环境最小平台配置）
-- 内容：iam 应用 + iam:* 权限点（含 app_code/tenant_grantable，V8 隔离）+ PlatformAdmin 角色
--       + 平台管理租户 + platform_admin 用户/成员（生产用，区别于 dev seed 的 admin）
-- ⚠️ 占位密码：platform_admin 初始密码为占位哈希（Platform@123），
--    生产部署必须用 IAM 改密 API（POST /api/v1/auth/reset-password 或管理端）设真实密码！
-- 约定：全部 INSERT IGNORE（幂等，重复应用不报错）；ID 固定可读（32 字符）。
-- ============================================================

SET NAMES utf8mb4;

-- 1. iam:* 管理权限点（11 码；tenant_grantable：member/role 租户可授=1，user/tenant/audit/idp 平台专属=0）
INSERT IGNORE INTO `gateway_permission`
  (`permission_id`, `permission_code`, `resource_type`, `app_code`, `tenant_grantable`, `action`, `permission_name`,
   `permission_description`, `category`, `is_builtin`, `permission_status`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('p-2001', 'iam:user:read',    'IAM', 'iam', 0, 'USER_READ',    '查询用户',   '用户查询', 'User', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2002', 'iam:user:write',   'IAM', 'iam', 0, 'USER_WRITE',   '管理用户',   '用户增删改', 'User', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2003', 'iam:tenant:read',  'IAM', 'iam', 0, 'TENANT_READ',  '查询租户',   '租户查询', 'Tenant', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2004', 'iam:tenant:write', 'IAM', 'iam', 0, 'TENANT_WRITE', '管理租户',   '租户创建/域名', 'Tenant', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2005', 'iam:member:read',  'IAM', 'iam', 1, 'MEMBER_READ',  '查询成员',   '成员查询', 'Member', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2006', 'iam:member:write', 'IAM', 'iam', 1, 'MEMBER_WRITE', '管理成员',   '成员增删/审批/授权', 'Member', 1, 'ACTIVE',0, 'system', 'system'),
  ('p-2007', 'iam:role:read',    'IAM', 'iam', 1, 'ROLE_READ',    '查询角色',   '角色查询', 'Role', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2008', 'iam:role:write',   'IAM', 'iam', 1, 'ROLE_WRITE',   '管理角色',   '角色增删/授权', 'Role', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2009', 'iam:audit:read',   'IAM', 'iam', 0, 'AUDIT_READ',   '查询审计',   '审计日志查询', 'Audit', 1, 'ACTIVE',0, 'system', 'system'),
  ('p-2010', 'iam:idp:read',     'IAM', 'iam', 0, 'IDP_READ',     '查询 IdP 配置','管理面 IdP/组映射配置查询', 'IdP', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2011', 'iam:idp:write',    'IAM', 'iam', 0, 'IDP_WRITE',    '管理 IdP 配置','管理面 IdP/组映射配置增删改', 'IdP', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2012', 'iam:apps:read',    'IAM', 'iam', 1, 'APPS_READ',    '查询应用',   '应用目录查询（可租户授权）', 'Apps', 1, 'ACTIVE', 0, 'system', 'system'),
  ('p-2013', 'iam:apps:write',   'IAM', 'iam', 1, 'APPS_WRITE',   '管理应用',   '应用接入管理（可租户授权）', 'Apps', 1, 'ACTIVE', 0, 'system', 'system');

-- 2. PlatformAdmin（平台级角色，scope=PLATFORM，内置）
INSERT IGNORE INTO `gateway_role`
  (`role_id`, `scope_type`, `scope_id`, `role_code`, `role_name`, `role_description`,
   `is_builtin`, `role_status`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('r-2001', 'PLATFORM', 'PLATFORM', 'PlatformAdmin', 'Platform Admin', '平台管理员（管理面全权）', 1, 'ACTIVE', 0, 'system', 'system');

-- 3. PlatformAdmin → 全部 iam:*（11 码）
INSERT IGNORE INTO `gateway_role_permission`
  (`role_permission_id`, `role_id`, `permission_id`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('rp-4001', 'r-2001', 'p-2001', 0, 'system', 'system'),
  ('rp-4002', 'r-2001', 'p-2002', 0, 'system', 'system'),
  ('rp-4003', 'r-2001', 'p-2003', 0, 'system', 'system'),
  ('rp-4004', 'r-2001', 'p-2004', 0, 'system', 'system'),
  ('rp-4005', 'r-2001', 'p-2005', 0, 'system', 'system'),
  ('rp-4006', 'r-2001', 'p-2006', 0, 'system', 'system'),
  ('rp-4007', 'r-2001', 'p-2007', 0, 'system', 'system'),
  ('rp-4008', 'r-2001', 'p-2008', 0, 'system', 'system'),
  ('rp-4009', 'r-2001', 'p-2009', 0, 'system', 'system'),
  ('rp-4010', 'r-2001', 'p-2012', 0, 'system', 'system'),
  ('rp-4011', 'r-2001', 'p-2013', 0, 'system', 'system'),
  ('rp-5010', 'r-2001', 'p-2010', 0, 'system', 'system'),
  ('rp-5011', 'r-2001', 'p-2011', 0, 'system', 'system');

-- 4. IAM 自身应用（app_code='iam'）
INSERT IGNORE INTO `iam_application`
  (`app_id`, `app_code`, `app_name`, `app_status`, `description`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('app-2002', 'iam', 'Platform IAM', 'ACTIVE', 'IAM 平台自身管理应用', 0, 'system', 'system');

-- 5. IAM 平台管理员模板（PLATFORM 作用域，is_owner）
INSERT IGNORE INTO `iam_application_role_template`
  (`template_id`, `app_code`, `scope_type`, `role_code`, `role_name`, `role_description`, `permission_codes_json`,
   `is_owner`, `is_admin`, `priority`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('tpl-2006', 'iam', 'PLATFORM', 'PlatformAdmin', 'IAM 平台管理员', '平台级：用户/租户/成员/角色/审计/IdP 全量管理',
   JSON_ARRAY('iam:user:read','iam:user:write','iam:tenant:read','iam:tenant:write',
              'iam:member:read','iam:member:write','iam:role:read','iam:role:write',
              'iam:audit:read','iam:idp:read','iam:idp:write'),
   1, 1, 5, 0, 'system', 'system');

-- 6. 平台管理租户（ORGANIZATION；启用 iam 应用）
INSERT IGNORE INTO `gateway_tenant`
  (`tenant_id`, `tenant_code`, `tenant_name`, `tenant_type`, `tenant_status`,
   `registration_source`, `owner_user_id`, `join_policy`, `sso_required`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('platform-mgmt-00000000000000000001', 'platform-management', '平台管理', 'ORGANIZATION', 'ACTIVE',
   'BOOTSTRAP', 'platform-admin-00000000000000000001', 'INVITE_ONLY', 0,
   0, 'system', 'system');

INSERT IGNORE INTO `iam_tenant_application`
  (`tenant_app_id`, `tenant_id`, `app_code`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('tpa-platform-mgmt-0000000000000000001', 'platform-mgmt-00000000000000000001', 'iam', 0, 'system', 'system');

-- 7. platform_admin 用户 + 本地身份 + 成员（平台租户，PlatformAdmin）
-- ⚠️ 占位密码哈希（Platform@123）——生产部署后必须用改密 API 设置真实密码！
INSERT IGNORE INTO `gateway_user`
  (`user_id`, `username`, `primary_email`, `password_hash`, `full_name`, `display_name`,
   `default_tenant_id`, `user_status`, `registration_source`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('platform-admin-00000000000000000001', 'platform_admin', 'platform_admin@unify.local',
   '$2y$10$f1tzpG3DB1S8bZ2dh6bX6.hmLcDtnwXF/NhG4zEc75lHz4rup6Cja', 'Platform Admin', 'Platform Admin',
   'platform-mgmt-00000000000000000001', 'ACTIVE', 'BOOTSTRAP',
   0, 'system', 'system');

INSERT IGNORE INTO `gateway_user_identity`
  (`user_identity_id`, `user_id`, `provider_type`, `provider_key`, `issuer`, `subject`,
   `login_name`, `identity_status`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('id-platform-admin-00000000000000000001', 'platform-admin-00000000000000000001', 'LOCAL', 'password', NULL, 'platform_admin', 'platform_admin', 'ACTIVE', 0, 'system', 'system');

INSERT IGNORE INTO `gateway_membership`
  (`membership_id`, `tenant_id`, `user_id`, `membership_status`, `join_source`, `is_default`,
   `delete_flag`, `create_by`, `update_by`)
VALUES
  ('ms-platform-admin-00000000000000000001', 'platform-mgmt-00000000000000000001',
   'platform-admin-00000000000000000001', 'ACTIVE', 'BOOTSTRAP', 1, 0, 'system', 'system');

INSERT IGNORE INTO `gateway_membership_role`
  (`membership_role_id`, `membership_id`, `role_id`, `grant_source`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('mr-platform-admin-00000000000000000001', 'ms-platform-admin-00000000000000000001', 'r-2001', 'DIRECT', 0, 'system', 'system');

-- 兜底：历史 permission 行补隔离列（旧结构迁移来的库 iam:* 可能缺 app_code/tenant_grantable；幂等）

-- G3：存量模板行补 is_admin 标记（幂等）
UPDATE `iam_application_role_template` SET `is_admin` = 1 WHERE `template_id` = 'tpl-2006';

-- 8. G1 配额维度（租户全局，docs/requirements/M10W4-W5 §G1；应用专属维度随应用 seed 追加）
INSERT IGNORE INTO `gateway_quota_dimension`
  (`dimension_id`, `app_code`, `dimension_key`, `dimension_name`, `unit`, `default_limit`, `source`, `sort_order`, `delete_flag`, `create_by`, `update_by`)
VALUES
  ('gd-2001', 'iam', 'members', 'Members', NULL, 10, 'IAM', 10, 0, 'system', 'system'),
  ('gd-2002', 'iam', 'apps', 'Apps', NULL, 20, 'IAM', 20, 0, 'system', 'system');

UPDATE `gateway_permission` SET `app_code` = 'iam', `tenant_grantable` = 1
 WHERE `permission_id` IN ('p-2005','p-2006','p-2007','p-2008');
UPDATE `gateway_permission` SET `app_code` = 'iam', `tenant_grantable` = 0
 WHERE `permission_id` IN ('p-2001','p-2002','p-2003','p-2004','p-2009','p-2010','p-2011');

-- 2026-10-30 存量补偿（INSERT IGNORE 不刷新已存在行，幂等）：
-- ① iam 权限点 category 回填（按类型：Member/Role/Tenant/User/Audit/IdP/Apps）
UPDATE `gateway_permission` SET `category` = CASE `permission_code`
    WHEN 'iam:member:read' THEN 'Member' WHEN 'iam:member:write' THEN 'Member'
    WHEN 'iam:role:read' THEN 'Role' WHEN 'iam:role:write' THEN 'Role'
    WHEN 'iam:tenant:read' THEN 'Tenant' WHEN 'iam:tenant:write' THEN 'Tenant'
    WHEN 'iam:user:read' THEN 'User' WHEN 'iam:user:write' THEN 'User'
    WHEN 'iam:audit:read' THEN 'Audit'
    WHEN 'iam:idp:read' THEN 'IdP' WHEN 'iam:idp:write' THEN 'IdP'
    WHEN 'iam:apps:read' THEN 'Apps' WHEN 'iam:apps:write' THEN 'Apps'
    ELSE `category` END WHERE `app_code` = 'iam';
-- ② PlatformAdmin 模板补 iam:apps:*（NOT JSON_CONTAINS 守卫，可重复执行）
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:apps:read')
    WHERE `template_id` = 'tpl-2006' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:apps:read"');
UPDATE `iam_application_role_template` SET `permission_codes_json` =
    JSON_ARRAY_APPEND(`permission_codes_json`, '$', 'iam:apps:write')
    WHERE `template_id` = 'tpl-2006' AND NOT JSON_CONTAINS(`permission_codes_json`, '"iam:apps:write"');

-- 2026-11-05 邮箱验证能力存量口径：引导/dev 账号先于该能力存在，一律视为已验证
UPDATE `gateway_user` SET `email_verified` = 1 WHERE `email_verified` = 0;

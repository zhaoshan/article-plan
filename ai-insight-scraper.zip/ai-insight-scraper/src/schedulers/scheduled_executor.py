"""定时调度执行器

APScheduler 触发后的实际执行入口：
  1. 查询调度配置并校验启用状态
  2. 获取 per-site 锁防止同一站点重叠执行
  3. 创建 crawl_schedule_logs 与 crawl_tasks 记录
  4. 调用 FullSiteCrawler 完成 tree → dynamic → LinkTreeSyncer
  5. 同步更新日志与任务状态
"""

import asyncio
import logging
import uuid
from datetime import datetime

from src.core.crawl_semaphore import CrawlSemaphoreGuard
from src.core.full_site_crawler import FullSiteCrawler
from src.database import (
    ScheduleRepository,
    ScheduleLogRepository,
    TaskRepository,
    CrawlScheduleLogModel,
)
from src.models.crawl_task import CrawlTask

logger = logging.getLogger(__name__)

# 站点级执行锁：防止同一站点的多次调度实例并发执行
_site_locks: dict[str, asyncio.Lock] = {}


def _get_site_lock(site: str) -> asyncio.Lock:
    """获取指定站点的执行锁"""
    if site not in _site_locks:
        _site_locks[site] = asyncio.Lock()
    return _site_locks[site]


async def execute_scheduled_crawl(
    schedule_id: str,
    trigger_type: str = "cron",
) -> None:
    """执行一次定时调度爬取。

    Args:
        schedule_id: 调度配置 UUID
        trigger_type: 触发方式，cron 或 manual
    """
    schedule_repo = ScheduleRepository()
    log_repo = ScheduleLogRepository()
    task_repo = TaskRepository()

    schedule = await schedule_repo.find_by_id(schedule_id)
    if schedule is None:
        logger.warning(f"调度配置不存在: schedule_id={schedule_id}")
        return

    if not schedule.enabled:
        logger.info(f"调度已禁用，跳过执行: schedule_id={schedule_id}")
        return

    site = schedule.site
    target_url = schedule.target_url
    lock = _get_site_lock(site)

    if lock.locked():
        logger.warning(f"站点 {site} 已有调度执行中，跳过本次触发: schedule_id={schedule_id}")
        log = CrawlScheduleLogModel(
            log_id=str(uuid.uuid4()),
            schedule_id=schedule_id,
            task_id=None,
            site=site,
            target_url=target_url,
            status="skipped",
            trigger_type=trigger_type,
            error_message="同一站点已有执行实例，本次触发被跳过",
        )
        await log_repo.create(log)
        return

    async with lock:
        log = CrawlScheduleLogModel(
            log_id=str(uuid.uuid4()),
            schedule_id=schedule_id,
            task_id=None,
            site=site,
            target_url=target_url,
            status="pending",
            trigger_type=trigger_type,
        )
        log = await log_repo.create(log)

        task = CrawlTask(
            task_type="scheduled_full_site",
            site=site,
            target_url=target_url,
            max_depth=schedule.max_depth,
            headless=bool(schedule.headless),
            output_type=schedule.output_type,
            schedule_id=schedule_id,
        )
        await task_repo.create(task)
        await task_repo.mark_running(task.task_id)
        await log_repo.update_status(
            log.log_id,
            "running",
            task_id=task.task_id,
            started_at=datetime.now(),
        )

        try:
            async with CrawlSemaphoreGuard(task.task_id):
                crawler = FullSiteCrawler(
                    headless=bool(schedule.headless),
                    max_depth=schedule.max_depth,
                    output_type=schedule.output_type,
                )
                result = await crawler.run(target_url, master_task=task)

            links_path = result.get("links_path")
            tree_path = result.get("tree_path")
            stats = result.get("stats", {})
            pages_crawled = stats.get("total_pages", 0)
            links_found = stats.get("total_links", 0)

            await task_repo.mark_completed(
                task_id=task.task_id,
                links_path=links_path,
                tree_path=tree_path,
                pages_crawled=pages_crawled,
                links_found=links_found,
            )
            await log_repo.mark_completed(
                log_id=log.log_id,
                task_id=task.task_id,
                links_path=links_path,
                tree_path=tree_path,
                pages_crawled=pages_crawled,
                links_found=links_found,
            )
            logger.info(
                f"定时调度执行完成: schedule_id={schedule_id}, task_id={task.task_id}, "
                f"site={site}, pages={pages_crawled}, links={links_found}"
            )

        except Exception as e:
            error_message = str(e)
            logger.exception(f"定时调度执行失败: schedule_id={schedule_id}, task_id={task.task_id}")
            await task_repo.mark_failed(task.task_id, error_message)
            await log_repo.mark_failed(
                log_id=log.log_id,
                error_message=error_message,
                task_id=task.task_id,
            )

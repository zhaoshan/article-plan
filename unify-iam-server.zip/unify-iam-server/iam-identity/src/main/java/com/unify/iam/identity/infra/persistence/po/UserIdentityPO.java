package com.unify.iam.identity.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_user_identity 用户身份绑定表 PO（本地密码 / OIDC / SAML）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_user_identity")
public class UserIdentityPO extends BaseEntity {

    /** 身份绑定业务唯一标识 */
    private String userIdentityId;
    /** 所属用户 ID */
    private String userId;
    /** 身份协议类型：LOCAL/OIDC/SAML */
    private String providerType;
    /** 身份提供方标识：password/google/microsoft/... */
    private String providerKey;
    /** OIDC/SAML issuer / entityId；本地密码登录可为空 */
    private String issuer;
    /** 外部身份主键（OIDC sub / SAML NameID / 本地登录名） */
    private String subject;
    /** 外部 IdP 组织标识 */
    private String externalTenantKey;
    /** 外部登录名 */
    private String loginName;
    /** IdP 侧邮箱 */
    private String emailAtIdp;
    /** IdP 侧邮箱是否已验证 */
    private Integer emailVerified;
    private String fullNameAtIdp;
    private String phoneAtIdp;
    /** 身份绑定状态：ACTIVE/DISABLED/REVOKED */
    private String identityStatus;
    /** 原始/裁剪后 claims 快照（审计/排障；E2E-2 JIT 落 SSO claims） */
    private String claimsJson;
    /** 最近一次登录时间 */
    private LocalDateTime lastLoginAt;
}

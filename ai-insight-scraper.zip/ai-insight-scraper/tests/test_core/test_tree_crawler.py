"""TreeCrawler 单元测试 — 外站过滤逻辑、导航重试与失败率阈值"""

import pytest
from unittest.mock import AsyncMock, Mock

from src.core.tree_crawler import (
    TreeCrawler,
    PageNavigationError,
    PartialFailureThresholdError,
)
from src.models.traversal_config import DomainTraversalConfig
from src.utils.url_utils import normalize_url


class TestShouldCollectOuterSite:
    """_should_collect_outer_site 外站过滤逻辑测试"""

    def test_need_outer_site_false_skips_all(self):
        """need_outer_site=False 时不收集任何外域"""
        config = DomainTraversalConfig(need_outer_site=False, outer_site_whitelist=[])
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._should_collect_outer_site(
            normalize_url("https://other.com/page")
        ) is False

    def test_need_outer_site_true_empty_whitelist_collects_all(self):
        """need_outer_site=True + whitelist=[] → 收集所有外域"""
        config = DomainTraversalConfig(need_outer_site=True, outer_site_whitelist=[])
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._should_collect_outer_site(
            normalize_url("https://other.com/page")
        ) is True
        assert crawler._should_collect_outer_site(
            normalize_url("https://another.org/x")
        ) is True

    def test_whitelist_matches_exact_domain(self):
        """白名单精确匹配域名"""
        config = DomainTraversalConfig(
            need_outer_site=True, outer_site_whitelist=["partner.com"]
        )
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._should_collect_outer_site(
            normalize_url("https://partner.com/page")
        ) is True

    def test_whitelist_matches_subdomain(self):
        """白名单匹配子域名"""
        config = DomainTraversalConfig(
            need_outer_site=True, outer_site_whitelist=["partner.com"]
        )
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._should_collect_outer_site(
            normalize_url("https://sub.partner.com/page")
        ) is True

    def test_whitelist_rejects_non_matching(self):
        """白名单拒绝不匹配的域名"""
        config = DomainTraversalConfig(
            need_outer_site=True, outer_site_whitelist=["partner.com"]
        )
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._should_collect_outer_site(
            normalize_url("https://other.com/page")
        ) is False

    def test_whitelist_multiple_entries(self):
        """白名单包含多个条目"""
        config = DomainTraversalConfig(
            need_outer_site=True,
            outer_site_whitelist=["partner.com", "jpx.co.jp"],
        )
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._should_collect_outer_site(
            normalize_url("https://partner.com/a")
        ) is True
        assert crawler._should_collect_outer_site(
            normalize_url("https://www.jpx.co.jp/b")
        ) is True
        assert crawler._should_collect_outer_site(
            normalize_url("https://unrelated.com/c")
        ) is False


class TestMaxDepthOverride:
    """crawl() 的 max_depth 覆盖逻辑测试"""

    def test_max_depth_overrides_config(self):
        """传入的 max_depth 覆盖配置文件值"""
        config = DomainTraversalConfig(drill_down_levels=5)
        crawler = TreeCrawler(traversal_config=config)
        # 不实际爬取，只验证构造和参数传递正确
        assert crawler._traversal_config.drill_down_levels == 5

    def test_max_depth_none_uses_config(self):
        """max_depth=None 时使用配置文件值"""
        config = DomainTraversalConfig(drill_down_levels=3)
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._traversal_config.drill_down_levels == 3

    def test_max_depth_zero_means_unlimited(self):
        """max_depth=0 表示不限"""
        config = DomainTraversalConfig(drill_down_levels=0)
        crawler = TreeCrawler(traversal_config=config)
        assert crawler._traversal_config.drill_down_levels == 0


class TestDomainTraversalConfigDefaults:
    """DomainTraversalConfig 新增字段默认值校验"""

    def test_default_resilience_values(self):
        """所有新增字段均使用预期默认值"""
        config = DomainTraversalConfig()
        assert config.page_navigation_timeout_ms == 60000
        assert config.page_load_state_timeout_ms == 30000
        assert config.page_load_wait_ms == 2000
        assert config.page_retry_count == 2
        assert config.page_retry_delay_ms == 1000
        assert config.max_partial_failure_rate == 0.5
        assert config.min_pages_for_failure_check == 10
        assert config.min_tree_pages_threshold == 50
        assert config.min_tree_success_rate == 0.8


class TestNavigatePageWithRetry:
    """_navigate_page_with_retry 重试逻辑测试"""

    @pytest.mark.asyncio
    async def test_retry_succeeds_after_two_failures(self):
        """goto 失败两次后成功，验证重试次数与关闭行为"""
        config = DomainTraversalConfig(page_retry_count=2)
        crawler = TreeCrawler(traversal_config=config)

        pages: list[AsyncMock] = []
        for i in range(3):
            page = AsyncMock()
            page.goto = AsyncMock(side_effect=TimeoutError("timeout") if i < 2 else None)
            page.wait_for_load_state = AsyncMock(return_value=None)
            page.wait_for_timeout = AsyncMock(return_value=None)
            page.is_closed = AsyncMock(return_value=False)
            pages.append(page)

        context = AsyncMock()
        context.new_page = AsyncMock(side_effect=pages)

        result = await crawler._navigate_page_with_retry(
            context, "https://example.com", config
        )

        assert result is pages[2]
        assert context.new_page.await_count == 3
        assert pages[0].close.await_count == 1
        assert pages[1].close.await_count == 1
        assert pages[2].close.await_count == 0

    @pytest.mark.asyncio
    async def test_retry_exhausted_closes_all_pages(self):
        """goto 始终失败，验证 page.close() 被调用"""
        config = DomainTraversalConfig(page_retry_count=2)
        crawler = TreeCrawler(traversal_config=config)

        pages: list[AsyncMock] = []
        for _ in range(3):
            page = AsyncMock()
            page.goto = AsyncMock(side_effect=TimeoutError("timeout"))
            page.wait_for_load_state = AsyncMock(return_value=None)
            page.wait_for_timeout = AsyncMock(return_value=None)
            page.is_closed = AsyncMock(return_value=False)
            pages.append(page)

        context = AsyncMock()
        context.new_page = AsyncMock(side_effect=pages)

        with pytest.raises(PageNavigationError):
            await crawler._navigate_page_with_retry(
                context, "https://example.com", config
            )

        for page in pages:
            assert page.close.await_count == 1


class TestCrawlSinglePageFailureHandling:
    """_crawl_single_page 失败处理测试"""

    @pytest.mark.asyncio
    async def test_failure_increments_failed_and_closes_page(self, monkeypatch):
        """页面提取失败时增加失败计数并关闭 Page"""
        config = DomainTraversalConfig()
        crawler = TreeCrawler(traversal_config=config)
        crawler._target_domain = "example.com"

        fake_page = AsyncMock()
        fake_page.is_closed = Mock(return_value=False)

        async def fake_navigate(*args, **kwargs):
            return fake_page

        monkeypatch.setattr(TreeCrawler, "_navigate_page_with_retry", fake_navigate)

        async def fake_extract_links(*args, **kwargs):
            raise TimeoutError("extract failed")

        monkeypatch.setattr(
            "src.core.tree_crawler.extract_links_from_page", fake_extract_links
        )

        fake_context = AsyncMock()
        result = await crawler._crawl_single_page(
            fake_context, "https://example.com/child", depth=1, max_depth=0
        )

        assert result == []
        assert crawler._failed_pages == 1
        fake_page.close.assert_awaited_once()


class TestPartialFailureThreshold:
    """实时失败率阈值测试"""

    @pytest.mark.asyncio
    async def test_crawl_tree_raises_when_failure_rate_exceeds_threshold(self, monkeypatch):
        """模拟大量子页面失败，验证 _crawl_tree 抛出 PartialFailureThresholdError"""
        config = DomainTraversalConfig(
            min_pages_for_failure_check=5,
            max_partial_failure_rate=0.5,
        )
        crawler = TreeCrawler(traversal_config=config)
        crawler._target_domain = "example.com"

        call_count = 0

        async def fake_crawl_single_page(self, context, url, depth, max_depth):
            nonlocal call_count
            self._failed_pages += 1
            call_count += 1
            if call_count == 1:
                return [f"https://example.com/child{i}" for i in range(1, 6)]
            return []

        monkeypatch.setattr(TreeCrawler, "_crawl_single_page", fake_crawl_single_page)

        fake_context = AsyncMock()
        with pytest.raises(PartialFailureThresholdError):
            await crawler._crawl_tree(
                fake_context, "https://example.com", max_depth=0
            )

        assert crawler._aborted_due_to_failure_rate is True

    @pytest.mark.asyncio
    async def test_crawl_tree_all_success_no_threshold_error(self, monkeypatch):
        """全成功场景不触发阈值异常"""
        config = DomainTraversalConfig(
            min_pages_for_failure_check=5,
            max_partial_failure_rate=0.5,
        )
        crawler = TreeCrawler(traversal_config=config)
        crawler._target_domain = "example.com"

        async def fake_crawl_single_page(self, context, url, depth, max_depth):
            return []

        monkeypatch.setattr(TreeCrawler, "_crawl_single_page", fake_crawl_single_page)

        fake_context = AsyncMock()
        await crawler._crawl_tree(
            fake_context, "https://example.com", max_depth=0
        )

        assert crawler._attempted_pages == 1
        assert crawler._failed_pages == 0
        assert crawler._aborted_due_to_failure_rate is False
        assert crawler._compute_failure_rate() == 0.0

package com.unify.iam.app.security;

import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jose.util.Base64URL;
import com.unify.iam.app.config.IamProperties;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateCrtKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.EnumSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * RSA-2048 密钥管理：首启生成并持久化到配置路径（PKCS#8 PEM），重启不换钥。
 *
 * <p>持久化的意义：重启后 kid/公钥不变 → 已签发 token 持续有效、parlant PyJWKClient
 * 缓存不失效。kid 轮换留未来阶段（换 kid 即断旧 token）。
 */
@Component
public class RsaKeyManager implements InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(RsaKeyManager.class);
    private static final int KEY_SIZE = 2048;

    private final IamProperties props;
    private RSAKey signingKey;

    public RsaKeyManager(IamProperties props) {
        this.props = props;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.signingKey = loadOrCreate(Path.of(props.getJwt().getPrivateKeyPath()), props.getJwt().getKid());
    }

    /** 签发用 RSAKey（含私钥 + kid）。 */
    public RSAKey signingKey() {
        return signingKey;
    }

    /** kid。 */
    public String kid() {
        return props.getJwt().getKid();
    }

    private RSAKey loadOrCreate(Path path, String kid) throws Exception {
        if (Files.exists(path)) {
            log.info("加载已有 JWT 私钥：{}", path);
            return parsePem(path, kid);
        }
        RSAKey key = new RSAKeyGenerator(KEY_SIZE).keyID(kid).generate();
        persistPem(path, key);
        log.info("生成并持久化 JWT 私钥：{}", path);
        return key;
    }

    private void persistPem(Path path, RSAKey key) throws Exception {
        Path abs = path.toAbsolutePath();
        if (abs.getParent() != null) {
            Files.createDirectories(abs.getParent());
        }
        byte[] der = key.toPrivateKey().getEncoded(); // PKCS#8
        String pem = "-----BEGIN PRIVATE KEY-----\n"
                + Base64.getMimeEncoder(64, "\n".getBytes()).encodeToString(der)
                + "\n-----END PRIVATE KEY-----\n";
        Files.writeString(path, pem);
        try {
            Files.setPosixFilePermissions(path, EnumSet.of(
                    PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
        } catch (UnsupportedOperationException e) {
            // 非 POSIX 文件系统（如 Windows）忽略
            log.debug("当前文件系统不支持 POSIX 权限，跳过 0600 设置");
        }
    }

    private RSAKey parsePem(Path path, String kid) throws Exception {
        String pem = Files.readString(path);
        String base64 = pem.replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replaceAll("\\s", "");
        byte[] der = Base64.getDecoder().decode(base64);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        RSAPrivateCrtKey rsaPriv = (RSAPrivateCrtKey) kf.generatePrivate(new PKCS8EncodedKeySpec(der));
        // nimbus 10.x：Builder(Base64URL n, Base64URL e) + privateKey(RSAPrivateCrtKey) 重建完整 RSAKey
        return new RSAKey.Builder(Base64URL.encode(rsaPriv.getModulus()), Base64URL.encode(rsaPriv.getPublicExponent()))
                .privateKey(rsaPriv)
                .keyID(kid)
                .build();
    }
}

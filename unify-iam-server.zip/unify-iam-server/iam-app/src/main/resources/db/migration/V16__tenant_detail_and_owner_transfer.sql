-- Tenant detail drawer support: authoritative IAM usage/quota storage and purpose-aware owner invitations.
-- Existing migrations are immutable; this file is additive only.

ALTER TABLE `gateway_invitation`
  ADD COLUMN `invitation_purpose` VARCHAR(32) NOT NULL DEFAULT 'MEMBER'
    COMMENT '邀请用途：MEMBER/OWNER_TRANSFER' AFTER `invite_type`,
  ADD COLUMN `delivery_status` VARCHAR(32) NOT NULL DEFAULT 'NOT_REQUESTED'
    COMMENT '投递状态：NOT_REQUESTED/DELIVERED；不表示邀请已接受' AFTER `invitation_status`,
  ADD KEY `idx_invitation_tenant_purpose_status`
    (`tenant_id`, `invitation_purpose`, `invitation_status`, `expires_at`);

-- Extend the existing current-branch quota schema without recreating its tables.
ALTER TABLE gateway_quota_dimension
  ADD COLUMN dimension_status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
  ADD KEY idx_quota_dimension_source_status (source, dimension_status),
  MODIFY COLUMN default_limit BIGINT DEFAULT NULL;
ALTER TABLE gateway_tenant_quota MODIFY COLUMN limit_value BIGINT DEFAULT NULL;

package com.unify.iam.identity.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.identity.infra.persistence.po.IdpGroupMappingPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_idp_group_mapping Mapper。 */
@Mapper
public interface IdpGroupMappingMapper extends BaseMapper<IdpGroupMappingPO> {
}
package com.unify.iam.app.app.service;

import com.unify.iam.app.infra.persistence.po.EmailVerificationPO;
import com.unify.iam.app.infra.persistence.repository.EmailVerificationRepository;
import com.unify.iam.app.mail.RegistrationVerificationMailService;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.SecureToken;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 注册邮箱验证码（2026-11-05，docs/08 §16）：发码（10 分钟有效）/ 校码 / 注册事务内消费。
 *
 * <p>安全设计：
 * <ul>
 *   <li>明文验证码绝不落库（只存 SHA-256 hash）；6 位数字，SecureRandom 生成；</li>
 *   <li>防轰炸：60s 重发冷却 + 每邮箱每用途 24h 上限 10 次；</li>
 *   <li>防爆破：单码校验次数 ≥5 即作废（REVOKED）；</li>
 *   <li>防枚举：发码端点对任意合法邮箱统一受理（注册本就开放，邮箱存在性不是秘密）；</li>
 *   <li>消费语义：注册事务内 {@link #consumeForRegister} 校验并翻转 VERIFIED——
 *       同一验证码不可注册两个账号。</li>
 * </ul>
 */
@Service
public class EmailVerificationService {

    /** 校验入口与用途（预留 RESET 等扩展）。 */
    public static final String PURPOSE_REGISTER = "REGISTER";
    static final long TTL_MINUTES = 10;
    static final long RESEND_COOLDOWN_SECONDS = 60;
    static final int MAX_ATTEMPTS = 5;
    static final long DAILY_LIMIT = 10;

    private static final SecureRandom RANDOM = new SecureRandom();

    private final EmailVerificationRepository repository;
    private final RegistrationVerificationMailService mailService;

    public EmailVerificationService(EmailVerificationRepository repository,
                                    RegistrationVerificationMailService mailService) {
        this.repository = repository;
        this.mailService = mailService;
    }

    /** 发码：冷却/上限校验 → 旧 PENDING 作废 → 新码落库并投递邮件（日志兜底模式输出码值）。 */
    @Transactional
    public void send(String email) {
        String normalized = normalize(email);
        repository.findLatestByEmailPurpose(normalized, PURPOSE_REGISTER).ifPresent(latest -> {
            if ("PENDING".equals(latest.getVerificationStatus())
                    && latest.getCreateTime() != null
                    && latest.getCreateTime().plusSeconds(RESEND_COOLDOWN_SECONDS).isAfter(LocalDateTime.now())) {
                throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_RATE_LIMITED);
            }
        });
        if (repository.countRecentByEmailPurpose(normalized, PURPOSE_REGISTER,
                LocalDateTime.now().minusHours(24)) >= DAILY_LIMIT) {
            throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_RATE_LIMITED);
        }
        repository.findLatestByEmailPurpose(normalized, PURPOSE_REGISTER)
                .filter(po -> "PENDING".equals(po.getVerificationStatus()))
                .ifPresent(po -> repository.updateStatus(po.getVerificationId(), "REVOKED", null));

        String code = String.format("%06d", RANDOM.nextInt(1_000_000));
        EmailVerificationPO po = new EmailVerificationPO();
        po.setVerificationId(IdGenerator.newBizId());
        po.setEmail(normalized);
        po.setPurpose(PURPOSE_REGISTER);
        po.setCodeHash(SecureToken.hash(code));
        po.setVerificationStatus("PENDING");
        po.setAttempts(0);
        po.setExpiresAt(LocalDateTime.now().plusMinutes(TTL_MINUTES));
        repository.insert(po);
        mailService.sendCode(normalized, code, po.getExpiresAt());
    }

    /**
     * 校码（独立校验端点）：错码 → 400 VERIFICATION_CODE_WRONG（次数+1，≥5 作废）；
     * 过期 → 翻转 EXPIRED → 400 VERIFICATION_CODE_EXPIRED；通过 → 翻转 VERIFIED（待注册消费）。
     */
    // 无事务：抛错时 attempts++/REVOKED 必须落库（防爆破依赖跨请求的持久计数）
    public void verify(String email, String code) {
        EmailVerificationPO latest = requireLatest(normalize(email));
        if (isExpired(latest)) {
            repository.updateStatus(latest.getVerificationId(), "EXPIRED", null);
            throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_EXPIRED);
        }
        if (!latest.getCodeHash().equals(SecureToken.hash(code.trim()))) {
            repository.bumpAttempts(latest.getVerificationId());
            if ((latest.getAttempts() == null ? 0 : latest.getAttempts()) + 1 >= MAX_ATTEMPTS) {
                repository.updateStatus(latest.getVerificationId(), "REVOKED", null);
            }
            throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_WRONG);
        }
        repository.updateStatus(latest.getVerificationId(), "VERIFIED", LocalDateTime.now());
    }

    /** 注册事务内消费：PENDING/VERIFIED 且未过期、码匹配 → 翻转 VERIFIED（消费，防一码多号）。 */
    @Transactional
    public void consumeForRegister(String email, String code) {
        String normalized = normalize(email);
        if (code == null || code.isBlank()) {
            throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_REQUIRED);
        }
        EmailVerificationPO latest = repository
                .findLatestByEmailPurpose(normalized, PURPOSE_REGISTER)
                .orElseThrow(() -> AuthException.badRequest(ErrorCode.VERIFICATION_CODE_WRONG));
        if (isExpired(latest)) {
            repository.updateStatus(latest.getVerificationId(), "EXPIRED", null);
            throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_EXPIRED);
        }
        boolean usable = "PENDING".equals(latest.getVerificationStatus())
                || "VERIFIED".equals(latest.getVerificationStatus());
        if (!usable || !latest.getCodeHash().equals(SecureToken.hash(code.trim()))) {
            throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_WRONG);
        }
        repository.updateStatus(latest.getVerificationId(), "VERIFIED", LocalDateTime.now());
    }

    private EmailVerificationPO requireLatest(String email) {
        return repository.findLatestByEmailPurpose(email, PURPOSE_REGISTER)
                .orElseThrow(() -> AuthException.badRequest(ErrorCode.VERIFICATION_CODE_WRONG));
    }

    private boolean isExpired(EmailVerificationPO po) {
        return po.getExpiresAt() == null || !po.getExpiresAt().isAfter(LocalDateTime.now());
    }

    private String normalize(String email) {
        if (email == null || email.isBlank() || !email.contains("@")) {
            throw AuthException.badRequest(ErrorCode.EMAIL_REQUIRED);
        }
        return email.trim().toLowerCase();
    }
}

package com.unify.iam.identity.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.identity.infra.persistence.po.IdpConfigPO;
import org.apache.ibatis.annotations.Mapper;

/** gateway_tenant_idp_config Mapper。 */
@Mapper
public interface IdpConfigMapper extends BaseMapper<IdpConfigPO> {
}
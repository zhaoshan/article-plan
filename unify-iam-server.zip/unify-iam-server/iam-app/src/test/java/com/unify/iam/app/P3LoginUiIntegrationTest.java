package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * P3 登录 UI 后端集成测试：注册（个人租户）/ 找回重置 / 邀请接受 / 域名验证。
 */
class P3LoginUiIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    @Test
    void registerCreatesPersonalTenantAndExposesSelfIdentityProfileAfterLogin() throws Exception {
        issueVerificationCode("newuser@unify.local");
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", "newuser", "email", "newuser@unify.local", "password", b64("New123456!"),
                                "verification_code", "123456"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.user_id").isNotEmpty());

        String token = login("newuser", "New123456!");
        MvcResult me = mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userName").value("newuser"))
                .andExpect(jsonPath("$.data.email").value("newuser@unify.local"))
                .andExpect(jsonPath("$.data.registrationSource").value("SELF_SERVICE"))
                .andReturn();
        Map<String, Object> identity = JsonUtils.fromJson(dataJson(me.getResponse().getContentAsString()), Map.class);
        String tenantId = identity.get("tenantId").toString();
        // 注册自动建 PERSONAL 租户
        String type = jdbcTemplate.queryForObject(
                "SELECT tenant_type FROM gateway_tenant WHERE tenant_id=?", String.class, tenantId);
        assertThat(type).isEqualTo("PERSONAL");
        // 2026-11-02 修复断言：不带 app_codes 的 hub 直接注册，个人租户也灌入平台默认应用（imorph）
        // + owner 授 is_owner 模板角色（与 a31162a JIT 分支同口径；否则 aud 无 imorph → 登录目录 DENIED）
        assertThat(jdbcTemplate.queryForList(
                "SELECT app_code FROM iam_tenant_application WHERE tenant_id=?", String.class, tenantId))
                .containsExactly("imorph");
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_membership_role mr JOIN gateway_role r ON r.role_id=mr.role_id"
                        + " JOIN gateway_membership m ON m.membership_id=mr.membership_id"
                        + " WHERE m.tenant_id=? AND r.role_code='iMorph-Owner'", Integer.class, tenantId))
                .isEqualTo(1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT last_login_time FROM gateway_user WHERE username=?", java.time.LocalDateTime.class, "newuser"))
                .isNotNull();
    }

    @Test
    void forgotAndResetPasswordFlow() throws Exception {
        // ① 注册一个独立用户（避免污染共享库里 seed 账号的密码）
        issueVerificationCode("pwduser@unify.local");
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", "pwduser", "email", "pwduser@unify.local", "password", b64("Old123456!"),
                                "verification_code", "123456"))))
                .andExpect(status().isOk());

        // ② forgot（pwduser@unify.local）→ dev 返回 token
        String forgotBody = mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("email", "pwduser@unify.local"))))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        String token = unwrapData(forgotBody).get("token").toString();
        assertThat(token).isNotBlank();

        // ③ 重置密码
        mockMvc.perform(post("/api/v1/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("token", token, "new_password", b64("NewOp12345!")))))
                .andExpect(status().isOk());

        // ④ 旧密码失效、新密码可用
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"pwduser\",\"password\":\"" + b64("Old123456!") + "\"}"))
                .andExpect(status().isUnauthorized());
        assertThat(login("pwduser", "NewOp12345!")).isNotBlank();
    }

    @Test
    void invitationAcceptAddsMembership() throws Exception {
        // ① 注册一个新人
        issueVerificationCode("invitee@unify.local");
        mockMvc.perform(post("/api/v1/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "username", "invitee", "email", "invitee@unify.local", "password", b64("Inv123456!"),
                                "verification_code", "123456"))))
                .andExpect(status().isOk());
        String inviteeToken = login("invitee", "Inv123456!");

        // ② 管理员发邀请（tenant-org-a）
        String admin = login("admin", "admin123");
        String inviteBody = mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of(
                                "email", "invitee@unify.local", "tenant_id", "tenant-org-a"))))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        // 日志模式（基类默认）：邀请落库 + 响应直接返回 token（与生产严格模式同形态，docs/08 §7）
        String inviteToken = (String) unwrapData(inviteBody).get("token");
        assertThat(inviteToken).isNotBlank();

        // ③ 受邀人接受 → 成为 tenant-org-a 成员
        mockMvc.perform(post("/api/v1/auth/invitations/" + inviteToken + "/accept")
                        .header("Authorization", "Bearer " + inviteToken))
                .andExpect(status().isUnauthorized()); // 无 Bearer → 401（先带正确 Bearer 再接受）
        mockMvc.perform(post("/api/v1/auth/invitations/" + inviteToken + "/accept")
                        .header("Authorization", "Bearer " + inviteeToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("ACCEPTED"));

        // ④ memberships 含 tenant-org-a（个人租户 + 企业租户）
        String memberships = mockMvc.perform(get("/api/v1/auth/memberships")
                        .header("Authorization", "Bearer " + inviteeToken))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertThat(memberships).contains("tenant-org-a");
    }

    @Test
    void domainCreateAndVerify() throws Exception {
        String admin = login("admin", "admin123");
        String body = mockMvc.perform(post("/api/v1/admin/tenants/tenant-org-a/domains")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("domain", "sub.org-a.com"))))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        String domainId = unwrapData(body).get("tenant_domain_id").toString();
        assertThat(String.valueOf(unwrapData(body).get("challenge_token"))).isNotBlank();

        mockMvc.perform(post("/api/v1/admin/domains/" + domainId + "/verify")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("VERIFIED"));

        Integer verified = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_tenant_domain WHERE tenant_domain_id=? AND verification_status='VERIFIED'",
                Integer.class, domainId);
        assertThat(verified).isEqualTo(1);
    }
}

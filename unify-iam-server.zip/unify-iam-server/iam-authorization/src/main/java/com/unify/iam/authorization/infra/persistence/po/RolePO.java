package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** gateway_role 角色表 PO。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_role")
public class RolePO extends BaseEntity {

    /** 角色业务唯一标识 */
    private String roleId;
    /** 作用域类型：PLATFORM/TENANT */
    private String scopeType;
    /** 作用域标识：TENANT 时为 tenant_id，PLATFORM 为 PLATFORM */
    private String scopeId;
    /** 角色编码 */
    private String roleCode;
    /** 角色名称 */
    private String roleName;
    private String roleDescription;
    /** 是否内置角色 */
    private Integer isBuiltin;
    /** 角色状态：ACTIVE/DISABLED */
    private String roleStatus;
}

package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.app.infra.persistence.po.PasswordResetTokenPO;
import com.unify.iam.app.infra.persistence.repository.PasswordResetTokenRepository;
import com.unify.iam.app.infra.persistence.repository.RefreshTokenRepository;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.app.mail.InvitationMailService;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.SecureToken;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserIdentityRepository;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 密码找回（docs/04 §3.5）：forgot 生成一次性重置令牌（同邮箱仅最新有效）；reset 改密 + 撤销旧 refresh。
 *
 * <p>P0-08（2026-11-09）：forgot 不再无条件返回 token——仅 SMTP 未配置（日志模式，dev 便利）
 * 时响应带 token；生产配置 SMTP 后只返回 {@code {"status":"SENT"}}，token 只经邮件交付。
 * 已知/未知邮箱统一 {@code SENT} 形态（原 detail 形态差异构成邮箱枚举辅助，已消除），
 * 并按邮箱 60s 冷却限流。
 */
@Service
public class PasswordResetService {

    private static final int TTL_MINUTES = 15;

    /** forgot 同邮箱冷却（P0-08 限流）。 */
    private static final long FORGOT_COOLDOWN_SECONDS = 60;

    private final UserRepository userRepository;
    private final PasswordResetTokenRepository tokenRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final UserIdentityRepository userIdentityRepository;
    private final InvitationMailService invitationMailService;
    private final IamProperties props;
    /** 邮件投递判别（P0-08）：未配置 SMTP（日志模式）时 forgot 响应才带 token。 */
    private final com.unify.iam.app.mail.EmailTool emailTool;
    private final AuditService auditService;

    public PasswordResetService(UserRepository userRepository,
                                PasswordResetTokenRepository tokenRepository,
                                RefreshTokenRepository refreshTokenRepository,
                                UserIdentityRepository userIdentityRepository,
                                InvitationMailService invitationMailService,
                                IamProperties props,
                                com.unify.iam.app.mail.EmailTool emailTool,
                                AuditService auditService) {
        this.auditService = auditService;
        this.userRepository = userRepository;
        this.tokenRepository = tokenRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.userIdentityRepository = userIdentityRepository;
        this.invitationMailService = invitationMailService;
        this.props = props;
        this.emailTool = emailTool;
    }

    /**
     * 发起找回（P0-08）：邮箱存在则生成 token 并（LOCAL 身份时）发邮件；
     * 已知/未知邮箱统一返回 {@code {"status":"SENT"}}——token 仅在 SMTP 未配置（日志模式）时
     * 附加在响应里供 dev 闭环；生产配置 SMTP 后 token 只经邮件交付。
     * 同一邮箱 60s 冷却（VERIFICATION_CODE_RATE_LIMITED），原 detail 形态差异已消除。
     */
    @Transactional
    public Map<String, String> forgot(String email) {
        String em = email.trim().toLowerCase();
        if (tokenRepository.countSince(em, LocalDateTime.now().minusSeconds(FORGOT_COOLDOWN_SECONDS)) > 0) {
            throw AuthException.badRequest(ErrorCode.VERIFICATION_CODE_RATE_LIMITED);
        }
        Optional<UserPO> user = userRepository.findByPrimaryEmail(em);
        if (user.isEmpty()) {
            return Map.of("status", "SENT"); // 防枚举：与已知邮箱同形态
        }
        tokenRepository.invalidateByEmail(em); // 旧 token 全部失效
        String plain = SecureToken.random();
        PasswordResetTokenPO po = new PasswordResetTokenPO();
        po.setPasswordResetTokenId(IdGenerator.newBizId());
        po.setUserId(user.get().getUserId());
        po.setEmail(em);
        po.setTokenHash(SecureToken.hash(plain));
        po.setExpiresAt(LocalDateTime.now().plusMinutes(TTL_MINUTES));
        po.setIsLatest(1);
        tokenRepository.insert(po);
        // docs/08 §2.1②：发送重置邮件（模板 templates/reset-password-email.html，链接指前端 /reset-password?token=）；
        // SSO-only 账号（无 LOCAL 身份）不发——无密码可重置，统一防枚举文案不暴露账号类型
        boolean hasLocal = userIdentityRepository.findLocalActive(user.get().getUserId().trim()).isPresent();
        if (hasLocal) {
            String base = props.getMail().getInvitationLinkBaseUrl().replaceAll("/+$", "");
            invitationMailService.sendPasswordReset(em, base + "/reset-password?token=" + plain);
        }
        if (!emailTool.isMailConfigured()) {
            // 日志模式（SMTP 未配置，dev）：响应带 token 供本地闭环；生产配置 SMTP 后不走这里
            return Map.of("status", "SENT", "token", plain);
        }
        return Map.of("status", "SENT"); // 生产：token 只经邮件交付，响应不暴露
    }

    /** 重置密码：校验令牌 → 改密 → 标记使用 → 撤销该用户所有 refresh。 */
    @Transactional
    public void reset(String token, String newPassword) {
        // P1-03 统一密码策略（解码后、哈希前）
        com.unify.iam.common.util.PasswordPolicy.validate(newPassword);
        PasswordResetTokenPO po = tokenRepository.findByHashLatestActive(SecureToken.hash(token))
                .orElseThrow(() -> AuthException.unauthorized(ErrorCode.RESET_LINK_INVALID));
        UserPO user = userRepository.findByUserId(po.getUserId())
                .orElseThrow(() -> AuthException.unauthorized(ErrorCode.USER_NOT_FOUND));
        user.setPasswordHash(BCryptUtils.hash(newPassword));
        userRepository.update(user);
        tokenRepository.markUsed(po.getId());
        refreshTokenRepository.revokeByUser(po.getUserId()); // 改密后旧会话失效
        // P1-15：忘记密码重置此前零审计——补 USER_RESET_PASSWORD（metadata 只记事实标记）
        auditService.write("USER_RESET_PASSWORD", po.getUserId(), "USER", po.getUserId(), "SUCCESS",
                java.util.Map.of("sessions_revoked", true));
    }
}

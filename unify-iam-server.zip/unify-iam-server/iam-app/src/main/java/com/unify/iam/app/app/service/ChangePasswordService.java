package com.unify.iam.app.app.service;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.infra.persistence.repository.RefreshTokenRepository;
import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 登录态自助改密（G2 首登强制改密，docs/08 §2）：校验旧密码（或初始密码）→ 更新 BCrypt →
 * 清零 {@code must_change_password}。
 *
 * <p>P1-15（2026-11-11）会话吊销对齐「忘记密码重置/管理员重置」：改密后撤销该用户全部
 * refresh token + 全部成员 bump token_version（旧 access 按方案 c 立即 stale）——密码泄露
 * 场景下改密即可踢出攻击者。响应携带重签的新会话（前端可选消费：替换 store 则本人无感；
 * 不消费则下次刷新被踢回登录页，与另外两条重置链路同一语义，账号单人使用时可接受）。
 * 审计事件 {@code USER_CHANGE_PASSWORD}（metadata 记事实标记，绝不记密码/哈希/token）。
 */
@Service
public class ChangePasswordService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final TokenVersionService tokenVersionService;
    private final TokenService tokenService;
    private final MembershipResolver membershipResolver;
    private final AuditService auditService;

    public ChangePasswordService(UserRepository userRepository,
                                 RefreshTokenRepository refreshTokenRepository,
                                 TokenVersionService tokenVersionService,
                                 TokenService tokenService,
                                 MembershipResolver membershipResolver,
                                 AuditService auditService) {
        this.userRepository = userRepository;
        this.refreshTokenRepository = refreshTokenRepository;
        this.tokenVersionService = tokenVersionService;
        this.tokenService = tokenService;
        this.membershipResolver = membershipResolver;
        this.auditService = auditService;
    }

    /**
     * @param membershipId 当前会话成员关系（用于重签新会话；用 claims 里的，不用默认解析——
     *                     改密后角色已按当前 membership 重新计算）
     * @return 新会话（access + refresh），响应可携带
     */
    @Transactional
    public LoginResponse change(String userId, String membershipId, String oldPassword, String newPassword) {
        // P1-03 统一密码策略（解码后、哈希前）
        com.unify.iam.common.util.PasswordPolicy.validate(newPassword);
        UserPO user = userRepository.findByUserId(userId)
                .orElseThrow(() -> AuthException.unauthorized(ErrorCode.USER_NOT_FOUND));
        if (user.getPasswordHash() == null || !BCryptUtils.matches(oldPassword, user.getPasswordHash())) {
            throw AuthException.unauthorized(ErrorCode.OLD_PASSWORD_INCORRECT);
        }
        user.setPasswordHash(BCryptUtils.hash(newPassword));
        user.setMustChangePassword(0);
        userRepository.update(user);
        // P1-15：撤全部旧 refresh + 全部成员版本 bump（旧 access 立即 stale）
        refreshTokenRepository.revokeByUser(userId);
        tokenVersionService.bumpForUser(userId, "PASSWORD_CHANGE");
        MembershipPO membership = membershipResolver.findById(membershipId.trim())
                .orElseThrow(() -> AuthException.unauthorized(ErrorCode.MEMBERSHIP_NOT_FOUND));
        LoginResponse session = tokenService.issueWithRefresh(
                new UserPrincipal(user.getUserId(), user.getUsername(), null), membership);
        auditService.write("USER_CHANGE_PASSWORD", userId, "USER", userId, "SUCCESS", Map.of(
                "sessions_revoked", true,
                "new_token_issued", true));
        return session;
    }
}

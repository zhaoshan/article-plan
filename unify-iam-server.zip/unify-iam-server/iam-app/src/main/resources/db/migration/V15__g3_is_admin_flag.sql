-- G3 更换 Owner：管理员角色通用定义——与 is_owner 对称的 is_admin 标记（Owner 转出后的降级目标；每应用至多一个）
ALTER TABLE `iam_application_role_template`
  ADD COLUMN `is_admin` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '管理员角色（G3：Owner 转出后的降级目标；每应用至多一个）' AFTER `is_owner`;

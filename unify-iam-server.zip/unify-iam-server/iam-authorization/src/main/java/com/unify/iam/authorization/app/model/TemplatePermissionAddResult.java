package com.unify.iam.authorization.app.model;

/**
 * 应用角色模板新增权限点结果：added=false 表示模板已含该权限点（幂等，未发生写入）；
 * permissionCreated=true 表示本次在 gateway_permission 字典新登记了该权限点。
 *
 * @param permissionCount 写入后模板权限点总数
 */
public record TemplatePermissionAddResult(
        String appCode,
        String roleCode,
        String permissionCode,
        boolean added,
        int permissionCount,
        boolean permissionCreated) {
}

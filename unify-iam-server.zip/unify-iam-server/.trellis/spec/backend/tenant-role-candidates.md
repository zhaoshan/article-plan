# Tenant member role catalog and permission-tree contract

## 1. Scope / trigger
Role management, Invite members and Edit role use the same target-tenant administrative role list. Catalog visibility is distinct from assignment authority. The former combined global/tenant catalog was removed on 2026-11-06.

## 2. Signatures
- Canonical tenant API: `GET /api/v1/admin/roles?scope_type=TENANT&scope_id=<tenant_id>`.
- Platform aggregate: `GET /api/v1/admin/roles?scope_type=PLATFORM&scope_id=PLATFORM`.
- `AdminRoleController.list` -> `AdminRoleService.listByScope` -> `TenantScopeGuard` -> `RoleRepository.listForAdmin`.
- Permission directory: `GET /api/v1/admin/permissions` -> `PermissionRepository.listActive`.
- Permission write: `PUT /api/v1/admin/roles/{role_id}/permissions` -> `AdminRoleService.setPermissions` -> tenant grantability validation.
- Removed: `GET /api/v1/admin/tenant/roles?tenant_id=<tenant_id>`; no handler or dedicated union repository query remains.

## 3. Contracts
- Both GET APIs require `iam:role:read`. Do not carry over the removed endpoint's `iam:member:read` gate: member-read-only callers receive 403 from the canonical role API.
- Send the exact uppercase tenant scope and explicit target tenant ID. A non-platform caller can target only its authenticated token tenant. Platform authority is checked against actual membership role bindings, not a JWT role name. Authorization precedes role data queries.
- TENANT lists contain only non-deleted rows with `(scope_type=TENANT, scope_id=target)`, including builtin, Owner and DISABLED roles. No PLATFORM union or Owner-code exclusion applies. PLATFORM management intentionally aggregates every non-deleted role across scopes. Both are unpaginated, `id ASC`; runtime `listByScope` remains ACTIVE-only.
- Response uses the existing API envelope with `data: {roles, count}` and no catalog `tenant_id` field. Role fields include `role_id`, `role_code`, `role_name`, optional `role_description`, `scope_type`, `scope_id`, optional `tenant_name`, `role_status`, boolean `is_builtin`/`is_owner`, and numeric `permissionCounts`.
- Existing `filter_scope_type`, `filter_scope_id` and `keyword` only narrow an authorized management query; see database-guidelines.md.
- Permission directory returns all non-deleted ACTIVE points for shared platform/tenant use. Fields are strings: `permission_id`, `permission_code`, `permission_name`, `resource_type`, `app_code`, `tenant_grantable` (`"1"` or `"0"`), `category`. There is no server-side tenant-grantable query parameter. Tenant role trees select flag `"1"` and IAM or target-enabled applications.
- Tenant permission writes independently require `tenant_grantable=1` AND (`app_code=iam` OR target tenant enabled that app). Client tree filtering is not the enforcement boundary.
- iMorph-Admin template (`tpl-3002`) and existing non-deleted TENANT `iMorph-Admin` roles receive `iam:role:write`, enabling creation and the existing role write operations within their authenticated tenant. Member remains without role-write. Repeatable seed repair must be idempotent and revive a tombstoned binding instead of silently ignoring it. Added permissions become visible in freshly issued/refreshed tokens; seed deployment alone does not rewrite existing JWTs.
- Member Source continues using persisted `gateway_membership.join_source`; do not derive it from roles or user identity. Member assignment policy is unchanged by this read API consolidation.

## 4. Validation and error matrix
| Condition | Result |
| --- | --- |
| Missing/invalid Bearer on canonical GET | 401 |
| Missing iam:role:read (even with member-read) | 403 |
| Foreign tenant without actual platform authority | 403 before role query |
| Forged PlatformAdmin JWT role without actual PLATFORM binding | 403 for PLATFORM / foreign tenant query |
| Authorized tenant has no roles / unknown tenant | 200, roles=[], count=0 |
| Removed endpoint | No registered handler; authenticated request returns 404 |
| Tenant permission write includes unknown ID | 400, PERMISSION_NOT_FOUND |
| Tenant permission write includes platform-only / unenabled-app permission | 400, PERMISSION_NOT_GRANTABLE |

## 5. Good / base / bad cases
Good: a tenant admin queries its authenticated tenant and receives every non-deleted tenant role while the permission tree selects string flag `"1"`. Base: a platform admin selects a target tenant through the same TENANT query. Bad: combine PLATFORM custom roles into tenant options, filter out Owner/builtin rows at the API, assume member-read grants role-read, or treat the directory's platform permissions as tenant-grantable.

## 6. Tests required
- `AdminRoleListIntegrationTest`: canonical tenant collection including disabled/builtin/Owner, exclusion of foreign/PLATFORM/deleted rows, unchanged platform aggregation, cross-tenant and forged JWT denial, role-read permission gate.
- Endpoint-removal integration regression: no registered handler plus authenticated 404; an unauthorized error alone does not prove deletion.
- Permission catalog regression: string `"1"` for tenant-grantable IAM points, string `"0"` for platform-only points, permission-read gate, retained shared directory semantics.
- `P3AdminCrudIntegrationTest.tenantRoleCannotGrantPlatformOnlyPermissions`: writes reject platform points while accepting target-enabled business and grantable IAM points.
- Actual iMorph-Admin provisioning/login tests: template grants role-write, own-tenant creation succeeds, foreign-tenant and PLATFORM creation fail, Member creation fails, and existing-role seed repair is idempotent.
- Member source regressions continue to preserve persisted `join_source`.

## 7. Wrong vs correct
Wrong: keep a parallel union query for member dialogs or remove PLATFORM points from the shared permission catalog to fix a tenant UI. Correct: use the authorized TENANT role API for all tenant role lists; retain the shared permission metadata and enforce tenant grants independently on writes.

The old endpoint required `iam:member:read` and excluded tenant Owner codes; the canonical list deliberately changes both behaviors. Coordinate frontend/backend rollout. Do not add assignment privileges just because a role is visible: existing invitation/member-write eligibility is a separate contract.

# -*- coding: utf-8 -*-
"""
HTML 转 Markdown 工具类

提供将 BeautifulSoup HTML 元素转换为 Markdown 格式的通用方法，
支持表格、列表、链接、图片等结构的正确转换。

用法：
    from app.utils.html_converter import HtmlConverter

    soup = BeautifulSoup(html_text, "html.parser")
    detail_div = soup.find("div", class_="content")
    markdown = HtmlConverter.html_to_markdown(detail_div, base_url="https://example.com")
"""

import re
from typing import Optional
from urllib.parse import urljoin

from bs4 import Tag
from markdownify import markdownify as md


class HtmlConverter:
    """
    HTML 转 Markdown 工具类

    将 BeautifulSoup 元素转换为结构化的 Markdown 文本，
    正确保留表格、列表、链接、图片等 HTML 元素。

    关键设计：
    - 不使用 markdownify 的 convert 参数限制标签范围，
      让其自动处理所有标签，确保表格（table/thead/tbody/tr/th/td）
      能被完整转换为 Markdown 表格格式
    - 通过 base_url 参数补全图片和链接的相对路径
    - 可选移除 <style> 标签（政府类站点常含 TRS_Editor 样式块）
    """

    @staticmethod
    def html_string_to_markdown(
        html_string: str,
        base_url: Optional[str] = None,
        remove_style_tags: bool = True,
    ) -> str:
        """
        将原始 HTML 字符串转换为 Markdown 格式（便捷方法）

        内部将字符串解析为 BeautifulSoup 后调用 html_to_markdown()，
        自动处理图片/链接 URL 补全、图片回退等逻辑。

        Args:
            html_string: 原始 HTML 字符串（如 Playwright element.inner_html() 的输出）
            base_url: 基准 URL，用于补全相对路径
            remove_style_tags: 是否移除 <style> 标签

        Returns:
            Markdown 格式的文本；输入为空时返回空字符串
        """
        if not html_string or not html_string.strip():
            return ""

        from bs4 import BeautifulSoup

        soup = BeautifulSoup(html_string, "html.parser")
        return HtmlConverter.html_to_markdown(
            soup, base_url=base_url, remove_style_tags=remove_style_tags
        )

    @staticmethod
    def html_to_markdown(
        detail_div: Optional[Tag],
        base_url: Optional[str] = None,
        remove_style_tags: bool = True,
    ) -> str:
        """
        将 HTML 内容转换为 Markdown 格式

        保留的 HTML 结构：
        - 表格 -> Markdown 表格（| col1 | col2 |）
        - 图片 -> ![alt](src)
        - 链接 -> [text](href)
        - 标题 -> # / ## / ### 等 ATX 风格
        - 列表 -> - / 1. 格式
        - 加粗/斜体 -> **bold** / *italic*
        - 引用 -> > blockquote

        Args:
            detail_div: BeautifulSoup 元素（通常为 div 正文区域）
            base_url: 基准 URL，用于将图片和链接的相对路径补全为绝对路径。
                      为 None 时不做补全。
            remove_style_tags: 是否移除 <style> 标签。
                               政府类站点文章常含 TRS_Editor 等样式块，
                               移除后可避免样式文本混入 Markdown 内容。
                               默认 True。

        Returns:
            Markdown 格式的文本；输入为 None 时返回空字符串
        """
        if not detail_div:
            return ""

        # 预处理：移除 <style> 标签
        if remove_style_tags:
            for style_tag in detail_div.find_all("style"):
                style_tag.decompose()

        # 预处理：为图片补充完整 URL
        if base_url:
            for img in detail_div.find_all("img"):
                src = img.get("src", "")
                if src and not src.startswith("http") and not src.startswith("data:"):
                    img["src"] = urljoin(base_url, src)

        # 预处理：为链接补充完整 URL
        if base_url:
            for a in detail_div.find_all("a", href=True):
                href = a["href"]
                if href and not href.startswith("http") and not href.startswith("#") and not href.startswith("mailto:"):
                    a["href"] = urljoin(base_url, href)

        # 使用 markdownify 转换（不限制 convert 参数，让所有标签自动处理）
        markdown = md(
            str(detail_div),
            heading_style="ATX",
        )

        # 后处理：当 markdownify 输出无实质内容时（如纯图片表格），
        # 从原始 HTML 中提取图片地址，构造 Markdown 图片格式
        stripped = re.sub(r"[|\- \t\n\r]", "", markdown)
        if len(stripped) < 10:
            img_urls = []
            for img in detail_div.find_all("img"):
                src = img.get("src", "")
                if src:
                    img_urls.append(src)
            if img_urls:
                markdown = "\n".join(
                    f"![图片]({img_url})" for img_url in img_urls
                )
            else:
                markdown = ""

        # 后处理：清理多余空行（3个以上换行 -> 2个）
        markdown = re.sub(r"\n{3,}", "\n\n", markdown).strip()

        # 后处理：去除行尾空白
        lines = [line.rstrip() for line in markdown.split("\n")]
        markdown = "\n".join(lines)

        return markdown

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.authorization.infra.persistence.mapper.RolePermissionMapper;
import com.unify.iam.authorization.infra.persistence.repository.RolePermissionRepository;
import com.unify.iam.common.util.JsonUtils;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;

class AdminRolePermissionCountsIntegrationTest extends IamIntegrationTestBase {

    @Autowired
    private RolePermissionRepository rolePermissionRepository;

    @MockitoSpyBean
    private RolePermissionMapper rolePermissionMapper;

    @Test
    void countsMatchCurrentBindingsAfterRevokeAndRegrant() throws Exception {
        String body = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"admin\",\"password\":\"" + b64("admin123") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String token = JsonUtils.fromJson(dataJson(body), LoginResponse.class).accessToken();
        String assigned = createRole(token, "CountAssigned");
        String empty = createRole(token, "CountEmpty");

        setPermissions(token, assigned, List.of("p-1001", "p-1002", "p-1001"));
        // 多角色列表只调用一次聚合查询；不为每个角色单独查询权限。
        org.mockito.Mockito.clearInvocations(rolePermissionMapper);
        assertCounts(token, assigned, empty, 2);
        org.mockito.Mockito.verify(rolePermissionMapper, org.mockito.Mockito.times(1))
                .selectMaps(org.mockito.ArgumentMatchers.any(com.baomidou.mybatisplus.core.conditions.Wrapper.class));

        setPermissions(token, assigned, List.of("p-1002"));
        assertCounts(token, assigned, empty, 1);
        assertThat(jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_role_permission WHERE role_id = ? AND delete_flag = 1",
                Integer.class, assigned)).isEqualTo(1);

        setPermissions(token, assigned, List.of("p-1001", "p-1002"));
        assertCounts(token, assigned, empty, 2);
        setPermissions(token, assigned, List.of());
        assertCounts(token, assigned, empty, 0);

        org.mockito.Mockito.clearInvocations(rolePermissionMapper);
        assertThat(rolePermissionRepository.countByRoleIds(List.of())).isEmpty();
        org.mockito.Mockito.verifyNoInteractions(rolePermissionMapper);
        mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "TENANT").param("scope_id", "count-no-roles")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(0))
                .andExpect(jsonPath("$.data.roles").isEmpty());
        org.mockito.Mockito.verifyNoInteractions(rolePermissionMapper);
    }

    private String createRole(String token, String code) throws Exception {
        String body = mockMvc.perform(post("/api/v1/admin/roles")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("scope_type", "PLATFORM", "scope_id", "PLATFORM",
                                "role_code", code, "role_name", code))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return unwrapData(body).get("role_id").toString();
    }

    private void setPermissions(String token, String roleId, List<String> ids) throws Exception {
        mockMvc.perform(put("/api/v1/admin/roles/" + roleId + "/permissions")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("permission_ids", ids))))
                .andExpect(status().isOk());
    }

    @SuppressWarnings("unchecked")
    private void assertCounts(String token, String assigned, String empty, int expected) throws Exception {
        String body = mockMvc.perform(get("/api/v1/admin/roles")
                        .param("scope_type", "PLATFORM").param("scope_id", "PLATFORM")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        List<Map<String, Object>> roles = (List<Map<String, Object>>) unwrapData(body).get("roles");
        Map<String, Object> assignedRole = roles.stream()
                .filter(role -> assigned.equals(role.get("role_id"))).findFirst().orElseThrow();
        assertThat(assignedRole.get("permissionCounts")).isInstanceOf(Number.class);
        assertThat(((Number) assignedRole.get("permissionCounts")).intValue()).isEqualTo(expected);
        Map<String, Object> emptyRole = roles.stream()
                .filter(role -> empty.equals(role.get("role_id"))).findFirst().orElseThrow();
        assertThat(emptyRole.get("permissionCounts")).isEqualTo(0);
    }
}

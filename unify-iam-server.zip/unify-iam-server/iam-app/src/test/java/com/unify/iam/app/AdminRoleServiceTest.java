package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.unify.iam.api.dto.admin.UpdateRoleRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.app.service.admin.AdminRoleService;
import com.unify.iam.app.infra.persistence.po.AuditLogPO;
import com.unify.iam.app.infra.persistence.repository.AuditLogRepository;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RolePermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AdminRoleServiceTest {

    @Mock
    private RoleRepository roleRepository;
    @Mock
    private RolePermissionRepository rolePermissionRepository;
    @Mock
    private PermissionRepository permissionRepository;
    @Mock
    private TenantApplicationRepository tenantApplicationRepository;
    @Mock
    private TenantScopeGuard tenantScopeGuard;
    @Mock
    private TokenVersionService tokenVersionService;
    @Mock
    private AuditService auditService;
    @Mock
    private AuditLogRepository auditLogRepository;

    @Mock
    private com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository membershipRoleRepository;

    private AdminRoleService service;

    @BeforeEach
    void setUp() {
        service = new AdminRoleService(roleRepository, rolePermissionRepository, permissionRepository,
                tenantApplicationRepository, tenantScopeGuard, tokenVersionService, auditService, membershipRoleRepository);
    }

    @Test
    void updateChangesOnlyDisplayMetadataAuditsAndDoesNotBumpTokens() {
        RolePO role = tenantRole();
        JwtClaims claims = claims();
        when(roleRepository.findById("r-1")).thenReturn(Optional.of(role));
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));

        service.update(claims, "r-1", new UpdateRoleRequest(" Support operator ", "Handles tickets", null));

        assertThat(role.getRoleCode()).isEqualTo("SupportOperator");
        assertThat(role.getRoleName()).isEqualTo("Support operator");
        assertThat(role.getRoleDescription()).isEqualTo("Handles tickets");
        verify(tenantScopeGuard).assertTenantScope(claims, "tenant-org-a");
        verify(roleRepository).updateBasicInfo("r-1", "Support operator", "Handles tickets");
        verifyNoInteractions(tokenVersionService);

        ArgumentCaptor<AuditLogPO> audit = ArgumentCaptor.forClass(AuditLogPO.class);
        verify(auditLogRepository).insert(audit.capture());
        assertThat(audit.getValue().getEventType()).isEqualTo("ADMIN_UPDATE_ROLE");
        assertThat(audit.getValue().getTenantId()).isEqualTo("tenant-org-a");
        assertThat(audit.getValue().getTargetId()).isEqualTo("r-1");
        assertThat(audit.getValue().getBeforeJson()).contains("Support");
        assertThat(audit.getValue().getAfterJson()).contains("Support operator");
    }

    @Test
    void updateRejectsRoleCodeBeforeLoadingOrWritingRole() {
        assertThatThrownBy(() -> service.update(claims(), "r-1",
                new UpdateRoleRequest("Support operator", null, "Renamed")))
                .isInstanceOf(AuthException.class)
                .hasMessage("role_code cannot be updated");

        verifyNoInteractions(roleRepository, tenantScopeGuard, tokenVersionService, auditService, membershipRoleRepository);
    }

    @Test
    void updateRejectsInvalidMetadataDefensively() {
        assertThatThrownBy(() -> service.update(claims(), "r-1",
                new UpdateRoleRequest("   ", null, null)))
                .isInstanceOf(AuthException.class)
                .hasMessage("role_name is required");
        assertThatThrownBy(() -> service.update(claims(), "r-1",
                new UpdateRoleRequest("n", "x".repeat(513), null)))
                .isInstanceOf(AuthException.class)
                .hasMessage("role_description must not exceed 512 characters");

        verify(roleRepository, never()).update(any());
        verifyNoInteractions(tenantScopeGuard, tokenVersionService, auditService, membershipRoleRepository);
    }

    @Test
    void updateUsesPlatformGuardForPlatformRole() {
        RolePO role = tenantRole();
        JwtClaims claims = claims();
        role.setScopeType("PLATFORM");
        role.setScopeId("PLATFORM");
        when(roleRepository.findById("r-1")).thenReturn(Optional.of(role));
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));

        service.update(claims, "r-1", new UpdateRoleRequest("Platform operator", null, null));

        verify(tenantScopeGuard).assertPlatformAdmin(claims);
        verify(roleRepository).updateBasicInfo("r-1", "Platform operator", null);
    }

    @Test
    void missingNullAndBlankCodesAreGeneratedPersistedAndAudited() {
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));
        for (String code : java.util.Arrays.asList(null, "", "   ")) {
            service.create(claims(), new com.unify.iam.api.dto.admin.CreateRoleRequest(
                    "TENANT", "tenant-org-a", code, " Support ", null));
        }
        ArgumentCaptor<RolePO> saved = ArgumentCaptor.forClass(RolePO.class);
        verify(roleRepository, org.mockito.Mockito.times(3)).create(saved.capture());
        ArgumentCaptor<AuditLogPO> audits = ArgumentCaptor.forClass(AuditLogPO.class);
        verify(auditLogRepository, org.mockito.Mockito.times(3)).insert(audits.capture());
        assertThat(saved.getAllValues()).extracting(RolePO::getRoleCode).doesNotHaveDuplicates();
        for (int i = 0; i < 3; i++) {
            RolePO role = saved.getAllValues().get(i);
            assertThat(role.getRoleCode()).matches("role_[a-f0-9]{32}");
            assertThat(role.getRoleName()).isEqualTo("Support");
            assertThat(audits.getAllValues().get(i).getMetadataJson()).contains(role.getRoleCode());
            assertThat(audits.getAllValues().get(i).getTenantId()).isEqualTo("tenant-org-a");
        }
    }

    @Test
    void explicitCodeRemainsSupportedAndTrimmed() {
        when(auditService.audit()).thenReturn(new AuditService.AuditEntry(auditLogRepository));
        service.create(claims(), new com.unify.iam.api.dto.admin.CreateRoleRequest(
                "TENANT", "tenant-org-a", " Support ", "Support", null));
        verify(roleRepository).create(org.mockito.ArgumentMatchers.argThat(r -> "Support".equals(r.getRoleCode())));
    }

    @Test
    void listFiltersAreNormalizedWithoutChangingAuthorizationScope() {
        JwtClaims c = claims();
        service.listByScope(c, "TENANT", "tenant-org-a", " TENANT,PLATFORM,TENANT ", " foreign ", " needle ");
        org.mockito.InOrder order = org.mockito.Mockito.inOrder(tenantScopeGuard, roleRepository);
        order.verify(tenantScopeGuard).assertTenantScope(c, "tenant-org-a");
        order.verify(roleRepository).listForAdmin("TENANT", "tenant-org-a", List.of("TENANT", "PLATFORM"), "foreign", "needle");
    }

    @Test
    void listRejectsMalformedTypeFiltersAndDoesNotQueryRoles() {
        for (String raw : List.of("", " ", "tenant", "UNKNOWN", "TENANT,", ",PLATFORM")) {
            assertThatThrownBy(() -> service.listByScope(claims(), "PLATFORM", "PLATFORM", raw, null, null))
                    .isInstanceOf(AuthException.class);
        }
        verifyNoInteractions(roleRepository);
    }

    @Test
    void scopeDenialPrecedesAnyFilteredRoleQuery() {
        JwtClaims c = claims();
        org.mockito.Mockito.doThrow(AuthException.forbidden("denied"))
                .when(tenantScopeGuard).assertPlatformAdmin(c);
        assertThatThrownBy(() -> service.listByScope(c, "PLATFORM", "PLATFORM", "TENANT", "foreign", "needle"))
                .isInstanceOf(AuthException.class);
        verifyNoInteractions(roleRepository);
    }

    private JwtClaims claims() {
        long now = Instant.now().getEpochSecond();
        return new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"), "u-1",
                "tenant-org-a", "ms-1", List.of("TenantAdmin"), List.of("iam:role:write"), Map.of(),
                now + 3600, now, "jti", 0L);
    }

    private RolePO tenantRole() {
        RolePO role = new RolePO();
        role.setRoleId("r-1");
        role.setRoleCode("SupportOperator");
        role.setRoleName("Support");
        role.setRoleDescription("Initial description");
        role.setScopeType("TENANT");
        role.setScopeId("tenant-org-a");
        role.setRoleStatus("ACTIVE");
        return role;
    }
}

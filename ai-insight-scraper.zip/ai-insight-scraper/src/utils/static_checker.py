import sys
from pathlib import Path

from bs4 import BeautifulSoup


def estimate_static_probability(html: str) -> float:
    """
    基于HTML内容估算页面为静态页面的概率 (0-100)
    分数越高，越可能是静态页面
    """
    if not html or len(html) < 50:
        return 0.0

    soup = BeautifulSoup(html, 'html.parser')
    # 提取所有脚本标签内的纯文本内容
    scripts = soup.find_all('script')
    script_content = ''.join([s.get_text() for s in scripts])

    # 提取前先移除style标签，避免CSS文本干扰后续判定
    # 同时记录style标签总长度，用于修正HTML体积计算
    total_style_len = sum(len(s.get_text()) for s in soup.find_all('style'))
    for style_tag in soup.find_all('style'):
        style_tag.decompose()

    # 获取纯文本（排除script/style等）
    body = soup.find('body')
    body_text = body.get_text(separator=' ', strip=True) if body else ''
    full_text = soup.get_text(separator=' ', strip=True)

    # 1. 基础分
    score = 50.0

    # --- 减分项 (倾向于动态) ---

    # 1.1 JS代码体积占比（如果超过30%，说明JS是重头戏）
    # 排除style标签内容，因为CSS既不是静态内容也不是JS，不应参与比例计算
    total_js_len = len(script_content)
    total_html_len = len(html) - total_style_len
    if total_html_len > 0:
        js_ratio = total_js_len / total_html_len
        if js_ratio > 0.3:
            score -= 25
        elif js_ratio > 0.15:
            score -= 10

    # 1.2 DOM操作关键词（出现这些意味着JS在改变页面结构）
    dom_keywords = ['document.createElement', 'appendChild', 'innerHTML', 'removeChild', 'document.write',
                    'createElement']
    if any(keyword in script_content for keyword in dom_keywords):
        score -= 15  # 只要出现即扣分

    # 1.3 检查现代框架根节点（如果#app或#root内几乎为空）
    root_selectors = ['#app', '#root', '#__next']
    for sel in root_selectors:
        tag = soup.select_one(sel)
        if tag:
            # 如果这个壳里只有不到10个字符（去除空白），说明是动态占位
            if len(tag.get_text(strip=True)) < 10:
                score -= 20
                break  # 找到一个壳即可

    # 1.4 检查加载占位词
    if 'loading' in full_text.lower() or 'placeholder' in full_text.lower():
        score -= 10

    # --- 加分项 (倾向于静态) ---

    # 2.1 Body 有大量实际文字（超过500字，说明服务端已渲染内容）
    if len(body_text) > 500:
        score += 20
    elif len(body_text) > 200:
        score += 10

    # 2.2 SEO相关：存在完善的Meta描述（静态页面通常重视SEO）
    meta_desc = soup.find('meta', attrs={'name': 'description'})
    if meta_desc and meta_desc.get('content') and len(meta_desc['content']) > 20:
        score += 5

    # 2.3 Next.js/Nuxt等SSR框架标识（虽然是JS框架，但内容已预渲染，归为偏静态）
    if '__NEXT_DATA__' in html or '__NUXT__' in html or 'data-reactroot' in html:
        score += 10

    # 限制分数范围在 0 - 100 之间
    return max(0.0, min(100.0, score))


def _check_file(file_path: Path) -> None:
    """从文件读取HTML内容并输出静态页面概率判定结果"""
    try:
        html_content = file_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        print(f"错误: 文件不存在 - {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"错误: 无法读取文件 - {e}")
        sys.exit(1)

    prob = estimate_static_probability(html_content)
    verdict = "静态页面" if prob >= 50 else "动态页面"
    print(f"文件: {file_path}")
    print(f"静态页面概率: {prob:.2f}%")
    print(f"判定结果: {verdict}")


def _print_demo() -> None:
    """打印内置示例（无文件参数时的默认行为）"""
    # 示例1：静态HTML
    static_html = """
    <html>
        <head><meta name="description" content="这是一个关于Python编程的教程"></head>
        <body>
            <h1>Python入门</h1>
            <p>这是一段非常详细的Python基础教程内容，大约有几百个字，包含了变量、循环、函数等知识点。</p>
            <p>这里是第二段内容，继续填充文字以增加文本量，确保超过500个字符的话，分数会更高。</p>
            <script>console.log("hello world")</script>
        </body>
    </html>
    """
    static_prob = estimate_static_probability(static_html)
    print(f"[示例1] 静态页面概率: {static_prob:.2f}%")

    # 示例2：动态CSR（React空壳）
    dynamic_html = """
    <html>
        <head><title>Loading...</title></head>
        <body>
            <div id="root"></div>
            <script>
                document.getElementById('root').innerHTML = '<h1>Hello React</h1>';
                // 大量其他JS代码...
            </script>
            <script src="/static/js/main.chunk.js"></script>
            <script src="/static/js/vendor.chunk.js"></script>
        </body>
    </html>
    """
    dynamic_prob = estimate_static_probability(dynamic_html)
    print(f"[示例2] 动态页面概率: {dynamic_prob:.2f}%")


# --- 使用示例 ---
if __name__ == "__main__":
    if len(sys.argv) > 1:
        _check_file(Path(sys.argv[1]))
    else:
        _print_demo()
"""FAQ 动态页面爬取脚本（从 scripts/crawl_tokyostarbank_faq.py 提取核心逻辑）

适用站点：support.tokyostarbank.co.jp 的 FAQ 分类页面。
交互流程：
  1. 打开 FAQ 分类页，等待分组按钮渲染
  2. 循环发现并点击 h4 分组按钮展开分类
  3. 在展开的分组内发现子分类按钮
  4. 逐个点击子分类按钮 → 等待 h5 内容 → 滚动懒加载 → 提取链接
  5. 分组按钮点击可能动态新增更多分组，持续循环直到全部处理
"""

import logging
import random
from datetime import datetime

from playwright.async_api import BrowserContext, Page

from src.core.dynamic_scripts.base import DynamicScript
from src.utils.url_utils import normalize_url, is_valid_url

logger = logging.getLogger(__name__)

# ── 页面常量 ──────────────────────────────────────────

# 分组按钮选择器（h4 分类，带 id 属性）
CATEGORY_BUTTON_SELECTOR = (
    'button.MuiButtonBase-root.MuiButton-root.MuiButton-contained'
    '.faq-category__button.faq-has-subcategory.MuiButton-fullWidth'
)

# 子分类按钮选择器（核心识别类：faq-subcategory + faq-category__button）
BUTTON_SELECTOR = (
    'button.MuiButtonBase-root.MuiButton-root.MuiButton-text'
    '.faq-subcategory.faq-category__button'
)

# 子内容加载标识（h5 问题标题，表示按钮点击后内容已渲染）
SUB_CONTENT_SELECTOR = 'h5.MuiTypography-root.faq-panel-content__q.MuiTypography-h5'

# 滚动加载参数
SCROLL_STEP = 800
SCROLL_DELAY_MS = 1500
SCROLL_MAX_IDLE = 3

# 页面超时（毫秒）
PAGE_TIMEOUT = 60000

# JS 链接提取脚本
JS_EXTRACT_LINKS = """
(() => {
  const collectedLinks = [];
  const seen = new Set();

  for (let i = 0; i < document.links.length; i++) {
    const link = document.links[i];
    if (link.href && link.href.trim()) {
      const href = link.href.trim();
      if (!href.startsWith('javascript:') && !href.startsWith('mailto:') && !href.startsWith('tel:')) {
        if (!seen.has(href)) {
          seen.add(href);
          collectedLinks.push(href);
        }
      }
    }
  }

  return collectedLinks;
})();
"""


class FaqCrawler(DynamicScript):
    """FAQ 动态页面爬取器"""

    # ── 公共入口 ─────────────────────────────────────

    async def execute(
        self,
        context: BrowserContext,
        parent_link: str,
        entry_url: str,
    ) -> dict:
        """执行 FAQ 动态爬取。

        Returns:
            dict: discovered_links + stats
        """
        page = await context.new_page()
        try:
            result = await self._crawl_faq(page, entry_url)
            return {
                "discovered_links": result.get("all_crawled_links", []),
                "stats": {
                    "total_categories": result.get("total_categories", 0),
                    "total_buttons": result.get("total_buttons", 0),
                    "total_links": result.get("total_links", 0),
                },
            }
        finally:
            await page.close()

    # ── 主流程 ──────────────────────────────────────

    async def _crawl_faq(self, page: Page, url: str) -> dict:
        """爬取 FAQ 动态站点的主流程。

        流程：
        1. 打开 FAQ 分类页，等待 h5 确认页面渲染完成
        2. 循环：获取未处理的分组按钮 → 点击展开 → 发现子分类按钮
        3. 逐个点击子分类按钮 → 等待 h5 → 滚动 → 提取链接
        4. 分组按钮可能动态新增，持续循环直到全部处理
        """
        logger.info(f"正在打开 FAQ 页面: {url}")
        await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)

        # 等待至少一个 h5 子内容标识出现
        try:
            await page.wait_for_selector(SUB_CONTENT_SELECTOR, timeout=20000)
            logger.info("h5 子内容标识已出现，页面内容已渲染")
        except Exception:
            logger.warning("未检测到 h5 子内容标识，尝试继续处理")

        # 等待分组按钮渲染
        try:
            await page.wait_for_selector(CATEGORY_BUTTON_SELECTOR, timeout=15000)
            cat_count = await page.locator(CATEGORY_BUTTON_SELECTOR).count()
            logger.info(f"分组按钮组件已加载，当前 {cat_count} 个")
        except Exception:
            logger.error("未检测到分组按钮组件，页面结构可能已变更")
            return {
                "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "url": url,
                "all_crawled_links": [],
                "total_categories": 0,
                "total_buttons": 0,
                "total_links": 0,
                "error": "category button not found",
            }

        # 等待子分类按钮渲染
        try:
            await page.wait_for_selector(BUTTON_SELECTOR, timeout=10000)
            btn_count = await page.locator(BUTTON_SELECTOR).count()
            logger.info(f"按钮组件已加载，当前可见 {btn_count} 个按钮")
        except Exception:
            logger.warning("未检测到按钮组件，尝试继续处理")

        processed_category_ids: set[str] = set()
        processed_buttons_total = 0
        all_crawled_links: list[str] = []

        while True:
            # 动态获取分组按钮列表
            category_infos = await page.evaluate("""
                () => {
                    const SEL = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-contained.faq-category__button.faq-has-subcategory.MuiButton-fullWidth';
                    const btns = Array.from(document.querySelectorAll(SEL));
                    return btns.map((btn, idx) => ({
                        index: idx,
                        id: btn.id || '',
                        text: btn.innerText.trim(),
                        ariaExpanded: btn.getAttribute('aria-expanded')
                    }));
                }
            """)

            # 找第一个未处理的分组按钮
            target = None
            for info in category_infos:
                if info["id"] and info["id"] not in processed_category_ids:
                    target = info
                    break

            if target is None:
                logger.info(f"所有分组按钮已处理完毕（共 {len(category_infos)} 个）")
                break

            target_id = target["id"]
            target_text = target["text"]
            is_expanded = target["ariaExpanded"] == "true"

            processed_category_ids.add(target_id)

            logger.info(
                f"\n{'='*50}\n"
                f"分组按钮: {target_text} (id={target_id}, "
                f"已处理 {len(processed_category_ids)} 个)"
            )

            # 点击分组按钮展开
            if not is_expanded:
                try:
                    cat_btn = page.locator(f'//*[@id="{target_id}"]')
                    await cat_btn.click()
                    await page.wait_for_timeout(random.randint(800, 1500))
                    try:
                        await page.wait_for_selector(SUB_CONTENT_SELECTOR, timeout=10000)
                    except Exception:
                        pass
                    logger.info(f"  已点击展开分组: {target_text}")
                except Exception as e:
                    logger.warning(f"  点击分组按钮失败: {e}")
                    continue
            else:
                logger.info(f"  分组已展开，无需点击")

            # 查询当前分组下的子分类按钮
            all_btn_infos = await page.evaluate("""
                ([targetId]) => {
                    const BTN_SEL = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-text.faq-subcategory.faq-category__button';
                    const catBtn = document.getElementById(targetId);
                    if (!catBtn) return [];
                    const catParent = catBtn.closest('div');
                    const collapseDiv = catParent ? catParent.nextElementSibling : null;
                    if (!collapseDiv) return [];
                    const btns = Array.from(collapseDiv.querySelectorAll(BTN_SEL));
                    return btns.map((btn, idx) => ({
                        globalIndex: idx,
                        text: btn.innerText.trim()
                    }));
                }
            """, [target_id])

            logger.info(f"  当前分组下找到 {len(all_btn_infos)} 个子分类按钮")

            # 逐个点击子分类按钮
            for btn_idx, btn_info in enumerate(all_btn_infos):
                btn_text = btn_info["text"]
                logger.info(f"  点击按钮 [{btn_idx + 1}/{len(all_btn_infos)}]: {btn_text}")

                try:
                    await page.evaluate("window.scrollTo(0, 0)")

                    clicked = await self._click_button_with_retry(page, btn_text)
                    if not clicked:
                        logger.error(f"    按钮 '{btn_text}' 重试 3 次仍失败，跳过")
                        continue

                    h5_appeared = await self._wait_for_sub_content(page, max_wait_seconds=30)
                    if not h5_appeared:
                        logger.warning(f"    h5 未出现，尝试继续获取链接")

                    await page.wait_for_timeout(random.randint(1000, 3000))

                    final_count = await self._scroll_to_load_all(page)
                    logger.info(f"    滚动加载完成，页面链接数: {final_count}")

                    unique_links = await self._extract_unique_links(page)
                    logger.info(f"    获取子链接 {len(unique_links)} 个")

                    all_crawled_links.extend(unique_links)
                    processed_buttons_total += 1

                except Exception as e:
                    logger.error(f"    处理按钮失败: {btn_text}, 错误: {e}")
                    continue

        # 汇总
        total_links = len(all_crawled_links)

        logger.info(
            f"FAQ 爬取完成: {len(processed_category_ids)} 个分类, "
            f"{processed_buttons_total} 个按钮, {total_links} 条链接"
        )

        return {
            "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "url": url,
            "all_crawled_links": all_crawled_links,
            "total_categories": len(processed_category_ids),
            "total_buttons": processed_buttons_total,
            "total_links": total_links,
        }

    # ── 页面交互工具 ────────────────────────────────

    async def _scroll_to_load_all(self, page: Page) -> int:
        """持续滚动页面直到没有新链接出现（懒加载内容全部加载）。

        Returns:
            最终链接数
        """
        idle_count = 0
        scroll_round = 0
        last_link_count = await page.evaluate("document.links.length")

        while idle_count < SCROLL_MAX_IDLE:
            await page.evaluate(f"window.scrollBy(0, {SCROLL_STEP})")
            scroll_round += 1
            await page.wait_for_timeout(SCROLL_DELAY_MS)

            current_link_count = await page.evaluate("document.links.length")

            if current_link_count > last_link_count:
                idle_count = 0
                logger.debug(
                    f"    滚动第 {scroll_round} 次："
                    f"新链接 {current_link_count - last_link_count} 个，"
                    f"累计 {current_link_count}"
                )
                last_link_count = current_link_count
            else:
                idle_count += 1

            at_bottom = await page.evaluate(
                "() => (window.innerHeight + window.scrollY) >= document.body.scrollHeight - 100"
            )
            if at_bottom and idle_count >= 1:
                break

        return last_link_count

    async def _extract_unique_links(self, page: Page) -> list[str]:
        """从当前页面提取去重后的有效链接列表。

        Returns:
            去重后的链接列表（原始 URL，非标准化）
        """
        raw_links = await page.evaluate(JS_EXTRACT_LINKS)
        valid_links = [href for href in raw_links if is_valid_url(href)]

        seen: set[str] = set()
        unique_links: list[str] = []
        for link in valid_links:
            norm = normalize_url(link)
            if norm not in seen:
                seen.add(norm)
                unique_links.append(link)

        return unique_links

    async def _click_button_with_retry(
        self, page: Page, btn_text: str, max_retries: int = 3
    ) -> bool:
        """点击按钮（带重试）：每次重试前重新查询全局按钮，按文本匹配定位。

        Returns:
            是否点击成功
        """
        for retry in range(max_retries):
            try:
                target_idx = await page.evaluate("""
                    (btnText) => {
                        const BTN_SEL = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-text.faq-subcategory.faq-category__button';
                        const btns = Array.from(document.querySelectorAll(BTN_SEL));
                        for (let i = 0; i < btns.length; i++) {
                            if (btns[i].innerText.trim() === btnText) {
                                return i;
                            }
                        }
                        return -1;
                    }
                """, btn_text)

                if target_idx < 0:
                    logger.warning(f"    重试 {retry + 1}/{max_retries}: 未找到按钮 '{btn_text}'")
                    await page.wait_for_timeout(1000)
                    continue

                btn = page.locator(BUTTON_SELECTOR).nth(target_idx)
                await btn.click(timeout=15000)
                logger.info(f"    已点击按钮: {btn_text} (global_idx={target_idx}, 重试={retry})")
                return True
            except Exception as e:
                logger.warning(f"    重试 {retry + 1}/{max_retries} 点击按钮失败: {e}")
                await page.wait_for_timeout(2000)

        return False

    async def _wait_for_sub_content(
        self, page: Page, max_wait_seconds: int = 30
    ) -> bool:
        """等待子内容加载（h5 出现），轮询检测加载中标识。

        Returns:
            h5 是否出现
        """
        rounds = max_wait_seconds // 5
        for wait_round in range(rounds):
            try:
                await page.wait_for_selector(SUB_CONTENT_SELECTOR, timeout=5000)
                logger.info(f"    h5 子内容已出现 (等待第 {wait_round + 1} 轮)")
                return True
            except Exception:
                logger.info(f"    等待 h5 第 {wait_round + 1}/{rounds} 轮，尚未出现")
                loading = await page.evaluate("""
                    () => {
                        const loaders = document.querySelectorAll(
                            '.MuiCircularProgress-root, .loading, [class*="loading"], [class*="spinner"]'
                        );
                        return loaders.length > 0;
                    }
                """)
                if loading:
                    logger.info(f"    检测到加载中标识，继续等待")

        logger.warning(f"    等待 {max_wait_seconds} 秒后 h5 仍未出现")
        return False

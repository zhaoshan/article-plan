package com.unify.iam.tenant.infra.persistence.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

/** gateway_membership Mapper。 */
@Mapper
public interface MembershipMapper extends BaseMapper<MembershipPO> {

    /**
     * 令牌版本 +1（方案 c 即时吊销 bump；@TableLogic 同款注意：不能用 updateById 手动改版本号之外的同表字段）。
     *
     * @return 命中行数（成员不存在/已删 → 0）
     */
    @Update("UPDATE gateway_membership SET token_version = token_version + 1 WHERE membership_id = #{membershipId} AND delete_flag = 0")
    int bumpTokenVersion(@Param("membershipId") String membershipId);
}

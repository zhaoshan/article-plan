package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * G1 Usage 配额集成测试：Usage 视图（模板默认 + 租户调额覆盖）、席位强制（邀请/加成员）、应用数强制、租户作用域。
 */
class QuotaIntegrationTest extends IamIntegrationTestBase {

    private static final String DIM_MEMBERS = "gd-2001";
    private static final String DIM_APPS = "gd-2002";

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("access_token").toString();
    }

    @Test
    void usageViewShowsDefaultsAndTenantOverride() throws Exception {
        String admin = login("admin", "admin123");
        // 租户只开通 imorph → Usage 仅含 imorph 维度（iam 全局维度不出现：配额跟随开通应用）
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"q-view\",\"tenant_name\":\"Q View\","
                                + "\"app_codes\":[\"imorph\"],\"owner_user_id\":\"u-1000\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        String imorphMembers = dimId("imorph", "members");
        mockMvc.perform(get("/api/v1/admin/tenants/" + tenantId + "/usage")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.usage.length()").value(2))
                .andExpect(jsonPath("$.data.usage[0].dimension_key").value("members"))
                .andExpect(jsonPath("$.data.usage[0].app_code").value("imorph"))
                .andExpect(jsonPath("$.data.usage[0].limit").value(10))
                .andExpect(jsonPath("$.data.usage[0].override").value(false))
                .andExpect(jsonPath("$.data.usage[0].used").isNumber())
                .andExpect(jsonPath("$.data.usage[1].dimension_key").value("apps"));

        // 调额覆盖 → limit 生效 override=true；清除 → 回落默认
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + imorphMembers)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"limit_value\":3}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.limit").value(3))
                .andExpect(jsonPath("$.data.override").value(true));
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + imorphMembers)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.limit").value(10))
                .andExpect(jsonPath("$.data.override").value(false));
    }

    private String dimId(String appCode, String key) {
        return jdbcTemplate.queryForObject(
                "SELECT dimension_id FROM gateway_quota_dimension WHERE app_code=? AND dimension_key=?",
                String.class, appCode, key).trim();
    }

    @Test
    void memberSeatEnforcedOnInviteAndAdminAdd() throws Exception {
        String admin = login("admin", "admin123");
        // 造租户（imorph）：owner=admin（1 个 ACTIVE 成员）
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"q1\",\"tenant_name\":\"Q1\","
                                + "\"app_codes\":[\"imorph\"],\"owner_user_id\":\"u-1000\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        // iam 全局维度对未启用 iam 的租户不强制（配额跟随开通应用）：调 iam:members=1 也不拦
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + DIM_MEMBERS)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"limit_value\":1}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"q1iam@unify.local\",\"tenant_id\":\"" + tenantId + "\"}"))
                .andExpect(status().isOk());
        // 恢复 iam 维度默认，再压 imorph:members=1（owner 已占 1 + 上一步邀请待接受）→ 400
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + DIM_MEMBERS)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isOk());
        String imorphMembers = dimId("imorph", "members");
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + imorphMembers)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"limit_value\":1}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"q1full@unify.local\",\"tenant_id\":\"" + tenantId + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("席位不足")));
        mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"" + tenantId + "\",\"user_id\":\"u-1001\",\"role_ids\":[]}"))
                .andExpect(status().isBadRequest());
        // 放宽到 3（1 在册 + 1 待接受 + 新邀请）→ 邀请放行
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + imorphMembers)
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"limit_value\":3}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"q1ok@unify.local\",\"tenant_id\":\"" + tenantId + "\"}"))
                .andExpect(status().isOk());
    }

    @Test
    void imorphDimensionsSeededAndEnforced() throws Exception {
        String admin = login("admin", "admin123");
        // imorph 维度 seed（R__app_imorph.sql）：members 10 / apps 20
        // 建租户启用 imorph（owner=admin）→ Usage 视图含全局 iam + imorph 两组维度
        String tenantId = unwrapData(mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"q-imorph\",\"tenant_name\":\"Q Imorph\","
                                + "\"app_codes\":[\"imorph\"],\"owner_user_id\":\"u-1000\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("tenant_id").toString();
        mockMvc.perform(get("/api/v1/admin/tenants/" + tenantId + "/usage")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.usage.length()").value(2))
                .andExpect(jsonPath("$.data.usage[?(@.app_code == 'imorph' && @.dimension_key == 'members')].limit")
                        .value(org.hamcrest.Matchers.hasItem(10)))
                .andExpect(jsonPath("$.data.usage[?(@.app_code == 'imorph' && @.dimension_key == 'apps')].limit")
                        .value(org.hamcrest.Matchers.hasItem(20)));

        // imorph.members 调额 1（owner 已占 1 席）→ 邀请 400（应用专属配额同样强制）
        String imorphMembersDim = jdbcTemplate.queryForObject(
                "SELECT dimension_id FROM gateway_quota_dimension WHERE app_code='imorph' AND dimension_key='members'",
                String.class);
        mockMvc.perform(put("/api/v1/admin/tenants/" + tenantId + "/usage/" + imorphMembersDim.trim())
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"limit_value\":1}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/admin/invitations")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"qimorphfull@unify.local\",\"tenant_id\":\"" + tenantId + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("imorph")));
    }

    @Test
    void usageScopedToOwnTenants() throws Exception {
        String admin = login("admin", "admin123");
        // 新租户 owner = 新用户 → 该用户读 org-a 的 usage 越权 403
        unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"qscope\",\"email\":\"qscope@unify.local\",\"password\":\"Passw0rd!\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString());
        String uid = jdbcTemplate.queryForObject(
                "SELECT user_id FROM gateway_user WHERE primary_email='qscope@unify.local'", String.class);
        mockMvc.perform(post("/api/v1/admin/tenants")
                        .header("Authorization", "Bearer " + admin)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_code\":\"q-scope\",\"tenant_name\":\"Q Scope\","
                                + "\"app_codes\":[\"parlant-agent-server\"],\"owner_user_id\":\"" + uid + "\"}"))
                .andExpect(status().isOk());
        String owner = login("qscope", "Passw0rd!");
        mockMvc.perform(get("/api/v1/admin/tenants/tenant-org-a/usage")
                        .header("Authorization", "Bearer " + owner))
                .andExpect(status().isForbidden());
        // 本租户可读
        mockMvc.perform(get("/api/v1/admin/tenants/tenant-org-a/usage")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());
    }
}

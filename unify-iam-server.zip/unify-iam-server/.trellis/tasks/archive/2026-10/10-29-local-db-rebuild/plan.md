# 本地数据库重建与服务重启计划

日期：2026-10-29（Asia/Shanghai）

## 范围与约束

- 仅操作当前 platform-iam-service 主工作区、其既有本地 MySQL 容器和既有 launchd Java 服务。
- 保留现有源代码、配置和 Git 状态；不提交、合并、推送、切换、重置分支，不创建或删除 worktree。
- 用户已明确授权删除本地开发数据库 unify_iam。

## 执行步骤

1. 核实数据库连接确实为本机开发 MySQL，并记录删除前状态。
2. 停止既有 Java 服务，精确删除 `unify_iam` 数据库，不触碰其他 schema。
3. 使用项目要求的 Maven/JDK 参数重新编译当前代码。
4. 通过既有 launchd 服务重启 Java 服务，让 Flyway schema 与 seed 机制初始化数据库。
5. 验证数据库、Flyway、服务健康、端口和 Git 未提交状态。

## 初始证据

- MySQL 容器：`platform-iam-service-mysql`，镜像 `mysql:8.0`，`127.0.0.1:3306`，healthy，版本 8.0.46。
- `unify_iam` 存在，删除前 24 张表，Flyway 最新已成功到 17。
- 既有服务：launchd `com.platform-iam.service`，当前监听 8090，健康检查 200/UP。

## 执行结果

- 删除前目标确认：`platform-iam-service-mysql` / `mysql:8.0` / `127.0.0.1:3306` / MySQL 8.0.46；`unify_iam` 存在且 24 表。
- 删除后由应用配置 `jdbc:mysql://127.0.0.1:3306/unify_iam?createDatabaseIfNotExist=true` 触发重建；Flyway 应用 17 个迁移并到 v18，平台 bootstrap 与 `imorph` seed 成功。
- 编译成功：`mvn clean install -DskipTests -Dmaven.compiler.proc=full`。
- 重启成功：launchd `com.platform-iam.service` 当前运行，PID 81490，监听 8090。
- 健康验证成功：health/readiness 均 HTTP 200/UP，JWKS HTTP 200 且返回 `iam-key-1` RS256。
- Git 未提交状态保留；未执行任何 Git/worktree 操作。

package com.unify.iam.app.mail;

import com.unify.iam.app.config.IamProperties;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

/**
 * 邀请邮件编排（G2，docs/08 §2.5 + §3）：加载 classpath HTML 模板 →
 * {@link MailTemplateRenderer} 渲染（{{变量}} + {{#initial_password}} 条件块）→ {@link EmailTool} 投递。
 *
 * <p>模板变量对齐 M10W4-W5 设计：{{Full_Name}} {{tenant_name}} {{role}} {{invited_email}}
 * {{initial_password}}（仅新账号，已有账号整块移除）{{expires_at}} {{invitation_link}}。
 */
@Service
public class InvitationMailService {

    private static final DateTimeFormatter EXPIRES_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final EmailTool emailTool;
    private final IamProperties props;

    public InvitationMailService(EmailTool emailTool, IamProperties props) {
        this.emailTool = emailTool;
        this.props = props;
    }

    /** Owner 邀请（建租户 owner_email 开通）。initialPassword=null 表示已有账号（省略密码行）。 */
    public void sendOwnerInvitation(String to, String tenantName, String initialPassword,
                                    LocalDateTime expiresAt, String invitationToken) {
        send(to, props.getMail().getOwnerInvitationSubject(), props.getMail().getOwnerInvitationTemplate(),
                baseVars(to, tenantName, initialPassword, expiresAt, invitationToken));
    }

    /** Member/Admin 邀请。 */
    public void sendMemberInvitation(String to, String tenantName, String role, String initialPassword,
                                     LocalDateTime expiresAt, String invitationToken) {
        Map<String, String> vars = baseVars(to, tenantName, initialPassword, expiresAt, invitationToken);
        vars.put("role", role == null ? "Member" : role);
        send(to, props.getMail().getMemberInvitationSubject(), props.getMail().getMemberInvitationTemplate(), vars);
    }

    /** 密码重置邮件（docs/08 §2.1）：reset_url = hub 基址 + /reset-password?token=<明文>（前端 ResetPassword 从 query 预填）。 */
    public void sendPasswordReset(String to, String resetUrl) {
        Map<String, String> vars = new LinkedHashMap<>();
        vars.put("Full_Name", to.substring(0, to.indexOf('@')));
        vars.put("reset_url", resetUrl);
        send(to, props.getMail().getPasswordResetSubject(), props.getMail().getPasswordResetTemplate(), vars);
    }

    /** {{invitation_link}} = hub 基址 + /invitations/accept?token=..&app=..（app 默认 imorph，产品口径 docs/08 §2.5）。 */
    public String invitationLink(String invitationToken) {
        String base = props.getMail().getInvitationLinkBaseUrl().replaceAll("/+$", "");
        return base + "/invitations/accept?token=" + invitationToken + "&app=" + props.getMail().getInvitationDefaultApp();
    }

    private Map<String, String> baseVars(String to, String tenantName, String initialPassword,
                                         LocalDateTime expiresAt, String invitationToken) {
        Map<String, String> vars = new LinkedHashMap<>();
        vars.put("Full_Name", to.substring(0, to.indexOf('@')));
        vars.put("tenant_name", tenantName);
        vars.put("invited_email", to);
        // 仅新账号放入 initial_password——已有账号（null）由渲染器整块移除密码区块
        vars.put("initial_password", initialPassword);
        vars.put("expires_at", expiresAt == null ? "" : expiresAt.format(EXPIRES_FMT));
        vars.put("invitation_link", invitationLink(invitationToken));
        return vars;
    }

    private void send(String to, String subjectTemplate, String bodyClasspath, Map<String, String> vars) {
        String html = load(bodyClasspath);
        emailTool.send(to, MailTemplateRenderer.render(subjectTemplate, vars),
                MailTemplateRenderer.render(html, vars));
    }

    private String load(String classpath) {
        try {
            return new String(new ClassPathResource(classpath).getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("邮件模板加载失败: " + classpath, e);
        }
    }
}

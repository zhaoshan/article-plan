# Research: Member role writes, invitation validation and PLATFORM security semantics

- Query: Can the member role picker safely offer custom PLATFORM roles together with the target tenant's non-owner roles?
- Scope: Internal; current local main checkout only, including existing uncommitted changes. No implementation.
- Date: 2026-11-05

## Findings

### Existing member writes

- `iam-app/src/main/java/com/unify/iam/app/app/service/admin/AdminMemberService.java:100`: `add` authorizes the target tenant, checks seat quota and tenant/user existence, creates an ACTIVE membership, and passes supplied `role_ids` directly to `replaceDirectRoles` at line 122. It does not validate individual role existence, status, tenant ownership, PLATFORM scope, or owner uniqueness.
- Same file, line 130: `setRoles` resolves membership and authorizes its tenant, then preserves last-admin capability (`assertKeepsAdmin`, line 251) and checks owner uniqueness (`assertOwnerUnique`, line 227). It replaces role bindings at line 138, bumps token version, and audits old/new IDs. Those protections do not establish an assignment allowlist or validate scope/status for every role ID.
- `iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/repository/MembershipRoleRepository.java:90`: replacement trims/deduplicates role IDs, revives/inserts DIRECT bindings, and removes missing bindings. No role lookup or policy validation occurs here.
- `iam-api/src/main/java/com/unify/iam/api/dto/admin/SetRolesRequest.java:8`: null role_ids becomes an empty list (clear-all semantics); there is no role element validation. The UI must not accidentally clear roles while options are loading.
- `AdminMemberService.java:87`: current member roles are read separately from candidate roles; results are existing bindings with role_id/code/name, not an assignment catalogue.

### Invitations have a different, incompatible assignment rule

- `iam-app/src/main/java/com/unify/iam/app/app/service/InvitationService.java:126`: create authorizes the tenant, checks invitation delivery/quota/duplicate conditions, then calls `issueForTenant` using the singular request `role_id` at lines 155-156. The checked-in runtime contract here is singular despite a historical migration named multiple_roles.
- Same file, lines 223-237: explicit/default role goes through `assertRoleInTenant` and owner uniqueness checks before invitation persistence.
- Same file, lines 322-327: `assertRoleInTenant` requires a non-deleted existing role with `scope_type=TENANT` and matching target `scope_id`. ALL PLATFORM roles are rejected, including non-builtin custom roles. It does not explicitly check `role_status=ACTIVE`.
- Same file, lines 263-279: omitted/blank role_id is not a safe "no role" choice. Default resolution selects an available owner role first, otherwise admin, then Member; only missing template/defaults may result in null. A non-owner picker must explicitly send its selected role and must not submit while loading or silently omit it on failure. Changing backend default behavior needs explicit scope agreement.
- Same file, lines 346-401: acceptance checks invitation status and matching email, creates/finds membership, checks owner uniqueness, binds the saved default role, and marks accepted. It does not re-run `assertRoleInTenant`, status, application eligibility or the original actor's grant authority at acceptance. New eligibility rules must consider create-to-accept drift, not just picker loading.
- Owner setup/transfer use separate invitation purposes and ownership service calls (lines 396-399). A regular member-picker filter must not silently redefine these flows.

### Owner matching is template based, not a literal name or builtin flag

- `iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/repository/ApplicationRoleTemplateRepository.java:32`: owner codes are the distinct trimmed `role_code` values of non-deleted templates with `is_owner=1` in the tenant's enabled application codes.
- `AdminMemberService.java:231` and `InvitationService.java:304` resolve these codes using `TenantApplicationRepository.findAppCodesByTenant`. Never filter only role_code='Owner' or role_name='Owner'; non-owner builtin tenant roles remain candidates under the requested rule.
- Member writes prevent assigning an owner role when another ACTIVE holder exists. Last-admin protection also prevents removing the sole owner role (AdminMemberService lines 268-289) and losing the final IAM member/role write capability (lines 251-264). Merely excluding owner from the candidate list does not authorize clearing an existing owner binding.
- Invitation uniqueness additionally considers PENDING invitations (InvitationService lines 303-318).

### Critical: PLATFORM currently means platform management authority

- `iam-app/src/main/java/com/unify/iam/app/security/TenantScopeGuard.java:26`: `isPlatformAdmin` delegates to role membership lookup, not role name or builtin status.
- `iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/mapper/RoleMapper.java:17`: `countPlatformRolesByMembership` counts ANY non-deleted PLATFORM role binding for that membership. It has no role_status, is_builtin, role_code, or platform-tenant constraint.
- `TenantScopeGuard.java:31`: such a member bypasses target tenant checks; line 41 also accepts them for platform-only operations. Endpoint permission gates still apply, so this is scope elevation, not automatically every permission. A member with tenant-management permissions plus a custom PLATFORM role can pass foreign-tenant checks for those permissions.
- `iam-authorization/src/main/java/com/unify/iam/authorization/infra/persistence/mapper/AuthorizationQueryMapper.java:18` and line 30: effective roles/permissions use ACTIVE roles, but the platform-admin scope check above does not. Permission unions do not constrain role scope to membership tenant or enabled applications.
- Therefore, broadening invitation/member choices to all custom PLATFORM roles is a security semantic decision. Do not describe it as a harmless list-query filter. A safe future implementation needs explicit policy for reusable global roles versus platform administration, consistent read/write validation, and tests against tenant-admin privilege escalation. No such change was authorized or implemented in this research task.

## Files found

The file:line anchors above cover member services/DTO, binding repository, invitation orchestration, owner template repository, tenant scope guard and effective authorization mapper. Relevant project guidance: `.trellis/workflow.md`; `.trellis/spec/backend/database-guidelines.md` (management/runtime query separation; scope authorization precedes queries).

## External references

None. Conclusions use current repository code only.

## Caveats / Not Found

- No frontend source was inspected and no runtime tests were run; this is source-level contract analysis.
- No existing common grantability validator was found in the inspected member/invitation write paths. New query output alone will neither make invitation submission accept PLATFORM roles nor close the member-write gaps.
- Existing owner bindings, disabled/deleted choices, invitation default behavior, acceptance-time drift and global-role scope authority must be addressed explicitly in a later approved implementation scope.

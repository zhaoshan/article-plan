# 用户启停 PUT pending：运行故障与恢复

## 结论

本地 Java 服务确有局部运行故障。健康检查、登录、GET 正常，但合法管理员的用户 PUT 更新无法返回。根因证据指向运行中 Spring Boot 可执行 JAR 被重新打包覆盖，旧 JVM 的嵌套 ZIP/classloader 状态失效；不是用户更新 SQL 的事务锁或外部 HTTP 依赖阻塞。

本轮只重启当前项目既有的本地服务，没有修改生产 Java、SQL、DTO、配置或前端，也没有重新打包 JAR。恢复后真实启停、代理路径、失败响应均通过验证。

## 已证实的证据

1. 故障进程 PID 83256 启动于 2026-10-27 17:19（Asia/Shanghai），命令行为当前项目 `iam-app/target/iam-app-0.0.1-SNAPSHOT.jar`。该 JAR 文件修改时间为 17:55:42；当前项目 tenant-member-search-projection 会话记录也记录了运行期间执行 Maven package。
2. 新登录取得有效管理员会话后，直连 8090 和经 5174 代理的 DISABLED/ACTIVE PUT 都在客户端 10 秒观察窗口内无响应。查询仍在 13–37ms 返回，状态维持 ACTIVE。见 runtime-probes.json。10 秒是探测上限，不是服务端自行超时。
3. 请求进行时，MySQL 没有活跃事务，锁等待数为 0，连接处于 Sleep。线程快照中没有停在用户 SQL、事务或外部调用的工作线程。见 active-db-evidence.txt、thread-print.txt、thread-dump.txt。这是多次采样证据，不能扩展为对所有历史请求的绝对断言。
4. JFR 捕获同一请求时，依次出现：
   - `java.io.EOFException`，`org.springframework.boot.loader.zip.DataBlock.readFully`。
   - `java.io.UncheckedIOException`，`ZipContent.loadZipCentralDirectoryFileHeaderRecord`。
   - `jakarta.validation.ValidationException: HV000032: Unable to initialize ...PatternValidator`。
   - 日志异常处理类 `ch.qos.logback.classic.spi.ThrowableProxy` 的 `ClassNotFoundException` / `NoClassDefFoundError`。
   - `ServletException: Handler processing failed: ...NoClassDefFoundError`，错误响应处理也失败。
   见 classloading-deep-evidence.json。由此可解释请求在参数校验/错误处理阶段失败，数据库未写入，且没有正常错误响应。普通线程快照没有持续繁忙线程，并不能据此判断请求成功。
5. 当前磁盘 JAR 的 ZIP 完整性检查通过，内嵌 logback-classic-1.5.22.jar 中确有 ThrowableProxy.class；因此不是当前构建永久漏打该类。
6. 仅执行 `launchctl kickstart -k gui/501/com.platform-iam.service` 重启当前项目既有服务。新 PID 17662 加载同一路径现有 JAR，不改源码、配置和数据库结构，随后全部真实用户启停请求恢复。该前后对照与上述 ZIP/classloading 错误共同支持根因判断。

## 恢复验证

| 路径 | 操作 | HTTP | 耗时 |
| --- | --- | --- | --- |
| 直连 localhost:8090 | DISABLED | 200 | 99ms |
| 直连 localhost:8090 | ACTIVE | 200 | 28ms |
| 经 localhost:5174 | DISABLED | 200 | 55ms |
| 经 localhost:5174 | ACTIVE | 200 | 23ms |
| 直连 localhost:8090 | 无令牌 | 401 | 8ms |
| 直连 localhost:8090 | 无效邮箱 | 400 | 14ms |
| 直连 localhost:8090 | 不存在用户 | 404 | 15ms |

- 每次成功 PUT 后都通过 GET 读取数据库投影，确认实际状态匹配。成功响应维持原有信封和 user_id。
- 目标用户原始状态 ACTIVE。中断后通过既有探测文件和数据库确认原始状态未改变；恢复实测 finally 再设回 ACTIVE，最终 GET 与数据库只读核验一致。
- 新服务 `/actuator/health` 返回 HTTP 200、UP；业务写入和错误路径均实测通过，因此本次没有只依据 health 判断恢复。
- 现有 AdminUserServiceTest、AdminUserControllerTest、AdminUserEmailUpdateIntegrationTest 共 20 项通过，0 failures/errors/skipped，Maven BUILD SUCCESS。命令与日志见 session.md / tests.log。
- 使用 Maven test，没有执行 package，避免再次覆盖运行中的 JAR。测试的集成部分使用隔离 Testcontainers MySQL。

## 判断边界与后续运行约束

- 运行中 JAR 被覆盖以及请求触发 ZIP/classloading 异常均有证据；没有保存覆盖前的 JAR，所以无法还原覆盖瞬间的逐字节偏移变化，也未故意再次覆盖健康进程来制造破坏性复现。
- 附件 Bearer 在排查时已过期，直连 8090 会立即 401；它解释不了新会话的 PUT pending。测试使用正常本地登录的新会话，仅在内存中持有凭证，证据不包含 token、密码或私钥。
- 尚无证据表明用户更新事务存在死锁、锁等待、连接池耗尽或外部服务阻塞；不据此添加超时、重试或修改业务更新代码。
- 既有本地服务仍直接运行 target JAR。后续在该路径重新 package/clean/install 后，应立即重启既有服务，并验证真实写接口；更稳妥的长期部署方式是从独立、不可覆盖的版本化产物启动，避免构建输出覆盖运行产物。本次没有修改工作区外的启动定义。

## Git 与范围

- 项目：`/Users/ramiro.li/root/apps/work/platform-iam-service`。
- 分支：`feature/v0.10.3-m10w3`；HEAD 784c255。
- 本轮文件变更仅 `.trellis/tasks/10-27-admin-user-update-pending/` 下记录与脱敏验证证据。已有其他任务记录和 API 手册未提交改动保留。
- 未执行 git add/commit/merge/push/checkout/reset 或任何 worktree 操作，全部本轮记录未暂存、未提交。

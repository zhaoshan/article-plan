package com.unify.iam.app.app.service.admin;

import com.unify.iam.api.dto.admin.CreateRoleRequest;
import com.unify.iam.api.dto.admin.SetPermissionsRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.authorization.infra.persistence.po.PermissionPO;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RolePermissionRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.security.TenantScopeGuard;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;

/**
 * 管理面角色服务（docs/04 §3.2，iam:role:*；docs/06 §3.3 租户级作用域）。
 *
 * <p>作用域目标：scope_type=PLATFORM 仅平台管理员可操作；scope_type=TENANT 限本租户（租户级）。
 * 权限隔离（V8）：TENANT 角色只能绑定「该租户已开通应用的业务权限」+「租户内 iam:member/role」，
 * 平台专属权限（iam:user/tenant/audit/idp）不可授给 TENANT 角色（防提权）。
 */
@Service
public class AdminRoleService {

    private static final String IAM_APP = "iam";

    private final RoleRepository roleRepository;
    private final RolePermissionRepository rolePermissionRepository;
    private final PermissionRepository permissionRepository;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final TenantScopeGuard tenantScopeGuard;
    private final TokenVersionService tokenVersionService;
    private final AuditService auditService;

    public AdminRoleService(RoleRepository roleRepository,
                            RolePermissionRepository rolePermissionRepository,
                            PermissionRepository permissionRepository,
                            TenantApplicationRepository tenantApplicationRepository,
                            TenantScopeGuard tenantScopeGuard,
                            TokenVersionService tokenVersionService,
                            AuditService auditService) {
        this.roleRepository = roleRepository;
        this.rolePermissionRepository = rolePermissionRepository;
        this.permissionRepository = permissionRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.tenantScopeGuard = tenantScopeGuard;
        this.tokenVersionService = tokenVersionService;
        this.auditService = auditService;
    }

    public List<RolePO> listByScope(JwtClaims claims, String scopeType, String scopeId) {
        String type = scopeType == null ? "TENANT" : scopeType;
        String id = scopeId == null ? "PLATFORM" : scopeId;
        assertRoleScope(claims, type, id);
        return roleRepository.listByScope(type, id);
    }

    public String create(JwtClaims claims, CreateRoleRequest request) {
        String type = request.scopeType() == null ? "TENANT" : request.scopeType();
        String id = request.scopeId() == null ? "PLATFORM" : request.scopeId();
        assertRoleScope(claims, type, id);
        RolePO role = new RolePO();
        role.setRoleId(IdGenerator.newBizId());
        role.setScopeType(type);
        role.setScopeId(id);
        role.setRoleCode(request.roleCode().trim());
        role.setRoleName(request.roleName().trim());
        role.setRoleDescription(request.roleDescription());
        role.setIsBuiltin(0);
        role.setRoleStatus("ACTIVE");
        roleRepository.create(role);
        return role.getRoleId();
    }

    public void setPermissions(JwtClaims claims, String roleId, SetPermissionsRequest request) {
        RolePO role = roleRepository.findById(roleId).orElseThrow(() -> AuthException.notFound("角色不存在"));
        assertRoleScope(claims, role.getScopeType(), role.getScopeId());
        if ("TENANT".equals(role.getScopeType())) {
            assertTenantGrantable(role.getScopeId(), request.permissionIds());
        }
        rolePermissionRepository.replaceForRole(roleId, request.permissionIds());
        // 角色权限变更影响该角色所有持有者 → 批量 bump（方案 c 即时吊销）
        tokenVersionService.bumpForRoleHolders(roleId, "PERM_CHANGE");
    }

    /** 角色当前权限点 id 集（管理台授权回显）。 */
    public List<String> getPermissionIds(String roleId) {
        return rolePermissionRepository.listPermissionIdsForRole(roleId);
    }

    public void delete(JwtClaims claims, String roleId) {
        RolePO role = roleRepository.findById(roleId).orElseThrow(() -> AuthException.notFound("角色不存在"));
        assertRoleScope(claims, role.getScopeType(), role.getScopeId());
        roleRepository.logicalDelete(roleId);
        // G5-b：角色删除审计（TENANT 角色填目标租户）
        String tenantId = "TENANT".equals(role.getScopeType()) ? role.getScopeId() : null;
        auditService.audit().event("ADMIN_DELETE_ROLE").actor(claims.userId())
                .tenant(tenantId).target("ROLE", roleId)
                .write(Map.of("role_code", role.getRoleCode(), "scope_type", role.getScopeType()));
    }

    /** 角色作用域目标校验：PLATFORM → 需平台管理员；TENANT → 目标租户 == token.tenantId。 */
    private void assertRoleScope(JwtClaims claims, String scopeType, String scopeId) {
        if ("PLATFORM".equals(scopeType)) {
            tenantScopeGuard.assertPlatformAdmin(claims);
        } else {
            tenantScopeGuard.assertTenantScope(claims, scopeId);
        }
    }

    /**
     * TENANT 角色可授集校验（V8 权限隔离，防提权）：
     * 只允许绑定「该租户已开通应用的业务权限」+「IAM 租户内管理权限（iam:member/role，tenant_grantable=1）」；
     * 平台专属（iam:user/tenant/audit/idp）或未开通应用的权限 → 400。
     */
    private void assertTenantGrantable(String tenantId, List<String> permissionIds) {
        if (permissionIds == null || permissionIds.isEmpty()) {
            return;
        }
        Map<String, PermissionPO> byId = permissionRepository.findByIds(permissionIds).stream()
                .collect(Collectors.toMap(PermissionPO::getPermissionId, Function.identity(), (a, b) -> a));
        Set<String> enabledApps = Set.copyOf(tenantApplicationRepository.findAppCodesByTenant(tenantId));
        for (String id : permissionIds) {
            PermissionPO p = byId.get(id);
            if (p == null) {
                throw AuthException.badRequest("权限点不存在：" + id);
            }
            boolean tenantGrantable = p.getTenantGrantable() != null && p.getTenantGrantable() == 1;
            boolean ok = tenantGrantable && (IAM_APP.equals(p.getAppCode()) || enabledApps.contains(p.getAppCode()));
            if (!ok) {
                throw AuthException.badRequest("权限 [" + p.getPermissionCode()
                        + "] 不能授予该租户角色（平台专属或应用未开通）");
            }
        }
    }
}

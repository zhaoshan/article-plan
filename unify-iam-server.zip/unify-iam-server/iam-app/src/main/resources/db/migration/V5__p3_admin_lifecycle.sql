-- --------------------------------------------
-- unify-iam-server E2E-3（P3）：管理面与账号生命周期（V5）
-- 数据库：MySQL 8.x；schema：unify_iam
-- 内容：账号生命周期/管理面相关表 + 管理权限点 + PlatformAdmin 授 admin
-- 来源：ai-chat-insight `20260325-统一注册登录-schema-mysql.sql`（refresh/reset）+ 架构源 Tenant-IAM DDL（invitation/join/domain/audit）
-- 说明：refresh_token 在 ai-chat-insight 基础上补 tenant_id/membership_id（单租户 membership 语义，刷新重签同一上下文）；seed 幂等
-- --------------------------------------------

SET NAMES utf8mb4;

-- ============================================================
-- 1. refresh token（复用 ai-chat-insight，++ tenant_id / membership_id）
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_refresh_token` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `refresh_token_id` CHAR(32) NOT NULL COMMENT 'refresh token 业务唯一标识（UUID 无横线 32 位）',
  `user_id` CHAR(32) NOT NULL COMMENT '对应 gateway_user.user_id',
  `tenant_id` CHAR(32) NOT NULL COMMENT '签发时激活的租户（刷新重签同一 membership 上下文）',
  `membership_id` CHAR(32) NOT NULL COMMENT '签发时激活的成员关系',
  `refresh_token_hash` VARCHAR(128) NOT NULL COMMENT 'refresh token hash（避免明文落库）',
  `expires_at` DATETIME NOT NULL COMMENT 'refresh token 过期时间',
  `revoked_at` DATETIME DEFAULT NULL COMMENT '注销/撤销时间；非空表示该会话无效',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0 正常 1 删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_refresh_token_id` (`refresh_token_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_membership_id` (`membership_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='refresh token 表（含租户/成员上下文）';

-- ============================================================
-- 2. password reset token（复用 ai-chat-insight）
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_password_reset_token` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `password_reset_token_id` CHAR(32) NOT NULL COMMENT 'password reset token 业务唯一标识（UUID 无横线 32 位）',
  `user_id` CHAR(32) DEFAULT NULL COMMENT '关联 gateway_user.user_id；邮箱不存在用户时可为空（防枚举）',
  `email` VARCHAR(64) NOT NULL COMMENT 'token 绑定邮箱',
  `token_hash` VARCHAR(128) NOT NULL COMMENT 'secureToken hash（避免明文落库）',
  `expires_at` DATETIME NOT NULL COMMENT 'token 过期时间（TTL=15 分钟）',
  `used_at` DATETIME DEFAULT NULL COMMENT 'one-time 使用时间；非空表示已使用',
  `invalidated_at` DATETIME DEFAULT NULL COMMENT '被后续请求作废时间（同邮箱仅最新有效）',
  `is_latest` TINYINT NOT NULL DEFAULT 1 COMMENT '是否最新有效（1=最新）',
  `email_latest_slot` VARCHAR(64) GENERATED ALWAYS AS (CASE WHEN `is_latest` = 1 THEN `email` ELSE NULL END) STORED COMMENT '仅最新行非空，配合 uk 保证同邮箱仅一条 is_latest=1',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0 正常 1 删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_password_reset_token_id` (`password_reset_token_id`),
  UNIQUE KEY `uk_password_reset_latest` (`email_latest_slot`),
  KEY `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='password reset token 表';

-- ============================================================
-- 3. 租户域名（企业自助接入/域名路由）——架构源 DDL
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_tenant_domain` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `tenant_domain_id` CHAR(32) NOT NULL COMMENT '租户域名业务唯一标识',
  `tenant_id` CHAR(32) NOT NULL COMMENT '所属租户ID；逻辑关联 gateway_tenant.tenant_id',
  `domain` VARCHAR(255) NOT NULL COMMENT '域名，如 example.com',
  `domain_type` VARCHAR(16) NOT NULL DEFAULT 'COMPANY' COMMENT '域名类型：COMPANY/PUBLIC/ALIAS',
  `verification_status` VARCHAR(16) NOT NULL DEFAULT 'PENDING' COMMENT '验证状态：PENDING/VERIFIED/FAILED/EXPIRED/REVOKED',
  `join_policy` VARCHAR(16) NOT NULL DEFAULT 'REQUEST' COMMENT '域名加入策略：DISABLED/REQUEST/AUTO_JOIN/SSO_ONLY',
  `is_primary` TINYINT NOT NULL DEFAULT 0 COMMENT '是否主域名：0否 1是',
  `is_public_email_domain` TINYINT NOT NULL DEFAULT 0 COMMENT '是否公共邮箱域名：0否 1是',
  `verified_at` DATETIME DEFAULT NULL COMMENT '验证通过时间',
  `last_checked_at` DATETIME DEFAULT NULL COMMENT '最近一次校验时间',
  `remarks` VARCHAR(512) DEFAULT NULL COMMENT '备注',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_tenant_domain_id` (`tenant_domain_id`),
  UNIQUE KEY `uk_gateway_domain` (`domain`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_verification_status` (`verification_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户可识别域名表';

-- ============================================================
-- 4. 域名验证挑战——架构源 DDL
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_tenant_domain_challenge` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `tenant_domain_challenge_id` CHAR(32) NOT NULL COMMENT '域名验证挑战业务唯一标识',
  `tenant_domain_id` CHAR(32) NOT NULL COMMENT '所属租户域名ID',
  `challenge_type` VARCHAR(16) NOT NULL COMMENT '挑战方式：DNS_TXT/HTTP_FILE/EMAIL',
  `challenge_status` VARCHAR(16) NOT NULL DEFAULT 'PENDING' COMMENT '挑战状态：PENDING/VERIFIED/FAILED/EXPIRED/CANCELLED',
  `challenge_token` VARCHAR(255) NOT NULL COMMENT '挑战令牌',
  `challenge_payload` VARCHAR(1024) DEFAULT NULL COMMENT '挑战附加内容',
  `expires_at` DATETIME NOT NULL COMMENT '挑战过期时间',
  `verified_at` DATETIME DEFAULT NULL COMMENT '挑战通过时间',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_tenant_domain_challenge_id` (`tenant_domain_challenge_id`),
  UNIQUE KEY `uk_gateway_domain_challenge_token` (`challenge_token`),
  KEY `idx_tenant_domain_id` (`tenant_domain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户域名验证挑战表';

-- ============================================================
-- 5. 租户邀请——架构源 DDL
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_invitation` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `invitation_id` CHAR(32) NOT NULL COMMENT '邀请业务唯一标识',
  `tenant_id` CHAR(32) NOT NULL COMMENT '目标租户ID',
  `email` VARCHAR(255) NOT NULL COMMENT '被邀请邮箱',
  `invite_type` VARCHAR(16) NOT NULL DEFAULT 'EMAIL' COMMENT '邀请类型：EMAIL/LINK/BULK_IMPORT',
  `invitation_status` VARCHAR(16) NOT NULL DEFAULT 'PENDING' COMMENT '邀请状态：PENDING/ACCEPTED/EXPIRED/REVOKED',
  `invite_token_hash` VARCHAR(128) NOT NULL COMMENT '邀请 token hash（避免明文落库）',
  `default_role_id` CHAR(32) DEFAULT NULL COMMENT '默认授予角色ID',
  `invited_by_user_id` CHAR(32) DEFAULT NULL COMMENT '发起邀请的用户ID',
  `accepted_by_user_id` CHAR(32) DEFAULT NULL COMMENT '接受邀请的用户ID',
  `message` VARCHAR(512) DEFAULT NULL COMMENT '邀请备注',
  `expires_at` DATETIME NOT NULL COMMENT '邀请过期时间',
  `accepted_at` DATETIME DEFAULT NULL COMMENT '接受时间',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_invitation_id` (`invitation_id`),
  UNIQUE KEY `uk_gateway_invite_token_hash` (`invite_token_hash`),
  KEY `idx_tenant_email_status` (`tenant_id`, `email`, `invitation_status`),
  KEY `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户邀请表';

-- ============================================================
-- 6. 加入租户申请——架构源 DDL
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_join_request` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `join_request_id` CHAR(32) NOT NULL COMMENT '加入申请业务唯一标识',
  `tenant_id` CHAR(32) NOT NULL COMMENT '目标租户ID',
  `user_id` CHAR(32) DEFAULT NULL COMMENT '申请用户ID；申请发起时可能已登录，也可能仅凭邮箱',
  `email` VARCHAR(255) NOT NULL COMMENT '申请邮箱',
  `request_source` VARCHAR(16) NOT NULL DEFAULT 'DOMAIN_DISCOVERY' COMMENT '申请来源：DOMAIN_DISCOVERY/SSO/JOIN_PAGE/ADMIN',
  `request_status` VARCHAR(16) NOT NULL DEFAULT 'PENDING' COMMENT '申请状态：PENDING/APPROVED/REJECTED/CANCELLED',
  `request_reason` VARCHAR(512) DEFAULT NULL COMMENT '申请原因',
  `reviewed_by_user_id` CHAR(32) DEFAULT NULL COMMENT '审批人用户ID',
  `review_note` VARCHAR(512) DEFAULT NULL COMMENT '审批备注',
  `reviewed_at` DATETIME DEFAULT NULL COMMENT '审批时间',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_join_request_id` (`join_request_id`),
  KEY `idx_tenant_email_status` (`tenant_id`, `email`, `request_status`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='加入租户申请表';

-- ============================================================
-- 7. 审计日志——架构源 DDL（P3 起步，粗粒度）
-- ============================================================
CREATE TABLE IF NOT EXISTS `gateway_audit_log` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `audit_log_id` CHAR(32) NOT NULL COMMENT '审计日志业务唯一标识',
  `tenant_id` CHAR(32) DEFAULT NULL COMMENT '租户ID；平台级操作可为空',
  `actor_user_id` CHAR(32) DEFAULT NULL COMMENT '操作者用户ID',
  `actor_membership_id` CHAR(32) DEFAULT NULL COMMENT '操作者成员关系ID',
  `event_type` VARCHAR(64) NOT NULL COMMENT '事件类型；如 TENANT_CREATED/INVITE_SENT/ROLE_GRANTED/SSO_LOGIN',
  `target_type` VARCHAR(64) NOT NULL COMMENT '目标类型；如 TENANT/USER/MEMBERSHIP/IDP_CONFIG/ROLE',
  `target_id` VARCHAR(128) DEFAULT NULL COMMENT '目标业务ID',
  `result_status` VARCHAR(16) NOT NULL DEFAULT 'SUCCESS' COMMENT '结果状态：SUCCESS/FAILED/DENIED',
  `trace_id` VARCHAR(64) DEFAULT NULL COMMENT '链路追踪ID',
  `request_id` VARCHAR(64) DEFAULT NULL COMMENT '请求ID',
  `ip_address` VARCHAR(64) DEFAULT NULL COMMENT '来源 IP',
  `user_agent` VARCHAR(512) DEFAULT NULL COMMENT '来源 User-Agent',
  `before_json` JSON DEFAULT NULL COMMENT '变更前快照',
  `after_json` JSON DEFAULT NULL COMMENT '变更后快照',
  `metadata_json` JSON DEFAULT NULL COMMENT '扩展元数据',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_gateway_audit_log_id` (`audit_log_id`),
  KEY `idx_tenant_event_time` (`tenant_id`, `event_type`, `create_time`),
  KEY `idx_actor_user_id` (`actor_user_id`),
  KEY `idx_trace_id` (`trace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限/租户/SSO/管理操作审计日志表';

-- ============================================================

-- [seed 已剥离] 原 seed 数据移至 db/seed / db/seed-dev（R__ 幂等）；本迁移只留 schema。

package com.unify.iam.identity.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.identity.infra.persistence.mapper.IdpGroupMappingMapper;
import com.unify.iam.identity.infra.persistence.po.IdpGroupMappingPO;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/**
 * IdP 组映射仓储：查某 IdP 配置下的 ACTIVE 白名单映射（优先级升序）。
 */
@Repository
public class IdpGroupMappingRepository {

    private final IdpGroupMappingMapper idpGroupMappingMapper;

    public IdpGroupMappingRepository(IdpGroupMappingMapper idpGroupMappingMapper) {
        this.idpGroupMappingMapper = idpGroupMappingMapper;
    }

    public List<IdpGroupMappingPO> findActiveByConfig(String idpConfigId) {
        return idpGroupMappingMapper.selectList(new LambdaQueryWrapper<IdpGroupMappingPO>()
                .eq(IdpGroupMappingPO::getTenantIdpConfigId, idpConfigId)
                .eq(IdpGroupMappingPO::getMappingStatus, "ACTIVE")
                .orderByAsc(IdpGroupMappingPO::getPriority));
    }

    /** 某 IdP 配置下的全部映射（含 DISABLED，管理面列表用，docs/07 §3.2）。 */
    public List<IdpGroupMappingPO> listByConfig(String idpConfigId) {
        return idpGroupMappingMapper.selectList(new LambdaQueryWrapper<IdpGroupMappingPO>()
                .eq(IdpGroupMappingPO::getTenantIdpConfigId, idpConfigId)
                .orderByAsc(IdpGroupMappingPO::getPriority));
    }

    public Optional<IdpGroupMappingPO> findById(String mappingId) {
        return Optional.ofNullable(idpGroupMappingMapper.selectOne(new LambdaQueryWrapper<IdpGroupMappingPO>()
                .eq(IdpGroupMappingPO::getIdpGroupMappingId, mappingId)));
    }

    public void create(IdpGroupMappingPO po) {
        idpGroupMappingMapper.insert(po);
    }

    public void update(IdpGroupMappingPO po) {
        idpGroupMappingMapper.updateById(po);
    }

    public void logicalDelete(String mappingId) {
        idpGroupMappingMapper.delete(new LambdaQueryWrapper<IdpGroupMappingPO>()
                .eq(IdpGroupMappingPO::getIdpGroupMappingId, mappingId));
    }
}
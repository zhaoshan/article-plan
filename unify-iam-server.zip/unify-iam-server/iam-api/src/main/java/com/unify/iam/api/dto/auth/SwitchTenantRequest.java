package com.unify.iam.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;

/** 切换租户请求：{@code POST /api/v1/auth/switch-tenant}。 */
public record SwitchTenantRequest(
        @NotBlank(message = "membership_id 不能为空") @JsonProperty("membership_id") String membershipId) {
}

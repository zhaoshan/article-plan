# Implementation plan

1. Add scope constants/validation in the admin tenant service or a small local helper, preserving the existing limit clamp and standard `AuthException.badRequest` responses.
2. Extend `TenantRepository#listAll` (or add a scope-aware sibling) with an optional tenant-id predicate while retaining the existing selected columns, ordering, logical-delete behavior, and bounded limit.
3. Bind `scope_type` and `scope_id` in `AdminTenantController#list`, pass the validated scope through the service, and keep application enrichment unchanged.
4. Add focused controller tests covering `PLATFORM/PLATFORM`, `TENANT/<id>`, omitted parameters, lowercase/mixed-case values, invalid tuples, and camelCase field names.
5. Add or extend an integration test with distinct tenants and application links; assert filtered rows, count, empty unknown tenant, permission rejection, and legacy no-parameter behavior.
6. Run the affected module tests, full Maven verification required by project guidance, and inspect the final diff/status.

Risk/rollback point: the repository and controller changes are isolated to tenant listing. If validation or query behavior conflicts with an existing caller, revert only the task files and implementation files while preserving unrelated working-tree content.

## Validation record

- `git diff --check` passes.
- `python3 ./.trellis/scripts/task.py validate .trellis/tasks/11-02-tenant-scope-filtering` passes after both context manifests were curated.
- Maven compile/test execution is blocked by the host JDK (`26.0.2.1`) and the project's Lombok setup: the baseline `iam-common` compile cannot generate the existing `CommonResponse` all-arguments constructor, and continuing with a temporary local constructor workaround exposes the same missing Lombok accessors throughout `iam-identity`, `iam-tenant`, and `iam-app`. The workaround was restored; no unrelated source changes remain.

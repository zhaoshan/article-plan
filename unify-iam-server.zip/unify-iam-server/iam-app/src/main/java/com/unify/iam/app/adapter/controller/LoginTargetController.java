package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.LoginTarget;
import com.unify.iam.app.app.service.LoginTargetService;
import com.unify.iam.app.security.JwtAuth;
import com.unify.iam.app.security.JwtSigner;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

/** 登录 Hub 专用的已认证应用目录与回跳决策。 */
@RestController
@RequestMapping("/api/v1/auth")
public class LoginTargetController {
    private final JwtSigner signer;
    private final LoginTargetService targets;

    public LoginTargetController(JwtSigner signer, LoginTargetService targets) {
        this.signer = signer;
        this.targets = targets;
    }

    @GetMapping("/available-apps")
    public LoginTarget.Catalog applications(@RequestHeader(value = "Authorization", required = false) String authorization) {
        return targets.catalog(JwtAuth.verify(signer, authorization).userId());
    }

    @PostMapping("/resolve-target")
    public LoginTarget.Resolution resolve(@RequestHeader(value = "Authorization", required = false) String authorization,
            @Valid @RequestBody LoginTarget.Request request) {
        return targets.resolve(JwtAuth.verify(signer, authorization), request);
    }
}

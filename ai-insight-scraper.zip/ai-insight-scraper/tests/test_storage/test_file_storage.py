"""file_storage 测试"""

import pytest
from src.storage.file_storage import FileStorage


@pytest.mark.asyncio
class TestFileStorage:
    """FileStorage 测试"""

    async def test_save_and_load(self, temp_dir):
        """保存并加载文件"""
        storage = FileStorage(temp_dir / "output")
        path = await storage.save("hello world", "test.txt")
        content = await storage.load("test.txt")
        assert content == "hello world"
        assert path.endswith("test.txt")

    async def test_save_json(self, temp_dir):
        """保存 JSON 文件"""
        storage = FileStorage(temp_dir / "output")
        await storage.save_json({"key": "值"}, "data.json")
        content = await storage.load("data.json")
        assert "key" in content
        assert "值" in content

    async def test_load_nonexistent_raises(self, temp_dir):
        """加载不存在的文件抛出异常"""
        storage = FileStorage(temp_dir / "output")
        with pytest.raises(FileNotFoundError):
            await storage.load("nope.txt")

    async def test_list_files(self, temp_dir):
        """列出文件"""
        storage = FileStorage(temp_dir / "output")
        await storage.save("a", "1.txt")
        await storage.save("b", "2.txt")
        files = storage.list_files()
        assert len(files) == 2

    async def test_save_creates_parent_dirs(self, temp_dir):
        """自动创建父目录"""
        storage = FileStorage(temp_dir / "output")
        await storage.save("data", "sub/deep/file.txt")
        content = await storage.load("sub/deep/file.txt")
        assert content == "data"

# 会话记录

## 2026-10-27 调查

- 项目：/Users/ramiro.li/root/apps/work/platform-iam-service；分支 feature/v0.10.3-m10w3。起始已有大量并行未提交改动，全部保留。
- 当前根目录缺少 AGENTS.md 和 .trellis/workflow.md，已读取现有 CLAUDE.md 与安全/迁移规则。没有访问其他项目或前端目录。
- 8090 服务健康检查 UP，运行 JAR 位于当前项目 iam-app/target。调查期间其他会话将进程从 29067 更新为 83256，17:19:17 启动成功；本任务未重启服务。
- 源码：switch-tenant 接受 membership_id（成员关系 ID，非 tenant_id），返回新 access/refresh；me 身份来自 Bearer claims；refresh 使用请求体 refresh_token 所绑定 membership；没有 Cookie/HttpSession 恢复租户的应用逻辑。
- 待隔离测试证实：旧 refresh 独立有效并仍绑定原租户，若前端只替换 access 而保留旧 refresh，随后刷新会返回原租户。此行为符合单 membership 凭据语义，不宜通过撤销其他设备会话来掩盖客户端凭据替换错误。

## 完成证据

- 主会话提供前端定位：平台管理员管理无自身 membership 的租户时只是导航管理路由，不调用 switch，侧栏仍按原 Bearer 租户勾选。本任务未访问前端，独立确认后端没有平台管理员 membership 归属豁免，也没有任意 tenant_id 切换接口。
- 8090 健康 UP。7 项只读/无效凭据探测全部符合预期：无 Bearer me=401；snake_case membership_id 无 Bearer=401；membershipId/tenant_id 请求=400；refresh_token 无效=401；refreshToken=400；均无 Set-Cookie。结果留存 runtime-probes.json。
- 新增 SwitchTenantSessionIntegrationTest：每个用例在 Testcontainers MySQL 上新建随机用户/LOCAL identity/三个租户和成员关系，测试事务回滚，使用独立测试密钥。没有写入本地业务库或修改真实用户权限。
- 完整验证登录 A → switch B → me/session-status B → refresh B → me/session-status B → switch C → refresh C → me/session-status C；B 的轮换前 refresh 重放=401。
- 验证 switch 后原 access 仍表示 A，原 refresh 即使配 Bearer B 仍返回 A，新 B refresh 则保持 B。Cookie 与 query 中的 A 不覆盖 B 的 Bearer；仅 cookie 无法认证。
- 验证 is_default 仍为 A，C 为字符串 0，当前 me 为 C；重新密码登录仍进默认 A。这不是隐式服务器缓存恢复。
- 验证 membershipId/tenant_id 错误字段=400，tenant ID 填入 membership_id=403，refreshToken 错误字段=400；响应 token/user 形状与平铺 camelCase me 按实际序列化断言。
- 测试编写阶段补齐 LOCAL identity 测试夹具、修正集合 JSONPath 后，最终命令 `mvn -pl iam-app -am test -Dtest='SwitchTenantSessionIntegrationTest,P3SwitchTenantIntegrationTest,P3RefreshIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false -Dmaven.compiler.proc=full`：BUILD SUCCESS；8 tests、0 failures、0 errors、0 skipped。详细结果留存 validation.log。
- git diff --check 通过，暂存区为空；分支仍 feature/v0.10.3-m10w3。本任务仅新增上述测试及本任务 .trellis 记录，无生产代码改动、迁移、接口扩展、提交/推送/合并、分支/worktree 操作。全部并行改动保留。
- 限制：当前运行服务只做无业务写入探测，成功链路在源码隔离集成环境验证；没有对真实账号、浏览器 cookie 或前端路由做现场端到端验证。运行服务在调查期间被其他会话更新，本任务未部署/重启。

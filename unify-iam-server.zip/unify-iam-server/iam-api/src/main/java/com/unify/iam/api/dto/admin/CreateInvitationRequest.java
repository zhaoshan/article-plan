package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

/** 邀请创建请求（管理面）：邮箱 + 目标租户 + 可选默认角色。 */
public record CreateInvitationRequest(
        @NotBlank(message = "email 不能为空") @Email String email,
        @NotBlank(message = "tenant_id 不能为空") @JsonProperty("tenant_id") String tenantId,
        @JsonProperty("role_id") String roleId) {
}

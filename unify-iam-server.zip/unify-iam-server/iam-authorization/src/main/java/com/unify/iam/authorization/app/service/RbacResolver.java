package com.unify.iam.authorization.app.service;

import com.unify.iam.authorization.app.model.RbacResult;
import com.unify.iam.authorization.infra.persistence.mapper.AuthorizationQueryMapper;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * RBAC 解析：按 membershipId 计算角色与权限点（令牌管线第三步）。
 *
 * <p>每次调用实时查库，不做长缓存——E2E 验收#7（换角色 seed 授权立即变化）依赖此行为。
 */
@Service
public class RbacResolver {

    private final AuthorizationQueryMapper authorizationQueryMapper;

    public RbacResolver(AuthorizationQueryMapper authorizationQueryMapper) {
        this.authorizationQueryMapper = authorizationQueryMapper;
    }

    /**
     * 解析成员的 {roles, permissions}（有序、去重、状态过滤）。
     */
    public RbacResult resolve(String membershipId) {
        List<String> roles = authorizationQueryMapper.selectRoleCodesByMembership(membershipId);
        List<String> permissions = authorizationQueryMapper.selectPermissionCodesByMembership(membershipId);
        return RbacResult.of(roles, permissions);
    }
}

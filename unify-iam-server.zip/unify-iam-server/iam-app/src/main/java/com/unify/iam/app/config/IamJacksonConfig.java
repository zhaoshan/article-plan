package com.unify.iam.app.config;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 全局时间序列化约定（2026-11-03）：MySQL DATETIME 存 **UTC 墙钟**（容器默认时区），
 * LocalDateTime 原样序列化会得到无时区标记的字符串——前端按浏览器本地时区解析会差 8 小时。
 *
 * <p>约定：库中 UTC → 输出带 Z 的 ISO-8601（{@code 2026-10-08T08:50:32Z}）——前端
 * {@code new Date()}/dayjs 见 Z 自动按 UTC 解析并转本地显示，零特殊处理。
 * 仅影响序列化输出，不影响存储与 DB 侧 NOW() 比较；LocalDate（无时分秒）与 Instant
 * （Boot 默认即带 Z）不受影响。
 */
@Configuration
public class IamJacksonConfig {

    private static final DateTimeFormatter UTC_ISO = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer utcLocalDateTimeCustomizer() {
        return builder -> builder.serializerByType(LocalDateTime.class, new JsonSerializer<LocalDateTime>() {
            @Override
            public void serialize(LocalDateTime value, JsonGenerator gen, SerializerProvider serializers)
                    throws IOException {
                gen.writeString(UTC_ISO.format(value));
            }
        });
    }
}

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.app.mail.EmailTool;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

/**
 * 密码重置邮件（docs/08 §2.1②）集成测试：forgot 按 reset-password-email.html 模板发信（LOCAL 账号），
 * SSO-only 账号不发；邮件里的 reset_url token 可直接完成重置闭环。
 */
class PasswordResetMailIntegrationTest extends IamIntegrationTestBase {

    private static final Pattern RESET_URL = Pattern.compile("/reset-password\\?token=([A-Za-z0-9_\\-]+)");

    @MockitoBean
    private EmailTool emailTool;

    @Test
    void forgotSendsResetEmailWithUsableToken() throws Exception {
        // 专用用户（不动共享库 admin 密码）——需有可用成员关系才能登录（加入 tenant-org-a）
        String uid = unwrapData(mockMvc.perform(post("/api/v1/admin/users")
                        .header("Authorization", "Bearer " + login("admin", "admin123"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"rsuser\",\"email\":\"rsuser@unify.local\",\"password\":\"" + b64("RsOld123!") + "\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString())
                .get("user_id").toString();
        mockMvc.perform(post("/api/v1/admin/members")
                        .header("Authorization", "Bearer " + login("admin", "admin123"))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"tenant_id\":\"tenant-org-a\",\"user_id\":\"" + uid + "\",\"role_ids\":[]}"))
                .andExpect(status().isOk());
        jdbcTemplate.update("UPDATE gateway_user SET must_change_password=0 WHERE username='rsuser'");
        jdbcTemplate.update("UPDATE gateway_membership SET is_default=1 WHERE user_id=? AND tenant_id='tenant-org-a'", uid);

        mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"rsuser@unify.local\"}"))
                .andExpect(status().isOk());

        ArgumentCaptor<String> html = ArgumentCaptor.forClass(String.class);
        verify(emailTool).send(eq("rsuser@unify.local"), anyString(), html.capture());
        String body = html.getValue();
        assertThat(body).contains("/reset-password?token=").contains("rsuser");

        // 邮件里的 reset_url 带明文 token，可直接走重置闭环（改密 → 旧密码失效）
        Matcher m = RESET_URL.matcher(body);
        assertThat(m.find()).isTrue();
        mockMvc.perform(post("/api/v1/auth/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"token\":\"" + m.group(1) + "\",\"new_password\":\"" + b64("ResetNew123!") + "\"}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"rsuser\",\"password\":\"" + b64("RsOld123!") + "\"}"))
                .andExpect(status().isUnauthorized()); // 旧密码已失效（改密吊销 refresh）
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"rsuser\",\"password\":\"" + b64("ResetNew123!") + "\"}"))
                .andExpect(status().isOk());
    }

    /** P0-08：SMTP 已配置（真实投递模式）时，forgot 响应不得携带 token——token 只经邮件交付。 */
    @Test
    void forgotDoesNotExposeTokenWhenMailConfigured() throws Exception {
        Mockito.when(emailTool.isMailConfigured()).thenReturn(true);
        mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"admin@unify.local\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("SENT"))
                .andExpect(jsonPath("$.data.token").doesNotExist());
        // 邮件仍真实投递（LOCAL 身份的 admin 会收到重置邮件）
        verify(emailTool).send(eq("admin@unify.local"), anyString(), contains("/reset-password?token="));
    }

    /** P0-08：已知/未知邮箱返回同形态 {"status":"SENT"}（原 detail 形态差异构成邮箱枚举辅助，已消除）。 */
    @Test
    void forgotReturnsSameShapeForUnknownEmail() throws Exception {
        String body = mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"no-such-user@unify.local\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("SENT"))
                .andExpect(jsonPath("$.data.token").doesNotExist())
                .andReturn().getResponse().getContentAsString();
        // 与已知邮箱（日志模式带 token）对比：未知邮箱绝不出现 token
        assertThat(body).doesNotContain("token");
    }

    /** P0-08：同一邮箱 forgot 60s 冷却，重复提交 400 限流（用已知 LOCAL 邮箱——未知邮箱不落令牌、无冷却对象）。 */
    @Test
    void forgotEnforcesPerEmailCooldown() throws Exception {
        String email = "viewer@unify.local"; // seed 只读用户：本类其它用例均不碰，避免共享 60s 窗口
        mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\"}"))
                .andExpect(status().isOk());
        mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"" + email + "\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IAM-AUTH-011"));
    }

    private String login(String username, String password) throws Exception {
        org.springframework.test.web.servlet.MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk()).andReturn();
        return unwrapData(res.getResponse().getContentAsString()).get("access_token").toString();
    }

    @Test
    void forgotSkipsEmailForSsoOnlyAccount() throws Exception {
        // SSO-only 用户：有 OIDC 身份、无 LOCAL 身份
        jdbcTemplate.update("""
                INSERT IGNORE INTO gateway_user
                  (user_id, username, primary_email, password_hash, full_name, display_name,
                   default_tenant_id, user_status, registration_source, delete_flag, create_by, update_by)
                VALUES ('u-rs-sso-00000000000000000001', 'rs_sso@unify.local', 'rs_sso@unify.local',
                        'x', 'rs_sso', 'rs_sso', NULL, 'ACTIVE', 'SSO', 0, 'system', 'system')
                """);
        jdbcTemplate.update("""
                INSERT IGNORE INTO gateway_user_identity
                  (user_identity_id, user_id, provider_type, provider_key, issuer, subject,
                   login_name, identity_status, delete_flag, create_by, update_by)
                VALUES ('id-rs-sso-00000000000000000001', 'u-rs-sso-00000000000000000001', 'OIDC', 'keycloak',
                        'https://idp.test/iss', 'sub-rs-sso', 'rs_sso@unify.local', 'ACTIVE', 0, 'system', 'system')
                """);
        mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"rs_sso@unify.local\"}"))
                .andExpect(status().isOk());
        // SSO-only 不发重置邮件（无密码可重置），且响应不暴露账号类型（防枚举统一文案）
        Mockito.verify(emailTool, never()).send(eq("rs_sso@unify.local"), anyString(), anyString());
        // 未知邮箱同样静默
        mockMvc.perform(post("/api/v1/auth/forgot-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"nobody@unify.local\"}"))
                .andExpect(status().isOk());
        verify(emailTool, never()).send(contains("nobody@unify.local"), anyString(), anyString());
    }
}

package com.unify.iam.app.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.app.infra.persistence.mapper.AuditLogMapper;
import com.unify.iam.app.infra.persistence.po.AuditLogPO;
import java.util.List;
import org.springframework.stereotype.Repository;

/** 审计日志仓储。 */
@Repository
public class AuditLogRepository {

    /** 单页查询上限兜底（防大 size）。 */
    private static final int MAX_SIZE = 200;

    private final AuditLogMapper auditLogMapper;

    public AuditLogRepository(AuditLogMapper auditLogMapper) {
        this.auditLogMapper = auditLogMapper;
    }

    public void insert(AuditLogPO po) {
        auditLogMapper.insert(po);
    }

    /** 审计分页查询（docs/05 Audit 页）：按租户/事件/操作人过滤，按时间倒序，page 从 1 起。 */
    public List<AuditLogPO> list(String tenantId, String eventType, String actorUserId, int page, int size) {
        LambdaQueryWrapper<AuditLogPO> wrapper = buildFilter(tenantId, eventType, actorUserId);
        int safeSize = Math.min(Math.max(size, 1), MAX_SIZE);
        int offset = (Math.max(page, 1) - 1) * safeSize;
        wrapper.orderByDesc(AuditLogPO::getId)
                .last("LIMIT " + safeSize + " OFFSET " + offset);
        return auditLogMapper.selectList(wrapper);
    }

    /** 匹配记录总数（分页 total）。 */
    public long count(String tenantId, String eventType, String actorUserId) {
        return auditLogMapper.selectCount(buildFilter(tenantId, eventType, actorUserId));
    }

    private LambdaQueryWrapper<AuditLogPO> buildFilter(String tenantId, String eventType, String actorUserId) {
        LambdaQueryWrapper<AuditLogPO> wrapper = new LambdaQueryWrapper<>();
        if (tenantId != null && !tenantId.isBlank()) {
            wrapper.eq(AuditLogPO::getTenantId, tenantId.trim());
        }
        if (eventType != null && !eventType.isBlank()) {
            wrapper.eq(AuditLogPO::getEventType, eventType.trim());
        }
        if (actorUserId != null && !actorUserId.isBlank()) {
            wrapper.eq(AuditLogPO::getActorUserId, actorUserId.trim());
        }
        return wrapper;
    }
}

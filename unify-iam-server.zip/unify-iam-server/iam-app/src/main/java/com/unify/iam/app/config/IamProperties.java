package com.unify.iam.app.config;

import com.unify.iam.api.constant.ClaimConstants;
import java.util.List;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * IAM 应用配置（前缀 {@code iam}）。
 */
@Data
@ConfigurationProperties(prefix = "iam")
public class IamProperties {

    /** JWT 签发配置 */
    private Jwt jwt = new Jwt();

    /** 是否启用 dev-token 端点（2026-11-09 P0-07：默认关——生产误配置即拒；local/test 显式开启） */
    private boolean devTokenEnabled = false;

    /** P1-02 登录暴力破解防护：账号/IP 双维度失败计数 + 冷却锁定 */
    private LoginRateLimit loginRateLimit = new LoginRateLimit();

    /** 可选 Redis 中间件（P1-02 限流共享计数等多副本场景）：默认 enabled=false 不装配任何 Redis Bean */
    private Redis redis = new Redis();

    @lombok.Data
    public static class Redis {
        /** 总开关：false = 登录限流走进程内实现（本地/单实例默认） */
        private boolean enabled = false;
        /** 环境前缀（key 第一段，防多环境共享实例串数据），如 uat/prod */
        private String env = "uat";
        private String mode = "standalone";
        /** 命令超时 */
        private java.time.Duration timeout = java.time.Duration.ofSeconds(2);
        private boolean ssl = false;
        private final Standalone standalone = new Standalone();
        private final Cluster cluster = new Cluster();
        private final Pool pool = new Pool();
    }

    @lombok.Data
    public static class Standalone {
        private String host = "localhost";
        private int port = 6379;
        private int database = 0;
        /** ACL 用户名，可选 */
        private String username = "";
        /** 推荐 ENC() jasypt 密文，勿落明文 */
        private String password = "";
    }

    @lombok.Data
    public static class Cluster {
        /** 节点列表，形如 host:port */
        private java.util.List<String> nodes = new java.util.ArrayList<>();
        private int maxRedirects = 3;
        private String username = "";
        private String password = "";
    }

    @lombok.Data
    public static class Pool {
        private int maxActive = 8;
        private int maxIdle = 8;
        private int minIdle = 1;
    }

    @lombok.Data
    public static class LoginRateLimit {
        /** 总开关 */
        private boolean enabled = true;
        /** 账号维度：连续失败达该值即锁定 */
        private int maxFailures = 5;
        /** 账号维度：锁定时长（秒） */
        private long lockSeconds = 600;
        /** IP 维度：滑动窗口内失败达该值即冷却 */
        private int ipMaxFailures = 20;
        /** IP 维度：滑动窗口（秒） */
        private long ipWindowSeconds = 600;
        /** IP 维度：冷却时长（秒） */
        private long ipLockSeconds = 900;
        /** 是否信任 X-Forwarded-For 取客户端 IP（仅网关场景开启——直接信任会被伪造绕过） */
        private boolean trustXff = false;
    }

    /** E2E-2 OIDC SSO 配置 */
    private Oidc oidc = new Oidc();

    /** 版本 feed 配置（方案 c 即时吊销，docs/07 §8.3；parlant doc11 附录 B） */
    private Versions versions = new Versions();

    /** 邀请邮件统一配置（docs/08 §3/§15；Owner/Member 同组，不区分；SMTP 未配置 → 日志模式） */
    private Mail mail = new Mail();

    /** G2 增强：app_code → 应用主页地址（环境级兜底；iam_application.homepage_url 优先） */
    private java.util.Map<String, String> appHomepages = new java.util.LinkedHashMap<>();

    /** 应用允许的额外回跳来源；同时必须命中 OIDC 全局白名单，默认仅允许应用主页来源。 */
    private java.util.Map<String, List<String>> appReturnOrigins = new java.util.LinkedHashMap<>();

    @Data
    public static class Mail {
        /** 邀请链接 hub 基址（{{invitation_link}} = base + /invitations/accept?token=..&app=..） */
        private String invitationLinkBaseUrl = "http://localhost:5173";
        /**
         * 严格投递模式开关（docs/08 §7，全邀请邮件统一）：false（默认/dev）= 日志兜底允许；
         * true（生产）= 创建前闸门校验（{@link com.unify.iam.app.mail.InvitationDeliveryGuard}），
         * 投递失败抛异常整事务回滚。不切换实现，只切换同一条链路的严格度。
         */
        private boolean deliveryEnabled;
        /** 邀请链接隐含应用参数（默认 imorph，db/seed/R__app_imorph.sql 注册） */
        private String invitationDefaultApp = "imorph";
        /** Owner 邀请邮件主题模板（{{变量}} 同正文） */
        private String ownerInvitationSubject = "You're invited to manage {{tenant_name}} on iMorph";
        /** Member/Admin 邀请邮件主题模板 */
        private String memberInvitationSubject = "You've been invited to join {{tenant_name}} on iMorph";
        /** Owner 邀请邮件正文模板（classpath HTML，含 {{#initial_password}} 条件块） */
        private String ownerInvitationTemplate = "templates/tenant-owner-invitation-email.html";
        /** Member/Admin 邀请邮件正文模板（classpath HTML） */
        private String memberInvitationTemplate = "templates/tenant-member-admin-invitation-email.html";
        /** 密码重置邮件主题模板（docs/08 §2.1③ 流程） */
        private String passwordResetSubject = "Reset your password for iMorph";
        /** 密码重置邮件正文模板（classpath HTML，变量 {{Full_Name}}/{{reset_url}}） */
        private String passwordResetTemplate = "templates/reset-password-email.html";
        /** 注册验证码邮件主题模板 */
        private String emailVerificationSubject = "Verify your email for iMorph";
        /** 注册验证码邮件正文模板（classpath HTML，变量 {{Full_Name}}/{{verification_code}}） */
        private String emailVerificationTemplate = "templates/email-verification-email.html";
    }
    /** 平台企业租户开通策略；不由租户表单接收应用或租户 code。 */
    private EnterpriseTenantProvisioning enterpriseTenantProvisioning = new EnterpriseTenantProvisioning();

    @Data
    public static class Jwt {
        /** kid（E2E-1 固定，不轮换） */
        private String kid = ClaimConstants.DEFAULT_KID;
        /** issuer */
        private String issuer = ClaimConstants.DEFAULT_ISSUER;
        /** audiences 白名单（多应用接入，docs/user-manual 03）：签发 aud = 租户启用应用 ∩ 该列表；无应用记录租户回落全量 */
        private List<String> audiences = List.of(ClaimConstants.DEFAULT_AUDIENCE);
        /** 令牌有效期（秒），默认 2h */
        private long ttlSeconds = ClaimConstants.DEFAULT_TTL_SECONDS;
        /** refresh token 有效期（天），默认 30 */
        private long refreshTtlDays = 30;
        /** RSA 私钥持久化路径（PKCS#8 PEM；首启生成，重启不换钥） */
        private String privateKeyPath = "./keys/rsa-private.pem";
    }

    @Data
    public static class Versions {
        /** 版本 feed 服务间鉴权共享令牌（parlant 侧 IAM_VERSIONS_TOKEN 对齐；空 → 端点 403 禁用） */
        private String serviceToken = "";
        /** 增量 feed 单次最大返回条数（游标分页） */
        private int feedLimit = 1000;
    }

    @Data
    public static class Oidc {
        /** OIDC 回调地址（在本服务上的 redirect_uri；浏览器跳转 IdP 后回跳本端点） */
        private String redirectUri = "http://localhost:8090/api/v1/auth/oidc/callback";
        /** 登录成功回跳前端的地址（dev：携带 ?access_token=） */
        private String frontendRedirect = "http://localhost:5173/login";
        /** 允许的 ID Token 签名算法（白名单） */
        private String allowedAlgorithms = "RS256,ES256";
        /** hub 回跳 return_to 白名单（hop-2 防 open redirect + token 外泄；新业务源在此加，hub 前端零改动） */
        private List<String> allowedReturnOrigins = List.of("http://localhost:5173");
    }



    @Data
    public static class EnterpriseTenantProvisioning {
        /** 新企业租户固定开通的业务应用；必须全部是 ACTIVE 且仅含 TENANT 作用域模板。 */
        private List<String> defaultAppCodes = List.of("imorph");
    }
}

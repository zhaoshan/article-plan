package com.unify.iam.app.support;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSender;

/** Test-only SMTP substitute used by integration tests; it never opens a network connection. */
@TestConfiguration(proxyBeanMethods = false)
public class MemberInvitationMailTestConfiguration {

    @Bean
    @ConditionalOnMissingBean(JavaMailSender.class)
    MemberInvitationTestMailSender memberInvitationTestMailSender() {
        return new MemberInvitationTestMailSender();
    }
}

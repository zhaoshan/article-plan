# Technical design

## Change boundary

The behavior gap is between the controller contract (`tenant_id` required) and the requested role-aligned
scope contract. The behavior lives in the member controller, query service, and SQL mapper; authorization
must remain in the service layer before data access. Expected code changes are limited to:

- `iam-app/.../AdminMemberController.java`: bind `scope_type`/`scope_id` and retain existing filters.
- `iam-app/.../TenantMemberQueryService.java`: normalize/validate scope, authorize platform vs tenant,
  and orchestrate one or many tenant queries while preserving projection and aggregate fields.
- `iam-app/.../TenantMemberQueryMapper.java`: support an optional tenant predicate/global query with all
  existing filters applied before ordering and limit.
- Relevant controller/integration tests and the member API documentation/spec if the executable contract is
  currently documented there.

Explicitly out of scope: frontend changes, write endpoints, role permissions, user-directory behavior,
new pagination, or schema changes.

## Scope contract

| scope_type | scope_id | authorization | data |
| --- | --- | --- | --- |
| `PLATFORM` | `PLATFORM` | `TenantScopeGuard.assertPlatformAdmin` | all non-deleted memberships across tenants |
| `TENANT` | concrete tenant ID | `TenantScopeGuard.assertTenantScope` | memberships whose tenant ID equals target |

Both fields are required when either is present. Values are case-sensitive. The service must not infer
PLATFORM from a missing/invalid tuple.

## Query and aggregation

The mapper receives an optional tenant ID. A null tenant ID omits the tenant predicate, while keyword and
owner-candidate predicates remain in SQL before stable `id ASC` ordering and the bounded limit. Count uses the
same predicate set. For tenant scope, the existing tenant owner and tenant type are loaded once. For platform
scope, the service loads the visible tenant metadata needed for per-row owner eligibility and projection, then
projects members in one batch; response `count` is returned-row count and `total` is pre-limit matched count.
`tenant_type` is omitted for a multi-tenant result (or represented only if the existing envelope requires a
single value); each member retains its own `tenant_id`.

## Compatibility

The old `tenant_id` parameter is explicitly rejected, including when mixed with new fields. No compatibility mapping or implicit PLATFORM default exists. Require exact uppercase scope type and PLATFORM id. The canonical status filter is `membership_status=ACTIVE,PENDING` (comma separated; supported values ACTIVE, PENDING, SUSPENDED); reject `status` aliases, blank values and malformed lists. Every row includes tenant_id, tenant_name and tenant_type; top-level singleton tenant fields are omitted in PLATFORM scope.

## Authorization order

The interceptor continues to enforce `iam:member:read`. The service validates the tuple, then performs the
platform/tenant scope guard, then queries data. Tenant existence checks must not precede authorization in a way
that leaks whether a foreign tenant exists. The global path must require a real platform membership role via
`TenantScopeGuard`, not JWT role names alone. In the global path, `owner_candidates` compares each row to its own tenant owner, never to one shared owner ID.

# 用户启停 PUT pending 排查计划

1. 阅读本项目规则、检查当前分支和既有未提交内容。
2. 沿 Controller → Service → Repository → 审计，结合运行线程、MySQL 事务/锁及实际 HTTP 请求定位阻塞。
3. 依据证据实施必要的最小修复；在隔离数据库验证状态更新、权限、错误响应与事务。
4. 保存脱敏证据、验证结果和未提交交接记录。

## 范围与规则

- 仅当前项目主工作区；不访问其他 Platform IAM 项目。
- AGENTS.md 和 .trellis/workflow.md 均不存在，已读取 CLAUDE.md 和 .claude/rules；沿用现有 .trellis/tasks 计划、实施、验证、会话记录流程。未发现非提交操作确认门禁。
- 保留原有任务和 API 文档的未提交内容。不得暂存、提交、合并、推送、切换/重置分支或操作 worktree。
- 凭证仅在内存中使用，禁止输出或写入任务日志。

## 完成情况

- 四步完成。真实 PUT pending 已重现，JFR 捕获嵌套 ZIP EOF、校验器初始化失败及日志类加载失败；进程使用的 target JAR 在运行期间被 Maven package 覆盖。
- 重启当前项目既有 launchctl 服务后，8090 与 5174 的真实禁用/启用均 HTTP 200，持久化读回正确，目标恢复 ACTIVE。
- 20 项现有回归通过；没有修改生产源码、配置或数据库结构。证据、判断边界和后续构建运行约束见 investigation.md。

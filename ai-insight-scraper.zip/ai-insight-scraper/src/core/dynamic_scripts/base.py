"""动态脚本协议 — 所有动态爬取脚本必须实现此抽象基类"""

from abc import ABC, abstractmethod
from playwright.async_api import BrowserContext


class DynamicScript(ABC):
    """
    动态页面爬取脚本抽象基类。

    每个实现类负责一种特定类型的动态页面交互
    （如 FAQ 分类展开、滚动懒加载等），只做链接提取，不管理浏览器或文件读写。

    协议方法签名：
        async def execute(
            self,
            context: BrowserContext,
            parent_link: str,
            entry_url: str,
        ) -> dict
    """

    @abstractmethod
    async def execute(
        self,
        context: BrowserContext,
        parent_link: str,
        entry_url: str,
    ) -> dict:
        """
        执行动态爬取。

        Args:
            context: Playwright BrowserContext（由编排器注入，已配置反检测参数）
            parent_link: 动态链接在静态树中的父链接（用于日志/上下文）
            entry_url: 脚本实际打开并交互的入口 URL

        Returns:
            dict:
                discovered_links: list[str] — 爬取到的所有链接（未过滤）
                stats: dict — 统计信息（如 total_categories, total_buttons）
        """
        ...

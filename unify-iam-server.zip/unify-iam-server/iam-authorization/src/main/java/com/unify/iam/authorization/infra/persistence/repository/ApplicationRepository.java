package com.unify.iam.authorization.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.unify.iam.authorization.infra.persistence.mapper.ApplicationMapper;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import java.util.Collection;
import java.util.List;
import org.springframework.stereotype.Repository;

/** 应用注册仓储（docs/06 §2.2：租户按启用应用查模板）。 */
@Repository
public class ApplicationRepository {

    private final ApplicationMapper applicationMapper;

    public ApplicationRepository(ApplicationMapper applicationMapper) {
        this.applicationMapper = applicationMapper;
    }

    /** 按 app_code 集查 ACTIVE 应用。 */
    public List<ApplicationPO> findActiveByCodes(Collection<String> codes) {
        if (codes == null || codes.isEmpty()) {
            return List.of();
        }
        return applicationMapper.selectList(new LambdaQueryWrapper<ApplicationPO>()
                .in(ApplicationPO::getAppCode, codes)
                .eq(ApplicationPO::getAppStatus, "ACTIVE"));
    }

    /** 全部 ACTIVE 应用（管理台建租户表单的应用目录，docs/05 §7.3）。 */
    public List<ApplicationPO> listActive() {
        return applicationMapper.selectList(new LambdaQueryWrapper<ApplicationPO>()
                .eq(ApplicationPO::getAppStatus, "ACTIVE")
                .orderByAsc(ApplicationPO::getId));
    }
}

package com.unify.iam.app.security;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.model.AuthorizationContext;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.common.exception.AuthException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * 管理面鉴权拦截器（docs/04 §3.1）：校验 `/api/v1/admin/**` 的 Bearer 令牌 + 所需 {@code iam:*} 权限。
 *
 * <p>复用 {@link JwtSigner#verify}（与 /me 同款验签）；校验通过后将 claims/上下文写入 request attribute，
 * 供 controller 读取。无/坏 token → 401；有 token 但缺权限点 → 403。
 *
 * <p>2026-11-09 方案 c 闭环：签发时 claims.ver = membership.token_version；任何角色/权限/成员变更
 * bump 版本。拦截器比对「token ver vs 库内当前 ver」——落后即 401 {@code IAM-AUTH-015 TOKEN_STALE}，
 * 前端 client.ts 的「401 → 静默 refresh → 原地重试」链路零改动接管（refresh 重解析 RBAC 追平）。
 * 仅覆盖 /admin/**（拦截器注册范围）；/auth/refresh 等纠偏端点天然不在此列。成员关系已删（孤儿
 * 清理等）同样按 stale 拒绝。
 */
@Component
public class ManagementAuthorizationInterceptor implements HandlerInterceptor {

    public static final String AUTH_CLAIMS_ATTR = "iam.claims";
    public static final String AUTH_CONTEXT_ATTR = "iam.authContext";

    private final JwtSigner jwtSigner;
    private final org.springframework.beans.factory.ObjectProvider<
            com.unify.iam.tenant.infra.persistence.repository.MembershipRepository> membershipRepositoryProvider;

    public ManagementAuthorizationInterceptor(JwtSigner jwtSigner,
            org.springframework.beans.factory.ObjectProvider<
                    com.unify.iam.tenant.infra.persistence.repository.MembershipRepository> membershipRepositoryProvider) {
        this.jwtSigner = jwtSigner;
        this.membershipRepositoryProvider = membershipRepositoryProvider;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (!(handler instanceof HandlerMethod)) {
            return true; // 静态资源等，放行
        }
        JwtClaims claims = verify(request.getHeader("Authorization"));
        assertVersionFresh(claims);
        request.setAttribute(AUTH_CLAIMS_ATTR, claims);
        request.setAttribute(AUTH_CONTEXT_ATTR, toContext(claims));

        RequirePermission rp = ((HandlerMethod) handler).getMethodAnnotation(RequirePermission.class);
        if (rp != null && !claims.permissions().contains(rp.value())) {
            throw AuthException.forbidden(ErrorCode.PERMISSION_DENIED_GENERIC, rp.value());
        }
        return true;
    }

    /** ver 比对：claims.ver 落后库内当前版本（或成员关系已删）→ 401 TOKEN_STALE（前端刷新追平）。
     *  ObjectProvider：@WebMvcTest 切片未装配仓储时跳过本检查（生产全上下文恒存在）。 */
    private void assertVersionFresh(JwtClaims claims) {
        var repository = membershipRepositoryProvider.getIfAvailable();
        if (repository == null) {
            return;
        }
        Integer current = repository.findById(claims.membershipId().trim())
                .map(com.unify.iam.tenant.infra.persistence.po.MembershipPO::getTokenVersion)
                .orElse(null);
        if (current == null || claims.ver() < current) {
            throw AuthException.unauthorized(ErrorCode.TOKEN_STALE);
        }
    }

    private JwtClaims verify(String authorization) {
        String token = extractBearer(authorization);
        if (token == null) {
            throw AuthException.unauthorized(ErrorCode.BEARER_REQUIRED);
        }
        return jwtSigner.verify(token);
    }

    private AuthorizationContext toContext(JwtClaims claims) {
        return new AuthorizationContext(claims.userId(), claims.tenantId(), claims.membershipId(),
                claims.roles(), claims.permissions(), claims.attrs());
    }

    private String extractBearer(String authorization) {
        if (authorization == null || !authorization.regionMatches(true, 0, "bearer ", 0, 7)) {
            return null;
        }
        return authorization.substring(7).trim();
    }
}
# 租户切换服务端独立核验

1. 读取当前项目约束、确认运行服务、工作区和源码实际契约。
2. 用既有 Testcontainers + MockMvc 集成设施，事务内创建独立用户和 A/B/C 三个租户，验证登录 A → 切 B → me B → refresh → me B → 切 C。
3. 覆盖旧 access/refresh、cookie、默认 membership 与当前 membership 的区别及 snake_case/camelCase/信封和目标 ID 误用。
4. 如发现服务端缺陷，做最小修复并聚焦回归；否则记录可复核证据和前端契约，不新增无关接口/迁移。

本轮用户已授权立即修复。AGENTS.md 和 .trellis/workflow.md 在当前仓库不存在，遵守现有 CLAUDE.md 与 .claude/rules。全部任务记录放在本目录；不创建虚构确认门禁，不执行 Git 写入操作。

## 完成

4 步完成。未发现本次会话切换服务端缺陷，未修改生产代码/鉴权/接口/数据库迁移。新增 3 个隔离回归用例，与现有切换/刷新测试合计 8 个全部通过；7 项运行服务 HTTP 探测符合预期；git diff --check 通过。交接见 contract.md，运行探测见 runtime-probes.json，完整验证见 validation.log。

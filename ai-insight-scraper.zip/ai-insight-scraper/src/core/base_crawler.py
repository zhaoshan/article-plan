"""BaseCrawler — Playwright 浏览器管理基类

提供 TreeCrawler 和 DynamicCrawler 共用的：
  - 浏览器启动与上下文创建（_setup_browser_context）
  - 浏览器关闭（_teardown_browser）
  - 通用常量（USER_AGENT、viewport 等）
"""

import logging

from playwright.async_api import Browser, BrowserContext

from src.utils.chrome_utils import find_chrome_path, USER_AGENT

logger = logging.getLogger(__name__)

# 默认视口大小
DEFAULT_VIEWPORT = {"width": 1920, "height": 1080}

# 浏览器启动参数
BROWSER_LAUNCH_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-features=VizDisplayCompositor",
    "--disable-dev-shm-usage",
    "--no-sandbox",
]


class BaseCrawler:
    """爬虫基类，封装 Playwright 浏览器生命周期管理。

    子类需要设置 self.headless（bool）和 self._browser（Browser | None）。
    """

    headless: bool
    _browser: Browser | None = None

    # ── 浏览器管理 ──────────────────────────────────────

    async def _setup_browser_context(self, playwright) -> BrowserContext:
        """创建浏览器实例和上下文。

        优先使用本地 Chrome，未找到则使用 Playwright 自带 Chromium。

        Args:
            playwright: async_playwright() 上下文管理器返回的 Playwright 实例

        Returns:
            BrowserContext: 已配置 viewport + user_agent 的浏览器上下文
        """
        chrome_path = find_chrome_path()
        if chrome_path:
            logger.info(f"使用本地 Chrome: {chrome_path}")
            self._browser = await playwright.chromium.launch(
                executable_path=chrome_path,
                headless=self.headless,
                args=BROWSER_LAUNCH_ARGS,
            )
        else:
            logger.info("使用 Playwright 自带 Chromium")
            self._browser = await playwright.chromium.launch(
                headless=self.headless,
                args=BROWSER_LAUNCH_ARGS,
            )

        context = await self._browser.new_context(
            viewport=DEFAULT_VIEWPORT,
            user_agent=USER_AGENT,
        )
        return context

    async def _teardown_browser(self, context: BrowserContext) -> None:
        """安全关闭浏览器上下文和实例。

        Args:
            context: 浏览器上下文（来自 _setup_browser_context 的返回值）
        """
        try:
            await context.close()
        except Exception:
            pass
        if self._browser:
            try:
                await self._browser.close()
            except Exception:
                pass

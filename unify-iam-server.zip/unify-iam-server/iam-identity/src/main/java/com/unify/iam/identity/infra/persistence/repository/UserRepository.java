package com.unify.iam.identity.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.unify.iam.identity.infra.persistence.mapper.UserMapper;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/**
 * 用户仓储。读取时对 CHAR(32) 业务键做 trim，避免 PAD_CHAR_TO_FULL_LENGTH 等场景的尾随空格。
 */
@Repository
public class UserRepository {

    private final UserMapper userMapper;

    public UserRepository(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    /** 按登录名（唯一）查用户；逻辑删除已由 @TableLogic 自动过滤。 */
    public Optional<UserPO> findByUsername(String username) {
        return Optional.ofNullable(userMapper.selectOne(new LambdaQueryWrapper<UserPO>()
                .eq(UserPO::getUsername, username)))
                .map(this::trimBizKeys);
    }

    /** 按用户业务 ID 查用户。 */
    public Optional<UserPO> findByUserId(String userId) {
        return Optional.ofNullable(userMapper.selectOne(new LambdaQueryWrapper<UserPO>()
                .eq(UserPO::getUserId, userId)))
                .map(this::trimBizKeys);
    }

    /** 按主邮箱查用户（找回/邀请用，小写匹配）。 */
    public Optional<UserPO> findByPrimaryEmail(String email) {
        return Optional.ofNullable(userMapper.selectOne(new LambdaQueryWrapper<UserPO>()
                        .eq(UserPO::getPrimaryEmail, email == null ? null : email.trim().toLowerCase())))
                .map(this::trimBizKeys);
    }

    /** 新建用户（JIT 用）；username 唯一键冲突视为已存在（幂等）。 */
    public boolean create(UserPO po) {
        try {
            return userMapper.insert(po) > 0;
        } catch (org.springframework.dao.DuplicateKeyException e) {
            return false;
        }
    }

    /** 更新默认租户入口（JIT 建成员后写回）。 */
    public void updateDefaultTenant(String userId, String tenantId) {
        userMapper.update(null, new LambdaUpdateWrapper<UserPO>()
                .eq(UserPO::getUserId, userId)
                .set(UserPO::getDefaultTenantId, tenantId));
    }

    /** 管理端用户查询：只取非敏感字段（不含密码哈希），按 id 升序，限 100 条。 */
    public List<UserPO> search(int limit) {
        return userMapper.selectList(new LambdaQueryWrapper<UserPO>()
                        .select(UserPO::getUserId, UserPO::getUsername, UserPO::getPrimaryEmail,
                                UserPO::getUserStatus, UserPO::getRegistrationSource, UserPO::getCreateTime)
                        .orderByAsc(UserPO::getId)
                        .last("LIMIT " + Math.min(Math.max(limit, 1), 100)))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 用户目录检索（member:read 可访问）：按 username/email 模糊匹配，limit 上限 20。 */
    public List<UserPO> searchByKeyword(String keyword, int limit) {
        String kw = keyword == null ? "" : keyword.trim();
        LambdaQueryWrapper<UserPO> wrapper = new LambdaQueryWrapper<UserPO>()
                .select(UserPO::getUserId, UserPO::getUsername, UserPO::getPrimaryEmail,
                        UserPO::getUserStatus)
                .orderByAsc(UserPO::getId)
                .last("LIMIT " + Math.min(Math.max(limit, 1), 20));
        if (!kw.isEmpty()) {
            wrapper.and(w -> w.like(UserPO::getUsername, kw).or().like(UserPO::getPrimaryEmail, kw));
        }
        return userMapper.selectList(wrapper).stream().map(this::trimBizKeys).toList();
    }

    /** 按 user_id 集批量查（成员列表补 username 用，避免 N+1）。 */
    public List<UserPO> findByIds(java.util.Collection<String> userIds) {
        if (userIds == null || userIds.isEmpty()) {
            return java.util.List.of();
        }
        return userMapper.selectList(new LambdaQueryWrapper<UserPO>()
                        .in(UserPO::getUserId, userIds))
                .stream().map(this::trimBizKeys).toList();
    }

    /** 更新用户（资料/状态；不含密码哈希）。 */
    public void update(UserPO po) {
        userMapper.updateById(po);
    }

    /** 逻辑删除（delete_flag=1，经 @TableLogic）。 */
    public void logicalDelete(String userId) {
        userMapper.delete(new LambdaQueryWrapper<UserPO>().eq(UserPO::getUserId, userId));
    }

    private UserPO trimBizKeys(UserPO po) {
        if (po.getUserId() != null) {
            po.setUserId(po.getUserId().trim());
        }
        if (po.getDefaultTenantId() != null) {
            po.setDefaultTenantId(po.getDefaultTenantId().trim());
        }
        if (po.getTenantId() != null) {
            po.setTenantId(po.getTenantId().trim());
        }
        return po;
    }
}

# Local rebuild and restart — 2026-11-02

## Authorization and scope

The user explicitly requested rebuilding and restarting the current local Java service. This is operational follow-up to the existing in-progress admin-role-list task, not a new implementation task. Only the current main workspace was used. No frontend restart, business-data modification, credential retrieval, Git staging/commit/push/branch operation, or worktree operation was performed.

## Existing runtime

- LaunchAgent: `gui/501/com.platform-iam.service`.
- Original PID: `92751`, listening on `*:8090`.
- Working directory: `/Users/ramiro.li/root/apps/work/platform-iam-service`.
- Command: existing JDK 26.0.2.1 `java -jar` against `iam-app/target/iam-app-0.0.1-SNAPSHOT.jar` in this workspace.
- Preserved LaunchAgent environment, persistent signing-key path, port, JDK, and log configuration.
- Initial sandboxed localhost probes could not connect. A leftover `/tmp` health file was stale and was explicitly not used as evidence. Subsequent successful probes were run outside the sandbox.

## Build

- Toolchain: `/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home`, OpenJDK 21.0.11.
- Command: `JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home PATH=/opt/homebrew/opt/openjdk@21/bin:$PATH mvn clean install -DskipTests -Dmaven.compiler.proc=full`.
- Result: all seven reactor modules SUCCESS; BUILD SUCCESS at 2026-11-02 15:22:10 +08:00. Tests intentionally skipped for the rebuild scope; existing regression results are recorded in implement.md.
- Log: `restart-build.log` in this task directory.
- JAR SHA-256: `616fb5e119c45eeea8d0976600a1ef34e9e0f538757aae5dddbeb6a67d6e9b75`.
- Packaged AdminRoleService and nested RoleRepository bytes match current compiled classes. Both contain the new `listForAdmin` path.
- Initial sandbox build failed at installation into `~/.m2`; no old process was stopped. The first escalation timed out before execution; the retry with JDK 21 succeeded.

## Restart and validation

- Only after BUILD SUCCESS: `launchctl kickstart -k gui/501/com.platform-iam.service`.
- New PID: `6464`; LaunchAgent state running, run count 3, listener `*:8090`.
- New startup log: Java 26.0.2.1, no explicit active profile, fallback Spring profile `default`.
- Flyway: 20 migrations validated; database version 19, no migration necessary.
- Tomcat started on 8090; IamApplication started at 15:22:44.680 +08:00 in 10.939 seconds.
- New stdout startup section contains no ERROR/WARN; new stderr bytes: zero.
- `GET /actuator/health`, `/actuator/health/readiness`, `/actuator/health/liveness`: HTTP 200, `UP`.
- `GET /.well-known/jwks.json`: HTTP 200, one public signing key.
- Unauthenticated `GET /api/v1/admin/roles?scope_type=PLATFORM&scope_id=PLATFORM`: direct 8090 and existing 5174 proxy both HTTP 401.
- Later check retained the same PID 6464, run count 3, listening port and HTTP 200/UP health/readiness. lsof confirms the open JAR and working directory are this workspace.
- No JWT was read or persisted. Full authenticated role-list response contents were NOT verified during this restart; 401 verifies protected-route availability only.

## Logs and final state

- Application log: `/Users/ramiro.li/root/apps/work/platform-iam-service/logs/platform-iam-service.log`.
- Existing stdout: `/Users/ramiro.li/Library/Logs/platform-iam/iam-app.out.log`.
- Existing stderr: `/Users/ramiro.li/Library/Logs/platform-iam/iam-app.err.log`.
- Branch remains `feature/lee-1102`; existing uncommitted business/source/spec/doc/test changes preserved. `git diff --check` passed.
- Spec-update review: no new API, schema, environment contract, or runtime configuration was introduced. No further spec edit needed; operational facts are retained here.
- Task remains in_progress and unarchived because changes must remain uncommitted and repository archive/session helpers may auto-commit.

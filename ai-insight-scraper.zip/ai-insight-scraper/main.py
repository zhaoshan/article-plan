"""Web Scraper Service — FastAPI 应用入口"""

import asyncio
import logging
import logging.handlers
import sys
from pathlib import Path

# Windows 上 Playwright 需要 ProactorEventLoop 才能启动子进程
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.requests import Request
from fastapi.responses import JSONResponse

from src.config.system_config import load_system_config
from src.database.connection import init_engine, init_db, close_db
from src.database import seed_crawl_link_tree_if_empty
from src.routers import (
    crawl_router,
    link_tree_router,
    content_router,
    v2_public_router,
    schedule_router,
)
from src.models.api_response import DefaultResult
from src.schedulers import scheduler_service
from src.core.scrape_rate_limiter import ScrapeRateLimitError

# ── 日志配置：控制台 + 文件（按天滚动） ────────────────
_LOG_FORMAT = "[%(asctime)s] %(levelname)s - %(name)s - %(message)s"
_LOG_DATEFMT = "%d/%b/%Y %H:%M:%S"
_LOG_DIR = Path("logs")
_LOG_DIR.mkdir(parents=True, exist_ok=True)

# 根日志器：INFO 级别，同时输出到控制台和文件
_root_logger = logging.getLogger()
_root_logger.setLevel(logging.INFO)

# 控制台 handler（实时观察）
_console_handler = logging.StreamHandler()
_console_handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_LOG_DATEFMT))
_root_logger.addHandler(_console_handler)

# 文件 handler：按天滚动，保留 30 天，UTF-8 编码
_file_handler = logging.handlers.TimedRotatingFileHandler(
    filename=_LOG_DIR / "app.log",
    when="midnight",
    interval=1,
    backupCount=30,
    encoding="utf-8",
)
_file_handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_LOG_DATEFMT))
_root_logger.addHandler(_file_handler)

logging.getLogger(__name__).info(f"日志文件输出目录: {_LOG_DIR.resolve()}")


# ── 应用生命周期 ──────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用启动/关闭时的生命周期管理"""
    # 启动时：加载系统配置，初始化数据库引擎，创建表
    config = load_system_config()
    if config.database is not None:
        init_engine(config.database)
        await init_db()
        # 异步初始化种子数据，不阻塞应用启动
        asyncio.create_task(seed_crawl_link_tree_if_empty())
        # 启动调度器并加载启用调度
        scheduler_service.start()
        await scheduler_service.load_schedules_from_db()
    else:
        logging.getLogger(__name__).warning("数据库未配置，跳过数据库初始化与调度器")
    yield
    # 关闭时：释放调度器与数据库连接池
    await scheduler_service.shutdown()
    await close_db()


app = FastAPI(
    title="Web Scraper Service",
    description="通用 Web 数据爬取服务 — 站点链接树遍历与内容提取",
    version="0.1.0",
    lifespan=lifespan,
)

# 注册路由
app.include_router(v2_public_router)
app.include_router(crawl_router)
app.include_router(link_tree_router)
app.include_router(content_router)
app.include_router(schedule_router)


# ── 全局异常处理 ──────────────────────────────────────
# 将所有异常统一转换为 DefaultResult 格式，确保 API 响应格式一致

@app.exception_handler(ScrapeRateLimitError)
async def scrape_rate_limit_error_handler(
    request: Request, exc: ScrapeRateLimitError
) -> JSONResponse:
    """将 /v2/scrape 限流异常转换为 /v2 风格响应（HTTP 429）"""
    return JSONResponse(
        status_code=exc.status_code,
        content={"success": False, "error": exc.error},
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """将 HTTPException 转换为 DefaultResult 格式"""
    return JSONResponse(
        status_code=exc.status_code,
        content=DefaultResult(
            code=str(exc.status_code),
            message=exc.detail if isinstance(exc.detail, str) else "请求错误",
            data=None,
        ).model_dump(),
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """将未捕获的异常转换为 DefaultResult 格式"""
    return JSONResponse(
        status_code=500,
        content=DefaultResult(
            code="500",
            message=f"服务器内部错误: {exc}",
            data=None,
        ).model_dump(),
    )


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    # 注意：不要开启 reload=True。uvicorn 的 reload 模式会在 Windows 上强制使用
    # SelectorEventLoop（不支持子进程），导致 Playwright 启动浏览器子进程时报
    # NotImplementedError。关闭 reload 后 uvicorn 会自动使用 ProactorEventLoop。
    uvicorn.run(app, host="0.0.0.0", port=8000)

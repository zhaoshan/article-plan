"""API 通用响应模型（从 scripts/common_response.py 迁移，Pydantic V2 风格）"""

from pydantic import BaseModel, Field


class DefaultResult(BaseModel):
    """通用 API 响应封装"""

    model_config = {"extra": "forbid"}

    code: str = Field(default="0000", description="响应码，0000 表示成功")
    message: str = Field(default="SUCCESS", description="响应消息")
    data: object | None = Field(default=None, description="响应数据")

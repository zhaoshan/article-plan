package com.unify.iam.common.result;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 统一响应体（供未来内部管理接口使用）。
 *
 * <p>注意：对外部契约端点（登录 token / dev-token / jwks / me）不使用本信封——
 * 这些端点返回真实 HTTP 状态码 + {@code {"detail": ...}}（见 {@code AuthException} 与
 * GlobalExceptionHandler 的双轨约定）。本类服务于未来内部 CRUD 的 ai-chat-insight 式约定。
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommonResponse<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 是否成功 */
    private boolean success;
    /** 结果码 */
    private String code;
    /** 提示信息 */
    private String message;
    /** 数据 */
    private T data;

    public static <T> CommonResponse<T> success(T data) {
        return new CommonResponse<>(true, null, null, data);
    }

    public static <T> CommonResponse<T> success() {
        return success(null);
    }

    public static <T> CommonResponse<T> fail(String code, String message) {
        return new CommonResponse<>(false, code, message, null);
    }
}

-- Invitation uniqueness hard guard (2026-11-04): concurrent/duplicate invites must not create
-- multiple PENDING rows for the same (tenant, email, purpose). Existing migrations are immutable;
-- this file is additive only (new column + unique key), with an idempotent data cleanup first.
--
-- 存量清理：同 (tenant_id, email, purpose) 的多条 PENDING 仅保留最新一条，其余置 CANCELLED
-- （语义正确：旧邀请作废、新邀请生效；清理是加唯一索引的前置条件）。
UPDATE `gateway_invitation` old_row
JOIN (
  SELECT `invitation_id`
  FROM (
    SELECT `invitation_id`,
           ROW_NUMBER() OVER (
             PARTITION BY `tenant_id`, `email`, `invitation_purpose`
             ORDER BY `id` DESC
           ) AS rn
    FROM `gateway_invitation`
    WHERE `invitation_status` = 'PENDING'
  ) ranked
  WHERE ranked.rn > 1
) dup ON old_row.`invitation_id` = dup.`invitation_id`
SET old_row.`invitation_status` = 'CANCELLED',
    old_row.`update_by` = 'V20-dedup';

-- 生成列：仅 PENDING 行生成唯一键（其它状态为 NULL，MySQL 唯一索引允许多个 NULL）。
-- 注意：不能用 NOW()（生成列要求确定性函数）——过期行由应用层在邀请前主动翻转为 EXPIRED
-- （InvitationRepository.markExpiredInvitations），保证 PENDING ⇒ 未过期。
ALTER TABLE `gateway_invitation`
  ADD COLUMN `pending_key` VARCHAR(224) GENERATED ALWAYS AS (
    CASE WHEN `invitation_status` = 'PENDING'
         THEN CONCAT(`tenant_id`, ':', `email`, ':', `invitation_purpose`) END) STORED
    COMMENT 'pending unique key (tenant:email:purpose), anti duplicate invite 2026-11-04' AFTER `default_role_id`;

ALTER TABLE `gateway_invitation`
  ADD UNIQUE KEY `uk_invitation_pending` (`pending_key`);

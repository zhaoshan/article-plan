package com.unify.iam.app.infra.persistence.repository;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.unify.iam.app.infra.persistence.mapper.RefreshTokenMapper;
import com.unify.iam.app.infra.persistence.po.RefreshTokenPO;
import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.stereotype.Repository;

/** refresh token 仓储（落库存哈希，非明文）。 */
@Repository
public class RefreshTokenRepository {

    private final RefreshTokenMapper refreshTokenMapper;

    public RefreshTokenRepository(RefreshTokenMapper refreshTokenMapper) {
        this.refreshTokenMapper = refreshTokenMapper;
    }

    public void insert(RefreshTokenPO po) {
        refreshTokenMapper.insert(po);
    }

    /** 按哈希查未撤销、未过期、未删除的 refresh（业务键 trim）。 */
    public Optional<RefreshTokenPO> findActiveByHash(String hash) {
        return Optional.ofNullable(refreshTokenMapper.selectOne(new LambdaQueryWrapper<RefreshTokenPO>()
                        .eq(RefreshTokenPO::getRefreshTokenHash, hash)
                        .isNull(RefreshTokenPO::getRevokedAt)
                        .gt(RefreshTokenPO::getExpiresAt, LocalDateTime.now())))
                .map(this::trimBizKeys);
    }

    /** 撤销（置 revoked_at=now）。 */
    public void markRevoked(Long id) {
        refreshTokenMapper.update(null, new LambdaUpdateWrapper<RefreshTokenPO>()
                .eq(RefreshTokenPO::getId, id)
                .set(RefreshTokenPO::getRevokedAt, LocalDateTime.now()));
    }

    /** 撤销某用户全部有效 refresh（改密/登出全部场景）。 */
    public void revokeByUser(String userId) {
        refreshTokenMapper.update(null, new LambdaUpdateWrapper<RefreshTokenPO>()
                .eq(RefreshTokenPO::getUserId, userId)
                .isNull(RefreshTokenPO::getRevokedAt)
                .set(RefreshTokenPO::getRevokedAt, LocalDateTime.now()));
    }

    private RefreshTokenPO trimBizKeys(RefreshTokenPO po) {
        if (po.getRefreshTokenId() != null) {
            po.setRefreshTokenId(po.getRefreshTokenId().trim());
        }
        if (po.getUserId() != null) {
            po.setUserId(po.getUserId().trim());
        }
        if (po.getTenantId() != null) {
            po.setTenantId(po.getTenantId().trim());
        }
        if (po.getMembershipId() != null) {
            po.setMembershipId(po.getMembershipId().trim());
        }
        return po;
    }
}
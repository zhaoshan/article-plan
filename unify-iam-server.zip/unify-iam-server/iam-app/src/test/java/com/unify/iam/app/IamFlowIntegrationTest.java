package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.factories.DefaultJWSVerifierFactory;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.model.AuthorizationContext;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.JsonUtils;
import java.security.Key;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * 集成测试（Testcontainers MySQL 8 + Flyway）：覆盖 E2E-1 验收矩阵的 IAM 侧输入。
 *
 * <p>验收 #1/2/3/4/5/6 的最终 401/403/200 裁决在 parlant 侧；本类验证 IAM 产出的
 * claims/权限集正确（即那些裁决的输入），并以"仿真 parlant gateway Provider"独立验签。
 */
class IamFlowIntegrationTest extends IamIntegrationTestBase {

    private static final List<String> NINE_PERMISSIONS = List.of(
            "agent:read", "agent:build", "agent:publish", "agent:delete",
            "session:read", "session:send", "customer:manage", "trace:read", "settings:read");

    @Autowired
    private JwtSigner jwtSigner;

    // ============================================================
    // helpers
    // ============================================================

    private String loginToken(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + b64(password) + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    /** 复刻 parlant GatewayProvider 验签逻辑：JWKS 按 kid 取钥 → RS256 验签 → require exp → aud 校验。 */
    private JWTClaimsSet simulateParlantGatewayVerify(String token, String expectedAud) throws Exception {
        String jwksJson = mockMvc.perform(get("/.well-known/jwks.json"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        JWKSet jwkSet = JWKSet.parse(jwksJson);
        SignedJWT jwt = SignedJWT.parse(token);

        JWSKeySelector<SecurityContext> selector =
                new JWSVerificationKeySelector<>(JWSAlgorithm.RS256, new ImmutableJWKSet<>(jwkSet));
        List<? extends Key> keys = selector.selectJWSKeys(jwt.getHeader(), null);
        if (keys.isEmpty()) {
            throw new AuthException(401, "unknown kid"); // 仿 PyJWKClient.get_signing_key_from_jwt 失败
        }
        JWSVerifier verifier = new DefaultJWSVerifierFactory().createJWSVerifier(jwt.getHeader(), keys.get(0));
        if (!jwt.verify(verifier)) {
            throw new AuthException(401, "invalid signature");
        }
        JWTClaimsSet claims = jwt.getJWTClaimsSet();
        if (claims.getExpirationTime() == null) {
            throw new AuthException(401, "missing exp"); // 仿 options={"require":["exp"]}
        }
        if (claims.getExpirationTime().before(new Date())) {
            throw new AuthException(401, "expired"); // 仿 ExpiredSignatureError
        }
        if (expectedAud != null && !claims.getAudience().contains(expectedAud)) {
            throw new AuthException(401, "aud mismatch");
        }
        return claims;
    }

    /** 复刻 parlant claims_to_context：claims → AuthorizationContext。 */
    private AuthorizationContext translate(JWTClaimsSet claims) {
        return new AuthorizationContext(
                String.valueOf(claims.getSubject()),
                String.valueOf(claims.getClaim("tenantId")),
                claims.getClaim("membershipId") == null ? null : String.valueOf(claims.getClaim("membershipId")),
                toStrList(claims.getClaim("roles")),
                toStrList(claims.getClaim("permissions")),
                claims.getClaim("attrs") instanceof Map<?, ?> attrs ? toStrListMap(attrs) : Map.of());
    }

    @SuppressWarnings("unchecked")
    private List<String> toStrList(Object value) {
        if (value == null) {
            return List.of();
        }
        return ((List<?>) value).stream().map(String::valueOf).toList();
    }

    @SuppressWarnings("unchecked")
    private Map<String, List<String>> toStrListMap(Map<?, ?> map) {
        return (Map<String, List<String>>) map;
    }

    private int count(String table) {
        return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM " + table, Integer.class);
    }

    // ============================================================
    // I1/I2 迁移与 seed
    // ============================================================

    @Test
    void flywayCreatesExpectedTables() {
        List<String> tables = jdbcTemplate.queryForList(
                "SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name LIKE 'gateway\\_%'",
                String.class);
        // E2E-1 的 8 张 + E2E-2（V3）的 2 张 + E2E-3（V5）的 7 张 + V10 的 1 张（方案 c 版本日志）
        assertThat(tables).containsExactlyInAnyOrder(
                "gateway_user", "gateway_tenant", "gateway_membership", "gateway_user_identity",
                "gateway_role", "gateway_permission", "gateway_role_permission", "gateway_membership_role",
                "gateway_tenant_idp_config", "gateway_idp_group_mapping",
                "gateway_email_verification", // V21 注册邮箱验证码（2026-11-05）
                "gateway_refresh_token", "gateway_password_reset_token",
                "gateway_tenant_domain", "gateway_tenant_domain_challenge",
                "gateway_invitation", "gateway_join_request", "gateway_audit_log",
                "gateway_membership_version_log",
                "gateway_quota_dimension", "gateway_tenant_quota");
    }

    @Test
    void seedDataIsComplete() {
        // 按 seed 行「存在性」断言（共享单例容器下其它集成测试可能新增数据，勿用全局 COUNT）
        assertThat(exists("gateway_user", "user_id IN ('u-1000','u-1001','u-1002')")).isTrue();
        assertThat(exists("gateway_tenant", "tenant_id='tenant-org-a'")).isTrue();
        assertThat(exists("gateway_membership", "membership_id IN ('ms-1001','ms-2001','ms-3001')")).isTrue();
        assertThat(exists("gateway_user_identity", "user_identity_id IN ('id-1001','id-2001','id-3001')")).isTrue();
        assertThat(exists("gateway_role", "role_id IN ('r-1001','r-1002','r-1003','r-2001')")).isTrue(); // 3 业务 + PlatformAdmin
        assertThat(exists("gateway_permission", "permission_id IN ('p-1001','p-1002','p-1003','p-1004','p-1005','p-1006','p-1007','p-1008','p-1009','p-2001','p-2009')")).isTrue();
        // TenantAdmin 绑 9 业务码；PlatformAdmin 绑 9 个 iam:*
        assertThat(exists("gateway_role_permission",
                "role_id='r-1002' AND permission_id IN ('p-1001','p-1002','p-1003','p-1004','p-1005','p-1006','p-1007','p-1008','p-1009')")).isTrue();
        assertThat(exists("gateway_role_permission",
                "role_id='r-2001' AND permission_id IN ('p-2001','p-2002','p-2003','p-2004','p-2005','p-2006','p-2007','p-2008','p-2009')")).isTrue();
        // admin 成员持有 TenantAdmin + PlatformAdmin
        assertThat(exists("gateway_membership_role",
                "membership_id='ms-1001' AND role_id IN ('r-1002','r-2001')")).isTrue();
    }

    private boolean exists(String table, String where) {
        Integer n = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM " + table + " WHERE " + where + " AND delete_flag=0", Integer.class);
        return n != null && n > 0;
    }

    // ============================================================
    // I3 全链路登录（真实表 → claims）
    // ============================================================

    @Test
    void fullLoginProducesCorrectClaims() throws Exception {
        String token = loginToken("operator", "op123");
        JWTClaimsSet claims = SignedJWT.parse(token).getJWTClaimsSet();

        assertThat(claims.getSubject()).isEqualTo("u-1001");
        assertThat(String.valueOf(claims.getClaim("tenantId"))).isEqualTo("tenant-org-a"); // 无尾空格
        assertThat(String.valueOf(claims.getClaim("membershipId"))).isEqualTo("ms-2001");
        assertThat(toStrList(claims.getClaim("roles"))).containsExactly("AgentOperator");
        assertThat(toStrList(claims.getClaim("permissions"))).containsExactlyInAnyOrderElementsOf(NINE_PERMISSIONS);
        assertThat(claims.getAudience()).contains("parlant-agent-server");
        assertThat(claims.getIssuer()).isEqualTo("https://www.identityfabric.com");
        assertThat((Map<?, ?>) claims.getClaim("attrs")).isEmpty();
    }

    // ============================================================
    // I4-I7 仿真 parlant gateway Provider（验收核心）
    // ============================================================

    @Test
    void parlantGatewayProviderSimulationTranslatesContext() throws Exception {
        String token = loginToken("operator", "op123");
        JWTClaimsSet claims = simulateParlantGatewayVerify(token, "parlant-agent-server");

        AuthorizationContext ctx = translate(claims);
        assertThat(ctx.userId()).isEqualTo("u-1001");
        assertThat(ctx.tenantId()).isEqualTo("tenant-org-a");
        assertThat(ctx.membershipId()).isEqualTo("ms-2001");
        assertThat(ctx.roles()).containsExactlyInAnyOrder("AgentOperator");
        assertThat(ctx.permissions()).containsExactlyInAnyOrderElementsOf(NINE_PERMISSIONS);
        assertThat(ctx.attrs()).isEmpty();
    }

    @Test
    void tamperedTokenRejectedInSimulation() throws Exception {
        String token = loginToken("operator", "op123");
        // 篡改签名中段字符（base64url 末位在 len%4==2 时低位被忽略，改中段保证解码字节变化）
        int sigStart = token.lastIndexOf('.') + 1;
        String sig = token.substring(sigStart);
        int mid = sig.length() / 2;
        char flipped = sig.charAt(mid) == 'A' ? 'B' : 'A';
        String tampered = token.substring(0, sigStart)
                + sig.substring(0, mid) + flipped + sig.substring(mid + 1);

        assertThatThrownBy(() -> simulateParlantGatewayVerify(tampered, "parlant-agent-server"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessageContaining("signature");
    }

    @Test
    void expiredTokenRejectedInSimulation() throws Exception {
        long now = Instant.now().getEpochSecond();
        JwtClaims expired = new JwtClaims("https://www.identityfabric.com", List.of("parlant-agent-server"),
                "u-1001", "tenant-org-a", "ms-2001",
                List.of("AgentOperator"), List.of("agent:read"), Map.of(),
                now - 60, now - 7200, "jti-expired", 0L);
        String token = jwtSigner.sign(expired);

        assertThatThrownBy(() -> simulateParlantGatewayVerify(token, "parlant-agent-server"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessageContaining("expired");
    }

    @Test
    void unknownKidTokenRejectedInSimulation() throws Exception {
        RSAKey other = new RSAKeyGenerator(2048).keyID("iam-key-2").generate();
        long now = Instant.now().getEpochSecond();
        JWTClaimsSet cs = new JWTClaimsSet.Builder()
                .subject("u-1001").claim("tenantId", "tenant-org-a")
                .claim("roles", List.of("AgentOperator")).claim("permissions", List.of("agent:read"))
                .expirationTime(new Date((now + 7200) * 1000))
                .issueTime(new Date(now * 1000))
                .build();
        SignedJWT otherJwt = new SignedJWT(
                new JWSHeader.Builder(JWSAlgorithm.RS256).keyID("iam-key-2").build(), cs);
        otherJwt.sign(new RSASSASigner(other));

        assertThatThrownBy(() -> simulateParlantGatewayVerify(otherJwt.serialize(), "parlant-agent-server"))
                .isInstanceOf(AuthException.class)
                .satisfies(e -> assertThat(((AuthException) e).getHttpStatus()).isEqualTo(401))
                .hasMessageContaining("kid");
    }

    // ============================================================
    // I8 403 场景输入：Viewer 无 agent:publish
    // ============================================================

    @Test
    void viewerLacksPublishPermission() throws Exception {
        String token = loginToken("viewer", "view123");
        JWTClaimsSet claims = simulateParlantGatewayVerify(token, "parlant-agent-server");

        List<String> perms = toStrList(claims.getClaim("permissions"));
        assertThat(perms).contains("agent:read", "session:read", "settings:read");
        assertThat(perms).doesNotContain("agent:publish", "agent:build", "agent:delete", "session:send");
    }

    // ============================================================
    // I9 换角色 seed → 授权立即变化（验收 #7）
    // ============================================================

    @Test
    void roleChangeTakesEffectOnNextLogin() throws Exception {
        // 给 viewer 的成员关系（ms-3001）追加 AgentOperator 角色
        jdbcTemplate.update("""
                INSERT INTO gateway_membership_role
                  (membership_role_id, membership_id, role_id, grant_source, delete_flag, create_by, update_by)
                VALUES ('mr-3999', 'ms-3001', 'r-1001', 'DIRECT', 0, 'system', 'system')
                """);
        try {
            String token = loginToken("viewer", "view123");
            JWTClaimsSet claims = simulateParlantGatewayVerify(token, "parlant-agent-server");

            assertThat(toStrList(claims.getClaim("roles"))).contains("Viewer", "AgentOperator");
            assertThat(toStrList(claims.getClaim("permissions"))).contains("agent:publish");
        } finally {
            // 清理本用例写入的行，避免污染共享库（影响其它用例的精确断言）
            jdbcTemplate.update("DELETE FROM gateway_membership_role WHERE membership_role_id = 'mr-3999'");
        }
    }

    // ============================================================
    // I10 /me 语义 + 其它端点
    // ============================================================

    @Test
    void meWithoutTokenReturns401() throws Exception {
        mockMvc.perform(get("/api/v1/auth/me"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("Missing token")));
    }

    @Test
    void meWithValidTokenReturnsContext() throws Exception {
        String token = loginToken("operator", "op123");
        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.userId").value("u-1001"))
                .andExpect(jsonPath("$.data.tenantId").value("tenant-org-a"))
                .andExpect(jsonPath("$.data.roles[0]").value("AgentOperator"))
                .andExpect(jsonPath("$.data.attrs").isMap());
    }

    @Test
    void unknownUserLoginReturns401() throws Exception {
        mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"ghost\",\"password\":\"" + b64("x") + "\"}"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Incorrect username or password"));
    }

    @Test
    void devTokenIssuesPerSeedUser() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/dev-token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"user_id\":\"u-1002\"}"))
                .andExpect(status().isOk())
                .andReturn();
        LoginResponse resp = JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class);
        assertThat(resp.user().userId()).isEqualTo("u-1002");
        assertThat(resp.user().roles()).containsExactly("Viewer");

        // dev-token 产出的令牌同样能被仿真验签通过
        JWTClaimsSet claims = simulateParlantGatewayVerify(resp.accessToken(), "parlant-agent-server");
        assertThat(claims.getSubject()).isEqualTo("u-1002");
    }
}

package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;

/** 管理面 IdP 组→角色映射请求（docs/07 §3.2，建/改共用）。 */
public record GroupMappingRequest(
        @JsonProperty("match_mode") String matchMode,
        @JsonProperty("match_value") String matchValue,
        @JsonProperty("target_role_id") String targetRoleId,
        Integer priority,
        @JsonProperty("mapping_status") String mappingStatus) {
}

package com.unify.iam.app;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

/**
 * G8 邮箱存在性判定（{@code POST /api/v1/auth/user-exists}，X-IAM-Service-Token）集成测试：
 * 存在性 + auth_mode（identity 计算：LOCAL→password / 仅 OIDC→sso，两者都有→password）。
 */
class UserExistsIntegrationTest extends IamIntegrationTestBase {

    private static final String SERVICE_TOKEN = "it-service-token";
    private static final String URL = "/api/v1/auth/user-exists";

    private org.springframework.test.web.servlet.ResultActions check(String body, String serviceToken)
            throws Exception {
        var req = post(URL).contentType(MediaType.APPLICATION_JSON).content(body);
        if (serviceToken != null) {
            req = req.header("X-IAM-Service-Token", serviceToken);
        }
        return mockMvc.perform(req);
    }

    @Test
    void missingServiceTokenReturns401() throws Exception {
        check("{\"email\":\"admin@unify.local\"}", null)
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    void wrongServiceTokenReturns401() throws Exception {
        check("{\"email\":\"admin@unify.local\"}", "wrong-token")
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    void blankEmailReturns400() throws Exception {
        check("{\"email\":\"\"}", SERVICE_TOKEN)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    void existingLocalUserReturnsPassword() throws Exception {
        // seed-dev：admin@unify.local 有 LOCAL/password 身份
        check("{\"email\":\"admin@unify.local\"}", SERVICE_TOKEN)
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.exists").value(true))
                .andExpect(jsonPath("$.data.auth_mode").value("password"));
    }

    @Test
    void unknownEmailReturnsNotExists() throws Exception {
        check("{\"email\":\"nobody@unify.local\"}", SERVICE_TOKEN)
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.exists").value(false));
    }

    @Test
    void oidcOnlyUserReturnsSso() throws Exception {
        insertUser("u-g8ssouser0000000000000000001", "g8_sso_user", "g8-sso@unify.local");
        jdbcTemplate.update("""
                INSERT IGNORE INTO gateway_user_identity
                  (user_identity_id, user_id, provider_type, provider_key, issuer, subject,
                   login_name, identity_status, delete_flag, create_by, update_by)
                VALUES ('id-g8-sso-00000000000000000001', 'u-g8ssouser0000000000000000001', 'OIDC', 'keycloak',
                        'https://idp.test/iss', 'sub-g8-sso', 'g8-sso@unify.local', 'ACTIVE', 0, 'system', 'system')
                """);
        check("{\"email\":\"g8-sso@unify.local\"}", SERVICE_TOKEN)
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.exists").value(true))
                .andExpect(jsonPath("$.data.auth_mode").value("sso"));
    }

    @Test
    void bothIdentitiesPreferPassword() throws Exception {
        String uid = "u-g8bothuser0000000000000000001";
        insertUser(uid, "g8_both_user", "g8-both@unify.local");
        jdbcTemplate.update("""
                INSERT IGNORE INTO gateway_user_identity
                  (user_identity_id, user_id, provider_type, provider_key, issuer, subject,
                   login_name, identity_status, delete_flag, create_by, update_by)
                VALUES ('id-g8-both-0000000000000000001', ?, 'LOCAL', 'password', NULL, 'g8_both_user',
                        'g8_both_user', 'ACTIVE', 0, 'system', 'system')
                """, uid);
        jdbcTemplate.update("""
                INSERT IGNORE INTO gateway_user_identity
                  (user_identity_id, user_id, provider_type, provider_key, issuer, subject,
                   login_name, identity_status, delete_flag, create_by, update_by)
                VALUES ('id-g8-both-0000000000000000002', ?, 'OIDC', 'keycloak', 'https://idp.test/iss',
                        'sub-g8-both', 'g8-both@unify.local', 'ACTIVE', 0, 'system', 'system')
                """, uid);
        // 决策：两者都有 → password（前端可再跳 SSO）
        check("{\"email\":\"g8-both@unify.local\"}", SERVICE_TOKEN)
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.exists").value(true))
                .andExpect(jsonPath("$.data.auth_mode").value("password"));
    }

    private void insertUser(String userId, String username, String email) {
        jdbcTemplate.update("""
                INSERT IGNORE INTO gateway_user
                  (user_id, username, primary_email, password_hash, full_name, display_name,
                   default_tenant_id, user_status, registration_source, delete_flag, create_by, update_by)
                VALUES (?, ?, ?, '$2y$10$7fz/ZSudBKRu/2fbea44sOImpP.amOjFSvf26iCp5s8Oovl.HDvfa',
                        ?, ?, NULL, 'ACTIVE', 'ADMIN', 0, 'system', 'system')
                """, userId, username, email, username, username);
    }
}

package com.unify.iam.app.mail;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Objects;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * 基于 Spring Mail 的邮件发送实现（对齐 ai-chat-insight {@code JavaMailEmailTool}）。
 *
 * <p>未配置 SMTP（{@code spring.mail.host/username} 为空）时回退为日志模式——log 记录收件人与主题，
 * 应用照常启动/流程不阻断（dev/test 友好；生产配置 SMTP 后真实发送）。
 */
@Component
public class JavaMailEmailTool implements EmailTool {

    private static final Logger log = LoggerFactory.getLogger(JavaMailEmailTool.class);

    private final JavaMailSender javaMailSender;
    private final String springMailHost;
    private final String from;

    public JavaMailEmailTool(
            ObjectProvider<JavaMailSender> javaMailSenderProvider,
            @org.springframework.beans.factory.annotation.Value("${spring.mail.host:}") String springMailHost,
            @org.springframework.beans.factory.annotation.Value("${spring.mail.username:}") String from) {
        this.javaMailSender = javaMailSenderProvider.getIfAvailable();
        this.springMailHost = springMailHost;
        this.from = from;
    }

    @Override
    public void send(String to, String subject, String htmlBody) {
        if (!isMailConfigured()) {
            log.info("Send email (mail not configured): to={}, subject={}", to, subject);
            return;
        }
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, false, StandardCharsets.UTF_8.name());
            helper.setTo(Objects.requireNonNull(to));
            helper.setFrom(Objects.requireNonNull(from));
            helper.setSubject(Objects.requireNonNull(subject));
            helper.setText(Objects.requireNonNull(htmlBody), true);
            javaMailSender.send(message);
            log.info("Send email by mail: to={}, subject={}", to, subject);
        } catch (MailException | MessagingException e) {
            log.error("Send email failed: to={}, subject={}", to, subject, e);
            throw new IllegalStateException("Send email failed", e);
        }
    }

    /** SMTP 是否已配置（host + from 缺一不可）。 */
    public boolean isMailConfigured() {
        return javaMailSender != null
                && StringUtils.hasText(springMailHost)
                && StringUtils.hasText(from);
    }
}

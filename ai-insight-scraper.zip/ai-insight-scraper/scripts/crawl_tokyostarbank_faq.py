# -*- coding: utf-8 -*-
"""
爬取 support.tokyostarbank.co.jp FAQ 动态站点脚本

功能：
1. 打开 FAQ 分类页面，逐个处理 h4 分类区块
2. 第一个 h4 不需要点击，直接获取其按钮
3. 从第二个 h4 开始，点击展开后获取按钮
4. 对每个按钮：点击 → 等待子内容加载 → 滚动获取所有子链接
5. h4 点击可能新增更多 h4，动态更新列表继续遍历
6. 保存所有结果到 JSON 文件

关键规则：
- 每点击一个 h4 就处理一次按钮点击和链接爬取，不能等所有 h4 点开再处理
- 按钮点击后新内容替换当前页面，不是内联追加
- 滚动页面以获取懒加载的子链接

用法：
    # CDP 模式（连接已运行的 Chrome，推荐）
    python -m app.scripts.tsb.crawl_tokyostarbank_faq

    # 本地 Chromium 模式
    python -m app.scripts.tsb.crawl_tokyostarbank_faq --local-chromium

    # 显示浏览器窗口（调试用）
    python -m app.scripts.tsb.crawl_tokyostarbank_faq --local-chromium --visible

    # 指定输出文件
    python -m app.scripts.tsb.crawl_tokyostarbank_faq --output result.json
"""

import asyncio
import json
import logging
import os
import sys
import argparse
import random
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict
from urllib.parse import urlparse

from playwright.async_api import async_playwright, Browser, BrowserContext, Page

# 确保项目根目录在 sys.path 中
_project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# 解决 Windows 控制台 UTF-8 编码问题
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ==================== 常量配置 ====================

# 默认 FAQ 分类页 URL
DEFAULT_FAQ_URL = "https://support.tokyostarbank.co.jp/category/c59a6135-81ab-4dd8-9087-962794dee628/"

# 输出文件路径
DEFAULT_OUTPUT = Path(__file__).parent.parent.parent / "crawler" / "service" / "crawl_output" / "tsb_faq_sublinks.json"

# 浏览器 User-Agent
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)

# CDP 默认调试端口
CDP_DEBUG_PORT = 9222

# 页面超时时间（毫秒）
PAGE_TIMEOUT = 60000

# Chromium 启动参数
CHROMIUM_ARGS = [
    '--disable-blink-features=AutomationControlled',
    '--disable-features=VizDisplayCompositor',
    '--disable-dev-shm-usage',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-software-rasterizer',
    '--disable-gpu',
]

# 滚动加载相关参数
SCROLL_STEP = 800          # 每次滚动像素
SCROLL_DELAY_MS = 1500     # 每次滚动后等待时间（毫秒）
SCROLL_MAX_IDLE = 3        # 连续无新链接的最大次数，超过则停止滚动

# 分组按钮选择器（点击展开 h4 分类的按钮，带 id 属性）
CATEGORY_BUTTON_SELECTOR = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-contained.faq-category__button.faq-has-subcategory.MuiButton-fullWidth'

# 按钮选择器（子分类按钮，核心识别类：faq-subcategory + faq-category__button）
BUTTON_SELECTOR = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-text.faq-subcategory.faq-category__button'

# 子内容加载后的标识（h5 问题标题，表示按钮点击后子内容已渲染）
SUB_CONTENT_SELECTOR = 'h5.MuiTypography-root.faq-panel-content__q.MuiTypography-h5'


# 全局唯一链接文件路径（FAQ 子链接追加写入此文件）
ALL_UNIQUE_LINKS_FILE = Path(__file__).parent.parent.parent.parent / "crawl_result" / "tsb" / "all_tsb_unique_links.json"


def normalize_link_for_dedup(url: str) -> str:
    """
    链接规范化用于去重比较：
    1. http:// 统一转为 https://
    2. 去掉 ? 后面的查询参数
    3. 去掉 # 后面的锚点
    4. 路径末尾的 / 保留（与文件中已有格式一致）
    """
    try:
        parsed = urlparse(url)
        # http 转 https
        scheme = "https" if parsed.scheme == "http" else parsed.scheme
        # 去掉 query 和 fragment
        netloc = parsed.netloc
        path = parsed.path
        # 去掉 www.（但 tokyostarbank.co.jp 域名不去掉，因为其正常域名无 www 前缀）
        if netloc.startswith("www.") and not netloc.endswith("tokyostarbank.co.jp"):
            netloc = netloc[4:]
        return f"{scheme}://{netloc}{path}".lower()
    except Exception:
        return url.lower()


def save_links_to_all_unique_file(new_links: List[str]) -> None:
    """
    将新获取的链接规范化后，与已有链接去重，追加写入 all_tsb_unique_links.json。

    规则：
    1. 写入前做链接规范化（http→https，去掉 ? 和 # 部分）
    2. 与已有链接对比去重，不写入重复数据
    3. 新增链接追加在 JSON 数组末尾
    """
    file_path = ALL_UNIQUE_LINKS_FILE

    # 1. 读取已有链接
    existing_links = []
    if file_path.exists():
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                existing_links = json.load(f)
            logger.info(f"已有链接文件加载成功，当前 {len(existing_links)} 条")
        except (json.JSONDecodeError, Exception) as e:
            logger.warning(f"读取已有链接文件失败: {e}，将覆盖写入")
            existing_links = []

    # 2. 构建已有链接的规范化集合（用于去重比较）
    existing_norm_set = set()
    for link in existing_links:
        norm = normalize_link_for_dedup(link)
        existing_norm_set.add(norm)

    # 3. 规范化新链接，去重后追加
    appended_count = 0
    for link in new_links:
        norm = normalize_link_for_dedup(link)
        if norm not in existing_norm_set:
            # 用规范化后的链接写入（规范化版本）
            existing_links.append(norm)
            existing_norm_set.add(norm)
            appended_count += 1

    # 4. 写回文件
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(existing_links, f, ensure_ascii=False, indent=2)

    logger.info(f"链接去重写入完成：新增 {appended_count} 条，总计 {len(existing_links)} 条，文件: {file_path}")


# ==================== 日志配置 ====================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ==================== 工具函数 ====================

def _find_chrome_path() -> str:
    """查找本地 Chrome 浏览器可执行文件路径"""
    import platform

    system = platform.system()
    if system == "Windows":
        paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ]
    elif system == "Darwin":
        paths = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        ]
    else:
        paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
        ]

    for path in paths:
        if os.path.exists(path):
            return path
    return ""


def ensure_https(url: str) -> str:
    """将 http:// 协议升级为 https://"""
    if url.startswith("http://"):
        return "https://" + url[7:]
    return url


def is_valid_url(url: str) -> bool:
    """检查 URL 是否有效（只处理 http/https 链接）"""
    try:
        parsed = urlparse(url)
        return parsed.scheme in ['http', 'https'] and bool(parsed.netloc)
    except Exception:
        return False


def normalize_url(url_string: str) -> str:
    """标准化 URL 用于去重比较"""
    try:
        url = urlparse(url_string)
        if url.scheme not in ['http', 'https']:
            return url_string.lower()
        host = url.netloc.replace('www.', '')
        pathname = url.path.rstrip('/')
        return f"{url.scheme}://{host}{pathname}".lower()
    except Exception:
        return url_string.lower()


# ==================== JS 注入脚本 ====================

JS_EXTRACT_LINKS = """
(() => {
  const collectedLinks = [];
  const seen = new Set();

  for (let i = 0; i < document.links.length; i++) {
    const link = document.links[i];
    if (link.href && link.href.trim()) {
      const href = link.href.trim();
      if (!href.startsWith('javascript:') && !href.startsWith('mailto:') && !href.startsWith('tel:')) {
        if (!seen.has(href)) {
          seen.add(href);
          collectedLinks.push(href);
        }
      }
    }
  }

  return collectedLinks;
})();
"""


# ==================== 核心爬取逻辑 ====================

async def scroll_to_load_all(page: Page) -> int:
    """
    持续滚动页面，直到没有新链接出现（懒加载内容全部加载）。

    Returns:
        最终链接数
    """
    idle_count = 0
    scroll_round = 0
    last_link_count = await page.evaluate("document.links.length")

    while idle_count < SCROLL_MAX_IDLE:
        await page.evaluate(f"window.scrollBy(0, {SCROLL_STEP})")
        scroll_round += 1
        await page.wait_for_timeout(SCROLL_DELAY_MS)

        current_link_count = await page.evaluate("document.links.length")

        if current_link_count > last_link_count:
            idle_count = 0
            logger.debug(f"    滚动第 {scroll_round} 次：新链接 {current_link_count - last_link_count} 个，累计 {current_link_count}")
            last_link_count = current_link_count
        else:
            idle_count += 1

        # 检查是否已滚动到页面底部
        at_bottom = await page.evaluate(
            "() => (window.innerHeight + window.scrollY) >= document.body.scrollHeight - 100"
        )
        if at_bottom and idle_count >= 1:
            break

    return last_link_count


async def extract_unique_links(page: Page) -> List[str]:
    """
    从当前页面提取去重后的有效链接列表。

    Returns:
        去重后的链接列表
    """
    raw_links = await page.evaluate(JS_EXTRACT_LINKS)
    valid_links = [href for href in raw_links if is_valid_url(href)]

    seen = set()
    unique_links = []
    for link in valid_links:
        norm = normalize_url(link)
        if norm not in seen:
            seen.add(norm)
            unique_links.append(link)

    return unique_links


async def click_button_with_retry(page: Page, btn_text: str, max_retries: int = 3) -> bool:
    """
    点击按钮（带重试）：每次重试前重新查询全局按钮，按文本匹配定位。

    Args:
        page: Playwright Page 对象
        btn_text: 按钮文本
        max_retries: 最大重试次数

    Returns:
        是否点击成功
    """
    for retry in range(max_retries):
        try:
            # 重新获取全局按钮列表，按文本匹配找到索引
            target_idx = await page.evaluate("""
                (btnText) => {
                    const BTN_SEL = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-text.faq-subcategory.faq-category__button';
                    const btns = Array.from(document.querySelectorAll(BTN_SEL));
                    for (let i = 0; i < btns.length; i++) {
                        if (btns[i].innerText.trim() === btnText) {
                            return i;
                        }
                    }
                    return -1;
                }
            """, btn_text)

            if target_idx < 0:
                logger.warning(f"    重试 {retry + 1}/{max_retries}: 未找到按钮 '{btn_text}'")
                await page.wait_for_timeout(1000)
                continue

            btn = page.locator(BUTTON_SELECTOR).nth(target_idx)
            await btn.click(timeout=15000)
            logger.info(f"    已点击按钮: {btn_text} (global_idx={target_idx}, 重试={retry})")
            return True
        except Exception as e:
            logger.warning(f"    重试 {retry + 1}/{max_retries} 点击按钮失败: {e}")
            await page.wait_for_timeout(2000)

    return False


async def wait_for_sub_content(page: Page, max_wait_seconds: int = 30) -> bool:
    """
    等待子内容加载（h5 出现），轮询检测加载中标识。

    Args:
        page: Playwright Page 对象
        max_wait_seconds: 最长等待秒数

    Returns:
        h5 是否出现
    """
    rounds = max_wait_seconds // 5
    for wait_round in range(rounds):
        try:
            await page.wait_for_selector(SUB_CONTENT_SELECTOR, timeout=5000)
            logger.info(f"    h5 子内容已出现 (等待第 {wait_round + 1} 轮)")
            return True
        except Exception:
            logger.info(f"    等待 h5 第 {wait_round + 1}/{rounds} 轮，尚未出现")
            # 检查页面是否有加载中的提示
            loading = await page.evaluate("""
                () => {
                    const loaders = document.querySelectorAll(
                        '.MuiCircularProgress-root, .loading, [class*="loading"], [class*="spinner"]'
                    );
                    return loaders.length > 0;
                }
            """)
            if loading:
                logger.info(f"    检测到加载中标识，继续等待")

    logger.warning(f"    等待 {max_wait_seconds} 秒后 h5 仍未出现")
    return False


async def crawl_faq(page: Page, url: str) -> Dict:
    """
    爬取 FAQ 动态站点的主流程。

    流程：
    1. 打开 FAQ 分类页，等待 h5 出现确认页面渲染完成
    2. 逐个点击 h4 展开分类
    3. 每点击一个 h4 后，从全局查询按钮，与已点击按钮取差集得到新按钮
    4. 逐个点击新按钮，等待 h5 加载后滚动获取子链接
    5. h4 点击可能新增更多 h4，动态更新列表继续遍历

    关键：每点击一个 h4 就立即处理其按钮，不等所有 h4 展开后再处理。

    Args:
        page: Playwright Page 对象
        url: FAQ 分类页 URL

    Returns:
        爬取结果字典
    """
    # 打开页面
    logger.info(f"正在打开 FAQ 页面: {url}")
    await page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)

    # 等待至少一个 h5 子内容标识出现（说明页面内容已渲染完成）
    try:
        await page.wait_for_selector(SUB_CONTENT_SELECTOR, timeout=20000)
        logger.info("h5 子内容标识已出现，页面内容已渲染")
    except Exception:
        logger.warning("未检测到 h5 子内容标识，尝试继续处理")

    # 等待分组按钮和子分类按钮组件渲染
    try:
        await page.wait_for_selector(CATEGORY_BUTTON_SELECTOR, timeout=15000)
        cat_count = await page.locator(CATEGORY_BUTTON_SELECTOR).count()
        logger.info(f"分组按钮组件已加载，当前 {cat_count} 个")
    except Exception:
        logger.error("未检测到分组按钮组件，页面结构可能已变更")
        return {"crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "url": url, "results": [], "error": "category button not found"}

    try:
        await page.wait_for_selector(BUTTON_SELECTOR, timeout=10000)
        btn_count = await page.locator(BUTTON_SELECTOR).count()
        logger.info(f"按钮组件已加载，当前可见 {btn_count} 个按钮")
    except Exception:
        logger.warning("未检测到按钮组件，尝试继续处理")

    all_results = []
    processed_category_ids = set() # 已处理的分组按钮 id 集合
    processed_buttons_total = 0
    all_crawled_links = []  # 收集本次爬取的所有子链接（用于追加写入全局链接文件）

    while True:
        # 动态获取分组按钮列表（点击分组按钮可能新增更多分组按钮）
        category_infos = await page.evaluate("""
            () => {
                const SEL = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-contained.faq-category__button.faq-has-subcategory.MuiButton-fullWidth';
                const btns = Array.from(document.querySelectorAll(SEL));
                return btns.map((btn, idx) => ({
                    index: idx,
                    id: btn.id || '',
                    text: btn.innerText.trim(),
                    ariaExpanded: btn.getAttribute('aria-expanded')
                }));
            }
        """)

        # 找到第一个未处理过的分组按钮（用 id 判断）
        target = None
        for info in category_infos:
            if info["id"] and info["id"] not in processed_category_ids:
                target = info
                break

        if target is None:
            logger.info(f"所有分组按钮已处理完毕（共 {len(category_infos)} 个）")
            break

        target_index = target["index"]
        target_id = target["id"]
        target_text = target["text"]
        is_expanded = target["ariaExpanded"] == "true"

        # 立即标记为已处理（避免无限循环）
        processed_category_ids.add(target_id)

        logger.info(f"\n{'='*50}")
        logger.info(f"分组按钮[{target_index}/{len(category_infos)}]: {target_text} (id={target_id}, 已处理 {len(processed_category_ids)} 个)")

        # 点击分组按钮展开（如果已经展开则不需要点击）
        if not is_expanded:
            try:
                # 用 id 精确定位并点击（id 可能以数字开头，CSS 选择器不合法，用 xpath）
                cat_btn = page.locator(f'//*[@id="{target_id}"]')
                await cat_btn.click()
                await page.wait_for_timeout(random.randint(800, 1500))
                try:
                    await page.wait_for_selector(SUB_CONTENT_SELECTOR, timeout=10000)
                except Exception:
                    pass
                logger.info(f"  已点击展开分组: {target_text}")
            except Exception as e:
                logger.warning(f"  点击分组按钮失败: {e}")
                processed_category_ids.add(target_id)
                continue
        else:
            logger.info(f"  分组已展开，无需点击")

        # 查询当前分组下可见的子分类按钮
        # DOM 结构：分组按钮与 MuiCollapse-container 是兄弟关系，按钮在 Collapse 容器内
        all_btn_infos = await page.evaluate("""
            ([targetId]) => {
                const BTN_SEL = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-text.faq-subcategory.faq-category__button';
                const CAT_SEL = 'button.MuiButtonBase-root.MuiButton-root.MuiButton-contained.faq-category__button.faq-has-subcategory.MuiButton-fullWidth';
                // 找到当前分组按钮元素
                const catBtn = document.getElementById(targetId);
                if (!catBtn) return [];
                // 分组按钮的父级 div 与 MuiCollapse-container 是兄弟关系
                const catParent = catBtn.closest('div');
                const collapseDiv = catParent ? catParent.nextElementSibling : null;
                if (!collapseDiv) return [];
                // 从 Collapse 容器中获取子分类按钮
                const btns = Array.from(collapseDiv.querySelectorAll(BTN_SEL));
                return btns.map((btn, idx) => ({
                    globalIndex: idx,
                    text: btn.innerText.trim()
                }));
            }
        """, [target_id])

        logger.info(f"  当前分组下找到 {len(all_btn_infos)} 个子分类按钮")
        if all_btn_infos:
            logger.info(f"  按钮: {[b['text'] for b in all_btn_infos]}")

        # 逐个点击子分类按钮
        for btn_idx, btn_info in enumerate(all_btn_infos):
            btn_text = btn_info["text"]

            logger.info(f"  点击按钮 [{btn_idx + 1}/{len(all_btn_infos)}]: {btn_text}")

            try:
                # 先滚动回页面顶部
                await page.evaluate("window.scrollTo(0, 0)")

                # 点击按钮（带重试）
                clicked = await click_button_with_retry(page, btn_text)
                if not clicked:
                    logger.error(f"    按钮 '{btn_text}' 重试 3 次仍失败，跳过")
                    continue

                # 等待子内容加载（轮询等待 h5，最长 30 秒）
                h5_appeared = await wait_for_sub_content(page, max_wait_seconds=30)
                if not h5_appeared:
                    logger.warning(f"    h5 未出现，尝试继续获取链接")

                # 额外等待 1-3 秒，确保数据完全渲染
                await page.wait_for_timeout(random.randint(1000, 3000))

                # 持续向下滚动窗口获取所有懒加载的子链接
                final_count = await scroll_to_load_all(page)
                logger.info(f"    滚动加载完成，页面链接数: {final_count}")

                # 提取去重后的子链接
                unique_links = await extract_unique_links(page)
                logger.info(f"    获取子链接 {len(unique_links)} 个")

                all_crawled_links.extend(unique_links)

                all_results.append({
                    "category": target_text,
                    "category_id": target_id,
                    "button": btn_text,
                    "button_index": btn_idx,
                    "link_count": len(unique_links),
                    "links": unique_links,
                })
                processed_buttons_total += 1

            except Exception as e:
                logger.error(f"    处理按钮失败: {btn_text}, 错误: {e}")
                continue

        # 当前 h4 的按钮处理完毕，循环回到 while True 重新获取 h4 列表
        # （点击 h4 可能新增了更多 h4，需要动态发现）

    # 汇总结果
    total_links = sum(r["link_count"] for r in all_results)
    unique_category_set = set(r["category"] for r in all_results)

    # 将本次爬取的所有子链接追加写入全局唯一链接文件
    if all_crawled_links:
        save_links_to_all_unique_file(all_crawled_links)

    result = {
        "crawl_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "url": url,
        "total_categories": len(unique_category_set),
        "total_buttons": processed_buttons_total,
        "total_links": total_links,
        "results": all_results,
    }

    return result


# ==================== 主流程 ====================

async def run(url: str, output: str, use_cdp: bool = True,
              cdp_port: int = CDP_DEBUG_PORT, headless: bool = True):
    """
    主流程

    Args:
        url: FAQ 分类页 URL
        output: 输出 JSON 文件路径
        use_cdp: 是否使用 CDP 连接已运行的 Chrome
        cdp_port: CDP 调试端口
        headless: 是否无头模式
    """
    url = ensure_https(url)

    async with async_playwright() as p:
        browser = None
        cdp_browser = None
        ctx = None

        try:
            if use_cdp:
                cdp_url = f"http://127.0.0.1:{cdp_port}"
                logger.info(f"正在通过 CDP 连接已运行的 Chrome: {cdp_url}")
                cdp_browser = await p.chromium.connect_over_cdp(
                    endpoint_url=cdp_url,
                    timeout=30000,
                )
                contexts = cdp_browser.contexts
                if contexts:
                    ctx = contexts[0]
                    logger.info(f"已连接 Chrome，复用现有 context（共 {len(contexts)} 个）")
                else:
                    ctx = await cdp_browser.new_context(
                        viewport={"width": 1920, "height": 1080},
                        user_agent=USER_AGENT,
                    )
                    logger.info("已连接 Chrome，创建新 context")
            else:
                chrome_path = _find_chrome_path()
                if chrome_path:
                    logger.info(f"使用本地 Chrome: {chrome_path}")
                    browser = await p.chromium.launch(
                        executable_path=chrome_path,
                        headless=headless,
                        args=CHROMIUM_ARGS,
                    )
                else:
                    logger.info("使用 Playwright 自带的 Chromium")
                    browser = await p.chromium.launch(
                        headless=headless,
                        args=CHROMIUM_ARGS,
                    )
                ctx = await browser.new_context(
                    viewport={"width": 1920, "height": 1080},
                    user_agent=USER_AGENT,
                )

            page = await ctx.new_page()

            # 执行爬取
            result = await crawl_faq(page, url)

            # 保存结果
            output_path = Path(output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)

            logger.info(f"\n{'='*50}")
            logger.info(f"爬取完成！")
            logger.info(f"  分组分类数: {result['total_categories']}")
            logger.info(f"  按钮总数: {result['total_buttons']}")
            logger.info(f"  子链接总数: {result['total_links']}")
            logger.info(f"  结果已保存到: {output_path}")

        except Exception as e:
            logger.error(f"处理出错: {e}")
            import traceback
            traceback.print_exc()
        finally:
            if browser:
                try:
                    await browser.close()
                except Exception:
                    pass
            if cdp_browser:
                try:
                    await cdp_browser.close()
                except Exception:
                    pass


def main():
    """脚本入口"""
    parser = argparse.ArgumentParser(description="爬取 support.tokyostarbank.co.jp FAQ 动态站点")
    parser.add_argument(
        "--url",
        type=str,
        default=DEFAULT_FAQ_URL,
        help=f"FAQ 分类页 URL（默认: {DEFAULT_FAQ_URL}）",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(DEFAULT_OUTPUT),
        help=f"输出 JSON 文件路径（默认: {DEFAULT_OUTPUT}）",
    )
    parser.add_argument(
        "--local-chromium",
        action="store_true",
        help="使用本地 Playwright Chromium（默认通过 CDP 连接已运行的 Chrome）",
    )
    parser.add_argument(
        "--cdp-port",
        type=int,
        default=CDP_DEBUG_PORT,
        help=f"CDP 调试端口（默认 {CDP_DEBUG_PORT}）",
    )
    parser.add_argument(
        "--visible",
        action="store_true",
        help="显示浏览器窗口（仅 --local-chromium 模式生效，调试用）",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=60,
        help="页面超时秒数（默认 60）",
    )

    args = parser.parse_args()

    global PAGE_TIMEOUT
    PAGE_TIMEOUT = args.timeout * 1000

    use_cdp = not args.local_chromium
    headless = not args.visible

    asyncio.run(run(
        url=args.url,
        output=args.output,
        use_cdp=use_cdp,
        cdp_port=args.cdp_port,
        headless=headless,
    ))


if __name__ == "__main__":
    main()

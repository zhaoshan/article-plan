-- Email verification for registration (2026-11-05): verification codes with 10-minute TTL.
-- Existing migrations are immutable; this file is additive only.

-- gateway_user.email_verified 列自 V1 已存在（此前无业务使用，2026-11-05 注册验证码链路激活其语义：
-- 0=未验证禁止登录 / 1=已验证）。
-- 存量回填 1：既有账号与 JIT 邀请账号先于该能力存在，视为已验证（邀请链接点击即邮箱归属证明）。
UPDATE `gateway_user` SET `email_verified` = 1 WHERE `email_verified` = 0;

-- 验证码表：明文验证码绝不落库（只存 SHA-256 hash）；PENDING 有效期 10 分钟。
CREATE TABLE `gateway_email_verification` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `verification_id` CHAR(32) NOT NULL COMMENT '验证码业务唯一标识',
  `email` VARCHAR(255) NOT NULL COMMENT '目标邮箱（小写归一）',
  `purpose` VARCHAR(32) NOT NULL DEFAULT 'REGISTER' COMMENT '用途：REGISTER（预留 RESET 等）',
  `code_hash` CHAR(64) NOT NULL COMMENT '验证码 SHA-256（明文不落库）',
  `verification_status` VARCHAR(16) NOT NULL DEFAULT 'PENDING' COMMENT '状态：PENDING/VERIFIED/EXPIRED/REVOKED',
  `attempts` INT NOT NULL DEFAULT 0 COMMENT '已校验次数（≥5 作废，防爆破）',
  `expires_at` DATETIME NOT NULL COMMENT '过期时间（10 分钟）',
  `verified_at` DATETIME DEFAULT NULL COMMENT '校验通过时间',
  `delete_flag` TINYINT NOT NULL DEFAULT 0 COMMENT '0正常 1删除',
  `create_by` VARCHAR(64) DEFAULT NULL COMMENT '创建人',
  `update_by` VARCHAR(64) DEFAULT NULL COMMENT '最后修改人',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_email_verification_id` (`verification_id`),
  KEY `idx_email_verification_lookup` (`email`, `purpose`, `verification_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='邮箱验证码（注册验证，10 分钟有效，2026-11-05）';

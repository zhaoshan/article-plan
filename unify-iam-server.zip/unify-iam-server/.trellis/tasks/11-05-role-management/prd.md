# Role management backend

## Goal
Improve role management with tenant attribution, optional generated role codes and authorized listing filters.

## Requirements and acceptance
- List items expose tenant_name from the tenant identified by TENANT scope_id, loaded in one batch; missing/blank scopes and missing/deleted tenants have no name. No N+1 lookups.
- Preserve existing scope_type/scope_id authorization semantics, global platform listing, tenant isolation, disabled visibility, logical deletion, id ordering and unpaginated {roles,count} envelope.
- Add filter_scope_type (comma-separated PLATFORM/TENANT OR), filter_scope_id (exact tenant ID), keyword (literal contains on role_name OR role_description). Dimensions combine with AND and cannot broaden access.
- Omitted filters preserve existing requests. Blank keyword means no search; blank tenant filter means no filtering. Supplied empty/malformed scope-type lists return 400.
- POST accepts omitted/null/blank role_code and generates role_<32-hex UUID>; explicit nonblank codes remain supported and trimmed. Generated values are persisted and audited. PUT remains immutable for role_code.
- Tests cover binding, batch enrichment, filtering and authorization, persisted creation and audit behavior.

## Constraints
Only this project/main checkout. Preserve unrelated dirty files. No commits, pushes, merges, branch changes/resets or worktrees. Frontend implementation belongs to its independent task.

## Authorization
User explicitly directed: “上述问题分析完成之后，立即实施”. This supersedes additional task/planning confirmation gates. Contract was supplied in the delegation and synchronized with the frontend task.

package com.unify.iam.app.app.service.admin;

import com.unify.iam.api.dto.admin.CreateTenantRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.authorization.app.model.AppRoleTemplate;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.InvitationService;
import com.unify.iam.app.app.service.JitLocalAccountService;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.mail.InvitationMailService;
import com.unify.iam.app.security.TenantScopeGuard;
import com.unify.iam.app.app.service.TenantAppProvisionService;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 管理面租户服务（docs/04 §3.2，iam:tenant:*）。
 *
 * <p>docs/06 §2.3 / §5.3：建租户时按「显式选择的启用应用」查预置角色模板
 * （{@link TenantAppProvisionService} 灌入角色 + owner 授 is_owner + 登记租户↔应用），
 * 可选 {@code owner_user_id} 建首人成员。新增应用 = 插数据，不改代码。
 */
@Service
public class AdminTenantService {

    private final TenantRepository tenantRepository;
    private final MembershipRepository membershipRepository;
    private final UserRepository userRepository;
    private final TenantScopeGuard tenantScopeGuard;
    private final TenantAppProvisionService tenantAppProvisionService;
    private final TokenVersionService tokenVersionService;
    private final AuditService auditService;
    private final JitLocalAccountService jitLocalAccountService;
    private final InvitationService invitationService;
    private final InvitationMailService invitationMailService;
    private final com.unify.iam.app.app.service.QuotaService quotaService;

    public AdminTenantService(TenantRepository tenantRepository,
                              MembershipRepository membershipRepository,
                              UserRepository userRepository,
                              TenantScopeGuard tenantScopeGuard,
                              TenantAppProvisionService tenantAppProvisionService,
                              TokenVersionService tokenVersionService,
                              AuditService auditService,
                              JitLocalAccountService jitLocalAccountService,
                              InvitationService invitationService,
                              InvitationMailService invitationMailService,
                              com.unify.iam.app.app.service.QuotaService quotaService) {
        this.tenantRepository = tenantRepository;
        this.membershipRepository = membershipRepository;
        this.userRepository = userRepository;
        this.tenantScopeGuard = tenantScopeGuard;
        this.tenantAppProvisionService = tenantAppProvisionService;
        this.tokenVersionService = tokenVersionService;
        this.auditService = auditService;
        this.jitLocalAccountService = jitLocalAccountService;
        this.invitationService = invitationService;
        this.invitationMailService = invitationMailService;
        this.quotaService = quotaService;
    }

    @Transactional
    public String create(CreateTenantRequest request) {
        List<AppRoleTemplate> templates = tenantAppProvisionService.loadForApps(request.appCodes());
        TenantPO tenant = new TenantPO();
        tenant.setTenantId(IdGenerator.newBizId());
        tenant.setTenantCode(request.tenantCode().trim());
        tenant.setTenantName(request.tenantName().trim());
        tenant.setTenantType(request.tenantType() == null ? "ORGANIZATION" : request.tenantType());
        tenant.setTenantStatus("ACTIVE");
        tenant.setRegistrationSource("ADMIN");
        tenant.setPrimaryDomain(request.primaryDomain() == null ? null : request.primaryDomain().trim());
        tenant.setJoinPolicy("INVITE_ONLY");
        tenantRepository.create(tenant);
        tenantAppProvisionService.seedTemplates(tenant.getTenantId(), templates);
        quotaService.assertAppCount(tenant.getTenantId(), request.appCodes().size()); // G1：应用数强制
        tenantAppProvisionService.recordTenantApps(tenant.getTenantId(), request.appCodes());
        if (request.ownerUserId() != null && !request.ownerUserId().isBlank()) {
            createOwnerMembership(tenant.getTenantId(), request.ownerUserId().trim(), templates);
        } else if (request.ownerEmail() != null && !request.ownerEmail().isBlank()) {
            // G2 A-02「Create and send invite」：任意 Owner 邮箱（不存在则 JIT 建号 + 初始密码）→ 发 Owner 邀请邮件
            String em = request.ownerEmail().trim().toLowerCase();
            JitLocalAccountService.ProvisionResult provisioned = jitLocalAccountService.provisionIfAbsent(em);
            createOwnerMembership(tenant.getTenantId(), provisioned.userId(), templates);
            // G2 增强（产品口径）：邀请必传角色——建租户邀请的角色 = is_owner=1 模板角色（如 iMorph-Owner）
            String ownerRoleId = tenantAppProvisionService.findOwnerRoleId(tenant.getTenantId(), templates);
            InvitationService.Issued issued =
                    invitationService.issueForTenant(tenant.getTenantId(), em, ownerRoleId);
            invitationMailService.sendOwnerInvitation(em, tenant.getTenantName(),
                    provisioned.initialPassword(), issued.expiresAt(), issued.token());
        }
        return tenant.getTenantId();
    }

    public List<TenantPO> list(int limit) {
        return tenantRepository.listAll(limit);
    }

    public void update(JwtClaims claims, String tenantId, Map<String, String> fields) {
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        TenantPO tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> AuthException.notFound("租户不存在"));
        String oldStatus = tenant.getTenantStatus();
        String oldName = tenant.getTenantName();
        String oldDomain = tenant.getPrimaryDomain();
        String newStatus = fields.get("tenant_status");
        if (fields.get("tenant_name") != null) {
            tenant.setTenantName(fields.get("tenant_name"));
        }
        if (newStatus != null) {
            tenant.setTenantStatus(newStatus.trim());
        }
        if (fields.get("primary_domain") != null) {
            tenant.setPrimaryDomain(fields.get("primary_domain"));
        }
        tenantRepository.update(tenant);
        // G1：租户转为非 ACTIVE（停用）→ 该租户所有 ACTIVE 成员批量 bump，已登录 token 即时失效
        if (newStatus != null && !"ACTIVE".equals(newStatus.trim()) && !newStatus.trim().equals(oldStatus)) {
            tokenVersionService.bumpForTenant(tenantId, "TENANT_DISABLED");
        }
        // G5-b：租户变更（启停/改名/域名）审计，含变更前后值
        Map<String, Object> before = new LinkedHashMap<>();
        before.put("tenant_status", oldStatus);
        before.put("tenant_name", oldName);
        before.put("primary_domain", oldDomain);
        Map<String, Object> after = new LinkedHashMap<>();
        after.put("tenant_status", tenant.getTenantStatus());
        after.put("tenant_name", tenant.getTenantName());
        after.put("primary_domain", tenant.getPrimaryDomain());
        auditService.audit().event("ADMIN_UPDATE_TENANT").actor(claims.userId())
                .tenant(tenantId).target("TENANT", tenantId)
                .before(before).after(after).write(Map.of("fields", fields));
    }

    public void delete(JwtClaims claims, String tenantId) {
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        tenantRepository.findById(tenantId).orElseThrow(() -> AuthException.notFound("租户不存在"));
        // G1：删除前批量 bump（删除后成员仍保留，但 token 失效）
        tokenVersionService.bumpForTenant(tenantId, "TENANT_REMOVED");
        tenantRepository.logicalDelete(tenantId);
        // G5-b：租户删除审计
        auditService.audit().event("ADMIN_DELETE_TENANT").actor(claims.userId())
                .tenant(tenantId).target("TENANT", tenantId).write(Map.of());
    }

    /**
     * 建首人成员（OWNER 加入）并授启用应用中 {@code is_owner} 的模板角色（docs/06 §3.1）。
     * {@code is_default} 仅在用户没有「租户仍有效」的默认成员时置 1（保证可登录）；
     * 已有有效默认（如已是别的租户 owner）则置 0——避免同一用户多个 is_default=1 导致登录歧义；
     * 若唯一默认落在已删/停用租户，则本新成员接管默认（否则登录仍指向已删租户而失败）。
     */
    private void createOwnerMembership(String tenantId, String userId, List<AppRoleTemplate> templates) {
        userRepository.findByUserId(userId).orElseThrow(() -> AuthException.notFound("用户不存在"));
        if (membershipRepository.findByTenantAndUser(tenantId, userId).isPresent()) {
            return;
        }
        boolean hasValidDefault = membershipRepository.findDefaultActive(userId)
                .map(m -> tenantRepository.findById(m.getTenantId().trim())
                        .map(t -> "ACTIVE".equals(t.getTenantStatus())).orElse(false))
                .orElse(false);
        MembershipPO po = new MembershipPO();
        po.setMembershipId(IdGenerator.newBizId());
        po.setTenantId(tenantId);
        po.setUserId(userId);
        po.setMembershipStatus("ACTIVE");
        po.setJoinSource("OWNER");
        if (hasValidDefault) {
            po.setIsDefault(0);
        } else {
            // 接管默认：先清掉旧的（含已删/停用租户里的）默认标记，保证一用户恰一个 is_default=1
            membershipRepository.clearDefault(userId);
            po.setIsDefault(1);
        }
        membershipRepository.create(po);
        tenantAppProvisionService.grantOwnerRoles(po.getMembershipId(), tenantId, templates);
    }
}

package com.unify.iam.app;

import com.unify.iam.api.dto.auth.LoginTarget;
import com.unify.iam.api.dto.auth.LoginTarget.Decision;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.app.service.LoginTargetService;
import com.unify.iam.app.config.IamProperties;
import com.unify.iam.authorization.infra.persistence.po.ApplicationPO;
import com.unify.iam.authorization.infra.persistence.repository.*;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.*;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class LoginTargetServiceTest {
    private final MembershipResolver memberships = mock(MembershipResolver.class);
    private final TenantApplicationRepository tenantApps = mock(TenantApplicationRepository.class);
    private final ApplicationRepository apps = mock(ApplicationRepository.class);
    private final TenantRepository tenants = mock(TenantRepository.class);
    private final RoleRepository roles = mock(RoleRepository.class);
    private final IamProperties props = new IamProperties();
    private final LoginTargetService service = new LoginTargetService(memberships, tenantApps, apps, tenants, roles, props);
    private ApplicationPO app;

    @BeforeEach
    void setup() {
        props.getJwt().setAudiences(List.of("business", "other"));
        props.getOidc().setAllowedReturnOrigins(List.of("https://business.test", "https://other.test"));
        app = new ApplicationPO();
        app.setAppCode("business"); app.setAppName("Business"); app.setHomepageUrl("https://business.test/home");
        when(apps.findActiveByCodes(anyCollection())).thenReturn(List.of(app));
        var initial = member("m1", "t1");
        when(memberships.listByUser("u1")).thenReturn(List.of(initial));
    }

    private MembershipPO member(String id, String tenantId) {
        MembershipPO m = new MembershipPO();
        m.setMembershipId(id); m.setUserId("u1"); m.setTenantId(tenantId); m.setMembershipStatus("ACTIVE");
        TenantPO t = new TenantPO(); t.setTenantId(tenantId); t.setTenantName(tenantId); t.setTenantStatus("ACTIVE");
        when(tenants.findById(tenantId)).thenReturn(Optional.of(t));
        when(tenantApps.findAppCodesByTenant(tenantId)).thenReturn(List.of("business"));
        return m;
    }

    private JwtClaims claims(String tenant, String membership, List<String> audiences) {
        return new JwtClaims("issuer", audiences, "u1", tenant, membership, List.of(), List.of(), Map.of(), 9999999999L, 0, "jti", 0);
    }

    private LoginTarget.Resolution resolve(String appCode, String callback, String membership) {
        return service.resolve(claims("t1", "m1", List.of("business")), new LoginTarget.Request(appCode, callback, membership));
    }

    @Test void currentTenantReceivesValidatedCallback() {
        var result = resolve("business", "https://business.test/callback?next=orders#tab", null);
        assertThat(result.decision()).isEqualTo(Decision.REDIRECT);
        assertThat(result.callbackUrl()).isEqualTo("https://business.test/callback?next=orders#tab");
        assertThat(result.membership().membershipId()).isEqualTo("m1");
    }

    @Test void absentCallbackUsesConfiguredHomepage() {
        assertThat(resolve("business", null, null).callbackUrl()).isEqualTo("https://business.test/home");
        app.setHomepageUrl(null);
        props.getAppHomepages().put("business", "https://business.test/fallback");
        assertThat(resolve("business", null, null).callbackUrl()).endsWith("/fallback");
    }

    @Test void absentAppRequiresApplicationChoice() {
        var result = resolve(null, null, null);
        assertThat(result.decision()).isEqualTo(Decision.CHOOSE_APPLICATION);
        assertThat(result.applications()).hasSize(1);
    }

    @Test void globalAllowlistCannotAuthorizeAnotherApplicationOrigin() {
        assertBadCallback("https://other.test/callback");
        assertBadCallback("https://business.test.evil.test/callback");
        assertBadCallback("https://business.test@other.test/callback");
        assertBadCallback("javascript:alert(1)");
        assertBadCallback("//business.test/callback");
    }

    @Test void applicationOriginMustAlsoBeGloballyAllowed() {
        props.getOidc().setAllowedReturnOrigins(List.of());
        assertBadCallback("https://business.test/callback");
    }

    @Test void extraApplicationOriginStillRequiresGlobalAllowlist() {
        props.getAppReturnOrigins().put("business", List.of("https://other.test"));
        assertThat(resolve("business", "https://other.test/callback", null).decision()).isEqualTo(Decision.REDIRECT);
        props.getOidc().setAllowedReturnOrigins(List.of("https://business.test"));
        assertBadCallback("https://other.test/callback");
    }

    @Test void normalizesDefaultPortAndHostname() {
        assertThat(resolve("business", "https://BUSINESS.test:443/callback", null).decision()).isEqualTo(Decision.REDIRECT);
    }

    @Test void missingHomepageIsConfigurationFailureRatherThanAccessDenial() {
        app.setHomepageUrl(null);
        assertThatThrownBy(() -> resolve("business", null, null)).isInstanceOfSatisfying(AuthException.class,
                e -> assertThat(e.getHttpStatus()).isEqualTo(503));
    }

    @Test void multipleMembershipsRequireExplicitSelectionEvenForCurrentTenant() {
        var first = member("m1", "t1");
        var second = member("m2", "t2");
        when(memberships.listByUser("u1")).thenReturn(List.of(first, second));
        var result = resolve("business", null, null);
        assertThat(result.decision()).isEqualTo(Decision.CHOOSE_TENANT);
        assertThat(result.memberships()).hasSize(2);
        var selected = resolve("business", null, "m2");
        assertThat(selected.decision()).isEqualTo(Decision.SWITCH_TENANT);
        assertThat(selected.callbackUrl()).isNull();
        assertThat(service.resolve(claims("t2", "m2", List.of("business")),
                new LoginTarget.Request("business", null, "m2")).decision()).isEqualTo(Decision.REDIRECT);
    }

    @Test void foreignOrRemovedMembershipCannotBeSelected() {
        assertThatThrownBy(() -> resolve("business", null, "someone-elses-membership"))
                .isInstanceOfSatisfying(AuthException.class, e -> assertThat(e.getHttpStatus()).isEqualTo(403));
    }

    @Test void tokenMustContainTargetAudienceBeforeHandoff() {
        assertThatThrownBy(() -> service.resolve(claims("t1", "m1", List.of("other")),
                new LoginTarget.Request("business", null, null)))
                .isInstanceOfSatisfying(AuthException.class, e -> assertThat(e.getHttpStatus()).isEqualTo(403));
    }

    @Test void disabledApplicationCannotBeSelectedAndAdminCanReturnToConsole() {
        when(apps.findActiveByCodes(anyCollection())).thenReturn(List.of());
        assertThat(resolve("business", null, null).decision()).isEqualTo(Decision.DENIED);
        when(roles.hasPlatformRoleByMembership("m1")).thenReturn(true);
        assertThat(resolve("business", null, null).decision()).isEqualTo(Decision.IAM_CONSOLE);
        assertThat(resolve(null, null, null).decision()).isEqualTo(Decision.IAM_CONSOLE);
    }

    @Test void excludedOrSuspendedMembershipsAndDisabledTenantsCannotEnterCatalog() {
        var member = member("m2", "t2"); member.setMembershipStatus("SUSPENDED");
        when(memberships.listByUser("u1")).thenReturn(List.of(member));
        when(apps.findActiveByCodes(anyCollection())).thenReturn(List.of());
        assertThat(service.catalog("u1").applications()).isEmpty();
        member.setMembershipStatus("ACTIVE");
        var tenant = new TenantPO(); tenant.setTenantStatus("DISABLED");
        when(tenants.findById("t2")).thenReturn(Optional.of(tenant));
        assertThat(service.catalog("u1").applications()).isEmpty();
    }

    @Test void callbackWithoutAppIsNotInferredFromUrl() {
        assertThatThrownBy(() -> resolve(null, "https://business.test", null)).isInstanceOfSatisfying(AuthException.class,
                e -> assertThat(e.getHttpStatus()).isEqualTo(400));
    }

    private void assertBadCallback(String callback) {
        assertThatThrownBy(() -> resolve("business", callback, null)).isInstanceOfSatisfying(AuthException.class,
                e -> assertThat(e.getHttpStatus()).isEqualTo(400));
    }
}

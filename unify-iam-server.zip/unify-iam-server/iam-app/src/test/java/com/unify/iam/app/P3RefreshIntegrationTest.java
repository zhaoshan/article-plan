package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.dto.auth.RefreshRequest;
import com.unify.iam.common.util.JsonUtils;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * P3 refresh token 集成测试：登录带回 refresh → 轮换 → 旧 refresh 失效 → logout 撤销。
 */
class P3RefreshIntegrationTest extends IamIntegrationTestBase {

    private LoginResponse login() throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"operator\",\"password\":\"op123\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class);
    }

    private LoginResponse refresh(String refreshToken) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(new RefreshRequest(refreshToken))))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class);
    }

    @Test
    void loginReturnsRefreshTokenAndRotationWorks() throws Exception {
        LoginResponse first = login();
        assertThat(first.accessToken()).isNotBlank();
        assertThat(first.refreshToken()).isNotBlank();

        // 轮换：新 access + 新 refresh
        LoginResponse rotated = refresh(first.refreshToken());
        assertThat(rotated.accessToken()).isNotBlank().isNotEqualTo(first.accessToken());
        assertThat(rotated.refreshToken()).isNotBlank().isNotEqualTo(first.refreshToken());

        // 新 access 可用
        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + rotated.accessToken()))
                .andExpect(status().isOk());

        // 旧 refresh 已被轮换作废 → 401
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(new RefreshRequest(first.refreshToken()))))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void logoutRevokesRefreshToken() throws Exception {
        LoginResponse loginResp = login();
        assertThat(loginResp.refreshToken()).isNotBlank();

        mockMvc.perform(post("/api/v1/auth/logout")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(new RefreshRequest(loginResp.refreshToken()))))
                .andExpect(status().isOk());

        // 撤销后 refresh → 401
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(new RefreshRequest(loginResp.refreshToken()))))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void invalidRefreshTokenRejected() throws Exception {
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"refresh_token\":\"not-a-real-token\"}"))
                .andExpect(status().isUnauthorized());
    }
}
package com.unify.iam.app.adapter.controller;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.api.dto.auth.SwitchTenantRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.api.model.UserPrincipal;
import com.unify.iam.app.app.service.TokenService;
import com.unify.iam.app.security.JwtAuth;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.identity.infra.persistence.po.UserPO;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import jakarta.validation.Valid;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 多租户切换（docs/04 §3.4）：令牌仍单租户语义，切换 = 用目标 membership 重签。
 *
 * <p>位于 /api/v1/auth/**（不拦截），凭 Bearer 认证（JwtAuth 验签）。
 */
@RestController
@RequestMapping("/api/v1/auth")
public class SwitchTenantController {

    private final JwtSigner jwtSigner;
    private final TokenService tokenService;
    private final MembershipResolver membershipResolver;
    private final UserRepository userRepository;
    private final TenantRepository tenantRepository;
    private final com.unify.iam.app.app.service.MembershipMenuService membershipMenuService;

    public SwitchTenantController(JwtSigner jwtSigner,
                                  TokenService tokenService,
                                  MembershipResolver membershipResolver,
                                  UserRepository userRepository,
                                  TenantRepository tenantRepository,
                              com.unify.iam.app.app.service.MembershipMenuService membershipMenuService) {
        this.jwtSigner = jwtSigner;
        this.tokenService = tokenService;
        this.membershipResolver = membershipResolver;
        this.userRepository = userRepository;
        this.tenantRepository = tenantRepository;
        this.membershipMenuService = membershipMenuService;
    }

    /** 切换到目标租户（校验该 membership 属于当前用户），返回新 access + refresh。 */
    @PostMapping("/switch-tenant")
    public LoginResponse switchTenant(@RequestHeader(value = "Authorization", required = false) String authorization,
                                      @Valid @RequestBody SwitchTenantRequest request) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        MembershipPO membership = membershipResolver.findById(request.membershipId().trim())
                .filter(m -> m.getUserId().equals(claims.userId())
                        && "ACTIVE".equals(m.getMembershipStatus()))
                .orElseThrow(() -> AuthException.forbidden("无权切换到该租户"));
        // 租户必须仍存在且 ACTIVE（逻辑删除/停用的租户不可切换，防"已删仍可切换"）
        tenantRepository.findById(membership.getTenantId().trim())
                .filter(t -> "ACTIVE".equals(t.getTenantStatus()))
                .orElseThrow(() -> AuthException.forbidden("租户不可用或已删除"));
        UserPO user = userRepository.findByUserId(claims.userId())
                .orElseThrow(() -> AuthException.unauthorized("用户不存在"));
        return tokenService.issueWithRefresh(
                        new UserPrincipal(user.getUserId(), user.getUsername(), null), membership)
                .withMustChangePassword((user.getMustChangePassword() != null && user.getMustChangePassword() == 1));
    }

    /** 当前用户的可切换成员列表（前端租户选择器数据源）。 */
    @GetMapping("/memberships")
    public Map<String, Object> memberships(@RequestHeader(value = "Authorization", required = false) String authorization) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        // G9：菜单增强字段（tenant_type/roles/is_owner/is_current/last_opened_at/created_at）
        List<Map<String, Object>> list = membershipMenuService.listForMenu(claims.userId(), claims.membershipId());
        return Map.of("memberships", list, "count", list.size());
    }
}

# unify-iam-server — Claude 项目说明（CLAUDE.md）

Gateway 权限体系 IAM 服务：统一身份与权限控制面（身份 / 租户 / 纯 RBAC / 企业 SSO / 令牌签发）。
技术栈：Java 21 · Spring Boot 3.5.9 · Maven 多模块 · MyBatis-Plus 3.5.9 · Nimbus JOSE · Flyway · Testcontainers。

## 文档导航（动手前先读相关设计）
- `docs/01-总体设计与功能模块拆分.md`：总体模块/包设计 + 开发阶段拆分（P1-P6）+ 签名私钥管理规范
- `docs/02-E2E1-首阶段实现方案.md`：E2E-1（登录/RBAC/令牌）已交付
- `docs/03-E2E2-企业SSO与组织接入.md`：E2E-2（OIDC SSO/JIT/组映射）已交付，附录 A 为实现记录
- `docs/04-E2E3-P3管理面与账号生命周期设计.md`：P3 设计方案（管理面/refresh/多租户/审计）
- `docs/05-IAM前端管理台与统一登录设计.md`：platform-iam-web 前端设计
- `docs/06-应用角色模板与租户级管理面设计.md`：应用角色模板（表驱动 `iam_application_role_template`，建租户显式选 `app_codes`）+ 租户级管理面（`TenantScopeGuard` 作用域分层），已交付，附录 A/B/C 为实现记录
- `docs/07-管理面SSO配置-IdP配置与组角色映射.md`：P3.5（P3 管理面补充增量，非 P4）已交付——IdP/组映射管理 API（iam:idp:* 仅平台管理员）+ 管理台「SSO 配置」页；client_secret 加密为待办；应用模板管理不实现
- `docs/08-账号生命周期与租户协作-实施方案.md`：M10W4-W5 功能「怎么做」——密码重置邮件标准时序（SPA）+ G1-G8/S1/S2 实施索引（与 requirements/M10W4-W5 差距文档 What/How 互补）
- `docs/user-manual/`：用户操作手册——00 索引/角色矩阵、01 平台管理员（含附录 A 初始化数据表、附录 B API、parlant 示例）、02 租户管理员（纯界面）、03 业务系统接入指南、04 业务逻辑流程、05 API 接口梳理
- `docs/requirements/`：业务需求与能力差距——CommonCapabilities_M10W3.md（iMorph 多租户公共能力 PRD）、M10W3-能力盘点与IAM差距分析.md、M10W4-W5-能力差距与实施拆分.md（租户开通与成员协作 UI 设计 → IAM 缺口：配额/Owner 邮箱开通+邮件+初始密码/更换 Owner）
- 原始设计/契约源：`docs/original-design/`

## 构建与测试
```bash
# 全量（单元+Web+Testcontainers 集成）
mvn clean install
# 只跑集成（Testcontainers MySQL，需 Docker）
mvn -pl iam-app -am test -Dtest='IamFlowIntegrationTest,OidcSsoIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false
# 快速（跳过集成）
mvn -pl iam-app -am test -Dtest='!IamFlowIntegrationTest,!OidcSsoIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false
```
- 集成测试用**内置 Mock OIDC Provider**（`support/MockOidcProvider`），无镜像依赖；改 SSO 相关务必跑 `OidcSsoIntegrationTest`。
- 集成测试基类 `IamIntegrationTestBase` 用「手动单例容器」（static 一次性启动），**勿改回 `@Container` 继承**（会因子类间先停后复用而连不上库）。

## 架构要点（改代码前必读）
- 6 模块：`iam-common` / `iam-api` / `iam-identity` / `iam-tenant` / `iam-authorization` / `iam-app`（可启动）。
- **依赖方向**：三个业务模块互不依赖，只向下依赖 `iam-api`→`iam-common`；跨域编排一律在 `iam-app`。
- **令牌签发管线**：`TokenService.issueFor`（membership→RBAC→claims→sign）是唯一签发点；本地密码经 `LocalPasswordAuthenticator`、OIDC 经 `OidcAuthenticator`——**认证来源可插拔，管线不动**。新增登录方式只换认证器。
- **契约单一事实源**：`iam-api` 的 `AuthorizationContext`/`JwtClaims`/`PermissionCodes`（9 权限点）。

## 不可破坏的契约（锁死）
- JWT claims：`iss`（现 `https://www.identityfabric.com`）·`aud`（= 租户启用应用 ∩ `iam.jwt.audiences` 白名单，单值序列化为字符串、多值为数组，无应用记录租户回落全量；业务按自身 app_code ∈ aud 校验，勿改）·`sub`·`tenantId`·`membershipId`·`roles`·`permissions`·`attrs`·`exp/iat/jti`·`ver`（方案 c 即时吊销：签发时的 membership.token_version，旧 token 落后即失效）；RS256，kid=`iam-key-1`。
- **令牌单租户语义**：一个 token 只含一个激活 membership；多租户切换靠 `switch-tenant` 重签，不在 token 里塞多租户。
- **响应信封（统一）**：**全部 `/api/v1/**` JSON 接口**成功与失败都套 `{success,code,message,data}`（成功 `data` 为业务体，失败真实状态码 + `message` 为文案）；判定集中在 `EnvelopePaths.inScope`（`ApiEnvelopeAdvice` 套成功、`GlobalExceptionHandler` 套失败）。**仅 `/api/v1/auth/oidc/**` 排除**（OIDC 重定向流程：成功 302 带 token 回跳，错误保持 `{"detail":...}`）；`/.well-known/jwks.json` 天然裸 JWK Set。
- **密码字段线上 base64**：`password`/`old_password`/`new_password` 请求字段一律 base64（严格解码、无兼容明文期；登录入口解码失败走统一 401 防枚举）——审计形式要求，编码非加密、机密性靠 TLS。消费端（platform-iam-web `encodePassword`、parlant `auth.py`、测试 `b64()`）已同步，新增客户端必须遵守。
- **消费端同步解包**：业务系统消费 IAM 外部端点（parlant-agent `auth.py` 登录/刷新、`versions.py` 版本 feed）按 `data` 解包信封；改判定范围时同步 `platform-iam-web/src/api/client.ts`（按响应是否带 `success` 判别，成功透出 `data`）与 parlant 对应代码。**服务间端点**（`X-IAM-Service-Token` = `iam.versions.service-token`）：versions（版本 feed）、status-check（后台任务执行前校验任务归属的租户/成员是否仍有效，G4）、user-exists（G8 邮箱存在性判定 → `{exists, auth_mode}`，登录注册两段式）。`app-access` 为登录后能力检查；`session-status`/`tenant-status` 需 Bearer（tenant-status 限调用者成员关系防枚举）。
- **权限点目录**：`iam-api` 的 9 码与 parlant `permissions.py`、`gateway_permission` 同套 code，改一处同步另一处。

## 日志分层（2026-11-05 起）
- **① 访问日志**：`AccessLogFilter` 每个 /api/v1 请求一行（method/path/status/耗时/rid/actor/tenant）；query 只记参数名不记值。
- **② 失败日志**：`GlobalExceptionHandler`——4xx 业务拒绝 WARN（无堆栈）、5xx ERROR（带堆栈）；requestId 由 MDC 自动带入。
- **③ body 白名单**：仅 `@LogPayload` 注解端点输出请求体，**强制过 `LogMasks`**（password/token/secret 等字段名黑名单无条件打码，email 掩码）。凭据类端点（/auth/token、register、refresh、reset/change-password、SSO callback query）**永不声明**。
- **④ 点状日志**：关键链路口语化 INFO/WARN（登录成败、邀请签发/接受、Owner 转交），与 ①靠 requestId 串联。
- 分级：状态迁移 INFO / 业务拒绝 WARN / 系统异常 ERROR；禁止字符串拼接（占位符 `{}`）。

## 安全约束（本类应用硬性要求，改动时自查）
- **JWT 校验**：算法白名单 `RS256/ES256`，**显式禁用 `none` 与 HS 系**（防伪造与密钥/算法混淆，OWASP）；校验 `iss`/`aud`/`exp`/`nonce`；JWKS 按 `kid` 选钥 + 缓存 300s + 未知 kid 回源。
- **iss/aud 双向校验**：`aud` 必须含本服务标识（parlant-agent-server）、`iss` 与预期 issuer **逐字相等**——两者都校验，缺一不可（防 issuer/audience 混淆）。
- **JWT 非机密**：签名不加密，claims 可读——**token 不承载密钥/密码等敏感值**（敏感数据走数据策略/后置，勿塞进 claims）。
- **吊销与重放**：无状态 JWT 需 denylist/短 TTL 才能即时吊销；短 TTL(1800s)+nonce 防重放、refresh token 轮换；**方案 c 即时吊销（V10 签发侧 + 2026-11-09 消费侧闭环）**：角色/权限/成员变更 bump `membership.token_version`——① 业务系统消费 versions feed 自清缓存（秒~分钟级）；② **IAM 管理面拦截器比对 token `ver` vs 库内版本**，落后即 401 `IAM-AUTH-015 TOKEN_STALE`，前端「401→静默 refresh→原地重试」零改动接管（refresh 重解析 RBAC 追平）；成员关系已删同样按 stale 拒。`/auth/**` 纠偏端点不在校验范围。
- **OIDC 回调 redirect 目标必须配置白名单**（`iam.oidc.frontend-redirect` 用配置值、不回显用户输入）——防 open redirect。
- **签名私钥**：`keys/rsa-private.pem`（0600，gitignore，**永不提交/不落日志**）；路径由 `IAM_JWT_PRIVATE_KEY_PATH` 固定为绝对路径（避免不同启动目录各生成一把）；换钥靠 kid 并存窗口无缝轮换；泄露即轮换并作废旧 token。公钥只经 `/.well-known/jwks.json` 发布。
- **认证失败统一 401 + 同文案**（防账号枚举）；**默认最小权限**（无权限点即 403）。
- **管理面**（P3 `/api/v1/admin/**`）：默认拒绝 + 显式白名单；用 `iam:*` 权限点与业务 9 码分离。
- **敏感数据**：`client_secret_cipher` 加密存储（P2 直取明文，生产必须加密）；token/密钥不写日志。

## 开发注意（踩过的坑，避免重犯）
- **Flyway 迁移一经应用不可改**（改会 checksum 失配→启动失败）；变更只能新增 `V{n+1}__...`。**`db/migration` 只放 schema（建表/改表）**；**`spring.flyway.locations: classpath:db/migration,db/seed`**——schema + **平台引导（`db/seed/R__platform_bootstrap.sql`：iam 应用/iam:* 权限/PlatformAdmin/平台租户/platform_admin）默认应用到所有环境**；`db/seed-dev/R__seed_dev.sql`（dev 数据：admin/operator/viewer、tenant-org-a、parlant）**不进任何环境 locations**，仅测试基类 `IamIntegrationTestBase` 的 `@DynamicPropertySource` 注入 + 手动参考；**业务数据（租户/应用/成员/授权）手动初始化**。环境相关/带占位数据（Keycloak 配置、客户端密钥）仍放 `scripts/` 幂等脚本。
- **删迁移文件记得清 `target/classes`**：被删的迁移（如曾有的 V2/V7）会残留在 target/classes，测试/启动仍会应用 → 必须 `mvn clean`（或删 `target/classes/db`）一次，否则新旧 seed 混跑出隔离列不一致（授权 400）。
- **全局 Jackson `default-property-inclusion: non_null`**：Map 里的 null 会被序列化器丢掉——feed tombstone 用显式哨兵 `version:-1`，别指望 null 字段能传出去。
- **私钥相对路径坑**：`./keys/rsa-private.pem` 随启动目录变化会生成多把 key → token 失配。用 `IAM_JWT_PRIVATE_KEY_PATH` 固定。
- **`@MapperScan` 独立在 `IamPersistenceConfig`（勿移到 `IamApplication`），且已收窄到四个 `infra.persistence.mapper` 包**——原全树扫描会把非 Mapper 接口（如 mail.EmailTool）当 Mapper 代理（启动不报错、调用才炸 Invalid bound statement）；新增模块的 mapper 包要在 `IamPersistenceConfig` 登记，普通接口放其它包无影响。
- **CHAR(32) 业务键读取一律 trim**；按非唯一列（`primary_domain`/`owner+type`）查租户用 `LIMIT 1`（`selectOne` 多行会抛 500）。
- **Keycloak 组 claim 是完整路径（前导斜杠 `/agent-operators`）**：组映射 `match_value` 用带斜杠形态；IAM 匹配已容忍斜杠。
- **`global` 异常兜底**：`NoResourceFoundException`（Chrome DevTools 探测 `/.well-known/...`）返回 404 而非 500，别被它误导排查。
- **`spring.mail.host` 切勿配空串**：`@ConditionalOnProperty` 只看属性「存在」，空值会装配连不上 SMTP 的 sender 并拖垮 `/actuator/health`（mail 指示器 DOWN → 503）——不配就保持日志模式；已 `management.health.mail.enabled=false` 双保险。
- **JIT claims 快照每次登录刷新**（`gateway_user_identity.claims_json` 反映最新登录，供审计/排障）。

- **提交纪律（强制）**：代码改动——**unify-iam-server 与 platform-iam-web 两个仓库一律不自动提交**。即使已跑完测试/文档已同步，也**必须等用户明确说「提交」**后才 `git add` + `git commit`；提交前先向用户列出将提交的文件确认，且 `git add` 前自查是否有密钥/本地临时改动（如 application.yml 里的硬编码 token）被误扫入。

## 本地运行与验证
```bash
cd iam-app && mvn spring-boot:run     # schema + 平台引导（flyway=db/migration,db/seed）；连 127.0.0.1:3306/unify_iam（SPRING_DATASOURCE_* 可覆盖），端口 8090
curl -s localhost:8090/.well-known/jwks.json
curl -s -X POST localhost:8090/api/v1/auth/token -H 'Content-Type: application/json' -d '{"username":"platform_admin","password":"Platform@123"}'   # 平台引导占位密码，部署后立即改密
curl -s localhost:8090/api/v1/auth/me -H "Authorization: Bearer <token>"
```
- **账号**：平台引导（`platform_admin` 等）由 `db/seed` 自动应用（占位密码见脚本注释，部署后改密）；dev seed 账号（admin/operator/viewer）不进环境 locations（仅测试/手动）；业务账号/租户手动建。
- 企业 SSO：Keycloak 8099 建 realm org-a + client iam + 用户 alice@org-a.com + 组 agent-operators（`gateway_tenant_idp_config.kc-org-a` 已配）。

## parlant-agent 对接
parlant `.env`：`AUTH_MODE=gateway` + `JWT_JWKS_URL=http://127.0.0.1:8090/.well-known/jwks.json` + `IAM_TOKEN_URL=http://127.0.0.1:8090/api/v1/auth/token`（`JWT_ISSUER` 对齐 IAM issuer 可开启 iss 校验）。**路由代码零改动，只换认证来源。**

## 环境提示
- 本机出网需代理：`export all_proxy=http://127.0.0.1:7899`（`NO_PROXY=localhost,127.0.0.1`）；内置 WebSearch/WebFetch 工具可能不可用，可用 `curl -x http://127.0.0.1:7899 ...` 拉网页/DuckDuckGo 搜索兜底。

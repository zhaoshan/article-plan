# Member invitation email delivery plan

Date: 2026-10-27

Status: Complete.

## Scope and constraints

- Work only in the current `platform-iam-service` main worktree.
- Keep task, planning, session, contract, and validation records in this repository's `.trellis/` directory.
- Do not inspect or change frontend source or another Platform IAM project.
- Preserve existing uncommitted and parallel edits. Do not create/delete a worktree, switch/reset a branch, commit, merge, or push.
- Hidden-path searches confirmed that `AGENTS.md` and `.trellis/workflow.md` do not exist in this worktree. `CLAUDE.md` and `.claude/rules/security.md` are the applicable instructions; no undocumented Trellis confirmation gate can be inferred.

## Confirmed baseline

1. `POST /api/v1/admin/invitations` currently requires `iam:member:write`, applies `TenantScopeGuard`, creates a seven-day `MEMBER` invitation, stores its token hash, writes `delivery_status=DEVELOPMENT_TOKEN`, and returns the plaintext token.
2. That path does not call any mail sender. The existing SMTP code is limited to Owner invitations and cannot make an ordinary member invitation a real email send.
3. `GET /api/v1/admin/tenants` and `GET /api/v1/admin/tenants/{tenantId}` both return `tenant_id`, `tenant_name`, and `tenant_code`; the invitation request itself must use the internal `tenant_id`, not the code.
4. The existing Owner mail flow establishes the correct failure boundary: incomplete configuration or a sender exception is `503`, and the transaction rolls back the invitation. The member flow should share those guarantees while keeping its configuration separate.

## Chosen contract

```http
POST /api/v1/admin/invitations
Authorization: Bearer <token with iam:member:write>
Content-Type: application/json

{"email":"invitee@example.com","tenant_id":"...","role_id":"..."}
```

- `role_id` remains optional and, when present, must belong to the requested tenant.
- The existing tenant scope guard rejects out-of-scope tenant IDs even when the caller has `iam:member:write`.
- Success returns `data:{invitation_id, invitation_status:"PENDING", delivery_status:"SUBMITTED"}`. No plaintext invitation token is returned, persisted, or audited.
- `SUBMITTED` means the configured `JavaMailSender` accepted the synchronous submission. It does not state that a receiving mailbox accepted the message or that the recipient acted on it.
- The deployment must configure Spring Mail plus `iam.member-invitation.delivery-enabled`, `from`, and an absolute `accept-url-template` containing `{token}`. Missing configuration or a sender exception returns `503`; because send executes inside the invitation transaction, no inaccessible pending invitation remains.

## Implementation checklist

- [x] Read applicable current-project instructions and record the absence of the requested workflow files.
- [x] Trace the member invitation route, scope authorization, persistence, acceptance route, tenant list code contract, existing Owner SMTP flow, and current tests.
- [x] Add the typed non-sensitive result, member-mail configuration, synchronous mail boundary, and transactional invite submission.
- [x] Update the API reference for exact client, tenant-code, permission, and delivery semantics.
- [x] Add test-only mail substitution and focused HTTP/rollback/acceptance coverage without external delivery.
- [x] Run focused validation, `git diff --check`, and complete task/session/check records.

## Implementation and validation result

- Added `MemberInvitationMailService`, backed by the existing Spring Mail infrastructure. It validates explicit
  member-invitation configuration, renders an escaped tenant-specific acceptance email, and treats only a successful
  `JavaMailSender` call as `SUBMITTED`; neither API nor audit receives the plaintext token.
- `InvitationService.create(...)` retains its existing permission/scope/role/quota checks, stores only the token hash,
  invokes the sender inside its transaction, and returns a typed non-sensitive response. Mail configuration or send
  failure is `503` and rolls back the new invitation.
- Added the `iam.member-invitation.*` deployment configuration and documented the exact response, error semantics,
  tenant ID/code contract, and SMTP prerequisites.
- The integration-test base now uses an in-process `JavaMailSender` capture substitute for member invites. The new
  test verifies one captured MIME message and acceptance token, no response token, persisted `SUBMITTED` state, and
  `503` rollback. Existing invite acceptance tests retrieve their token from this substitute, so no test uses SMTP.
- Focused compile passed. Member/role/tenant invitation regression passed 33 tests. Member plus Owner-mail regression
  passed 6 tests. `git diff --check` passed. No external email was sent.

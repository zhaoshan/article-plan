# Technical design

## Boundary and data flow

`AdminTenantController#list` will bind the optional snake_case query parameters and pass them to `AdminTenantService`. The service will validate the scope tuple once, then call a repository method that adds the corresponding `tenant_id` predicate before applying the existing ordered limit. The controller will continue to enrich the returned rows through `applicationsByTenant` and serialize the existing `{tenants, count}` payload.

## Scope contract

| scope_type | scope_id | Meaning | Result |
| --- | --- | --- | --- |
| omitted | omitted | Existing platform management list | All visible tenants, subject to `limit` |
| `PLATFORM` | `PLATFORM` | Platform scope | All visible tenants, subject to `limit` |
| `TENANT` | tenant id | One tenant scope | Only that tenant, subject to the same query and response rules |

Any partial tuple, blank id, unsupported value, or mismatched platform id is a 400. Values are intentionally case-sensitive so clients cannot silently broaden a request through a typo.

## Compatibility and isolation

The no-parameter path remains byte-for-byte compatible at the business level. The existing `iam:tenant:read` interceptor remains the first authorization gate. Filtering is performed in the repository query, before enrichment and before the limit is materialized, so a tenant-scoped request cannot receive a neighboring tenant through ordering or application lookup.

## Verification strategy

- Add focused controller tests for parameter binding, strict validation, correct filtering handoff, and incorrect field/case behavior.
- Add an integration regression around the real endpoint with two tenants and application relationships to prove scope filtering, empty/missing behavior, enrichment, permission isolation, and no-parameter compatibility.
- Run the relevant Maven tests and the repository’s required compile/check commands.

package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.JsonUtils;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;

/**
 * P3 加入申请集成测试：用户申请 → 待审批 → 管理员批准 → 成为成员 → 可切换该租户。
 */
class P3JoinRequestIntegrationTest extends IamIntegrationTestBase {

    private String login(String username, String password) throws Exception {
        MvcResult res = mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}"))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.fromJson(dataJson(res.getResponse().getContentAsString()), LoginResponse.class).accessToken();
    }

    private String adminPost(String url, Object body, String token) throws Exception {
        MvcResult res = mockMvc.perform(post(url)
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(body)))
                .andExpect(status().isOk())
                .andReturn();
        return JsonUtils.toJson(JsonUtils.fromJson(res.getResponse().getContentAsString(), Map.class).get("data"));
    }

    @Test
    void joinRequestPendingThenApproveAndSwitch() throws Exception {
        String admin = login("admin", "admin123");
        String viewer = login("viewer", "view123");

        // ① 建租户 T（INVITE_ONLY）→ 改为 DOMAIN_REQUEST 以便申请
        String tenantId = JsonUtils.fromJson(
                adminPost("/api/v1/admin/tenants", Map.of(
                        "tenant_code", "jr-tenant", "tenant_name", "JR Tenant",
                        "tenant_type", "ORGANIZATION", "app_codes", java.util.List.of("parlant-agent-server")), admin),
                Map.class).get("tenant_id").toString();
        jdbcTemplate.update("UPDATE gateway_tenant SET join_policy='DOMAIN_REQUEST' WHERE tenant_id=?", tenantId);

        // ② viewer 申请加入 → PENDING
        mockMvc.perform(post("/api/v1/memberships/join-request")
                        .header("Authorization", "Bearer " + viewer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", tenantId))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.status").value("PENDING"));

        // ③ 管理员审批列表含该申请 → approve
        String listBody = mockMvc.perform(get("/api/v1/admin/join-requests")
                        .header("Authorization", "Bearer " + admin)
                        .param("tenant_id", tenantId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(1))
                .andReturn().getResponse().getContentAsString();
        String joinRequestId = firstId(listBody, "join_requests", "join_request_id");
        mockMvc.perform(post("/api/v1/admin/join-requests/" + joinRequestId + "/approve")
                        .header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk());

        // ④ viewer 现在已是 T 成员 → 可切换租户
        String memberships = mockMvc.perform(get("/api/v1/auth/memberships")
                        .header("Authorization", "Bearer " + viewer))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertThat(memberships).contains(tenantId);
        String newMembershipId = membershipIdForTenant(memberships, tenantId);

        MvcResult sw = mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + viewer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("membership_id", newMembershipId))))
                .andExpect(status().isOk())
                .andReturn();
        LoginResponse switched = JsonUtils.fromJson(dataJson(sw.getResponse().getContentAsString()), LoginResponse.class);
        mockMvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + switched.accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenantId").value(tenantId));

        // ⑤ 申请状态已 APPROVED
        Integer approved = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM gateway_join_request WHERE join_request_id=? AND request_status='APPROVED'",
                Integer.class, joinRequestId);
        assertThat(approved).isEqualTo(1);
    }

    @Test
    void inviteOnlyTenantRejectsJoinRequest() throws Exception {
        String admin = login("admin", "admin123");
        String viewer = login("viewer", "view123");
        String tenantId = JsonUtils.fromJson(
                adminPost("/api/v1/admin/tenants", Map.of(
                        "tenant_code", "inv-only", "tenant_name", "Invite Only",
                        "tenant_type", "ORGANIZATION", "app_codes", java.util.List.of("parlant-agent-server")), admin),
                Map.class).get("tenant_id").toString();
        // 默认 INVITE_ONLY

        mockMvc.perform(post("/api/v1/memberships/join-request")
                        .header("Authorization", "Bearer " + viewer)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("tenant_id", tenantId))))
                .andExpect(status().isForbidden());
    }

    private String firstId(String jsonBody, String listKey, String itemKey) {
        Map<String, Object> parsed = unwrapData(jsonBody);
        Object list = parsed.get(listKey);
        if (list instanceof java.util.List<?> rows && !rows.isEmpty()) {
            return String.valueOf(((Map<?, ?>) rows.get(0)).get(itemKey));
        }
        return "";
    }

    private String membershipIdForTenant(String membershipsBody, String tenantId) {
        Map<String, Object> parsed = unwrapData(membershipsBody);
        Object list = parsed.get("memberships");
        if (list instanceof java.util.List<?> rows) {
            for (Object row : rows) {
                Map<?, ?> m = (Map<?, ?>) row;
                if (tenantId.equals(String.valueOf(m.get("tenant_id")))) {
                    return String.valueOf(m.get("membership_id"));
                }
            }
        }
        return "";
    }
}

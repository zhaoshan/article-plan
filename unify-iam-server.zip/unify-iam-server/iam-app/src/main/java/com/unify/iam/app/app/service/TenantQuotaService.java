package com.unify.iam.app.app.service;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.dto.admin.TenantUsageDimension;
import com.unify.iam.api.dto.admin.TenantUsageSummary;
import com.unify.iam.app.infra.persistence.repository.InvitationRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.infra.persistence.po.QuotaDimensionPO;
import com.unify.iam.tenant.infra.persistence.po.TenantQuotaPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.QuotaDimensionRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantQuotaRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 租户配额与真实 IAM Usage 的唯一编排点。
 *
 * <p>不持久化派生用量：成员来自 membership 与未过期 PENDING invitation，应用来自已启用的
 * tenant/application 关系。未知 IAM 维度不会被伪造为零用量，而是显式标为 usage 不可用。
 */
@Service
public class TenantQuotaService {

    private static final String MEMBERS = "members";
    private static final String APPS = "apps";

    private final TenantRepository tenantRepository;
    private final QuotaDimensionRepository quotaDimensionRepository;
    private final TenantQuotaRepository tenantQuotaRepository;
    private final MembershipRepository membershipRepository;
    private final InvitationRepository invitationRepository;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository membershipRoleRepository;
    private final com.unify.iam.authorization.infra.persistence.repository.RoleRepository roleRepository;
    private final com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository applicationRoleTemplateRepository;

    public TenantQuotaService(TenantRepository tenantRepository,
                              QuotaDimensionRepository quotaDimensionRepository,
                              TenantQuotaRepository tenantQuotaRepository,
                              MembershipRepository membershipRepository,
                              InvitationRepository invitationRepository,
                              TenantApplicationRepository tenantApplicationRepository,
                              com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository membershipRoleRepository,
                              com.unify.iam.authorization.infra.persistence.repository.RoleRepository roleRepository,
                              com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository applicationRoleTemplateRepository) {
        this.tenantRepository = tenantRepository;
        this.quotaDimensionRepository = quotaDimensionRepository;
        this.tenantQuotaRepository = tenantQuotaRepository;
        this.membershipRepository = membershipRepository;
        this.invitationRepository = invitationRepository;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.roleRepository = roleRepository;
        this.applicationRoleTemplateRepository = applicationRoleTemplateRepository;
    }

    /** 租户已启用应用的 is_owner 模板角色 id 集（有效席位排除项；G3 同口径）。 */
    private List<String> resolveOwnerRoleIds(String tenantId) {
        java.util.Set<String> ownerCodes = new java.util.HashSet<>(
                applicationRoleTemplateRepository.listIsOwnerRoleCodes(
                        tenantApplicationRepository.findAppCodesByTenant(tenantId)));
        return roleRepository.listByScope("TENANT", tenantId.trim()).stream()
                .filter(r -> r.getRoleCode() != null && ownerCodes.contains(r.getRoleCode().trim()))
                .map(r -> r.getRoleId().trim())
                .toList();
    }

    public TenantUsageSummary usageFor(String tenantId) {
        return new TenantUsageSummary(dimensionsFor(tenantId));
    }

    /** 设置已知 IAM 维度的租户覆盖。有限额度不得被降到当前真实保留量以下。 */
    @Transactional
    public TenantUsageDimension updateLimit(String tenantId, String dimensionKey, long limitValue) {
        String normalizedTenantId = tenantId.trim();
        tenantRepository.findByIdForUpdate(normalizedTenantId)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        QuotaDimensionPO dimension = resolveTenantDimension(normalizedTenantId, dimensionKey);
        TenantUsageDimension current = dimensionFor(normalizedTenantId, dimension,
                overridesByDimension(normalizedTenantId));
        if (!current.usageAvailable()) {
            throw AuthException.badRequest(ErrorCode.QUOTA_NO_USAGE_SOURCE);
        }
        if (limitValue < current.usedCount()) {
            throw AuthException.badRequest(ErrorCode.QUOTA_LIMIT_BELOW_USAGE, current.usedCount());
        }
        tenantQuotaRepository.save(normalizedTenantId, dimension.getDimensionId(), limitValue);
        return dimensionFor(normalizedTenantId, dimension, overridesByDimension(normalizedTenantId));
    }

    /** 清除租户覆盖，恢复维度默认值；默认值若已低于当前真实用量则拒绝产生不可执行的策略。 */
    @Transactional
    public TenantUsageDimension resetLimit(String tenantId, String dimensionKey) {
        String normalizedTenantId = tenantId.trim();
        tenantRepository.findByIdForUpdate(normalizedTenantId)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        QuotaDimensionPO dimension = resolveTenantDimension(normalizedTenantId, dimensionKey);
        TenantUsageDimension current = dimensionFor(normalizedTenantId, dimension,
                overridesByDimension(normalizedTenantId));
        if (!current.usageAvailable()) {
            throw AuthException.badRequest(ErrorCode.QUOTA_NO_USAGE_SOURCE);
        }
        if (tenantApplicationRepository.findAppCodesByTenant(normalizedTenantId).contains(dimension.getAppCode())
                && dimension.getDefaultLimit() != null && dimension.getDefaultLimit() < current.usedCount()) {
            throw AuthException.badRequest(ErrorCode.DEFAULT_QUOTA_BELOW_USAGE, current.usedCount());
        }
        tenantQuotaRepository.save(normalizedTenantId, dimension.getDimensionId(), null);
        return dimensionFor(normalizedTenantId, dimension, overridesByDimension(normalizedTenantId));
    }

    /**
     * /quotas/{dimensionKey} 维度解析（2026-11-03 修复）：按 **G1 适用口径**取「租户已启用应用 ∩ 维度 key」
     * 的维度——修复旧实现无条件解析 iam 全局维度导致：非 iam 租户调额写到了 usage 视图不可见的维度上
     * （调额后 GET /usage 「不变」），且业务应用维度永远无法经此端点调整。多个应用提供同名维度时
     * 400 引导用 PUT /usage/{dimensionId} 显式指定；租户无适用维度时回落 iam 全局维度（旧行为兼容）。
     */
    private QuotaDimensionPO resolveTenantDimension(String tenantId, String dimensionKey) {
        java.util.Set<String> apps = new java.util.HashSet<>(
                tenantApplicationRepository.findAppCodesByTenant(tenantId));
        List<QuotaDimensionPO> applicable = quotaDimensionRepository.listActiveByKey(dimensionKey).stream()
                .filter(d -> apps.contains(d.getAppCode().trim()))
                .toList();
        if (applicable.size() > 1) {
            throw AuthException.badRequest(ErrorCode.QUOTA_DIMENSION_AMBIGUOUS);
        }
        if (applicable.size() == 1) {
            return applicable.get(0);
        }
        return quotaDimensionRepository.findActiveIamDimension(dimensionKey)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.QUOTA_DIMENSION_NOT_FOUND));
    }

    /** 新增成员前保留一个席位；目标租户行锁防止并发邀请/加成员越过同一个有限上限。 */
    @Transactional
    public void assertCanReserveMember(String tenantId) {
        String normalizedTenantId = tenantId.trim();
        tenantRepository.findByIdForUpdate(normalizedTenantId)
                .orElseThrow(() -> AuthException.notFound(ErrorCode.TENANT_NOT_FOUND));
        quotaDimensionRepository.findActiveIamDimension(MEMBERS).ifPresent(dimension -> {
            Long override = Optional.ofNullable(overridesByDimension(normalizedTenantId)
                            .get(dimension.getDimensionId()))
                    .map(TenantQuotaPO::getLimitValue).orElse(null);
            // 适用性口径与 dimensionFor/G1 一致：默认上限仅对启用该应用的租户生效（iam 维度对未启用 iam 的租户不强制）
            Long effectiveLimit = override != null ? override
                    : tenantApplicationRepository.findAppCodesByTenant(normalizedTenantId).contains(dimension.getAppCode())
                            ? dimension.getDefaultLimit() : null;
            // 强制基准与展示口径分离（2026-10-30）：非 Owner 活跃成员全占位 + 待接受邀请，
            // 不用展示用 usedCount（有效席位）——避免 JIT 角色延期账号绕过配额。
            long used = membershipRoleRepository.countActiveNonOwnerMembers(
                    normalizedTenantId, resolveOwnerRoleIds(normalizedTenantId));
            long pending = invitationRepository.countPendingWithoutMembership(normalizedTenantId)
                    + membershipRepository.countByTenantAndStatuses(normalizedTenantId, List.of("PENDING"));
            if (effectiveLimit != null && used + pending >= effectiveLimit) {
                throw AuthException.badRequest(ErrorCode.MEMBER_QUOTA_EXHAUSTED);
            }
        });
    }

    /** 创建新租户前检查模板默认额度；新租户尚不存在，因此不存在租户覆盖。 */
    public void assertCreationFitsDefaultLimits(List<String> appCodes, int appCount, int memberCount) {
        if (!appCodes.contains("iam")) {
            return;
        }
        for (QuotaDimensionPO dimension : quotaDimensionRepository.listActiveIamDimensions()) {
            long requested = switch (dimension.getDimensionKey()) {
                case APPS -> appCount;
                case MEMBERS -> memberCount;
                default -> 0;
            };
            if (requested > 0 && dimension.getDefaultLimit() != null && requested > dimension.getDefaultLimit()) {
                throw AuthException.badRequest(ErrorCode.INIT_EXCEEDS_QUOTA, dimension.getDimensionName());
            }
        }
    }

    /**
     * 详情 usage 维度枚举（2026-11-03 与 GET /usage 对齐）：G1 适用口径 = 租户已启用应用的 ACTIVE 维度
     * （defaultLimit 非空）——旧实现无条件枚举 iam 应用自身维度，非 iam 租户看到不适用的 iam 维度、
     * 反而看不到自己启用应用的维度。
     */
    private List<TenantUsageDimension> dimensionsFor(String tenantId) {
        String normalizedTenantId = tenantId.trim();
        Map<String, TenantQuotaPO> overrides = overridesByDimension(normalizedTenantId);
        List<String> appCodes = tenantApplicationRepository.findAppCodesByTenant(normalizedTenantId);
        return quotaDimensionRepository.listActiveByAppCodes(appCodes).stream()
                .filter(dimension -> dimension.getDefaultLimit() != null)
                .map(dimension -> dimensionFor(normalizedTenantId, dimension, overrides))
                .toList();
    }

    private Map<String, TenantQuotaPO> overridesByDimension(String tenantId) {
        return tenantQuotaRepository.listByTenant(tenantId).stream()
                .collect(Collectors.toMap(TenantQuotaPO::getDimensionId, quota -> quota, (a, b) -> a,
                        LinkedHashMap::new));
    }

    private TenantUsageDimension dimensionFor(String tenantId, QuotaDimensionPO dimension,
                                               Map<String, TenantQuotaPO> overridesByDimension) {
        Long override = Optional.ofNullable(overridesByDimension.get(dimension.getDimensionId()))
                .map(TenantQuotaPO::getLimitValue).orElse(null);
        // Current-branch defaults follow enabled applications. An explicit quota override
        // from the drawer still applies to the tenant, even without the IAM app.
        Long effectiveLimit = override != null ? override
                : tenantApplicationRepository.findAppCodesByTenant(tenantId).contains(dimension.getAppCode())
                        ? dimension.getDefaultLimit() : null;
        UsageCounts counts = countsFor(tenantId, dimension.getDimensionKey());
        boolean limited = effectiveLimit != null;
        boolean overLimit = counts.available() && limited && counts.usedCount() > effectiveLimit;
        Long remaining = counts.available() && limited ? Math.max(0, effectiveLimit - counts.usedCount()) : null;
        return new TenantUsageDimension(
                dimension.getAppCode(), dimension.getDimensionKey(), dimension.getDimensionName(), dimension.getUnit(),
                dimension.getSource(), counts.available(), counts.usedCount(), counts.activeCount(), counts.pendingCount(),
                effectiveLimit, limited, remaining, overLimit);
    }

    private UsageCounts countsFor(String tenantId, String dimensionKey) {
        return switch (dimensionKey) {
            case MEMBERS -> {
                // G1 口径修订（2026-10-30）：used = 有效席位（有角色且不含 owner 角色）+ 待定（成员/邀请）；
                // Owner 免费席位、角色延期账号（accept 前零角色）不计入展示用量。
                long effective = membershipRoleRepository.countEffectiveMembers(tenantId, resolveOwnerRoleIds(tenantId));
                // pending 口径（2026-11-03）：未接受的邀请（含已预建成员的）计为待定席位
                long pending = invitationRepository.countPendingInvitations(tenantId);
                yield new UsageCounts(true, effective + pending, effective, pending);
            }
            case APPS -> {
                long apps = tenantApplicationRepository.findAppCodesByTenant(tenantId).size();
                yield new UsageCounts(true, apps, apps, 0L);
            }
            default -> new UsageCounts(false, null, null, null);
        };
    }

    private record UsageCounts(boolean available, Long usedCount, Long activeCount, Long pendingCount) {
    }
}

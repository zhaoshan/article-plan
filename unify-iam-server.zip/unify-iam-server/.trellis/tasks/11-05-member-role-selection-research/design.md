# Approved query implementation

## Contract
User-approved route with repository global prefix: GET `/api/v1/admin/tenant/roles?tenant_id=<tenantId>`; no alternate `/admin/members/role-options` route. Permission iam:member:read aligns with member data reads. Normalize required tenant_id, authorize via TenantScopeGuard, verify target exists, then query. Invalid/blank tenant ID 400, unauthorized scope 403, authorized missing tenant 404, authentication 401, all in existing envelopes. No silent target default.

Data is `{tenant_id, roles, count}`. Roles expose role_id, role_code, role_name, optional role_description, scope_type, scope_id, role_status, boolean is_builtin/is_owner. count is returned length. New API is an exact catalog query, not an assertion of grantability; no can_assign/unavailable_reason. Disabled rows remain in the requested all-role collection. All returned is_owner=false.

## Query
Isolated RoleRepository method with grouped union: `(scope_type=PLATFORM AND scope_id=PLATFORM AND is_builtin=0) OR (scope_type=TENANT AND scope_id=T)`, logical deletion applied to both arms, id ASC. Resolve target enabled application templates' is_owner codes once, then remove only matching TENANT Owner roles. Do not filter platform rows by tenant owner code, exclude tenant builtins, or modify listForAdmin/listByScope. is_builtin=0 is the available representation of administrator-created custom global roles; no creator privilege history is inferred.

## Source
TenantMemberQueryService.legacyBrief already emits join_source from TenantMemberSummary, populated by TenantMemberProjectionService.memberSummary from MembershipPO.getJoinSource. Verify real mapper selection and regression-test passthrough. No duplicate Source backend field.

## Write and identity boundary
Current InvitationService rejects PLATFORM role IDs; member add/setRoles have incomplete per-role scope/status validation. Any PLATFORM binding triggers platform scope authority via RoleMapper/TenantScopeGuard even for custom roles. Neither the query approval nor Source request authorizes decoupling this model or permitting new platform grants. Preserve write behavior for now, test/document mismatch, and report it as unresolved delivery scope. Do not add flags that pretend the user accepted restricted selections. Broader shared validation, issuer provenance and acceptance changes in the original research are not part of this implementation.

## Frontend handoff
Both dialogs consume data.roles from this route with the actual row target tenant ID. Edit keeps current bindings separate and shows skeleton until candidate/current reads finish; never clear selections from a pending/default empty array. Invite trigger remains enabled; panel shows pending skeleton, loaded options immediately, distinct empty/error/retry. Use existing join_source as Source text after Role. No new loading fields, no external frontend access.

## Compatibility / risk
No DDL; no changes to management/runtime list behavior or permission constants. Role DTO is distinct from PO. Existing member join_source stays additive/no shape change. Inability to safely grant all PLATFORM candidates is explicitly unresolved, not masked by read success. Historical proposal and evidence remain under research/; this file supersedes the former recommended path and can_assign policy.

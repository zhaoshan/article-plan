-- G9：租户切换菜单「Last opened」排序——成员级最近打开时间（初始登录设置 / switch-tenant 更新；静默刷新不刷）
ALTER TABLE `gateway_membership`
  ADD COLUMN `last_opened_at` DATETIME DEFAULT NULL COMMENT '成员级最近打开时间（G9：登录落入成员时设置、切换租户更新）' AFTER `is_default`;

package com.unify.iam.app;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator;
import com.unify.iam.app.adapter.controller.JwksController;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.app.security.RsaKeyManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(JwksController.class)
class JwksControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private RsaKeyManager keyManager;

    // @WebMvcTest 自动加载 HandlerInterceptor 类型的 @Component（管理面拦截器），需提供其依赖
    @MockitoBean
    private JwtSigner jwtSigner;

    @BeforeEach
    void setUp() throws Exception {
        RSAKey key = new RSAKeyGenerator(2048).keyID("iam-key-1").generate();
        when(keyManager.signingKey()).thenReturn(key);
        when(keyManager.kid()).thenReturn("iam-key-1");
    }

    @Test
    void jwksReturnsPublicKeyWithFixedKidAndCacheHeader() throws Exception {
        mockMvc.perform(get("/.well-known/jwks.json"))
                .andExpect(status().isOk())
                .andExpect(header().string("Cache-Control", org.hamcrest.Matchers.containsString("max-age=300")))
                .andExpect(jsonPath("$.keys[0].kty").value("RSA"))
                .andExpect(jsonPath("$.keys[0].kid").value("iam-key-1"))
                .andExpect(jsonPath("$.keys[0].alg").value("RS256"))
                .andExpect(jsonPath("$.keys[0].use").value("sig"))
                .andExpect(jsonPath("$.keys[0].n").isNotEmpty())
                .andExpect(jsonPath("$.keys[0].e").value("AQAB"));
    }
}

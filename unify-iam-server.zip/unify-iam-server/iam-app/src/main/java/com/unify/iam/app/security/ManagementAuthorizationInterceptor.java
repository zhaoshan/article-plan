package com.unify.iam.app.security;

import com.unify.iam.api.model.AuthorizationContext;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.common.exception.AuthException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * 管理面鉴权拦截器（docs/04 §3.1）：校验 `/api/v1/admin/**` 的 Bearer 令牌 + 所需 {@code iam:*} 权限。
 *
 * <p>复用 {@link JwtSigner#verify}（与 /me 同款验签）；校验通过后将 claims/上下文写入 request attribute，
 * 供 controller 读取。无/坏 token → 401；有 token 但缺权限点 → 403。
 */
@Component
public class ManagementAuthorizationInterceptor implements HandlerInterceptor {

    public static final String AUTH_CLAIMS_ATTR = "iam.claims";
    public static final String AUTH_CONTEXT_ATTR = "iam.authContext";

    private final JwtSigner jwtSigner;

    public ManagementAuthorizationInterceptor(JwtSigner jwtSigner) {
        this.jwtSigner = jwtSigner;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (!(handler instanceof HandlerMethod)) {
            return true; // 静态资源等，放行
        }
        JwtClaims claims = verify(request.getHeader("Authorization"));
        request.setAttribute(AUTH_CLAIMS_ATTR, claims);
        request.setAttribute(AUTH_CONTEXT_ATTR, toContext(claims));

        RequirePermission rp = ((HandlerMethod) handler).getMethodAnnotation(RequirePermission.class);
        if (rp != null && !claims.permissions().contains(rp.value())) {
            throw AuthException.forbidden("缺少权限点：" + rp.value());
        }
        return true;
    }

    private JwtClaims verify(String authorization) {
        String token = extractBearer(authorization);
        if (token == null) {
            throw AuthException.unauthorized("缺少令牌：请带 Authorization: Bearer <token>");
        }
        return jwtSigner.verify(token);
    }

    private AuthorizationContext toContext(JwtClaims claims) {
        return new AuthorizationContext(claims.userId(), claims.tenantId(), claims.membershipId(),
                claims.roles(), claims.permissions(), claims.attrs());
    }

    private String extractBearer(String authorization) {
        if (authorization == null || !authorization.regionMatches(true, 0, "bearer ", 0, 7)) {
            return null;
        }
        return authorization.substring(7).trim();
    }
}
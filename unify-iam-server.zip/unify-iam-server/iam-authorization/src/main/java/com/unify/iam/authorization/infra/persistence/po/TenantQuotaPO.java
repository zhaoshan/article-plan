package com.unify.iam.authorization.infra.persistence.po;

import com.baomidou.mybatisplus.annotation.TableName;
import com.unify.iam.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/** G1 租户配额调额覆盖：gateway_tenant_quota（无行=用模板默认）。 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("gateway_tenant_quota")
public class TenantQuotaPO extends BaseEntity {

    /** 覆盖业务唯一标识 */
    private String tenantQuotaId;
    /** 租户ID */
    private String tenantId;
    /** 配额维度ID（逻辑关联 gateway_quota_dimension.dimension_id） */
    private String dimensionId;
    /** 租户级覆盖上限；NULL=用模板默认 */
    private Integer limitValue;
}

# Admin role list scope and status visibility

The user explicitly authorized implementation of the corrected contract without further product-scope confirmation.

## Requirements
- PLATFORM requests require the existing platform-admin guard and return all non-deleted roles across tenants, including DISABLED roles.
- All other requests return only TENANT roles for the authorized target tenant.
- Preserve logical deletion, response fields, and runtime ACTIVE-only queries.
- Verify global listing, disabled roles, tenant isolation, forged platform scope, and soft deletion.
- Work only in this repository. No commit, push, merge, branch switch, or worktree operations.

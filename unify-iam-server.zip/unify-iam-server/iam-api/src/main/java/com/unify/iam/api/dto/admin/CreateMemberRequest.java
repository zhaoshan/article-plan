package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import java.util.List;

/** 添加成员到租户：tenant_id + user_id + 可选角色。 */
public record CreateMemberRequest(
        @NotBlank(message = "tenant_id 不能为空") @JsonProperty("tenant_id") String tenantId,
        @NotBlank(message = "user_id 不能为空") @JsonProperty("user_id") String userId,
        @JsonProperty("role_ids") List<String> roleIds) {
}

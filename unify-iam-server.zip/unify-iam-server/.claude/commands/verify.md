---
description: 构建并运行测试（全量 / 快速 / 集成）
---

运行构建与测试，参数可选：`full`（默认，`mvn clean install` 全量）、`quick`（跳过集成）、`it`（只跑集成）。

- full：`mvn clean install`
- quick：`mvn -pl iam-app -am test -Dtest='!IamFlowIntegrationTest,!OidcSsoIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false`
- it：`mvn -pl iam-app -am test -Dtest='IamFlowIntegrationTest,OidcSsoIntegrationTest' -Dsurefire.failIfNoSpecifiedTests=false`

集成测试需要 Docker（Testcontainers 临时 MySQL）。跑完后报告各模块 `Tests run` 与 BUILD 结果；有失败给出失败用例与原因。

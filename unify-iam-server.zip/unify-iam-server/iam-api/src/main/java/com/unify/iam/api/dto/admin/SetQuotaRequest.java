package com.unify.iam.api.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;

/** G1 租户配额调额请求：{@code PUT /api/v1/admin/tenants/{tenantId}/usage/{dimensionId}}。 */
public record SetQuotaRequest(
        /** 覆盖上限；null/缺省 = 清除覆盖（回落模板默认） */
        @JsonProperty("limit_value") Integer limitValue) {
}

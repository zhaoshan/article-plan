"""爬取请求模型"""

from pydantic import BaseModel, Field, field_validator


class CrawlRequest(BaseModel):
    """启动爬取任务的请求参数"""

    model_config = {"extra": "forbid", "str_strip_whitespace": True}

    target_url: str = Field(
        ...,
        description="爬取入口 URL",
        min_length=1,
        max_length=2048,
    )
    output_type: str = Field(
        default="local",
        description="输出方式：local（本地文件）或 s3（S3 存储，后续实现）",
        pattern=r"^(local|s3)$",
    )
    headless: bool = Field(
        default=True,
        description="是否使用无头模式运行浏览器",
    )
    max_depth: int | None = Field(
        default=None,
        ge=0,
        description="爬取层级，传入时覆盖配置文件中的 drill_down_levels，0=不限",
    )

    @field_validator("target_url")
    @classmethod
    def validate_url_scheme(cls, v: str) -> str:
        """校验 URL 必须以 http:// 或 https:// 开头"""
        if not v.startswith(("http://", "https://")):
            raise ValueError("target_url 必须以 http:// 或 https:// 开头")
        return v


class FullSiteCrawlRequest(BaseModel):
    """启动全量链接树爬取任务的请求参数"""

    model_config = {"extra": "forbid", "str_strip_whitespace": True}

    target_url: str = Field(
        ...,
        description="要全量爬取的站点首页 URL",
        min_length=1,
        max_length=2048,
    )
    headless: bool = Field(
        default=True,
        description="是否使用无头模式运行浏览器",
    )
    max_depth: int | None = Field(
        default=None,
        ge=0,
        description="爬取层级，覆盖配置文件中的 drill_down_levels，0=不限",
    )

    @field_validator("target_url")
    @classmethod
    def validate_url_scheme(cls, v: str) -> str:
        """校验 URL 必须以 http:// 或 https:// 开头"""
        if not v.startswith(("http://", "https://")):
            raise ValueError("target_url 必须以 http:// 或 https:// 开头")
        return v


class DynamicCrawlRequest(BaseModel):

    model_config = {"extra": "forbid", "str_strip_whitespace": True}

    site: str = Field(
        ..., min_length=1, max_length=256,
        description="站点域名（如 'tokyostarbank.co.jp'）",
    )
    page_type: str = Field(
        ..., min_length=1, max_length=64,
        description="动态页面类型（如 'faq'）",
    )
    static_links_file: str = Field(
        ..., min_length=1,
        description="all_unique_links_{ts}.json 文件路径（用于合并）",
    )
    static_tree_file: str = Field(
        ..., min_length=1,
        description="tree_structure_{ts}.json 文件路径（用于合并）",
    )
    headless: bool = Field(
        default=True,
        description="是否使用无头模式运行浏览器",
    )

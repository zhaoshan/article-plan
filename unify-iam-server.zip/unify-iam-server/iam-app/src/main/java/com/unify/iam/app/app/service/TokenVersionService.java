package com.unify.iam.app.app.service;

import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.MembershipVersionLogRepository;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 令牌版本管理（方案 c 即时吊销，docs/07 §8.3；parlant doc11 附录 B）。
 *
 * <p>任何影响成员权限或会话安全的变更（角色/权限/移除/改密）都 bump 该成员 {@code token_version}：
 * JWT 签发时带当前版本（ver），parlant 缓存 IAM 版本 feed 后，旧 token 的 ver 落后即被拒——
 * 把「权限变更生效延迟」从 TTL 级降到 feed 刷新间隔级。每次 bump 记入
 * {@link MembershipVersionLogRepository} 支撑增量 feed。
 */
@Service
public class TokenVersionService {

    private static final Logger log = LoggerFactory.getLogger(TokenVersionService.class);

    private final MembershipRepository membershipRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final MembershipVersionLogRepository versionLogRepository;

    public TokenVersionService(MembershipRepository membershipRepository,
                               MembershipRoleRepository membershipRoleRepository,
                               MembershipVersionLogRepository versionLogRepository) {
        this.membershipRepository = membershipRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.versionLogRepository = versionLogRepository;
    }

    /**
     * 单个成员版本 +1 并记日志（角色/权限变更）。
     * 2026-11-12 宽容化：成员已删（孤儿绑定场景——membership_role 活着但 membership 软删）
     * → 跳过 + WARN 而非 404——成员删了本就无 token 可吊销，且批量 bump（bumpForRoleHolders/
     * bumpForUser）不该因单条脏数据整体失败（role-templates/permissions 同步曾因此全事务回滚）。
     */
    @Transactional
    public boolean bump(String membershipId, String changeType) {
        MembershipPO before = membershipRepository.findById(membershipId).orElse(null);
        if (before == null) {
            log.warn("token version bump skipped | membership gone（孤儿绑定？建议清理 gateway_membership_role）| membershipId={}",
                    membershipId);
            return false;
        }
        if (membershipRepository.bumpTokenVersion(membershipId) == 0) {
            return false; // 成员已删/不存在：无 token 可吊销，仅靠 tombstone
        }
        MembershipPO after = membershipRepository.findById(membershipId).orElseThrow();
        int version = after.getTokenVersion() == null ? 0 : after.getTokenVersion();
        versionLogRepository.record(membershipId, before.getTenantId(), version, changeType);
        return true;
    }

    /**
     * 某角色所有持有者批量 +1（角色权限变更影响全体，PERM_CHANGE）。
     * @return 实际 bump 成功的成员数（孤儿绑定自动跳过，不计入）
     */
    @Transactional
    public int bumpForRoleHolders(String roleId, String changeType) {
        List<String> membershipIds = membershipRoleRepository.findMembershipIdsByRole(roleId);
        int bumped = 0;
        for (String membershipId : membershipIds) {
            if (bump(membershipId, changeType)) {
                bumped++;
            }
        }
        return bumped;
    }

    /** 成员移除 → 记 tombstone（parlant 缓存清除该成员，旧 token 立即拒绝；不 bump 版本号）。 */
    @Transactional
    public void recordRemoval(String membershipId, String tenantId) {
        versionLogRepository.record(membershipId, tenantId, 0, "MEMBERSHIP_REMOVE");
    }

    /** 租户停用/删除 → 该租户全部 ACTIVE 成员批量 bump（G1：租户停用时已登录 token 即时失效）。 */
    @Transactional
    public void bumpForTenant(String tenantId, String changeType) {
        for (MembershipPO m : membershipRepository.listByTenant(tenantId)) {
            if ("ACTIVE".equals(m.getMembershipStatus())) {
                bump(m.getMembershipId(), changeType);
            }
        }
    }

    /** 某用户改密等会话安全事件：其所有 ACTIVE 成员关系版本 +1。 */
    @Transactional
    public void bumpForUser(String userId, String changeType) {
        for (MembershipPO m : membershipRepository.listByUser(userId)) {
            if ("ACTIVE".equals(m.getMembershipStatus())) {
                bump(m.getMembershipId(), changeType);
            }
        }
    }
}

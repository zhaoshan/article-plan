package com.unify.iam.app.app.service.admin;

import com.unify.iam.api.dto.admin.CreateMemberRequest;
import com.unify.iam.api.dto.admin.SetRolesRequest;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.authorization.infra.persistence.po.MembershipRolePO;
import com.unify.iam.authorization.infra.persistence.po.RolePO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository;
import com.unify.iam.authorization.infra.persistence.repository.MembershipRoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.identity.infra.persistence.repository.UserRepository;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import com.unify.iam.app.app.service.AuditService;
import com.unify.iam.app.app.service.TokenVersionService;
import com.unify.iam.app.security.TenantScopeGuard;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 管理面成员服务（docs/04 §3.2，iam:member:*；docs/06 §3.3 租户级作用域）。
 */
@Service
public class AdminMemberService {

    private final MembershipRepository membershipRepository;
    private final TenantRepository tenantRepository;
    private final UserRepository userRepository;
    private final MembershipRoleRepository membershipRoleRepository;
    private final RoleRepository roleRepository;
    private final TenantScopeGuard tenantScopeGuard;
    private final TokenVersionService tokenVersionService;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final ApplicationRoleTemplateRepository applicationRoleTemplateRepository;
    private final AuditService auditService;
    private final com.unify.iam.app.app.service.QuotaService quotaService;

    public AdminMemberService(MembershipRepository membershipRepository,
                              TenantRepository tenantRepository,
                              UserRepository userRepository,
                              MembershipRoleRepository membershipRoleRepository,
                              RoleRepository roleRepository,
                              TenantScopeGuard tenantScopeGuard,
                              TokenVersionService tokenVersionService,
                              TenantApplicationRepository tenantApplicationRepository,
                              ApplicationRoleTemplateRepository applicationRoleTemplateRepository,
                              AuditService auditService,
                              com.unify.iam.app.app.service.QuotaService quotaService) {
        this.membershipRepository = membershipRepository;
        this.tenantRepository = tenantRepository;
        this.userRepository = userRepository;
        this.membershipRoleRepository = membershipRoleRepository;
        this.roleRepository = roleRepository;
        this.tenantScopeGuard = tenantScopeGuard;
        this.tokenVersionService = tokenVersionService;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.applicationRoleTemplateRepository = applicationRoleTemplateRepository;
        this.auditService = auditService;
        this.quotaService = quotaService;
    }

    public List<MembershipPO> listByTenant(JwtClaims claims, String tenantId) {
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        return membershipRepository.listByTenant(tenantId);
    }

    /** 成员当前角色（管理台授角色回显）。限该成员所在租户。 */
    public List<RolePO> getRoles(JwtClaims claims, String membershipId) {
        MembershipPO membership = membershipRepository.findById(membershipId)
                .orElseThrow(() -> AuthException.notFound("成员关系不存在"));
        tenantScopeGuard.assertTenantScope(claims, membership.getTenantId());
        return membershipRoleRepository.listByMembership(membershipId).stream()
                .map(mr -> roleRepository.findById(mr.getRoleId()))
                .filter(java.util.Optional::isPresent)
                .map(java.util.Optional::get)
                .toList();
    }

    /** 添加成员：建 membership（ACTIVE，ADMIN 加入）+ 绑定角色（DIRECT）。限本租户（租户级）或任意（平台级）。 */
    @Transactional
    public String add(JwtClaims claims, CreateMemberRequest request) {
        String tenantId = request.tenantId().trim();
        String userId = request.userId().trim();
        tenantScopeGuard.assertTenantScope(claims, tenantId);
        quotaService.assertMemberSeat(tenantId); // G1：席位强制
        tenantRepository.findById(tenantId).orElseThrow(() -> AuthException.notFound("租户不存在"));
        userRepository.findByUserId(userId).orElseThrow(() -> AuthException.notFound("用户不存在"));
        if (membershipRepository.findByTenantAndUser(tenantId, userId).isPresent()) {
            throw AuthException.badRequest("用户已是该租户成员");
        }
        String membershipId = IdGenerator.newBizId();
        MembershipPO po = new MembershipPO();
        po.setMembershipId(membershipId);
        po.setTenantId(tenantId);
        po.setUserId(userId);
        po.setMembershipStatus("ACTIVE");
        po.setJoinSource("ADMIN");
        po.setIsDefault(0);
        membershipRepository.create(po);
        if (request.roleIds() != null && !request.roleIds().isEmpty()) {
            membershipRoleRepository.replaceDirectRoles(membershipId, request.roleIds());
        }
        return membershipId;
    }

    /** 覆盖式设置成员角色（DIRECT）。限该成员所在租户。角色变更后 bump 令牌版本（方案 c 即时吊销）。
     *  G3：若为最后一名租户管理员且新角色集不再含管理能力 → 阻断（防把最后 Admin 降权）。 */
    @Transactional
    public void setRoles(JwtClaims claims, String membershipId, SetRolesRequest request) {
        MembershipPO membership = membershipRepository.findById(membershipId)
                .orElseThrow(() -> AuthException.notFound("成员关系不存在"));
        tenantScopeGuard.assertTenantScope(claims, membership.getTenantId());
        assertKeepsAdmin(membership.getTenantId(), membershipId, request.roleIds());
        List<String> oldRoleIds = membershipRoleRepository.listByMembership(membershipId).stream()
                .map(mr -> mr.getRoleId().trim()).toList();
        membershipRoleRepository.replaceDirectRoles(membershipId, request.roleIds());
        tokenVersionService.bump(membershipId, "ROLE_CHANGE");
        // G5-b：成员改角色审计，含变更前后角色集
        auditService.audit().event("ADMIN_SET_MEMBER_ROLES").actor(claims.userId())
                .tenant(membership.getTenantId().trim()).target("MEMBERSHIP", membershipId)
                .before(oldRoleIds).after(request.roleIds()).write(Map.of());
    }

    /** 移除成员。限该成员所在租户。移除后记 tombstone（方案 c：parlant 清除缓存，旧 token 立即拒绝）。
     *  G3：最后一名租户管理员不可移除。 */
    public void remove(JwtClaims claims, String membershipId) {
        MembershipPO membership = membershipRepository.findById(membershipId)
                .orElseThrow(() -> AuthException.notFound("成员关系不存在"));
        tenantScopeGuard.assertTenantScope(claims, membership.getTenantId());
        String tenantId = membership.getTenantId();
        assertKeepsAdmin(tenantId, membershipId, null);
        membershipRepository.logicalDelete(membershipId);
        tokenVersionService.recordRemoval(membershipId, tenantId);
    }

    /** 停用成员（SUSPENDED）：不能访问该租户，但保留关系与角色（区别于移除）。停用即时失效（bump）。
     *  G3：最后一名租户管理员不可停用。恢复后按原角色重新登录。 */
    @Transactional
    public void suspend(JwtClaims claims, String membershipId) {
        MembershipPO membership = membershipRepository.findById(membershipId)
                .orElseThrow(() -> AuthException.notFound("成员关系不存在"));
        tenantScopeGuard.assertTenantScope(claims, membership.getTenantId());
        if ("SUSPENDED".equals(membership.getMembershipStatus())) {
            throw AuthException.badRequest("成员已停用");
        }
        assertKeepsAdmin(membership.getTenantId(), membershipId, null);
        String oldStatus = membership.getMembershipStatus();
        membership.setMembershipStatus("SUSPENDED");
        membershipRepository.update(membership);
        tokenVersionService.bump(membershipId, "MEMBER_SUSPENDED");
        // G5-b：成员停用审计
        Map<String, Object> before = new LinkedHashMap<>();
        before.put("membership_status", oldStatus);
        Map<String, Object> after = new LinkedHashMap<>();
        after.put("membership_status", "SUSPENDED");
        auditService.audit().event("ADMIN_SUSPEND_MEMBER").actor(claims.userId())
                .tenant(membership.getTenantId().trim()).target("MEMBERSHIP", membershipId)
                .before(before).after(after).write(Map.of());
    }

    /** 恢复成员（SUSPENDED → ACTIVE）：按当前角色/状态重新登录，不 bump（旧 token 已在停用时失效）。 */
    @Transactional
    public void restore(JwtClaims claims, String membershipId) {
        MembershipPO membership = membershipRepository.findById(membershipId)
                .orElseThrow(() -> AuthException.notFound("成员关系不存在"));
        tenantScopeGuard.assertTenantScope(claims, membership.getTenantId());
        if (!"SUSPENDED".equals(membership.getMembershipStatus())) {
            throw AuthException.badRequest("成员未停用");
        }
        membership.setMembershipStatus("ACTIVE");
        membershipRepository.update(membership);
        // G5-b：成员恢复审计
        Map<String, Object> before = new LinkedHashMap<>();
        before.put("membership_status", "SUSPENDED");
        Map<String, Object> after = new LinkedHashMap<>();
        after.put("membership_status", "ACTIVE");
        auditService.audit().event("ADMIN_RESTORE_MEMBER").actor(claims.userId())
                .tenant(membership.getTenantId().trim()).target("MEMBERSHIP", membershipId)
                .before(before).after(after).write(Map.of());
    }

    /**
     * G3 最后管理员保护（docs/requirements CommonCapabilities，方式 B）：
     * ① 每个业务系统的 is_owner（租户Admin）角色必须保留 ≥1 持有者——目标持任一 is_owner 角色且操作后
     *    该角色无其它 ACTIVE 持有者 → 阻断（按 role_code 匹配模板 is_owner；跨应用撞名已被 loadForApps 校验阻止）；
     * ② 兜底：IAM 租户管理能力（iam:member/role:write）不能归零（无 is_owner 标记的租户/应用）。
     */
    private void assertKeepsAdmin(String tenantId, String membershipId, Collection<String> newRoleIds) {
        // 当前成员包含iam管理相关权限、同时没有其他具备IAM管理能力的成员、并且新角色没有iam管理能力
        boolean iamGuard = membershipRoleRepository.membershipHasAdminCapability(membershipId)
                && !membershipRoleRepository.tenantHasAnotherActiveAdmin(tenantId, membershipId)
                && !keepsIamCapability(newRoleIds);
        boolean ownerGuard = soleIsOwnerAfter(tenantId, membershipId, newRoleIds);
        if (iamGuard || ownerGuard) {
            throw AuthException.badRequest("至少保留一名有效租户管理员");
        }
    }

    /** 新角色集是否仍含「租户管理能力」角色（② 的降权放行）。 */
    private boolean keepsIamCapability(Collection<String> newRoleIds) {
        return newRoleIds != null && newRoleIds.stream().anyMatch(membershipRoleRepository::roleHasAdminCapability);
    }

    /** ① 目标当前持任一 is_owner 角色，且操作后该角色无其它 ACTIVE 持有者 → 唯一 Owner，需阻断。 */
    private boolean soleIsOwnerAfter(String tenantId, String membershipId, Collection<String> newRoleIds) {
        List<String> appCodes = tenantApplicationRepository.findAppCodesByTenant(tenantId);
        Set<String> ownerCodes = new HashSet<>(applicationRoleTemplateRepository.listIsOwnerRoleCodes(appCodes));
        if (ownerCodes.isEmpty()) {
            return false;
        }
        Set<String> newIds = newRoleIds == null ? Set.of()
                : newRoleIds.stream().map(String::trim).collect(Collectors.toSet());
        for (MembershipRolePO mr : membershipRoleRepository.listByMembership(membershipId)) {
            String roleId = mr.getRoleId().trim();
            if (newIds.contains(roleId)) {
                continue; // 操作后仍持有该角色
            }
            String code = roleRepository.findById(roleId)
                    .map(RolePO::getRoleCode).map(String::trim).orElse(null);
            if (code == null || !ownerCodes.contains(code)) {
                continue; // 非 is_owner 角色
            }
            if (!membershipRoleRepository.roleHasAnotherActiveHolder(roleId, membershipId)) {
                return true; // 该 is_owner 角色只剩目标一人
            }
        }
        return false;
    }
}

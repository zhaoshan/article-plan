package com.unify.iam.app;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.unify.iam.api.dto.auth.LoginResponse;
import com.unify.iam.common.util.BCryptUtils;
import com.unify.iam.common.util.IdGenerator;
import com.unify.iam.common.util.JsonUtils;
import jakarta.servlet.http.Cookie;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.MockMvcPrint;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;

/** 真实 MySQL 隔离数据验证：切换、续签、旧凭据与当前租户的边界。 */
@Transactional
@AutoConfigureMockMvc(print = MockMvcPrint.NONE)
class SwitchTenantSessionIntegrationTest extends IamIntegrationTestBase {

    private String userId;
    private String password;
    private String tenantA;
    private String tenantB;
    private String tenantC;
    private String membershipA;
    private String membershipB;
    private String membershipC;

    @BeforeEach
    void isolatedUserAndThreeTenants() {
        userId = IdGenerator.newBizId();
        password = IdGenerator.newBizId();
        tenantA = IdGenerator.newBizId();
        tenantB = IdGenerator.newBizId();
        tenantC = IdGenerator.newBizId();
        jdbcTemplate.update("""
                INSERT INTO gateway_user (user_id, username, password_hash, default_tenant_id, email_verified)
                VALUES (?, ?, ?, ?, 1)
                """, userId, userId, BCryptUtils.hash(password), tenantA);
        jdbcTemplate.update("""
                INSERT INTO gateway_user_identity (user_identity_id, user_id, provider_type, provider_key)
                VALUES (?, ?, 'LOCAL', 'password')
                """, IdGenerator.newBizId(), userId);
        membershipA = tenantAndMembership(tenantA, "ORGANIZATION", 1);
        membershipB = tenantAndMembership(tenantB, "PERSONAL", 0);
        membershipC = tenantAndMembership(tenantC, "ORGANIZATION", 0);
    }

    private String tenantAndMembership(String tenantId, String type, int isDefault) {
        String membershipId = IdGenerator.newBizId();
        jdbcTemplate.update("""
                INSERT INTO gateway_tenant (tenant_id, tenant_code, tenant_name, tenant_type, owner_user_id)
                VALUES (?, ?, 'Switch session isolated tenant', ?, ?)
                """, tenantId, tenantId, type, userId);
        jdbcTemplate.update("""
                INSERT INTO gateway_membership (membership_id, tenant_id, user_id, is_default)
                VALUES (?, ?, ?, ?)
                """, membershipId, tenantId, userId, isDefault);
        return membershipId;
    }

    private LoginResponse login() throws Exception {
        return credentials(mockMvc.perform(post("/api/v1/auth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("username", userId, "password", b64(password)))))
                .andExpect(status().isOk()).andReturn());
    }

    private LoginResponse switchTo(LoginResponse current, String targetMembership) throws Exception {
        return credentials(mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + current.accessToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("membership_id", targetMembership))))
                .andExpect(status().isOk()).andReturn());
    }

    private LoginResponse refresh(LoginResponse current) throws Exception {
        // 没有 Bearer：刷新只认请求体中的 refresh_token。
        return credentials(mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("refresh_token", current.refreshToken()))))
                .andExpect(status().isOk()).andReturn());
    }

    private LoginResponse credentials(MvcResult result) throws Exception {
        String json = result.getResponse().getContentAsString();
        Map<String, Object> data = unwrapData(json);
        assertThat(data.keySet()).contains(
                "access_token", "refresh_token", "token_type", "expires_in", "refresh_expires_in", "user");
        assertThat(data.containsKey("tenantId")).isFalse();
        assertThat(result.getResponse().getHeaders("Set-Cookie")).isEmpty();
        assertThat(result.getRequest().getSession(false)).isNull();
        return JsonUtils.fromJson(dataJson(json), LoginResponse.class);
    }

    private void me(LoginResponse current, String tenantId, String membershipId) throws Exception {
        mockMvc.perform(get("/api/v1/auth/me")
                        .header("Authorization", "Bearer " + current.accessToken())
                        // cookie / query 都不能覆盖已验签 Bearer 的上下文。
                        .cookie(new Cookie("tenant_id", tenantA), new Cookie("JSESSIONID", "old-session"))
                        .param("tenant_id", tenantA).param("membership_id", membershipA))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.userId").value(userId))
                .andExpect(jsonPath("$.data.tenantId").value(tenantId))
                .andExpect(jsonPath("$.data.membershipId").value(membershipId))
                .andExpect(jsonPath("$.data.tenant_id").doesNotExist())
                .andExpect(jsonPath("$.data.user").doesNotExist());
        mockMvc.perform(get("/api/v1/auth/session-status")
                        .header("Authorization", "Bearer " + current.accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.tenant_id").value(tenantId))
                .andExpect(jsonPath("$.data.membership_id").value(membershipId))
                .andExpect(jsonPath("$.data.valid").value(true));
    }

    @Test
    void loginA_switchB_meB_refresh_meB_switchC_refresh_meC() throws Exception {
        LoginResponse a = login();
        me(a, tenantA, membershipA);
        LoginResponse b = switchTo(a, membershipB);
        me(b, tenantB, membershipB);
        LoginResponse refreshedB = refresh(b);
        me(refreshedB, tenantB, membershipB);

        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("refresh_token", b.refreshToken()))))
                .andExpect(status().isUnauthorized());

        LoginResponse c = switchTo(refreshedB, membershipC);
        me(c, tenantC, membershipC);
        me(refresh(c), tenantC, membershipC);

        // is_default 是下次密码登录的入口，不是当前租户选中标记。
        mockMvc.perform(get("/api/v1/auth/memberships")
                        .header("Authorization", "Bearer " + c.accessToken()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.count").value(3))
                .andExpect(jsonPath("$.data.memberships[?(@.membership_id == '" + membershipA
                        + "')].is_default").value(contains(1)))
                .andExpect(jsonPath("$.data.memberships[?(@.membership_id == '" + membershipC
                        + "')].is_default").value(contains(0)));
        me(login(), tenantA, membershipA);
    }

    @Test
    void retainingOldAccessOrRefreshReproducesOriginalTenantWithoutChangingNewCredentials() throws Exception {
        LoginResponse a = login();
        LoginResponse b = switchTo(a, membershipB);
        me(b, tenantB, membershipB);
        me(a, tenantA, membershipA);

        // 模拟客户端仅替换 access、仍保留 A refresh；即使 Bearer 是 B，刷新也只认 A refresh。
        LoginResponse restoredA = credentials(mockMvc.perform(post("/api/v1/auth/refresh")
                        .header("Authorization", "Bearer " + b.accessToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("refresh_token", a.refreshToken()))))
                .andExpect(status().isOk()).andReturn());
        me(restoredA, tenantA, membershipA);
        me(b, tenantB, membershipB);
        me(refresh(b), tenantB, membershipB);

        // 没有隐式 cookie 登录态；仅 cookie 不能恢复任何当前租户。
        mockMvc.perform(get("/api/v1/auth/me")
                        .cookie(new Cookie("tenant_id", tenantA), new Cookie("JSESSIONID", "old-session")))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void targetMustBeOwnedMembershipIdAndRequestUsesSnakeCase() throws Exception {
        LoginResponse a = login();
        for (Map<String, String> body : java.util.List.of(
                Map.of("membershipId", membershipB), Map.of("tenant_id", tenantB))) {
            mockMvc.perform(post("/api/v1/auth/switch-tenant")
                            .header("Authorization", "Bearer " + a.accessToken())
                            .contentType(MediaType.APPLICATION_JSON).content(JsonUtils.toJson(body)))
                    .andExpect(status().isBadRequest());
        }
        // 字段名正确但填的是 tenant_id，同样不能作为 membership_id 使用。
        mockMvc.perform(post("/api/v1/auth/switch-tenant")
                        .header("Authorization", "Bearer " + a.accessToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("membership_id", tenantB))))
                .andExpect(status().isForbidden());
        mockMvc.perform(post("/api/v1/auth/refresh")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(JsonUtils.toJson(Map.of("refreshToken", a.refreshToken()))))
                .andExpect(status().isBadRequest());
        me(a, tenantA, membershipA);
    }
}

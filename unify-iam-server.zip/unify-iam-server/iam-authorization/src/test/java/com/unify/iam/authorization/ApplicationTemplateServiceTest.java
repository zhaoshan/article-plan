package com.unify.iam.authorization;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.unify.iam.authorization.app.model.TemplatePermissionAddResult;
import com.unify.iam.authorization.app.model.TemplatePermissionGrant;
import com.unify.iam.authorization.app.service.ApplicationTemplateService;
import com.unify.iam.authorization.infra.persistence.po.ApplicationRoleTemplatePO;
import com.unify.iam.authorization.infra.persistence.po.PermissionPO;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRepository;
import com.unify.iam.authorization.infra.persistence.repository.ApplicationRoleTemplateRepository;
import com.unify.iam.authorization.infra.persistence.repository.PermissionRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.common.exception.ErrorCode;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** {@link ApplicationTemplateService}：模板新增权限点 + create_permission 自动登记字典。 */
@ExtendWith(MockitoExtension.class)
class ApplicationTemplateServiceTest {

    @Mock
    private ApplicationRepository applicationRepository;
    @Mock
    private ApplicationRoleTemplateRepository templateRepository;
    @Mock
    private PermissionRepository permissionRepository;

    private ApplicationTemplateService service;

    @BeforeEach
    void setUp() {
        service = new ApplicationTemplateService(applicationRepository, templateRepository, permissionRepository);
    }

    private ApplicationRoleTemplatePO template(String... codes) {
        ApplicationRoleTemplatePO po = new ApplicationRoleTemplatePO();
        po.setId(7L);
        po.setTemplateId("tpl-1");
        po.setAppCode("parlant-agent-server");
        po.setRoleCode("Viewer");
        po.setPermissionCodesJson(com.unify.iam.common.util.JsonUtils.toJson(List.of(codes)));
        return po;
    }

    @Test
    void unknownPermissionRejectedWhenCreateDisabled() {
        when(templateRepository.findByAppCodeAndRoleCode("parlant-agent-server", "Viewer"))
                .thenReturn(Optional.of(template("agent:read")));
        when(permissionRepository.findIdByCodes(List.of("parlant-agent:deploy:read"))).thenReturn(Map.of());

        TemplatePermissionGrant grant = new TemplatePermissionGrant(
                "parlant-agent-server", "Viewer", "parlant-agent:deploy:read", "ops-zhao",
                false, null, null, null, null);

        assertThatThrownBy(() -> service.addPermission(grant))
                .isInstanceOf(AuthException.class)
                .extracting(e -> ((AuthException) e).getCode()).isEqualTo(ErrorCode.PERMISSION_NOT_FOUND.code());
        verify(permissionRepository, never()).create(any());
    }

    @Test
    void createPermissionRegistersDictionaryEntryBeforeAppending() {
        when(templateRepository.findByAppCodeAndRoleCode("parlant-agent-server", "Viewer"))
                .thenReturn(Optional.of(template("agent:read")));
        when(permissionRepository.findIdByCodes(List.of("parlant-agent:deploy:read"))).thenReturn(Map.of());
        when(templateRepository.listByRoleCode("Viewer")).thenReturn(List.of(template("agent:read")));

        TemplatePermissionGrant grant = new TemplatePermissionGrant(
                "parlant-agent-server", "Viewer", "parlant-agent:deploy:read", "ops-zhao",
                true, "查看部署", "Deploy", "read", "Deploy");

        TemplatePermissionAddResult result = service.addPermission(grant);

        assertThat(result.added()).isTrue();
        assertThat(result.permissionCreated()).isTrue();
        assertThat(result.permissionCount()).isEqualTo(2);
        ArgumentCaptor<PermissionPO> captor = ArgumentCaptor.forClass(PermissionPO.class);
        verify(permissionRepository).create(captor.capture());
        PermissionPO created = captor.getValue();
        assertThat(created.getPermissionCode()).isEqualTo("parlant-agent:deploy:read");
        assertThat(created.getPermissionName()).isEqualTo("查看部署");
        assertThat(created.getResourceType()).isEqualTo("Deploy");
        assertThat(created.getAction()).isEqualTo("read");
        assertThat(created.getAppCode()).isEqualTo("parlant-agent-server");
        assertThat(created.getTenantGrantable()).isEqualTo(1);
        assertThat(created.getCategory()).isEqualTo("Deploy");
        assertThat(created.getPermissionStatus()).isEqualTo("ACTIVE");
        assertThat(created.getUpdateBy()).isEqualTo("ops-zhao");
    }

    @Test
    void createPermissionWithoutMetadataIsBadRequest() {
        when(templateRepository.findByAppCodeAndRoleCode("parlant-agent-server", "Viewer"))
                .thenReturn(Optional.of(template("agent:read")));
        when(permissionRepository.findIdByCodes(List.of("parlant-agent:deploy:read"))).thenReturn(Map.of());

        TemplatePermissionGrant grant = new TemplatePermissionGrant(
                "parlant-agent-server", "Viewer", "parlant-agent:deploy:read", "ops-zhao",
                true, "查看部署", null, "read", null);

        assertThatThrownBy(() -> service.addPermission(grant))
                .isInstanceOf(AuthException.class)
                .extracting(e -> ((AuthException) e).getCode())
                .isEqualTo(ErrorCode.PERMISSION_METADATA_REQUIRED.code());
        verify(permissionRepository, never()).create(any());
    }

    @Test
    void existingDictionaryEntryDoesNotRecreate() {
        when(templateRepository.findByAppCodeAndRoleCode("parlant-agent-server", "Viewer"))
                .thenReturn(Optional.of(template("agent:read")));
        when(permissionRepository.findIdByCodes(List.of("agent:build")))
                .thenReturn(Map.of("agent:build", "p-1"));
        when(templateRepository.listByRoleCode("Viewer")).thenReturn(List.of(template("agent:read")));

        TemplatePermissionGrant grant = new TemplatePermissionGrant(
                "parlant-agent-server", "Viewer", "agent:build", "ops-zhao",
                true, null, null, null, null);

        TemplatePermissionAddResult result = service.addPermission(grant);

        assertThat(result.added()).isTrue();
        assertThat(result.permissionCreated()).isFalse();
        verify(permissionRepository, never()).create(any());
    }

    @Test
    void alreadyContainedPermissionIsIdempotentWithoutAnyWrite() {
        when(templateRepository.findByAppCodeAndRoleCode("parlant-agent-server", "Viewer"))
                .thenReturn(Optional.of(template("agent:read", "parlant-agent:deploy:read")));
        when(permissionRepository.findIdByCodes(List.of("parlant-agent:deploy:read")))
                .thenReturn(Map.of("parlant-agent:deploy:read", "p-9"));

        TemplatePermissionGrant grant = new TemplatePermissionGrant(
                "parlant-agent-server", "Viewer", "parlant-agent:deploy:read", "ops-zhao",
                true, null, null, null, null);

        TemplatePermissionAddResult result = service.addPermission(grant);

        assertThat(result.added()).isFalse();
        assertThat(result.permissionCreated()).isFalse();
        assertThat(result.permissionCount()).isEqualTo(2);
        verify(templateRepository, never()).updatePermissionCodes(any());
        verify(permissionRepository, never()).create(any());
    }
}

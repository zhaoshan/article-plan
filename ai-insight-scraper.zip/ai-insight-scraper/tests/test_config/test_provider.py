"""config 配置解析测试"""

import json
import pytest
from src.config.provider import FileConfigProvider
from src.config.traversal_config import load_traversal_config, _parse_bool
from src.models.traversal_config import DomainTraversalConfig


class TestFileConfigProvider:
    """FileConfigProvider 测试"""

    def test_loads_existing_file(self, sample_config_dir):
        """加载存在的配置文件"""
        provider = FileConfigProvider(sample_config_dir)
        config = provider.load_json("traversal_rule_config.json")
        assert "example.com" in config
        assert "no-outer.com" in config

    def test_returns_empty_for_missing_file(self, sample_config_dir):
        """不存在的文件返回空字典"""
        provider = FileConfigProvider(sample_config_dir)
        config = provider.load_json("nonexistent.json")
        assert config == {}

    def test_raises_for_invalid_dir(self, tmp_path):
        """无效目录抛出异常"""
        nonexistent = tmp_path / "nope"
        with pytest.raises(FileNotFoundError):
            FileConfigProvider(nonexistent)


class TestLoadTraversalConfig:
    """load_traversal_config 测试"""

    def test_finds_config_by_domain(self, sample_config_dir):
        """按域名找到配置"""
        config = load_traversal_config("example.com", sample_config_dir)
        assert isinstance(config, DomainTraversalConfig)
        assert config.need_outer_site is True
        assert config.outer_site_whitelist == ["partner.com"]
        assert config.drill_down_levels == 2

    def test_returns_defaults_for_unknown_domain(self, sample_config_dir):
        """未知域名返回默认值"""
        config = load_traversal_config("unknown-domain.com", sample_config_dir)
        assert config.need_outer_site is True
        assert config.outer_site_whitelist == []
        assert config.drill_down_levels == 0

    def test_need_outer_site_false(self, sample_config_dir):
        """need_outer_site 为 False 的配置"""
        config = load_traversal_config("no-outer.com", sample_config_dir)
        assert config.need_outer_site is False

    def test_drill_down_levels_default_zero(self, sample_config_dir):
        """drill_down_levels 默认为 0"""
        config = load_traversal_config("unknown.com", sample_config_dir)
        assert config.drill_down_levels == 0


class TestParseBool:
    """_parse_bool 测试"""

    @pytest.mark.parametrize("value,expected", [
        ("True", True),
        ("true", True),
        ("False", False),
        ("false", False),
        ("1", True),
        ("yes", True),
        ("0", False),
        ("no", False),
        (True, True),
        (False, False),
    ])
    def test_parse_bool(self, value, expected):
        assert _parse_bool(value) == expected

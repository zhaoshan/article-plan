package com.unify.iam.app.adapter.controller;

import com.unify.iam.common.exception.ErrorCode;
import com.unify.iam.api.model.JwtClaims;
import com.unify.iam.app.security.JwtAuth;
import com.unify.iam.app.security.JwtSigner;
import com.unify.iam.authorization.infra.persistence.repository.RoleRepository;
import com.unify.iam.authorization.infra.persistence.repository.TenantApplicationRepository;
import com.unify.iam.common.exception.AuthException;
import com.unify.iam.tenant.app.service.MembershipResolver;
import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 应用可用性能力端点（docs/user-manual 03 §3.2；「选租户 / 跳 IAM 控制台 / 阻断」的分流依据）。
 *
 * <p>登录后 hub 据此判断「该用户能否进入目标业务应用」：
 * {@code memberships} = 用户在【启用该应用】的租户里的成员（多租户选择弹窗数据源；空 = 无可用租户）；
 * {@code is_platform_admin} = 是否持有平台级角色（无可用租户时据此引导到 IAM 控制台，否则阻断）。
 */
@RestController
@RequestMapping("/api/v1/auth")
public class AppAccessController {

    private final JwtSigner jwtSigner;
    private final MembershipResolver membershipResolver;
    private final TenantApplicationRepository tenantApplicationRepository;
    private final TenantRepository tenantRepository;
    private final RoleRepository roleRepository;

    public AppAccessController(JwtSigner jwtSigner,
                               MembershipResolver membershipResolver,
                               TenantApplicationRepository tenantApplicationRepository,
                               TenantRepository tenantRepository,
                               RoleRepository roleRepository) {
        this.jwtSigner = jwtSigner;
        this.membershipResolver = membershipResolver;
        this.tenantApplicationRepository = tenantApplicationRepository;
        this.tenantRepository = tenantRepository;
        this.roleRepository = roleRepository;
    }

    @GetMapping("/app-access")
    public Map<String, Object> appAccess(
            @RequestHeader(value = "Authorization", required = false) String authorization,
            @RequestParam(value = "app_code") String appCode) {
        JwtClaims claims = JwtAuth.verify(jwtSigner, authorization);
        String app = appCode == null ? "" : appCode.trim();
        if (app.isEmpty()) {
            throw AuthException.badRequest(ErrorCode.APP_CODE_REQUIRED);
        }
        Set<String> appTenants = new HashSet<>(tenantApplicationRepository.findTenantIdsByAppCode(app));
        List<MembershipPO> memberships = membershipResolver.listByUser(claims.userId());

        // 可选租户 = 用户的 ACTIVE 成员 ∩ 启用了该应用的租户
        List<Map<String, Object>> usable = memberships.stream()
                .filter(m -> "ACTIVE".equals(m.getMembershipStatus()) && appTenants.contains(m.getTenantId().trim()))
                .map(this::toBrief)
                .toList();
        // 平台管理员：任一 ACTIVE 成员持 PLATFORM 作用域角色（与 TenantScopeGuard 同口径）
        boolean isPlatformAdmin = memberships.stream()
                .filter(m -> "ACTIVE".equals(m.getMembershipStatus()))
                .anyMatch(m -> roleRepository.hasPlatformRoleByMembership(m.getMembershipId()));

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("memberships", usable);
        result.put("is_platform_admin", isPlatformAdmin);
        return result;
    }

    private Map<String, Object> toBrief(MembershipPO m) {
        Map<String, Object> e = new LinkedHashMap<>();
        e.put("membership_id", m.getMembershipId());
        e.put("tenant_id", m.getTenantId());
        tenantRepository.findById(m.getTenantId()).ifPresent(t -> {
            e.put("tenant_name", t.getTenantName());
            e.put("tenant_code", t.getTenantCode());
        });
        return e;
    }
}

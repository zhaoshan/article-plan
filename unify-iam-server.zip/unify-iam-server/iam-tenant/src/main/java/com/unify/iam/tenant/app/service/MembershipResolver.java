package com.unify.iam.tenant.app.service;

import com.unify.iam.tenant.infra.persistence.po.MembershipPO;
import com.unify.iam.tenant.infra.persistence.po.TenantPO;
import com.unify.iam.tenant.infra.persistence.repository.MembershipRepository;
import com.unify.iam.tenant.infra.persistence.repository.TenantRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

/**
 * 成员关系解析：定位用户在租户中的默认 ACTIVE 成员关系（令牌管线第二步）。
 *
 * <p>成员关系一律要求其租户**存在且 ACTIVE**（逻辑删除/停用的租户不可登录、不可切换，
 * 否则会出现"租户已删仍可切换"的漏洞）。
 */
@Service
public class MembershipResolver {

    private final MembershipRepository membershipRepository;
    private final TenantRepository tenantRepository;

    public MembershipResolver(MembershipRepository membershipRepository,
                              TenantRepository tenantRepository) {
        this.membershipRepository = membershipRepository;
        this.tenantRepository = tenantRepository;
    }

    /** 取用户默认 ACTIVE 成员关系（且租户有效）；无则空（调用方决定 401 语义）。 */
    public Optional<MembershipPO> findDefaultActiveMembership(String userId) {
        return membershipRepository.findDefaultActive(userId)
                .filter(this::tenantActive);
    }

    /** 按成员关系 ID 查（dev-token 指定 membership 用；不含租户状态过滤，由调用方自定）。 */
    public Optional<MembershipPO> findById(String membershipId) {
        return membershipRepository.findById(membershipId);
    }

    /** 按成员关系 ID 查且租户必须有效（refresh 轮换/续签用——漏查租户状态会让停用租户绕过续签）。 */
    public Optional<MembershipPO> findActiveById(String membershipId) {
        return findById(membershipId).filter(this::tenantActive);
    }

    /** 某用户的全部成员关系（多租户切换用）——过滤掉租户已删除/停用的。 */
    public List<MembershipPO> listByUser(String userId) {
        return membershipRepository.listByUser(userId).stream()
                .filter(this::tenantActive)
                .toList();
    }

    /** 成员关系所属租户是否有效（存在且 ACTIVE；findById 已排除逻辑删除 delete_flag=1）。 */
    private boolean tenantActive(MembershipPO membership) {
        return tenantRepository.findById(membership.getTenantId().trim())
                .map(TenantPO::getTenantStatus)
                .map("ACTIVE"::equals)
                .orElse(false);
    }
}

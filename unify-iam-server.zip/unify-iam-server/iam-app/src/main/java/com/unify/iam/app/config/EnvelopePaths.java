package com.unify.iam.app.config;

/**
 * 统一信封作用域（docs/user-manual/05 §使用方与鉴权模型）：
 * 全部 JSON API（{@code /api/v1/**}）套 {@code {success, code, message, data}}——管理台、
 * hub、业务系统接口统一；失败仍是真实 HTTP 状态码 + 信封（{@code message} 为文案）。
 *
 * <p>唯一排除：{@code /api/v1/auth/oidc/**}——标准 OIDC 重定向流程（authorize=302、
 * callback 成功=302 带 token 回跳前端），信封对重定向语义无意义，错误体保持真实状态码
 * + {@code {"detail":...}}。{@code /.well-known/jwks.json} 不在 {@code /api/v1/**} 下，
 * 天然保持裸 JWK Set（标准 JOSE 客户端直接消费，不可套）。
 */
public final class EnvelopePaths {

    private EnvelopePaths() {
    }

    /** 请求路径是否在信封作用域内。 */
    public static boolean inScope(String path) {
        if (path == null) {
            return false;
        }
        if (!path.startsWith("/api/v1/")) {
            return false;
        }
        return !path.startsWith("/api/v1/auth/oidc/");
    }
}

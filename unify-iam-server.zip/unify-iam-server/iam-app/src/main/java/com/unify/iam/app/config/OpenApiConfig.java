package com.unify.iam.app.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** springdoc OpenAPI 信息。 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI openApi() {
        return new OpenAPI().info(new Info()
                .title("platform-iam-service")
                .description("Gateway 权限体系 IAM 服务（E2E-1）：登录令牌 / JWKS / RBAC 上下文")
                .version("0.0.1-SNAPSHOT"));
    }
}
